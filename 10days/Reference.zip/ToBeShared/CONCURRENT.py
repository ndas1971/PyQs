   
###*** Multithreading
#daemon - process waits for non daemon thread/process while exiting 
#but process does not wait for daemon thread/process and exists(and in process cleanup-they are cleaned)
#daemon should be set before start()

import time
import random
import threading 

def w(sleeptime):
	time.sleep(sleeptime)
	print(threading.current_thread().getName()," Thread finished")

t = threading.Thread(target=w, args=(10,))
t.start(); print("Main thread")


t = threading.Thread(target=w)
t.start(); t.join(); print("Main thread")

##Another example 
import time
import random
import threading

def worker(sleeptime):
    print(threading.current_thread().getName(), "Entering")
    time.sleep(sleeptime)
    print(threading.current_thread().getName(), "exiting")
    
if __name__ == '__main__':
    print("sequentially")
    worker(1)
    print("Parallely")
    ths = []
    st = time.time()
    for i in range(10):
        th = threading.Thread(target=worker, args=(5,))
        ths.append(th)
    [th.start() for th in ths]
    [th.join() for th in ths]  # wait for ending
    print("Time taken:", round(time.time()-st, 3), " secs")

#With process 
import time
import random
import multiprocessing

def worker(sleeptime):
    print(multiprocessing.current_process().name, "Entering")
    time.sleep(sleeptime)
    print(multiprocessing.current_process().name, "exiting")
    
if __name__ == '__main__':
    print("sequentially")
    worker(1)
    print("Parallely")
    ths = []
    st = time.time()
    for i in range(10):
        th = multiprocessing.Process(target=worker, args=(5,))
        ths.append(th)
    [th.start() for th in ths]
    [th.join() for th in ths]  # wait for ending
    print("Time taken:", round(time.time()-st, 3), " secs")
    
#Note Signal Handling in Process in trickey
#SIGINT(CRTL+C) handling is inherited by child process if not ignored 
#So handle it in child process (KeyboardInterrupt is not child of Exception)
import time
import time
import random
import multiprocessing

def worker(sleeptime):
    try:
        print(multiprocessing.current_process().name, "Entering")
        time.sleep(sleeptime)
        print(multiprocessing.current_process().name, "exiting")
    except KeyboardInterrupt as ex:
        print(multiprocessing.current_process().name, 'KeyboardInterrupt - cleaning')
    
if __name__ == '__main__':
    ths = []
    for i in range(10):
        th = multiprocessing.Process(target=worker, args=(10,))
        ths.append(th)
    [th.start() for th in ths]
    while all( [not th.is_alive() for th in ths]):
        time.sleep(0.5)
    try:
        [th.join() for th in ths]  
    except KeyboardInterrupt as ex:
        print('KeyboardInterrupt')    
    
    
##RLock- threading 

#golbal variable are shared 
import threading , time 
shared= []
def proc(lck):
    global shared    
    print("before", threading.current_thread().getName())
    with lck:   #lck.accquire()
        print("Acquired", threading.current_thread().getName())
        time.sleep(2)
        shared.append(threading.current_thread().getName())
    #lck.release()
    time.sleep(2)    

ids = []
lock = threading.RLock() #one at time 
lock = threading.Semaphore(2) #two at time 
#A Semaphore can be released more times than it's acquired, 
#and that will raise its counter above the starting value. 
#A BoundedSemaphore can't be released more than no of acquire 
for i in range(10):
    t = threading.Thread(target=proc, args=(lock,))
    ids.append(t)
[t.start() for t in ids]
[t.join() for t in ids]



#With process , global variable are not shared , Use Array, Value or Manager.list/.dict 
# list(sequence)/list()/dict(mapping)/dict() for initial value 
# can contained nested Manager list/dict etc 

import  time 
import multiprocessing 


def proc(lck,shared):
    print("before", multiprocessing.current_process().name)
    with lck:   #lck.accquire()
        print("Acquired", multiprocessing.current_process().name)
        time.sleep(2)
        shared.append(multiprocessing.current_process().name)
    #lck.release()
    time.sleep(2)    


if __name__ == '__main__':
    ids = []
    manager = multiprocessing.Manager()
    shared = manager.list()
    lock = multiprocessing.RLock() #one at time 
    #lock = multiprocessing.Semaphore(2) #two at time 
    #A Semaphore can be released more times than it's acquired, 
    #and that will raise its counter above the starting value. 
    #A BoundedSemaphore can't be raised above the starting value
    for i in range(10):
        t = multiprocessing.Process(target=proc, args=(lock,shared))
        ids.append(t)
    [t.start() for t in ids]
    [t.join() for t in ids]
    print(shared)
    

##Queue
import queue
import threading
import time

def worker(q):
	while True:
		item = q.get()
		print(threading.current_thread().getName(), item)
		time.sleep(2)
		q.task_done()

		
que = queue.Queue()
for i in range(2):
	t = threading.Thread(target=worker, args=(que,))
	t.start()

for item in range(10):  #Only one thread get one item 
	que.put(item)

que.join()       # block until all tasks are done

#OR with Event 
import queue
import threading
import time, random

#Display buffer 
output = []  #list of tuples 


def display(lock, event, exit_event):
    displayindex = 0
    while True:
        if exit_event.is_set():
            break 
        event_is_set = event.wait() # waits for flag to true 
        print('Display ' , threading.current_thread().getName(), end=" ")
        #is there anything to display 
        while displayindex < len(output):
            with lock:
                print( output[displayindex] )
            displayindex += 1
        #reset the event 
        event.clear()  #flag is false 


def download(que,lock,event):
    while True:
        item = que.get() # blocks 
        print(threading.current_thread().getName(), "got", item)
        time.sleep(random.randint(1,5))		
        #Update output 
        with lock:
            output.append( (item, "OK") )
        que.task_done()
        event.set() #make flag true 
        
		
que = queue.Queue()
event = threading.Event()
lock = threading.RLock()
exit_event = threading.Event()
#Start download , make it daemon such that main thread exits 
for i in range(2):
    t = threading.Thread(target=download, args=(que,lock,event), daemon = True)
    t.start()
#Start download 
display_t = threading.Thread(target=display, args=(lock,event, exit_event))
display_t.start()

#Main Thread
for item in range(10):  #Only one thread get one item 
	que.put(item)

que.join() #Blocks until all items in the queue have been gotten and processed
exit_event.set()
display_t.join() #wait for display to end 


##process Queue 
#example 
from __future__ import print_function
from multiprocessing import Process, Queue, Pipe, RLock



class A(object):
    def __init__(self, v):
        self.value = v 
    def __repr__(self):
        return "A(%d)" % (self.value,)

def queuef(q, obj):
    q.put([42, None, 'hello', {'from': 'queue'}, obj])
    
def pipef(conn, obj):
    conn.send([42, None, 'hello', {'from': 'pipe'}, obj])
    conn.close()
    
if __name__ == '__main__':
    #lck
    lck = RLock()
    #A
    a = A(20)
    #Queue
    q = Queue()
    p = Process(target=queuef, args=(q, a))
    p.start()
    with lck:
        print(q.get())    # prints "[42, None, 'hello']"
    p.join()
    #Pipe
    parent_conn, child_conn = Pipe()
    p = Process(target=pipef, args=(child_conn, a))
    p.start()
    with lck:
        print(parent_conn.recv())   # prints "[42, None, 'hello']"
    p.join()
    
Joining processes that use queues
    Bear in mind that a process that has put items in a queue will wait 
    before terminating until all the buffered items are consumed 
    OR call the Queue.cancel_join_thread method of the queue to avoid this behaviour.
    #deadlock
    #A fix here would be to swap the last two lines (or simply remove the p.join() line).

    from multiprocessing import Process, Queue

    def f(q):
        q.put('X' * 1000000)

    if __name__ == '__main__':
        queue = Queue()
        p = Process(target=f, args=(queue,))
        p.start()
        p.join()                    # this deadlocks
        obj = queue.get()
    

##futures 

import threading , time 
import concurrent.futures
import os, os.path 

from functools import wraps 

def  profile(fun):
    def _inner(*args, **kargs):
        import time
        now = time.time()
        dont_print = 'dont_print' in kargs
        res = fun(*args,**kargs)
        if not dont_print:
            print(fun.__name__, "(", threading.current_thread().getName(), 
                "): ", round(time.time() - now, 2), " secs")
        return res
    return _inner
    
def  aprofile(afun):
    async def _inner(*args, **kargs):
        import time
        now = time.time()
        dont_print = 'dont_print' in kargs
        res = await afun(*args,**kargs)
        if not dont_print:
            print(afun.__name__, "(", threading.current_thread().getName(), 
                "): ", round(time.time() - now, 2), " secs")
        return res
    return _inner
    
#note local lambda can not be prickled , so 
#it is written as top level function which is pickable 
# note run time might be higher than sequential because of process creation
def get_dir_size(p):
    return FileUtil(p).getDirSize(dont_print=True)

class FileUtil:    
    def __init__(self, path):
        self.path = path
    def get_size(self, rootpath,files):
        ed = {}
        for file in files:
            try:
                ed[file] = os.path.getsize(os.path.join(rootpath,file))
            except Exception as ex:
                pass
        return ed
    @profile
    def getDirSize(self, **kwargs):
        s = 0
        for rootpath, dirs, files in os.walk(self.path):
            el = self.get_size(rootpath, files)
            #print(el, files,rootpath)
            s += sum(el.values())
        return s 
    @profile
    def getDirSizeThreaded(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        res = ex.map(lambda p : FileUtil(p).getDirSize(dont_print=True), 
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        ex.shutdown()
        return s 
    @profile
    def getDirSizeThreadedSubmit(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        fs = [ ex.submit( lambda p : FileUtil(p).getDirSize(dont_print=True), 
                    os.path.join(rootpath,d))
              for d in dirs]
        for res in concurrent.futures.as_completed(fs):
            s += res.result()
        ex.shutdown()
        return s 
    @profile
    def getDirSizeThreadedP(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ProcessPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        res = ex.map(get_dir_size, 
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        ex.shutdown()
        return s 
    @profile
    def getDirSizeThreadedSubmitP(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ProcessPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        fs = [ ex.submit( get_dir_size, 
                    os.path.join(rootpath,d))
              for d in dirs]
        for res in concurrent.futures.as_completed(fs):
            s += res.result()
        ex.shutdown()
        return s 
    @profile
    def getDirSizePoolP(self, ws=4):
        import os, os.path 
        s = 0
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        with multiprocessing.Pool(processes=ws) as pool: 
            res = pool.map(get_dir_size, 
                [os.path.join(rootpath,d) for d in dirs])
        
        s += sum(res)
        return s 
        
    @profile
    def getDirSizeThreadedEE(self, executor):
        s = 0
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        res = executor.map(lambda p : FileUtil(p).getDirSize(dont_print=True), 
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        return s 
    @aprofile 
    async def getDirSizeAsync(self, executor=None):
        s = 0
        rootpath, dirs, files = next( os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #awaitable loop.run_in_executor(executor, func, *args)
        #awaitable asyncio.gather(*aws, loop=None, return_exceptions=False)
        loop = asyncio.get_running_loop()
        async_jobs = [loop.run_in_executor(executor,
                                     lambda p: FileUtil(p).getDirSize(dont_print=True), 
                                     os.path.join(rootpath,d)) for d in dirs]
        res = await asyncio.gather(*async_jobs)
        s += sum(res)
        return s 
        
    @aprofile 
    async def getDirSizeAsync_v2(self,  executor=None):
        s = 0
        rootpath, dirs, files = next( os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #awaitable loop.run_in_executor(executor, func, *args)
        #awaitable asyncio.gather(*aws, loop=None, return_exceptions=False)
        loop = asyncio.get_running_loop()
        async_jobs = {loop.run_in_executor(executor,
                                     lambda p: FileUtil(p).getDirSize(dont_print=True), 
                                     os.path.join(rootpath,d)) for d in dirs}                                     
        for coro in asyncio.as_completed(async_jobs):
            size = await coro
            s += size            
        return s 
        
if __name__ == '__main__':
    path = r"C:\windows\system32"
    fiu = FileUtil(path)
    #first time more for cache operations, so do after one time     
    print("sequential")
    r = fiu.getDirSize()    

    print("Now parallel")
    rs = fiu.getDirSizeThreaded()
    
    print("Now parallel")
    rs = fiu.getDirSizeThreaded(8)
    
    print("Now parallel")
    rs = fiu.getDirSizeThreadedSubmit()  

    print("Now parallel")
    rs = fiu.getDirSizeThreadedP()
    
    print("Now parallel with 8")
    rs = fiu.getDirSizeThreadedP(8)
    
    print("Now parallel with submit ")
    rs = fiu.getDirSizeThreadedSubmitP()  
    
    print("Now parallel with Pool ")
    rs = fiu.getDirSizePool()  
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=ws)  as executor:
        r = fiu.getDirSizeThreadedEE(executor) 
        print(r)
        r = asyncio.run(fiu.getDirSizeAsync(executor))
        print(r)
        r = asyncio.run(fiu.getDirSizeAsync_v2(executor))
        print(r)
        import timeit 
        print(timeit.timeit(stmt="asyncio.run(fiu.getDirSizeAsync_v2(executor))", number=10, globals=globals()))



#2nd version with submit, retures Future 

urls = [r"D:\hands", r"D:\hands", r"D:\hands"]
urls = [r"C:\windows\WinSxS", r"C:\windows\Microsoft.NET", r"C:\windows\SysWOW64"]

ex = concurrent.futures.ThreadPoolExecutor(max_workers=4)
#can do nested (CAUTION as might become deadlock )
# this type of dict formation is not possible with ProcessPoolExecutor
fs = { ex.submit(lambda p : FileUtil(p).getDirSizeThreaded(), url): url for url in urls }
fs = { ex.submit(lambda p : FileUtil(p).getDirSize(), url): url for url in urls }

#do ur work 

#below blocks , Might raise exception if load fails
#hence use with try block 
#with Key, fs[res] has to be before res.result()
for res in concurrent.futures.as_completed(fs):
    url = fs[res]
    print(url,res.result())

ex.shutdown()

#could use 
done, not_done = concurrent.futures.wait(fs, timeout=None, return_when=ALL_COMPLETED) #FIRST_COMPLETED,FIRST_EXCEPTION
#done set contains done futures


#Another examples 
import threading , time 
import requests , concurrent.futures


def download(url):
    print("Download ", url, "in ", threading.current_thread().getName())
    con = requests.get(url)
    return [url, len(con.text)]
    
urls = ["http://www.google.co.in" for i in range(5)]
st = time.time()
print("sequential")
r = download(urls[0])
one = time.time()-st
print(r, " took", one)
print("Now parallel")
ex = concurrent.futures.ThreadPoolExecutor(max_workers=5)
st = time.time()
rs = ex.map(download, urls)
print(list(rs), " took ", time.time()-st , "supposed to take ", 5*one , " sequentally")
ex.shutdown()  

#2nd version with submit, retures Future 

result = [ex.submit(load, url) for url in urls ]
#do ur work 

#below blocks , Might raise exception if load fails
#hence use with try block 
output = [res.result() for res in concurrent.futures.as_completed(result)] #with Key, fs[res] has to be before res.result()
len(output)

#could use 
done, not_done = concurrent.futures.wait(result, timeout=None, return_when=ALL_COMPLETED) #FIRST_COMPLETED,FIRST_EXCEPTION
#done set contains done futures


ex.shutdown()


###Tutorials - Type and poetry
https://peps.python.org/pep-0636/
https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html
https://www.pythonsheets.com/notes/python-asyncio.html


#Poetry 
set PATH=C:\Python311;C:\Python311\Scripts;%PATH%
set PATH=%PATH%;C:\Python311\poetry_env\Scripts
poetry new demo
cd demo

poetry config virtualenvs.in-project true 
poetry add requests
poetry add --group dev pytest pytest-cov
poetry install
poetry env info
poetry shell
#Execute
poetry build -v
exit


from .utilities import convert , Unit 

##demo\utilities.py 
"""
#equivalent 
#https://docs.python.org/3/library/enum.html
class Unit(Enum):
    F = 1
    C = 2
    @classmethod
    def other_unit(cls, unit):
        pass 

Unit(1) 
Unit.F 
Unit.F.name 
Unit.F.value 
Unit.F in Unit 
Unit['F']
len(Unit)
for a in Unit:
    print(a)
for a in reversed(Unit):
    print(a)
    
if we do Flag 
from enum import Flag  
class Unit(Flag):
    F = 1
    C = 2
OR 
U = Flag('U', ['F', 'C'])
~Unit.F  == Unit.C 

IntEnum can do +, _ etc 
Flag can do & (AND), | (OR), ^ (XOR), and ~ (INVERT)
"""
#(deg * 9/5) + 32 = f
#(f - 32) * 5/9 = deg

from enum import Enum 

Unit = Enum("Unit", ['F', 'C'])

def convert(value: int|float,/,  unit:Unit) -> float:
    d2f = lambda deg: (deg * 9/5) + 32
    f2d = lambda f : (f - 32) * 5/9 
    conv = { Unit.F : f2d, Unit.C: d2f }
    match unit:
        case Unit():
            return conv[unit](value)
        case _:
            raise Exception("not valid unit")

if __name__ == '__main__':    
    # put types for mypy, else it would be inferred as object 
    values: list[int|float] = [ 0, 32] 
    units  = [Unit.F] * len(values) + [Unit.C] * len(values)
    for v, u in zip([*values, *values], units):
        print(f"{v=}, {u.name=}, {convert(v,u)=}")

            
Then 
poetry shell 
mypy demo\utilities.py 
python demo\utilities.py 
pytest -v 



###Example -py 3.11

mkdir demo 
echo > demo\__init__.py 
echo > demo\utilities.py 

OR 

poetry new demo 
cd  demo 
poetry add --group dev pytest pytest-cov hypothesis mypy

Note 
Dependency groups, other than the implicit main group, must only contain dependencies 
you need in your development process.
Therefore they are not included in distributions


##demo\__init__.py 
from .utilities import convert , Unit 

##demo\utilities.py 
from enum import Enum 
from typing import overload 
from typing import reveal_type, TYPE_CHECKING

Unit = Enum("Unit", ['F', 'C'])
"""
#equivalent 
#https://docs.python.org/3/library/enum.html
class Unit(Enum):
    F = 1
    C = 2
    @classmethod
    def other_unit(cls, unit):
        pass 

Unit(1) 
Unit.F 
Unit.F.name 
Unit.F.value 
Unit.F in Unit 
Unit['F']
len(Unit)
for a in Unit:
    print(a)
for a in reversed(Unit):
    print(a)
    
if we do Flag 
from enum import Flag  
class Unit(Flag):
    F = 1
    C = 2
OR 
U = Flag('U', ['F', 'C'])
~Unit.F  == Unit.C 

IntEnum can do +, _ etc 
Flag can do & (AND), | (OR), ^ (XOR), and ~ (INVERT)
"""
#(deg * 9/5) + 32 = f
#(f - 32) * 5/9 = deg

InType = int|float|list[float]|tuple[float]|list[int]|tuple[int]
OutType = float | list[float] | tuple[float,...]

@overload 
def convert(value:int, / , unit:Unit, *, prec:int=3) -> float: ...
@overload 
def convert(value: float, / , unit:Unit, *, prec:int=3) -> float: ...
@overload 
def convert(value:list[int] , / , unit:Unit, *, prec:int=3) -> list[float]: ...
@overload 
def convert(value:list[float] , / , unit:Unit, *, prec:int=3) -> list[float]: ...
@overload 
def convert(value:tuple[int], / , unit:Unit, *, prec:int=3) -> tuple[float]: ...
@overload 
def convert(value:tuple[float] , / , unit:Unit, *, prec:int=3) -> tuple[float]: ...



def convert(value: InType, /, unit:Unit, *, prec:int=3) -> OutType:
    d2f = lambda deg: (deg * 9/5) + 32
    f2d = lambda f : (f - 32) * 5/9 
    conv = { Unit.F : f2d, Unit.C: d2f }
    match value:
        case [a, ] | (a, ):
            return [convert(a, unit)] if type(value) is list else (convert(a, unit),)
        case [a, *b] | (a, *b):
            return [convert(a, unit), *convert(b, unit)] if type(value) is list else (convert(a, unit), *convert(b, unit))
        case float(a) | int(a):
            return round(conv[unit](a), prec)
        case _ :
            raise NotImplementedError()

if __name__ == '__main__':    
    # put types for mypy, else it would be inferred as object 
    values: list[int|float|list[int|float]] = [ 0, 32, [32],] # (32,), (32,32), [32,32]] #,[[32,32]], [[32],[32]] ]
    if TYPE_CHECKING:  # mypy type printing 
        reveal_type(values)
    units  = [Unit.F] * len(values) + [Unit.C] * len(values)
    for v, u in zip([*values, *values], units):
        print(f"{v=}, {u.name=}, {convert(v,u)=}")
    #Note above line would fail in mypy values is of mixed type 
    #make values as one type like list[list[int]] or list[tuple[int]]
    #then it succeeds 
            
Then 
poetry shell 
mypy demo\utilities.py 
python demo\utilities.py 
pytest -v 
       
            
Change below to handle extened precision and nan ie float('nan'), float('+inf'),float('-inf')

for hypothesis testing 
import math 

def convert(... , prec:int|None=3) -> OutType:
        ...
        case (float(a) | int(a)) if math.isfinite(a):
            return round(conv[unit](a), prec) if prec else conv[unit](a)
        case (float(a) | int(a)) if not math.isfinite(a):
            return a
        ...
        
        
Build 
poetry build 
cd ..

Create virtualenv 
python -m venv .\env 
.\env\Scripts\activate
pip install --force-reinstall --no-dependencies demo/dist/demo-0.1.0-py3-none-any.whl
then test 
python 
>>> from demo import convert, Unit 




##tests/test_utilities.py 
import demo 


def test_all(data):
    values, units, expected  = data 
    actual = []
    for v, u in zip([*values, *values], units):
       actual.append(demo.convert(v,u))
    assert actual == expected 
        
        
#https://hypothesis.readthedocs.io/en/latest/data.html
from hypothesis import given
from hypothesis.strategies import floats, sampled_from
import math

#@given(floats(width=32, allow_nan=False,allow_infinity=False), sampled_from([demo.Unit.F, demo.Unit.C]))
@given(floats(width=32), sampled_from([demo.Unit.F, demo.Unit.C]))
def test_decode_inverts_encode(s, u):
    opp_u = demo.Unit.C if u == demo.Unit.F else demo.Unit.F
    new_s = demo.convert(demo.convert(s,u, prec=None), opp_u, prec=None) 
    assert math.isclose(new_s, s, abs_tol=0.001) if math.isfinite(s) else True 

##conftest.py     outside tests 
import pytest 
import demo 

@pytest.fixture 
def data():
    values = [ 0, 32, [32], (32,), (32,32), [32,32],[[32,32]], [[32],[32]] ]
    units  = [demo.Unit.F] * len(values) + [demo.Unit.C] * len(values)
    expected = [-17.778,0.0,[0.0],(0.0,),(0.0, 0.0),[0.0, 0.0],[[0.0, 0.0]],[[0.0], [0.0]],32.0,89.6,[89.6],(89.6,),(89.6, 89.6),[89.6, 89.6],[[89.6, 89.6]],[[89.6], [89.6]]]
    return values, units , expected
    
    
###Asynchronous programming 
$ python -m asyncio
asyncio REPL ...

import asyncio

await asyncio.sleep(10, result='hello')
'hello'

asyncio.run(coro, *, debug=None, loop_factory=None)
    Execute the coroutine coro and return the result.
class asyncio.Runner(*, debug=None, loop_factory=None)
    A context manager 
    Sometimes several top-level async functions should be called in the same event loop
    and contextvars.Context.
    run(coro, *, context=None)
    close()
    get_loop()
    
    
#Example 
Coroutines declared with the async/await syntax is the preferred way of writing asyncio applications
Note that simply calling a coroutine will not schedule it to be executed:
>>> main()
<coroutine object main at 0x1053bb7c8>


async def main():
    await asyncio.sleep(1)
    print('hello')

asyncio.run(main())


async def main():
    await asyncio.sleep(1)
    print('hello')

with asyncio.Runner() as runner:
    runner.run(main())
    
##Example 

    
awaitable asyncio.gather(*aws, return_exceptions=False)
    If return_exceptions is True, exceptions are treated the same 
    as successful results, and aggregated in the result list.
    If any awaitable in aws is a coroutine, it is automatically scheduled as a Task
    
import asyncio 
import time  #time.sleep is called non asynio aware code. Never call in asyncio code
import logging 
logging.basicConfig(level=logging.DEBUG)

def normal_method(delay):
    time.sleep(delay)
    return "slept happily"


async def worker(delay, what):
    await asyncio.sleep(delay)  # ayncio aware sleep #doing IO here 
    #print(what)
    return what 

async def mainS():
    res1 = await worker(5,"Hello")
    res2 = await worker(5,"World")
    return res1+res2
    
#mainP or mainP1 or mainP2 
async def mainP():
    res = await asyncio.gather(
            worker(5,"Hello"),
            worker(5,"World"))
    return res
    
   
async def mainP1():
    task1 = asyncio.create_task(worker(5,"Hello"))
    task2 = asyncio.create_task(worker(5,"Hello"))
    #do other activities 
    res1 = await task1
    res2 = await task2
    return res1+res2
    
    
async def mainP2():
    import random
    o = [random.randint(1,5) for _ in range(10)]
    tasks = [ asyncio.create_task(worker(i, f"Hello-{i}")) for i in o]
    out = []
    for e in asyncio.as_completed(tasks): # Py3.13 - async for 
        res = await e
        out.append( res)
    return out 
    
async def call_normal(delay):
    res =  await asyncio.to_thread(normal_method, delay)
    return res 

#__name__ is variable, python creates internally 
#in module __name__  = module name 
#in script , __name__ becomes __main__ 
if __name__ == '__main__':
    #OPT-1
    res = asyncio.run(worker(5,"Hello"), debug=True) #starts Eventloop 
    print(res)
    
    #OPT-2 - running many top level coro
    with asyncio.Runner() as r:
        st = time.time()
        res = r.run(mainS())
        print(res)
        print("Time taken", time.time() - st, "secs")  #10 secs 
        st = time.time()
        res = r.run(mainP())
        print(res)        
        print("Time taken", time.time() - st, "secs")  #5 secs 
        
        st = time.time()
        res = r.run(mainP1())
        print(res)
        print("Time taken", time.time() - st, "secs")  #5 secs   
        st = time.time()
        res = r.run(mainP2())
        print(res)
        print("Time taken", time.time() - st, "secs")  #5 secs 
        
        st = time.time()
        res = r.run(call_normal(5))
        print(res)
        print("Time taken", time.time() - st, "secs")  #5 secs 
    
#Many functions to run in same context 
async def main():
    await asyncio.sleep(1)
    print('hello')

with asyncio.Runner() as runner:
    runner.run(main())
    
#run two hello coroutines concurrently, storing in variable is must
task1 = asyncio.create_task(
        worker(5, "Hello"))

task2 = asyncio.create_task(
    worker(5, "Hello"))

# Wait until both tasks are completed (should take
# around 5 seconds.)
await task1
await task2


#With timeout 
delay can either be None, or a float/int number of seconds to wait

async def main():
    try:
        async with asyncio.timeout(10):
            await long_running_task()
    except TimeoutError:
        print("The long operation timed out, but we've handled it.")

    print("This statement will run regardless.")
    
async def main():
    # Wait for at most 1 second
    try:
        await asyncio.wait_for(worker(5, "Hello"), timeout=1.0)
    except TimeoutError:
        print('timeout!')
        
        

#to_thread , as_completed, wait_for
task1 = asyncio.create_task(
        worker(5, "Hello"))

task2 = asyncio.create_task(
    worker(5, "Hello"))
    
async asyncio.wait(aws, *, timeout=None, return_when=ALL_COMPLETED)
    timeout (a float or int), if specified, can be used to control the maximum number 
    of seconds to wait before returning.
    Note that this function does not raise TimeoutError. 
    Futures or Tasks that aren’t done when the timeout occurs are simply returned in the second set.

done, pending = await asyncio.wait([task1, task2]) #create task out of coroutine 

asyncio.as_completed(aws, *, timeout=None)
    A TimeoutError is raised if the timeout occurs before all awaitables are done
    
async for aws in as_completed([task1, task2]):
    res = await aws
    if aws is task1:
        print("task1")
    else:
        print("task2")
        
async asyncio.to_thread(func, /, *args, **kwargs)
    for executing IO-bound functions/methods that would otherwise block the event loop 
    
def blocking_io(loop):
    time.sleep(1)
    #concurrent.futures.Future
    coro = asyncio.sleep(1, result=3)
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result(timeout) 

inside async def 
loop = asyncio.get_running_loop() or asyncio.get_event_loop()
list_of_result = await asyncio.gather(
        asyncio.to_thread(lambda loop=loop: blocking_io(loop)),
        asyncio.sleep(1))
        
        

Tasks can easily and safely be cancelled. 
When a task is cancelled, asyncio.CancelledError will be raised in the task at the next opportunity.
It is recommended that coroutines use try/finally blocks to robustly perform clean-up logic. 
In case asyncio.CancelledError is explicitly caught, 
it should generally be propagated when clean-up is complete. 
asyncio.CancelledError directly subclasses BaseException so most code will not need to be aware of it.

For TaskGroup 
While terminating a task group is not natively supported by the standard library, 
termination can be achieved by adding an exception-raising task to the task group
and ignoring the raised exception:

import asyncio
from asyncio import TaskGroup

class TerminateTaskGroup(Exception):
    """Exception raised to terminate a task group."""

async def force_terminate_task_group():
    """Used to force termination of a task group."""
    raise TerminateTaskGroup()
    
async def main():
    try:
        async with TaskGroup() as group:
            # spawn some tasks
            group.create_task(worker(5, "Hello"))
            group.create_task(worker(5, "Hello"))
            # sleep for 1 second
            await asyncio.sleep(1)
            # add an exception-raising task to force the group to terminate
            group.create_task(force_terminate_task_group())
    except* TerminateTaskGroup:
        pass
        
        
#run_inExecutor 
import asyncio
import concurrent.futures

def blocking_io():
    with open('x.txt', 'wt') as f:
        f.write("A"*100)
    with open('x.txt', 'rt') as f:
        return f.read()
        

def cpu_bound():
    return sum(i * i for i in range(10 ** 7))

async def main():
    loop = asyncio.get_running_loop()
    # 1. 
    result = await loop.run_in_executor(
        None, blocking_io)
    print('default thread pool', result)

    # 2.
    with concurrent.futures.ThreadPoolExecutor() as pool:
        result = await loop.run_in_executor(
            pool, blocking_io)
        print('custom thread pool', result)

    # 3. Run in a custom process pool:
    with concurrent.futures.ProcessPoolExecutor() as pool:
        result = await loop.run_in_executor(
            pool, cpu_bound)
        print('custom process pool', result)

if __name__ == '__main__':
    asyncio.run(main())
    

##Example 
import asyncio 
import time, sys
import aiohttp
#setup
if sys.platform == 'win32':
	asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
#setip end 
    
    
async def download(url):
    async with aiohttp.ClientSession() as sess:
        async with sess.get(url) as resp:
            return await resp.text()
    
async def download_10_p(urls):
    tasks = [ download(i)  for i in urls ]
    return await asyncio.gather(*tasks)
    
async def download_10_f(urls):    
    tasks = []
    for i in urls :
        task = asyncio.create_task(download(i))
        tasks.append(task)
    #other work 
    res = []
    for t in tasks:
        res.append( await t)
    return res 
    
async def download_10_y(urls):  
    res = []
    async with aiohttp.ClientSession() as sess:
        for url in urls:
            async with sess.get(url) as resp:
                res.append( await resp.text())
    return res 
    
async def download_10_b(urls):
    tasks = [ asyncio.create_task(download(url)) for url in urls]
    out = []
    for e in asyncio.as_completed(tasks): 
        res = await e
        out.append( res)
    return out 
    
    

if __name__ == '__main__':
    url = "http://httpbin.org/get"
    urls = [url] * 10
    print("One download")
    st = time.time()
    res = asyncio.run(download(url))
    print(len(res))
    print("Time taken", time.time() - st, "secs")
    #handson 
    print("10 download")
    codes = [download_10_p, download_10_f, download_10_y, download_10_b]
    for code in codes :
        st = time.time()
        res = asyncio.run(code(urls))
        print(sum([len(r) for r in res ]))
        print("Time taken", time.time() - st, "secs")
    
##Example 
# can not use glob/os.path/open - Anyio 
#     https://anyio.readthedocs.io/en/stable/fileio.html
#    anyio Path follows python pathlib API 
#    https://docs.python.org/3/library/pathlib.html
#    check github for any reference doc 
#    https://github.com/agronholm/anyio/blob/master/src/anyio/_core/_fileio.py

#Given directory find total size , include all the directories and subdirectories

#or directory - asyncdef fn1 
#anyio.Glob 
#USe glob to get all files and directory 
#if file 
#    get size 
#if directory 
#    recursive 
#    
#Get root label Path.walk 
#get size of all root labels files 
#for each directory 
#    call asyncdef1 <- mainP or mainP2 
#    
import asyncio 
from anyio import Path 
import sys 

DEBUG = bool(sys.argv[1]) if len(sys.argv) > 1 else False 
def print_d(*a,**b):
    if DEBUG:
        print(*a, **b)

#TODO - Handle exception
async def get_size(root,fs):
    res = sum([ (await Path(root, f).stat()).st_size for f in fs])
    return res 

async def get_size_one_dir(root, dir):
    s = 0
    async for rp, sds, fs in Path(root,dir).walk():
        print_d(f"{rp=},{sds=},{fs=}")
        s += await get_size(rp,fs)
        for sd in sds:
            s += await get_size_one_dir(rp,sd)
    return s 
    
async def dir_size(path):
    s = 0
    #Take root levels files and dirs 
    #async for rp, sds, fs in Path(path).walk(): 
    #    break    
    rp, sds, fs = await Path(path).walk().__anext__()
    print_d(f"{rp=},{sds=},{fs=}")
    s += await get_size(rp,fs)
    #for each subdir, now spawn one coroutine 
    res = await asyncio.gather(*[
            get_size_one_dir(rp,sd) for sd in sds
            ])
    s += sum(res)
    return s 
    
if __name__ == '__main__':
    path="."
    res = asyncio.run(dir_size(path)) 
    print(res)
            
        
    
    
##Awesome asyncio 
https://github.com/timofurrer/awesome-asyncio

##More example 
There are three main types of awaitable objects: coroutines, Tasks, and Futures.


Many coroutines  

    import asyncio
    import time

    async def say_after(delay, what):
        await asyncio.sleep(delay)
        print(what)

    async def main():
        print(f"started at {time.strftime('%X')}")
        await say_after(1, 'hello')
        await say_after(2, 'world')
        print(f"finished at {time.strftime('%X')}")

    asyncio.run(main())

    Expected output:
    started at 17:13:52
    hello
    world
    finished at 17:13:55
    
    #Running coroutines concurrently:
    When a coroutine is wrapped into a Task with functions like asyncio.create_task() 
    the coroutine is automatically scheduled to run soon:
    asyncio.create_task(coro, *, name=None, context=None)
        An optional keyword-only context argument allows specifying a custom contextvars.Context 
        for the coro to run in. The current context copy is created when no context is provided.
        
        Save a reference to the result of this function, to avoid a task disappearing mid-execution. 
        The event loop only keeps weak references to tasks.
    
    async def main():
        task1 = asyncio.create_task(
            say_after(1, 'hello'))

        task2 = asyncio.create_task(
            say_after(2, 'world'))

        print(f"started at {time.strftime('%X')}")

        # Wait until both tasks are completed (should take
        # around 2 seconds.)
        await task1
        await task2

        print(f"finished at {time.strftime('%X')}")

    Note that expected output now shows that the snippet runs 1 second faster than before:

    started at 17:14:32
    hello
    world
    finished at 17:14:34

    The asyncio.TaskGroup class provides a more modern alternative to create_task(). 

    async def main():
        async with asyncio.TaskGroup() as tg:
            task1 = tg.create_task(
                say_after(1, 'hello'))

            task2 = tg.create_task(
                say_after(2, 'world'))

            print(f"started at {time.strftime('%X')}")

        # The await is implicit when the context manager exits.

        print(f"finished at {time.strftime('%X')}")

    The timing and output should be the same as for the previous version.
        
    Tasks can easily and safely be cancelled. 
    When a task is cancelled, asyncio.CancelledError will be raised in the task at the next opportunity.

    It is recommended that coroutines use try/finally blocks to robustly perform clean-up logic. 
    
    The first time any of the tasks belonging to the group fails 
    with an exception other than asyncio.CancelledError, the remaining tasks in the group are cancelled
        
##Task Methods 
   done()
        Return True if the Task is done.
        A Task is done when the wrapped coroutine either returned a value, raised an exception, 
        or the Task was cancelled.

    result()
        Return the result of the Task.       

    exception()
        Return the exception of the Task.

        If the wrapped coroutine raised an exception that exception is returned. 
        If the wrapped coroutine returned normally this method returns None.


    add_done_callback(callback, *, context=None)
        Add a callback to be run when the Task is done.
        This method should only be used in low-level callback-based code.

    remove_done_callback(callback)
        Remove callback from the callbacks list.

    get_stack(*, limit=None)
    print_stack(*, limit=None, file=None)
    get_coro()
    get_context()
    get_name()
    set_name(value)
    cancel(msg=None)
        Request the Task to be cancelled.

        The following example illustrates how coroutines can intercept the cancellation request:

        async def cancel_me():
            print('cancel_me(): before sleep')

            try:
                # Wait for 1 hour
                await asyncio.sleep(3600)
            except asyncio.CancelledError:
                print('cancel_me(): cancel sleep')
                raise
            finally:
                print('cancel_me(): after sleep')

        async def main():
            # Create a "cancel_me" Task
            task = asyncio.create_task(cancel_me())

            # Wait for 1 second
            await asyncio.sleep(1)

            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                print("main(): cancel_me is cancelled now")

        asyncio.run(main())

        # Expected output:
        #
        #     cancel_me(): before sleep
        #     cancel_me(): cancel sleep
        #     cancel_me(): after sleep
        #     main(): cancel_me is cancelled now

    cancelled()
        Return True if the Task is cancelled.
        
##Terminating a Task Group
While terminating a task group is not natively supported by the standard library, 
termination can be achieved by adding an exception-raising task to the task group 
and ignoring the raised exception:

import asyncio
from asyncio import TaskGroup

class TerminateTaskGroup(Exception):
    """Exception raised to terminate a task group."""

async def force_terminate_task_group():
    """Used to force termination of a task group."""
    raise TerminateTaskGroup()

async def job(task_id, sleep_time):
    print(f'Task {task_id}: start')
    await asyncio.sleep(sleep_time)
    print(f'Task {task_id}: done')

async def main():
    try:
        async with TaskGroup() as group:
            # spawn some tasks
            group.create_task(job(1, 0.5))
            group.create_task(job(2, 1.5))
            # sleep for 1 second
            await asyncio.sleep(1)
            # add an exception-raising task to force the group to terminate
            group.create_task(force_terminate_task_group())
    except* TerminateTaskGroup:
        pass

asyncio.run(main())

Expected output:

Task 1: start
Task 2: start
Task 1: done


coroutine asyncio.sleep(delay, result=None)
    Block for delay seconds.

    Example of coroutine displaying the current date every second for 5 seconds:

    import asyncio
    import datetime

    async def display_date():
        loop = asyncio.get_running_loop()
        end_time = loop.time() + 5.0
        while True:
            print(datetime.datetime.now())
            if (loop.time() + 1.0) >= end_time:
                break
            await asyncio.sleep(1)

    asyncio.run(display_date())

    
awaitable asyncio.gather(*aws, return_exceptions=False)

    Run awaitable objects in the aws sequence concurrently.

    If return_exceptions is False (default), the first raised exception is immediately propagated 
    to the task that awaits on gather(). 
    Other awaitables in the aws sequence won’t be cancelled and will continue to run.

    If return_exceptions is True, exceptions are treated the same as successful results, 
    and aggregated in the result list.

    If gather() is cancelled, all submitted awaitables (that have not completed yet) are also cancelled.

    import asyncio

    async def factorial(name, number):
        f = 1
        for i in range(2, number + 1):
            print(f"Task {name}: Compute factorial({number}), currently i={i}...")
            await asyncio.sleep(1)
            f *= i
        print(f"Task {name}: factorial({number}) = {f}")
        return f

    async def main():
        # Schedule three calls *concurrently*:
        L = await asyncio.gather(
            factorial("A", 2),
            factorial("B", 3),
            factorial("C", 4),
        )
        print(L)

    asyncio.run(main())

    # Expected output:
    #
    #     Task A: Compute factorial(2), currently i=2...
    #     Task B: Compute factorial(3), currently i=2...
    #     Task C: Compute factorial(4), currently i=2...
    #     Task A: factorial(2) = 2
    #     Task B: Compute factorial(3), currently i=3...
    #     Task C: Compute factorial(4), currently i=3...
    #     Task B: factorial(3) = 6
    #     Task C: Compute factorial(4), currently i=4...
    #     Task C: factorial(4) = 24
    #     [2, 6, 24]


asyncio.timeout(delay)
    Return an asynchronous context manager that can be used to limit the amount of time 
    spent waiting on something.

    delay can either be None, or a float/int number of seconds to wait. If delay is None, 
    no time limit will be applied; this can be useful if the delay is unknown when the context manager 
    is created.

    In either case, the context manager can be rescheduled after creation using Timeout.reschedule().

    Example:

    async def main():
        async with asyncio.timeout(10):
            await long_running_task()

    If long_running_task takes more than 10 seconds to complete, the context manager will cancel 
    the current task and handle the resulting asyncio.CancelledError internally, 
    transforming it into a TimeoutError which can be caught and handled.

    The asyncio.timeout() context manager is what transforms the asyncio.CancelledError 
    into a TimeoutError, which means the TimeoutError can only be caught outside of the context manager.

    Example of catching TimeoutError:

    async def main():
        try:
            async with asyncio.timeout(10):
                await long_running_task()
        except TimeoutError:
            print("The long operation timed out, but we've handled it.")

        print("This statement will run regardless.")
        
    #rescheduling 
    async def main():
        try:
            # We do not know the timeout when starting, so we pass ``None``.
            async with asyncio.timeout(None) as cm:
                # We know the timeout now, so we reschedule it.
                new_deadline = get_running_loop().time() + 10
                cm.reschedule(new_deadline)

                await long_running_task()
        except TimeoutError:
            pass    
            
asyncio.timeout_at(when)
    Similar to asyncio.timeout(), except when is the absolute time to stop waiting, or None.

    Example:

    async def main():
        loop = get_running_loop()
        deadline = loop.time() + 20
        try:
            async with asyncio.timeout_at(deadline):
                await long_running_task()
        except TimeoutError:
            print("The long operation timed out, but we've handled it.")

        print("This statement will run regardless.")

    Added in version 3.11.

coroutine asyncio.wait_for(aw, timeout)
    Wait for the aw awaitable to complete with a timeout.

    timeout can either be None or a float or int number of seconds to wait for. 
    If timeout is None, block until the future completes.

    If a timeout occurs, it cancels the task and raises TimeoutError.

    If the wait is cancelled, the future aw is also cancelled.

    Example:

    async def eternity():
        # Sleep for one hour
        await asyncio.sleep(3600)
        print('yay!')

    async def main():
        # Wait for at most 1 second
        try:
            await asyncio.wait_for(eternity(), timeout=1.0)
        except TimeoutError:
            print('timeout!')

    asyncio.run(main())

    # Expected output:
    #
    #     timeout!



coroutine asyncio.wait(aws, *, timeout=None, return_when=ALL_COMPLETED)
    Run Future and Task instances in the aws iterable concurrently 
    and block until the condition specified by return_when.

    The aws iterable must not be empty.

    Returns two sets of Tasks/Futures: (done, pending).

    Usage:

    done, pending = await asyncio.wait(aws)

    timeout (a float or int), if specified, can be used to control the maximum number of seconds to wait before returning.

    Note that this function does not raise TimeoutError. 
    Futures or Tasks that aren’t done when the timeout occurs are simply returned in the second set.

    asyncio.FIRST_COMPLETED
   	    The function will return when any future finishes or is cancelled.

    asyncio.FIRST_EXCEPTION
        The function will return when any future finishes by raising an exception. 
        If no future raises an exception then it is equivalent to ALL_COMPLETED.

    asyncio.ALL_COMPLETED    	
        The function will return when all futures finish or are cancelled.

    Unlike wait_for(), wait() does not cancel the futures when a timeout occurs.

  
asyncio.as_completed(aws, *, timeout=None)
    Run awaitable objects in the aws iterable concurrently. 
    The returned object can be iterated to obtain the results of the awaitables as they finish.

    The object returned by as_completed() can be iterated as an asynchronous iterator or a plain iterator. When asynchronous iteration is used, the originally-supplied awaitables are yielded 
    if they are tasks or futures. 
    This makes it easy to correlate previously-scheduled tasks with their results. Example:

    ipv4_connect = create_task(open_connection("127.0.0.1", 80))
    ipv6_connect = create_task(open_connection("::1", 80))
    tasks = [ipv4_connect, ipv6_connect]

    async for earliest_connect in as_completed(tasks):
        # earliest_connect is done. The result can be obtained by
        # awaiting it or calling earliest_connect.result()
        reader, writer = await earliest_connect

        if earliest_connect is ipv6_connect:
            print("IPv6 connection established.")
        else:
            print("IPv4 connection established.")


    When used as a plain iterator, each iteration yields a new coroutine that returns the result 
    or raises the exception of the next completed awaitable.
    This pattern is compatible with Python versions older than 3.13:

    ipv4_connect = create_task(open_connection("127.0.0.1", 80))
    ipv6_connect = create_task(open_connection("::1", 80))
    tasks = [ipv4_connect, ipv6_connect]

    for next_connect in as_completed(tasks):
        # next_connect is not one of the original task objects. It must be
        # awaited to obtain the result value or raise the exception of the
        # awaitable that finishes next.
        reader, writer = await next_connect

    A TimeoutError is raised if the timeout occurs before all awaitables are done. 
    This is raised by the async for loop during asynchronous iteration or by the coroutines 
    yielded during plain iteration.




coroutine asyncio.to_thread(func, /, *args, **kwargs)
    Asynchronously run function func in a separate thread.

    Any *args and **kwargs supplied for this function are directly passed to func. 
    Also, the current contextvars.Context is propagated, allowing context variables 
    from the event loop thread to be accessed in the separate thread.

    Return a coroutine that can be awaited to get the eventual result of func.

    This coroutine function is primarily intended to be used for executing IO-bound functions/methods 
    that would otherwise block the event loop if they were run in the main thread. For example:

    def blocking_io():
        print(f"start blocking_io at {time.strftime('%X')}")
        # Note that time.sleep() can be replaced with any blocking
        # IO-bound operation, such as file operations.
        time.sleep(1)
        print(f"blocking_io complete at {time.strftime('%X')}")

    async def main():
        print(f"started main at {time.strftime('%X')}")

        await asyncio.gather(
            asyncio.to_thread(blocking_io),
            asyncio.sleep(1))

        print(f"finished main at {time.strftime('%X')}")


    asyncio.run(main())

    # Expected output:
    #
    # started main at 19:50:53
    # start blocking_io at 19:50:53
    # blocking_io complete at 19:50:54
    # finished main at 19:50:54

    Directly calling blocking_io() in any coroutine would block the event loop for its duration, 
    resulting in an additional 1 second of run time. Instead, by using asyncio.to_thread(), 
    we can run it in a separate thread without blocking the event loop.


asyncio.run_coroutine_threadsafe(coro, loop)
    Scheduling From Other Threads

    Submit a coroutine to the given event loop. Thread-safe.

    Return a concurrent.futures.Future to wait for the result from another OS thread.

    This function is meant to be called from a different OS thread 
    than the one where the event loop is running. Example:

    # Create a coroutine
    coro = asyncio.sleep(1, result=3)

    # Submit the coroutine to a given loop
    future = asyncio.run_coroutine_threadsafe(coro, loop)

    # Wait for the result with an optional timeout argument
    assert future.result(timeout) == 3

    If an exception is raised in the coroutine, the returned Future will be notified. 
    It can also be used to cancel the task in the event loop:

    try:
        result = future.result(timeout)
    except TimeoutError:
        print('The coroutine took too long, cancelling the task...')
        future.cancel()
    except Exception as exc:
        print(f'The coroutine raised an exception: {exc!r}')
    else:
        print(f'The coroutine returned: {result!r}')


asyncio.current_task(loop=None)
    Return the currently running Task instance, or None if no task is running.
  
asyncio.all_tasks(loop=None)
    Return a set of not yet finished Task objects run by the loop.

asyncio.iscoroutine(obj)
    Return True if obj is a coroutine object.
    

##Synchronization Primitives
    Lock
    Event
    Condition
    Semaphore
    BoundedSemaphore
    Barrier


class asyncio.Lock
    Implements a mutex lock for asyncio tasks. Not thread-safe.

 
    lock = asyncio.Lock()

    # ... later
    async with lock:
        # access shared state

    which is equivalent to:

    lock = asyncio.Lock()

    # ... later
    await lock.acquire()
    try:
        # access shared state
    finally:
        lock.release()


class asyncio.Event
    An event object. Not thread-safe.

    An asyncio event can be used to notify multiple asyncio tasks that some event has happened.

    Example:

    async def waiter(event):
        print('waiting for it ...')
        await event.wait()
        print('... got it!')

    async def main():
        # Create an Event object.
        event = asyncio.Event()

        # Spawn a Task to wait until 'event' is set.
        waiter_task = asyncio.create_task(waiter(event))

        # Sleep for 1 second and set the event.
        await asyncio.sleep(1)
        event.set()

        # Wait until the waiter task is finished.
        await waiter_task

    asyncio.run(main())

 
class asyncio.Condition(lock=None)
    A Condition object. Not thread-safe.

    An asyncio condition primitive can be used by a task to wait for some event to happen 
    and then get exclusive access to a shared resource.

    In essence, a Condition object combines the functionality of an Event and a Lock. 

    The preferred way to use a Condition is an async with statement:

    cond = asyncio.Condition()

    # ... later
    async with cond:
        await cond.wait()

    
    notify(n=1)
        Wake up n tasks (1 by default) waiting on this condition. 

    locked()
        Return True if the underlying lock is acquired.

    notify_all()
        Wake up all tasks waiting on this condition.

 
    coroutine wait()
        Wait until notified.

        If the calling task has not acquired the lock when this method is called, a RuntimeError is raised.

        This method releases the underlying lock, and then blocks until it is awakened 
        by a notify() or notify_all() call. 
        Once awakened, the Condition re-acquires its lock and this method returns True.

    coroutine wait_for(predicate)
        Wait until a predicate becomes true.

        The predicate must be a callable which result will be interpreted as a boolean value. 
        The method will repeatedly wait() until the predicate evaluates to true. 
        The final value is the return value.



class asyncio.Semaphore(value=1)
    A Semaphore object. Not thread-safe.

    A semaphore manages an internal counter which is decremented by each acquire() call 
    and incremented by each release() call. 
    The counter can never go below zero; when acquire() finds that it is zero, 
    it blocks, waiting until some task calls release().

    sem = asyncio.Semaphore(10)

    # ... later
    async with sem:
        # work with shared resource

 
class asyncio.BoundedSemaphore(value=1)
    A bounded semaphore object. Not thread-safe.

    Bounded Semaphore is a version of Semaphore that raises a ValueError in release() 
    if it increases the internal counter above the initial value.


class asyncio.Barrier(parties)
    A barrier object. Not thread-safe.

    A barrier is a simple synchronization primitive that allows to block until parties 
    number of tasks are waiting on it. Tasks can wait on the wait() method 
    and would be blocked until the specified number of tasks end up waiting on wait(). 
    At that point all of the waiting tasks would unblock simultaneously.

    async with can be used as an alternative to awaiting on wait().

    The barrier can be reused any number of times.

    Example:

    async def example_barrier():
       # barrier with 3 parties
       b = asyncio.Barrier(3)

       # create 2 new waiting tasks
       asyncio.create_task(b.wait())
       asyncio.create_task(b.wait())

       await asyncio.sleep(0)
       print(b)

       # The third .wait() call passes the barrier
       await b.wait()
       print(b)
       print("barrier passed")

       await asyncio.sleep(0)
       print(b)

    asyncio.run(example_barrier())

    Result of this example is:

    <asyncio.locks.Barrier object at 0x... [filling, waiters:2/3]>
    <asyncio.locks.Barrier object at 0x... [draining, waiters:0/3]>
    barrier passed
    <asyncio.locks.Barrier object at 0x... [filling, waiters:0/3]>

##Subprocesses

import asyncio

async def run(cmd):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE)

    stdout, stderr = await proc.communicate()

    print(f'[{cmd!r} exited with {proc.returncode}]')
    if stdout:
        print(f'[stdout]\n{stdout.decode()}')
    if stderr:
        print(f'[stderr]\n{stderr.decode()}')

asyncio.run(run('ls /zzz'))

will print:

['ls /zzz' exited with 1]
[stderr]
ls: /zzz: No such file or directory

#to run several commands simultaneously:

async def main():
    await asyncio.gather(
        run('ls /zzz'),
        run('sleep 1; echo "hello"'))


coroutine asyncio.create_subprocess_exec(program, *args, stdin=None, stdout=None, stderr=None, limit=None, **kwds)

coroutine asyncio.create_subprocess_shell(cmd, stdin=None, stdout=None, stderr=None, limit=None, **kwds)    
    Return a Process instance.

asyncio.subprocess.PIPE
    Can be passed to the stdin, stdout or stderr parameters.
asyncio.subprocess.STDOUT
asyncio.subprocess.DEVNULL

class asyncio.subprocess.Process
    This class is not thread safe.

    coroutine wait()
        Wait for the child process to terminate.
        Set and return the returncode attribute.
       
        This method can deadlock when using stdout=PIPE or stderr=PIPE and the child process generates 
        so much output that it blocks waiting for the OS pipe buffer to accept more data. 
        Use the communicate() method when using pipes to avoid this condition.

    coroutine communicate(input=None)
        Interact with process:
            send data to stdin (if input is not None);
            closes stdin;
            read data from stdout and stderr, until EOF is reached;
            wait for process to terminate.
        The optional input argument is the data (bytes object) that will be sent to the child process.

        Return a tuple (stdout_data, stderr_data).

    terminate()
        Stop the child process.
    kill()
        Kill the child process.

    stdin
    stdout
    stderr
    pid
    returncode


##Subprocess and Threads
Standard asyncio event loop supports running subprocesses from different threads by default.

On Windows subprocesses are provided by ProactorEventLoop only (default), 
SelectorEventLoop has no subprocess support.

import asyncio
import sys

async def get_date():
    code = 'import datetime; print(datetime.datetime.now())'

    # Create the subprocess; redirect the standard output
    # into a pipe.
    proc = await asyncio.create_subprocess_exec(
        sys.executable, '-c', code,
        stdout=asyncio.subprocess.PIPE)

    # Read one line of output.
    data = await proc.stdout.readline()
    line = data.decode('ascii').rstrip()

    # Wait for the subprocess exit.
    await proc.wait()
    return line

date = asyncio.run(get_date())
print(f"Current date: {date}")


##Queues can be used to distribute workload between several concurrent tasks:

import asyncio
import random
import time


async def worker(name, queue):
    while True:
        # Get a "work item" out of the queue.
        sleep_for = await queue.get()

        # Sleep for the "sleep_for" seconds.
        await asyncio.sleep(sleep_for)

        # Notify the queue that the "work item" has been processed.
        queue.task_done()

        print(f'{name} has slept for {sleep_for:.2f} seconds')


async def main():
    # Create a queue that we will use to store our "workload".
    queue = asyncio.Queue()

    # Generate random timings and put them into the queue.
    total_sleep_time = 0
    for _ in range(20):
        sleep_for = random.uniform(0.05, 1.0)
        total_sleep_time += sleep_for
        queue.put_nowait(sleep_for)

    # Create three worker tasks to process the queue concurrently.
    tasks = []
    for i in range(3):
        task = asyncio.create_task(worker(f'worker-{i}', queue))
        tasks.append(task)

    # Wait until the queue is fully processed.
    started_at = time.monotonic()
    await queue.join()
    total_slept_for = time.monotonic() - started_at

    # Cancel our worker tasks.
    for task in tasks:
        task.cancel()
    # Wait until all worker tasks are cancelled.
    await asyncio.gather(*tasks, return_exceptions=True)

    print('====')
    print(f'3 workers slept in parallel for {total_slept_for:.2f} seconds')
    print(f'total expected sleep time: {total_sleep_time:.2f} seconds')


asyncio.run(main())

##Debug Mode
By default asyncio runs in production mode. In order to ease the development asyncio has a debug mode.

There are several ways to enable asyncio debug mode:
    Setting the PYTHONASYNCIODEBUG environment variable to 1.

    Using the Python Development Mode.

    Passing debug=True to asyncio.run().

    Calling loop.set_debug().

In addition to enabling the debug mode, consider also:
    setting the log level of the asyncio logger to logging.DEBUG, for example the following snippet 
    of code can be run at startup of the application:

    logging.basicConfig(level=logging.DEBUG)


##Concurrency and Multithreading
An event loop runs in a thread (typically the main thread) 
and executes all callbacks and Tasks in its thread. 
While a Task is running in the event loop, no other Tasks can run in the same thread.
When a Task executes an await expression, the running Task gets suspended, 
and the event loop executes the next Task.

To schedule a callback from another OS thread, the loop.call_soon_threadsafe() method should be used. 

loop.call_soon_threadsafe(callback, *args)

Almost all asyncio objects are not thread safe, which is typically not a problem 
If there’s a need for such code to call a low-level asyncio API, the loop.call_soon_threadsafe() 
method should be used, e.g.:

loop.call_soon_threadsafe(fut.cancel)

To schedule a coroutine object from a different OS thread, the run_coroutine_threadsafe() function s
hould be used. It returns a concurrent.futures.Future to access the result:

async def coro_func():
     return await asyncio.sleep(1, 42)

# Later in another OS thread:

future = asyncio.run_coroutine_threadsafe(coro_func(), loop)
# Wait for the result:
result = future.result()

To handle signals the event loop must be run in the main thread.

The loop.run_in_executor() method can be used with a concurrent.futures.ThreadPoolExecutor 
to execute blocking code in a different OS thread without blocking the OS thread 
that the event loop runs in.

There is currently no way to schedule coroutines or callbacks directly from a different process 
(such as one started with multiprocessing). 


##Running Blocking Code
Blocking (CPU-bound) code should not be called directly. For example, if a function performs 
a CPU-intensive calculation for 1 second, all concurrent asyncio Tasks and IO operations 
would be delayed by 1 second.

An executor can be used to run a task in a different thread or even in a different process 
to avoid blocking the OS thread with the event loop. See the loop.run_in_executor() method for more details.

asyncio.get_running_loop()
    Return the running event loop in the current OS thread.
    
asyncio.get_event_loop()
    Get the current event loop.

    When called from a coroutine or a callback (e.g. scheduled with call_soon or similar API), 
    this function will always return the running event loop.
    
awaitable loop.run_in_executor(executor, func, *args)
    Arrange for func to be called in the specified executor.

    The executor argument should be an concurrent.futures.Executor instance. 
    The default executor is used if executor is None. 
    The default executor can be set by loop.set_default_executor(),
    otherwise, a concurrent.futures.ThreadPoolExecutor will be lazy-initialized 
    and used by run_in_executor() if needed.

    Example:

    import asyncio
    import concurrent.futures

    def blocking_io():
        # File operations (such as logging) can block the
        # event loop: run them in a thread pool.
        with open('/dev/urandom', 'rb') as f:
            return f.read(100)

    def cpu_bound():
        # CPU-bound operations will block the event loop:
        # in general it is preferable to run them in a
        # process pool.
        return sum(i * i for i in range(10 ** 7))

    async def main():
        loop = asyncio.get_running_loop()

        # Options:

        # 1. Run in the default loop's executor:
        result = await loop.run_in_executor(
            None, blocking_io)
        print('default thread pool', result)

        # 2. Run in a custom thread pool:
        with concurrent.futures.ThreadPoolExecutor() as pool:
            result = await loop.run_in_executor(
                pool, blocking_io)
            print('custom thread pool', result)

        # 3. Run in a custom process pool:
        with concurrent.futures.ProcessPoolExecutor() as pool:
            result = await loop.run_in_executor(
                pool, cpu_bound)
            print('custom process pool', result)

    if __name__ == '__main__':
        asyncio.run(main())

    Note that the entry point guard (if __name__ == '__main__') is required for option 3 due to the peculiarities of multiprocessing, which is used by ProcessPoolExecutor. See Safe importing of main module.

  
##Logging
asyncio uses the logging module and all logging is performed via the 'asyncio' logger.

The default log level is logging.INFO, which can be easily adjusted:

logging.getLogger("asyncio").setLevel(logging.WARNING)

Network logging can block the event loop. It is recommended to use a separate thread for handling logs 
or use non-blocking IO. 

##Logging Dealing with handlers that block
Sometimes you have to get your logging handlers to do their work without blocking the thread 
you’re logging from. This is common in web applications, though of course it also occurs in other scenarios.

One solution is to use a two-part approach. For the first part, attach only a QueueHandler 
to those loggers which are accessed from performance-critical threads. 
They simply write to their queue, which can be sized to a large enough capacity 
or initialized with no upper bound to their size. 
The write to the queue will typically be accepted quickly, though you will probably need 
to catch the queue.Full exception as a precaution in your code. 

The second part of the solution is QueueListener, it’s passed a queue and some handlers, 
and it fires up an internal thread which listens to its queue for LogRecords sent from QueueHandlers 

https://docs.python.org/3/library/logging.handlers.html#logging.handlers.QueueHandler
https://docs.python.org/3/library/logging.handlers.html#logging.handlers.QueueListener

que = queue.Queue(-1)  # no limit on size
queue_handler = QueueHandler(que)
handler = logging.StreamHandler()
listener = QueueListener(que, handler)
root = logging.getLogger()
root.addHandler(queue_handler)
formatter = logging.Formatter('%(threadName)s: %(message)s')
handler.setFormatter(formatter)
listener.start()
# The log output will display the thread which generated
# the event (the main thread) rather than the internal
# thread which monitors the internal queue. This is what
# you want to happen.
root.warning('Look out!')
listener.stop()

which, when run, will produce:

MainThread: Look out!

##Detect never-awaited coroutines
When a coroutine function is called, but not awaited (e.g. coro() instead of await coro()) 
or the coroutine is not scheduled with asyncio.create_task(), asyncio will emit a RuntimeWarning:

import asyncio

async def test():
    print("never scheduled")

async def main():
    test()

asyncio.run(main())

Output:

test.py:7: RuntimeWarning: coroutine 'test' was never awaited
  test()

Output in debug mode:

test.py:7: RuntimeWarning: coroutine 'test' was never awaited
Coroutine created at (most recent call last)
  File "../t.py", line 9, in <module>
    asyncio.run(main(), debug=True)

  < .. >

  File "../t.py", line 7, in main
    test()
  test()

The usual fix is to either await the coroutine or call the asyncio.create_task() function:

async def main():
    await test()
    
##AnyIO 
To install AnyIO, run:

pip install anyio

Testing with AnyIO

##Creating asynchronous tests
Pytest does not natively support running asynchronous test functions, 
so they have to be marked for the AnyIO pytest plugin to pick them up. 

This can be done in one of two ways:
    Using the pytest.mark.anyio marker

    Using the anyio_backend fixture, either directly or via another fixture

The simplest way is thus the following:

import pytest

# This is the same as using the @pytest.mark.anyio on all test functions in the module
pytestmark = pytest.mark.anyio


async def test_something():
    ...

Marking modules, classes or functions with this marker has the same effect 
as applying the pytest.mark.usefixtures('anyio_backend') on them.

Thus, you can also require the fixture directly in your tests and fixtures:

import pytest


async def test_something(anyio_backend):
    ...

##Asynchronous fixtures
The plugin also supports coroutine functions as fixtures, 
for the purpose of setting up and tearing down asynchronous services used for tests.

There are two ways to get the AnyIO pytest plugin to run your asynchronous fixtures:

    Use them in AnyIO enabled tests (see the first section)

    Use the anyio_backend fixture (or any other fixture using it) in the fixture itself

The simplest way is using the first option:

import pytest

pytestmark = pytest.mark.anyio


@pytest.fixture
async def server():
    server = await setup_server()
    yield server
    await server.shutdown()


async def test_server(server):
    result = await server.do_something()
    assert result == 'foo'

For autouse=True fixtures, you may need to use the other approach:

@pytest.fixture(autouse=True)
async def server(anyio_backend):
    server = await setup_server()
    yield
    await server.shutdown()


async def test_server():
    result = await client.do_something_on_the_server()
    assert result == 'foo'

##Using async fixtures with higher scopes
For async fixtures with scopes other than function, you will need to define your own anyio_backend 
fixture because the default anyio_backend fixture is function scoped:

@pytest.fixture(scope='module')
def anyio_backend():
    return 'asyncio'


@pytest.fixture(scope='module')
async def server(anyio_backend):
    server = await setup_server()
    yield
    await server.shutdown()



##Asynchronous file I/O support
AnyIO provides asynchronous wrappers for blocking file operations. 
These wrappers run blocking operations in worker threads.


from anyio import open_file, run


async def main():
    async with await open_file('/some/path/somewhere') as f:
        contents = await f.read()
        print(contents)

run(main)

The wrappers also support asynchronous iteration of the file line by line, 
just as the standard file objects support synchronous iteration:

from anyio import open_file, run


async def main():
    async with await open_file('/some/path/somewhere') as f:
        async for line in f:
            print(line, end='')

run(main)

To wrap an existing open file object as an asynchronous file, you can use wrap_file():

from anyio import wrap_file, run


async def main():
    with open('/some/path/somewhere') as f:
        async for line in wrap_file(f):
            print(line, end='')

run(main)

Note

Closing the wrapper also closes the underlying synchronous file object.

##Asynchronous path operations
AnyIO provides an asynchronous version of the pathlib.Path class. 
It differs with the original in a number of ways:

    Operations that perform disk I/O (like read_bytes()) are run in a worker thread and thus require an await

    Methods like glob() return an asynchronous iterator that yields asynchronous Path objects

    Properties and methods that normally return pathlib.Path objects return Path objects instead

    Methods and properties from the Python 3.10 API are available on all versions

    Use as a context manager is not supported, as it is deprecated in pathlib

For example, to create a file with binary content:

from anyio import Path, run


async def main():
    path = Path('/foo/bar')
    await path.write_bytes(b'hello, world')

run(main)

Asynchronously iterating a directory contents can be done as follows:

from anyio import Path, run


async def main():
    # Print the contents of every file (assumed to be text) in the directory /foo/bar
    dir_path = Path('/foo/bar')
    async for path in dir_path.iterdir():
        if await path.is_file():
            print(await path.read_text())
            print('---------------------')

run(main)


## AioHttp 

$ pip install aiohttp
$ pip install aiodns



import aiohttp
import asyncio

async def main():

    async with aiohttp.ClientSession() as session:
        async with session.get('http://python.org') as response:

            print("Status:", response.status)
            print("Content-type:", response.headers['content-type'])

            html = await response.text()
            print("Body:", html[:15], "...")

asyncio.run(main())

This prints:

Status: 200
Content-type: text/html; charset=utf-8
Body: <!doctype html> ...

##More example 
import aiohttp
import asyncio

Now, let’s try to get a web-page. For example let’s query http://httpbin.org/get:

async def main():
    async with aiohttp.ClientSession() as session:
        async with session.get('http://httpbin.org/get') as resp:
            print(resp.status)
            print(await resp.text())

asyncio.run(main())

In order to make an HTTP POST request use ClientSession.post() coroutine:

session.post('http://httpbin.org/post', data=b'data')

Other HTTP methods are available as well:

session.put('http://httpbin.org/put', data=b'data')
session.delete('http://httpbin.org/delete')
session.head('http://httpbin.org/get')
session.options('http://httpbin.org/get')
session.patch('http://httpbin.org/patch', data=b'data')

To make several requests to the same site more simple, 

async with aiohttp.ClientSession('http://httpbin.org') as session:
    async with session.get('/get'):
        pass
    async with session.post('/post', data=b'data'):
        pass
    async with session.put('/put', data=b'data'):
        pass

##Passing Parameters In URLs
params = {'key1': 'value1', 'key2': 'value2'}
async with session.get('http://httpbin.org/get',
                       params=params) as resp:
    expect = 'http://httpbin.org/get?key1=value1&key2=value2'
    assert str(resp.url) == expect
    

##Binary Response Content
print(await resp.read())

b'[{"created_at":"2015-06-12T14:06:22Z","public":true,"actor":{...

The gzip and deflate transfer-encodings are automatically decoded for you.

You can enable brotli transfer-encodings support, just install Brotli or brotlicffi.

##JSON Request

async with aiohttp.ClientSession() as session:
    async with session.post(url, json={'test': 'object'})

By default session uses python’s standard json module for serialization. 
But it is possible to use different serializer. ClientSession accepts json_serialize parameter:

import ujson

async with aiohttp.ClientSession(
        json_serialize=ujson.dumps) as session:
    await session.post(url, json={'test': 'object'})

JSON Response Content

There’s also a built-in JSON decoder, in case you’re dealing with JSON data:

async with session.get('https://api.github.com/events') as resp:
    print(await resp.json())

In case that JSON decoding fails, json() will raise an exception. 
It is possible to specify custom encoding and decoder functions for the json() call.

##Streaming Response Content
async with session.get('https://api.github.com/events') as resp:
    await resp.content.read(10)

In general, however, you should use a pattern like this to save what is being streamed to a file:

with open(filename, 'wb') as fd:
    async for chunk in resp.content.iter_chunked(chunk_size):
        fd.write(chunk)

It is not possible to use read(), json() and text() after explicit reading from content.


##More complicated POST requests
Typically, you want to send some form-encoded data – much like an HTML form. 
To do this, simply pass a dictionary to the data argument. 
Your dictionary of data will automatically be form-encoded when the request is made:

payload = {'key1': 'value1', 'key2': 'value2'}
async with session.post('http://httpbin.org/post',
                        data=payload) as resp:
    print(await resp.text())

{
  ...
  "form": {
    "key2": "value2",
    "key1": "value1"
  },
  ...
}

If you want to send data that is not form-encoded you can do it by passing a bytes instead of a dict. This data will be posted directly and content-type set to 'application/octet-stream' by default:

async with session.post(url, data=b'\x00Binary-data\x00') as resp:
    ...

If you want to send JSON data:

async with session.post(url, json={'example': 'test'}) as resp:
    ...

To send text with appropriate content-type just use data argument:

async with session.post(url, data='Тест') as resp:
    ...

##POST a Multipart-Encoded File

To upload Multipart-encoded files:

url = 'http://httpbin.org/post'
files = {'file': open('report.xls', 'rb')}

await session.post(url, data=files)

You can set the filename and content_type explicitly:

url = 'http://httpbin.org/post'
data = aiohttp.FormData()
data.add_field('file',
               open('report.xls', 'rb'),
               filename='report.xls',
               content_type='application/vnd.ms-excel')

await session.post(url, data=data)

##Streaming uploads
aiohttp supports multiple types of streaming uploads, which allows you to send large files 
without reading them into memory.

As a simple case, simply provide a file-like object for your body:

with open('massive-body', 'rb') as f:
   await session.post('http://httpbin.org/post', data=f)

Or you can use asynchronous generator:

async def file_sender(file_name=None):
    async with aiofiles.open(file_name, 'rb') as f:
        chunk = await f.read(64*1024)
        while chunk:
            yield chunk
            chunk = await f.read(64*1024)

# Then you can use file_sender as a data provider:

async with session.post('http://httpbin.org/post',
                        data=file_sender(file_name='huge_file')) as resp:
    print(await resp.text())

Because the content attribute is a StreamReader (provides async iterator protocol), 
you can chain get and post requests together:

resp = await session.get('http://python.org')
await session.post('http://httpbin.org/post',
                   data=resp.content)


The value could be overridden by timeout parameter for the session (specified in seconds):

timeout = aiohttp.ClientTimeout(total=60)
async with aiohttp.ClientSession(timeout=timeout) as session:
    ...

Timeout could be overridden for a request like ClientSession.get():

async with session.get(url, timeout=timeout) as resp:
    ...

Supported ClientTimeout fields are:
    total
        The maximal number of seconds for the whole operation including connection establishment, 
        request sending and response reading.

    connect
        The maximal number of seconds for connection establishment of a new connection 
        or for waiting for a free connection from a pool if pool connection limits are exceeded.

    sock_connect
        The maximal number of seconds for connecting to a peer for a new connection, 
        not given from a pool.

    sock_read
            The maximal number of seconds allowed for period between reading 
            a new data portion from a peer.

        ceil_threshold
            The threshold value to trigger ceiling of absolute timeout values.

All fields are floats, None or 0 disables a particular timeout check, see the ClientTimeout reference for defaults and additional details.

Thus the default timeout is:

aiohttp.ClientTimeout(total=5*60, connect=None,
                      sock_connect=None, sock_read=None, ceil_threshold=5)


    
##class contextvars.Context
    Context() creates an empty context with no values in it. 
    To get a copy of the current context use the copy_context() function.

    Since each thread has its own context stack, 
    ContextVar objects behave in a similar fashion to threading.local() 
    when values are assigned in different threads.

    Attempting to enter an already entered context, 
    including contexts entered in other threads, raises a RuntimeError.

    After exiting a context, it can later be re-entered (from any thread).

    Any changes to ContextVar values via the ContextVar.set() method are recorded in the current context. 
    The ContextVar.get() method returns the value associated with the current context. 
    Exiting a context effectively reverts any changes made to context variables 
    while the context was entered 
    (if needed, the values can be restored by re-entering the context).

    run(callable, *args, **kwargs)
        Enters the Context, executes callable(*args, **kwargs), 
        then exits the Context. 
        Returns callable’s return value, or propagates an exception if one occurred.

        Example:

        import contextvars

        var = contextvars.ContextVar('var')
        var.set('spam')
        print(var.get())  # 'spam'

        ctx = contextvars.copy_context()

        def main():
            # 'var' was set to 'spam' before
            # calling 'copy_context()' and 'ctx.run(main)', so:
            print(var.get())  # 'spam'
            print(ctx[var])  # 'spam'

            var.set('ham')

            # Now, after setting 'var' to 'ham':
            print(var.get())  # 'ham'
            print(ctx[var])  # 'ham'

        # Any changes that the 'main' function makes to 'var'
        # will be contained in 'ctx'.
        ctx.run(main)

        # The 'main()' function was run in the 'ctx' context,
        # so changes to 'var' are contained in it:
        print(ctx[var])  # 'ham'

        # However, outside of 'ctx', 'var' is still set to 'spam':
        print(var.get())  # 'spam'

    copy()
    var in context
    context[var]
    get(var[, default])
    iter(context)
    len(proxy)
    keys()
    values()
    items()

##asyncio support
Context variables are natively supported in asyncio and are ready to be used 
without any extra configuration. For example, here is a simple echo server, 
that uses a context variable to make the address of a remote client available 
in the Task that handles that client:

import asyncio
import contextvars

client_addr_var = contextvars.ContextVar('client_addr')

def render_goodbye():
    # The address of the currently handled client can be accessed
    # without passing it explicitly to this function.

    client_addr = client_addr_var.get()
    return f'Good bye, client @ {client_addr}\r\n'.encode()

async def handle_request(reader, writer):
    addr = writer.transport.get_extra_info('socket').getpeername()
    client_addr_var.set(addr)

    # In any code that we call is now possible to get
    # client's address by calling 'client_addr_var.get()'.

    while True:
        line = await reader.readline()
        print(line)
        if not line.strip():
            break

    writer.write(b'HTTP/1.1 200 OK\r\n')  # status line
    writer.write(b'\r\n')  # headers
    writer.write(render_goodbye())  # body
    writer.close()

async def main():
    srv = await asyncio.start_server(
        handle_request, '127.0.0.1', 8081)

    async with srv:
        await srv.serve_forever()

asyncio.run(main())

# To test it you can use telnet or curl:
#     telnet 127.0.0.1 8081
#     curl 127.0.0.1:8081

###HandsON - with asyncio (co-operative asynchronous - not concurrent - single thread )
1. await can be used inside another async def called coroutine
   result = await croutine(..)
   args is A asyncio.Task, a coroutine or an awaitable, 
2. Inside main process use 
    result = asyncio.run(coroutine())
    asyncio.run(coro, *, debug=None, loop_factory=None)
   inside async def , 
       Use 
       task1 = asyncio.create_task(co(...))
       await task1 
       
       #for fire and forget 
       async with asyncio.TaskGroup() as tg:
         task1 = asyncio.create_task(co(...))
         task1 = asyncio.create_task(co(...))
         
       list = await  asyncio.gather(co(...), co(...), return_exceptions=False)
       done, pending = await asyncio.wait([co(...), co(...)], *, timeout=None, return_when=ALL_COMPLETED)
       
       async for f in as_completed([co(...), co(...)]): # f is original task 
            result= await f
            
3. Asynchronously run function func in a separate thread.
    await asyncio.to_thread(func, /, *args, **kwargs)
    ie use 
        await asyncio.to_thread(def_function_which_is_blocking)
        
    OR use 
        awaitable loop.run_in_executor(executor, func, *args)
        
   #default thread pool
   result = await loop.run_in_executor(None, def_function_which_is_blocking)
  
    # 2. Run in a custom thread pool:
    with concurrent.futures.ThreadPoolExecutor() as pool:
        result = await loop.run_in_executor( pool, def_function_which_is_io_blocking)
    # 3. Run in a custom process pool:
    with concurrent.futures.ProcessPoolExecutor() as pool:
        result = await loop.run_in_executor( pool, def_function_which_is_cpu_blocking)
    Process Must have 
    if __name__ == '__main__':
        asyncio.run(main())

        
4. Scheduling a coroutine From Other Threads into this loop 
   Note get_current_loop() from main thread should be passed to other thread 
   
   concurrent.futures.Future  = asyncio.run_coroutine_threadsafe(coro(...), loop)
   concurrent.futures.Future .result() gives result in other thread 


##Handson 
async def get(session, url, *args, **kwargs):  
    async with session.get(url, *args, **kwargs ) as resp:
        return (await resp.json())

async def post(session, url, *args, **kwargs):  
    async with session.post(url, *args, **kwargs ) as resp:
        return (await resp.json())

async def download_get(urls, *args, **kwargs):
    async with aiohttp.ClientSession() as session:
            results = await asyncio.gather(*[get(session, url, *args, **kwargs) for url in urls])
    return results 

async def download_post(urls, *args, **kwargs):
    async with aiohttp.ClientSession() as session:
            results = await asyncio.gather(*[post(session, url, *args, **kwargs) for url in urls])
    return results 

urls1 = ["http://httpbin.org/get" for i in range(10)]
urls2 = ["http://httpbin.org/post" for i in range(10)]
headers = {'Content-Type': 'application/json'}
params = { 'name': 'abc'}
data = {'name': 'xyz'}
import json 

#def program 
rsults = asyncio.run(download_get(urls1, params=params))       
rsults = asyncio.run(download_post(urls2, data=json.dumps(params),headers=headers))        



 
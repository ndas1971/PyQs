###Sorting and Lambda 



###zip and enumerate 
       
###OOP 
#  Class Example: User, PreUser, BankAcount
Bank User has name and account. There are two types of Users
Normal and privileged user . There are two types of privileged
users, Gold and Silver. Gold has cashback of 5% and Silver has 
cashback of 3% of expenditure when they spend any cash 

# Amount


class NotEnoughBalance(Exception):
    pass

class BankAccount:
    def __init__(self, initAmount):
        self.amount = initAmount
    def transact(self, amount):
        if self.amount +amount < 0 :
            raise NotEnoughBalance("Not possible")
        self.amount = self.amount + amount
    def __str__(self):
        return "BankAccount("+str(self.amount)+")"
        
from abc import ABCMeta, abstractmethod
class BankUser(metaclass=ABCMeta):
    how_many_users = {'TotalUsers': 0}     #BankUser.how_many_users
    def __init__(self, name, initAmount):
        self.name = name 
        self.account = BankAccount(initAmount)
        self.update_user_types()
    @property  # get
    def balance(self):
        return self.account.amount        
    @balance.setter  #setting
    def balance(self, amount):
        #self.account.amount = amount
        raise NotImplementedError("can not set via property, use transact method")
    def update_user_types(self):
        t = self.getUserType()
        if t in BankUser.how_many_users:
            BankUser.how_many_users[t] += 1
        else:
            BankUser.how_many_users[t] = 1
        BankUser.how_many_users['TotalUsers'] += 1        
    def __str__(self):
        return "%s(%s,%s)" % (self.getUserType(), self.name, str(self.balance))
    @abstractmethod
    def getCashbackPercentage(self):
        return 0
    @abstractmethod
    def getUserType(self):
        pass
    @classmethod 
    def howMany(cls):
        return cls.how_many_users    
    def transact(self, amount):
        try:
            self.account.transact(amount)
            if amount < 0:
                cashback = self.getCashbackPercentage() * abs(amount)
                self.account.transact(cashback)
        except NotEnoughBalance as ex:
            print(str(ex), "Name:", self.name, "amount:", amount)

class NormalUser(BankUser):
    def getCashbackPercentage(self):
        return super().getCashbackPercentage()
    def getUserType(self):
        return "NormalUser"

class GoldUser(BankUser):
    def getCashbackPercentage(self):
        return 0.05     
    def getUserType(self):
        return "GoldUser"

class SilverUser(BankUser):
    def getCashbackPercentage(self):
        return 0.03    
    def getUserType(self):
        return "SilverUser"        

if __name__ == '__main__':   # pragma: no cover
    users = [GoldUser("Gold", 100),
             SilverUser("Silver", 100),
             NormalUser("Normal",100)]
    amounts = [100, -200, 300, -400, 400]
    for u in users:
        for am in amounts:
            u.transact(am)
        #u.balance = 500
        print(u, u.balance)
    print(BankUser.howMany())
    
DAY-1-Second Half



###*** Test coverage 
#Any unexpected error, remove .cache file 
$ pip install pytest-cov -i JPMC_INTERNAL_SERVER

$ pytest -v classTest 

$ pytest --cov=userh test_userh.py   
#check coverage of 'class/pkg' by running all tests under class/
Check https://pytest-cov.readthedocs.io/en/latest/reporting.html
--cov-report=html for html report 
eg to get line nos which are missed
--cov-report term-missing
#anotated source code check userh/classes.py,cover 
#where ! means missed line 
--cov-report annotate 
It uses internally coverage.py, check the meaning 
https://coverage.readthedocs.io/en/latest/cmd.html#text-annotation-coverage-annotate

Skipping 
https://coverage.readthedocs.io/en/latest/excluding.html
eg use # pragma: no cover to remove some code 
if __name__ == '__main__':  # pragma: no cover

$ pytest --cov=userh --cov-report term-missing test_user.py

        
'''
Lots of options 
$ pytest --help 

$ pytest -v test_userh.py
#check default markers
pytest --markers  
#check default fixtures 
pytest --fixtures

To check scope 
https://docs.pytest.org/en/stable/fixture.html#fixture-scopes

#to output of  stdout
$ pytest -v -s test_userh.py

#to check builtin fixture 
$ pytest --markers
         
#For running marker
pytest -v -m addl
pytest -v -m "not addl"

#request is optional and it contains few requestng functions 
https://docs.pytest.org/en/stable/fixture.html#fixtures-can-introspect-the-requesting-test-context
'''
#pytest.ini 
[pytest]
markers = 
    addl: Addl testcases 
    
#conftest.py 
from userh import * 
import pytest 

@pytest.fixture(scope='module')
def silver(request):  # request is optional, 
    a = SilverUser("Gold",  BankAccount(100))
    yield a   # use return, then no teardown code 
    print("shutdown code")
  
@pytest.fixture(scope='module')
def amounts(request):
    a = [ 100, -200, 300, -400, 400]
    yield a

@pytest.fixture(scope='module')
def normal(request):
    a = NormalUser("Gold",  BankAccount(100))
    yield a
    
    
#test_user.py 
from userh import *
import pytest

class TestUser:
    def test_gold(self, amounts):
        u = GoldUser("Gold",  BankAccount(100))
        for am in amounts:
            u.transact(am)
        assert u.balance == 710

@pytest.mark.addl     
def test_normal(normal, amounts):   
    for am in amounts:
            normal.transact(am)
    assert normal.balance == 700

@pytest.mark.addl     
def test_silver(silver, amounts):   
    for am in amounts:
            silver.transact(am)
    assert silver.balance == 704
    
    
#Quick mock 
#userh.py 
class BankUser:
    def __init__(self, name, initAmount):
        pass 
    @property  # get
    def balance(self):
        pass      
    def transact(self, amount):
        pass 
        
class GoldUser(BankUser):
    pass

#Monkey patching 
"""
Pytest 
(can be used in fixture as well, use as argument)
    monkeypatch.setattr(obj, name, value, raising=True)
        monkeypatch.setattr(os, "getcwd", lambda: "/")
        monkeypatch.setattr("os.getcwd", lambda: "/")
        
    monkeypatch.delattr(obj, name, raising=True)
    monkeypatch.setitem(mapping, name, value)
    monkeypatch.delitem(obj, name, raising=True)
    monkeypatch.setenv(name, value, prepend=None)
    monkeypatch.delenv(name, raising=True)
    monkeypatch.syspath_prepend(path)
    monkeypatch.chdir(path)

unitest.mock 
https://docs.python.org/3/library/unittest.mock.html#patch
patch(target, new=DEFAULT, spec=None, create=False, spec_set=None, autospec=None, new_callable=None, **kwargs)
    if target is instance, creates on instance 
    if target is class, it is created on class 
    Note target (for class) has to be as 'package.module.ClassName', with ''
    and for instance , '__main__.instanceVar'
    **kwargs can be  attribute1=value1, ..
    and/or {'method.return_value': 3, 'other.side_effect': KeyError}
    where method(..): returns 3 and other(...) raises KeyError 
    side_effect can be also a function of any args..
    If new is missing, it creates MagicMock(..), a callable 
To create on any instance of a Class, use - target is package.module.ClassName ie without ''
patch.object(target, attribute, new=DEFAULT, spec=None, create=False, spec_set=None, autospec=None, new_callable=None, **kwargs)
    In dict 
patch.dict(in_dict, values=(), clear=False, **kwargs)
eg @patch.dict('os.environ', {'newkey': 'newvalue'})


where to patch 
a.py
    -> Defines SomeClass

b.py
    -> from a import SomeClass
    -> some_function instantiates SomeClass
    Use 
    @patch('b.SomeClass')
    -> import a 
    Then use 
    @patch('a.SomeClass')
    


"""






#pytest -s -v test_userh.py
import userh 
from unittest.mock import patch

#IF balance is a method,   @patch.object(userh.GoldUser, 'balance', lambda *c,**kwargs: 710)
@patch.object(userh.GoldUser, 'balance', 710)
@patch.object(userh.GoldUser, 'transact', lambda *c,**kwargs: "OK")
def test_gold1():
    u = userh.GoldUser("Gold",  100)
    amounts = [ 100, -200, 300, -400, 400]   
    for am in amounts:
        print(u.transact(am))
    assert u.balance == 710
    
#Be advised that it is not recommended to patch builtin functions such as open, compile, etc., 
#because it might break pytest’s internals, hence Use as content as given below 
def test_gold2(monkeypatch):
    with monkeypatch.context() as m:
        #IF balance is a method,  m.setattr(userh.GoldUser, 'balance', lambda *c,**kwargs: 710)
        m.setattr(userh.GoldUser, 'balance', 710)
        m.setattr(userh.GoldUser, 'transact', lambda *c,**kwargs: "OK")
        u = userh.GoldUser("Gold",  100)
        amounts = [ 100, -200, 300, -400, 400]   
        for am in amounts:
            print(u.transact(am))
        assert u.balance == 710
        
#as a deco 
import userh 
import pytest

def mpatch(*a, **kw):
    def _ac(func):
        def _in(*args, **kargs):
            mkp = pytest.MonkeyPatch()
            with mkp.context() as m:
                m.setattr(*a, **kw)
                res = func(*args, **kargs)
                return res 
        return _in 
    return _ac 
    
@mpatch(userh.GoldUser, 'balance', 710)
@mpatch(userh.GoldUser, 'transact', lambda *a,**k: "OK")
def test_gold2():
    u = userh.GoldUser("Gold",  100)
    amounts = [ 100, -200, 300, -400, 400]   
    for am in amounts:
        print(u.transact(am))
    assert u.balance == 710        
        
        
#Example of lib replacement 
from pathlib import Path
def getssh():
    return Path.home() / ".ssh"
    



def test_getssh(monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: Path("/abc"))
    # Calling getssh() will use mockreturn in place of Path.home
    # for this test with the monkeypatch.
    x = getssh()
    assert x == Path("/abc/.ssh")
    
#Another Example  
import requests
def get_json(url):
    r = requests.get(url)
    return r.json()
    
class MockResponse:
    @staticmethod
    def json():
        return {"mock_key": "mock_response"}


def test_get_json(monkeypatch):
    monkeypatch.setattr(requests, "get", lambda *args, **kwargs: MockResponse())
    result = app.get_json("https://fakeurl")
    assert result["mock_key"] == "mock_response"
    
#Another Example   
If you want to prevent the 'requests' library from performing http requests 
in all your tests, you can do:

import pytest

@pytest.fixture(autouse=True)
def no_requests(monkeypatch):
    monkeypatch.delattr("requests.sessions.Session.request")

This autouse fixture will be executed for each test function 
and it will delete the method request.session.Session.request 
so that any attempts within tests to create http requests will fail.

#Another Example - With fixture 
import os

def get_os_user_lower():
    username = os.getenv("USER")
    if username is None:
        raise OSError("USER environment is not set.")
    return username.lower()
    

import pytest


@pytest.fixture
def mock_env_user(monkeypatch):
    monkeypatch.setenv("USER", "TestingUser")


@pytest.fixture
def mock_env_missing(monkeypatch):
    monkeypatch.delenv("USER", raising=False)


# notice the tests reference the fixtures for mocks
def test_upper_to_lower(mock_env_user):
    assert get_os_user_lower() == "testinguser"


def test_raise_exception(mock_env_missing):
    with pytest.raises(OSError):
        _ = get_os_user_lower()
        
#Another Example 

DEFAULT_CONFIG = {"user": "user1", "database": "db1"}

def create_connection_string(config=None):
    """Creates a connection string from input or defaults."""
    config = config or DEFAULT_CONFIG
    return f"User Id={config['user']}; Location={config['database']};"
    
# contents of test_app.py
import pytest

# app.py with the connection string function
import app


# all of the mocks are moved into separated fixtures
@pytest.fixture
def mock_test_user(monkeypatch):
    """Set the DEFAULT_CONFIG user to test_user."""
    monkeypatch.setitem(app.DEFAULT_CONFIG, "user", "test_user")


@pytest.fixture
def mock_test_database(monkeypatch):
    """Set the DEFAULT_CONFIG database to test_db."""
    monkeypatch.setitem(app.DEFAULT_CONFIG, "database", "test_db")


@pytest.fixture
def mock_missing_default_user(monkeypatch):
    """Remove the user key from DEFAULT_CONFIG"""
    monkeypatch.delitem(app.DEFAULT_CONFIG, "user", raising=False)


# tests reference only the fixture mocks that are needed
def test_connection(mock_test_user, mock_test_database):
    expected = "User Id=test_user; Location=test_db;"
    result = app.create_connection_string()
    assert result == expected


def test_missing_user(mock_missing_default_user):
    with pytest.raises(KeyError):
        _ = app.create_connection_string()
        
        
Using pytest-mock 
pip install pytest-mock

The mocker fixture has the same API as mock.patch, supporting the same arguments:
def test_foo(mocker):
    # all valid calls
    mocker.patch('os.remove')                           #by default returns None for any function 
                                                        #or use return_value = something 
                                                        #or side_effect = can be Exception of a user 
                                                        #defined function 
    mocker.patch.object(os, 'listdir', autospec=True)
    mocked_isfile = mocker.patch('os.path.isfile')
    
stub is for callback function 
def test_stub(mocker):
    def foo(on_something):
        on_something('foo', 'bar')

    stub = mocker.stub(name='on_something_stub')

    foo(stub)
    stub.assert_called_once_with('foo', 'bar')
    
        
#To capture 
pytest -s                  # disable all capturing, prints out and err on screen 
pytest --capture=sys       # replace sys.stdout/stderr with in-mem files
pytest --capture=fd        # also point filedescriptors 1 and 2 to temp file, 
                           #All output and errors (even from subprocesses) are captured., 
                           #not for others options 
pytest --capture=tee-sys   # combines 'sys' and '-s', capturing sys.stdout/stderr
                           # and passing it along to the actual sys.stdout/stderr
                           
For test function, use capsys 
The capsys, capsysbinary, capfd, and capfdbinary fixtures allow access 
to stdout/stderr output created during test execution. 

def test_myoutput(capsys):  # or use "capfd" for fd-level
    print("hello")
    sys.stderr.write("world\n")
    captured = capsys.readouterr()
    assert captured.out == "hello\n"
    assert captured.err == "world\n"
    print("next")
    captured = capsys.readouterr()
    assert captured.out == "next\n"
    
In case of mock 
from io import StringIO
def foo():
    print('Something')
    
@patch('sys.stdout', new_callable=StringIO)
def test(mock_stdout):
    foo()
    assert mock_stdout.getvalue() == 'Something\n'
test()
    
    
##Decorator 

#without wraps, trace prints _inner 
from functools import wraps
def  mea(fun):
    @wraps(fun)
    def _inner(*args, **kargs):
        import time
        now = time.time()
        res = fun(*args,**kargs)
        print(time.time() - now, " secs")
        return res
    return _inner

  
def trace(f):
    def _inner(*args, **kargs):
        print(f"entering {f.__name__}")
        res = f(*args,**kargs)
        print(f"exiting {f.__name__}")
        return res
    return _inner

import glob, os.path  
    
#opposite is OK 
@trace 
@mea
def getMaxFilename(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for file in files:
            if os.path.isfile(file):
                ed[file] =  os.path.getsize(file)
        for file in files:
            if not os.path.isfile(file):
                get_files(file, ed)
        return ed
    allfiles = get_files(path)
    sted = sorted(allfiles, key=lambda k: allfiles[k])
    return sted[-1]


#Suppose we, want to round to certain digits  of mea output 
from functools import wraps
def mea(howmany=2):
    def  _inner1(fun):
        @wraps(fun)
        def _inner2(*args, **kargs):
            import time
            now = time.time()
            res = fun(*args,**kargs)
            print(round(time.time() - now, howmany), " secs")
            return res
        return _inner2
    return _inner1

#default would work this way 
@trace 
@mea()
def getMaxFilename(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for file in files:
            if os.path.isfile(file):
                ed[file] =  os.path.getsize(file)
        for file in files:
            if not os.path.isfile(file):
                get_files(file, ed)
        return ed
    allfiles = get_files(path)
    sted = sorted(allfiles, key=lambda k: allfiles[k])
    return sted[-1]

    
##Using wraps 
#the name of the example function would have been 'wrapper', 
#and the docstring of the original example() would have been lost.
   
    
from functools import wraps
def my_decorator(f):
    @wraps(f)
    def wrapper(*args, **kwds):
        print 'Calling decorated function'
        return f(*args, **kwds)
    return wrapper

@my_decorator
def example():
    """Docstring"""
    print 'Called example function'

>>> example()
Calling decorated function
Called example function
>>> example.__name__
'example'
>>> example.__doc__
'Docstring'


###Iterator
import glob , os.path 

def get_files(path, res):
    files = glob.glob(os.path.join(glob.escape(path), "*"))
    for file in files:
        if os.path.isfile(file):
            res.append(file) 
    for file in files:
        if os.path.isdir(file):
            get_files(file, res)
    return res
            
#Iterator 
def get_files_recursive(path):
    files = glob.glob(os.path.join(glob.escape(path), "*"))
    #print(os.path.join(glob.escape(path), "*"), files)
    for file in files:
        if os.path.isfile(file):
            yield file 
    for file in files:
        if os.path.isdir(file):
            #print("dir", file)
            yield from get_files_recursive(file)
            
            
##HandsON 
MaxFile class 
from pkg.file import File 
fs = File(".")
fs.getMaxSizeFile(2) # gives two max file names 
fs.getLatestFiles(datetime.date(2018,2,1))
#Returns list of files after 1st Feb 2018 



import datetime, glob, os.path 
class File:
    def __init__(self, dir, dynamic=False):
        self.dir = dir 
        self.file_dict = None 
        self.dynamic = dynamic 
    def getAllFiles(self):
        def recurse(root, acc={} ):
            import os.path, glob
            lst = [os.path.normpath(f) for f in glob.glob(os.path.join(root, "*"))]
            acc.update( { f:{'size':os.path.getsize(f), 
                             'mtime': datetime.date.fromtimestamp(os.path.getmtime(f)),
                             'ctime': datetime.date.fromtimestamp(os.path.getctime(f))}   
                             for f in lst if os.path.isfile(f) } )
            [recurse(f, acc) for f in lst if os.path.isdir(f)]	
            return acc
        if not self.file_dict or self.dynamic:
            self.file_dict = recurse(self.dir)
    def getMaxSizeFile(self, howmany=1):
        self.getAllFiles()
        maxnames = sorted(self.file_dict.keys(), 
            key = lambda n: self.file_dict[n]['size'], reverse=True )
        return [(maxnames[i],self.file_dict[maxnames[i]]['size'])  
            for i in range(howmany)] 
    def getLatestFiles(self, after=datetime.date.today()-datetime.timedelta(days=7)):
        """ after : datetime.date(year, month, day)"""
        self.getAllFiles()
        return [ f  for f in  self.file_dict 
            if ( self.file_dict[f]['mtime'] >= after 
            or self.file_dict[f]['ctime'] >= after )]


###Groupby functions 
import os.path, glob 

def get_files_size(path, ed): # default mutable param does not really work with deco
    files = glob.glob(os.path.join(path, "*"))
    for file in files:
        if os.path.isfile(file):
            ed[file] = os.path.getsize(file)
    for file in files:
        if not os.path.isfile(file):
            get_files_size(file, ed)
    return ed

def groupBy(lst, keyFn):
    ed = {}
    for e in lst:
        key = keyFn(e)
        if key not in ed:
            ed[key] = [e]
        else:
            ed[key].append(e)
    return ed 

def multiKeyGroupBy(lst, multiKeyFn):
    ed = {}
    for e in lst:
        keys = multiKeyFn(e)
        for key in keys:
            if key not in ed:
                ed[key] = [e]
            else:
                ed[key].append(e)
    return ed     

path = r"D:\tool"
ed = get_files_size(path, {})

def multikeyFn(e, originalpath):    
    dirname = os.path.dirname(e)
    lst = [dirname]  
    while os.path.normpath(originalpath) != os.path.normpath(dirname):
        nextdirname = os.path.dirname(dirname)
        lst.append(nextdirname)
        dirname = nextdirname        
    return lst 

def multikeyFn(e, originalpath):  
    def inner(path, acc):
        return acc if os.path.normpath(originalpath) == os.path.normpath(path) else inner(os.path.dirname(path), acc + (path,))
    return inner(e, ()) 

res = multiKeyGroupBy(ed.items(), lambda t:  multikeyFn(t[0], path) )
#dict[key] = [ (name, size)]

onlysize = {k:[t[1] for t in lst]     for k, lst in res.items()}
dirsize = { k: (sum(lst), len(lst)) for k, lst in onlysize.items()}
##grouped
def grouped(lst, n):
    res = list(zip(*[lst[i::n] for i in range(n)]))
    #last segment
    end = n + n*((len(lst)-n)//n)
    if  lst[end:]:
        res.append(tuple(lst[end:]))
    return res   
###*** XML 
import xml.etree.ElementTree as ET
tr = ET.parse(r"data\example.xml")
#Or directly from a string:
root = ET.fromstring(country_data_as_string)

root = tr.getroot()
root.tag
root.attrib
root.text
nn = root.findall("./country/rank")
[n.text  for n in nn]

res = []
for n in nn:
    res.append(n.text)

[int(n.text)  for n in nn]

nn = root.findall("./country")
[n.attrib['name']  for n in nn]

res = []
for n in nn:
    res.append(n.attrib['name'])
    
#other 
#Give me all country names along with it's neighbors
{ c.attrib["name"] : [
    n.attrib["name"] for n in c.findall(".//neighbor")]
  for c in root_element.findall(".//country")}


# Top-level elements
root.findall(".")
root.findall("./country/neighbor")
# Nodes with name='Singapore' that have a 'year' child
root.findall(".//year/..[@name='Singapore']")
# 'year' nodes that are children of nodes with name='Singapore'
root.findall(".//*[@name='Singapore']/year")
# All 'neighbor' nodes that are the second child of their parent
root.findall(".//neighbor[2]")

#Modifying an XML File
#to update attribute,  use Element.set()
#to update text, just assign to text 
import xml.etree.ElementTree as ET
tree = ET.parse('example.xml')
root = tree.getroot()

for rank in root.iter('rank'):
    new_rank = int(rank.text) + 1
    rank.text = str(new_rank)
    rank.set('updated', 'yes')

tree.write('output.xml')

#Creation
#Element(tag, attrib={})
#SubElement(parent, tag, attrib={})
import xml.etree.ElementTree as ET
a = ET.Element('a')
b = ET.SubElement(a, 'b', attrib=dict(count="1")) #attrib must be string 
b.text = "hello"
ET.dump(a)

>>> #with NS
>>> tr1 = ET.parse(r"data\example1.xml")
>>> root1 = tr1.getroot()
>>> root1.tag
'{http://people.example.com}actors'
>>> ns = dict(ns="http://people.example.com")
>>> ns1 = dict(ns1="http://characters.example.com")
>>> nn = root1.findall(".//ns1:character", ns1)
>>> nn
>>> [n.text for n in nn]
['Lancelot', 'Archie Leach', 'Sir Robin', 'Gunther', 'Commander Clement']
>>> #Give actor name and his/her characters
>>> { actor.findall(".//ns:name", ns)[0].text : [
...    char.text for char in actor.findall(".//ns1:character", ns1)]
...  for actor in root1.findall(".//ns:actor", ns)}
{'John Cleese': ['Lancelot', 'Archie Leach'], 'Eric Idle': ['Sir Robin', 'Gunt
her', 'Commander Clement']}


#for example rest API 
url = "http://weatherapi1971.pythonanywhere.com/query.yahooapis.com/v1/public/yql"
p = {'q': "select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='mumbai') and u='c'",
         "format" : "xml"}
import requests 
r = requests.get(url, params=p)

#Now parse
import xml.etree.ElementTree as ET
obj = ET.fromstring(r.text)
#prettyprint 
rough_string = ET.tostring(obj, 'utf-8')
import xml.dom.minidom as dom
xp = dom.parseString(rough_string)
print(xp.toprettyxml(indent="\t"))


ns = dict(ns1="http://xml.weather.yahoo.com/ns/rss/1.0")
{e.attrib['date']: e.attrib['low']  for e in obj.findall('.//ns1:forecast', ns) }


###JSON 
import json
with open(r"data/example.json", "rt") as f:
    obj = json.load(f)

[emp['empId']   for emp in obj]

res = []
for emp in obj:
    res.append(emp['empId'])

[emp['details']['firstName'] + emp['details']['lastName']   for emp in obj]

for emp in obj:
    res.append(emp['details']['firstName'] + emp['details']['lastName'])

#other 
#Give me all office phone nos
[ ph["number"] for emp in obj
     for ph in emp['details']['phoneNumbers']
       if ph['type'] == 'office']

{ ph["number"] for emp in obj
     for ph in emp['details']['phoneNumbers']
       if ph['type'] == 'office'}

#OR
o = set()
for emp in obj:
    for ph in emp['details']['phoneNumbers']:
            if ph['type'] == 'office':
                    o.add(ph["number"])


>>> with open(r"data\weather.json", "rt") as f:
...     obj = json.load(f)
...
>>> type(obj)
<class 'dict'>
>>> obj.keys()
dict_keys(['query'])
>>> type(obj['query'])
<class 'dict'>
>>> obj['query'].keys()
dict_keys(['count', 'created', 'lang', 'results'])
>>> type(obj['query']['results'])
<class 'dict'>
>>> obj['query']['results'].keys()
dict_keys(['channel'])
>>> type(obj['query']['results']['channel'])
<class 'dict'>
>>> obj['query']['results']['channel'].keys()
dict_keys(['units', 'title', 'link', 'description', 'language', 'lastBuildDate
', 'ttl', 'location', 'wind', 'atmosphere', 'astronomy', 'image', 'item'])
>>> obj['query']['results']['channel']['item'].keys()
dict_keys(['title', 'lat', 'long', 'link', 'pubDate', 'condition', 'forecast',
 'description', 'guid'])
>>> type(obj['query']['results']['channel']['item']['forecast'])
<class 'list'>
>>> e = obj['query']['results']['channel']['item']['forecast'][0]
>>> e
{'code': '23', 'date': '19 Aug 2020', 'day': 'Wed', 'high': '27', 'low': '17',
 'text': 'Breezy'}
>>> e['date']
'19 Aug 2020'
>>> e['low']
'17'
>>> {e['date'] : e['low'] for e in obj['query']['results']['channel']['item'][
'forecast'] }

#for example rest API 
url = "http://weatherapi1971.pythonanywhere.com/query.yahooapis.com/v1/public/yql"
p = {'q': "select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='mumbai') and u='c'",
         "format" : "json"}
import requests 
r = requests.get(url, params=p)
obj = r.json()
{e['date']: e['low']  for e in 
  obj['query']['results']['channel']['item']['forecast'] }
  
##Pytest and Python Path 
Multiple path entries are also allowed: for a layout

repo/
├── src/
|   └── lib.py
├── app.py
└── tests
     ├── test_app.py
     └── test_lib.py

pyproject.toml example:

[tool.pytest.ini_options]
pythonpath = [
  ".", "src",
]

or pytest.ini example:

[pytest]
pythonpath = . src

will add both app and lib modules to sys.path, so

import app
import lib

will both work.
          

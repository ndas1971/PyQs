###Introducing IPython and the Jupyter Notebook
JupyterLab also comes with a visual debugger that lets you interactively set 
breakpoints, step into functions, and inspect variables.
https://jupyterlab.readthedocs.io/en/stable/user/debugger.html
The debugger can be enabled by toggling the bug button 
on in the upper-right corner of the notebook(before Python3 (ipykernel)


So in the old days, there is just one Jupyter Notebook, 
and now with JupyterLab (and in the future), Notebook is just one of the core 
applications in JupyterLab (along with others like code Console, 
command-line Terminal, and a Text Editor).

    View Files, running kernels, Commands, Notebook Tools, 
    Open Tabs or Extension manager
    Run cells using, among other options, Ctrl+Enter
    Run single expression, line or highlighted text using menu options 
    or keyboard shortcuts
    Run code directly in a console using Shift+Enter
    Inspect variables, dataframes or plots quickly 
    and easily in a console without cluttering your notebook output.

    
JupyterLab
https://jupyterlab.readthedocs.io/en/latest/

pip install jupyterlab

Once installed, launch JupyterLab with:

jupyter lab --notebook-dir=E:/ --preferred-dir E:/Documents/Somewhere/Else

JupyterLab’s file navigation URLs adopts the nomenclature 
of the classic notebook; these URLs are /tree URLs:

http(s)://<server:port>/<lab-location>/lab/tree/path/to/notebook.ipynb

By default, the file browser will navigate to the folder containing 
the requested file. 
This behavior can be changed with the optional file-browser-path query parameter:

http(s)://<server:port>/<lab-location>/lab/tree/path/to/notebook.ipynb?file-browser-path=/

Entering the above URL will show the workspace root folder instead 
of the /path/to/ folder in the file browser.

#Linking Notebook Sections
To create an URL which will scroll to a specific heading in the notebook 
append a hash (#) followed by the heading text with spaces replaced 
by minus characters (-), for example:

/lab/tree/path/to/notebook.ipynb?#my-heading

To get a link for a specific heading, hover over it in a rendered markdown cell 
until you see a pilcrow mark (¶) which will contain the desired anchor link:


Jupyter Notebook
pip install notebook

https://github.com/voila-dashboards/voila
Voilà turns Jupyter notebooks into standalone web applications.
Unlike the usual HTML-converted notebooks, each user connecting to the Voilà 
tornado application gets a dedicated Jupyter kernel 
which can execute the callbacks to changes in Jupyter interactive widgets.

pip install voila

To render the bqplot example notebook as a standalone app, 
run voila bqplot.ipynb. 
To serve a directory of jupyter notebooks, run voila with no argument.



$ C:\Anaconda3\Scripts\activate aiml
$ jupyter notebook --notebook-dir='D:/Desktop/PPT/python/Jupyter/code'


#Step-1  , Run - Shift+Enter 
print("Hello world!")

#Step-2
2 + 2

#Step-3: access last result 
_ * 3

#step-4: execute shell command 
!dir

#step-5: Magic command 
#https://ipython.readthedocs.io/en/stable/interactive/magics.html
%lsmagic
Help on any magic , put ? or ??
%timeit?

Line magics apply to the current line and start with %, 
while cell magics apply to the entire cell and start with %%. 

    %lsmagic: Shows a list of all available magic commands.
    %history -n: Displays the last n commands with their line numbers.
    %time Time execution of a Python statement or expression.
        This function can be used both as a line and cell magic:
    %timeit (more control) Time execution of a Python statement or expression
    Usage, in line mode:
        %timeit [-n<N> -r<R> [-t|-c] -q -p<P> -o] statement
    or in cell mode:
        %%timeit [-n<N> -r<R> [-t|-c] -q -p<P> -o] setup_code code code…
        -n<N>: execute the given statement <N> times in a loop. 
        If <N> is not provided, <N> is determined so as to get sufficient accuracy.
        -r<R>: number of repeats <R>, each consisting of <N> loops, 
        and take the average result. Default: 7
        -p<P>: use a precision of <P> digits to display the timing result. Default: 3
        -q: Quiet, do not print result.
        -o: return a TimeitResult that can be stored in a variable to inspect
    %quickref: Provides a quick reference of common magic commands and their descriptions.
    %env: Displays a list of all environment variables.
    %load and %run: Load and execute external Python scripts, respectively.
    %debug: Activates the interactive debugger for error analysis. 
    %magic    Print information about the magic function system.
    Supported formats: -latex, -brief, -rest

    
    Example 
     
    In [1]: %alias_magic t timeit
    Created `%t` as an alias for `%timeit`.
    Created `%%t` as an alias for `%%timeit`.

    In [2]: %t -n1 pass
    107 ns ± 43.6 ns per loop (mean ± std. dev. of 7 runs, 1 loop each)

    In [3]: %%t -n1
       ...: pass
       ...:
    107 ns ± 58.3 ns per loop (mean ± std. dev. of 7 runs, 1 loop each)

    In [4]: %alias_magic --cell whereami pwd
    UsageError: Cell magic function `%%pwd` not found.
    In [5]: %alias_magic --line whereami pwd
    Created `%whereami` as an alias for `%pwd`.

    In [6]: %whereami
    Out[6]: '/home/testuser'

    In [7]: %alias_magic h history -p "-l 30" --line
    Created `%h` as an alias for `%history -l 30`.

#Step-51:Use 
%pwd  #look at the current work dir
%cd   #change to the dir you want 
    
#Step-6: Use cell magic 
%%writefile test.txt
Hello world!


# Let's check what this file contains.
with open('test.txt', 'r') as f:
    print(f.read())

#Or 
%pycat test.txt

#List all variables 
a = 2
%who 
#Store any variable and read in any other notebook 
%store a 

#other notebook 
%store -r a 
print(a)

#Execute Html script 
%%html
<html>
<body>
<table>
        <tr> 
            <th>Name</th> 
            <th>Country</th> 
            <th>Age</th> 
        </tr> 
        <tr> 
            <td>Sid</td> 
            <td>India</td> 
            <td>22</td> 
        </tr>
        <tr> 
            <td>Dave</td> 
            <td>UK</td> 
            <td>28</td> 
        </tr>
</table>
</body>
</html>

#Get env 
%env PATH 

#Set env var 
%env variable value

#Object detail info 
a = "The World Makes Sense!"
%pinfo a


#find more information about any command by adding ? after it
#eg running external program 
%run?

#Step-7 : Create Markdown cell
press Esc and then press M (can be done with Menu as well)
    #Command 
    Toggle between edit and command mode with Esc and Enter, respectively.
    Once in command mode:
        Scroll up and down your cells with your Up and Down keys.
        Press A or B to insert a new cell above or below the active cell.
        M will transform the active cell to a Markdown cell.
        Y will set the active cell to a code cell.
        D + D (D twice) will delete the active cell.
        Z will undo cell deletion.
        Hold Shift and press Up or Down to select multiple cells at once.
            With multple cells selected, Shift + M will merge your selection.
    Ctrl + Shift + -, in edit mode, will split the active cell at the cursor.
    You can also click and Shift + Click in the margin to the left of your cells to select them.
Markdown  can be written with HTML tags as well as below github commands 
To edit markdown cell, double click it 
To show, click run or Shift+ENTER (there should not be any whitespace in the begining)

# This is a level 1 heading
## This is a level 2 heading
This is some plain text that forms a paragraph.
Add emphasis via **bold** and __bold__, or *italic* and _italic_.

Paragraphs must be separated by an empty line.

* Sometimes we want to include lists.
 * Which can be indented.

1. Lists can also be numbered.
2. For ordered lists.

[It is possible to include hyperlinks](https://www.example.com)

Inline code uses single backticks: `foo()`, and code blocks use triple backticks:

```
bar()
```

Or can be intented by 4 spaces:

    foo()

And finally, adding images is easy: ![Alt text](https://www.example.com/image.jpg)

Also mathematical equation [check Latex link](http://ctan.math.ca/tex-archive/info/symbols/comprehensive/SYMLIST) 
$$\hat{f}(\xi) = \int_{-\infty}^{+\infty} f(x) \, \exp \left(-2i\pi x \xi \right) dx $$


#Step-9: Sophisticated display 
from IPython.display import HTML, SVG, YouTubeVideo

#Step-10. HTML table dynamically with Python
HTML('''
<table style="border: 2px solid black;">
''' +
     ''.join(['<tr>' +
              ''.join([f'<td>{row},{col}</td>'
                       for col in range(5)]) +
              '</tr>' for row in range(5)]) +
     '''
</table>
''')

#create an SVG graphics dynamically:

SVG('''<svg width="600" height="80">''' +
    ''.join([f'''<circle
              cx="{(30 + 3*i) * (10 - i)}"
              cy="30"
              r="{3. * float(i)}"
              fill="red"
              stroke-width="2"
              stroke="black">
        </circle>''' for i in range(10)]) +
    '''</svg>''')



#display a Youtube video 
YouTubeVideo('VQBZ2MqWBZI')

#details of magic 
%quickref
IPython -- An enhanced Interactive Python - Quick Reference Card
================================================================

obj?, obj??      : Get help, or more help for object (also works as
                   ?obj, ??obj).
?foo.*abc*       : List names in 'foo' containing 'abc' in them.
%magic           : Information about IPython's 'magic' % functions.

Magic functions are prefixed by % or %%, and typically take their arguments
without parentheses, quotes or even commas for convenience.  Line magics take a
single % and cell magics are prefixed with two %%.

Example magic function calls:

%alias d ls -F   : 'd' is now an alias for 'ls -F'
alias d ls -F    : Works if 'alias' not a python name
alist = %alias   : Get list of aliases to 'alist'
cd /usr/share    : Obvious. cd -<tab> to choose from visited dirs.
%cd??            : See help AND source for magic %cd
%timeit x=10     : time the 'x=10' statement with high precision.
%%timeit x=2**100
x**100           : time 'x**100' with a setup of 'x=2**100'; setup code is not
                   counted.  This is an example of a cell magic.

System commands:

!cp a.txt b/     : System command escape, calls os.system()
cp a.txt b/      : after %rehashx, most system commands work without !
cp ${f}.txt $bar : Variable expansion in magics and system commands
files = !ls /usr : Capture system command output
files.s, files.l, files.n: "a b c", ['a','b','c'], 'a\nb\nc'

History:

_i, _ii, _iii    : Previous, next previous, next next previous input
_i4, _ih[2:5]    : Input history line 4, lines 2-4
exec(_i81)       : Execute input history line #81 again
%rep 81          : Edit input history line #81
_, __, ___       : previous, next previous, next next previous output
_dh              : Directory history
_oh              : Output history
%hist            : Command history of current session.
%hist -g foo     : Search command history of (almost) all sessions for 'foo'.
%hist -g         : Command history of (almost) all sessions.
%hist 1/2-8      : Command history containing lines 2-8 of session 1.
%hist 1/ ~2/     : Command history of session 1 and 2 sessions before current.
%hist ~8/1-~6/5  : Command history from line 1 of 8 sessions ago to
                   line 5 of 6 sessions ago.
%edit 0/         : Open editor to execute code with history of current session.

Autocall:

f 1,2            : f(1,2)  # Off by default, enable with %autocall magic.
/f 1,2           : f(1,2) (forced autoparen)
,f 1 2           : f("1","2")
;f 1 2           : f("1 2")

Remember: TAB completion works in many contexts, not just file names
or python names.

The following magic functions are currently available:

%alias:
    Define an alias for a system command.
%alias_magic:
    ::
%autoawait:
    
%autocall:
    Make functions callable without having to type parentheses.
%automagic:
    Make magic functions callable without having to type the initial %.
%autosave:
    Set the autosave interval in the notebook (in seconds).
%bookmark:
    Manage IPython's bookmark system.
%cd:
    Change the current working directory.
%clear:
    Clear the terminal.
%cls:
    Clear the terminal.
%colors:
    Switch color scheme for prompts, info system and exception handlers.
%conda:
    Run the conda package manager within the current kernel.
%config:
    configure IPython
%connect_info:
    Print information for connecting other clients to this kernel
%copy:
    Alias for `!copy`
%ddir:
    Alias for `!dir /ad /on`
%debug:
    ::
%dhist:
    Print your history of visited directories.
%dirs:
    Return the current directory stack.
%doctest_mode:
    Toggle doctest mode on and off.
%echo:
    Alias for `!echo`
%ed:
    Alias for `%edit`.
%edit:
    Bring up an editor and execute the resulting code.
%env:
    Get, set, or list environment variables.
%gui:
    Enable or disable IPython GUI event loop integration.
%hist:
    Alias for `%history`.
%history:
    ::
%killbgscripts:
    Kill all BG processes started by %%script and its family.
%ldir:
    Alias for `!dir /ad /on`
%less:
    Show a file through the pager.
%load:
    Load code into the current frontend.
%load_ext:
    Load an IPython extension by its module name.
%loadpy:
    Alias of `%load`
%logoff:
    Temporarily stop logging.
%logon:
    Restart logging.
%logstart:
    Start logging anywhere in a session.
%logstate:
    Print the status of the logging system.
%logstop:
    Fully stop logging and close log file.
%ls:
    Alias for `!dir /on`
%lsmagic:
    List currently available magic functions.
%macro:
    Define a macro for future re-execution. It accepts ranges of history,
%magic:
    Print information about the magic function system.
%matplotlib:
    ::
%mkdir:
    Alias for `!mkdir`
%more:
    Show a file through the pager.
%notebook:
    ::
%page:
    Pretty print the object and display it through a pager.
%pastebin:
    Upload code to dpaste.com, returning the URL.
%pdb:
    Control the automatic calling of the pdb interactive debugger.
%pdef:
    Print the call signature for any callable object.
%pdoc:
    Print the docstring for an object.
%pfile:
    Print (or run through pager) the file where an object is defined.
%pinfo:
    Provide detailed information about an object.
%pinfo2:
    Provide extra detailed information about an object.
%pip:
    Run the pip package manager within the current kernel.
%popd:
    Change to directory popped off the top of the stack.
%pprint:
    Toggle pretty printing on/off.
%precision:
    Set floating point precision for pretty printing.
%prun:
    Run a statement through the python code profiler.
%psearch:
    Search for object in namespaces by wildcard.
%psource:
    Print (or run through pager) the source code for an object.
%pushd:
    Place the current dir on stack and change directory.
%pwd:
    Return the current working directory path.
%pycat:
    Show a syntax-highlighted file through a pager.
%pylab:
    ::
%qtconsole:
    Open a qtconsole connected to this kernel.
%quickref:
    Show a quick reference sheet 
%recall:
    Repeat a command, or get command to input line for editing.
%rehashx:
    Update the alias table with all executable files in $PATH.
%reload_ext:
    Reload an IPython extension by its module name.
%ren:
    Alias for `!ren`
%rep:
    Alias for `%recall`.
%rerun:
    Re-run previous input
%reset:
    Resets the namespace by removing all names defined by the user, if
%reset_selective:
    Resets the namespace by removing names defined by the user.
%rmdir:
    Alias for `!rmdir`
%run:
    Run the named file inside IPython as a program.
%save:
    Save a set of lines or a macro to a given filename.
%sc:
    Shell capture - run shell command and capture output (DEPRECATED use !).
%set_env:
    Set environment variables.  Assumptions are that either "val" is a
%store:
    Lightweight persistence for python variables.
%sx:
    Shell execute - run shell command and capture output (!! is short-hand).
%system:
    Shell execute - run shell command and capture output (!! is short-hand).
%tb:
    Print the last traceback.
%time:
    Time execution of a Python statement or expression.
%timeit:
    Time execution of a Python statement or expression
%unalias:
    Remove an alias
%unload_ext:
    Unload an IPython extension by its module name.
%who:
    Print all interactive variables, with some minimal formatting.
%who_ls:
    Return a sorted list of all interactive variables.
%whos:
    Like %who, but gives some extra information about each variable.
%xdel:
    Delete a variable, trying to clear it from anywhere that
%xmode:
    Switch modes for the exception handlers.
%%!:
    Shell execute - run shell command and capture output (!! is short-hand).
%%HTML:
    Alias for `%%html`.
%%SVG:
    Alias for `%%svg`.
%%bash:
    %%bash script magic
%%capture:
    ::
%%cmd:
    %%cmd script magic
%%debug:
    ::
%%file:
    Alias for `%%writefile`.
%%html:
    ::
%%javascript:
    Run the cell block of Javascript code
%%js:
    Run the cell block of Javascript code
%%latex:
    Render the cell as a block of LaTeX
%%markdown:
    Render the cell as Markdown text block
%%perl:
    %%perl script magic
%%prun:
    Run a statement through the python code profiler.
%%pypy:
    %%pypy script magic
%%python:
    %%python script magic
%%python2:
    %%python2 script magic
%%python3:
    %%python3 script magic
%%ruby:
    %%ruby script magic
%%script:
    ::
%%sh:
    %%sh script magic
%%svg:
    Render the cell as an SVG literal
%%sx:
    Shell execute - run shell command and capture output (!! is short-hand).
%%system:
    Shell execute - run shell command and capture output (!! is short-hand).
%%time:
    Time execution of a Python statement or expression.
%%timeit:
    Time execution of a Python statement or expression
%%writefile:
    ::

#Notebooks are saved as structured text files (JSON format), 
nbconvert is a tool that can convert notebooks to other formats: raw text, 
Markdown, HTML, LaTeX/PDF

There is a free online service, nbviewer Lets renders notebook into HTML 
check https://nbviewer.jupyter.org/ 
When you give it a URL, it fetches the notebook from that URL, converts it to HTML, 
and serves that HTML to you.
nbviewer only supports launching notebooks stored on GitHub or as Gists on Binder. 
Binder(https://mybinder.org)does support other providers directly on the mybinder.org site.

Locally to get the same functionality (and more)
Check help 
$ jupyter nbconvert 

#To html 
$ jupyter nbconvert first.ipynb

#display this html 
from IPython.display import IFrame
IFrame('first.html', 600, 200)

To save jupyter nootbook as pdf, install pandoc(anaconda brings it) and MikTex 
https://github.com/jgm/pandoc/releases/latest
https://miktex.org/download (check where miktex-tex.exe)
then start jupyter - Note first time while saving, it may download many files, 
hence may fail couple of time, but keep on trying 

$ jupyter nbconvert --to pdf first.ipynb


###Linear algebra using numpy, 

## Rules of Broadcasting 
1. Shape manipulation 
   Convert lower rank array's shape to higher rank shape 
   'by prepending 1'(always prepend)
   For example vector with shape (3,) 
   is converted to rank 2 array as (1,3) or rank 3 as (1,1,3)
   array with (2,3) is converted to rank 3 by (1,2,3)
						
2. Compatibility of arrays 
   Compatible if they have the same size in a dimension, 
   or if one of the arrays has size 1 in that dimension.
   For example , shape (2,3) is compatible with other array 
   with shape (2,3) or (1,3) or (2,1) or (1,1) or (1,) 
   then Broadcasting is possible for other array  

3. Broadcasting  
   If a dimesion is 1 , other dimesions are copied along that dimension 
   when doing operations between arrays 
   eg (1,3) is stacked 2 times to get (2,3) ie np.tile(x13,(2,1))
   (2,1) is stacked three times to get (2,3) ie  np.tile(x21, (1,3)) or np.repeat(x21, 3, axis=1) 
   (1,1) or (1,) can be tiled ie np.tile(x11, (2,3))
   #Example:
   If a.shape is (5,1), b.shape is (1,6), c.shape is (6,) 
   and d.shape is () (ie d scalar), 
   then a, b, c, and d are all broadcastable to dimension (5,6); 
    •a acts like a (5,6) array where a[:,0] is broadcast to the other columns,
    •b acts like a (5,6) array where b[0,:] is broadcast to the other rows,
    •c acts like a (1,6) array and therefore like a (5,6) array where c[:] is broadcast to every row
    •d acts like a (5,6) array where the single value is repeated.

import numpy as np

x = np.array([1,2,3])
y = np.linspace(2.0, 3.0, num=3)
z = np.arange(12).reshape(2,6)
ru = np.random.random((2,6))
rn = np.random.normal(0,1,(6,4)) #mu, sigma 

x.shape 
x.ndim 
z.shape
ru.ndim 
x[0]
z[0,0]
z[:, 0:2]
z[z>2]
z[ (z>2) & (z<4) ] #parentesis must 
z[0,0] = 20
y.shape 
y1 = y[:, None] #becomes 2D 
y1.shape 
np.squeeze(y1)
#broadcasting 
x + y1 # x[None, :] + y1 
#otherwise all 
np.sqrt(z)
x + 2 
x / y 
z * ru 
#matrix mul 
np.mat(z) * np.mat(rn) 
np.mat(rn).I 
rn.T
#sum like axis =0, row varying , axis=N, no collapsed by varying that exists 
np.sum(z, axis=0)  #(2,6) -> (6,) ,row varying, we get col sum -> 1,6 -> 6,
np.sum(z,axis=1)   #(2,6) -> (2,)  , col varying , we get row sum -> 2,1 -> 2, 
#axis=N means that axis collapsing to 1 and then squeeze to remove that dimension 
#In 2D, M,N , axis=1, means (M,1) ie res[0,0] = sum of x[0,:] = -> (M,)
#In (M,N,L,P,Q), axis =2 means L collapsing ie res[0,0,0,0] = sum of x[0,0,:,0,0] -> (M,N,P,Q)
#conversion 
z.astype(str)


#2D with 1D 
#(M,N) with hstack we need (M,1) as we are adding one col with M rows 
#so (M,) -> convert to (M,1) -> hstack needs M compatibility
#(M,N) with vstack we need (1,N) as we are adding one row with N cols 
#so (N,) -> convert to (1,N) -> vstack needs N compatibility
>>> x = np.array([[1,2],[3,4]])
>>> x
array([[1, 2],
       [3, 4]])
>>> y = np.array([5,6])
>>> y
array([5, 6])  #(2,)
>>> y1 = y[:, None]     #(2, 1), None diemsion increases 
>>> y1
array([[5],
       [6]])
>>> y2 = y[None, :]  #(1, 2)
>>> y2
array([[5, 6]])
>>> np.hstack((x,y1))  # 2,2 with 2,1 => 2,3
array([[1, 2, 5],
       [3, 4, 6]])
>>> np.vstack((x,y2))  # 2,2 with 1,2 => (3,2)
array([[1, 2],
       [3, 4],
       [5, 6]])
>>> y1.ravel()
array([5, 6])
>>> y2.ravel()
array([5, 6])

#title 
>>> np.tile(x, (2,2))  #row=2, col=2
array([[1, 2, 3, 1, 2, 3],
       [1, 2, 3, 1, 2, 3]])
>>> np.tile(x, (2,1))  #row=2, col=1
array([[1, 2, 3],
       [1, 2, 3]])
       
#stacking
a = np.array([1,2,3])
b = np.array([2,3,4])
>>> np.c_[a,b]  #columnwise stack
array([[1, 2],
       [2, 3],
       [3, 4]])
#or
>>> np.stack((a,b), axis=1)
array([[1, 2],
       [2, 3],
       [3, 4]])

#rowwise stack
>>> np.stack((a,b), axis=0)
array([[1, 2, 3],
       [2, 3, 4]])
#or
>>> np.vstack((a,b))
array([[1, 2, 3],
       [2, 3, 4]])

#
>>> np.hstack((a,b))
array([1, 2, 3, 2, 3, 4])
       
#Solve the system of equations 3 * x0 + x1 = 9 
#and x0 + 2 * x1 = 8:

a = np.array([[3,1], [1,2]])
b = np.array([9,8])
x = np.linalg.solve(a, b)
>>> x
array([ 2.,  3.])
#Check that the solution is correct:
>>> np.allclose(np.dot(a, x), b)
True     
       

##few Other Operations 
#Execute - 0.1.numpy_operations.py
   
#Scipy 
import numpy as np
from scipy.optimize import minimize

#https://docs.scipy.org/doc/scipy/reference/tutorial/optimize.html
f(x) = SUM( 100*(x_i+1-x_i^2)^2 + (1-x_i)^2 ) from i=1..n-1
ie with 0 based, i = 0..n-2

#code 
def rosen(x):
    return sum(100.0*(x[1:]-x[:-1]**2.0)**2.0 + (1-x[:-1])**2.0)

x0 = np.array([1.3, 0.7, 0.8, 1.9, 1.2])
res = minimize(rosen, x0, method='nelder-mead',
    options={'xtol': 1e-8, 'disp': True})

>>> print(res.x)
[1. 1. 1. 1. 1.]

#Also have many Testing 
H0 = base assumptions, Each test has one H0 
#understanding 
If p value <= .01    -> 'not significant'  #reject H0
If p value <= .05   -> 'marginally significant'
If p value >= .10   -> 'significant'
If p value > .10   -> 'highly significant.'  #accept H0

#Problem 
A soft drink company has invented a new drink, 
and would like to find out if it will be as popular as the existing favorite drink. 
For this purpose, its research department arranges 18 participants for taste testing. 
Each participant tries both drinks in random order before giving his or her opinion. 

It turns out that 5 of the participants like the new drink better, 
and the rest prefer the old one. 
Are two drinks equally popular? 

#H0 : two drinks are equally popular ie p=0.5 
import scipy.stats
> scipy.stats.binom_test(5, 18)              
0.096252441406249986             #>0.05, accept H0
 
#Another 
A car manufacturer claims that no more than 10% of their cars are unsafe.
15 cars are inspected for safety, 3 were found to be unsafe. Test the
manufacturer's claim:

#H0 = < 10% are unsafe 
>>> stats.binom_test(3, n=15, p=0.1, alternative='greater')
0.18406106910639114  #accept H0 
 
#Ho: g1, g2, g3 have same median 
g1 = [10, 14, 14, 18, 20, 22, 24, 25, 31, 31, 32, 39, 43, 43, 48, 49]
g2 = [28, 30, 31, 33, 34, 35, 36, 40, 44, 55, 57, 61, 91, 92, 99]
g3 = [0, 3, 9, 22, 23, 25, 25, 33, 34, 34, 40, 45, 46, 48, 62, 67, 84]
from scipy.stats import median_test
stat, p, med, tbl = median_test(g1, g2, g3)
#The median is
>>> med
34.0
>>> p
0.12609082774093244  #>0.5, don't reject H0 


Gender  Right handed    Left handed     Total
Male        43          9               52
Female      44          4               48 
Total       87          13              100 

#H0: male-female's  right or left handed are independent 
obs = np.array([[43,9], [44,4]])
>>> stats.chi2_contingency(obs)
(1.0724852071005921, 
0.300384770390566,  #>0.05, accept H0 
1, array([[45.24,  6.76],
       [41.76,  6.24]]))
       
 
###Plotting using matplotlib 
#There are three layers to the matplotlib API. 
1.The matplotlib.backend_bases.FigureCanvas 
    is the area  onto which the figure is drawn, 
2.The matplotlib.backend_bases.Renderer 
    is the object  which knows how to draw on the FigureCanvas, 
    The FigureCanvas and Renderer handle all the details of talking 
    to user interface toolkits like wxPython or drawing languages like PostScript®
3.The matplotlib.artist.Artist 
    is the object that knows how to use a renderer to paint onto the canvas. 
    The Artist handles all the high level constructs 
    like representing and laying out the figure, text, and lines. 
    The typical user will spend 95% of their time working with the Artists.  
    There are two types of Artists: primitives and containers. 
    #check class hierarchy https://matplotlib.org/api/artist_api.html  
    The primitives represent the standard graphical objects 
    eg  Line2D, Rectangle, Text, AxesImage, etc.(subclass of Artist)
    and the containers are places to put primitives (Axis, Axes and Figure)(subclass of Artist) 
    
Components 
    The Figure is the final image, and may contain one or more Axes.
    The Axes represents an individual plot (not to be confused with
        Axis, which refers to the x-, y-, or z-axis of a plot).
        
    Parts of a Figure 
    https://matplotlib.org/stable/_images/anatomy.png
    Check in https://matplotlib.org/stable/users/explain/quick_start.html

##With multiple x, y pairs in same plot
import numpy as np
import matplotlib.pyplot as plt

# evenly sampled time at 200ms intervals
t = np.arange(0., 5., 0.2)

# red solid, blue dashed and green triangles
plt.plot(t, t, 'r-', t, t**2, 'b--', t, t**3, 'g^')
plt.show()




#options - Open and Read must 
#Execute - 0.2.plt_options.py




##Various other methods on plt 
#Execute - 0.2.plt_methods.py
#OR 
#Example
import matplotlib.pyplot as plt
#x,y , red and line 
plt.plot([1,2,3,4], [1,2,3,4],'r-', lw=2)                #y values , x is taken as 0,1,2,3
plt.xlabel('x axis label', fontsize=14, color='red')
plt.ylabel('y axis label')
plt.title('My first plot ')
plt.legend(['Straight Line'], loc='best')
plt.grid(True)
plt.yscale('linear') #log, symlog, logit
plt.xscale('linear')
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.axis.html
plt.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
#or 
plt.ylim(0, 4)
plt.xlim(0, 10)

#x, y are graph/data co-ordinates
plt.text(2, 2, r'$\mu=100,\ \sigma=15$')  #Any text  or  '$any LaTex code$'

#put a rectangular box around the text 
plt.text(1,1, "Another text", bbox=dict(facecolor='red', alpha=0.5))

#https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.annotate.html
#text with arrow , note default is data coordinates 
plt.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) 
#xytext=location of text, xy=location for annotation
plt.show()

##Basic Matplotlib details  
#The explicit and the implicit interfaces
there are essentially two ways to use Matplotlib:
    Explicitly create Figures and Axes, and call methods on them (the "object-oriented (OO) style").

    Rely on pyplot to implicitly create and manage the Figures and Axes, 
    and use pyplot functions for plotting.

So one can use the OO-style

x = np.linspace(0, 2, 100)  # Sample data.

# Note that even in the OO-style, we use `.pyplot.figure` to create the Figure.
fig, ax = plt.subplots(figsize=(5, 2.7), layout='constrained')
ax.plot(x, x, label='linear')  # Plot some data on the Axes.
ax.plot(x, x**2, label='quadratic')  # Plot more data on the Axes...
ax.plot(x, x**3, label='cubic')  # ... and some more.
ax.set_xlabel('x label')  # Add an x-label to the Axes.
ax.set_ylabel('y label')  # Add a y-label to the Axes.
ax.set_title("Simple Plot")  # Add a title to the Axes.
ax.legend()  # Add a legend.


or the pyplot-style:

x = np.linspace(0, 2, 100)  # Sample data.

plt.figure(figsize=(5, 2.7), layout='constrained')
plt.plot(x, x, label='linear')  # Plot some data on the (implicit) Axes.
plt.plot(x, x**2, label='quadratic')  # etc.
plt.plot(x, x**3, label='cubic')
plt.xlabel('x label')
plt.ylabel('y label')
plt.title("Simple Plot")
plt.legend()

In addition, there is a third approach, for the case when embedding Matplotlib in a GUI application, 
which completely drops pyplot, even for figure creation. 
https://matplotlib.org/stable/gallery/user_interfaces/index.html#user-interfaces

The following example uses Flask, but other frameworks work similarly:

import base64
from io import BytesIO

from flask import Flask

from matplotlib.figure import Figure

app = Flask(__name__)


@app.route("/")
def hello():
    # Generate the figure **without using pyplot**.
    fig = Figure()
    ax = fig.subplots()
    ax.plot([1, 2])
    # Save it to a temporary buffer.
    buf = BytesIO()
    fig.savefig(buf, format="png")
    # Embed the result in the html output.
    data = base64.b64encode(buf.getbuffer()).decode("ascii")
    return f"<img src='data:image/png;base64,{data}'/>"


#Styling Artists
Most plotting methods have styling options for the Artists, accessible either 
when a plotting method is called, or from a "setter" on the Artist. 

fig, ax = plt.subplots(figsize=(5, 2.7))
x = np.arange(len(data1))
ax.plot(x, np.cumsum(data1), color='blue', linewidth=3, linestyle='--')
l, = ax.plot(x, np.cumsum(data2), color='orange', linewidth=2)
l.set_linestyle(':')

#Colors
Matplotlib has a very flexible array of colors that are accepted for most Artists; 
https://matplotlib.org/stable/users/explain/colors/colors.html#colors-def

Some Artists will take multiple colors. i.e. for a scatter plot, the edge of the markers 
can be different colors from the interior:

fig, ax = plt.subplots(figsize=(5, 2.7))
ax.scatter(data1, data2, s=50, facecolor='C0', edgecolor='k')

#Linewidths, linestyles, and markersizes
Line widths are typically in typographic points (1 pt = 1/72 inch) 
and available for Artists that have stroked lines. 
Similarly, stroked lines can have a linestyle. 

See the linestyles example.
https://matplotlib.org/stable/gallery/lines_bars_and_markers/linestyles.html

Marker size depends on the method being used. plot 
specifies markersize in points, and is generally the "diameter" or width of the marker. 

scatter specifies markersize as approximately proportional to the visual area of the marker. 
There is an array of markerstyles available as string codes (see markers), 
https://matplotlib.org/stable/api/markers_api.html#module-matplotlib.markers
or users can define their own MarkerStyle (see Marker reference):
https://matplotlib.org/stable/gallery/lines_bars_and_markers/marker_reference.html

fig, ax = plt.subplots(figsize=(5, 2.7))
ax.plot(data1, 'o', label='data1')
ax.plot(data2, 'd', label='data2')
ax.plot(data3, 'v', label='data3')
ax.plot(data4, 's', label='data4')
ax.legend()

#Labelling plots - Axes labels and text
set_xlabel, set_ylabel, and set_title are used to add text in the indicated locations 
Text can also be directly added to plots using text:

mu, sigma = 115, 15
x = mu + sigma * np.random.randn(10000)
fig, ax = plt.subplots(figsize=(5, 2.7), layout='constrained')
# the histogram of the data
n, bins, patches = ax.hist(x, 50, density=True, facecolor='C0', alpha=0.75)

ax.set_xlabel('Length [cm]')
ax.set_ylabel('Probability')
ax.set_title('Aardvark lengths\n (not really)')
ax.text(75, .025, r'$\mu=115,\ \sigma=15$')
ax.axis([55, 175, 0, 0.03])
ax.grid(True)

All of the text functions return a matplotlib.text.Text instance. 
Just as with lines above, you can customize the properties by passing keyword arguments 
into the text functions:

t = ax.set_xlabel('my data', fontsize=14, color='red')

These properties are covered in more detail in Text properties and layout.
https://matplotlib.org/stable/users/explain/text/text_props.html#text-props

#Using mathematical expressions in text
Matplotlib accepts TeX equation expressions in any text expression. 

ax.set_title(r'$\sigma_i=15$')

where the r preceding the title string signifies that the string is a raw string 
Matplotlib has a built-in TeX expression parser and layout engine, and ships its own math fonts – 
https://matplotlib.org/stable/users/explain/text/mathtext.html#mathtext

You can also use LaTeX directly to format your text and incorporate the output directly 
into your display figures or saved postscript – see Text rendering with LaTeX.
https://matplotlib.org/stable/users/explain/text/usetex.html#usetex

#Annotations
We can also annotate points on a plot, often by connecting an arrow pointing to xy, 
to a piece of text at xytext:

fig, ax = plt.subplots(figsize=(5, 2.7))

t = np.arange(0.0, 5.0, 0.01)
s = np.cos(2 * np.pi * t)
line, = ax.plot(t, s, lw=2)

ax.annotate('local max', xy=(2, 1), xytext=(3, 1.5),
            arrowprops=dict(facecolor='black', shrink=0.05))

ax.set_ylim(-2, 2)

In this basic example, both xy and xytext are in data coordinates. 
There are a variety of other coordinate systems one can choose
https://matplotlib.org/stable/users/explain/text/annotations.html#annotations-tutorial
https://matplotlib.org/stable/users/explain/text/annotations.html#plotting-guide-annotation
https://matplotlib.org/stable/gallery/text_labels_and_annotations/annotation_demo.html


#Legends
Often we want to identify lines or markers with a Axes.legend:
https://matplotlib.org/stable/users/explain/axes/legend_guide.html#legend-guide

fig, ax = plt.subplots(figsize=(5, 2.7))
ax.plot(np.arange(len(data1)), data1, label='data1')
ax.plot(np.arange(len(data2)), data2, label='data2')
ax.plot(np.arange(len(data3)), data3, 'd', label='data3')
ax.legend()

#Axis scales and ticks
Each Axes has two (or three) Axis objects representing the x- and y-axis. 
These control the scale of the Axis, the tick locators and the tick formatters. 
Additional Axes can be attached to display further Axis objects.

#Scales
In addition to the linear scale, Matplotlib supplies non-linear scales, such as a log-scale. 
Since log-scales are used so much there are also direct methods like loglog, semilogx, and semilogy. 

There are a number of scales (see Scales for other examples). 
https://matplotlib.org/stable/gallery/scales/scales.html

Here we set the scale manually:

fig, axs = plt.subplots(1, 2, figsize=(5, 2.7), layout='constrained')
xdata = np.arange(len(data1))  # make an ordinal for this
data = 10**data1
axs[0].plot(xdata, data)

axs[1].set_yscale('log')
axs[1].plot(xdata, data)

The scale sets the mapping from data values to spacing along the Axis. 
This happens in both directions, and gets combined into a transform, which is the way 
that Matplotlib maps from data coordinates to Axes, Figure, or screen coordinates. 
See Transformations Tutorial.
https://matplotlib.org/stable/users/explain/artists/transforms_tutorial.html#transforms-tutorial

#Tick locators and formatters
Each Axis has a tick locator and formatter that choose where along the Axis objects to put tick marks. 

A simple interface to this is set_xticks:

fig, axs = plt.subplots(2, 1, layout='constrained')
axs[0].plot(xdata, data1)
axs[0].set_title('Automatic ticks')

axs[1].plot(xdata, data1)
axs[1].set_xticks(np.arange(0, 100, 30), ['zero', '30', 'sixty', '90'])
axs[1].set_yticks([-1.5, 0, 1.5])  # note that we don't need to specify labels
axs[1].set_title('Manual ticks')

#Automatic ticks, Manual ticks
Different scales can have different locators and formatters; for instance the log-scale 
above uses LogLocator and LogFormatter. 

See Tick locators and Tick formatters for other formatters and locators and information for writing your own.
https://matplotlib.org/stable/gallery/ticks/tick-locators.html
https://matplotlib.org/stable/gallery/ticks/tick-formatters.html


#Plotting dates and strings
Matplotlib can handle plotting arrays of dates and arrays of strings, 
as well as floating point numbers. 

These get special locators and formatters as appropriate. For dates:

from matplotlib.dates import ConciseDateFormatter

fig, ax = plt.subplots(figsize=(5, 2.7), layout='constrained')
dates = np.arange(np.datetime64('2021-11-15'), np.datetime64('2021-12-25'),
                  np.timedelta64(1, 'h'))
data = np.cumsum(np.random.randn(len(dates)))
ax.plot(dates, data)
ax.xaxis.set_major_formatter(ConciseDateFormatter(ax.xaxis.get_major_locator()))


For more information see the date examples (e.g. Date tick labels)
https://matplotlib.org/stable/gallery/text_labels_and_annotations/date.html


For strings, we get categorical plotting (see: Plotting categorical variables).
https://matplotlib.org/stable/gallery/lines_bars_and_markers/categorical_variables.html

fig, ax = plt.subplots(figsize=(5, 2.7), layout='constrained')
categories = ['turnips', 'rutabaga', 'cucumber', 'pumpkins']

ax.bar(categories, np.random.rand(len(categories)))

One caveat about categorical plotting is that some methods of parsing text files 
return a list of strings, even if the strings all represent numbers or dates. 

If you pass 1000 strings, Matplotlib will think you meant 1000 categories 
and will add 1000 ticks to your plot!



## Working with multiple figures and axes
#Plots may contain many Figure, 
#each figure is one display window
#each Figure may contain many Axes
#Figure contains set/get of figure related attributes 
#eg get_figheight(),get_figwidth()
#Axes contains plot() and set/get of xlabel, ylabel etc


#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplots.html 
##Option-1 
#note subplots(..) returns (figure,axes)
#where axes is numpy.ndarray, hence access like axes[0,0], axes[0,1],... for complex subplots 
#for simple , can destructure immediately

#sharex=True, means only one X ticks value printing , similarly for sharey
#figsize : (float, float), optional, default: None
#width, height in inches. 
#If not provided, defaults to rcParams["figure.figsize"] = [6.4, 4.8].

figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, sharex=False, sharey=True, figsize=(15,15))

import matplotlib.pyplot as plt
import numpy as np

# Create some fake data.
x1 = np.linspace(0.0, 5.0)
y1 = np.cos(2 * np.pi * x1) * np.exp(-x1)
x2 = np.linspace(0.0, 2.0)
y2 = np.cos(2 * np.pi * x2)

subplots() is the recommended method to generate simple subplot arrangements:

fig, (ax1, ax2) = plt.subplots(2, 1)
fig.suptitle('A tale of 2 subplots')

ax1.plot(x1, y1, 'o-')
ax1.set_ylabel('Damped oscillation')

ax2.plot(x2, y2, '.-')
ax2.set_xlabel('time (s)')
ax2.set_ylabel('Undamped')

plt.show()

#Another example 
fig = plt.figure(layout="constrained")
ax_array = fig.subplots(2, 2, squeeze=False)

ax_array[0, 0].bar(["a", "b", "c"], [5, 7, 9])
ax_array[0, 1].plot([1, 2, 3])
ax_array[1, 0].hist(hist_data, bins="auto")
ax_array[1, 1].imshow([[1, 2], [2, 1]])

Constrained layout automatically adjusts subplots 
so that decorations like tick labels, legends, and colorbars do not overlap, 
while still preserving the logical layout requested by the user.

Constrained layout is similar to Tight layout, but is substantially more flexible
Note that layout managers can measurably slow down figure display.
    'constrained': The constrained layout solver adjusts Axes sizes to avoid overlapping Axes 
    decorations. Can handle complex plot layouts and colorbars, and is thus recommended.

    'compressed': uses the same algorithm as 'constrained', but removes extra space between 
    fixed-aspect-ratio Axes. Best for simple grids of Axes.

    'tight': Use the tight layout mechanism. This is a relatively simple algorithm 
    that adjusts the subplot parameters so that decorations do not overlap. 

    'none': Do not use a layout engine.

#OR 
import matplotlib.pyplot as plt
import numpy as np

t = np.arange(0.0, 2.0, 0.01)
s1 = np.sin(2*np.pi*t)
s2 = np.sin(4*np.pi*t)

Create figure 1

plt.figure(1)
plt.subplot(211)
plt.plot(t, s1)
plt.subplot(212)
plt.plot(t, 2*s1)

#Example 
import matplotlib.pyplot as plt
import numpy as np

# Fixing random state for reproducibility
np.random.seed(19680801)

plt.subplot(211)
plt.imshow(np.random.random((100, 100)))
plt.subplot(212)
plt.imshow(np.random.random((100, 100)))

plt.subplots_adjust(bottom=0.1, right=0.8, top=0.9)
cax = plt.axes((0.85, 0.1, 0.075, 0.8))
plt.colorbar(cax=cax)

plt.show()

matplotlib.pyplot.subplots_adjust(left=None, bottom=None, 
  right=None, top=None, wspace=None, hspace=None)
    Adjust the subplot layout parameters.
    Unset parameters are left unmodified; initial values are given by rcParams["figure.subplot.[name]"].
    left
        The position of the left edge of the subplots, as a fraction of the figure width.
    right
        The position of the right edge of the subplots, as a fraction of the figure width.
    bottom
        The position of the bottom edge of the subplots, as a fraction of the figure height.
    top
        The position of the top edge of the subplots, as a fraction of the figure height.
    wspace
        The width of the padding between subplots, as a fraction of the average Axes width.
    hspace
        The height of the padding between subplots, as a fraction of the average Axes height.

matplotlib.pyplot.tight_layout(*, pad=1.08, h_pad=None, w_pad=None, rect=None)
    Adjust the padding between and around subplots.

#Others 
#Execute - 0.2.plt_multi.py

#mosaic 
matplotlib.pyplot.subplot_mosaic(mosaic, *, sharex=False, sharey=False, width_ratios=None, 
height_ratios=None, empty_sentinel='.', subplot_kw=None, 
gridspec_kw=None, per_subplot_kw=None, **fig_kw)

mosaic
    list of list of {hashable or nested} or str
    A visual layout of how you want your Axes to be arranged labeled as strings. For example
    x = [['A panel', 'A panel', 'edge'],
         ['C panel', '.',       'edge']]
    If input is a str, then it must be of the form
    '''
    AAE
    C.E
    '''

fig = plt.figure(layout="constrained")
ax_dict = fig.subplot_mosaic(
    [
        ["bar", "plot"],
        ["hist", "image"],
    ],
)
ax_dict["bar"].bar(["a", "b", "c"], [5, 7, 9])
ax_dict["plot"].plot([1, 2, 3])
ax_dict["hist"].hist(hist_data)
ax_dict["image"].imshow([[1, 2], [2, 1]])
identify_axes(ax_dict)

mosaic = """
    AB
    CD
    """ 
now labeled with {"A", "B", "C", "D"} rather than {"bar", "plot", "hist", "image"}).

mosaic = "AB;CD"
will give you the same composition, 
where the ";" is used as the row separator instead of newline.

axd = plt.figure(layout="constrained").subplot_mosaic(
    """
    ABD
    CCD
    """
)
axd = plt.figure(layout="constrained").subplot_mosaic(
    """
    A.C
    BBB
    .D.
    """
)
axd = plt.figure(layout="constrained").subplot_mosaic(
    """
    .a.
    bAc
    .d.
    """,
    # set the height ratios between the rows
    height_ratios=[1, 3.5, 1],
    # set the width ratios between the columns
    width_ratios=[1, 3.5, 1],
)

mosaic = """AA
            BC"""
fig = plt.figure()
axd = fig.subplot_mosaic(
    mosaic,
    gridspec_kw={
        "bottom": 0.25,
        "top": 0.95,
        "left": 0.1,
        "right": 0.5,
        "wspace": 0.5,
        "hspace": 0.5,
    },
)
axd = fig.subplot_mosaic(
    mosaic,
    gridspec_kw={
        "bottom": 0.05,
        "top": 0.75,
        "left": 0.6,
        "right": 0.95,
        "wspace": 0.5,
        "hspace": 0.5,
    },
)


##Advanced concepts - Coordinate system and subfigure 
https://matplotlib.org/stable/users/explain/artists/transforms_tutorial.html
In the "Transformation Object" column, ax is a Axes instance, 
fig is a Figure instance, 
and subfigure is a SubFigure instance.


data
	The coordinate system of the data in the Axes.
	Transformation object from system to display : ax.transData
axes
	The coordinate system of the Axes; (0, 0) is bottom left of the Axes, 
    and (1, 1) is top right of the Axes.
	Transformation object from system to display: ax.transAxes

subfigure
	The coordinate system of the SubFigure; (0, 0) is bottom left of the subfigure, 
    and (1, 1) is top right of the subfigure. If a figure has no subfigures, 
    this is the same as transFigure.
	Transformation object from system to display : subfigure.transSubfigure

figure
	The coordinate system of the Figure; (0, 0) is bottom left of the figure, 
    and (1, 1) is top right of the figure.
	Transformation object from system to display: fig.transFigure

figure-inches
	The coordinate system of the Figure in inches; (0, 0) is bottom left of the figure, 
    and (width, height) is the top right of the figure in inches.
	Transformation object from system to display: fig.dpi_scale_trans

xaxis, yaxis
	Blended coordinate systems, using data coordinates on one direction 
    and axes coordinates on the other.
	Transformation object from system to display: ax.get_xaxis_transform(), 
    ax.get_yaxis_transform()

display
	The native coordinate system of the output ; (0, 0) is the bottom left of the window, 
    and (width, height) is top right of the output in "display units".
    The exact interpretation of the units depends on the back end. 
    For example it is pixels for Agg and points for svg/pdf.
	Transformation object from system to display: None, or IdentityTransform

Below is in data 
import matplotlib.pyplot as plt
import numpy as np

import matplotlib.patches as mpatches

x = np.arange(0, 10, 0.005)
y = np.exp(-x/2.) * np.sin(2*np.pi*x)

fig, ax = plt.subplots()
ax.plot(x, y)
ax.set_xlim(0, 10)
ax.set_ylim(-1, 1)

plt.show()

Below in Axes coordinates , text is in default data 
fig = plt.figure()
for i, label in enumerate(('A', 'B', 'C', 'D')):
    ax = fig.add_subplot(2, 2, i+1)
    ax.text(0.05, 0.95, label, transform=ax.transAxes,
            fontsize=16, fontweight='bold', va='top')

plt.show()

Below in physical orordinates 
fig, ax = plt.subplots(figsize=(5, 4))
x, y = 10*np.random.rand(2, 1000)
ax.plot(x, y*10., 'go', alpha=0.2)  # plot some data in data coordinates
# add a circle in fixed-coordinates
circ = mpatches.Circle((2.5, 2), 1.0, transform=fig.dpi_scale_trans,
                       facecolor='blue', alpha=0.75)
ax.add_patch(circ)
plt.show()
If we change the figure size, the circle does not change its absolute position and is cropped.
fig, ax = plt.subplots(figsize=(7, 2))

Blended transform 
In fact these blended lines and spans are so useful, there is builtin function 
(see axhline(), axvline(), axhspan(), axvspan()) 
Axes.axhline(y=0, xmin=0, xmax=1, **kwargs) # y in data coordinates, xmin/max in axes coordinate 
Axes.axvline(x=0, ymin=0, ymax=1, **kwargs) # x in data coordinates
Axes.axhspan(ymin, ymax, xmin=0, xmax=1, **kwargs) #ymin/max in data 
Axes.axvspan(xmin, xmax, ymin=0, ymax=1, **kwargs)  #xmin/max in data 

for example to create a horizontal span which highlights some region of the y-data 
but spans across the x-axis regardless of the data limits, pan or zoom level, etc. 

#eg  horizontal span 
import matplotlib.transforms as transforms

fig, ax = plt.subplots()
x = np.random.randn(1000)

ax.hist(x, 30)
ax.set_title(r'$\sigma=1 \/ \dots \/ \sigma=2$', fontsize=16)

# the x coords of this transformation are data, and the y coord are axes
#blended_transform_factory(x_transform, y_transform)
trans = transforms.blended_transform_factory(
    ax.transData, ax.transAxes)
#OR 
trans = ax.get_xaxis_transform()

# highlight the 1..2 stddev region with a span.
# We want x to be in data coordinates and y to span from 0..1 in axes coords.
#Rectangle(xy, width, height, *, angle=0.0, rotation_point='xy', **kwargs)
#from xy[0] to xy[0] + width in x-direction and from xy[1] to xy[1] + height in y-direction.
rect = mpatches.Rectangle((1, 0), width=1, height=1, transform=trans,
                          color='yellow', alpha=0.5)
ax.add_patch(rect)

plt.show()



#SubFigure 
Sometimes it is desirable to have a figure with two different layouts in it. 
This can be achieved with nested gridspecs, but having a virtual figure 
with its own artists is helpful, 
so Matplotlib also has "subfigures", accessed by calling matplotlib.figure.Figure.add_subfigure 
in a way that is analogous to matplotlib.figure.Figure.add_subplot, 
or matplotlib.figure.Figure.subfigures to make an array of subfigures. 
Note that subfigures can also have their own child subfigures.

import matplotlib.pyplot as plt
import numpy as np


def example_plot(ax, fontsize=12, hide_labels=False):
    #Create a pseudocolor plot with a non-regular rectangular grid.
    #https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.pcolormesh.html
    pc = ax.pcolormesh(np.random.randn(30, 30), vmin=-2.5, vmax=2.5)
    if not hide_labels:
        ax.set_xlabel('x-label', fontsize=fontsize)
        ax.set_ylabel('y-label', fontsize=fontsize)
        ax.set_title('Title', fontsize=fontsize)
    return pc

np.random.seed(19680808)
# gridspec inside gridspec
fig = plt.figure(layout='constrained', figsize=(10, 4))
subfigs = fig.subfigures(1, 2, wspace=0.07)

axsLeft = subfigs[0].subplots(1, 2, sharey=True)
subfigs[0].set_facecolor('0.75')
Color can be 
String representation of float value in closed interval [0, 1] for grayscale values.
	'0' as black   '1' as white   '0.8' as light gray

for ax in axsLeft:
    pc = example_plot(ax)
subfigs[0].suptitle('Left plots', fontsize='x-large')
#Add a colorbar to a plot.
#https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.colorbar.html
subfigs[0].colorbar(pc, shrink=0.6, ax=axsLeft, location='bottom')

axsRight = subfigs[1].subplots(3, 1, sharex=True)
for nn, ax in enumerate(axsRight):
    pc = example_plot(ax, hide_labels=True)
    if nn == 2:
        ax.set_xlabel('xlabel')
    if nn == 1:
        ax.set_ylabel('ylabel')

subfigs[1].set_facecolor('0.85')
subfigs[1].colorbar(pc, shrink=0.6, ax=axsRight)
subfigs[1].suptitle('Right plots', fontsize='x-large')

fig.suptitle('Figure suptitle', fontsize='xx-large')

plt.show()




##Saving to a file
#output format is deduced from the extension of the filename
plt.savefig(file_name)

##More Usage of Matplotlib 

import matplotlib.pyplot as plt
import numpy as np

data = {'Barton LLC': 109438.50,
        'Frami, Hills and Schmidt': 103569.59,
        'Fritsch, Russel and Anderson': 112214.71,
        'Jerde-Hilpert': 112591.43,
        'Keeling LLC': 100934.30,
        'Koepp Ltd': 103660.54,
        'Kulas Inc': 137351.96,
        'Trantow-Barrows': 123381.38,
        'White-Trantow': 135841.99,
        'Will LLC': 104437.60}
group_data = list(data.values())
group_names = list(data.keys())
group_mean = np.mean(group_data)

fig, ax = plt.subplots()
ax.barh(group_names, group_data)

#Controlling the style
There are many styles available in Matplotlib in order to let you tailor your visualization 
to your needs.

print(plt.style.available)
['Solarize_Light2', '_classic_test_patch', '_mpl-gallery', '_mpl-gallery-nogrid',
 'bmh', 'classic', 'dark_background', 'fast', 'fivethirtyeight', 'ggplot', 
 'grayscale', 'seaborn-v0_8', 'seaborn-v0_8-bright', 'seaborn-v0_8-colorblind', 
 'seaborn-v0_8-dark', 'seaborn-v0_8-dark-palette', 'seaborn-v0_8-darkgrid', 
 'seaborn-v0_8-deep', 'seaborn-v0_8-muted', 'seaborn-v0_8-notebook', 
 'seaborn-v0_8-paper', 'seaborn-v0_8-pastel', 'seaborn-v0_8-poster', 
 'seaborn-v0_8-talk', 'seaborn-v0_8-ticks', 'seaborn-v0_8-white', 
 'seaborn-v0_8-whitegrid', 'tableau-colorblind10']

You can activate a style with the following:

plt.style.use('fivethirtyeight')
fig, ax = plt.subplots()
ax.barh(group_names, group_data)

The style controls many things, such as color, linewidths, backgrounds, etc.

First let's rotate the labels on the x-axis so that they show up more clearly. 
We can gain access to these labels with the axes.Axes.get_xticklabels() method:

labels = ax.get_xticklabels()

pyplot.setp()  will take a list (or many lists) of Matplotlib objects, 
and attempt to set some style element of each one.

plt.setp(labels, rotation=45, horizontalalignment='right')

matplotlib.pyplot.setp(obj, *args, **kwargs)
https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.setp.html
    obj: Artist or list of Artist
    x = np.arange(0, 1, 0.01)
    lines = plt.plot(x, sin(2*pi*x), x, sin(4*pi*x))
    plt.setp(lines, linewidth=2, color='r')
    #to get 
    setp(line, 'linestyle')
    linestyle: {'-', '--', '-.', ':', '', (offset, on-off-seq), ...}
    #or get all 
    setp(line)
It looks like this cut off some of the labels on the bottom. 
We can tell Matplotlib to automatically make room for elements in the figures that we create. 
To do this we set the autolayout value of our rcParams. 

Also use Axes.set(many args...) to set properties of Axes 

plt.rcParams.update({'figure.autolayout': True})


fig, ax = plt.subplots(figsize=(8, 4)) #Width, height in inches.
ax.barh(group_names, group_data)
labels = ax.get_xticklabels()
plt.setp(labels, rotation=45, horizontalalignment='right')
#https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.set.html
ax.set(xlim=[-10000, 140000], xlabel='Total Revenue', ylabel='Company',
       title='Company Revenue')
       
def currency(x, pos):
    """The two arguments are the value and tick position"""
    if x >= 1e6:
        s = f'${x*1e-6:1.1f}M'
    else:
        s = f'${x*1e-3:1.0f}K'
    return s
    
ax.xaxis.set_major_formatter(currency)


#Combining multiple visualizations
It is possible to draw multiple plot elements on the same instance of axes.Axes. 
To do this we simply need to call another one of the plot methods on that Axes object.

fig, ax = plt.subplots(figsize=(8, 8))
ax.barh(group_names, group_data)
labels = ax.get_xticklabels()
plt.setp(labels, rotation=45, horizontalalignment='right')

# Add a vertical line, here we set the style in the function call
ax.axvline(group_mean, ls='--', color='r')

# Annotate new companies
for group in [3, 5, 8]:
    #x, y in data coordinates
    ax.text(145000, group, "New Company", fontsize=10,  verticalalignment="center")

# Now we move our title up since it's getting a little cramped
#1.0 is the top
ax.title.set(y=1.05)

#xlim in data coordinates
ax.set(xlim=[-10000, 140000], xlabel='Total Revenue', ylabel='Company',
       title='Company Revenue')
ax.xaxis.set_major_formatter(currency)
#data coordinates
ax.set_xticks([0, 25e3, 50e3, 75e3, 100e3, 125e3])
#subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
#left,right - as a fraction of the figure width.
#bottom, top - as a fraction of the figure height 
#wspace - fraction of average Axes width , similarly for hspace 
fig.subplots_adjust(right=.1)



#Saving our plot
There are many file formats we can save to in Matplotlib. 

To see a list of available options, use:

print(fig.canvas.get_supported_filetypes())
{'eps': 'Encapsulated Postscript', 'jpg': 'Joint Photographic Experts Group', 
'jpeg': 'Joint Photographic Experts Group', 'pdf': 'Portable Document Format', 
'pgf': 'PGF code for LaTeX', 'png': 'Portable Network Graphics', 
'ps': 'Postscript', 'raw': 'Raw RGBA bitmap', 'rgba': 'Raw RGBA bitmap', 
'svg': 'Scalable Vector Graphics', 'svgz': 'Scalable Vector Graphics',
 'tif': 'Tagged Image File Format', 'tiff': 'Tagged Image File Format', 
 'webp': 'WebP Image Format'}

We can then use the figure.Figure.savefig() in order to save the figure to disk. 

Note that there are several useful flags we show below:
    transparent=True makes the background of the saved figure transparent if the format supports it.

    dpi=80 controls the resolution (dots per square inch) of the output.

    bbox_inches="tight" fits the bounds of the figure to our plot.

# Uncomment this line to save the figure.
fig.savefig('sales.png', transparent=False, dpi=80, bbox_inches="tight")
#Then display 
plt.show()


##Autoscaling
Matplotlib can set them automatically based on the data already on the axes. 
OR Use manually - eg  ax.set_xlim(xmin, xmax))  

#Example 
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

x = np.linspace(-2 * np.pi, 2 * np.pi, 100)
y = np.sinc(x)

fig, ax = plt.subplots()
ax.plot(x, y)

#default margins 
print(ax.margins())
#(0.05, 0.05)

#margins can be in range of (-0.5, Inf)
#where negative margins clips data. Using a single number for margins affects both axes
#eg increase 
ax.margins(0.2, 0.2)

#By default, the limits are recalculated every time you add a new curve to the plot:
fig, ax = plt.subplots(ncols=2, figsize=(12, 8))
ax[0].plot(x, y)
ax[0].set_title("Single curve")
ax[1].plot(x, y)
ax[1].plot(x * 2.0, y)
ax[1].set_title("Two curves")

#To disable autoscaling is to manually set the axis limit
#eg To see only a part of the data in greater detail. 
#Setting the xlim persists even if we add more curves to the data. 
#To recalculate the new limits calling Axes.autoscale will toggle the functionality manually.

fig, ax = plt.subplots(ncols=2, figsize=(12, 8))
ax[0].plot(x, y)
ax[0].set_xlim(left=-1, right=1)
ax[0].plot(x + np.pi * 0.5, y)
ax[0].set_title("set_xlim(left=-1, right=1)\n")
ax[1].plot(x, y)
ax[1].set_xlim(left=-1, right=1)
ax[1].plot(x + np.pi * 0.5, y)
ax[1].autoscale()
ax[1].set_title("set_xlim(left=-1, right=1)\nautoscale()")

print(ax[0].get_autoscale_on())  # False means disabled
print(ax[1].get_autoscale_on())  # True means enabled -> recalculated

#Arguments of the autoscale function give us precise control over the process of autoscaling. 
#Axes.autoscale(self, enable=True, axis='both', tight=None)
#enable:True (default) turns autoscaling on, 
#False turns it off. None leaves the autoscaling state unchanged.
#The argument tight sets the margin of the selected axis to zero. 
#To preserve settings of either enable or tight you can set the opposite one to None, 
#that way it should not be modified. 
#However, setting enable to None and tight to True affects both axes regardless of the axis argument.

fig, ax = plt.subplots()
ax.plot(x, y)
ax.margins(0.2, 0.2)
ax.autoscale(enable=None, axis="x", tight=True) #axis x autoscale is unmodified 

print(ax.margins())
#(0, 0)
    
##Few other plotting command than plot 
#Execute - 0.2.plt_other_plot.py

##ColorMaps 
#Colourmap - Setting a range of colors for various items 
#select by 
#https://matplotlib.org/gallery/color/colormap_reference.html
from matplotlib import cm 
cmap=plt.get_cmap('Dark2')  #string_name 
>>> cmap.colors
((0.10588235294117647, 0.6196078431372549, 0.4666666666666667), ...)
#or 
cmap=cm.Dark2
#see all 
dir(cm)

##HandsON - understanding polyfit 
x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])

z = np.polyfit(x, y, 3)  #Polynomial coefficients, highest power first,0th index 
>>> z
array([ 0.08703704, -0.81349206,  1.69312169, -0.03968254])

>>> p = np.poly1d(z) #highest power first,0th index 
>>> print(p)
         3          2
0.08704 x - 0.8135 x + 1.693 x - 0.03968

>>> p(0.5)   #evaluate 
0.6143849206349179

>>> p.r #roots
array([6.24151464, 3.08128307, 0.02370685])
#+,-,*,**,/ are overloaded , np.methods() can be called 

>> p**2
poly1d([ 7.57544582e-03, -1.41607878e-01,  9.56497928e-01, -2.76158982e+00,
       2.93122393e+00, -1.34374738e-01,  1.57470396e-03])
>> np.sin(p)
array([ 0.08692719, -0.72669053,  0.99252758, -0.03967213])


#High-order polynomials may oscillate wildly:
p30 = np.poly1d(np.polyfit(x, y, 30))
>>> p30(4)
-0.80000000000000204

##HandsON - Create equal spaced 100 points between -2 and 6 and 
#then plot above p and p30 graphs for those x points 

#plot 
import matplotlib.pyplot as plt
xp = np.linspace(-2, 6, 100)
_ = plt.plot(x, y, '.', xp, p(xp), '-', xp, p30(xp), '--')
plt.ylim(-2,2)
plt.show()





##3D plots 
#3D plots require x,y (create from meshgrid) and Z 
#Z points are mapped to color  from ColorMap 


from matplotlib import cm 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np

X = np.arange(-5, 5, 0.25)
Y = np.arange(-5, 5, 0.25)
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)



fig = plt.figure(figsize=(10,6))
ax = fig.add_subplot(111, projection='3d')  #requires Axes3D
#rstride 	Array row stride (step size)
#cstride 	Array column stride (step size)
surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, 
    linewidth=0, antialiased=False)
ax.set_zlim(-1.01, 1.01)
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=10)

fig.show()

#understanding pcolormesh, contour, imshow and contourf 
#Execute 0.2.plt_3dr_plot_understanding.py

#Others 
#Execute - 0.2.plt_3dr_plot.py




###Pandas and CSV  
import pandas as pd 
import matplotlib.pyplot as plt
path = r"data\iris.csv"
iris = pd.read_csv(path)
iris.head()
iris.columns
len(iris.columns)
len(iris.index)
iris.dtypes
iris['SepalRatio'] = iris.SepalLength/iris['SepalWidth']
iris['PetalRatio'] = iris.PetalLength/iris.PetalWidth
iris['dummy'] = iris.SepalRatio * 2 + iris.PetalRatio
iris[['SepalLength', 'PetalLength']]

iris.SepalRatio.mean()
iris.loc[iris.SepalRatio > iris.SepalRatio.mean(), :]

iris.iloc[100:150, ['SepalLength', 'PetalLength']]

#Return new DF 
>>> (iris.assign(sepal_ratio = iris['SepalWidth'] / iris['SepalLength']).head())
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200


#Or use function of one argument which is the  DF
>>> iris.assign(sepal_ratio = lambda df: (df['SepalWidth'] /df['SepalLength'])).head()
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200



#Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:

(iris.query('SepalLength > 5').assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength,            
                     PetalRatio = lambda df: df.PetalWidth / df.PetalLength)   
                .plot(kind='scatter', x='SepalRatio', y='PetalRatio'))
plt.show()

#Clearly two clusters 
iris_m = iris.assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength, 
    PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')

##Quick K-Means - Find those two clusters 
from sklearn.cluster import KMeans
numpy_features = iris_m[ ['SepalRatio','PetalRatio' ]].values
kmeans = KMeans(n_clusters=2, random_state=0).fit(numpy_features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
       
#unique Name 
iris.Name.unique()
#many str methods 
iris.Name.str.lower()
iris.Name.str.split("-") #gives a column with list of strings 
df = iris.Name.str.split("-", expand=True) #each list element becomes one column 
df.columns = ['part1', 'par2']
#merge 
pd.concat([iris, df], axis=1)  #columnwise stack 

#transforming- use apply or transform as lambda returns same size 
iris.Name.str.split("-", expand=True).apply(lambda s: np.char.lower(s.to_list()))
#T means transpose 
(iris.Name.str.split("-", 
                expand=True)[[0]].T.transform(
                lambda s: np.char.lower(s.to_list()))
                .shape
            )

>>> np.unique(iris.Name.apply(lambda x: un.tolist().index(x)))
array([0, 1, 2], dtype=int64)
#apply for Series, fn takes each element, 
#for DF, fn takes each col if axis=0 else takes each row if axis=1
iris["target"] = iris.Name.apply(lambda x: un.tolist().index(x))

#Get the first five rows of a column by name
iris['SepalLength'][:5]                     #Series
iris[ [ 'SepalLength', 'SepalWidth'] ][:5]  #DF 


#Create categorical ranges for numerical data. 14 is number of bins
sl_bin = pd.cut(iris['SepalLength'], 14)
sl_bin[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(sl_bin)
sl_bin.value_counts()

#Access through .cat 
iris["category"] = sl_bin
iris.category.cat.categories
#to get index of each bin 
iris.category.cat.rename_categories(range(14))

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
iris.ix[0,0:6]

#Order the data by specified column
iris['SepalLength'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = iris.sort_values(by=['SepalLength', 'PetalLength'])  #DF
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
iris['PetalLength'].value_counts()

#to obtain the datatype 
iris.dtypes

#Get the unique values for a column by name.
iris['Name'].unique()

#Get a count of the unique values of a column
len(iris['Name'].unique())

#Index into a column and get the first four rows
iris.ix[0:3,'Name']

#Obtain True/False  values which could be used inside iloc, loc etc 
iris.ix[:,'Name'] == 'Iris-setosa'
#Can get any columns , use  | , &, ~ for boolean conjunction, disjunction and inverse 
iris.loc[iris['Name'] == 'Iris-setosa', 'SepalLength']  #Series
iris.ix[iris['Name'] == 'Iris-setosa', 0] #note .iloc with boolean not available 
iris.loc[iris['Name'] == 'Iris-setosa', ['SepalLength','PetalLength']] #DF

#Query the data
qry1 = iris.query('Name == "Iris-setosa"')  #returns DF of original only where cond is valid 
qry1.head(10)

#Check a boolean condition
(iris.ix[:,'SepalLength'] > 4.3).any()


#Return descriptive statistics of the dataset- mean, std etc is calculated for each colu mn
>>> iris.describe()
       SepalLength
count   150.000000
mean      5.843333
std       0.828066
min       4.300000
25%       5.100000
50%       5.800000
75%       6.400000
max       7.900000
>>> iris.Name.describe()
count                 150
unique                  3
top       Iris-versicolor
freq                   50
Name: Name, dtype: object

#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(iris['category'],iris['target']) #DF, multiindex 

#Which same as merge 
#merge(right, how='inner', on=None, left_on=None, right_on=None, left_index=False, right_index=False)
iris.merge(df, right_index=True, left_index=True)

#value counts : value vs count  
iris['PetalLength'].value_counts()
#mean 
iris.mean() #columnwise 
iris.mean(axis=1) #rowwise 
#aggregation 
gr1 = iris.groupby('Name')
gr1.mean()  #DF of each column mean for each Name 
gr1.agg({'SepalLength':
    ['mean', 'max']}).to_csv("processed.csv")
#open data/processed.csv 

#Using UDF 
#drop
df2 = iris.drop(columns='Name')
df2.head()
iris.replace({'Name':{np.nan:0}})

#Conditionally update 
iris['dummy'] = 2
iris.loc[iris['Name'] == 'Iris-setosa', 'dummy'] = 0
#if true, then x else y , where(condition, x, y)
df['dummy'] = np.where(iris['Name'] == 'Iris-setosa', 0, df['dummy'])


#apply with index based access - check reference for axis meaning
iris.iloc[:, 0:4].apply(np.sum)  #columnwise #end exclusive, s-> each column ie pd.Series
iris.iloc[:, 0:4].apply(np.sum, axis=1) #rowwise 
Note apply can return Series or scalar , but transform must return same length series 

#similar to transform when single series is operated upon 
df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 

#If transofrm can not return same length series, it raises ValueError: Function did not transform
>>> iris.iloc[:, 0:4].transform(['sqrt'])
    SepalLength SepalWidth PetalLength PetalWidth
           sqrt       sqrt        sqrt       sqrt
0      2.258318   1.870829    1.183216   0.447214
1      2.213594   1.732051    1.183216   0.447214
2      2.167948   1.788854    1.140175   0.447214
3      2.144761   1.760682    1.224745   0.447214
4      2.236068   1.897367    1.183216   0.447214
..          ...        ...         ...        ...
145    2.588436   1.732051    2.280351   1.516575
146    2.509980   1.581139    2.236068   1.378405
147    2.549510   1.732051    2.280351   1.414214
148    2.489980   1.843909    2.323790   1.516575
149    2.428992   1.732051    2.258318   1.341641

[150 rows x 4 columns]
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp], axis=1)
          SepalLength  SepalWidth  PetalLength  PetalWidth
0   sqrt     2.258318    1.870829     1.183216    0.447214
    exp    164.021907   33.115452     4.055200    1.221403
1   sqrt     2.213594    1.732051     1.183216    0.447214
    exp    134.289780   20.085537     4.055200    1.221403
2   sqrt     2.167948    1.788854     1.140175    0.447214
...               ...         ...          ...         ...
147 exp    665.141633   20.085537   181.272242    7.389056
148 sqrt     2.489980    1.843909     2.323790    1.516575
    exp    492.749041   29.964100   221.406416    9.974182
149 sqrt     2.428992    1.732051     2.258318    1.341641
    exp    365.037468   20.085537   164.021907    6.049647

[300 rows x 4 columns]
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp], axis=1).index
MultiIndex([(  0, 'sqrt'),
            (  0,  'exp'),
            (  1, 'sqrt'),
            (  1,  'exp'),
            (  2, 'sqrt'),
            (  2,  'exp'),
            (  3, 'sqrt'),
            (  3,  'exp'),
            (  4, 'sqrt'),
            (  4,  'exp'),
            ...
            (145, 'sqrt'),
            (145,  'exp'),
            (146, 'sqrt'),
            (146,  'exp'),
            (147, 'sqrt'),
            (147,  'exp'),
            (148, 'sqrt'),
            (148,  'exp'),
            (149, 'sqrt'),
            (149,  'exp')],
           length=300)
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp]).index
RangeIndex(start=0, stop=150, step=1)
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp])
    SepalLength             SepalWidth  ... PetalLength PetalWidth
           sqrt         exp       sqrt  ...         exp       sqrt       exp
0      2.258318  164.021907   1.870829  ...    4.055200   0.447214  1.221403
1      2.213594  134.289780   1.732051  ...    4.055200   0.447214  1.221403
2      2.167948  109.947172   1.788854  ...    3.669297   0.447214  1.221403
3      2.144761   99.484316   1.760682  ...    4.481689   0.447214  1.221403
4      2.236068  148.413159   1.897367  ...    4.055200   0.447214  1.221403
..          ...         ...        ...  ...         ...        ...       ...
145    2.588436  812.405825   1.732051  ...  181.272242   1.516575  9.974182
146    2.509980  544.571910   1.581139  ...  148.413159   1.378405  6.685894
147    2.549510  665.141633   1.732051  ...  181.272242   1.414214  7.389056
148    2.489980  492.749041   1.843909  ...  221.406416   1.516575  9.974182
149    2.428992  365.037468   1.732051  ...  164.021907   1.341641  6.049647

[150 rows x 8 columns]
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp]).columns
MultiIndex([('SepalLength', 'sqrt'),
            ('SepalLength',  'exp'),
            ( 'SepalWidth', 'sqrt'),
            ( 'SepalWidth',  'exp'),
            ('PetalLength', 'sqrt'),
            ('PetalLength',  'exp'),
            ( 'PetalWidth', 'sqrt'),
            ( 'PetalWidth',  'exp')],
           )
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp])[('SepalLength', 'sqrt')]
0      2.258318
1      2.213594
2      2.167948
3      2.144761
4      2.236068
         ...
145    2.588436
146    2.509980
147    2.549510
148    2.489980
149    2.428992
Name: (SepalLength, sqrt), Length: 150, dtype: float64
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp])[[('SepalLength', 'sqrt'), ('PetalLength', 'sqrt')]]
    SepalLength PetalLength
           sqrt        sqrt
0      2.258318    1.183216
1      2.213594    1.183216
2      2.167948    1.140175
3      2.144761    1.224745
4      2.236068    1.183216
..          ...         ...
145    2.588436    2.280351
146    2.509980    2.236068
147    2.549510    2.280351
148    2.489980    2.323790
149    2.428992    2.258318

[150 rows x 2 columns]
>>>








#In groupby, there is some difference 
There are two major differences between the transform and apply groupby methods.
Input:
    apply implicitly passes all the columns for each group as a DataFrame 
        to the custom function.
        so below works as x is full DF 
        > df.groupby('A').apply(lambda x: (x['C'] - x['D']))
        > df.groupby('A').apply(lambda x: (x['C'] - x['D']).mean())
    transform passes each column for each group individually as a Series 
        to the custom function.
        so below can not work as x is individual Series 
        > df.groupby('A').transform(lambda x: (x['C'] - x['D']))
        > df.groupby('A').transform(lambda x: (x['C'] - x['D']).mean())
            TypeError: cannot concatenate a non-NDFrame object
Output:
    The custom function passed to apply can return a scalar, 
        or a Series or DataFrame (or numpy array or even list).
    The custom function passed to transform must return a sequence 
        (a one dimensional Series, array or list) the same length(no of rows) as the group.

So, transform works on just one Series at a time 
and apply works on the entire DataFrame at once

#plot
iris.Name.value_counts().plot(kind='bar')
plt.show()

#How Many Factors - 3 
iris['index'] = iris.index
iris.plot(x='index', y='SepalLength', kind='scatter')
plt.show()

iris.plot(x='SepalWidth', y='SepalLength', kind='scatter')
plt.show()
iris.iloc[:,0:4].plot(kind='line')
#dont dow below as many plots 
plt.show()
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#or 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.savefig('plot.png')
#or in one plot 
#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label, title='SepalLength')

plt.tight_layout()
plt.legend()
plt.show()

#To sql 
from sqlalchemy import create_engine, text
engine = create_engine('sqlite:///iris.db', echo=False)

iris.to_sql('iris', con=engine,if_exists='replace') 
#{'fail', 'replace', 'append'}, default 'fail'
#index : bool, default True
conn = engine.connect()
conn.execute(text("select * from iris")).fetchall()

conn.execute("SELECT max(SepalLength) , count(*) FROM iris group by Name").fetchall()

pd.read_sql('iris', con=engine) 
pd.read_sql('select * from iris', con=engine) 

conn.close()



##More Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, pip install seaborn

iris.Name.value_counts().plot(kind='bar')
plt.show()
#with x and y 
iris.plot(x=None, y='SepalWidth', kind='line')
plt.show()
#full DF 
iris.plot( kind='line')
plt.show()
#for sub DF 
iris.iloc[:,0:4].plot(kind='line')
plt.show()
#with groupby 
iris.groupby('Name').plot(kind='line')
plt.show()
#as subplots 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#for partial DF 
iris.iloc[:,0:5].groupby('Name')['SepalLength'].plot(kind='line', subplots=True)
plt.show()

#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label)
plt.legend()
plt.show()

#all 
#https://matplotlib.org/users/colormaps.html
cm =['Blues', 'Greens', 'Reds']
fig, ax = plt.subplots(figsize=(8,6))
x_label = []
for i,(label, df) in enumerate(iris.groupby('Name')):
    x_label.append(label)
    df.plot(kind='line', ax=ax, colormap=cm[i])

plt.xlabel(x_label)
plt.legend()
plt.show()

#note 
iris.plot(kind='line') 
#is equivalent to 
iris.plot.line()
#and similarly for others 

#with subplots 
#multiple in one plot 
iris.plot(kind='line', y=['SepalLength','PetalLength'] )
#with subplots 
iris.plot(kind='line', y=['SepalLength','PetalLength'], subplots=True )

#Bar plot of median values
iris.groupby('Name')['SepalLength'].agg(np.mean).plot(kind = 'bar')
plt.show()

#Scatter_matrix or sns.pairplot
#hue is categorical data and for each hue, scatter_matrix is done
sns.pairplot(iris.iloc[:,0:5], hue='Name', size=2.5)
plt.show()

from pandas.plotting import scatter_matrix
scatter_matrix(iris.iloc[:,0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#for only one Name 
scatter_matrix(iris.ix[iris.Name=='Iris-virginica',0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#only density plot 
iris.SepalLength.plot.kde()
plt.show()
#or 
sns.kdeplot(iris.SepalLength)
sns.kdeplot(iris.SepalWidth)
plt.show()
#or
sns.distplot(iris.SepalLength)
plt.show()
#for bivariate kernel density estimate
sns.kdeplot(iris.iloc[:,0:4]) #bivariate kernel density estimate
plt.show()
#joint distribution of x,y and the marginal distributions (joit distribution with one const)
#For this plot, we'll set the style to a white background
#pearsonr = correlation coefficient  , -1 to 1, 0= not correlated, H0:not correlated 
#kind : { “scatter” | “reg” | “resid” | “kde” | “hex” }, optional
with sns.axes_style('white'):
    sns.jointplot(x="SepalLength", y="PetalLength", data=iris.iloc[:,0:4], kind='kde');

plt.show()

#Box plot - x= x axis categorical data, y= box plot variable  , hue=categorical data, for each, x vs y box plot is done 
#box plot - box-25%,median, 75%(third quartiles), min-max data - some convension of min and max - https://en.wikipedia.org/wiki/Box_plot, outliers
#seaborn.factorplot(x=None, y=None, hue=None, data=None, row=None, col=None, col_wrap=None, estimator=<function mean>, ci=95, n_boot=1000, units=None, order=None, hue_order=None, row_order=None, col_order=None, kind='point', size=4, aspect=1, orient=None, color=None, palette=None, legend=True, legend_out=True, sharex=True, sharey=True, margin_titles=False, facet_kws=None, **kwargs)
#kind : {point, bar, count, box, violin, strip}
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Barplot 
g = sns.factorplot(x="Name", data=iris.iloc[:,0:5], aspect=2,  kind="count", color='steelblue')


##Other Plots 
##scatter_matrix 
#https://pandas.pydata.org/pandas-docs/stable/visualization.html

from pandas.plotting import scatter_matrix
df = pd.DataFrame(np.random.randn(1000, 4), columns=['a', 'b', 'c', 'd'])
scatter_matrix(ver, alpha=0.2, figsize=(6, 6), diagonal='kde')
#only density plot 
df.a.plot.kde()

##lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.a)

##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for any and all time-lag separations
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.a)

#Bootstrap plots are used to visually assess the uncertainty of a statistic, 
#such as mean, median, midrange, etc. 
#A random subset of a specified size is selected from a data set, 
#the statistic in question is computed for this subset 
#and the process is repeated a specified number of times. 
#Resulting plots and histograms are what constitutes the bootstrap plot.
from pandas.plotting import bootstrap_plot
bootstrap_plot(df.a, size=50, samples=500, color='grey')


##Time/Date Plot 
ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2000', periods=1000))
ts = ts.cumsum()
ts.plot()

df = pd.DataFrame(np.random.randn(1000, 4), index=ts.index, columns=list('ABCD'))
df = df.cumsum()
plt.figure(); 
df.plot();

#with subplots 
df.plot(subplots=True, figsize=(6, 6));
#means 2 rows and 3 columns , each one is 6x6 
df.plot(subplots=True, layout=(2, 3), figsize=(6, 6), sharex=False);

#or maximum control 
fig, axes = plt.subplots(4, 4, figsize=(6, 6));
plt.subplots_adjust(wspace=0.5, hspace=0.5);
target1 = [axes[0][0], axes[1][1], axes[2][2], axes[3][3]]
target2 = [axes[3][0], axes[2][1], axes[1][2], axes[0][3]]
df.plot(subplots=True, ax=target1, legend=False, sharex=False, sharey=False);
(-df).plot(subplots=True, ax=target2, legend=False, sharex=False, sharey=False);
#or 
fig, axes = plt.subplots(nrows=2, ncols=2)
df['A'].plot(ax=axes[0,0]); axes[0,0].set_title('A');
df['B'].plot(ax=axes[0,1]); axes[0,1].set_title('B');
df['C'].plot(ax=axes[1,0]); axes[1,0].set_title('C');
df['D'].plot(ax=axes[1,1]); axes[1,1].set_title('D');



###then DB api 
rowsd = iris.values.tolist() #from DF 

#Note ? for sqlite, %s for mysql 

from sqlite3 import connect
con = connect(r"iris.db")
cur = con.cursor()
cur.execute("""create table iris (sl double, sw double,
        pl double, pw double, name string)""")
for r in rowsd:
    cur.execute("""insert into iris values(?,?,?,?,?) """, r)

con.commit()
q = cur.execute("""select name, max(sl) from iris group by name""")
result = list(q.fetchall())
print(result)
cur.execute("""drop table if exists iris""")

con.close()

#With sqlAlchemy 
from sqlalchemy import create_engine, text
engine = create_engine("sqlite:///foo.db")
#dump from DF to DB  OR use create table/insert table
iris.to_sql('iris', con=engine)

sql = "select max(SepalLength) from iris group by Name"
with engine.connect() as con:
    res = con.execute(text(sql)).fetchall()

with engine.connect() as con:           l()
    res = con.execute(text("select count(*) from iris")).fetchall()





#classical ORM is complex( Table, mapper(), and class objects), 
#declarative base simplfies that 
#https://docs.sqlalchemy.org/en/13/orm/extensions/declarative/basic_use.html
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import *
Base = declarative_base()

class Row(Base):
    __tablename__ = 'iris'
    # id = Column("some_table_id", Integer, primary_key=True)
    id = Column(Integer, primary_key=True)
    sl = Column(Float)
    sw = Column(Float)
    pl = Column(Float)
    pw = Column(Float)
    name = Column(String(36))
    def __repr__(self):
        return "Row(%.2f,%.2f,%.2f,%.2f,%s)" % (self.sl,self.sw, self.pl, self.pw, self.name)

engine = create_engine('sqlite:///iris1.db', echo=True)
#generates the Schema:
Base.metadata.create_all(engine)

from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)
session = Session()

#Add 
for sl,sw,pl,pw,n in rowsd:
    session.add(Row(sl=sl, sw=sw, pl=pl, pw=pw, name=n))

session.commit()
session.query(Row).count()
session.query(Row).all()
session.query(Row).first()
session.query(Row).filter(Row.sl < 5.1).all()

from sqlalchemy.sql import func, desc 
#func is pseduo object, use sql max\min  etc 
session.query(func.max(Row.sl), func.count(Row.name)) \
    .group_by(Row.name) \
    .order_by(desc(Row.name)) \
    .all()

    




###Excel-pandas 
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parse_dates=True, index_col=0, header=0)
# date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
#from pandas.tseries.offsets import *
#dft.index.freq = Day() #set freq as D 
##if above does not work 
#dft.index.freq = pd.tseries.frequencies.to_offset(Day())
#
dft = dft.asfreq('D')


dft['Open'] #OK 
dft[0:5]

import datetime
#For specific exact index for DF , use .loc 
#dft['2000-06-01'] #ERROR 
#dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
dft.loc['2000-06-01']
dft.loc['2000-06-01', 'Open']

dft.iloc[0]
dft.loc[datetime.date(2000, 6, 1)] 
#for both DF and Series- any partial date string or slice of exact index works 
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day

dft.Close.plot(kind='line')
plt.show()

#which year , stock market crashed 
dft_s = dft.resample('Y')  #'M' , for version <19.2, it is 'A'
dir(dft_s)
#month value would be mean()
dft_s['Open'].mean()   #
sr = dft_s[['Open', 'Close']].first() 
#shift one and drop na 
sr['Close'] = sr.Close.shift(-1)
sr.dropna(how='any', axis=0, inplace=True)
import numpy as np 
sr['diff'] = np.abs(sr.Close - sr.Open)
sr['diff'].idxmax()
sr.loc[[sr['diff'].idxmax()]].index.year.tolist() #DF required 

##other
dft_s = dft.resample('M')
dft_s.mean() #DF 
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})
sr = dft_s['Open'].first().to_frame() #series to DF 
sr.loc[sr['diff'].idxmax()]
sr['Year'] = sr.index.year  #date.astype(np.datetime64)


#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')



#Excel - Example 
df = pd.read_excel("data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225


#Q= "What percentage of the order total does each order represent?"
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]

#Or using openpyxl 
from openpyxl import load_workbook

wb = load_workbook(filename =r"data\Nifty-17_Years_Data-V1.xlsx", 
    data_only=True) #default false, so only read formula 
wb.get_sheet_names()

sheet = wb['Sheet1'] #or wb.worksheets[0]
sheet['A18'].value #datetime 
[(c1.value, c2.value) for c1, c2 in sheet['A1': 'B6']]
data  = []
#Iterating by rows, ie row by row 
#index from 1
for row in sheet.iter_rows(min_row=2):  #sheet.max_row, sheet.max_column
    r = []
    for cell in row:
        r.append(cell.value)
    data.append(r)

rows = sheet.rows #generator, can not remove header 


###Handson   - Exploring a dataset with pandas and matplotlib
#Use dataset containing all ATP matches played by the Swiss tennis player Roger Federer until 2012.

from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline

#Use 
player = 'Roger Federer'
df = pd.read_csv("https://raw.githubusercontent.com/ndas1971/Misc/master/federer.csv",
                 parse_dates=['start date'],
                 dayfirst=True)

df.head(3)

#select some 
df['win'] = df['winner'] == player
df['win'].tail()

#Calculate some 
won = 100 * df['win'].mean()
print(f"{player} has won {won:.0f}% of his matches.")

#Check some time dependent data 
date = df['start date']

#eg  proportion of double faults in each match 
df['dblfaults'] = (df['player1 double faults'] /
                   df['player1 total points total'])

#check 
df['dblfaults'].tail()

#stats 
df['dblfaults'].describe()

#Win per surface 
df.groupby('surface')['win'].mean()


#display the proportion of double faults as a function of the tournament date
gb = df.groupby('year')

#use the matplotlib plot_date() function because the x-axis contains dates:

fig, ax = plt.subplots(1, 1)
ax.plot_date(date.astype(datetime), df['dblfaults'], alpha=.25, lw=0)
ax.plot_date(gb['start date'].max().astype(datetime),  gb['dblfaults'].mean(), '-', lw=3)
ax.set_xlabel('Year')
ax.set_ylabel('Double faults per match')
ax.set_ylim(0)

#Reference 
pandas website at https://pandas.pydata.org/
pandas tutorial at http://pandas.pydata.org/pandas-docs/stable/10min.html
Python for Data Analysis, 2nd Edition, Wes McKinney, O'Reilly Media, at http://shop.oreilly.com/product/0636920050896.do


###Many Other pandas Operations 
#other operations 
#Execute -0.3.pd_ops.py

Creation 
    list of dict, columnName:value,.. for each row
    numpy 2D, columns=list of columns , index?= list of index , optional 
    list of list(rows), columns=...
    columnName:list of col values
For conversion use, 
    pd.to_numeric(Series), 
    pd.to_datetime(Series, ,format='%Y %m %d'), 
    pd.to_timedelta(Series, unit='ns')
drop a column 
    df1.drop('C', inplace=True, axis=1) #axis=0, for row, axis=1 for column , default is row  
    df1.drop(0,  axis=0)  #0th row    
Rename 
    df1.rename(columns={'CC': 'C'}, inplace=True)
    df1.rename(columns=n_cols) # new column names 
Rename index 
    df1.index 
    df1.index  = [10,20]
    #or
    df1.index = [0,1]
    df1r = df1.rename({0:20, 1:30}, axis='index')
Copy and append 
    df1.copy()
    pd.concat([df1,df2], axis=0) #rowwise stack , same index repeated 
    pd.concat([df1,df2], axis=0).reset_index() #reseting index 
    pd.concat([df1,df2], axis=0, ignore_index=True) #reseting index 
    #or 
    df2.append(df1)    #index copied 
    df2.append(df1, ignore_index=True) #equivlent to reset_index
    #columnwise 
    res = pd.concat([df1,df11], axis=1)  #columnwise stack for same index
    res=pd.concat([df1,df1r], axis=1) #creates Nan
    res.columns =list( "ABCDEFGHIJ") #change column names(earlier has duplicates)
    
dropna, fillna , inplace=False 
    df5.dropna(axis=0, how='all') #row wise, if row consists of 'all' or 'any' Nan
    df5.dropna(axis=0, how='any')
    df5.dropna(axis=1, how='any')  #columnwise 
    df5.fillna(0)          #nan by 0 
    df5.fillna({'A': 0})   #only A column 
    
replace 
    df1.replace('1', 20)            #one valye by one value 
    df1.replace({'A':'1'}, 20)      #only for A 
    df1.replace({'A':{'1':20}})     #Only for A, '1'
    df1.replace({'A':'1'}, {'A':20}) #Another way 
    df1.replace(['1','2'], 20)      #multiple values 
    df1.replace(['1','2'], [20,30])
threeways replace 
    df5.fillna({'A': 0})
    df5.replace({'A':{np.nan:0}})
    df5.loc[df5.A.isnull(), 'A'] = 0 #df5.A.isnull() returns True/False for each row 
   
map(only for series, convert one value to other)
    df1.A.map({'1': 'cat', '2':'dog'}) #missing  = Nan 
    #or takes a fun (each element)
    df1.A.map(lambda e: 'cat', na_action='ignore') #NaN values would not be passed to fn 
    
apply for Series(fn takes each element) 
    df1.A.apply(lambda e: len(e))
    #or fn takes an ufunc 
    df1.AA.apply(np.log)

Conversion 
    df1.AA.apply(str)
    #or
    df1.AA.astype('str')
    df1.A.astype(np.float64) #conversion 
    df1[['A', 'A']].astype(np.float64) #works with DF as well 

applymap:DF (fn takes each element)
    df1[['A','B']].applymap(lambda e: len(e))

apply/agg(func_takes_eachCol)- axis=0/Col, 1/Row ,returns Series/DF ie each Column/row trnsfrmed to another scalar(eg np.sum)/column/row 
    df1[['A','B']].apply(lambda col : len(col)) #column wise , ie get each column value
    df1[['A','B']].apply(lambda col : len(col), axis=1) #rowwise, ie get each row value 
    df1[['AA', 'AA']].apply(np.sum)  #columnwise 
    df1[['AA', 'AA']].apply(np.sum, axis=1) #rowwise  
    #agg can take below type as well which is not possible with apply 
    df.agg("mean", axis=1) #rowwise 
    df.agg({'A' : ['sum', 'min'], 'B' : ['min', 'max']})
    df.agg(['sum', 'min'])

transform(func_takes_eachCol) - axis=0/Col, 1/Row ,returns DF ie each Column/row trnsfrmed to another column/row 
    df1.transform(np.log) #each column by np.log 
    (-df1).transform('abs')  #string function , must exist on Series/column 
    df1.transform({'A': np.log, 'B': 'abs'})
    df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 
    
pandas.merge(left, right,.../DataFrame.merge(right,...
    how='inner', 
    on=None/sameColName, left_on=None/LeftCOL, right_on=None/RightCol,      
    left_index=False/IsLeftSideWithIndexMerge, right_index=IsRightSideWithIndexMerge, 
    indicator=False)
sortcut - DataFrame.join(other, on=None, how='left', lsuffix='', rsuffix='', sort=False)
    indicator,If True, adds a column to output DataFrame called '_merge' with 
    information on the source of each row    
    #Example     
    pd.merge(ydf, zdf)
        Rows that appear in both ydf and zdf (Intersection).
    pd.merge(ydf, zdf, how='outer')
        Rows that appear in either or both ydf and zdf(Union).
    pd.merge(ydf, zdf, how='outer',indicator=True).query('_merge == "left_only"').drop(columns=['_merge'])
        Rows that appear in ydf but not zdf (Setdiff).
    
    
##Other Plots 
https://pandas.pydata.org/pandas-docs/stable/user_guide/visualization.html

#Execute - 0.3.pd_other_plots.py


###ADVANCED: advanced operations 
##Melt 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data, columns=['weekday',
        'Person 1', 'Person 2', 'Person 3'])
#output 
     weekday  Person 1  Person 2  Person 3
0     Monday        12        10         8
1    Tuesday         6         6         5
2  Wednesday         5        11         7

#How can you do group by on person 
#this is not normalized table 
#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
#output 
     weekday    Person  Score
0     Monday  Person 1     12
1    Tuesday  Person 1      6
2  Wednesday  Person 1      5

#umpivot 
#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
#output 
Person    Person 1  Person 2  Person 3
weekday
Friday          11         8         7
Monday          12        10         8
#reset_index()
pm2 = pm.reset_index()



##excel style pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

#or to get to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])

##Stack and Unstack 
DataFrame.unstack(level=-1, fill_value=None)
DataFrame.stack(level=-1, dropna=True)
    level : int, string, or list of these, default -1 (last level)
        Level(s) of index to unstack, can pass level name
    fill_value : replace NaN with this value if the unstack produces missing values
    dropna : boolean, default True
        Whether to drop rows in the resulting Frame/Series with no valid values

#Meanings 
stack(column->row): Move last level(default) or 'level' of MultiIndex column labels 
       into last level of row labels
unstack(row->column): Move last level(default) or 'level' of MultiIndex row labels 
       into last level of column labels

#The stack function moves out a level in the DataFrame's columns 
#to produce either:
    •A Series, in the case of a simple column Index
    •A DataFrame, in the case of a MultiIndex in the columns

#Example 
tuples = list(zip(*[['bar', 'bar', 'baz', 'baz',
                    'foo', 'foo', 'qux', 'qux'],
                   ['one', 'two', 'one', 'two',
                    'one', 'two', 'one', 'two']]))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 2), index=index, columns=['A', 'B'])
df2 = df[:4]
>>> df2
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401
      
stacked = df2.stack() #(column->row)
>>> stacked
first  second   
bar    one     A    0.721555
               B   -0.706771
       two     A   -1.039575
               B    0.271860
baz    one     A   -0.424972
               B    0.567020
       two     A    0.276232
               B   -1.087401
dtype: float64

>>> stacked.unstack() #(row->column)
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401

>>> stacked.unstack(1) #(row->column), level=1 (0-based) moved to column 
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

>>> stacked.unstack(0) #(row->column), level=0 (0-based)
first          bar       baz
second                      
one    A  0.721555 -0.424972
       B -0.706771  0.567020
two    A -1.039575  0.276232
       B  0.271860 -1.087401

#If the indexes have names
>>> stacked.unstack('second')#(row->column), level=1 (0-based)
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

##Combining stack/unstack with stats and GroupBy
columns = pd.MultiIndex.from_tuples([('A', 'cat'), ('B', 'dog'),
                                     ('B', 'cat'), ('A', 'dog')],
                                    names=['exp', 'animal'])
index = pd.MultiIndex.from_product([('bar', 'baz', 'foo', 'qux'),
                                    ('one', 'two')],
                                   names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 4), index=index, columns=columns)
>>> df
exp                  A         B                   A
animal             cat       dog       cat       dog
first second                                        
bar   one     0.895717  0.805244 -1.206412  2.565646
      two     1.431256  1.340309 -1.170299 -0.226169
baz   one     0.410835  0.813850  0.132003 -0.827317
      two    -0.076467 -1.187678  1.130127 -1.436737
foo   one    -1.413681  1.607920  1.024180  0.569605
      two     0.875906 -2.211372  0.974466 -2.006747
qux   one    -0.410001 -0.078638  0.545952 -1.219217
      two    -1.226825  0.769804 -1.281247 -0.727707
      
#(column->row), then mean rowwise (index (0), columns (1)), then (row->column)
#here axis=0 means columnwise , =1 mean rowwise
>>> df.stack().mean(1).unstack() 
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048

# same result, another way
#axis : int, default 0, axis=0 means columnwise , =1 mean rowwise
#level : int, level name, or sequence of such, default None
#If the axis is a MultiIndex (hierarchical), group by a particular level or levels
>>> df.groupby(level=1, axis=1).mean()
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048
#(column->row),
>>> df.stack().groupby(level=1).mean()
exp            A         B
second                    
one     0.071448  0.455513
two    -0.424186 -0.204486
#(row->column)
>>> df.mean().unstack(0)
exp            A         B
animal                    
cat     0.060843  0.018596
dog    -0.413580  0.232430



##Compute a simple cross-tabulation of two (or more) factors
pandas.crosstab(index, columns, values=None, rownames=None, colnames=None, 
        aggfunc=None, margins=False, margins_name='All', 
        dropna=True, normalize=False)
    index : array-like, Series, or list of arrays/Series
        Values to group by in the rows
    columns : array-like, Series, or list of arrays/Series
        Values to group by in the columns
    values : array-like, optional
        Array of values to aggregate according to the factors. 
        Requires aggfunc be specified.
    aggfunc : function, optional
        If specified, requires values be specified as well
    rownames : sequence, default None
        If passed, must match number of row arrays passed
    colnames : sequence, default None
        If passed, must match number of column arrays passed
    margins : boolean, default False
        Add row/column margins (subtotals)
    margins_name : string, default 'All'
        Name of the row / column that will contain the totals when margins is True.
    dropna : boolean, default True
        Do not include columns whose entries are all NaN
    normalize : boolean, {'all', 'index', 'columns'}, or {0,1}, default False
        Normalize by dividing all values by the sum of values.
        •If passed 'all' or True, will normalize over all values.
        •If passed 'index' will normalize over each row.
        •If passed 'columns' will normalize over each column.
        •If margins is True, will also normalize margin values.

#Example 
df = pd.DataFrame({'A': [1, 2, 2, 2, 2], 'B': [3, 3, 4, 4, 4],
                   'C': [1, 1, np.nan, 1, 1]})
>>> df
   A  B    C
0  1  3  1.0
1  2  3  1.0
2  2  4  NaN
3  2  4  1.0
4  2  4  1.0
>>> pd.crosstab(df.A, df.B)
B  3  4
A      
1  1  0
2  1  3
>>> pd.crosstab(df.A, df.B, values=df.C, aggfunc=np.sum, normalize=True,margins=True)
B       3    4   All
A                   
1    0.25  0.0  0.25
2    0.25  0.5  0.75
All  0.50  0.5  1.00

foo = pd.Categorical(['a', 'b'], categories=['a', 'b', 'c'])
bar = pd.Categorical(['d', 'e'], categories=['d', 'e', 'f'])
>>> pd.crosstab(foo, bar)
col_0  d  e  f
row_0         
a      1  0  0
b      0  1  0
c      0  0  0
    


###Seaborn 
https://seaborn.pydata.org/
Seaborn is a library for making statistical graphics in Python. 
It builds on top of matplotlib and integrates closely with pandas data structures.


An introduction to seaborn
https://seaborn.pydata.org/tutorial/introduction.html
API 
https://seaborn.pydata.org/api.html


Terminologies 
'hue' is used to visualize the data of different categories in one plot. 
'palette' is used to change the colour of the plot.


Most functions accept data represented with objects from the pandas 
or numpy libraries as well as built-in Python types like lists and dictionaries.
https://seaborn.pydata.org/tutorial/data_structure.html
    When plotting x against y, each variable should be a vector. 
    
    A long-form data(normal 2D data) table has the following characteristics:
        Each variable is a column
        Each observation is a row
        #Example 
        flights = sns.load_dataset("flights")
        flights.head()
        #For example, making a monthly plot of the number of passengers per year looks like this:
        sns.relplot(data=flights, x="year", y="passengers", hue="month", kind="line")
        
        Many pandas operations, such as the split-apply-combine operations of a group-by, 
        will produce a dataframe where information has moved from the columns of the input dataframe 
        to the index of the output. 
        So long as the name is retained, you can still reference the data as normal:

        flights_avg = flights.groupby("year").mean(numeric_only=True)
        sns.relplot(data=flights_avg, x="year", y="passengers", kind="line")

        Additionally, it's possible to pass vectors of data directly as arguments to x, y, 
        and other plotting variables. 
        If these vectors are pandas objects, the name attribute will be used to label the plot:

        year = flights_avg.index
        passengers = flights_avg["passengers"]
        sns.relplot(x=year, y=passengers, kind="line")

        Numpy arrays and other objects that implement the Python sequence interface work too, 
        but if they don't have names, the plot will not be as informative without further tweaking:

        sns.relplot(x=year.to_numpy(), y=passengers.to_list(), kind="line")

        
        
    A wide form  is generally meant for spreadsheet, where the columns and rows 
        contain levels of different variables
        #Example 
        flights_wide = flights.pivot(index="year", columns="month", values="passengers")
        flights_wide.head()
        month 	Jan 	Feb 	Mar 	Apr 	May 	Jun 	Jul 	Aug 	Sep 	Oct 	Nov 	Dec
        year 												
        1949 	112 	118 	132 	129 	121 	135 	148 	148 	136 	119 	104 	118
        1950 	115 	126 	141 	135 	125 	149 	170 	170 	158 	133 	114 	140
        1951 	145 	150 	178 	163 	172 	178 	199 	199 	184 	162 	146 	166
        1952 	171 	180 	193 	181 	183 	218 	230 	242 	209 	191 	172 	194
        1953 	196 	196 	236 	235 	229 	243 	264 	272 	237 	211 	180 	201
        
        Seaborn treats the argument to data as wide form when neither x nor y are assigned.
        #Example of above Long form 
        sns.relplot(data=flights_wide, kind="line")
        
        Seaborn has assigned the index of the dataframe to x, the values of the dataframe to y, 
        and it has drawn a separate line for each month
        
        #Equivalent to 
        #Long form 
        sns.relplot(data=flights, x="month", y="passengers", hue="year", kind="line")
        #wide form 
        sns.relplot(data=flights_wide.transpose(), kind="line")
        
        The example we saw above used a rectangular pandas.DataFrame, as a collection of its columns. 
        A dict or list of pandas objects will also work, but we'll lose the axis labels:

        flights_wide_list = [col for _, col in flights_wide.items()]
        sns.relplot(data=flights_wide_list, kind="line")

        The vectors in a collection do not need to have the same length. 
        If they have an index, it will be used to align them:

        two_series = [flights_wide.loc[:1955, "Jan"], flights_wide.loc[1952:, "Aug"]]
        sns.relplot(data=two_series, kind="line")

        Whereas an ordinal index will be used for numpy arrays or simple Python sequences:

        two_arrays = [s.to_numpy() for s in two_series]
        sns.relplot(data=two_arrays, kind="line")

        But a dictionary of such vectors will at least use the keys:

        two_arrays_dict = {s.name: s.to_numpy() for s in two_series}
        sns.relplot(data=two_arrays_dict, kind="line")

        Rectangular numpy arrays are treated just like a dataframe without index information, 
        so they are viewed as a collection of column vectors. 
        Note that this is different from how numpy indexing operations work, 
        where a single indexer will access a row. 
        But it is consistent with how pandas would turn the array into a dataframe 
        or how matplotlib would plot it:

        flights_array = flights_wide.to_numpy()
        sns.relplot(data=flights_array, kind="line")


        
    Some dataset are messy 
        If datasets that are clearly long-form or wide-form are 'tidy',
        we might say that these more ambiguous datasets are 'messy'
        #Example 
        anagrams = sns.load_dataset("anagrams")
        anagrams

          subidr attnr 	  num1 	num2 	num3
        0 	1 	divided 	2 	4.0 	7
        1 	2 	divided 	3 	4.0 	5
        2 	3 	divided 	3 	5.0 	6
        3 	4 	divided 	5 	7.0 	5
        4 	5 	divided 	4 	5.0 	8
        ....
        12 	13 	focused 	6 	5.0 	9
        13 	14 	focused 	8 	8.0 	7
        14 	15 	focused 	8 	8.0 	7
        15 	16 	focused 	6 	8.0 	7
        
        The attention variable is between-subjects, 
        but there is also a within-subjects variable: the number of possible solutions 
        to the anagrams, which varied from 1 to 3
        
        How might we tell seaborn to plot the average score as a function 
        of attention and number of solutions?
        #Example 
        anagrams_long = anagrams.melt(id_vars=["subidr", "attnr"], var_name="solutions", value_name="score")
        anagrams_long.head()

          subidr attnr 	solutions 	score
        0 	1 	divided 	num1 	2.0
        1 	2 	divided 	num1 	3.0
        
        sns.catplot(data=anagrams_long, x="solutions", y="score", hue="attnr", kind="point")
        
        
https://seaborn.pydata.org/tutorial/objects_interface.html
The seaborn.objects namespace was introduced in version 0.12 
    as a completely new interface for making seaborn plots  
    he seaborn.objects namespace will provide access to all of the relevant classes. The most important is Plot
    #Example 
    import seaborn.objects as so    
            (
        so.Plot(penguins, x="bill_length_mm", y="bill_depth_mm")
        .add(so.Dot(color="g", pointsize=4))
    )
    (
        so.Plot(
            penguins, x="bill_length_mm", y="bill_depth_mm",
            edgecolor="sex", edgewidth="body_mass_g",
        )
        .add(so.Dot(color=".8"))
    )
    The Dot class is an example of a Mark
    See the Mark properties 
    https://seaborn.pydata.org/tutorial/properties.html
    
    The Dot mark represents each data point independently, so the assignment of a variable 
    to a property only has the effect of changing each dot's appearance. 
    #Example 
    (
    so.Plot(healthexp, x="Year", y="Life_Expectancy", color="Country")
    .add(so.Line())
    )
    
    As with many seaborn functions, the objects interface supports statistical transformations. 
    These are performed by Stat objects, such as Agg:
    (
        so.Plot(penguins, x="species", y="body_mass_g")
        .add(so.Bar(), so.Agg())
    )
    
    The objects interface more cleanly separates representation and transformation, 
    allowing you to compose Mark and Stat objects:
    (
        so.Plot(penguins, x="species", y="body_mass_g")
        .add(so.Dot(pointsize=10), so.Agg())
    )


seaborn functions as 'axes-level' or 'figure-level'. 

Figure level 
    Each module has a single figure-level function, which offers a unitary interface 
    to its various axes-level functions. 
    eg 
    relational - relplot (Figure level)
    https://seaborn.pydata.org/tutorial/relational.html
        how variables in a dataset relate to each other 
        and how those relationships depend on other variables. 
    axes-level
        scatterplot() (with kind="scatter"; the default)
        lineplot() (with kind="line")
    #Example 
    sns.relplot( data=tips, x="total_bill", y="tip", hue="smoker", style="time")

        
    Distributions- jointplot(),  pairplot(), displot (Figure-level)
    https://seaborn.pydata.org/tutorial/distributions.html
    histplot(), kdeplot(), ecdfplot(), and rugplot() (axes-level)
        What range do the observations cover? What is their central tendency? 
        Are they heavily skewed in one direction? 
        Is there evidence for bimodality? 
        Are there significant outliers?    
    #Example (Figure-level)
    penguins = sns.load_dataset("penguins")
    sns.displot(data=penguins, x="flipper_length_mm", hue="species", multiple="stack")
    
    https://seaborn.pydata.org/tutorial/function_overview.html#combining-multiple-views-on-the-data
    jointplot() plots the relationship or joint distribution of two variables 
    while adding marginal axes that show the univariate distribution of each one separately:
    
    sns.jointplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", hue="species")
    sns.jointplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", hue="species", kind="hist")

    pairplot() is similar — it combines joint and marginal views — 
    but rather than focusing on a single relationship, 
    it visualizes every pairwise combination of variables simultaneously:

    sns.pairplot(data=penguins, hue="species")
    
        
   Categorical - catplot(Figurelevel)
   https://seaborn.pydata.org/tutorial/categorical.html
   when one of the main variables is 'categorical' (divided into discrete groups)
   which is independent,x and  y is depending on x 
   Axes-level
       Categorical scatterplots:
            stripplot() (with kind="strip"; the default)
            swarmplot() (with kind="swarm")
        Categorical distribution plots:
            boxplot() (with kind="box")
            violinplot() (with kind="violin")
            boxenplot() (with kind="boxen")
        Categorical estimate plots:
            pointplot() (with kind="point")
            barplot() (with kind="bar")
            countplot() (with kind="count")
    #Example 
    tips = sns.load_dataset("tips")
    sns.catplot(data=tips, x="day", y="total_bill", hue="smoker", kind="box")
    
    Note figure-level functions cannot (easily) be composed with other plots. 
    By design, they 'own' their own figure, including its initialization
    
    The figure-level functions return a FacetGrid instance,
    https://seaborn.pydata.org/generated/seaborn.FacetGrid.html#seaborn.FacetGrid
    g = sns.FacetGrid(penguins, col="sex", height=3.5, aspect=.75)
    
    #EXample 
    tips = sns.load_dataset("tips")
    g = sns.relplot(data=tips, x="total_bill", y="tip")
    g.ax.axline(xy1=(10, 2), slope=.2, color="b", dashes=(5, 2))
    
    FacetGrid has few methods for customizing 
    g = sns.relplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", col="sex")
    g.set_axis_labels("Flipper length (mm)", "Bill length (mm)")

            
axes-level
    #Example 
    f, axs = plt.subplots(1, 2, figsize=(8, 4), gridspec_kw=dict(width_ratios=[4, 3]))
    sns.scatterplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", hue="species", ax=axs[0])
    sns.histplot(data=penguins, x="species", hue="species", shrink=.8, alpha=.8, legend=False, ax=axs[1])
    f.tight_layout()
    
Functions for drawing linear regression models
    regplot()-axieslevel and lmplot()-figurelevel(lmplot has hue)
    draw a scatterplot of two variables, x and y, 
    and then fit the regression model y ~ x and plot the resulting regression line 
    and a 95% confidence interval for that regression:
    
    #Example - regplot accepts simple numpy arrays, pandas.Series objects, 
    #or as references to variables in a pandas.DataFrame object passed to data
    tips = sns.load_dataset("tips")
    sns.regplot(x="total_bill", y="tip", data=tips);
    #OR - lmplot must have data=data and xy are string of column name 
    sns.lmplot(x="total_bill", y="tip", data=tips);
    
    It's possible to fit a linear regression when one of the variables takes discrete values
    But it does not look good
    
    One option is to add some random noise ('jitter') to the discrete values 
    to make the distribution of those values more clear. 
    Note that jitter is applied only to the scatterplot data 
    and does not influence the regression line fit itself:

    sns.lmplot(x="size", y="tip", data=tips, x_jitter=.05);

    OR it is good to collapse over the observations in each discrete bin to plot 
    an estimate of central tendency along with a confidence interval
    
    sns.lmplot(x="size", y="tip", data=tips, x_estimator=np.mean);
    
    #Fitting different kinds of models
    anscombe = sns.load_dataset("anscombe")
    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'II'"), ci=None, scatter_kws={"s": 80})
    
    the plot clearly shows that this is not a good model
    
    lmplot() and regplot() can fit a polynomial regression model to explore 
    simple kinds of nonlinear trends in the dataset(order=2):

    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'II'"),order=2, ci=None, scatter_kws={"s": 80})

    A different problem is posed by 'outlier' observations that deviate for some reason 
    other than the main relationship under study:

    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'III'"), ci=None, scatter_kws={"s": 80})

    In the presence of outliers, it can be useful to fit a robust regression, 
    which uses a different loss function to downweight relatively large residuals:

    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'III'"), robust=True, ci=None, scatter_kws={"s": 80});

    When the y variable is binary, simple linear regression also 'works' 
    but provides implausible predictions:

    tips["big_tip"] = (tips.tip / tips.total_bill) > .15
    sns.lmplot(x="total_bill", y="big_tip", data=tips, y_jitter=.03);

    The solution in this case is to fit a logistic regression, 
    such that the regression line shows the estimated probability of y = 1 for a given value of x:

    sns.lmplot(x="total_bill", y="big_tip", data=tips, logistic=True, y_jitter=.03);

    As the confidence interval around the regression line is computed using a bootstrap procedure, 
    you may wish to turn this off for faster iteration (using ci=None).

    An altogether different approach is to fit a nonparametric regression using a lowess smoother. 
    This approach has the fewest assumptions, although it is computationally intensive 
    and so currently confidence intervals are not computed at all:

    sns.lmplot(x="total_bill", y="tip", data=tips,lowess=True, line_kws={"color": "C1"});

    The residplot() function can be a useful tool for checking whether 
    the simple regression model is appropriate for a dataset. 
    It fits and removes a simple linear regression and then plots the residual values 
    for each observation. 

    Ideally, these values should be randomly scattered around y = 0:

    sns.residplot(x="x", y="y", data=anscombe.query("dataset == 'I'"), scatter_kws={"s": 80});

    If there is structure in the residuals, 
    it suggests that simple linear regression is not appropriate:

    sns.residplot(x="x", y="y", data=anscombe.query("dataset == 'II'"),scatter_kws={"s": 80});

    #Conditioning on other variables
    how does the relationship between these two variables change as a function of a third variable?

    This is where the main differences between regplot() and lmplot() appear. 
    While regplot() always shows a single relationship, 
    lmplot() combines regplot() with FacetGrid to show multiple fits using hue mapping or faceting.

    The best way to separate out a relationship is to plot both levels on the same axes 
    and to use color to distinguish them:

    sns.lmplot(x="total_bill", y="tip", hue="smoker", data=tips);

    Unlike relplot(), it's not possible to map a distinct variable to the style properties 
    of the scatter plot, but you can redundantly code the hue variable with marker shape:

    sns.lmplot(x="total_bill", y="tip", hue="smoker", data=tips,  markers=["o", "x"], palette="Set1");

    To add another variable, you can draw multiple 'facets' with each level of the variable 
    appearing in the rows or columns of the grid:

    sns.lmplot(x="total_bill", y="tip", hue="smoker", col="time", data=tips);
    sns.lmplot(x="total_bill", y="tip", hue="smoker", col="time", row="sex", data=tips, height=3);

    #Plotting a regression in other contexts
    A few other seaborn functions use regplot() in the context of a larger, more complex plot. 
    The first is the jointplot() function . jointplot() can use regplot() to show the linear regression 
    fit on the joint axes by passing kind="reg":

    sns.jointplot(x="total_bill", y="tip", data=tips, kind="reg");

    Using the pairplot() function with kind="reg" combines regplot() and PairGrid 
    to show the linear relationship between variables in a dataset. 

    Take care to note how this is different from lmplot(). In the figure below, 
    the two axes don't show the same relationship conditioned on two levels of a third variable; 
    rather, PairGrid() is used to show multiple relationships between different pairings 
    of the variables in a dataset:

    sns.pairplot(tips, x_vars=["total_bill", "size"], y_vars=["tip"], height=5, aspect=.8, kind="reg");

    Conditioning on an additional categorical variable is built into both of these functions 
    using the hue parameter:

    sns.pairplot(tips, x_vars=["total_bill", "size"], y_vars=["tip"], hue="smoker", height=5, aspect=.8, kind="reg");



Statistical estimation and error bars
    When showing a summary statistic(mean/median), it is usually appropriate to add error bars, 
    which provide a visual cue about how well the summary represents the underlying data points.

    The error bars around an estimate of central tendency can show one of two general things: 
    either the range of uncertainty about the estimate 
    or the spread of the underlying data around it. 
    
    These measures are related: given the same sample size, 
    estimates will be more uncertain when data has a broader spread. 
    But uncertainty will decrease as sample sizes grow, whereas spread will not.

    In seaborn, there are two approaches for constructing each kind of error bar.
    
    One approach is parametric, using a formula that relies on assumptions 
    about the shape of the distribution. 
    The other approach is nonparametric, using only the data that you provide.

    Your choice is made with the errorbar parameter, This parameter accepts the name 
    of the method to use and, optionally, a parameter that controls the size of the interval. 
    
    The choices can be defined in a 2D taxonomy that depends on what is shown and how it is constructed:

                    spread                              Uncertainity 
    Parametric      std dev, errorbar=('sd', scale)     std error , errorbar=('se', scale)

    Non-parametric   percentile interval                confidence interval 
                      errorbar=('pi', width)            errorbar=('ci', width)

    You will note that the size parameter is defined differently 
    for the parametric and nonparametric approaches. 
    
    For parametric error bars, it is a scalar factor that is multiplied 
    by the statistic defining the error (standard error or standard deviation). 
    
    For nonparametric error bars, it is a percentile width.

    Error bars that represent data spread present a compact display of the distribution, 
    using three numbers where boxplot() would use 5 or more a
    nd violinplot() would use a complicated algorithm.
    
    #Example 
    def plot_errorbars(arg, **kws):
        np.random.seed(sum(map(ord, "error_bars")))
        x = np.random.normal(0, 1, 100)
        f, axs = plt.subplots(2, figsize=(7, 2), sharex=True, layout="tight")
        sns.pointplot(x=x, errorbar=arg, **kws, capsize=.3, ax=axs[0])
        sns.stripplot(x=x, jitter=.3, ax=axs[1])
    
    #Standard deviation error bars
    By default, errorbar="sd" will draw error bars at +/- 1 sd around the estimate,
    but the range can be increased by passing a scaling size parameter. 
    
    Note that, assuming normally-distributed data, ~68% of the data will lie 
    within one standard deviation, ~95% will lie within two, a
    nd ~99.7% will lie within three:
    
    plot_errorbars("sd")

    #Percentile interval error bars
    Percentile intervals also represent the range where some amount of the data fall, 
    but they do so by computing those percentiles directly from your sample. 
    
    By default, errorbar="pi" will show a 95% interval, ranging from the 2.5 to the 97.5 percentiles. 
    You can choose a different range by passing a size parameter, 
    e.g., to show the inter-quartile range:

    plot_errorbars(("pi", 50))

    The standard deviation error bars will always be symmetrical around the estimate. 
    This can be a problem when the data are skewed, especially if there are natural bounds 
    (e.g., if the data represent a quantity that can only be positive). 
    
    In some cases, standard deviation error bars may extend to 'impossible' values. 
    The nonparametric approach does not have this problem, 
    because it can account for asymmetrical spread 
    and will never extend beyond the range of the data.

    #Measures of estimate uncertainty
    If your data are a random sample from a larger population, 
    then the mean (or other estimate) will be an imperfect measure of the true population average. 
    Error bars that show estimate uncertainty try to represent the range of likely values 
    for the true parameter.
    
    #Standard error bars
    The standard error statistic is related to the standard deviation:
    in fact it is just the standard deviation divided by the square root of the sample size. 
    The default, with errorbar="se", draws an interval +/-1 standard error from the mean:

    plot_errorbars("se")

    #Confidence interval error bars
    The nonparametric approach to representing uncertainty uses bootstrapping: 
    a procedure where the dataset is randomly resampled with replacement a number of times, 
    and the estimate is recalculated from each resample. 
    This procedure creates a distribution of statistics approximating 
    the distribution of values that you could have gotten for your estimate
    if you had a different sample.

    The confidence interval is constructed by taking a percentile interval 
    of the bootstrap distribution. 
    By default errorbar="ci" draws a 95% confidence interval:

    plot_errorbars("ci")

    The seaborn terminology is somewhat specific, because a confidence interval 
    in statistics can be parametric or nonparametric. 
    
    To draw a parametric confidence interval, you scale the standard error, 
    using a formula similar to the one mentioned above. 
    
    For example, an approximate 95% confidence interval can be constructed 
    by taking the mean +/- two standard errors:

    plot_errorbars(("se", 2))

    The nonparametric bootstrap has advantages similar to those of the percentile interval: 
    it will naturally adapt to skewed and bounded data in a way that a standard error interval cannot. 
    
    It is also more general. 
    While the standard error formula is specific to the mean, error bars can be computed 
    using the bootstrap for any estimator:

    plot_errorbars("ci", estimator="median")

    Bootstrapping involves randomness, and the error bars will appear slightly different 
    each time you run the code that creates them. 
    
    A few parameters control this. One sets the number of iterations (n_boot): 
    with more iterations, the resulting intervals will be more stable. 
    
    The other sets the seed for the random number generator, 
    which will ensure identical results:

    plot_errorbars("ci", n_boot=5000, seed=10)

    Because of its iterative process, bootstrap intervals can be expensive to compute, 
    especially for large datasets. 
    But because uncertainty decreases with sample size, 
    it may be more informative in that case to use an error bar that represents data spread.




###Basic Statistics and essentials  -Five number summary 
iris = pd.read_csv('toBeShared/data/iris.csv')
iris.iloc[:, 0:4].describe()
#default axis=0, columnwise, axis=1 rowwise 
iris.iloc[:, 0:4].mean()
iris.iloc[:, 0:4].std()
iris.iloc[:, 0:4].var()
iris.iloc[:, 0:4].median()
iris.iloc[:, 0:4].mode()
iris.iloc[:, 0:4].sem() 	    #Return unbiased standard error of the mean over requested axis.
iris.iloc[:, 0:4].mad() 	    #Return the mean absolute deviation of the values for the requested axis.

#The skewness for a normal distribution is zero, 
#and any symmetric data should have a skewness near zero. 
#Negative values for the skewness indicate data that are skewed left 
#and positive values for the skewness indicate data that are skewed right.
iris.iloc[:, 0:4].skew() 	    #Return unbiased skew over requested axis Normalized by N-1(kurtosis of skew == 0.0)

#Kurtosis is a measure of whether the data are heavy-tailed or light-tailed relative to a normal distribution. 
#That is, data sets with high kurtosis tend to have heavy tails, or outliers
iris.iloc[:, 0:4].kurt() 	    #Return unbiased kurtosis over requested axis using Fisher's definition of kurtosis (kurtosis of normal == 0.0).
iris.iloc[:, 0:4].kurtosis() 	#Return unbiased kurtosis over requested axis using Fisher's definition of kurtosis (kurtosis of normal == 0.0).

#covariance , + menas , both vary together, - means both vary inversely 
iris.iloc[:, 0:4].cov()
#correlation = covariance/stddev(x)*setdev(y)
#magnitude of how much both vary 
iris.iloc[:, 0:4].corr()
#parcentile 
np.percentile(iris.values[:, 0], [0, 25, 50, 75, 100]) 
iris.iloc[:, 0:4].quantile([0, .25, .50, .75, .100]) 	#Return values at the given quantile over requested axis.


###Box plots and outlier detection
#https://pandas.pydata.org/pandas-docs/version/0.22/visualization.html#box-plots
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
plt.rcParams['figure.figsize'] = [10, 10]

iris = pd.read_csv('toBeShared/data/iris.csv')
iris.iloc[:, 0:4].plot.box()
iris.boxplot(by='Name')
## save 
plt.figure(figsize=(4,4))
iris.boxplot(by='Name')
plt.savefig("box.png")

#histogram 
#alpha = transparent
#superimposed 
iris.iloc[:, 0:4].plot.hist( alpha=0.5, bins=50)
#seperate 
iris.iloc[:, 0:4].hist( color='k', alpha=0.5, bins=50)


## violin plot 
import seaborn as sns
#x vs y and hue as 'by' like parameter , could be None 
#kind : {point, bar, count, box, violin, strip}
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="violin", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))

#And then again box-plot 
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()


## Scatter plot 
iris.iloc[:, 0:4].plot.scatter(x='PetalLength', y='PetalWidth')
iris.iloc[:, 0:4].plot.line(x='PetalLength', y='PetalWidth')

## scatter matrix plot 
from pandas.plotting import scatter_matrix
scatter_matrix(iris, alpha=0.2, figsize=(2, 2), diagonal='kde')


## bar plot 
plt.figure();
#single row 
iris.iloc[5, 0:4].plot.bar(); plt.axhline(0, color='k'); plt.plt.axvline(0, color='k')
#many row s
iris.iloc[50:60,0:4].plot.bar()
iris.iloc[50:60,0:4].plot.bar(stacked=True)
iris.iloc[50:60,0:4].plot.barh(stacked=True)
#pie single row 
iris.iloc[50,0:4].plot.pie(subplots=True)

#DataFrame.plot.area([x, y]) 	Draw a stacked area plot.
df = pd.DataFrame(np.random.rand(10, 4), columns=['a', 'b', 'c', 'd'])
df.plot.area()

#DataFrame.plot.hexbin(x, y[, C, ...]) 	Generate a hexagonal binning plot.
df = pd.DataFrame(np.random.randn(1000, 2), columns=['a', 'b'])
df['b'] = df['b'] + np.arange(1000)
df.plot.hexbin(x='a', y='b', gridsize=25)

#DataFrame.plot.density([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.
#DataFrame.plot.kde([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.
iris.iloc[:, 0:4].plot.density()
iris.iloc[:, 0:4].plot.kde()



###Handson- Example of estimating normal parameters 
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

# Generate some data for this demonstration.
data = norm.rvs(10.0, 2.5, size=500) #loc,scale, size 

# Fit a normal distribution to the data:
>>> mu, std = norm.fit(data)  
(9.811694740931252, 2.6595778507346335)
# Plot the histogram.
plt.hist(data, bins=25, normed=True, alpha=0.6, color='g')

# Plot the PDF.
xmin, xmax = plt.xlim() #get xlimit 
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
title = "Fit results: mu = %.2f,  std = %.2f" % (mu, std)
plt.title(title)

plt.show()


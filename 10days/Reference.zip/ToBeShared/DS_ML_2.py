ML introduction 
Linear Regression and regression metrics 
PCA
Purpose of Cross validation
Describe Pipeline  and GridSearch and FeatureUnion 
Validation curve 
Learning curve 
Feature Extraction from text 
Feature Selection 
Transformation 
Logistic Regression 
SVM 
--------------------------
PPT 
data, supervised, unsupervised 
Pipeline, overfitting/underfitting 
CV, preprocessing 
Regression and metrics 
and CLassification metrics 

###Quick Works 
from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

data_url = "http://lib.stat.cmu.edu/datasets/boston"
raw_df = pd.read_csv(data_url, sep=r"\s+", skiprows=22, header=None)
data = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, :2]])
target = raw_df.values[1::2, 2]
>>> data
array([[6.3200e-03, 1.8000e+01, 2.3100e+00, ..., 1.5300e+01, 3.9690e+02,
        4.9800e+00],
       [2.7310e-02, 0.0000e+00, 7.0700e+00, ..., 1.7800e+01, 3.9690e+02,
        9.1400e+00],
       [2.7290e-02, 0.0000e+00, 7.0700e+00, ..., 1.7800e+01, 3.9283e+02,
        4.0300e+00],
       ...,
       [6.0760e-02, 0.0000e+00, 1.1930e+01, ..., 2.1000e+01, 3.9690e+02,
        5.6400e+00],
       [1.0959e-01, 0.0000e+00, 1.1930e+01, ..., 2.1000e+01, 3.9345e+02,
        6.4800e+00],
       [4.7410e-02, 0.0000e+00, 1.1930e+01, ..., 2.1000e+01, 3.9690e+02,
        7.8800e+00]])
>>> target
array([24. , 21.6, 34.7, 33.4, 36.2, 28.7, 22.9, 27.1, 16.5, 18.9, 15. ,
       18.9, 21.7, 20.4, 18.2, 19.9, 23.1, 17.5, 20.2, 18.2, 13.6, 19.6,
       15.2, 14.5, 15.6, 13.9, 16.6, 14.8, 18.4, 21. , 12.7, 14.5, 13.2,
       13.1, 13.5, 18.9, 20. , 21. , 24.7, 30.8, 34.9, 26.6, 25.3, 24.7,
       21.2, 19.3, 20. , 16.6, 14.4, 19.4, 19.7, 20.5, 25. , 23.4, 18.9,
       35.4, 24.7, 31.6, 23.3, 19.6, 18.7, 16. , 22.2, 25. , 33. , 23.5,
       19.4, 22. , 17.4, 20.9, 24.2, 21.7, 22.8, 23.4, 24.1, 21.4, 20. ,
       20.8, 21.2, 20.3, 28. , 23.9, 24.8, 22.9, 23.9, 26.6, 22.5, 22.2,
       23.6, 28.7, 22.6, 22. , 22.9, 25. , 20.6, 28.4, 21.4, 38.7, 43.8,
       33.2, 27.5, 26.5, 18.6, 19.3, 20.1, 19.5, 19.5, 20.4, 19.8, 19.4,
       21.7, 22.8, 18.8, 18.7, 18.5, 18.3, 21.2, 19.2, 20.4, 19.3, 22. ,
       20.3, 20.5, 17.3, 18.8, 21.4, 15.7, 16.2, 18. , 14.3, 19.2, 19.6,
       23. , 18.4, 15.6, 18.1, 17.4, 17.1, 13.3, 17.8, 14. , 14.4, 13.4,
       15.6, 11.8, 13.8, 15.6, 14.6, 17.8, 15.4, 21.5, 19.6, 15.3, 19.4,
       17. , 15.6, 13.1, 41.3, 24.3, 23.3, 27. , 50. , 50. , 50. , 22.7,
       25. , 50. , 23.8, 23.8, 22.3, 17.4, 19.1, 23.1, 23.6, 22.6, 29.4,
       23.2, 24.6, 29.9, 37.2, 39.8, 36.2, 37.9, 32.5, 26.4, 29.6, 50. ,
       32. , 29.8, 34.9, 37. , 30.5, 36.4, 31.1, 29.1, 50. , 33.3, 30.3,
       34.6, 34.9, 32.9, 24.1, 42.3, 48.5, 50. , 22.6, 24.4, 22.5, 24.4,
       20. , 21.7, 19.3, 22.4, 28.1, 23.7, 25. , 23.3, 28.7, 21.5, 23. ,
       26.7, 21.7, 27.5, 30.1, 44.8, 50. , 37.6, 31.6, 46.7, 31.5, 24.3,
       31.7, 41.7, 48.3, 29. , 24. , 25.1, 31.5, 23.7, 23.3, 22. , 20.1,
       22.2, 23.7, 17.6, 18.5, 24.3, 20.5, 24.5, 26.2, 24.4, 24.8, 29.6,
       42.8, 21.9, 20.9, 44. , 50. , 36. , 30.1, 33.8, 43.1, 48.8, 31. ,
       36.5, 22.8, 30.7, 50. , 43.5, 20.7, 21.1, 25.2, 24.4, 35.2, 32.4,
       32. , 33.2, 33.1, 29.1, 35.1, 45.4, 35.4, 46. , 50. , 32.2, 22. ,
       20.1, 23.2, 22.3, 24.8, 28.5, 37.3, 27.9, 23.9, 21.7, 28.6, 27.1,
       20.3, 22.5, 29. , 24.8, 22. , 26.4, 33.1, 36.1, 28.4, 33.4, 28.2,
       22.8, 20.3, 16.1, 22.1, 19.4, 21.6, 23.8, 16.2, 17.8, 19.8, 23.1,
       21. , 23.8, 23.1, 20.4, 18.5, 25. , 24.6, 23. , 22.2, 19.3, 22.6,
       19.8, 17.1, 19.4, 22.2, 20.7, 21.1, 19.5, 18.5, 20.6, 19. , 18.7,
       32.7, 16.5, 23.9, 31.2, 17.5, 17.2, 23.1, 24.5, 26.6, 22.9, 24.1,
       18.6, 30.1, 18.2, 20.6, 17.8, 21.7, 22.7, 22.6, 25. , 19.9, 20.8,
       16.8, 21.9, 27.5, 21.9, 23.1, 50. , 50. , 50. , 50. , 50. , 13.8,
       13.8, 15. , 13.9, 13.3, 13.1, 10.2, 10.4, 10.9, 11.3, 12.3,  8.8,
        7.2, 10.5,  7.4, 10.2, 11.5, 15.1, 23.2,  9.7, 13.8, 12.7, 13.1,
       12.5,  8.5,  5. ,  6.3,  5.6,  7.2, 12.1,  8.3,  8.5,  5. , 11.9,
       27.9, 17.2, 27.5, 15. , 17.2, 17.9, 16.3,  7. ,  7.2,  7.5, 10.4,
        8.8,  8.4, 16.7, 14.2, 20.8, 13.4, 11.7,  8.3, 10.2, 10.9, 11. ,
        9.5, 14.5, 14.1, 16.1, 14.3, 11.7, 13.4,  9.6,  8.7,  8.4, 12.8,
       10.5, 17.1, 18.4, 15.4, 10.8, 11.8, 14.9, 12.6, 14.1, 13. , 13.4,
       15.2, 16.1, 17.8, 14.9, 14.1, 12.7, 13.5, 14.9, 20. , 16.4, 17.7,
       19.5, 20.2, 21.4, 19.9, 19. , 19.1, 19.1, 20.1, 19.9, 19.6, 23.2,
       29.8, 13.8, 13.3, 16.7, 12. , 14.6, 21.4, 23. , 23.7, 25. , 21.8,
       20.6, 21.2, 19.1, 20.6, 15.2,  7. ,  8.1, 13.6, 20.1, 21.8, 24.5,
       23.1, 19.7, 18.3, 21.2, 17.5, 16.8, 22.4, 20.6, 23.9, 22. , 11.9])
>>> data.shape
(506, 13)
>>> target.shape
(506,)
#Features - 13, rows -506
#target is vector
scaler = StandardScaler()
data_s = scaler.fit_transform(data)  # 2D
#Spliting
X_train, X_test, y_train, y_test = train_test_split(data_s, target, random_state=0)
#Train, then score, predict and see test score
model = LinearRegression().fit(X_train, y_train)

>>> dir(model)
['__abstractmethods__', '__annotations__', '__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getstate__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__', '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__setstate__', '__sizeof__', '__sklearn_clone__', '__sklearn_tags__', '__str__', '__subclasshook__', '__weakref__', '_abc_impl', '_build_request_for_signature', '_check_feature_names', '_check_n_features', '_decision_function', '_doc_link_module', '_doc_link_template', '_doc_link_url_param_generator', '_estimator_type', '_get_default_requests', '_get_doc_link', '_get_metadata_request', '_get_param_names', '_get_tags', '_more_tags', '_parameter_constraints', '_repr_html_', '_repr_html_inner', '_repr_mimebundle_', '_set_intercept', '_validate_data', '_validate_params', 'coef_', 'copy_X', 'fit', 'fit_intercept', 'get_metadata_routing', 'get_params', 'intercept_', 'n_features_in_', 'n_jobs', 'positive', 'predict', 'rank_', 'score', 'set_fit_request', 'set_params', 'set_score_request', 'singular_']
>>> model.coef_
array([-1.01170421,  1.02558108, -0.03953238,  0.60731239, -1.80467996,
        2.64552328, -0.19783648, -3.018615  ,  2.0883816 , -1.90212879,
       -2.13154559,  0.77017134, -3.56070005])
>>>
>>> model.coef_
array([-1.01170421,  1.02558108, -0.03953238,  0.60731239, -1.80467996,
        2.64552328, -0.19783648, -3.018615  ,  2.0883816 , -1.90212879,
       -2.13154559,  0.77017134, -3.56070005])
>>> model.score(X_train, y_train)
0.7697699488741149

#By default R^
y_pred = model.predict(X_test)
>>> model.score(X_test, y_pred)
1.0
>>> model.score(X_test, y_test)
0.6354638433202128
>>>

from yellowbrick.regressor import *
>>> v = ResidualsPlot(model)
>>> v.fit(X_train, y_train)
visualizer.score(X_test, y_test)       
visualizer.show()  





##Classification 
iris = pd.read_csv(r"code\data\iris.csv")
data = iris[['SepalLength' , 'SepalWidth',  'PetalLength',  'PetalWidth']]
target = iris.Name
enc = LabelEncoder()
y = enc.fit_transform(target)
X = data

# in real stdcaler on X  and proceced
pca = PCA(n_components=1)
sel = SelectKBest(chi2, k=1)
cfeats = FeatureUnion([("pca", pca),("sel", sel)])
lr = LogisticRegression()
pipeline = Pipeline([('cf', cfeats),('lr', lr)])
search_grid = dict(cf__pca__n_components=[1,2], cf__sel__k=[1,2], lr__C=[0.1, 1,10])
#2*2*3
m = RandomizedSearchCV(pipeline, param_distributions=search_grid,cv=5, n_iter=50)  # KFold is 5
m.fit(X,y)
final_model = m.best_estimator_
final_model.score(X,y)
0.98
yHat = final_model.predict(X)
confusion_matrix(y,yHat)
array([[50,  0,  0],
       [ 0, 48,  2],
       [ 0,  1, 49]])
>>> m.best_params_
{'lr__C': 1, 'cf__sel__k': 2, 'cf__pca__n_components': 2}

##ROCAUC

Draw ROCAUC 
https://www.scikit-yb.org/en/latest/api/classifier/rocauc.html


X, y = load_iris(return_X_y=True)
scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

clf = LogisticRegression(random_state=0).fit(X_train, y_train)

clf.predict(X_test)
clf.predict_proba(X_test)  #predicted prob in each class 
clf.score(X_train, y_train)
clf.score(X_test, y_test)

from yellowbrick.classifier import ROCAUC
visualizer = ROCAUC(model, classes=["Iris-Setosa", "Iris-Versicolour", "Iris-Virginica"])
visualizer.fit(X_train, y_train)        
visualizer.score(X_test, y_test)       
visualizer.show()  

y_pred = clf.predict(X_test)
accuracy_score(y_test, y_pred)
confusion_matrix(y_test, y_pred)

##Example - spam/Ham-Handson 
sp = pd.read_csv("data/spam.csv", encoding='latin-1')
sp.head()
lenc = LabelEncoder()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]
y = lenc.fit_transform(y_raw)
tf = TfidfVectorizer()
X = tf.fit_transform(X_raw )

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
param_grid = dict(C= [0.001, 0.1, 1, 10, 100])
clf= LogisticRegression()
gs = GridSearchCV(clf, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)



###ML introduction from PPT 

###All import 
from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt


###Linear Regression and regression metrics 
        
##Simple OLS 
boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

data_url = "http://lib.stat.cmu.edu/datasets/boston"
raw_df = pd.read_csv(data_url, sep=r"\s+", skiprows=22, header=None)
#check above link, each row is not in one line 
data = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, :2]])
target = raw_df.values[1::2, 2]

scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
Y = boston["target"]
X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)
m = LinearRegression().fit(X_train,y_train)
m.coef_, m.intercept_
m.score(X_train,y_train)  #R^2 
m.score(X_test, y_test)
mean_squared_error(y_test, m.predict(X_test))

#scatter_matrix
from pandas.plotting import scatter_matrix
scatter_matrix(pd.DataFrame(X, columns=boston.feature_names), 
    diagonal='kde')
plt.show()


#Residual plot 
from yellowbrick.regressor import *
visualizer = ResidualsPlot(m)
visualizer.fit(X_train, y_train)  # Fit the training data to the model
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
visualizer.poof()                 # Draw/show/poof the data
#visualizer.poof(outpath="pcoords.png") #sve to file, ext determines file type 

#NOTE 
X and Y need to be two-dimensional arrays  and one dimensional of shape (n_samples, n_features)
and (n_sample, ) respectively. 
This is the case even if you only have one feature and one target.

Do you know the difference between an array of shape (6, 1) and an array of shape (6,)? 
the first is a true 2-dimensional array that happens to have one column, 
and the second is a completely 1-dimensional array.

Here's how to convert  data to 2d arrays. 

ages_train = np.array([20, 22, 25, 27, 30, 31, 31, 34, 42, 50])
ages_train[:, np.newaxis]


#Note 
https://scikit-learn.org/stable/modules/linear_model.html#generalized-linear-models
The choice of the distribution depends on the problem at hand:

If the target values are counts (non-negative integer valued) 
or relative frequencies (non-negative), you might use a Poisson distribution with a log-link.

If the target values are positive valued and skewed, you might try a Gamma distribution with a log-link.

If the target values seem to be heavier tailed than a Gamma distribution, 
you might try an Inverse Gaussian distribution 
(or even higher variance powers of the Tweedie family).

If the target values are probabilities, you can use the Bernoulli distribution. 
The Bernoulli distribution with a logit link can be used for binary classification. 
The Categorical distribution with a softmax link can be used for multiclass classification.

TweedieRegressor implements a generalized linear model 



##Lasso and Ridge and ElasticNet Regression
##Example - boston - With alpha and Lasso , coefficients are sparse 
#Execute - 3.0.linear_regression.py

Ridge Regression:
        Performs L2 regularization, i.e. adds penalty equivalent to square of the magnitude of coefficients
        Minimization objective = RSS + α * (sum of square of coefficients)
The RSS(residual sum of squared )  increases with increase in alpha, this model complexity reduces with reduction of overfitting. 
High alpha values can lead to significant underfitting. Note the rapid increase in RSS for values of alpha greater than 1

Lasso Regression:
        Performs L1 regularization, i.e. adds penalty equivalent to absolute value of the magnitude of coefficients
        Minimization objective = RSS + α * (sum of absolute value of coefficients)
For the same values of alpha, the coefficients of lasso regression are much smaller as compared to that of ridge regression 
For the same alpha, lasso has higher RSS (poorer fit) as compared to ridge regression
Many of the coefficients are zero even for very small values of alpha

Key Difference
Ridge: It includes all of the features in the model. Thus, the major advantage of ridge regression is coefficient shrinkage and reducing model complexity.
Lasso: Along with shrinking coefficients, lasso performs feature selection as well. Some of the coefficients become exactly zero, which is equivalent to the particular feature being excluded from the model.
    
Typical Use Cases
Ridge: It is majorly used to prevent overfitting. Since it includes all the features, it is not very useful in case of exorbitantly high #features, say in millions, as it will pose computational challenges.
Lasso: Since it provides sparse solutions, it is generally the model of choice (or some variant of this concept) for modelling cases where the #features are in millions or more. In such a case, getting a sparse solution is of great computational advantage as the features with zero coefficients can simply be ignored.

Presence of Highly Correlated Features
Ridge: It generally works well even in presence of highly correlated features as it will include all of them in the model but the coefficients will be distributed among them depending on the correlation.
Lasso: It arbitrarily selects any one feature among the highly correlated ones and reduced the coefficients of the rest to zero. Also, the chosen variable changes randomly with change in model parameters. This generally doesn’t work that well as compared to ridge regression.



##Regression Diagnostics 
#Execute 3.0.linear_regression.py

   

###Logistic Regression 
#Check 
#https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html

#Note l2 penalty 
#good for overfitting (Ridge) and highly correlated data(as coef shrinkage)
#l1 penalty
#many coef is zero, so feature selection , good for large no of features 

X, y = load_iris(return_X_y=True)
scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

clf = LogisticRegression(random_state=0, solver='lbfgs',
    multi_class='multinomial').fit(X_train, y_train)

clf.predict(X_test)
clf.predict_proba(X_test)  #predicted prob in each class 
clf.score(X_train, y_train)
clf.score(X_test, y_test)

##Clasification metrics 

#check meaning of average 
#https://scikit-learn.org/stable/modules/model_evaluation.html#from-binary-to-multiclass-and-multilabel 
#use weighted 

y_pred = clf.predict(X_test)
accuracy_score(y_test, y_pred)
confusion_matrix(y_test, y_pred)
precision_recall_fscore_support(y_test, y_pred, average='weighted')
precision_score(y_test, y_pred, average='weighted') 	
recall_score(y_test, y_pred, average='weighted') 	
f1_score(y_test, y_pred, average='weighted')
#It is possible to compute per-label precisions, recalls, F1-scores and supports 
#instead of averaging:
precision_recall_fscore_support(y_test, y_pred, average=None)

##Confusion_matric plot 
import seaborn as sns
sns.heatmap(confusion_matrix(y_test,y_pred),annot=True)

##More understanding - Clasification metrics 
false positive or false negative from prediction point of view 
Total case = N = a+b+c+d

        Actual True                             False 
Predicted 
True        a                                   b (false positive/false Alarm) - Type 1/alpha

False       c(false negative)(type-II/beta)     d

false alarm is Type 1/alpha - FAA


Accuracy = (a+d)/N 
recall,sensitivity = a/(a+c) -SEB - No beta
specificity= d/(b+d) - SPA - No alpha/False alarm 

precision = a/(a+b) - No false alarm - PrecisionPredictedTrueAlha - PRA
Fbeta = 1/(1/pre + 1/sen)

Since Classification model predicts probabilities of each class, 
there is some threashold required for calculating True and False. 
Hence for one threshold, we get one pair of Sensitivity and Specificity

Ideally we want to maximize both Sensitivity & Specificity. 
But this is not possible. 

Sometimes we want to be 100% sure on Predicted negatives, 
(specificity = 100%, no false alarm  - Actual F tested T)
Specificity(eg Testing a medicine is good(Actual T) or poisonous(actual F) ) 
ie false positive/aram is zero,


sometimes we want to be 100% sure on Predicted positives, 
(sensitivity = 100%, no false negative - Actual T tested F)
eg Predicting a customers good or bad before issuing the loan ) 
ie false negative is zero (predicted negative is zero for condition positive)

The threshold is set based on business problem

Sensitivity and Specificity are inversely proportional to each other. 
So when we increase Sensitivity, Specificity decreases 
When we decrease the threshold, we get more positive values 
thus it increases the sensitivity and decreasing the specificity.

As FPR is 1 - specificity. So when we increase TPR(sensitivity), 
FPR also increases and vice versa
(FPR - False positive rate-false alarm/alpha, TPR-true positive rate)

ROC Curve
Consider all the possible threshold values 
and the corresponding specificity and sensitivity rate
ROC(Receiver operating characteristic) curve is drawn by taking 
(1- specificity) on X-axis and sensitivity on Y- axis.
    

ROC and AUC
We want that curve to be far away from the straight line. 
Ideally, we want the area under the curve as high as possible. 
ie AUC. Area Under the Curve needs to be 1

ROC Curve Gives us an idea on the performance of the model 
under all possible values of threshold.

AUC=1.0, It is perfectly able to distinguish between positive class and negative class.

AUC=0.7, it means there is 70% chance that model will be able 
to distinguish between positive class and negative class.

AUC=0.5, model has no discrimination capacity to distinguish 
between positive class and negative class.

AUC=0.0, model is actually reciprocating the classes. 
It means, model is predicting negative class as a positive class and vice versa

##Understanding macro 
Multiclass classification
    a classification task with more than two classes;
    e.g., classify a set of images of fruits which may be oranges, apples, or pears.
    Multiclass classification makes the assumption that each sample is assigned to one 
    and only one label
    a fruit can be either an apple or a pear but not both at the same time .
    
    All classifiers in scikit-learn do multiclass classification out-of-the-box
    Other than inherently multiclass classifier, there are strategies 
    for reducing the problem of multiclass
    classification to multiple binary classification - One Vs the Rest and One vs One
    
One-vs-One: Here, you pick 2 classes at a time, and train a two-class-classifier using samples 
from the selected two classes only (other samples are ignored in this step). 
You repeat this for all the two class combinations. 
So you end up with N(N-1)/2 classifiers. 
And while testing, you do voting among these classifiers.

One-vs-Rest: Here, you pick one class and train a two-class-classifier 
with the samples of the selected class on one side and all the other samples on the other side. 
Thus, you end up with N classifiers. While testing, you simply classify the sample 
as belonging to the class with maximum score among the N classifiers.

                  Actual
                A   B   C
            A   a   b   c           
Predicted   B   d   e   f 
            C   g   h   i 
          
                        Actual A        notA
            A           diagonal        ActBPredA+ActCPredA
                           a                b+c 
predicted   notA   ActAPredB+ActAPredC  All other cells 
                          d+g               e+f+h+i
means 
                        Actual A        notA
            A           diagonal        allHorizontal
predicted   notA        allVertical     All other cells 

In General 
                        Actual x                             notx
            x           diagonalcell                        allHorizontal, alpha=false alarm 
predicted   notx        allVertical,beta,False negative     All other cells 
     
    
"macro" (average of all averages)
    calculates the mean of the binary metrics, giving equal weight to each class. 
    For example, for precision PrA=TpA/(TpA+FpA) for class A, ... for other classes 
    macro = (PrA+PrB+...)/No_of_classes, where PrA means Precision of class A
    
    In problems where infrequent classes are nonetheless important,     
    macro-averaging may be a means of highlighting their performance. 
    On the other hand, the assumption that all classes are equally important is often untrue, 
    such that macro-averaging will over-emphasize the typically low performance 
    on an infrequent class.

"weighted" (wt average of all averages, wt comes from no of support)
    accounts for class imbalance by computing the average of binary metrics 
    in which each class's score is weighted by its presence in the true data sample.
    (recommended to use this)
    wt = (SupportA*PrA + .....)/Total_Support

"micro" ( average of actual data)
    gives each sample-class pair an equal contribution to the overall metric 
    (except as a result of sample-weight).
    micro = (TpA + TpB + ....)/(TpA + FpA + TpB + FpB + ......)
    
    Rather than summing the metric per class, this sums the dividends and divisors 
    that make up the per-class metrics to calculate an overall quotient. 
    Micro-averaging may be preferred in multilabel settings, 
    including multiclass classification where a majority class is to be ignored.
    
    Support     Sensitivity
A 100 cases     90%  = 900/(900+100)
B 100 cases     80%  = 800/(800+200)
C 100 cases     90%  = 900/(900+100)

macro = (90%+80%+90%)/3 
wt = (100*90%+100*80%+100*90%)/300
micro = (900+800+900)/(900+100+800+200+900+100)


##Understand Conditional Probability 
One example 
in a class , boy wearing hat is 30%, girl wearing hat is 10% 
boy is of 40% and girl is of 60% 
Now hat is seen what is the prob that is on boy  or girl 
Pr(Boy|hat) = p(hat|Boy)*P(boy)/P(hat) = (0.3 * .4)/(.3*4 + .6*.1)
Pr(Girl|hat) =(.6*.1)/(.3*4 + .6*.1)

            hat .3
     boy, .4---
           no hat .7
class -- 
            hat .1
     girl, .6
            nohat .9
            

#Another example 
        symptom    Yes  No     Total 
--------------------------------------------
       Yes          1    0      1
cancer No          10    99989  99999
       total       11    99989  100000


                        P(Symp|Cancer)*P(Cancer)
P(Cancer|Symp) = -------------------------------------------------------------------
                 P(Symp) = P(Symp|Cancer)*P(Cancer) + P(Symp|NOCancer) * P(NOCancer)
     
              = (1 * 1/1e5)/(1*1/1e5 + 10/99999 * 99999/1e5) = 1/11 ~ 9.1%
              
Cancer=Actual, Symptoms = Tested 
Sensitivity = Cancer T Symp T /(Above + Cancer T Symp F=beta) = 1/1 = 100% 
specifity =   Cancer F Symp F / (above + Cancer F symp T) = 99989/(99989+10)=99.99%
accuracy = (Cancer T Symp T + Cancer F Symp F)/T = (1+99989)/100000 = 99.99%
Precesion = Cancer T Symp T/(above + Cancer F Symp T) = 1/(1+10)= 9%
Fbeta = 1/(1/precision + 1/sensitivity) = 8%


###ADVANCED: 
##Multicollinearity and Individual Impact of Variables
#Execute - 4.1.logistic_regression_vif_feature_importance.py 

##PCA
#execute 2.1.plot_pca.py


##Overfit vs underfit 
#Execute 2.3.plot_underfitting_overfitting.py

##Bias ,Variance and it's Tradeoff
#Execute 2.2.plot_train_error_vs_test_error.py



###Purpose of Cross validation
#https://scikit-learn.org/stable/modules/cross_validation.html

lr = LinearRegression()
boston = load_boston()
y = boston.target
CV= KFold(n_splits=10,shuffle=True)
scores = cross_val_score(lr, boston.data, y, cv=CV) 
print(scores.mean(), scores.std() )


##ADVANCED: Execute 2.4.plot_cv_predict.py


###ADVANCED:Feature Extraction from text 
#Extraction from Text , CountVectorizer - tokenization and count frequency 
#This model has many parameters, however the default values are quite reasonable 
#TfidfVectorizer - Equivalent to CountVectorizer followed by TfidfTransformer
#Tf means term-frequency while tf–idf means term-frequency times inverse document-frequency


vectorizer = CountVectorizer()
tf = TfidfVectorizer()
>>> vectorizer                     
CountVectorizer(analyzer=...'word', binary=False, decode_error=...'strict',
        dtype=<... 'numpy.int64'>, encoding=...'utf-8', input=...'content',
        lowercase=True, max_df=1.0, max_features=None, min_df=1,
        ngram_range=(1, 1), preprocessor=None, stop_words=None,
        strip_accents=None, token_pattern=...'(?u)\\b\\w\\w+\\b',
        tokenizer=None, vocabulary=None)

#corpus is list of Sentences or line 
import glob
#list of list 
lst = [open(name, "rt").readlines() for name in glob.glob("data/corpus/*")]
corpus = [ line.strip() for inner in lst for line in inner]

X = vectorizer.fit_transform(corpus)
>>> X                              
<4x9 sparse matrix of type '<... 'numpy.int64'>'
    with 19 stored elements in Compressed Sparse ... format>

vectorizer.get_feature_names()#see the feature name 
X.toarray()       

X = tf.fit_transform(corpus)
>>> X                              
<4x9 sparse matrix of type '<... 'numpy.int64'>'
    with 19 stored elements in Compressed Sparse ... format>

tf.get_feature_names()#see the feature name 
X.toarray() 




###Feature Selection and Pipeline 
iris = load_iris()
X, y = iris.data, iris.target 

# This dataset is way too high-dimensional. Better do PCA:
X_new = PCA(n_components=1).fit_transform(X,y)
>>> X_new.shape
(150, 1)

# Maybe some original features where good, too?
selection = SelectKBest(chi2, k=1).fit_transform(X,y)
>>> X_new.shape
(150, 1)

Chi-square (Χ2) distributions are a family of continuous probability distributions. They’re widely used 
in hypothesis tests, including the chi-square goodness of fit test and the chi-square test 
of independence.

Imagine taking a random sample of a standard normal distribution (Z). 
If you squared all the values in the sample, you would have the chi-square distribution with k = 1.


#OR Build estimator from PCA and Univariate selection:
pca = PCA(n_components=1)
selection = SelectKBest(chi2, k=1)
combined_features = FeatureUnion([("pca", pca),  
    ("univ_select", selection)])

lr = LogisticRegression()
pipeline = Pipeline([("features", combined_features), 
("lr", lr)])

pipeline.steps[0]
pipeline.named_steps['lr']
pipeline.get_params()
pipeline.get_params().keys()
pipeline.set_params(lr__C=10) 
pipeline.set_params(features__kernel_pca__kernel='rbf')


param_grid = dict(features__pca__n_components=[1, 2, 3],
                  features__univ_select__k=[1, 2],
                  lr__C=[0.1, 1, 10])

grid_search = RandomizedSearchCV(pipeline, 
    param_distributions=param_grid, cv=5, verbose=10)
grid_search.fit(X_train, y_train)
final_model = grid_search.best_estimator_
grid_search.best_params_ 
print(final_model)
y_pred = final_model.predict(X_test)
final_model.score(X_train, y_train)
accuracy_score(y_test, y_pred) #y_true, y_pred



###Model Saving and loading 
import pickle
s = pickle.dumps(final_model) #or pickle.dump(final_model, open("final","wb"))
clf = pickle.loads(s)         #clf = pickle.load(open("final", "rb"))
accuracy_score(y_test, clf.predict(X_test))




###transformation 

iris = pd.read_csv('data/iris.csv')
#For compatbility reasons, to work with pandas , convert pandas DF to ndArray 
#Note latest version of sklearn can directly take pandas(coerce with np.array())
#but , if pandas has all numeric, then OK, else, convert to ndArray as object- which is NotOK
#can convert to ndarray.astype(floaf64) etc 
dataset_array = iris.values[:, 0:4].astype(float64)
dataset_array.dtype
#or 
np.array(iris.iloc[:, 0:4])
#or 
mat = iris.iloc[:, 0:4].as_matrix()

#How ever sklearn preprocessing works on full array, not individual features 
#Note .fit(X), then .transform(X), .inverse_transform(transformed)
#each column of X is one feature 
y = string or numeric categorical 
    Use LabelEncoder(takes 1D/vector ie (n,)) to convert to integer 0...No_Of_classes,
    Note, one hot encoding (LabelBinarizer()) is not required for y at all
    (but LabelBinarizer() exists for converting binary classification to multi-class, 
    which done by sklearn by default)
X = string categorical , must be one hot encoded 
        Use LabelEncoder(1D/vector) , convert to (n,1) 
        ( reshape(-1,1)  or reshape(n,1) or [:, np.newaxis]
        and then use OneHotEncoder(takes 2D)
    numeric categorical - must be one hot encoded 
        Use OneHotEncoder(takes 2D)

All other values can be directly used
But X may require some below (all, .fit() takes 2D, first four takes 1D as well), all has default parameters
    sklearn.preprocessing.StandardScaler for mean=0, unit std , feature/columnwise 
        Check with .mean(axis=0), .std(axis=0)
    MinMaxScaler for [min,max] or MaxAbsScaler for [0,1], feature/columnwise 
    RobustScaler  for data with outlier , feature/columnwise
    If feature independence is required, 
        Put it with sklearn.decomposition.PCA(whiten=True) #ie n_components=None
    QuantileTransformer puts all features into the same, known range or distribution.
    PowerTransformer to Normal distribution featurewise 
    Normalizer  for each samples to have unit norm (row wise)
    Binarizer(threshold=..)thresholding numerical features to get boolean values
    PolynomialFeatures(n) to add a + b + ... + a*a +... + a*b + b*c+... (including iteraction term) 
        interaction_only=True, only interaction term 
    SimpleImputer(missing_values=np.nan, strategy='mean') for imputing missing value   

Feature Selection , fit(X,y) 
    SelectKBest removes all but the highest scoring features
    SelectFromModel is a meta-transformer that can be used along with any estimator that has a coef_ or feature_importances_ attribute after fitting.
    
Feature Extraction from text 
    CountVectorizer implements both tokenization and occurrence counting in a single class:
    TfidfVectorizer that combines all the options of CountVectorizer and TfidfTransformer in a single model:
    
    
##iris transformation 
iris = pd.read_csv('iris.csv')
X_raw = iris.iloc[:, 0:4].astype(np.float64)
y_raw = iris.iloc[:, 4]
lenc = LabelEncoder()
std = StandardScaler()
X = std.fit_transform(X_raw)
y = lenc.fit_transform(y_raw)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0) #DF
clf = LogisticRegression()
clf.fit(X_train, y_train)
clf.score(X_test, y_test)

y_pred = clf.predict(X_test)
accuracy_score(y_test, y_pred) #y_true, y_pred
confusion_matrix(y_test, y_pred)

list(lenc.inverse_transform(y_pred))



###Example - mushroom 
mush = pd.read_csv("data/mushroom.csv")
mush.head()
lenc = LabelEncoder()
oh = OneHotEncoder()
X_raw = mush.iloc[:, 1:]
y_raw = mush.iloc[:, 0]
y = lenc.fit_transform(y_raw)
X_raw1 = X_raw.apply(lambda col: lenc.fit_transform(col)) #3
X_raw1.head() 
X = oh.fit_transform(X_raw1) #20 features
X.toarray()
X_raw1['shape'].unique()
X_raw1['surface'].unique()
X_raw1['color'].unique()

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
param_grid = dict(C= [0.001, 0.1, 1, 10, 100])
clf= LogisticRegression()
gs = GridSearchCV(clf, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) #{'C': 100, 'penalty': 'l1'}
from yellowbrick.classifier import *
vis = ROCAUC(LogisticRegression(**gs.best_params_))
vis.fit(X_train, y_train)
vis.score(X_test, y_test)
vis.poof()
y_pred = gs.predict(X_test)

###Example - spam/Ham
sp = pd.read_csv("data/spam.csv", encoding='latin-1')
sp.head()
lenc = LabelEncoder()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]
y = lenc.fit_transform(y_raw)
tf = TfidfVectorizer()
X = tf.fit_transform(X_raw )

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
param_grid = dict(C= [0.001, 0.1, 1, 10, 100])
clf= LogisticRegression()
gs = GridSearchCV(clf, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)

unknown_X = pd.Series(["Hello how are you", "Free rewards"])
yHat = gs.predict(tf.fit_transform(unknown_X))
enc.inverse_transform(yHat)


#with ngrams 1,2 
sp = pd.read_csv("data/spam.csv", encoding='latin-1')
sp.head()
lenc = LabelEncoder()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]
y = lenc.fit_transform(y_raw)

tf = TfidfVectorizer(ngram_range=(1,2))
X = tf.fit_transform(X_raw ) #very high now 

pca = TruncatedSVD(n_components=1000)
lr = LogisticRegression()

X_train, X_test, y_train, y_test = train_test_split(
        X_raw,y, random_state=0) 
        
pipeline = Pipeline([
    ("tf", tf), 
    ('pca', TruncatedSVD(n_components=1000)),  
    ("lr", lr)])

param_grid = dict(lr__C=[100,500])
gs = GridSearchCV(pipeline, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)







###Example -  Titanic Data processing 
#Let's go through an example from Kaggle, the Titanic dataset. 
#The task here is to predict who will survive on Titanic, 
#based on a subset of whole dataset.
0. Note survived is 'y', rest all are 'X' 
1. Replace nan values of embarked, fare by mode of embarked, fare 
2. Create a transformer with following transformation 
   String categorical - embarked, pclass, sex, Title
                        FamilyID
   Take as it is - fare, parch , sibsp , FamiliySize, AgeOriginallyNaN
                   AgeFilledMedianByTitle   
   Create following columns as 
        Title - get Title portion from name
        LastName  - get last name ftom name 
        FamilySize - total of sibsp and parch + 1 
        FamilyID  - String of "LastName:FamiliySize"
                    If FamiliySize <=2 , then "Small_Family"
        AgeOriginallyNaN - new column where 0 = age is NaN, 1 = age is not NaN 
            Hint: Use .isnull() and convert to int 
        AgeFilledMedianByTitle , median age for that Title 
            Find median age for each title(groupby)
            then merge that with original DF on Title 
            
 

#Solutions 
from sklearn_pandas import *

df_train = pd.read_csv('toBeShared/data/titanic_train.csv', header = 0, index_col = 'ticket')
df_test = pd.read_csv('toBeShared/data/titanic_test.csv', header = 0, index_col = 'ticket')

#axis=0 , means vertical(row) stacking , axis=1, columnwise append 
df = pd.concat([df_train, df_test], keys=["train", "test"])

df.index.get_level_values(0)  #train, test 
df.index.get_level_values(1)  #ticket
df.index.names # [None, 'ticket']
df.index.names = ['type', 'ticket']
df.index.get_level_values('type')
df.index.get_level_values('ticket')
df.columns 
>>> df['sex'].reset_index()
       type              ticket     sex
0     train           A/5 21171    male
1     train            PC 17599  female

#get back 
df.loc['train', :]
df.loc['test', :]
df.loc[:, 'name' : 'sibsp']  #for all index 
df.loc[('train', '113803') , :] #one row 
df.iloc[3:4, :]  #DF 

#df.mode() gives DF of most frequent , take first col 
#replace NaN of 'fare' by mode of that 
df.loc[df['fare'].isnull(), 'fare'] = df['fare'].mode()[0]
#or could be used fillna as well 
df.fillna({'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] }, inplace=True)
#or could use replace 
df.replace({'fare':np.nan, 'embarked': np.nan}, {'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] }, inplace=True)

#drop cabin 
df.drop(columns='cabin', inplace=True)

#check any more null 
df[df.isnull().any(axis=1)]  #axis=1 is row 
df[df.isnull().any(axis=1)].loc['train',:]


#Setting up 
#Series.apply can take py fn or ufun, py fn- operates on eah element 
#df.apply has to be ufunc , if python func, vectorise with np.vectorize 
df['Title'] = df['name'].apply(lambda c: c[c.index(',') + 2 : c.index('.')])
df['LastName'] = df['name'].apply(lambda n: n[0:n.index(',')])

df['FamilySize'] = df['sibsp'] + df['parch'] + 1

df['FamilyID'] = df['LastName'] + ':' + df['FamilySize'].apply(str) #python fn, so operates on each element 
#if family size is <=2 
df.loc[df['FamilySize'] <= 2, 'FamilyID'] = 'Small_Family'

#convert age to 0 or 1 based on age is NaN or present 
df['AgeOriginallyNaN'] = df['age'].isnull().astype(int)

#for each title, get median age , and rename that column as AgeFilledMedianByTitle
medians_by_title = pd.DataFrame(df.groupby('Title')['age'].median()) \
  .rename(columns = {'age': 'AgeFilledMedianByTitle'}) #index is Title 
  
#Then for each row, fill AgeFilledMedianByTitle column 
#ie merge with df.Title with medians_by_title.index
#that merge would hamper original [train, test] sort order , hence sort_index 
df = df.merge(medians_by_title, left_on = 'Title', right_index = True) \
  .sort_index(level = 0).sort_index(level = 1) #by level 0 and the level=1 
  
#after processing , split 
df_train = df.ix['train']
df_test  = df.ix['test'].drop(columns=['survived'])

#Note Categoricals are embarked, pclass, sex , title, FamilyIDD 


#to create dummy variables out of categorical ones. 
#In Scikit ,algorithms accept only float variables.


transformations = [
                      ('embarked', LabelBinarizer()),
                      ('fare', None),
                      ('parch', None),
                      ('pclass', LabelBinarizer()),
                      ('sex', LabelBinarizer()),
                      ('sibsp', None),                                       
                      ('Title', LabelBinarizer()),
                      ('FamilySize', None),
                      ('FamilyID', LabelBinarizer()),
                      ('AgeOriginallyNaN', None),
                      ('AgeFilledMedianByTitle', None)]
                      
                      
%pip pip install sklearn-pandas
The mapper takes a list of tuples. 
Each tuple has three elements:
    column name(s): The first element is a column name from the pandas DataFrame, 
    or a list containing one or multiple columns 
    or an instance of a callable function such as make_column_selector.
    transformer(s): The second element is an object which will perform the transformation 
    which will be applied to that column.
    attributes: The third one is optional and is a dictionary containing the transformation options, 
    if applicable 
    #Example 
    >>> mapper = DataFrameMapper([
    ...     ('pet', sklearn.preprocessing.LabelBinarizer()),
    ...     (['children'], sklearn.preprocessing.StandardScaler())
    ... ])
    The difference between specifying the column selector as 'column' (as a simple string) 
    and ['column'] (as a list with one element) is the shape of the array that is passed to the transformer.
    In the first case, a one dimensional array will be passed, 
    while in the second case it will be a 2-dimensional array with one column, i.e. a column vector.



        
mapper = DataFrameMapper(transformations)

arr = mapper.fit_transform(df_train)


#Create pipeline 
pipeline = Pipeline([('featurize', mapper), ('forest', RandomForestClassifier())])

X = df_train[df_train.columns.drop('survived')]
y = df_train['survived']
model = pipeline.fit(X = X, y = y)
model.score(X, y)
#prediction
prediction = model.predict(df_test)  #their is no truth value 







###Validation curve 
#Execute 3.1.validation_curve_linear_regression.py

###Learning curve 
#Execute 3.2.learning_curve_linear_regression.py




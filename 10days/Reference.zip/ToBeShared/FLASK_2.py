##Example DB 
from sqlalchemy import * 
from flask import jsonify, g
app = ...

DATABASE = os.path.join(app.root_path,'people.db')
def get_db():
    db = getattr(g, '_database', None)  #do import g, g is global object in FLASK
    if db is None:
        db = g._database = create_engine("sqlite:///"+DATABASE)
    return db     
    
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        pass #db.close()
        
        
def getage(name):
    eg = get_db()
    with eg.connect() as conn:
        q = conn.execute(text("select age from people where name = :x") ,{'x': name})
        return q.fetchone()[0]

@app.route("/json", methods=['POST'])   # http://localhost:5000/json with jsondata
def js():
    user = dict(username='nobody', age="nonefound")
    if 'Content-Type' in request.headers and request.headers['Content-Type'].lower() == 'application/json':
        user['username'] = request.json.get("username", "nobody")
    try:
        user['age'] = getage(user['username'])
    except:
        pass
    resp = jsonify(user)
    resp.status_code = 200
    return resp  
    
'''
headers = {'Content-Type': 'application/json'}
import json
import requests as r 
obj = {'username' : 'das'}
res = r.post("http://localhost:5000/json", data=json.dumps(obj),headers=headers)
res.json() 
''' 

#Some data creation 
#https://docs.sqlalchemy.org/en/20/core/connections.html
from sqlalchemy import * 
DATABASE = "people.db"
db = create_engine("sqlite:///"+DATABASE)
with db.connect() as conn:
    conn.execute(text("""create table if not exists people (name string, age int)"""))
    conn.execute(text("""insert into people values(:x,:y)"""), {'x': "das", 'y': 20})
    conn.commit() #commit or rollback() is must 
    
with db.connect() as conn:
    q = conn.execute(text("select age from people where name=:x"), {'x': "das"})
    q.fetchall() #q.fetchone()


Note 
The “commit as you go” and “begin once” styles can be freely mixed 
within a single Engine.connect() block, provided that the call to Connection.begin() 
does not conflict with the “autobegin” behavior. 
To accomplish this, Connection.begin() should only be called either before any SQL statements 
have been emitted, or directly after a previous call to Connection.commit() 
or Connection.rollback():

with engine.connect() as connection:
    with connection.begin():
        # run statements in a "begin once" block
        connection.execute(some_table.insert(), {"x": 7, "y": "this is some data"})

    # transaction is committed

    # run a new statement outside of a block. The connection
    # autobegins
    connection.execute(
        some_other_table.insert(), {"q": 8, "p": "this is some more data"}
    )

    # commit explicitly
    connection.commit()

    # can use a "begin once" block here
    with connection.begin():
        # run more statements
        connection.execute(...)
        
##Application Globals - flask.g
#To share data that is valid for one request only from one function to another, 
#a global variable is not good enough because it would break in threaded environments. 
#Use flask.g , it is only valid for the active request 
#and that will return different values for each request. 

#methods 
'key' in g
iter(g)
g.get(name, default=None)
g.pop(name, default=<object object>)
g.setdefault(name, default=None)

##Nother exmaples 
import secrets

from flask import Flask, abort, g, jsonify, request

internal_token = "thisshouldbeanenvironmentvariable"

app = Flask(__name__)


def process_data():
    data = request.get_json()
    item_name = data["item_name"]
    token = g.token
    print(f"Do something with item: {item_name} using token: {token}")


@app.before_request
def verify_token():
    token = request.headers.get("x-token", "")
    if not secrets.compare_digest(
        token.encode("utf-8"), internal_token.encode("utf-8")
    ):
        abort(401)
    g.token = token


@app.route("/items/", methods=["POST"])
def create_item():
    data = request.get_json()
    token = g.token
    process_data()
    return jsonify({"data": data, "token": token})
##similar in fastAPI 
So, in FastAPI, you would probably pass any data needed directly via function parameters down the line.

import secrets

from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel

internal_token = "thisshouldbeanenvironmentvariable"

app = FastAPI()


class Item(BaseModel):
    name: str
    size: int = 0
    tags: set[str] = set()


def process_data(data: Item, token: str):
    item_name = data.name
    print(f"Do something with item: {item_name} using token: {token}")


def verify_token(x_token: str = Header()):
    if not secrets.compare_digest(
        x_token.encode("utf-8"), internal_token.encode("utf-8")
    ):
        raise HTTPException(401)
    return x_token


@app.post("/items/")
def create_item(item: Item, token: str = Depends(verify_token)):
    process_data(data=item, token=token)
    return {"data": item, "token": token}



##Quick Click    
What does it look like? Here is an example of a simple Click program:

import click

@click.command()
@click.option('--count', default=1, help='Number of greetings.')
@click.option('--name', prompt='Your name',help='The person to greet.')
def hello(count, name):
    """Simple program that greets NAME for a total of COUNT times."""
    for x in range(count):
        click.echo(f"Hello {name}!")

if __name__ == '__main__':
    hello()

And what it looks like when run:

python hello.py --count=3
Your name: John
Hello John!
Hello John!
Hello John!

It automatically generates nicely formatted help pages:

python hello.py --help
Usage: hello.py [OPTIONS]

  Simple program that greets NAME for a total of COUNT times.

Options:
  --count INTEGER  Number of greetings.
  --name TEXT      The person to greet.
  --help           Show this message and exit.

You can get the library directly from PyPI:

pip install click

##Using click - We need to packagify this 
mkdir flaskr
echo > flaskr\__init__.py
move  ..\quick_server.py flaskr\
move   ..\templates flaskr
move   ..\static flaskr
#__init__.py
from flask import Flask
app = Flask(__name__)
from . import quick_server
#Update quick_server.py
#from flask import Flask 
#app = Flask(__name__)
from flaskr import app

#Then add 
from flask import  g
import os.path 
from sqlalchemy import create_engine, text 

DATABASE = os.path.join(app.root_path,'database.db')

def get_db():
    db = getattr(g, '_database', None)  #do import g, g is global object in FLASK
    if db is None:
        db = g._database = create_engine("sqlite:///"+DATABASE)
    return db   

def init_db():
    db = get_db()
    with app.open_resource('schema.sql') as f:
        with db.connect().execution_options(autocommit=False) as conn:
            with conn.begin():
                for line in f.read().decode('utf8').split(";"):
                    conn.execute(text(line))   

import click 
from flask import cli 

@click.command('init-db')
@cli.with_appcontext
def init_db_command():
    """Clear the existing data and create new tables."""
    init_db()
    click.echo('Initialized the database.')

app.cli.add_command(init_db_command)


#Add schema.sql
DROP TABLE IF EXISTS people;
create table if not exists people (name string, age int);
insert into people values('das',20);
insert into people values('abc',30);

#open_resource() opens a file relative to the flaskr package,
from sqlalchemy import text
def init_db():
    db = get_db()
    with current_app.open_resource('schema.sql') as f:
        with engine.connect().execution_options(autocommit=False) as conn:
            with conn.begin():
                for line in f.read().decode('utf8').split(";"):
                    conn.execute(text(line))    



#Initialize the Database File
$ set FLASK_APP=flaskr
$ flask init-db
#Then run 
$ flask run 

##Example Login 
from flask import session, redirect, url_for #NEW
app.secret_key = b"jhdkjhdkhshd"  #NEW

from functools import wraps
def auth_required(f):
    @wraps(f)
    def _inner(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))  #login is method name 
        return f(*args, **kwargs)
    return _inner

    
@app.route("/")
@auth_required  #NEW, should be inner 
def home():   # http://localhost:5000/
    return """
            <html><body>
                <h1 id="some" class="cl2">Hello there!!! </h1>
                <h1 id="some2" class="cl2">Welcome</h1>
            </body></html>
        """

def check_auth(user, password):
    return user == 'admin' and password == 'secret'
   
@app.route("/login", methods=['GET', 'POST'])  # http://localhost:5000/login
def login():  
    if request.method == 'POST':
        name = request.form.get('name', 'all')
        password = request.form.get('pass', 'all')
        if check_auth(name, password):
            session['username'] = name
            return redirect(url_for('home'))  #home is method name 
        else:
            return "<h1>Error</h1>"
    else:
        return """
                <html><body>
                <form action="/login" method="post">
                 Name: <br/>
                 <input type="text" name="name" value="" />
                 Password: <br/>
                 <input type="password" name="pass" value="" />
                 <br/><br/>
                 <input type="submit" value="Submit" />
                </form>
                </body></html>
            """
        
'''
s = r.Session()
cred = {'name': 'admin', 'pass': 'secret'}
r1 = s.post("http://127.0.0.1:5000/login", cred)
r2 = s.get("http://127.0.0.1:5000/")
r2.text   
'''        
        
##Example upload 
import os
from flask import Flask, flash, request, redirect, url_for
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/upload', methods=['GET', 'POST']) #http://127.0.0.1:5000/upload
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file.filename:
            filename = secure_filename(file.filename) #normalizes the file path 
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('download',filename=filename))
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''
    
from flask import send_from_directory
#mimetype: str

#as_attachment: bool, attachment_filename:str, mimetype: str
@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)    
    
  
#with file upload and download 
files = {'file': open('copy.txt','rb')} #'file' same as form's name for type=file 
other_form_data = {'DB': 'photcat', 'OUT': 'csv', 'SHORT': 'short'}
r = requests.post("http://127.0.0.1:5000/upload", files=files, data=other_form_data)
r.request.url #'http://127.0.0.1:5000/download/copy.txt' , the redirected one 
r.status_code
r.headers.get('content-disposition') #'attachment; filename=copy.txt'
local_filename = r.headers.get('content-disposition').split("=")[-1]
with open(local_filename+".bak", 'wb') as f:
    f.write(r.content)

            
#for big file 
import shutil
with requests.get('http://127.0.0.1:5000/download/copy.txt', stream=True) as r:
    with open(local_filename+".bak2", 'wb') as f:
        shutil.copyfileobj(r.raw, f)           
        
        
###Middleware
The WSGI application above is a callable that behaves in a certain way. 
Middleware is a WSGI application that wraps another WSGI application. 

The outermost middleware will be called by the server. 
It can modify the data passed to it, then call the WSGI application (or further middleware) 
that it wraps, and so on. And it can take the return value of that call and modify it further.

From the WSGI server's perspective, there is one WSGI application, the one it calls directly. 
Typically, Flask is the "real" application at the end of the chain of middleware. 
But even Flask can call further WSGI applications, although that's an advanced, uncommon use case.

A common middleware you'll see used with Flask is Werkzeug's ProxyFix, 
which modifies the request to look like it came directly from a client even if it passed through 
HTTP proxies on the way. 

There are other middleware that can handle serving static files, authentication, etc.

##Example 
"""
CRUD - Using rest server 
db = people.db 
table = people

C  - POST /create  {"name": ..., "age": ...}
U - PUT /update/name  { "age": ...}
            If exists update, else ignores
D - DELETE /delete/name 
    if exists, delete, else ignores 
R - GET /all 
    list of dict of name and age 
    
"""
from flask import Flask, jsonify, g , request, session #a dict 
import os
from sqlalchemy import create_engine, text 
from functools import wraps

app = Flask(__name__)
SCHEMA = ["name", "age"]
app.secret_key = b"gjdagdkgkdgkagdkh"  
#for using session, above is required, this should long and super secret 
#it is used for signing session(by cookies)

#g in flask is a global object 
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        #create 
        DATABASE = os.path.join(app.root_path, "people.db")
        db = create_engine("sqlite:///" + DATABASE)
        g._database = db 
    return db 
    
def get_all():
    eng = get_db()
    with eng.connect() as conn:
        res = conn.execute(text("select name, age from people")).fetchall()
    return [dict(zip(SCHEMA,row)) for row in res]
    
def get_one(name):
    eng = get_db()
    with eng.connect() as conn:
        res = conn.execute(text("select age from people where name=:name"),
            dict(name=name)).fetchone()
    return res
  
def delete_one(name):
    eng = get_db()
    with eng.connect() as conn:
        conn.execute(text("delete from people where name=:name"),
                dict(name=name))
        conn.commit()
                
def update_one(name, age):
    eng = get_db()
    with eng.connect() as conn:
        conn.execute(text("Update people SET age=:age where name=:name"),
                dict(name=name, age=age))
        conn.commit()

def insert_one(name, age):
    eng = get_db()
    if get_one(name):
        return 
    with eng.connect() as conn:
        conn.execute(text("insert into people values(:name, :age)"),
                dict(name=name, age=age))
        conn.commit()
        
def auth_root(func):
    @wraps(func)
    def _inner(*args, **kwargs):
        if 'username' not in session:
            obj = dict(details="not logged in, Please log in at first")
            resp = jsonify(obj)
            resp.status_code = 401
            return resp 
        return func(*args, **kwargs)
    return _inner
#API 
#C  - POST /create  {"name": ..., "age": ...}
#U - PUT /update/name  { "age": ...}, If exists update, else ignores
#D - DELETE /delete/name ,     if exists, delete, else ignores 
#R - GET /all ,     list of dict of name and age 
@app.route("/all", methods=['GET'])
def get():
    obj = get_all()
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    
@app.route("/update/<string:name>", methods=['PUT'])
@auth_root      #must be inner most 
def update(name):
    age = None
    if 'Content-Type' in request.headers and \
            request.headers['Content-Type'] in ["application/json"]:
        age = request.json.get("age", None) 
    if age is None:
        obj = dict(name=name, details="no age in body, unable to update")
        status_code = 500
    else:
        print(name, age)
        update_one(name, age)
        obj=dict(name=name, details="updated")
        status_code = 200
    resp = jsonify(obj)
    resp.status_code = status_code
    return resp 
    
@app.route("/create", methods=['POST'])
@auth_root      #must be inner most 
def create():
    name, age = None, None
    if 'Content-Type' in request.headers and \
            request.headers['Content-Type'] in ["application/json"]:
        age = request.json.get("age", None) 
        name = request.json.get("name", None) 
    if age is None or name is None:
        obj = dict(details="no name/age in body, unable to update")
        status_code = 500
    else:
        insert_one(name, age)
        obj=dict(name=name, age=age, details="updated")
        status_code = 200
    resp = jsonify(obj)
    resp.status_code = status_code
    return resp 
    
@app.route("/delete/<string:name>", methods=['DELETE'])
@auth_root      #must be inner most 
def delete(name):
    delete_one(name)
    obj=dict(name=name, details="deleted")
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    

def check_pass(username, password):
    return username == 'admin' and password == 'verystrong'
    
@app.route("/login", methods=['POST'])
def login():
    username, password = None, None
    if 'Content-Type' in request.headers and \
            request.headers['Content-Type'] in ["application/json"]:
        username = request.json.get("username", None) 
        password = request.json.get("password", None) 
    if password is None or username is None or not check_pass(username, password):
        obj = dict(details="username or password is wrong")
        resp = jsonify(obj)
        resp.status_code = 401
        return resp 
    #signed in 
    session['username'] = username
    obj = dict(details="successfully logged in")
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    
@app.route("/logout", methods=['GET'])
def logout():
    if 'username' in session:
        del session['username'] 
    obj = dict(details="successfully logged out")
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    
    
if __name__ == '__main__':
    #http://localhost:5000
    app.run()
    
"""
import requests 
create = ("http://localhost:5000/create", 
            requests.post,
            dict(json = dict(name='das', age=5)))
update =  ("http://localhost:5000/update/das", 
            requests.put,
            dict(json = dict(age=15)))
get =   ("http://localhost:5000/all", 
            requests.get,
            {})          
delete = ("http://localhost:5000/delete/das", 
            requests.delete,
            {}) 
all = [create, update, get, delete]
for url, method, data in all:
    r = method(url, **data)
    print(r.json())
    
#With session 
sess = requests.Session()
#Try create, must fail 
url, method, data = create 
r = method(url, **data)
print(r.json())

#Now log in 
login = ("http://localhost:5000/login", 
            sess.post,
            dict(json = dict(username='admin', password="verystrong")))
            
create1 = ("http://localhost:5000/create", 
            sess.post,
            dict(json = dict(name='das', age=5)))
update1 =  ("http://localhost:5000/update/das", 
            sess.put,
            dict(json = dict(age=15)))
get1 =   ("http://localhost:5000/all", 
            sess.get,
            {})          
delete1 = ("http://localhost:5000/delete/das", 
            sess.delete,
            {})  
            
all = [login, create1, update1, get1, delete1]
for url, method, data in all:
    r = method(url, **data)
    print(r.json())
    
    
#Anybody can do all 
get2 =   ("http://localhost:5000/all", 
            sess.get,
            {}) 
            
url, method, data = get2 
r = method(url, **data)
print(r.json())


#Now logout 
logout = ("http://localhost:5000/logout", 
            sess.get,
            {})  
url, method, data = logout 
r = method(url, **data)
print(r.json())      
            
sess.close()
"""

###Flask-HTTPAuth
https://github.com/miguelgrinberg/Flask-HTTPAuth/tree/main/examples

Flask-HTTPAuth is a Flask extension that simplifies the use of HTTP authentication with Flask routes.
##Basic authentication examples

The following example application uses HTTP Basic authentication to protect route '/':

from flask import Flask
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'my secret'
auth = HTTPBasicAuth()

users = {
    "john": generate_password_hash("hello"),
    "susan": generate_password_hash("bye")
}

@auth.error_handler
def auth_error(status):
    """If defined, this callback function will be called by the framework 
    when it is necessary to send an authentication error back to the client. 
    The function can take one argument, the status code of the error, 
    which can be 401 (incorrect credentials) or 403 (correct, but insufficient credentials)
    """
    return "Access Denied", status

@auth.verify_password
def verify_password(username, password):
    if username in users and \
            check_password_hash(users.get(username), password):
        return username

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.current_user())

if __name__ == '__main__':
    app.run()

The function decorated with the verify_password decorator receives the username 
and password sent by the client. If the credentials belong to a user, 
then the function should return the user object. 

If the credentials are invalid the function can return None or False. 
The user object can then be queried from the current_user() method of the authentication instance.


#Testing 
import unittest
import base64
from flask import Flask
from flask_httpauth import HTTPBasicAuth


class HTTPAuthTestCase(unittest.TestCase):
    def setUp(self):
        app = Flask(__name__)
        app.config['SECRET_KEY'] = 'my secret'

        basic_auth = HTTPBasicAuth()

        @basic_auth.get_password
        def get_basic_password(username):
            if username == 'john':
                return 'hello'
            elif username == 'susan':
                return 'bye'
            else:
                return None

        @app.route('/')
        def index():
            return 'index'

        @app.route('/basic')
        @basic_auth.login_required
        def basic_auth_route():
            return 'basic_auth:' + basic_auth.username()

        self.app = app
        self.basic_auth = basic_auth
        self.client = app.test_client()

    def test_no_auth(self):
        response = self.client.get('/')
        self.assertEqual(response.data.decode('utf-8'), 'index')

    def test_basic_auth_prompt(self):
        response = self.client.get('/basic')
        self.assertEqual(response.status_code, 401)
        self.assertTrue('WWW-Authenticate' in response.headers)
        self.assertEqual(response.headers['WWW-Authenticate'],
                         'Basic realm="Authentication Required"')

    def test_basic_auth_ignore_options(self):
        response = self.client.options('/basic')
        self.assertEqual(response.status_code, 200)
        self.assertTrue('WWW-Authenticate' not in response.headers)

    def test_basic_auth_login_valid(self):
        creds = base64.b64encode(b'john:hello').decode('utf-8')
        response = self.client.get(
            '/basic', headers={'Authorization': 'Basic ' + creds})
        self.assertEqual(response.data.decode('utf-8'), 'basic_auth:john')

    def test_basic_auth_login_invalid(self):
        creds = base64.b64encode(b'john:bye').decode('utf-8')
        response = self.client.get(
            '/basic', headers={'Authorization': 'Basic ' + creds})
        self.assertEqual(response.status_code, 401)
        self.assertTrue('WWW-Authenticate' in response.headers)
        self.assertEqual(response.headers['WWW-Authenticate'],
                         'Basic realm="Authentication Required"')
                         

##Digest authentication example
https://en.wikipedia.org/wiki/Digest_access_authentication
Steps: 
Client makes request
Client gets back a nonce from the server and a 401 authentication request

Client sends back the following response array 
(username, realm, generate_md5_key(nonce, username, realm, URI, password_given_by_user_to_browser)) 

The server takes username and realm (plus it knows the URI the client is requesting) 
and it looks up the password for that username. 
Then it goes and does its own version of 
generate_md5_key(nonce, username, realm, URI, password_I_have_for_this_user_in_my_db)

It compares the output of generate_md5() that it got with the one the client sent, 
if they match the client sent the correct password. 
If they don't match the password sent was wrong.

    

from flask import Flask
from flask_httpauth import HTTPDigestAuth

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret key here'
auth = HTTPDigestAuth()

users = {
    "john": "hello",
    "susan": "bye"
}

@auth.get_password
def get_pw(username):
    if username in users:
        return users.get(username)
    return None

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.username())

if __name__ == '__main__':
    app.run()
    
#Reference 
__init__(self, scheme=None, realm=None, use_ha1_pw=False, qop='auth', algorithm='MD5')
    Create a digest authentication object.

    If the optional scheme argument is provided, 
    it will be used instead of the 'Digest' scheme in the WWW-Authenticate response. 
    A fairly common practice is to use a custom scheme to prevent browsers 
    from prompting the user to login.

    The realm argument can be used to provide an application defined realm 
    with the WWW-Authenticate header.

    If use_ha1_pw is False, then the get_password callback needs to 
    return the plain text password for the given user. If use_ha1_pw is True, 
    the get_password callback needs to return the HA1 value for the given user. 
    The advantage of setting use_ha1_pw to True is that it allows the application 
    to store the HA1 hash of the password in the user database.

    The qop option configures a list of accepted quality of protection extensions. 
    This argument can be given as a comma-separated string, a list of strings, or None to disable. 
    The default is auth. The auth-int option is currently not implemented.

    The algorithm option configures the hash generation algorithm to use. 
    The default is MD5. The two algorithms that are implemented are MD5 and MD5-Sess.

    generate_ha1(username, password)
        Generate the HA1 hash that can be stored in the user database 
        when use_ha1_pw is set to True in the constructor.
        
Note 
opaque. A string of data, specified by the server, 
that SHOULD be returned by the client unchanged in the Authorization header 
field of subsequent requests with URIs in the same protection space. 
It is RECOMMENDED that this string be Base64 or hexadecimal data

The nc parameter stands for "nonce count". The nc value is the hexadecimal count of the number 
of requests (including the current request) that the client has sent with the nonce value 
in this request. For example, in the first request sent in response to a given nonce value, 
the client sends "nc=00000001"

Nonce - A unique string specified by the server in the WWW-Authenticate response header
        
Client request (no authentication)

GET /dir/index.html HTTP/1.0
Host: localhost

(followed by a new line, in the form of a carriage return followed by a line feed).[13]

Server response

HTTP/1.0 401 Unauthorized
Server: HTTPd/0.9
Date: Sun, 10 Apr 2014 20:26:47 GMT
WWW-Authenticate: Digest realm="testrealm@host.com",
                        qop="auth,auth-int",
                        nonce="dcd98b7102dd2f0e8b11d0f600bfb0c093",
                        opaque="5ccc069c403ebaf9f0171e9517f40e41"
Content-Type: text/html
Content-Length: 153

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Error</title>
  </head>
  <body>
    <h1>401 Unauthorized.</h1>
  </body>
</html>

Client request (username "Mufasa", password "Circle Of Life")

GET /dir/index.html HTTP/1.0
Host: localhost
Authorization: Digest username="Mufasa",
                     realm="testrealm@host.com",
                     nonce="dcd98b7102dd2f0e8b11d0f600bfb0c093",
                     uri="/dir/index.html",
                     qop=auth,
                     nc=00000001,
                     cnonce="0a4f113b",
                     response="6629fae49393a05397450978507c4ef1",
                     opaque="5ccc069c403ebaf9f0171e9517f40e41"

(followed by a blank line, as before).

Server response

HTTP/1.0 200 OK
Server: HTTPd/0.9
Date: Sun, 10 Apr 2005 20:27:03 GMT
Content-Type: text/html
Content-Length: 7984


#Testing 
import unittest
import re
import pytest
from hashlib import md5 as basic_md5
from flask import Flask
from flask_httpauth import HTTPDigestAuth
from werkzeug.http import parse_dict_header


def md5(str):
    if type(str).__name__ == 'str':
        str = str.encode('utf-8')
    return basic_md5(str)


def get_ha1(user, pw, realm):
    a1 = user + ":" + realm + ":" + pw
    return md5(a1).hexdigest()


class HTTPAuthTestCase(unittest.TestCase):
    def setUp(self):
        app = Flask(__name__)
        app.config['SECRET_KEY'] = 'my secret'

        digest_auth = HTTPDigestAuth()

        @digest_auth.get_password
        def get_digest_password_2(username):
            if username == 'susan':
                return 'hello'
            elif username == 'john':
                return 'bye'
            else:
                return None

        @app.route('/')
        def index():
            return 'index'

        @app.route('/digest')
        @digest_auth.login_required
        def digest_auth_route():
            return 'digest_auth:' + digest_auth.username()

        self.app = app
        self.digest_auth = digest_auth
        self.client = app.test_client()


    def test_digest_auth_prompt(self):
        response = self.client.get('/digest')
        self.assertEqual(response.status_code, 401)
        self.assertTrue('WWW-Authenticate' in response.headers)
        self.assertTrue(re.match(r'^Digest realm="Authentication Required",'
                                 r'nonce="[0-9a-f]+",opaque="[0-9a-f]+",'
                                 r'algorithm="MD5",qop="auth"$',
                                 response.headers['WWW-Authenticate']))

    def test_digest_auth_ignore_options(self):
        response = self.client.options('/digest')
        self.assertEqual(response.status_code, 200)
        self.assertTrue('WWW-Authenticate' not in response.headers)

    def test_digest_auth_login_valid(self):
        response = self.client.get('/digest')
        self.assertTrue(response.status_code == 401)
        header = response.headers.get('WWW-Authenticate')
        auth_type, auth_info = header.split(None, 1)
        d = parse_dict_header(auth_info)
        """
        >>> d = parse_dict_header('foo="is a fish", bar="as well"')
        >>> type(d) is dict
        True
        >>> sorted(d.items())
        [('bar', 'as well'), ('foo', 'is a fish')]        
        """

        a1 = 'john:' + d['realm'] + ':bye'
        ha1 = md5(a1).hexdigest()
        a2 = 'GET:/digest'
        ha2 = md5(a2).hexdigest()
        #nc and cnonce are client side  once use no 
        a3 = ha1 + ':' + d['nonce'] + ':00000001:foobar:auth:' + ha2
        auth_response = md5(a3).hexdigest()

        response = self.client.get(
            '/digest', headers={
                'Authorization': 'Digest username="john",realm="{0}",'
                                 'nonce="{1}",uri="/digest",qop=auth,'
                                 'nc=00000001,cnonce="foobar",response="{2}",'
                                 'opaque="{3}"'.format(d['realm'],
                                                       d['nonce'],
                                                       auth_response,
                                                       d['opaque'])})
        self.assertEqual(response.data, b'digest_auth:john')

    def test_digest_auth_md5_sess_login_valid(self):
        self.digest_auth.algorithm = 'MD5-Sess'

        response = self.client.get('/digest')
        self.assertTrue(response.status_code == 401)
        header = response.headers.get('WWW-Authenticate')
        auth_type, auth_info = header.split(None, 1)
        d = parse_dict_header(auth_info)

        a1 = 'john:' + d['realm'] + ':bye'
        ha1 = md5(
            md5(a1).hexdigest() + ':' + d['nonce'] + ':foobar').hexdigest()
        a2 = 'GET:/digest'
        ha2 = md5(a2).hexdigest()
        a3 = ha1 + ':' + d['nonce'] + ':00000001:foobar:auth:' + ha2
        auth_response = md5(a3).hexdigest()

        response = self.client.get(
            '/digest', headers={
                'Authorization': 'Digest username="john",realm="{0}",'
                                 'nonce="{1}",uri="/digest",qop=auth,'
                                 'nc=00000001,cnonce="foobar",response="{2}",'
                                 'opaque="{3}"'.format(d['realm'],
                                                       d['nonce'],
                                                       auth_response,
                                                       d['opaque'])})
        self.assertEqual(response.data, b'digest_auth:john')


##Token Authentication Example
The following example application uses a custom HTTP authentication scheme to protect route '/' 
with a token:

from flask import Flask
from flask_httpauth import HTTPTokenAuth

app = Flask(__name__)
auth = HTTPTokenAuth(scheme='Bearer')

tokens = {
    "secret-token-1": "john",
    "secret-token-2": "susan"
}

@auth.verify_token
def verify_token(token):
    if token in tokens:
        return tokens[token]

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.current_user())

if __name__ == '__main__':
    app.run()

The HTTPTokenAuth is a generic authentication handler that can be used 
with non-standard authentication schemes, 
with the scheme name given as an argument in the constructor. 

In the above example, the WWW-Authenticate header provided by the server will use Bearer as scheme:

WWW-Authenticate: Bearer realm="Authentication Required"

The verify_token callback receives the authentication credentials provided 
by the client on the Authorization header. 

This can be a simple token, or can contain multiple arguments, 
which the function will have to parse and extract from the string. 

As with the verify_password, the function should return the user object if the token is valid.

#Reference 
 class flask_httpauth.HTTPTokenAuth

    This class handles HTTP authentication with custom schemes for Flask routes.
    __init__(scheme='Bearer', realm=None, header=None)
        Create a token authentication object.
        The scheme argument can be use to specify the scheme to be used 
        in the WWW-Authenticate response. 
        The Authorization header sent by the client must include this scheme followed by the token. 
        Example:

        Authorization: Bearer this-is-my-token

        The realm argument can be used to provide an application defined realm 
        with the WWW-Authenticate header.

        The header argument can be used to specify a custom header instead of Authorization 
        from where to obtain the token. If a custom header is used, the scheme should not be included. 
        Example:

        X-API-Key: this-is-my-token


#Testing 
import base64
import unittest
from flask import Flask
from flask_httpauth import HTTPTokenAuth


class HTTPAuthTestCase(unittest.TestCase):
    def setUp(self):
        app = Flask(__name__)
        app.config['SECRET_KEY'] = 'my secret'

        token_auth = HTTPTokenAuth('MyToken')
        token_auth2 = HTTPTokenAuth('Token', realm='foo')
        token_auth3 = HTTPTokenAuth(header='X-API-Key')

        @token_auth.verify_token
        def verify_token(token):
            if token == 'this-is-the-token!':
                return 'user'

        @token_auth3.verify_token
        def verify_token3(token):
            if token == 'this-is-the-token!':
                return 'user'

        @token_auth.error_handler
        def error_handler():
            return 'error', 401, {'WWW-Authenticate': 'MyToken realm="Foo"'}

        @app.route('/')
        def index():
            return 'index'

        @app.route('/protected')
        @token_auth.login_required
        def token_auth_route():
            return 'token_auth:' + token_auth.current_user()

        @app.route('/protected-optional')
        @token_auth.login_required(optional=True)
        def token_auth_optional_route():
            return 'token_auth:' + str(token_auth.current_user())

        @app.route('/protected2')
        @token_auth2.login_required
        def token_auth_route2():
            return 'token_auth2'

        @app.route('/protected3')
        @token_auth3.login_required
        def token_auth_route3():
            return 'token_auth3:' + token_auth3.current_user()

        self.app = app
        self.token_auth = token_auth
        self.client = app.test_client()

    def test_token_auth_prompt(self):
        response = self.client.get('/protected')
        self.assertEqual(response.status_code, 401)
        self.assertTrue('WWW-Authenticate' in response.headers)
        self.assertEqual(response.headers['WWW-Authenticate'],
                         'MyToken realm="Foo"')

    def test_token_auth_ignore_options(self):
        response = self.client.options('/protected')
        self.assertEqual(response.status_code, 200)
        self.assertTrue('WWW-Authenticate' not in response.headers)

    def test_token_auth_login_valid(self):
        response = self.client.get(
            '/protected', headers={'Authorization':
                                   'MyToken this-is-the-token!'})
        self.assertEqual(response.data.decode('utf-8'), 'token_auth:user')

    def test_token_auth_login_valid_different_case(self):
        response = self.client.get(
            '/protected', headers={'Authorization':
                                   'mytoken this-is-the-token!'})
        self.assertEqual(response.data.decode('utf-8'), 'token_auth:user')

    def test_token_auth_login_optional(self):
        response = self.client.get('/protected-optional')
        self.assertEqual(response.data.decode('utf-8'), 'token_auth:None')

    def test_token_auth_login_invalid_token(self):
        response = self.client.get(
            '/protected', headers={'Authorization':
                                   'MyToken this-is-not-the-token!'})
        self.assertEqual(response.status_code, 401)
        self.assertTrue('WWW-Authenticate' in response.headers)
        self.assertEqual(response.headers['WWW-Authenticate'],
                         'MyToken realm="Foo"')

##User Roles
To enable role support, write a function that returns the list of roles for a given user and decorate it with the get_user_roles decorator:

@auth.get_user_roles
def get_user_roles(user):
    return user.get_roles()


To restrict access to a route to users having a given role, add the role argument to the login_required decorator:

@app.route('/admin')
@auth.login_required(role='admin')
def admins_only():
    return "Hello {}, you are an admin!".format(auth.current_user())

The role argument can take a list of roles, in which case users who have 
any of the given roles will be granted access:

@app.route('/admin')
@auth.login_required(role=['admin', 'moderator'])
def admins_only():
    return "Hello {}, you are an admin or a moderator!".format(auth.current_user())

In the most advanced usage, users can be filtered by having multiple roles:

@app.route('/admin')
@auth.login_required(role=['user', ['moderator', 'contributor']])
def admins_only():
    return "Hello {}, you are a user or a moderator/contributor!".format(auth.c

###SQLAlchemy
$ pip install -U Flask-SQLAlchemy

##Initialize the Extension

First create the db object using the SQLAlchemy constructor.

Pass a subclass of either DeclarativeBase or DeclarativeBaseNoMeta to the constructor.

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
  pass

#https://flask-sqlalchemy.readthedocs.io/en/stable/api/#flask_sqlalchemy.SQLAlchemy
db = SQLAlchemy(model_class=Base)


Once constructed, the db object gives you access to the db.Model class to define models, 
and the db.session to execute queries.

The SQLAlchemy object also takes additional arguments to customize the objects it manages.

##Configure the Extension
The next step is to connect the extension to your Flask app. 
The only required Flask app config is the SQLALCHEMY_DATABASE_URI key. 
That is a connection string that tells SQLAlchemy what database to connect to.


# create the app
app = Flask(__name__)
# configure the SQLite database, relative to the app instance folder
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
# initialize the app with the extension
db.init_app(app)

##Define Models
https://flask-sqlalchemy.readthedocs.io/en/stable/models/

SQLAlchemy 2.x offers several possible base classes for your models: DeclarativeBase or DeclarativeBaseNoMeta.
https://docs.sqlalchemy.org/en/20/orm/mapping_api.html#sqlalchemy.orm.DeclarativeBase
https://docs.sqlalchemy.org/en/20/orm/mapping_api.html#sqlalchemy.orm.DeclarativeBaseNoMeta
If desired, you can enable SQLAlchemy’s native support for data classes by adding MappedAsDataclass 
as an additional parent class.

dataclass is quick class to generate many default methods 
https://docs.python.org/3/library/dataclasses.html

from dataclasses import dataclass

@dataclass
class InventoryItem:
    """Class for keeping track of an item in inventory."""
    name: str
    unit_price: float
    quantity_on_hand: int = 0

    def total_cost(self) -> float:
        return self.unit_price * self.quantity_on_hand
        


Subclass db.Model to define a model class. The model will generate a table name 
by converting the CamelCase class name to snake_case.

from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

class User(db.Model):
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(unique=True)
    email: Mapped[str]

originally Column was used in the lower "core"/sqlalchemy.sql layer AND the higher ORM layer. 
This created a conflict of purpose. So mapped_column now supersedes Column 
when using the ORM layer to add more functionality that can't be used by the core layer. 
The core layer will keep using Column
https://docs.sqlalchemy.org/en/20/orm/declarative_tables.html#declarative-table-with-mapped-column


##Create the Tables
After all models and tables are defined, call SQLAlchemy.create_all() to create the table schema 
in the database. This requires an application context. 
Since you’re not in a request at this point, create one manually.

with app.app_context():
    db.create_all()

If you define models in other modules, you must import them before calling create_all, 
otherwise SQLAlchemy will not know about them.

create_all does not update tables if they are already in the database. 
If you change a model’s columns, use a migration library like Alembic with Flask-Alembic 
or Flask-Migrate to generate migrations that update the database schema.

##Query the Data
Within a Flask view or CLI command, you can use db.session to execute queries and modify model data.

SQLAlchemy automatically defines an __init__ method for each model that assigns 
any keyword arguments to corresponding database columns and other attributes.

db.session.add(obj) adds an object to the session, to be inserted. 
Modifying an object’s attributes updates the object. 
db.session.delete(obj) deletes an object. 

Remember to call db.session.commit() after modifying, adding, or deleting any data.

db.session.execute(db.select(...)) constructs a query to select data from the database. 

@app.route("/users")
def user_list():
    users = db.session.execute(db.select(User).order_by(User.username)).scalars()
    return render_template("user/list.html", users=users)

@app.route("/users/create", methods=["GET", "POST"])
def user_create():
    if request.method == "POST":
        user = User(
            username=request.form["username"],
            email=request.form["email"],
        )
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("user_detail", id=user.id))

    return render_template("user/create.html")

@app.route("/user/<int:id>")
def user_detail(id):
    user = db.get_or_404(User, id)
    return render_template("user/detail.html", user=user)

@app.route("/user/<int:id>/delete", methods=["GET", "POST"])
def user_delete(id):
    user = db.get_or_404(User, id)

    if request.method == "POST":
        db.session.delete(user)
        db.session.commit()
        return redirect(url_for("user_list"))

    return render_template("user/delete.html", user=user)



        
###Packaging 
STEP1: CREATE below 
poetry new flaskr
cd flaskr



#ONLy for Office PC 
Given index-url = https://<<SERVER>>/artifactory/api/pypi/<<LOCATION>>/simple/
pip config list 

poetry source add --priority=default ourpypi index-url
poetry source add --priority=supplemental PyPI

#where venv to be created 
poetry config virtualenvs.in-project true 

#STEP1.1
poetry add flask gevent

Copy static, templates and quick_server.py inside flaskr\flaskr

STEP2: UPDATE
#flaskr\flaskr\__init__.py
from flask import Flask
app = Flask(__name__)
from . import quick_server
#Update flaskr\flaskr\quick_server.py
#app = Flask(__name__)  #comment this line 
from flaskr import app

STEP3: TEST 
poetry env info
poetry shell
set FLASK_APP=flaskr 
flask run   # run whatever set in FLASK_APP

STEP4:
exit
poetry build -v
#You can find the file in dist/flaskr-0.1.0-py3-none-any.whl

FURTHER TEST 
cd ..
python -m venv .\env 
.\env\Scripts\activate
pip install flaskr/dist/flaskr-0.1.0-py3-none-any.whl
set FLASK_APP=flaskr 
flask run 


Install 
$ pip install --force-reinstall --no-dependencies dist/flaskr-0.1.0-py3-none-any.whl

STEP4:
##Deployment
#https://flask.palletsprojects.com/en/1.1.x/deploying/wsgi-standalone/

# For example to deploy via  Gevent 
pip install gevent 
#Gevent is a coroutine-based Python networking library 
#that uses greenlet to provide a high-level synchronous API on top of libev event loop:

#Execute by 'python gevent_server.py'
#gevent_server.py
from gevent.pywsgi import WSGIServer
from flaskr import app

# http_server = WSGIServer(('localhost', 443), app, keyfile='key.pem', certfile='cert.pem')
http_server = WSGIServer(('localhost', 8080), app)
http_server.serve_forever()

##To generate self signed certificate 
Note cert.pem may have public ip or localhost 
But whatever it has , must be the same as given in above 'http_server'

import requests
r = requests.get("https://localhost/helloj?name=das&format=json", verify=False)
r = requests.get("https://localhost/helloj?name=das&format=json", verify="./cert.pem")

#Create - instead of localhost, gives public IP 
#-nodes (short for no DES) for no  passphrase(else min 4 character passphrase) 
(check by 'where openssl.exe' ) 
$ openssl req -x509 -subj '/CN=localhost' -nodes -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365


Note for subjectAltName error
Check 
https://gist.github.com/KeithYeh/bb07cadd23645a6a62509b1ec8986bbc
https://serverfault.com/questions/845766/generating-a-self-signed-cert-with-openssl-that-works-in-chrome-58

###CODE-WALKTHROUGH  - Integration with React 
#Main code 
from flask import Flask, request, jsonify, render_template, make_response 
import json , os 
import logging

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

@app.route("/env", methods=['GET','POST'])#http://localhost:5000/env or http://localhost:5000/env?render=reactjsx
def env():
    if request.method == 'POST':
        envp = request.form.get('envp', 'all').upper()
        app.logger.info(str(request.form))
        env_dict = os.environ
        if os.environ.get(envp, "notfound") != "notfound":
            env_dict = { envp : os.environ.get(envp,"notfound") }            
        #get it from URL params         
        return render_template("template_file", envs=env_dict)
    else:
        return f"""
            <html><body>
            <form action="/env" method="post">
              Put Variable name :<br>
              <input type="text" name="envp" value="ALL"><br>
              <input type="submit" value="Submit">
            </form> 
            </body></html>
        """
        

if __name__ == '__main__':
    app.run()    

#React code 
'use strict';

class BeautifulButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = { liked: false };
  }

  render() {
    if (this.state.liked) {      
      window.alert(this.props.k+"="+this.props.v)
      this.setState({ liked: false })
    }

    //synthetic events - https://reactjs.org/docs/events.html
    return <button onClick={() => this.setState({ liked: true })}>
            {this.props.k}
           </button>
  }
}

// Find all DOM containers, and render Like buttons into them.
document.querySelectorAll('.show_box')
  .forEach(domContainer => {
    // Read the k,v from a data-* attribute.
    const k_value = domContainer.dataset.k;
    const v_value = domContainer.dataset.v;
    ReactDOM.render(
      <BeautifulButton k={k_value} v={v_value} />,
      domContainer
    );
  });

#base template 
<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>{% block title %}{% endblock %}</title>
</head>
<body>
    {% block content %}
    {% endblock %}
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <!-- Note: when deploying, replace "development.js" with "production.min.js". -->
    <script src="https://unpkg.com/react@17/umd/react.production.min.js" crossorigin></script>
    <script src="https://unpkg.com/react-dom@17/umd/react-dom.production.min.js" crossorigin></script>
    //babel for JSX 
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <!-- Load our React component. -->
    <script type="text/babel" src="/static/like_button_jsx.js"></script>
</body>
</html>
#view template 
{% extends "base_react_jsx.html" %}
{% block title %}Give Env{% endblock %}
{% block content %}


<table class="table table-dark table-striped">
<tr><th>Key</th><th>Value</th></tr>
{% for k,v in envs.items() %}
<tr><td><div class="show_box" data-k="{{k}}" data-v="{{v}}"></div> </td><td>{{v}}</td></tr>
{% endfor %}
</table>
{% endblock %}

###CODE-WALKTHROUGH  - Tutorials 

/home/user/Projects/flask-tutorial
├── flaskr/
│   ├── __init__.py
│   ├── db.py
│   ├── schema.sql
│   ├── auth.py
│   ├── blog.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── auth/
│   │   │   ├── login.html
│   │   │   └── register.html
│   │   └── blog/
│   │       ├── create.html
│   │       ├── index.html
│   │       └── update.html
│   └── static/
│       └── style.css
├── tests/
│   ├── conftest.py
│   ├── data.sql
│   ├── test_factory.py
│   ├── test_db.py
│   ├── test_auth.py
│   └── test_blog.py
├── venv/
├── setup.py
└── MANIFEST.in


> set FLASK_APP=flaskr
> set FLASK_ENV=development
> flask init-db
> flask run
    




##->file:.\tutorial\pyproject.toml:
[project]
name = "flaskr"
version = "1.0.0"
description = "The basic blog app built in the Flask tutorial."
readme = "README.rst"
license = {text = "BSD-3-Clause"}
maintainers = [{name = "Pallets", email = "contact@palletsprojects.com"}]
dependencies = [
    "flask",
]

[project.urls]
Documentation = "https://flask.palletsprojects.com/tutorial/"

[project.optional-dependencies]
test = ["pytest"]

[build-system]
requires = ["flit_core<4"]
build-backend = "flit_core.buildapi"

[tool.flit.module]
name = "flaskr"

[tool.flit.sdist]
include = [
    "tests/",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
filterwarnings = ["error"]

[tool.coverage.run]
branch = true
source = ["flaskr", "tests"]

[tool.ruff]
src = ["src"]



##->file:.\tutorial\README.rst:
Flaskr
======

The basic blog app built in the Flask `tutorial`_.

.. _tutorial: https://flask.palletsprojects.com/tutorial/


Install
-------

**Be sure to use the same version of the code as the version of the docs
you're reading.** You probably want the latest tagged version, but the
default Git version is the main branch. ::

    # clone the repository
    $ git clone https://github.com/pallets/flask
    $ cd flask
    # checkout the correct version
    $ git tag  # shows the tagged versions
    $ git checkout latest-tag-found-above
    $ cd examples/tutorial

Create a virtualenv and activate it::

    $ python3 -m venv .venv
    $ . .venv/bin/activate

Or on Windows cmd::

    $ py -3 -m venv .venv
    $ .venv\Scripts\activate.bat

Install Flaskr::

    $ pip install -e .

Or if you are using the main branch, install Flask from source before
installing Flaskr::

    $ pip install -e ../..
    $ pip install -e .


Run
---

.. code-block:: text

    $ flask --app flaskr init-db
    $ flask --app flaskr run --debug

Open http://127.0.0.1:5000 in a browser.


Test
----

::

    $ pip install '.[test]'
    $ pytest

Run with coverage report::

    $ coverage run -m pytest
    $ coverage report
    $ coverage html  # open htmlcov/index.html in a browser



##->file:.\tutorial\flaskr\auth.py:
import functools

from flask import Blueprint
from flask import flash
from flask import g
from flask import redirect
from flask import render_template
from flask import request
from flask import session
from flask import url_for
from werkzeug.security import check_password_hash
from werkzeug.security import generate_password_hash

from .db import get_db

bp = Blueprint("auth", __name__, url_prefix="/auth")


def login_required(view):
    """View decorator that redirects anonymous users to the login page."""

    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for("auth.login"))

        return view(**kwargs)

    return wrapped_view


@bp.before_app_request
def load_logged_in_user():
    """If a user id is stored in the session, load the user object from
    the database into ``g.user``."""
    user_id = session.get("user_id")

    if user_id is None:
        g.user = None
    else:
        g.user = (
            get_db().execute("SELECT * FROM user WHERE id = ?", (user_id,)).fetchone()
        )


@bp.route("/register", methods=("GET", "POST"))
def register():
    """Register a new user.

    Validates that the username is not already taken. Hashes the
    password for security.
    """
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        db = get_db()
        error = None

        if not username:
            error = "Username is required."
        elif not password:
            error = "Password is required."

        if error is None:
            try:
                db.execute(
                    "INSERT INTO user (username, password) VALUES (?, ?)",
                    (username, generate_password_hash(password)),
                )
                db.commit()
            except db.IntegrityError:
                # The username was already taken, which caused the
                # commit to fail. Show a validation error.
                error = f"User {username} is already registered."
            else:
                # Success, go to the login page.
                return redirect(url_for("auth.login"))

        flash(error)

    return render_template("auth/register.html")


@bp.route("/login", methods=("GET", "POST"))
def login():
    """Log in a registered user by adding the user id to the session."""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        db = get_db()
        error = None
        user = db.execute(
            "SELECT * FROM user WHERE username = ?", (username,)
        ).fetchone()

        if user is None:
            error = "Incorrect username."
        elif not check_password_hash(user["password"], password):
            error = "Incorrect password."

        if error is None:
            # store the user id in a new session and return to the index
            session.clear()
            session["user_id"] = user["id"]
            return redirect(url_for("index"))

        flash(error)

    return render_template("auth/login.html")


@bp.route("/logout")
def logout():
    """Clear the current session, including the stored user id."""
    session.clear()
    return redirect(url_for("index"))



##->file:.\tutorial\flaskr\blog.py:
from flask import Blueprint
from flask import flash
from flask import g
from flask import redirect
from flask import render_template
from flask import request
from flask import url_for
from werkzeug.exceptions import abort

from .auth import login_required
from .db import get_db

bp = Blueprint("blog", __name__)


@bp.route("/")
def index():
    """Show all the posts, most recent first."""
    db = get_db()
    posts = db.execute(
        "SELECT p.id, title, body, created, author_id, username"
        " FROM post p JOIN user u ON p.author_id = u.id"
        " ORDER BY created DESC"
    ).fetchall()
    return render_template("blog/index.html", posts=posts)


def get_post(id, check_author=True):
    """Get a post and its author by id.

    Checks that the id exists and optionally that the current user is
    the author.

    :param id: id of post to get
    :param check_author: require the current user to be the author
    :return: the post with author information
    :raise 404: if a post with the given id doesn't exist
    :raise 403: if the current user isn't the author
    """
    post = (
        get_db()
        .execute(
            "SELECT p.id, title, body, created, author_id, username"
            " FROM post p JOIN user u ON p.author_id = u.id"
            " WHERE p.id = ?",
            (id,),
        )
        .fetchone()
    )

    if post is None:
        abort(404, f"Post id {id} doesn't exist.")

    if check_author and post["author_id"] != g.user["id"]:
        abort(403)

    return post


@bp.route("/create", methods=("GET", "POST"))
@login_required
def create():
    """Create a new post for the current user."""
    if request.method == "POST":
        title = request.form["title"]
        body = request.form["body"]
        error = None

        if not title:
            error = "Title is required."

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                "INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)",
                (title, body, g.user["id"]),
            )
            db.commit()
            return redirect(url_for("blog.index"))

    return render_template("blog/create.html")


@bp.route("/<int:id>/update", methods=("GET", "POST"))
@login_required
def update(id):
    """Update a post if the current user is the author."""
    post = get_post(id)

    if request.method == "POST":
        title = request.form["title"]
        body = request.form["body"]
        error = None

        if not title:
            error = "Title is required."

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                "UPDATE post SET title = ?, body = ? WHERE id = ?", (title, body, id)
            )
            db.commit()
            return redirect(url_for("blog.index"))

    return render_template("blog/update.html", post=post)


@bp.route("/<int:id>/delete", methods=("POST",))
@login_required
def delete(id):
    """Delete a post.

    Ensures that the post exists and that the logged in user is the
    author of the post.
    """
    get_post(id)
    db = get_db()
    db.execute("DELETE FROM post WHERE id = ?", (id,))
    db.commit()
    return redirect(url_for("blog.index"))



##->file:.\tutorial\flaskr\db.py:
import sqlite3

import click
from flask import current_app
from flask import g


def get_db():
    """Connect to the application's configured database. The connection
    is unique for each request and will be reused if this is called
    again.
    """
    if "db" not in g:
        g.db = sqlite3.connect(
            current_app.config["DATABASE"], detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row

    return g.db


def close_db(e=None):
    """If this request connected to the database, close the
    connection.
    """
    db = g.pop("db", None)

    if db is not None:
        db.close()


def init_db():
    """Clear existing data and create new tables."""
    db = get_db()

    with current_app.open_resource("schema.sql") as f:
        db.executescript(f.read().decode("utf8"))


@click.command("init-db")
def init_db_command():
    """Clear existing data and create new tables."""
    init_db()
    click.echo("Initialized the database.")


def init_app(app):
    """Register database functions with the Flask app. This is called by
    the application factory.
    """
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)



##->file:.\tutorial\flaskr\schema.sql:
-- Initialize the database.
-- Drop any existing data and create empty tables.

DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS post;

CREATE TABLE user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE post (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author_id INTEGER NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  FOREIGN KEY (author_id) REFERENCES user (id)
);



##->file:.\tutorial\flaskr\__init__.py:
import os

from flask import Flask


def create_app(test_config=None):
    """Create and configure an instance of the Flask application."""
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        # a default secret that should be overridden by instance config
        SECRET_KEY="dev",
        # store the database in the instance folder
        DATABASE=os.path.join(app.instance_path, "flaskr.sqlite"),
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile("config.py", silent=True)
    else:
        # load the test config if passed in
        app.config.update(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    @app.route("/hello")
    def hello():
        return "Hello, World!"

    # register the database commands
    from . import db

    db.init_app(app)

    # apply the blueprints to the app
    from . import auth
    from . import blog

    app.register_blueprint(auth.bp)
    app.register_blueprint(blog.bp)

    # make url_for('index') == url_for('blog.index')
    # in another app, you might define a separate main index here with
    # app.route, while giving the blog blueprint a url_prefix, but for
    # the tutorial the blog will be the main index
    app.add_url_rule("/", endpoint="index")

    return app



##->file:.\tutorial\flaskr\static\style.css:
html {
  font-family: sans-serif;
  background: #eee;
  padding: 1rem;
}

body {
  max-width: 960px;
  margin: 0 auto;
  background: white;
}

h1, h2, h3, h4, h5, h6 {
  font-family: serif;
  color: #377ba8;
  margin: 1rem 0;
}

a {
  color: #377ba8;
}

hr {
  border: none;
  border-top: 1px solid lightgray;
}

nav {
  background: lightgray;
  display: flex;
  align-items: center;
  padding: 0 0.5rem;
}

nav h1 {
  flex: auto;
  margin: 0;
}

nav h1 a {
  text-decoration: none;
  padding: 0.25rem 0.5rem;
}

nav ul  {
  display: flex;
  list-style: none;
  margin: 0;
  padding: 0;
}

nav ul li a, nav ul li span, header .action {
  display: block;
  padding: 0.5rem;
}

.content {
  padding: 0 1rem 1rem;
}

.content > header {
  border-bottom: 1px solid lightgray;
  display: flex;
  align-items: flex-end;
}

.content > header h1 {
  flex: auto;
  margin: 1rem 0 0.25rem 0;
}

.flash {
  margin: 1em 0;
  padding: 1em;
  background: #cae6f6;
  border: 1px solid #377ba8;
}

.post > header {
  display: flex;
  align-items: flex-end;
  font-size: 0.85em;
}

.post > header > div:first-of-type {
  flex: auto;
}

.post > header h1 {
  font-size: 1.5em;
  margin-bottom: 0;
}

.post .about {
  color: slategray;
  font-style: italic;
}

.post .body {
  white-space: pre-line;
}

.content:last-child {
  margin-bottom: 0;
}

.content form {
  margin: 1em 0;
  display: flex;
  flex-direction: column;
}

.content label {
  font-weight: bold;
  margin-bottom: 0.5em;
}

.content input, .content textarea {
  margin-bottom: 1em;
}

.content textarea {
  min-height: 12em;
  resize: vertical;
}

input.danger {
  color: #cc2f2e;
}

input[type=submit] {
  align-self: start;
  min-width: 10em;
}



##->file:.\tutorial\flaskr\templates\base.html:
<!doctype html>
<title>{% block title %}{% endblock %} - Flaskr</title>
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
<nav>
  <h1><a href="{{ url_for('index') }}">Flaskr</a></h1>
  <ul>
    {% if g.user %}
      <li><span>{{ g.user['username'] }}</span>
      <li><a href="{{ url_for('auth.logout') }}">Log Out</a>
    {% else %}
      <li><a href="{{ url_for('auth.register') }}">Register</a>
      <li><a href="{{ url_for('auth.login') }}">Log In</a>
    {% endif %}
  </ul>
</nav>
<section class="content">
  <header>
    {% block header %}{% endblock %}
  </header>
  {% for message in get_flashed_messages() %}
    <div class="flash">{{ message }}</div>
  {% endfor %}
  {% block content %}{% endblock %}
</section>



##->file:.\tutorial\flaskr\templates\auth\login.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Log In{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="username">Username</label>
    <input name="username" id="username" required>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>
    <input type="submit" value="Log In">
  </form>
{% endblock %}



##->file:.\tutorial\flaskr\templates\auth\register.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Register{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="username">Username</label>
    <input name="username" id="username" required>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>
    <input type="submit" value="Register">
  </form>
{% endblock %}



##->file:.\tutorial\flaskr\templates\blog\create.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}New Post{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="title">Title</label>
    <input name="title" id="title" value="{{ request.form['title'] }}" required>
    <label for="body">Body</label>
    <textarea name="body" id="body">{{ request.form['body'] }}</textarea>
    <input type="submit" value="Save">
  </form>
{% endblock %}



##->file:.\tutorial\flaskr\templates\blog\index.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Posts{% endblock %}</h1>
  {% if g.user %}
    <a class="action" href="{{ url_for('blog.create') }}">New</a>
  {% endif %}
{% endblock %}

{% block content %}
  {% for post in posts %}
    <article class="post">
      <header>
        <div>
          <h1>{{ post['title'] }}</h1>
          <div class="about">by {{ post['username'] }} on {{ post['created'].strftime('%Y-%m-%d') }}</div>
        </div>
        {% if g.user['id'] == post['author_id'] %}
          <a class="action" href="{{ url_for('blog.update', id=post['id']) }}">Edit</a>
        {% endif %}
      </header>
      <p class="body">{{ post['body'] }}</p>
    </article>
    {% if not loop.last %}
      <hr>
    {% endif %}
  {% endfor %}
{% endblock %}



##->file:.\tutorial\flaskr\templates\blog\update.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Edit "{{ post['title'] }}"{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="title">Title</label>
    <input name="title" id="title" value="{{ request.form['title'] or post['title'] }}" required>
    <label for="body">Body</label>
    <textarea name="body" id="body">{{ request.form['body'] or post['body'] }}</textarea>
    <input type="submit" value="Save">
  </form>
  <hr>
  <form action="{{ url_for('blog.delete', id=post['id']) }}" method="post">
    <input class="danger" type="submit" value="Delete" onclick="return confirm('Are you sure?');">
  </form>
{% endblock %}



##->file:.\tutorial\tests\conftest.py:
import os
import tempfile

import pytest

from flaskr import create_app
from flaskr.db import get_db
from flaskr.db import init_db

# read in SQL for populating test data
with open(os.path.join(os.path.dirname(__file__), "data.sql"), "rb") as f:
    _data_sql = f.read().decode("utf8")


@pytest.fixture
def app():
    """Create and configure a new app instance for each test."""
    # create a temporary file to isolate the database for each test
    db_fd, db_path = tempfile.mkstemp()
    # create the app with common test config
    app = create_app({"TESTING": True, "DATABASE": db_path})

    # create the database and load test data
    with app.app_context():
        init_db()
        get_db().executescript(_data_sql)

    yield app

    # close and remove the temporary database
    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture
def client(app):
    """A test client for the app."""
    return app.test_client()


@pytest.fixture
def runner(app):
    """A test runner for the app's Click commands."""
    return app.test_cli_runner()


class AuthActions:
    def __init__(self, client):
        self._client = client

    def login(self, username="test", password="test"):
        return self._client.post(
            "/auth/login", data={"username": username, "password": password}
        )

    def logout(self):
        return self._client.get("/auth/logout")


@pytest.fixture
def auth(client):
    return AuthActions(client)



##->file:.\tutorial\tests\data.sql:
INSERT INTO user (username, password)
VALUES
  ('test', 'pbkdf2:sha256:50000$TCI4GzcX$0de171a4f4dac32e3364c7ddc7c14f3e2fa61f2d17574483f7ffbb431b4acb2f'),
  ('other', 'pbkdf2:sha256:50000$kJPKsz6N$d2d4784f1b030a9761f5ccaeeaca413f27f2ecb76d6168407af962ddce849f79');

INSERT INTO post (title, body, author_id, created)
VALUES
  ('test title', 'test' || x'0a' || 'body', 1, '2018-01-01 00:00:00');



##->file:.\tutorial\tests\test_auth.py:
import pytest
from flask import g
from flask import session

from flaskr.db import get_db


def test_register(client, app):
    # test that viewing the page renders without template errors
    assert client.get("/auth/register").status_code == 200

    # test that successful registration redirects to the login page
    response = client.post("/auth/register", data={"username": "a", "password": "a"})
    assert response.headers["Location"] == "/auth/login"

    # test that the user was inserted into the database
    with app.app_context():
        assert (
            get_db().execute("SELECT * FROM user WHERE username = 'a'").fetchone()
            is not None
        )


@pytest.mark.parametrize(
    ("username", "password", "message"),
    (
        ("", "", b"Username is required."),
        ("a", "", b"Password is required."),
        ("test", "test", b"already registered"),
    ),
)
def test_register_validate_input(client, username, password, message):
    response = client.post(
        "/auth/register", data={"username": username, "password": password}
    )
    assert message in response.data


def test_login(client, auth):
    # test that viewing the page renders without template errors
    assert client.get("/auth/login").status_code == 200

    # test that successful login redirects to the index page
    response = auth.login()
    assert response.headers["Location"] == "/"

    # login request set the user_id in the session
    # check that the user is loaded from the session
    with client:
        client.get("/")
        assert session["user_id"] == 1
        assert g.user["username"] == "test"


@pytest.mark.parametrize(
    ("username", "password", "message"),
    (("a", "test", b"Incorrect username."), ("test", "a", b"Incorrect password.")),
)
def test_login_validate_input(auth, username, password, message):
    response = auth.login(username, password)
    assert message in response.data


def test_logout(client, auth):
    auth.login()

    with client:
        auth.logout()
        assert "user_id" not in session



##->file:.\tutorial\tests\test_blog.py:
import pytest

from flaskr.db import get_db


def test_index(client, auth):
    response = client.get("/")
    assert b"Log In" in response.data
    assert b"Register" in response.data

    auth.login()
    response = client.get("/")
    assert b"test title" in response.data
    assert b"by test on 2018-01-01" in response.data
    assert b"test\nbody" in response.data
    assert b'href="/1/update"' in response.data


@pytest.mark.parametrize("path", ("/create", "/1/update", "/1/delete"))
def test_login_required(client, path):
    response = client.post(path)
    assert response.headers["Location"] == "/auth/login"


def test_author_required(app, client, auth):
    # change the post author to another user
    with app.app_context():
        db = get_db()
        db.execute("UPDATE post SET author_id = 2 WHERE id = 1")
        db.commit()

    auth.login()
    # current user can't modify other user's post
    assert client.post("/1/update").status_code == 403
    assert client.post("/1/delete").status_code == 403
    # current user doesn't see edit link
    assert b'href="/1/update"' not in client.get("/").data


@pytest.mark.parametrize("path", ("/2/update", "/2/delete"))
def test_exists_required(client, auth, path):
    auth.login()
    assert client.post(path).status_code == 404


def test_create(client, auth, app):
    auth.login()
    assert client.get("/create").status_code == 200
    client.post("/create", data={"title": "created", "body": ""})

    with app.app_context():
        db = get_db()
        count = db.execute("SELECT COUNT(id) FROM post").fetchone()[0]
        assert count == 2


def test_update(client, auth, app):
    auth.login()
    assert client.get("/1/update").status_code == 200
    client.post("/1/update", data={"title": "updated", "body": ""})

    with app.app_context():
        db = get_db()
        post = db.execute("SELECT * FROM post WHERE id = 1").fetchone()
        assert post["title"] == "updated"


@pytest.mark.parametrize("path", ("/create", "/1/update"))
def test_create_update_validate(client, auth, path):
    auth.login()
    response = client.post(path, data={"title": "", "body": ""})
    assert b"Title is required." in response.data


def test_delete(client, auth, app):
    auth.login()
    response = client.post("/1/delete")
    assert response.headers["Location"] == "/"

    with app.app_context():
        db = get_db()
        post = db.execute("SELECT * FROM post WHERE id = 1").fetchone()
        assert post is None



##->file:.\tutorial\tests\test_db.py:
import sqlite3

import pytest

from flaskr.db import get_db


def test_get_close_db(app):
    with app.app_context():
        db = get_db()
        assert db is get_db()

    with pytest.raises(sqlite3.ProgrammingError) as e:
        db.execute("SELECT 1")

    assert "closed" in str(e.value)


def test_init_db_command(runner, monkeypatch):
    class Recorder:
        called = False

    def fake_init_db():
        Recorder.called = True

    monkeypatch.setattr("flaskr.db.init_db", fake_init_db)
    result = runner.invoke(args=["init-db"])
    assert "Initialized" in result.output
    assert Recorder.called



##->file:.\tutorial\tests\test_factory.py:
from flaskr import create_app


def test_config():
    """Test create_app without passing test config."""
    assert not create_app().testing
    assert create_app({"TESTING": True}).testing


def test_hello(client):
    response = client.get("/hello")
    assert response.data == b"Hello, World!"


            
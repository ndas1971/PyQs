print("""
The basic idea of latent semantic analysis (LSA) is,
that text do have a higher order (=latent semantic) structure 
which,however, is obscured by word usage (e.g. through the use of vague usages of words). 
By using conceptual indices that are derived statistically via a truncated singular value decomposition 
(a two-mode factor analysis)over a given document-term matrix, 
this variability problem can be overcome.
""")

##Step-1 - Text Cleaning

import spacy
spacy.load('en')
from spacy.lang.en import English
parser = English()

def tokenize(text):
    lda_tokens = []
    tokens = parser(text)
    for token in tokens:
        if token.orth_.isspace():
            continue
        elif token.like_url:
            lda_tokens.append('URL')
        elif token.orth_.startswith('@'):
            lda_tokens.append('SCREEN_NAME')
        else:
            lda_tokens.append(token.lower_)
    return lda_tokens

#use NLTK's Wordnet(a corpora) to find the meanings of words, synonyms, antonyms, and more. 
import nltk
#nltk.download('wordnet')

from nltk.corpus import wordnet as wn
def get_lemma(word):
    lemma = wn.morphy(word)
    if lemma is None:
        return word
    else:
        return lemma

#Or use below (WordNetLemmatizer to get the root word)
from nltk.stem.wordnet import WordNetLemmatizer
def get_lemma2(word):
    return WordNetLemmatizer().lemmatize(word)

#Filter out stop words:
#nltk.download('stopwords')
en_stop = set(nltk.corpus.stopwords.words('english'))

#Then full processing 

def prepare_text_for_lda(text):
    tokens = tokenize(text)
    tokens = [token for token in tokens if len(token) > 4]
    tokens = [token for token in tokens if token not in en_stop]
    tokens = [get_lemma(token) for token in tokens]
    return tokens

#Create list of tokens 
text = ("transporting food by cars will cause global warming. so we should go local.",
          "we should try to convince our parents to stop using cars because it will cause global warming.",
          "some food, such as mongo, requires a warm weather to grow. so they have to be transported to canada.",
          "a typical electronic circuit can be built with a battery, a bulb, and a switch.",
          "electricity flows from batteries to the bulb, just like water flows through a tube.",
          "batteries have chemical energe in it. then electrons flow through a bulb to light it up.",
          "birds can fly because they have feather and they are light.",
          "why some birds like pigeon can fly while some others like chicken cannot?",
          "feather is important for birds' fly. if feather on a bird's wings is removed, this bird cannot fly.")

import random
text_data = []
for line in text:
    tokens = prepare_text_for_lda(line)
    text_data.append(tokens)

from gensim import corpora
dictionary = corpora.Dictionary(text_data)
corpus = [dictionary.doc2bow(text) for text in text_data]

dictionary.save('lsa_dictionary.gensim')
corpora.MmCorpus.serialize('lsa_corpus.gensim.mm', corpus)         

#dictionary = corpora.Dictionary.load('dictionary.gensim')
#corpus = corpora.MmCorpus('corpus.gensim.mm')
# load id->word mapping (the dictionary), one of the results of step 2 above
#id2word = corpora.Dictionary.load_from_text('data/wiki_en_wordids.txt')
# load corpus iterator


#compute LSA of the English text 
# extract 5 LSI topics; use the default one-pass algorithm
import gensim
tfidf = gensim.models.TfidfModel(corpus)
corpus_tfidf = tfidf[corpus]

#lsi = gensim.models.lsimodel.LsiModel(corpus=corpus, id2word=dictionary, num_topics=5)
#or 
lsi = gensim.models.lsimodel.LsiModel(corpus=corpus_tfidf, id2word=dictionary, num_topics=5)

lsi.save('lsa_model5.gensim')
#lsi = gensim.models.lsimodel.LsiModel.load('lsa_model5.gensim')


# print the most contributing words (both positively and negatively) for each of the first ten topics
print("Top-n topics from LSA\n", lsi.print_topics(5))
#topic #0(332.762): 0.425*"utc" + 0.299*"talk" + 0.293*"page" + 0.226*"article" + 0.224*"delete" + 0.216*"discussion" + 0.205*"deletion" + 0.198*"should" + 0.146*"debate" + 0.132*"be"
#topic #1(201.852): 0.282*"link" + 0.209*"he" + 0.145*"com" + 0.139*"his" + -0.137*"page" + -0.118*"delete" + 0.114*"blacklist" + -0.108*"deletion" + -0.105*"discussion" + 0.100*"diff"
#topic #2(191.991): -0.565*"link" + -0.241*"com" + -0.238*"blacklist" + -0.202*"diff" + -0.193*"additions" + -0.182*"users" + -0.158*"coibot" + -0.136*"user" + 0.133*"he" + -0.130*"resolves"
#topic #3(141.284): -0.476*"image" + -0.255*"copyright" + -0.245*"fair" + -0.225*"use" + -0.173*"album" + -0.163*"cover" + -0.155*"resolution" + -0.141*"licensing" + 0.137*"he" + -0.121*"copies"
#topic #4(130.909): 0.264*"population" + 0.246*"age" + 0.243*"median" + 0.213*"income" + 0.195*"census" + -0.189*"he" + 0.184*"households" + 0.175*"were" + 0.167*"females" + 0.166*"males"
#topic #5(120.397): 0.304*"diff" + 0.278*"utc" + 0.213*"you" + -0.171*"additions" + 0.165*"talk" + -0.159*"image" + 0.159*"undo" + 0.155*"www" + -0.152*"page" + 0.148*"contribs"

print("""
It appears that according to LSI, 
feather, bird, important, are all related words 
(and contribute the most to the direction of the first topic)

""")

#LSA space for corpus 
corpus_lsi = lsi[corpus_tfidf]
print("For each doc, topic and  correlation eg (1, 0.8414592091711071) ie topic 1 and it's correlation ")
for doc in corpus_lsi: 
    print(doc)

#unseen vec
print("Map unseen doc to LSA space ")
new_doc = 'feather is important for birds'
new_doc = prepare_text_for_lda(new_doc)
new_doc_bow = dictionary.doc2bow(new_doc)
print(new_doc_bow)  #(125, 1), (234, 1), (442, 1), (587, 1), (1859, 1)]
new_tfidf = tfidf[new_doc_bow]
doc_lsa = lsi[new_tfidf] 
print(doc_lsa) #[(0, -1.4533589956641793), (2, -0.17747427918742487), (3, -0.04964336913501917)]
print("eg contains Topic and its correlation ")




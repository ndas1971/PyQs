from __future__ import print_function, division
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 
from pyspark import *                   #SparkContext,RDD,Broadcast,Accumulator,SparkConf,SparkFiles,StorageLevel,TaskContext

from pyspark.sql import *               #SparkSession, DataFrame, Column, Row, GroupedData, DataFrameNaFunctions, DataFrameStatFunctions, Window
import pyspark.sql.functions as F
from pyspark.sql.types import * 

from pyspark.ml  import *               #Transformer, UnaryTransformer,Estimator,Model,Pipeline,PipelineModel
from pyspark.ml.feature import *        #Binarizer, BucketedRandomProjectionLSHE, BucketedRandomProjectionLSHModelE, Bucketizer, ChiSqSelectorE, ChiSqSelectorModelE, CountVectorizer, CountVectorizerModel, DCT, ElementwiseProduct, FeatureHasherE, HashingTF, IDF, IDFModel, ImputerE, ImputerModelE, IndexToString, MaxAbsScaler, MaxAbsScalerModel, MinHashLSHE, MinHashLSHModelE, MinMaxScaler, MinMaxScalerModel, NGram, Normalizer, OneHotEncoderD, OneHotEncoderEstimator, OneHotEncoderModel, PCA, PCAModel, PolynomialExpansion, QuantileDiscretizerE, RegexTokenizer, RFormulaE, RFormulaModelE, SQLTransformer, StandardScaler, StandardScalerModel, StopWordsRemover, StringIndexer, StringIndexerModel, Tokenizer, VectorAssembler, VectorIndexer, VectorIndexerModel, VectorSizeHintE, VectorSlicer, Word2Vec, Word2VecModel, , 
from pyspark.ml.classification import * #LinearSVCE, LinearSVCModelE, LogisticRegression, LogisticRegressionModel, LogisticRegressionSummaryE, LogisticRegressionTrainingSummaryE, BinaryLogisticRegressionSummaryE, BinaryLogisticRegressionTrainingSummaryE, DecisionTreeClassifier, DecisionTreeClassificationModel, GBTClassifier, GBTClassificationModel, RandomForestClassifier, RandomForestClassificationModel, NaiveBayes, NaiveBayesModel, MultilayerPerceptronClassifier, MultilayerPerceptronClassificationModel, OneVsRestE, OneVsRestModelE, , 
from pyspark.ml.clustering import *     #BisectingKMeans, BisectingKMeansModel, BisectingKMeansSummaryE, KMeans, KMeansModel, GaussianMixture, GaussianMixtureModel, GaussianMixtureSummaryE, LDA, LDAModel, LocalLDAModel, DistributedLDAModel, , 
from pyspark.ml.linalg import *         #Vector, DenseVector, SparseVector, Vectors, Matrix, DenseMatrix, SparseMatrix, Matrices, , 
from pyspark.ml.recommendation import * #ALS, ALSModel, , 
from pyspark.ml.regression import *     #AFTSurvivalRegressionE, AFTSurvivalRegressionModelE, DecisionTreeRegressor, DecisionTreeRegressionModel, GBTRegressor, GBTRegressionModel, GeneralizedLinearRegressionE, GeneralizedLinearRegressionModelE, GeneralizedLinearRegressionSummaryE, GeneralizedLinearRegressionTrainingSummaryE, IsotonicRegression, IsotonicRegressionModel, LinearRegression, LinearRegressionModel, LinearRegressionSummaryE, LinearRegressionTrainingSummaryE, RandomForestRegressor, RandomForestRegressionModel, , 
from pyspark.ml.stat import *           #moduleChiSquareTestE, CorrelationE, , 
from pyspark.ml.tuning import *         #ParamGridBuilder, CrossValidator, CrossValidatorModel, TrainValidationSplitE, TrainValidationSplitModelE, , 
from pyspark.ml.evaluation import *     #Evaluator, BinaryClassificationEvaluatorE, RegressionEvaluatorE, MulticlassClassificationEvaluatorE, ClusteringEvaluatorE, , 
from pyspark.ml.fpm import *            #FPGrowthE, FPGrowthModelE, , 
from pyspark.ml.util import *           #BaseReadWrite, DefaultParamsReadable, DefaultParamsReader, DefaultParamsWritable, DefaultParamsWriter, Identifiable, JavaMLReadable, JavaMLReader, JavaMLWritable, JavaMLWriter, JavaPredictionModel, MLReadable, MLReader, MLWritable, MLWriter, , , 



from sklearn.datasets import *  
spark = SparkSession.builder.appName("basic").getOrCreate()

n_colors = 64

# Load the Summer Palace photo
china = load_sample_image("china.jpg")
china.shape  #(427, 640, 3)   # wxh and each value is RGB ie 3d dimension has three axis 
china[0,0,:] #array([174, 201, 231], dtype=uint8)

# Load Image and transform to a 2D numpy array of float and normalize each value 0-1
#Dividing by  255 is important so that plt.imshow behaves works well on float data (need to be in the range [0-1])
w, h, d = original_shape = tuple(china.shape)
image_array = np.reshape(china, (w * h, d)).astype(np.float64) / 255
image_array.shape #(273280, 3)

#schema can list of column names or a pyspark.sql.types.DataType
#or None, then real data should be dict of {'colName': Value} or Row or namedTuple
df = spark.createDataFrame(image_array.tolist(), schema=["R", "G", "B"])
#df.show()

trainingData, testData = df.randomSplit([.01,.99], seed=0) #only 1% subset as training data 

assembler = VectorAssembler().setInputCols(["R", "G", "B"]).setOutputCol("features")
ksetup = BisectingKMeans().setK(n_colors).setSeed(1)
pipeline = Pipeline(stages=[assembler,ksetup])
kmeans = pipeline.fit(trainingData)

#cluster shape 
len(kmeans.stages[-1].clusterCenters()), len(kmeans.stages[-1].clusterCenters()[0]) 
#(64, 3)

# Get labels for all points
predictions = kmeans.transform(df)  #2D array prediction, (Imagesize ie wxh) X value 
#prediction contain cluster no 
labels = predictions.select("prediction").toPandas().values # numpy array 

def recreate_image(cluster_centers, labels, w, h):
    """replace each value in original image, by cluster center"""
    d = cluster_centers.shape[1]
    image = np.zeros((w, h, d))
    label_idx = 0
    for i in range(w):
        for j in range(h):
            image[i][j] = cluster_centers[labels[label_idx]]
            label_idx += 1
    return image

# Display all results, alongside original image
plt.figure(1)
plt.clf()
plt.axis('off')
plt.title('Original image (96,615 colors)')
plt.imshow(china)

plt.figure(2)
plt.clf()
plt.axis('off')
plt.title('Quantized image (64 colors, K-Means)')
plt.imshow(recreate_image(np.array(kmeans.stages[-1].clusterCenters()), labels, w, h))


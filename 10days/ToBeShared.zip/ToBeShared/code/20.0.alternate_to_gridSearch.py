import sklearn.datasets
import numpy as np
import random, time 

'''
https://en.wikipedia.org/wiki/Evolutionary_algorithm
An evolutionary algorithm (EA) is a 
generic population-based metaheuristic optimization algorithm. 
An EA uses mechanisms inspired by biological evolution, 
such as reproduction, mutation, recombination, and selection

There are many types of EA , one is 
Evolutionary programming - Similar to genetic programming, 
but the structure of the program is fixed 
and its numerical parameters are allowed to evolve.

EvolutionaryAlgorithmSearchCV
    This allows to reduce the time required to find the best parameters for estimator. 
    Instead of trying out every possible combination of parameters, 
    evolve only the combinations that give the best results.
'''

#must use python35\deep module which is modified version of pypi

if __name__=='__main__':
    import warnings
    from sklearn.exceptions import * 
    warnings.simplefilter(action='ignore', category=FutureWarning)
    warnings.simplefilter(action='ignore', category=UserWarning)
    warnings.simplefilter(action='ignore', category=DeprecationWarning)

    data = sklearn.datasets.load_digits()
    X = data["data"]
    y = data["target"]

    from sklearn.svm import SVC
    from sklearn.model_selection import StratifiedKFold

    paramgrid = {"kernel": ["rbf"],
                 "C"     : np.logspace(-9, 9, num=25, base=10),
                 "gamma" : np.logspace(-9, 9, num=25, base=10)}

    random.seed(1)

    from evolutionary_search import EvolutionaryAlgorithmSearchCV
    '''
    EvolutionaryAlgorithmSearchCV(estimator, params, scoring=None, cv=4,
                 refit=True, verbose=False, population_size=50,
                 gene_mutation_prob=0.1, gene_crossover_prob=0.5,
                 tournament_size=3, generations_number=10, gene_type=None,
                 n_jobs=1, iid=True, error_score='raise',
        fit_params={})
    #check 
    https://github.com/rsteca/sklearn-deap/blob/master/evolutionary_search/cv.py
    '''
    st = time.time()
    cv = EvolutionaryAlgorithmSearchCV(estimator=SVC(),
                                       params=paramgrid,
                                       scoring="accuracy",
                                       cv=StratifiedKFold(n_splits=4),
                                       verbose=1,
                                       population_size=50,
                                       gene_mutation_prob=0.10,
                                       gene_crossover_prob=0.5,
                                       tournament_size=3,
                                       generations_number=5,
                                       n_jobs=4)
    cv.fit(X, y)
    print("..done", round(time.time()-st, 2) , " secs")
    print("Best Params", cv.best_estimator_)
    print("score", cv.best_estimator_.score(X,y)) #cv does not have score
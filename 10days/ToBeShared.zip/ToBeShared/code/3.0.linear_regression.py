import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

from sklearn.pipeline import * 
from sklearn.linear_model import *  
from sklearn.preprocessing import *  
from sklearn.datasets import *  
from sklearn.model_selection import *  
from sklearn.metrics import *  

print("-----------Linear regression on boston data(predicting house price based on location)-----")
boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

print("Doing Feature Scaling(StandardScaler) on X ...")
scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
Y = boston["target"]

def process(model, modelCV, alphas, names, X=X,y=Y, **kwargs):
    df = pd.DataFrame(index=names)    
    for alpha in alphas:
        m = model(alpha=alpha, **kwargs)        
        m.fit(X,y)        
        column_name = 'Alpha = %f' % alpha
        df[column_name] = m.coef_
    #Optimized alpha 
    lcv = modelCV(cv=3, **kwargs)
    lcv.fit(X,y)  
    try:
        column_name = 'Best Alpha = %f(%f)' % (lcv.alpha_, lcv.l1_ratio_)
    except:
        try:
            #it is not ElasticNet
            column_name = 'Best Alpha = %f' % (lcv.alpha_, )
        except:
            #it is GridSearchCV
            column_name = 'Best Alpha = %f' % (lcv.best_params_['alpha'], )
    try:        
        df[column_name] = lcv.coef_
    except:
        #it is GridSearchCV
        df[column_name] = lcv.best_estimator_.coef_
    return (df, lcv)

X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)

print("------------------Lasso on boston data ----------------")
print("Note with increasing alpha, coefficients are getting zero")

df, model = process(Lasso, LassoCV, [.0001, .5, 10], boston["feature_names"], X_train,y_train )   #coeff is zero 
print(df)
print(model)
print("With best alpha, train r^2 ", model.score(X_train, y_train),
                " test r^2 " , model.score(X_test, y_test),
#other metrics 
" MSE ", mean_squared_error(y_test, model.predict(X_test)) )	 #y_true, y_pred
 
input()
print("------------------Ridge on boston data----------------")
df, model = process(Ridge, RidgeCV, [.0001, .5, 10], boston["feature_names"], X_train,y_train)   
print(df)
print(model)
print("With best alpha, train r^2 ", model.score(X_train, y_train),
                " test r^2 " , model.score(X_test, y_test),
#other metrics 
" MSE ", mean_squared_error(y_test, model.predict(X_test)) )	 #y_true, y_pred

input()  
print("------------------ElasticNet  on boston data----------------")
df, model = process(ElasticNet, ElasticNetCV, [.0001, .5, 10], boston["feature_names"], X_train,y_train, l1_ratio=0.5) 
print(df)
print(model)
print("With best alpha, train r^2 ", model.score(X_train, y_train),
                " test r^2 " , model.score(X_test, y_test),
#other metrics 
" MSE ", mean_squared_error(y_test, model.predict(X_test)) )	 #y_true, y_pred
input()
print("------------------SGDRegressor  on boston data----------------")
from functools import partial
md = partial(SGDRegressor, l1_ratio=0.5, max_iter = np.ceil(10**6 / X.shape[0]), early_stopping=True, tol=1e-3)
param_grid = {'alpha': 10.0**-np.arange(1,7)}
mdCV = partial(GridSearchCV, 
        estimator =SGDRegressor(l1_ratio=0.5, max_iter = np.ceil(10**6 / X.shape[0]), early_stopping=True, tol=1e-3),
        param_grid=param_grid,
        scoring='r2')

df, model1 = process(md, mdCV, [.0001, .01, .1], boston["feature_names"], X_train,y_train )   #coeff is zero 
print(df)
print(model1)
print("With best alpha, train r^2 ", model1.score(X_train, y_train),
                " test r^2 " , model1.score(X_test, y_test),
#other metrics 
" MSE ", mean_squared_error(y_test, model1.predict(X_test)) )	 #y_true, y_pred
input()




print("------------------First regression diagnostic: Scatter matrix----------------")
## 
from pandas.plotting import scatter_matrix
scatter_matrix(pd.DataFrame(X, columns=boston.feature_names), alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
input()

print("""
Residuals Plot
Residuals are the difference between  target variable (y) and the predicted value (y), 
to analyze the variance of the error of the regressor. 
If the points are randomly dispersed around the horizontal axis, 
a linear regression model is usually appropriate for the data; 
otherwise(eg funnel data), a non-linear model(eg GLM, use statsmodels, SVC(nonlinear kernel), Boosting) is more appropriate. 
""")

from yellowbrick.regressor import *

# Instantiate the linear model and visualizer

visualizer = ResidualsPlot(model)

visualizer.fit(X_train, y_train)  # Fit the training data to the model
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
visualizer.poof()                 # Draw/show/poof the data
#visualizer.poof(outpath="pcoords.png") #sve to file, ext determines file type 

input()

print("""
Prediction Error Plot
A prediction error plot shows the actual targets from the dataset against the predicted values 

Data scientists can diagnose regression models using this plot by comparing against the 45 degree line, 
where the prediction exactly matches the model.
""")

visualizer = PredictionError(model)

visualizer.fit(X_train, y_train)  # Fit the training data to the visualizer
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
visualizer.poof()             # Draw/show/poof the data
input()



print("""
A Q-Q plot is a scatterplot created by plotting two sets of quantiles against one another. 
If both sets of quantiles came from the same distribution, we should see the points forming a line that's roughly straight. 

In case of regression, error should come from normal (maches with 45 deg line 
If there is exponential part in the plot, do a log transform of y 
""")
import statsmodels.api as sm

res = y_train - model.predict(X_train)
fig = sm.qqplot(res)
plt.show()

print("""
log transforms of y to get better QQ plot 
log1p(x) Calculates log(1 + x).
expm1 exp(x) - 1, the inverse of log1p.
""")

y_train_1 = np.log1p(y_train)
model = model.fit(X_train, y_train_1)
res = y_train_1 - model.predict(X_train)
fig = sm.qqplot(res)
plt.show()
#model 
model.score(X_train, y_train_1)
model.score(X_test, np.log1p(y_test))
y_pred = np.expm1(model.predict(X_test))
print("after log transformed, MSE ", mean_squared_error(y_test, y_pred) )
input()

print("""
Alpha Selection for Regularization
How varying alpha has changed models 
""")

# Create a list of alphas to cross-validate against
alphas = np.logspace(-10, 1, 400) #logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)

visualizer = AlphaSelection(model)

visualizer.fit(X, Y)
g = visualizer.poof()

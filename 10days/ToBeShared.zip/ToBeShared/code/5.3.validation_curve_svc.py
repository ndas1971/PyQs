import numpy as np
import pandas as pd

print("""
Most models have multiple hyperparameters and the best way 
to choose a combination of those parameters is with a grid search. 
However, it is sometimes useful to plot the influence 
of a single hyperparameter on the training and test data to determine 
if the estimator is underfitting or overfitting for some hyperparameter values.

This example takes long time 
""")


from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold
from yellowbrick.model_selection import ValidationCurve

# Load a classification data set
data = pd.read_csv("data/game.csv")

# Specify the features of interest and the target
target = "outcome"
features = [col for col in data.columns if col != target]

# Encode the categorical data with one-hot encoding
X = pd.get_dummies(data[features])
y = data[target]

# Create the validation curve visualizer
cv = StratifiedKFold(12)
param_range = np.logspace(-6, -1, 12)

viz = ValidationCurve(
    SVC(), param_name="gamma", param_range=param_range,
    logx=True, cv=cv, scoring="f1_weighted", n_jobs=-1,
)

viz.fit(X, y)
viz.poof()
###*** Flask with Jinja2 
#http://flask.palletsprojects.com/en/1.1.x/deploying/#deployment

##Setup 
If a new venv is required 
set VENV_PATH=C:\Python311\poetry_env
python -m venv %VENV_PATH%
%VENV_PATH%\Scripts\activate
python -m pip install -U pip setuptools
pip install poetry
exit 
set PATH=%PATH%;C:\Python311\poetry_env\Scripts

##General 
$ pip install poetry 
poetry new flaskr
cd flaskr

#add index-url 
https://<<SERVER>>/artifactory/api/pypi/<<LOCATION>>/simple/
pip config list  
#pip config get global.index-url 
#pip config --global get index-url
poetry source add --priority=default internalpypi index-url 
poetry source add --priority=supplemental PyPI

poetry config virtualenvs.in-project true 
poetry cache clear pypi --all

poetry add flask gevent
#poetry add django@^4.0.0
poetry install
poetry env info
poetry shell
#build 
poetry build -v

#WIth virtual env 
$ poetry shell 
> python flaskr\quick_server.py

##flaskr\flaskr\__init__.py 
from flask import Flask
app = Flask(__name__)
from . import quick_server

#WIth virtual env 
$ poetry shell 
set FLASK_APP=flaskr 
flask run 

#build 
poetry build -v
exit
#You can find the file in dist/flaskr-1.0.0-py3-none-any.whl

FURTHER TEST 
python -m vnev .\env 
.\env\Scripts\activate
pip install dist/flaskr-1.0.0-py3-none-any.whl
cd ..
set FLASK_APP=flaskr 
flask run 

Note 
1. your package contains a package with the same name as tool.poetry.name 
   located in the root of your project.
   If not, then mention in tool.poetry.packages
        A list of packages and modules to include in the final distribution.
   eg 
    [tool.poetry]
    # ...
    packages = [
        #at root directory
        { include = "my_package" },
        { include = "extra_package/**/*.py" },
        #stored inside a 'lib' directory
        { include = "my_package", from = "lib" },
    ]
2. MANIFEST.in file is replaced by tool.poetry.include, and tool.poetry.exclude sections. 
   tool.poetry.exclude is additionally implicitly populated by .gitignore
   These are extra files to be included or excluded 
   eg 
   exclude = ["my_package/excluded.py", "tests/not_this_dir", "**/node_modules/**/*"]
   include = ["CHANGELOG.md", "data/*"]
   
3. Poetry will require you to explicitly specify what versions of Python you intend to support,

###Flask COnfig 
#config.py 
class Config:
    TESTING = False

class ProductionConfig(Config):
    DATABASE_URI = 'production_uri'
    SECRET_KEY='some secret key'

class DevelopmentConfig(Config):
    DATABASE_URI = "developement_uri"

class TestingConfig(Config):
    DATABASE_URI = 'tsting_uri'
    TESTING = True
#hello.py 
#flask --app hello run --debug 

from flask import Flask 
import os 

from logging.config import dictConfig

#https://flask.palletsprojects.com/en/2.3.x/logging/
dictConfig({
    'version': 1,
    'root': {
        'level': 'INFO',
    }
})

app = Flask(__name__)

#Set configuration file 
#https://flask.palletsprojects.com/en/3.0.x/config/
match ("development" if app.config["DEBUG"] 
        else os.environ.get('environment', None)) :
    case "production" | "PRODUCTION":
        app.config.from_object('config.ProductionConfig')
    case "testing" | "TESTING":
        app.config.from_object('config.TestingConfig')
    case _:
        app.config.from_object('config.DevelopmentConfig')
        
        
    
@app.route("/")
def home():
    #default level is warning 
    #or else set 
    app.logger.info('%s using', ("development" if app.config["DEBUG"] 
        else os.environ.get('environment', None)))
    return f"""
    <h1>{app.config.get("DATABASE_URI", "Notfound")}</h1>    
    """

##Flask 
jinja2 core filter 
    https://jinja.palletsprojects.com/en/2.10.x/templates/#list-of-builtin-filters
Jinja2 Test 
    https://jinja.palletsprojects.com/en/2.10.x/templates/#builtin-tests

#First code 
from flask import Flask

# Flask(import_name, static_url_path=None, static_folder='static', 
# static_host=None, host_matching=False, subdomain_matching=False, 
# template_folder='templates', instance_path=None, 
# instance_relative_config=False, root_path=None)
app = Flask(__name__)

@app.route("/")#http://127.0.0.1:5000/
def home():
    return """
        <html><body>
        <h1>Hello there!!</h1>
        </body></html>
    """
    
if __name__ == '__main__':
    app.run()    
    #run(host=None, port=None, debug=None, load_dotenv=True, **options)
    #localhost, port=5000
    #host='0.0.0.0' means all IP interface in this machine 
    #URI = scheme:[//authority]path[?query][#fragment]
    #http://localhost:5000/PATH?URL_PARAMS
    
#updated 
@app.route("/")  # http://localhost:5000/
def home():
    return """
    <html>
    <head>
    <title>My webserver </title>
    <style>
    .some {
        color: red;
    }
    </style> </head>
    <body>
    <h1 id="some" class="some">Hello there !!! </h1>
    <h1 id="some2" class="some">Welcome </h1>
    </body></html>
    """
    
#OR  
# from flask import Response
# r = Response(response="<a>ok</a>", status=200, mimetype="application/xml")
# r.headers["Content-Type"] = "text/xml; charset=utf-8"
# return r  

#To handle favicon file - download 
#and store it to /static/favicon.ico 
@app.route("/favicon.ico")
def favicon():
    return app.send_static_file('favicon.ico')
    

    
#Other configuration 
Note static files are handled automatically. for example, if 
URL is /static/a.css and file is under static/a.css folder 

OR configure as below 

app = Flask(__name__,
            static_url_path='', 
            static_folder='web/static',
            template_folder='web/templates')

static_url_path='' 
    removes any preceding path from the URL (i.e. the default /static).
static_folder='web/static' 
    to serve any files found in the folder web/static as static files.
template_folder='web/templates' 
    similarly, this changes the templates folder.

<link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
would go now web/static/css/bootstrap.min.css

Eg 
from flask import Flask, send_from_directory

# set the project root directory as the static folder
app = Flask(__name__, static_url_path='')

@app.route('/js/<path:path>')
def send_js(path):
    return send_from_directory('js', path) #from project root_folder/js 

 
    
    
#Debug mode 
Flask will suppress any server error with a generic error page unless 
it is in debug mode. 
As such to enable just the interactive debugger without the code reloading, 
you have to invoke run() with debug=True and use_reloader=False
app.run(host=None, port=None, debug=None, load_dotenv=True, **options)

Note FLASK_ENV='production' is default, but can be 'development'
where just in load would happen 

host – the hostname to listen on. Set this to '0.0.0.0' 
to have the server available externally as well. 
Defaults to '127.0.0.1' or the host in the SERVER_NAME config variable if present.

port – the port of the webserver. Defaults to 5000 or the port defined 
in the SERVER_NAME config variable if present.


#BeautifulSoup 
from bs4 import BeautifulSoup
import requests

r  = requests.get("http://127.0.0.1:5000/")
data = r.text
soup = BeautifulSoup(data, 'html.parser')
soup.html.body.h1.name  #only first
soup.html.body.h1.attrs  #only first 
soup.html.body.h1.text  #only first
soup.find_all('h1') 
for e in soup.find_all('h1') :
    print(e.attrs['id'])  #e.text, e['id']

soup.select("html body h1")  
soup.select("h1#some")
soup.select("h1.some")



#flask code 
from flask import Flask, request, jsonify, render_template, make_response 
import json , os 

app = Flask(__name__)

'''
#to xml or json based on template 
template = render_template('somefile.xml', values=values)
r = make_response(template)
r.headers['Content-Type'] = 'application/xml'
r.status_code = 200 
return r 
'''
@app.route("/env", methods=['GET','POST'])#http://127.0.0.1:5000/env
def env():
    if request.method == 'POST':
        envp = request.form.get('envp', 'all').upper()
        env_dict = os.environ
        if os.environ.get(envp, "notfound") != "notfound":
            env_dict = { envp : os.environ.get(envp,"notfound") }
        return render_template("env.html", 
            envs=env_dict)
    else:
        return """
            <html><body>
            <form action="/env" method="post">
              Put Variable name :<br>
              <input type="text" name="envp" value="ALL">
              <br><br>
              <input type="submit" value="Submit">
            </form> 
            </body></html>
        """
        

#templates/env.html 
<html>
<body>
<table border="1">
<tr style="color: red"><th>Key</th><th>Value</th></tr>
{% if envs.items() %}  {# can put jinja test eg var is defined #}
{% for k,v in envs.items() %}
<tr>
<td>{{ k }}</td>
<td>{{ v }}</td>
</tr>
{% endfor %}
{% endif %}
</table>
</body>
</html>



##More example 

from flask import jsonify, Response
@app.route("/helloj") #http://localhost:5000/helloj?name=das&format=json 
@app.route("/helloj/<string:name>/")  #http://localhost:5000/helloj/das/
@app.route("/helloadv", methods=['POST'])
@app.route("/helloj/<string:name>/<string:format>") #http://localhost:5000/helloj/das/json
def helloj(name="ABC", format="json"):
    db = [{"name": "ABC", "age": 30},
           {"name": "das", "age": 40}]
    if request.method == 'GET':
        fname = request.args.get("name", name)
        fformat = request.args.get("format", format)
    elif request.method == 'POST' :
        if 'Content-Type' in request.headers and \
          request.headers['Content-Type'].lower() in ['text/json',  'application/json']:
            fname = request.json.get("name", "ABC")
            fformat = "json"
    age = None 
    for emp in db:
        if fname == emp['name']:
            age = emp['age']
    if fformat == "json":
        if age is not None:
            success = {"name" : fname, "age" : age}
            resp = jsonify(success)
            resp.status_code = 200
        else:
            error = {"details" : "Name is not found"}
            resp = jsonify(error)
            resp.status_code = 500
    elif fformat == "xml":
        data = f"""<?xml version="1.0"?>
               <data><name>{fname}</name>
               <age>{age}</age></data>"""
        resp = Response(response=data, status=200, mimetype="application/xml")
        resp.headers['Content-Type'] = "text/xml; charset=utf-8"
    else:
        resp = "Not Supported"
    return resp    
    
'''
import requests as r 
res = r.get("http://localhost:5000/helloj")
res.json() 

#for xml 
import xml.etree.ElementTree as ET
res = requests.get("http://localhost:5000/helloj?name=das&format=xml")
root = ET.fromstring(res.text)
root.tag
root.attrib
root.text
nn = root.findall(".//name")
[n.text  for n in nn]

headers = {'Content-Type': 'application/json'}
import json
obj = {'name' : 'das'}
res = r.post("http://localhost:5000/helloadv", data=json.dumps(obj),headers=headers)
res.json()
'''   

##Example DB 
from sqlalchemy import * 
from flask import jsonify, g
DATABASE = "people.db"
def get_db():
    db = getattr(g, '_database', None)  #do import g, g is global object in FLASK
    if db is None:
        db = g._database = create_engine("sqlite:///"+DATABASE)
    return db     
    
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        pass #db.close()
        
        
def getage(name):
    eg = get_db()
    q = eg.execute("select age from people where name = ?" ,name)
    return q.fetchone()[0]

@app.route("/json", methods=['POST'])   # http://localhost:5000/json with jsondata
def js():
    user = dict(username='nobody', age="nonefound")
    if 'Content-Type' in request.headers and request.headers['Content-Type'].lower() == 'application/json':
        user['username'] = request.json.get("username", "nobody")
    try:
        user['age'] = getage(user['username'])
    except:
        pass
    resp = jsonify(user)
    resp.status_code = 200
    return resp  
    
'''
headers = {'Content-Type': 'application/json'}
import json
import requests as r 
obj = {'username' : 'das'}
res = r.post("http://localhost:5000/json", data=json.dumps(obj),headers=headers)
res.json() 
''' 

#Some data creation 
from sqlalchemy import * 
DATABASE = "people.db"
db = create_engine("sqlite:///"+DATABASE)
db.execute("""create table if not exists people (name string, age int)""")
db.execute("""insert into people values(?,?)""", ["das", 20])

q = db.execute("select age from people where name=?", "das")
q.fetchone()


#OR 
with db.connect() as connection:
    result = connection.execute("select age from people where name=?", "das")
    for row in result:
        print("name:", row['name'])
        
#By default Autocommit 
conn = engine.connect()
conn.execute("INSERT INTO users VALUES (1, 'john')")  # autocommits

#OR explicitly
from sqlalchemy import text
with engine.connect().execution_options(autocommit=True) as conn:
    conn.execute(text("SELECT my_mutating_procedure()"))

##Application Globals - flask.g
#To share data that is valid for one request only from one function to another, 
#a global variable is not good enough because it would break in threaded environments. 
#Use flask.g , it is only valid for the active request 
#and that will return different values for each request. 

#methods 
'key' in g
iter(g)
g.get(name, default=None)
g.pop(name, default=<object object>)
g.setdefault(name, default=None)

##Quick Click    
What does it look like? Here is an example of a simple Click program:

import click

@click.command()
@click.option('--count', default=1, help='Number of greetings.')
@click.option('--name', prompt='Your name',help='The person to greet.')
def hello(count, name):
    """Simple program that greets NAME for a total of COUNT times."""
    for x in range(count):
        click.echo(f"Hello {name}!")

if __name__ == '__main__':
    hello()

And what it looks like when run:

python hello.py --count=3
Your name: John
Hello John!
Hello John!
Hello John!

It automatically generates nicely formatted help pages:

python hello.py --help
Usage: hello.py [OPTIONS]

  Simple program that greets NAME for a total of COUNT times.

Options:
  --count INTEGER  Number of greetings.
  --name TEXT      The person to greet.
  --help           Show this message and exit.

You can get the library directly from PyPI:

pip install click

##Using click - We need to packagify this 
mkdir flaskr
echo > flaskr\__init__.py
move  ..\quick_server.py flaskr\
move   ..\templates flaskr
move   ..\static flaskr
#__init__.py
from flask import Flask
app = Flask(__name__)
from . import quick_server
#Update quick_server.py
#from flask import Flask 
#app = Flask(__name__)
from flaskr import app

#Then add 
from flask import  g
import os.path 
from sqlalchemy import create_engine, text 

DATABASE = os.path.join(app.root_path,'database.db')

def get_db():
    db = getattr(g, '_database', None)  #do import g, g is global object in FLASK
    if db is None:
        db = g._database = create_engine("sqlite:///"+DATABASE)
    return db   

def init_db():
    db = get_db()
    with app.open_resource('schema.sql') as f:
        with db.connect().execution_options(autocommit=False) as conn:
            with conn.begin():
                for line in f.read().decode('utf8').split(";"):
                    conn.execute(text(line))   

import click 
from flask import cli 

@click.command('init-db')
@cli.with_appcontext
def init_db_command():
    """Clear the existing data and create new tables."""
    init_db()
    click.echo('Initialized the database.')

app.cli.add_command(init_db_command)


#Add schema.sql
DROP TABLE IF EXISTS people;
create table if not exists people (name string, age int);
insert into people values('das',20);
insert into people values('abc',30);

#open_resource() opens a file relative to the flaskr package,
from sqlalchemy import text
def init_db():
    db = get_db()
    with current_app.open_resource('schema.sql') as f:
        with engine.connect().execution_options(autocommit=False) as conn:
            with conn.begin():
                for line in f.read().decode('utf8').split(";"):
                    conn.execute(text(line))    



#Initialize the Database File
$ set FLASK_APP=flaskr
$ flask init-db
#Then run 
$ flask run 

##Example Login 
from flask import session, redirect, url_for #NEW
app.secret_key = b"jhdkjhdkhshd"  #NEW

from functools import wraps
def auth_required(f):
    @wraps(f)
    def _inner(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))  #login is method name 
        return f(*args, **kwargs)
    return _inner

    
@app.route("/")
@auth_required  #NEW, should be inner 
def home():   # http://localhost:5000/
    return """
            <html><body>
                <h1 id="some" class="cl2">Hello there!!! </h1>
                <h1 id="some2" class="cl2">Welcome</h1>
            </body></html>
        """

def check_auth(user, password):
    return user == 'admin' and password == 'secret'
   
@app.route("/login", methods=['GET', 'POST'])  # http://localhost:5000/login
def login():  
    if request.method == 'POST':
        name = request.form.get('name', 'all')
        password = request.form.get('pass', 'all')
        if check_auth(name, password):
            session['username'] = name
            return redirect(url_for('home'))  #home is method name 
        else:
            return "<h1>Error</h1>"
    else:
        return """
                <html><body>
                <form action="/login" method="post">
                 Name: <br/>
                 <input type="text" name="name" value="" />
                 Password: <br/>
                 <input type="password" name="pass" value="" />
                 <br/><br/>
                 <input type="submit" value="Submit" />
                </form>
                </body></html>
            """
        
'''
s = r.Session()
cred = {'name': 'admin', 'pass': 'secret'}
r1 = s.post("http://127.0.0.1:5000/login", cred)
r2 = s.get("http://127.0.0.1:5000/")
r2.text   
'''        
        
##Example upload 
import os
from flask import Flask, flash, request, redirect, url_for
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/upload', methods=['GET', 'POST']) #http://127.0.0.1:5000/upload
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file.filename:
            filename = secure_filename(file.filename) #normalizes the file path 
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('download',filename=filename))
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''
    
from flask import send_from_directory
#mimetype: str

#as_attachment: bool, attachment_filename:str, mimetype: str
@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)    
    
  
#with file upload and download 
files = {'file': open('copy.txt','rb')} #'file' same as form's name for type=file 
other_form_data = {'DB': 'photcat', 'OUT': 'csv', 'SHORT': 'short'}
r = requests.post("http://127.0.0.1:5000/upload", files=files, data=other_form_data)
r.request.url #'http://127.0.0.1:5000/download/copy.txt' , the redirected one 
r.status_code
r.headers.get('content-disposition') #'attachment; filename=copy.txt'
local_filename = r.headers.get('content-disposition').split("=")[-1]
with open(local_filename+".bak", 'wb') as f:
    f.write(r.content)

            
#for big file 
import shutil
with requests.get('http://127.0.0.1:5000/download/copy.txt', stream=True) as r:
    with open(local_filename+".bak2", 'wb') as f:
        shutil.copyfileobj(r.raw, f)           
        
        
###Middleware
The WSGI application above is a callable that behaves in a certain way. 
Middleware is a WSGI application that wraps another WSGI application. 

The outermost middleware will be called by the server. 
It can modify the data passed to it, then call the WSGI application (or further middleware) 
that it wraps, and so on. And it can take the return value of that call and modify it further.

From the WSGI server's perspective, there is one WSGI application, the one it calls directly. 
Typically, Flask is the "real" application at the end of the chain of middleware. 
But even Flask can call further WSGI applications, although that's an advanced, uncommon use case.

A common middleware you'll see used with Flask is Werkzeug's ProxyFix, 
which modifies the request to look like it came directly from a client even if it passed through 
HTTP proxies on the way. 

There are other middleware that can handle serving static files, authentication, etc.

###Flask-HTTPAuth

Flask-HTTPAuth is a Flask extension that simplifies the use of HTTP authentication with Flask routes.
Basic authentication examples

The following example application uses HTTP Basic authentication to protect route '/':

from flask import Flask
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
auth = HTTPBasicAuth()

users = {
    "john": generate_password_hash("hello"),
    "susan": generate_password_hash("bye")
}

@auth.verify_password
def verify_password(username, password):
    if username in users and \
            check_password_hash(users.get(username), password):
        return username

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.current_user())

if __name__ == '__main__':
    app.run()

The function decorated with the verify_password decorator receives the username and password sent by the client. If the credentials belong to a user, then the function should return the user object. If the credentials are invalid the function can return None or False. The user object can then be queried from the current_user() method of the authentication instance.
Digest authentication example

The following example uses HTTP Digest authentication:

from flask import Flask
from flask_httpauth import HTTPDigestAuth

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret key here'
auth = HTTPDigestAuth()

users = {
    "john": "hello",
    "susan": "bye"
}

@auth.get_password
def get_pw(username):
    if username in users:
        return users.get(username)
    return None

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.username())

if __name__ == '__main__':
    app.run()

Token Authentication Example

The following example application uses a custom HTTP authentication scheme to protect route '/' with a token:

from flask import Flask
from flask_httpauth import HTTPTokenAuth

app = Flask(__name__)
auth = HTTPTokenAuth(scheme='Bearer')

tokens = {
    "secret-token-1": "john",
    "secret-token-2": "susan"
}

@auth.verify_token
def verify_token(token):
    if token in tokens:
        return tokens[token]

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.current_user())

if __name__ == '__main__':
    app.run()

The HTTPTokenAuth is a generic authentication handler that can be used with non-standard authentication schemes, with the scheme name given as an argument in the constructor. In the above example, the WWW-Authenticate header provided by the server will use Bearer as scheme:

WWW-Authenticate: Bearer realm="Authentication Required"

The verify_token callback receives the authentication credentials provided by the client on the Authorization header. This can be a simple token, or can contain multiple arguments, which the function will have to parse and extract from the string. As with the verify_password, the function should return the user object if the token is valid.

In the examples directory you can find a complete example that uses JWS tokens. JWS tokens are similar to JWT tokens. However using JWT tokens would require an external dependency.
Using Multiple Authentication Schemes

Applications sometimes need to support a combination of authentication methods. For example, a web application could be authenticated by sending client id and secret over basic authentication, while third party API clients use a JWS or JWT bearer token. The MultiAuth class allows you to protect a route with more than one authentication object. To grant access to the endpoint, one of the authentication methods must validate.

In the examples directory you can find a complete example that uses basic and token authentication.
User Roles

Flask-HTTPAuth includes a simple role-based authentication system that can optionally be added to provide an additional layer of granularity in filtering accesses to routes. To enable role support, write a function that returns the list of roles for a given user and decorate it with the get_user_roles decorator:

@auth.get_user_roles
def get_user_roles(user):
    return user.get_roles()

To restrict access to a route to users having a given role, add the role argument to the login_required decorator:

@app.route('/admin')
@auth.login_required(role='admin')
def admins_only():
    return "Hello {}, you are an admin!".format(auth.current_user())

The role argument can take a list of roles, in which case users who have any of the given roles will be granted access:

@app.route('/admin')
@auth.login_required(role=['admin', 'moderator'])
def admins_only():
    return "Hello {}, you are an admin or a moderator!".format(auth.current_user())

In the most advanced usage, users can be filtered by having multiple roles:

@app.route('/admin')
@auth.login_required(role=['user', ['moderator', 'contributor']])
def admins_only():
    return "Hello {}, you are a user or a moderator/contributor!".format(auth.current_user())

Deployment Considerations

Be aware that some web servers do not pass the Authorization headers to the WSGI application by default. For example, if you use Apache with mod_wsgi, you have to set option WSGIPassAuthorization On as documented here.


###SQLAlchemy
$ pip install -U Flask-SQLAlchemy

Initialize the Extension

First create the db object using the SQLAlchemy constructor.

Pass a subclass of either DeclarativeBase or DeclarativeBaseNoMeta to the constructor.

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
  pass

#https://flask-sqlalchemy.readthedocs.io/en/stable/api/#flask_sqlalchemy.SQLAlchemy
db = SQLAlchemy(model_class=Base)


Once constructed, the db object gives you access to the db.Model class to define models, 
and the db.session to execute queries.

The SQLAlchemy object also takes additional arguments to customize the objects it manages.

##Configure the Extension
The next step is to connect the extension to your Flask app. 
The only required Flask app config is the SQLALCHEMY_DATABASE_URI key. 
That is a connection string that tells SQLAlchemy what database to connect to.


# create the app
app = Flask(__name__)
# configure the SQLite database, relative to the app instance folder
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
# initialize the app with the extension
db.init_app(app)

##Define Models
https://flask-sqlalchemy.readthedocs.io/en/stable/models/

SQLAlchemy 2.x offers several possible base classes for your models: DeclarativeBase or DeclarativeBaseNoMeta.
https://docs.sqlalchemy.org/en/20/orm/mapping_api.html#sqlalchemy.orm.DeclarativeBase
https://docs.sqlalchemy.org/en/20/orm/mapping_api.html#sqlalchemy.orm.DeclarativeBaseNoMeta
If desired, you can enable SQLAlchemy’s native support for data classes by adding MappedAsDataclass 
as an additional parent class.

dataclass is quick class to generate many default methods 
https://docs.python.org/3/library/dataclasses.html

from dataclasses import dataclass

@dataclass
class InventoryItem:
    """Class for keeping track of an item in inventory."""
    name: str
    unit_price: float
    quantity_on_hand: int = 0

    def total_cost(self) -> float:
        return self.unit_price * self.quantity_on_hand
        


Subclass db.Model to define a model class. The model will generate a table name 
by converting the CamelCase class name to snake_case.

from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

class User(db.Model):
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(unique=True)
    email: Mapped[str]

originally Column was used in the lower "core"/sqlalchemy.sql layer AND the higher ORM layer. 
This created a conflict of purpose. So mapped_column now supersedes Column 
when using the ORM layer to add more functionality that can't be used by the core layer. 
The core layer will keep using Column
https://docs.sqlalchemy.org/en/20/orm/declarative_tables.html#declarative-table-with-mapped-column


##Create the Tables
After all models and tables are defined, call SQLAlchemy.create_all() to create the table schema 
in the database. This requires an application context. 
Since you’re not in a request at this point, create one manually.

with app.app_context():
    db.create_all()

If you define models in other modules, you must import them before calling create_all, 
otherwise SQLAlchemy will not know about them.

create_all does not update tables if they are already in the database. 
If you change a model’s columns, use a migration library like Alembic with Flask-Alembic 
or Flask-Migrate to generate migrations that update the database schema.

##Query the Data
Within a Flask view or CLI command, you can use db.session to execute queries and modify model data.

SQLAlchemy automatically defines an __init__ method for each model that assigns 
any keyword arguments to corresponding database columns and other attributes.

db.session.add(obj) adds an object to the session, to be inserted. 
Modifying an object’s attributes updates the object. 
db.session.delete(obj) deletes an object. 

Remember to call db.session.commit() after modifying, adding, or deleting any data.

db.session.execute(db.select(...)) constructs a query to select data from the database. 

@app.route("/users")
def user_list():
    users = db.session.execute(db.select(User).order_by(User.username)).scalars()
    return render_template("user/list.html", users=users)

@app.route("/users/create", methods=["GET", "POST"])
def user_create():
    if request.method == "POST":
        user = User(
            username=request.form["username"],
            email=request.form["email"],
        )
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("user_detail", id=user.id))

    return render_template("user/create.html")

@app.route("/user/<int:id>")
def user_detail(id):
    user = db.get_or_404(User, id)
    return render_template("user/detail.html", user=user)

@app.route("/user/<int:id>/delete", methods=["GET", "POST"])
def user_delete(id):
    user = db.get_or_404(User, id)

    if request.method == "POST":
        db.session.delete(user)
        db.session.commit()
        return redirect(url_for("user_list"))

    return render_template("user/delete.html", user=user)



        
###Packaging 
STEP1: CREATE below 
poetry new flaskr
cd flaskr



#ONLy for Office PC 
Given index-url = https://<<SERVER>>/artifactory/api/pypi/<<LOCATION>>/simple/
pip config list 

poetry source add --priority=default ourpypi index-url
poetry source add --priority=supplemental PyPI

#where venv to be created 
poetry config virtualenvs.in-project true 

#STEP1.1
poetry add flask gevent

Copy static, templates and quick_server.py inside flaskr\flaskr

STEP2: UPDATE
#flaskr\flaskr\__init__.py
from flask import Flask
app = Flask(__name__)
from . import quick_server
#Update flaskr\flaskr\quick_server.py
#app = Flask(__name__)  #comment this line 
from flaskr import app

STEP3: TEST 
poetry env info
poetry shell
set FLASK_APP=flaskr 
flask run   # run whatever set in FLASK_APP

STEP4:
exit
poetry build -v
#You can find the file in dist/flaskr-0.1.0-py3-none-any.whl

FURTHER TEST 
cd ..
python -m venv .\env 
.\env\Scripts\activate
pip install flaskr/dist/flaskr-0.1.0-py3-none-any.whl
set FLASK_APP=flaskr 
flask run 


Install 
$ pip install --force-reinstall --no-dependencies dist/flaskr-0.1.0-py3-none-any.whl

STEP4:
##Deployment
#https://flask.palletsprojects.com/en/1.1.x/deploying/wsgi-standalone/

# For example to deploy via  Gevent 
pip install gevent 
#Gevent is a coroutine-based Python networking library 
#that uses greenlet to provide a high-level synchronous API on top of libev event loop:

#Execute by 'python gevent_server.py'
#gevent_server.py
from gevent.pywsgi import WSGIServer
from flaskr import app

# http_server = WSGIServer(('localhost', 443), app, keyfile='key.pem', certfile='cert.pem')
http_server = WSGIServer(('localhost', 8080), app)
http_server.serve_forever()

##To generate self signed certificate 
Note cert.pem may have public ip or localhost 
But whatever it has , must be the same as given in above 'http_server'

import requests
r = requests.get("https://localhost/helloj?name=das&format=json", verify=False)
r = requests.get("https://localhost/helloj?name=das&format=json", verify="./cert.pem")

#Create - instead of localhost, gives public IP 
#-nodes (short for no DES) for no  passphrase(else min 4 character passphrase) 
(check by 'where openssl.exe' ) 
$ openssl req -x509 -subj '/CN=localhost' -nodes -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365


Note for subjectAltName error
Check 
https://gist.github.com/KeithYeh/bb07cadd23645a6a62509b1ec8986bbc
https://serverfault.com/questions/845766/generating-a-self-signed-cert-with-openssl-that-works-in-chrome-58

###CODE-WALKTHROUGH  - Tutorials 
### Flask Tutorials 
/home/user/Projects/flask-tutorial
├── flaskr/
│   ├── __init__.py
│   ├── db.py
│   ├── schema.sql
│   ├── auth.py
│   ├── blog.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── auth/
│   │   │   ├── login.html
│   │   │   └── register.html
│   │   └── blog/
│   │       ├── create.html
│   │       ├── index.html
│   │       └── update.html
│   └── static/
│       └── style.css
├── tests/
│   ├── conftest.py
│   ├── data.sql
│   ├── test_factory.py
│   ├── test_db.py
│   ├── test_auth.py
│   └── test_blog.py
├── venv/
├── setup.py
└── MANIFEST.in


> set FLASK_APP=flaskr
> set FLASK_ENV=development
> flask init-db
> flask run
    




##->file:.\tutorial\pyproject.toml:
[project]
name = "flaskr"
version = "1.0.0"
description = "The basic blog app built in the Flask tutorial."
readme = "README.rst"
license = {text = "BSD-3-Clause"}
maintainers = [{name = "Pallets", email = "contact@palletsprojects.com"}]
dependencies = [
    "flask",
]

[project.urls]
Documentation = "https://flask.palletsprojects.com/tutorial/"

[project.optional-dependencies]
test = ["pytest"]

[build-system]
requires = ["flit_core<4"]
build-backend = "flit_core.buildapi"

[tool.flit.module]
name = "flaskr"

[tool.flit.sdist]
include = [
    "tests/",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
filterwarnings = ["error"]

[tool.coverage.run]
branch = true
source = ["flaskr", "tests"]

[tool.ruff]
src = ["src"]



##->file:.\tutorial\README.rst:
Flaskr
======

The basic blog app built in the Flask `tutorial`_.

.. _tutorial: https://flask.palletsprojects.com/tutorial/


Install
-------

**Be sure to use the same version of the code as the version of the docs
you're reading.** You probably want the latest tagged version, but the
default Git version is the main branch. ::

    # clone the repository
    $ git clone https://github.com/pallets/flask
    $ cd flask
    # checkout the correct version
    $ git tag  # shows the tagged versions
    $ git checkout latest-tag-found-above
    $ cd examples/tutorial

Create a virtualenv and activate it::

    $ python3 -m venv .venv
    $ . .venv/bin/activate

Or on Windows cmd::

    $ py -3 -m venv .venv
    $ .venv\Scripts\activate.bat

Install Flaskr::

    $ pip install -e .

Or if you are using the main branch, install Flask from source before
installing Flaskr::

    $ pip install -e ../..
    $ pip install -e .


Run
---

.. code-block:: text

    $ flask --app flaskr init-db
    $ flask --app flaskr run --debug

Open http://127.0.0.1:5000 in a browser.


Test
----

::

    $ pip install '.[test]'
    $ pytest

Run with coverage report::

    $ coverage run -m pytest
    $ coverage report
    $ coverage html  # open htmlcov/index.html in a browser



##->file:.\tutorial\flaskr\auth.py:
import functools

from flask import Blueprint
from flask import flash
from flask import g
from flask import redirect
from flask import render_template
from flask import request
from flask import session
from flask import url_for
from werkzeug.security import check_password_hash
from werkzeug.security import generate_password_hash

from .db import get_db

bp = Blueprint("auth", __name__, url_prefix="/auth")


def login_required(view):
    """View decorator that redirects anonymous users to the login page."""

    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for("auth.login"))

        return view(**kwargs)

    return wrapped_view


@bp.before_app_request
def load_logged_in_user():
    """If a user id is stored in the session, load the user object from
    the database into ``g.user``."""
    user_id = session.get("user_id")

    if user_id is None:
        g.user = None
    else:
        g.user = (
            get_db().execute("SELECT * FROM user WHERE id = ?", (user_id,)).fetchone()
        )


@bp.route("/register", methods=("GET", "POST"))
def register():
    """Register a new user.

    Validates that the username is not already taken. Hashes the
    password for security.
    """
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        db = get_db()
        error = None

        if not username:
            error = "Username is required."
        elif not password:
            error = "Password is required."

        if error is None:
            try:
                db.execute(
                    "INSERT INTO user (username, password) VALUES (?, ?)",
                    (username, generate_password_hash(password)),
                )
                db.commit()
            except db.IntegrityError:
                # The username was already taken, which caused the
                # commit to fail. Show a validation error.
                error = f"User {username} is already registered."
            else:
                # Success, go to the login page.
                return redirect(url_for("auth.login"))

        flash(error)

    return render_template("auth/register.html")


@bp.route("/login", methods=("GET", "POST"))
def login():
    """Log in a registered user by adding the user id to the session."""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        db = get_db()
        error = None
        user = db.execute(
            "SELECT * FROM user WHERE username = ?", (username,)
        ).fetchone()

        if user is None:
            error = "Incorrect username."
        elif not check_password_hash(user["password"], password):
            error = "Incorrect password."

        if error is None:
            # store the user id in a new session and return to the index
            session.clear()
            session["user_id"] = user["id"]
            return redirect(url_for("index"))

        flash(error)

    return render_template("auth/login.html")


@bp.route("/logout")
def logout():
    """Clear the current session, including the stored user id."""
    session.clear()
    return redirect(url_for("index"))



##->file:.\tutorial\flaskr\blog.py:
from flask import Blueprint
from flask import flash
from flask import g
from flask import redirect
from flask import render_template
from flask import request
from flask import url_for
from werkzeug.exceptions import abort

from .auth import login_required
from .db import get_db

bp = Blueprint("blog", __name__)


@bp.route("/")
def index():
    """Show all the posts, most recent first."""
    db = get_db()
    posts = db.execute(
        "SELECT p.id, title, body, created, author_id, username"
        " FROM post p JOIN user u ON p.author_id = u.id"
        " ORDER BY created DESC"
    ).fetchall()
    return render_template("blog/index.html", posts=posts)


def get_post(id, check_author=True):
    """Get a post and its author by id.

    Checks that the id exists and optionally that the current user is
    the author.

    :param id: id of post to get
    :param check_author: require the current user to be the author
    :return: the post with author information
    :raise 404: if a post with the given id doesn't exist
    :raise 403: if the current user isn't the author
    """
    post = (
        get_db()
        .execute(
            "SELECT p.id, title, body, created, author_id, username"
            " FROM post p JOIN user u ON p.author_id = u.id"
            " WHERE p.id = ?",
            (id,),
        )
        .fetchone()
    )

    if post is None:
        abort(404, f"Post id {id} doesn't exist.")

    if check_author and post["author_id"] != g.user["id"]:
        abort(403)

    return post


@bp.route("/create", methods=("GET", "POST"))
@login_required
def create():
    """Create a new post for the current user."""
    if request.method == "POST":
        title = request.form["title"]
        body = request.form["body"]
        error = None

        if not title:
            error = "Title is required."

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                "INSERT INTO post (title, body, author_id) VALUES (?, ?, ?)",
                (title, body, g.user["id"]),
            )
            db.commit()
            return redirect(url_for("blog.index"))

    return render_template("blog/create.html")


@bp.route("/<int:id>/update", methods=("GET", "POST"))
@login_required
def update(id):
    """Update a post if the current user is the author."""
    post = get_post(id)

    if request.method == "POST":
        title = request.form["title"]
        body = request.form["body"]
        error = None

        if not title:
            error = "Title is required."

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                "UPDATE post SET title = ?, body = ? WHERE id = ?", (title, body, id)
            )
            db.commit()
            return redirect(url_for("blog.index"))

    return render_template("blog/update.html", post=post)


@bp.route("/<int:id>/delete", methods=("POST",))
@login_required
def delete(id):
    """Delete a post.

    Ensures that the post exists and that the logged in user is the
    author of the post.
    """
    get_post(id)
    db = get_db()
    db.execute("DELETE FROM post WHERE id = ?", (id,))
    db.commit()
    return redirect(url_for("blog.index"))



##->file:.\tutorial\flaskr\db.py:
import sqlite3

import click
from flask import current_app
from flask import g


def get_db():
    """Connect to the application's configured database. The connection
    is unique for each request and will be reused if this is called
    again.
    """
    if "db" not in g:
        g.db = sqlite3.connect(
            current_app.config["DATABASE"], detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row

    return g.db


def close_db(e=None):
    """If this request connected to the database, close the
    connection.
    """
    db = g.pop("db", None)

    if db is not None:
        db.close()


def init_db():
    """Clear existing data and create new tables."""
    db = get_db()

    with current_app.open_resource("schema.sql") as f:
        db.executescript(f.read().decode("utf8"))


@click.command("init-db")
def init_db_command():
    """Clear existing data and create new tables."""
    init_db()
    click.echo("Initialized the database.")


def init_app(app):
    """Register database functions with the Flask app. This is called by
    the application factory.
    """
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)



##->file:.\tutorial\flaskr\schema.sql:
-- Initialize the database.
-- Drop any existing data and create empty tables.

DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS post;

CREATE TABLE user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE post (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author_id INTEGER NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  FOREIGN KEY (author_id) REFERENCES user (id)
);



##->file:.\tutorial\flaskr\__init__.py:
import os

from flask import Flask


def create_app(test_config=None):
    """Create and configure an instance of the Flask application."""
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        # a default secret that should be overridden by instance config
        SECRET_KEY="dev",
        # store the database in the instance folder
        DATABASE=os.path.join(app.instance_path, "flaskr.sqlite"),
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile("config.py", silent=True)
    else:
        # load the test config if passed in
        app.config.update(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    @app.route("/hello")
    def hello():
        return "Hello, World!"

    # register the database commands
    from . import db

    db.init_app(app)

    # apply the blueprints to the app
    from . import auth
    from . import blog

    app.register_blueprint(auth.bp)
    app.register_blueprint(blog.bp)

    # make url_for('index') == url_for('blog.index')
    # in another app, you might define a separate main index here with
    # app.route, while giving the blog blueprint a url_prefix, but for
    # the tutorial the blog will be the main index
    app.add_url_rule("/", endpoint="index")

    return app



##->file:.\tutorial\flaskr\static\style.css:
html {
  font-family: sans-serif;
  background: #eee;
  padding: 1rem;
}

body {
  max-width: 960px;
  margin: 0 auto;
  background: white;
}

h1, h2, h3, h4, h5, h6 {
  font-family: serif;
  color: #377ba8;
  margin: 1rem 0;
}

a {
  color: #377ba8;
}

hr {
  border: none;
  border-top: 1px solid lightgray;
}

nav {
  background: lightgray;
  display: flex;
  align-items: center;
  padding: 0 0.5rem;
}

nav h1 {
  flex: auto;
  margin: 0;
}

nav h1 a {
  text-decoration: none;
  padding: 0.25rem 0.5rem;
}

nav ul  {
  display: flex;
  list-style: none;
  margin: 0;
  padding: 0;
}

nav ul li a, nav ul li span, header .action {
  display: block;
  padding: 0.5rem;
}

.content {
  padding: 0 1rem 1rem;
}

.content > header {
  border-bottom: 1px solid lightgray;
  display: flex;
  align-items: flex-end;
}

.content > header h1 {
  flex: auto;
  margin: 1rem 0 0.25rem 0;
}

.flash {
  margin: 1em 0;
  padding: 1em;
  background: #cae6f6;
  border: 1px solid #377ba8;
}

.post > header {
  display: flex;
  align-items: flex-end;
  font-size: 0.85em;
}

.post > header > div:first-of-type {
  flex: auto;
}

.post > header h1 {
  font-size: 1.5em;
  margin-bottom: 0;
}

.post .about {
  color: slategray;
  font-style: italic;
}

.post .body {
  white-space: pre-line;
}

.content:last-child {
  margin-bottom: 0;
}

.content form {
  margin: 1em 0;
  display: flex;
  flex-direction: column;
}

.content label {
  font-weight: bold;
  margin-bottom: 0.5em;
}

.content input, .content textarea {
  margin-bottom: 1em;
}

.content textarea {
  min-height: 12em;
  resize: vertical;
}

input.danger {
  color: #cc2f2e;
}

input[type=submit] {
  align-self: start;
  min-width: 10em;
}



##->file:.\tutorial\flaskr\templates\base.html:
<!doctype html>
<title>{% block title %}{% endblock %} - Flaskr</title>
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
<nav>
  <h1><a href="{{ url_for('index') }}">Flaskr</a></h1>
  <ul>
    {% if g.user %}
      <li><span>{{ g.user['username'] }}</span>
      <li><a href="{{ url_for('auth.logout') }}">Log Out</a>
    {% else %}
      <li><a href="{{ url_for('auth.register') }}">Register</a>
      <li><a href="{{ url_for('auth.login') }}">Log In</a>
    {% endif %}
  </ul>
</nav>
<section class="content">
  <header>
    {% block header %}{% endblock %}
  </header>
  {% for message in get_flashed_messages() %}
    <div class="flash">{{ message }}</div>
  {% endfor %}
  {% block content %}{% endblock %}
</section>



##->file:.\tutorial\flaskr\templates\auth\login.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Log In{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="username">Username</label>
    <input name="username" id="username" required>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>
    <input type="submit" value="Log In">
  </form>
{% endblock %}



##->file:.\tutorial\flaskr\templates\auth\register.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Register{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="username">Username</label>
    <input name="username" id="username" required>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>
    <input type="submit" value="Register">
  </form>
{% endblock %}



##->file:.\tutorial\flaskr\templates\blog\create.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}New Post{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="title">Title</label>
    <input name="title" id="title" value="{{ request.form['title'] }}" required>
    <label for="body">Body</label>
    <textarea name="body" id="body">{{ request.form['body'] }}</textarea>
    <input type="submit" value="Save">
  </form>
{% endblock %}



##->file:.\tutorial\flaskr\templates\blog\index.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Posts{% endblock %}</h1>
  {% if g.user %}
    <a class="action" href="{{ url_for('blog.create') }}">New</a>
  {% endif %}
{% endblock %}

{% block content %}
  {% for post in posts %}
    <article class="post">
      <header>
        <div>
          <h1>{{ post['title'] }}</h1>
          <div class="about">by {{ post['username'] }} on {{ post['created'].strftime('%Y-%m-%d') }}</div>
        </div>
        {% if g.user['id'] == post['author_id'] %}
          <a class="action" href="{{ url_for('blog.update', id=post['id']) }}">Edit</a>
        {% endif %}
      </header>
      <p class="body">{{ post['body'] }}</p>
    </article>
    {% if not loop.last %}
      <hr>
    {% endif %}
  {% endfor %}
{% endblock %}



##->file:.\tutorial\flaskr\templates\blog\update.html:
{% extends 'base.html' %}

{% block header %}
  <h1>{% block title %}Edit "{{ post['title'] }}"{% endblock %}</h1>
{% endblock %}

{% block content %}
  <form method="post">
    <label for="title">Title</label>
    <input name="title" id="title" value="{{ request.form['title'] or post['title'] }}" required>
    <label for="body">Body</label>
    <textarea name="body" id="body">{{ request.form['body'] or post['body'] }}</textarea>
    <input type="submit" value="Save">
  </form>
  <hr>
  <form action="{{ url_for('blog.delete', id=post['id']) }}" method="post">
    <input class="danger" type="submit" value="Delete" onclick="return confirm('Are you sure?');">
  </form>
{% endblock %}



##->file:.\tutorial\tests\conftest.py:
import os
import tempfile

import pytest

from flaskr import create_app
from flaskr.db import get_db
from flaskr.db import init_db

# read in SQL for populating test data
with open(os.path.join(os.path.dirname(__file__), "data.sql"), "rb") as f:
    _data_sql = f.read().decode("utf8")


@pytest.fixture
def app():
    """Create and configure a new app instance for each test."""
    # create a temporary file to isolate the database for each test
    db_fd, db_path = tempfile.mkstemp()
    # create the app with common test config
    app = create_app({"TESTING": True, "DATABASE": db_path})

    # create the database and load test data
    with app.app_context():
        init_db()
        get_db().executescript(_data_sql)

    yield app

    # close and remove the temporary database
    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture
def client(app):
    """A test client for the app."""
    return app.test_client()


@pytest.fixture
def runner(app):
    """A test runner for the app's Click commands."""
    return app.test_cli_runner()


class AuthActions:
    def __init__(self, client):
        self._client = client

    def login(self, username="test", password="test"):
        return self._client.post(
            "/auth/login", data={"username": username, "password": password}
        )

    def logout(self):
        return self._client.get("/auth/logout")


@pytest.fixture
def auth(client):
    return AuthActions(client)



##->file:.\tutorial\tests\data.sql:
INSERT INTO user (username, password)
VALUES
  ('test', 'pbkdf2:sha256:50000$TCI4GzcX$0de171a4f4dac32e3364c7ddc7c14f3e2fa61f2d17574483f7ffbb431b4acb2f'),
  ('other', 'pbkdf2:sha256:50000$kJPKsz6N$d2d4784f1b030a9761f5ccaeeaca413f27f2ecb76d6168407af962ddce849f79');

INSERT INTO post (title, body, author_id, created)
VALUES
  ('test title', 'test' || x'0a' || 'body', 1, '2018-01-01 00:00:00');



##->file:.\tutorial\tests\test_auth.py:
import pytest
from flask import g
from flask import session

from flaskr.db import get_db


def test_register(client, app):
    # test that viewing the page renders without template errors
    assert client.get("/auth/register").status_code == 200

    # test that successful registration redirects to the login page
    response = client.post("/auth/register", data={"username": "a", "password": "a"})
    assert response.headers["Location"] == "/auth/login"

    # test that the user was inserted into the database
    with app.app_context():
        assert (
            get_db().execute("SELECT * FROM user WHERE username = 'a'").fetchone()
            is not None
        )


@pytest.mark.parametrize(
    ("username", "password", "message"),
    (
        ("", "", b"Username is required."),
        ("a", "", b"Password is required."),
        ("test", "test", b"already registered"),
    ),
)
def test_register_validate_input(client, username, password, message):
    response = client.post(
        "/auth/register", data={"username": username, "password": password}
    )
    assert message in response.data


def test_login(client, auth):
    # test that viewing the page renders without template errors
    assert client.get("/auth/login").status_code == 200

    # test that successful login redirects to the index page
    response = auth.login()
    assert response.headers["Location"] == "/"

    # login request set the user_id in the session
    # check that the user is loaded from the session
    with client:
        client.get("/")
        assert session["user_id"] == 1
        assert g.user["username"] == "test"


@pytest.mark.parametrize(
    ("username", "password", "message"),
    (("a", "test", b"Incorrect username."), ("test", "a", b"Incorrect password.")),
)
def test_login_validate_input(auth, username, password, message):
    response = auth.login(username, password)
    assert message in response.data


def test_logout(client, auth):
    auth.login()

    with client:
        auth.logout()
        assert "user_id" not in session



##->file:.\tutorial\tests\test_blog.py:
import pytest

from flaskr.db import get_db


def test_index(client, auth):
    response = client.get("/")
    assert b"Log In" in response.data
    assert b"Register" in response.data

    auth.login()
    response = client.get("/")
    assert b"test title" in response.data
    assert b"by test on 2018-01-01" in response.data
    assert b"test\nbody" in response.data
    assert b'href="/1/update"' in response.data


@pytest.mark.parametrize("path", ("/create", "/1/update", "/1/delete"))
def test_login_required(client, path):
    response = client.post(path)
    assert response.headers["Location"] == "/auth/login"


def test_author_required(app, client, auth):
    # change the post author to another user
    with app.app_context():
        db = get_db()
        db.execute("UPDATE post SET author_id = 2 WHERE id = 1")
        db.commit()

    auth.login()
    # current user can't modify other user's post
    assert client.post("/1/update").status_code == 403
    assert client.post("/1/delete").status_code == 403
    # current user doesn't see edit link
    assert b'href="/1/update"' not in client.get("/").data


@pytest.mark.parametrize("path", ("/2/update", "/2/delete"))
def test_exists_required(client, auth, path):
    auth.login()
    assert client.post(path).status_code == 404


def test_create(client, auth, app):
    auth.login()
    assert client.get("/create").status_code == 200
    client.post("/create", data={"title": "created", "body": ""})

    with app.app_context():
        db = get_db()
        count = db.execute("SELECT COUNT(id) FROM post").fetchone()[0]
        assert count == 2


def test_update(client, auth, app):
    auth.login()
    assert client.get("/1/update").status_code == 200
    client.post("/1/update", data={"title": "updated", "body": ""})

    with app.app_context():
        db = get_db()
        post = db.execute("SELECT * FROM post WHERE id = 1").fetchone()
        assert post["title"] == "updated"


@pytest.mark.parametrize("path", ("/create", "/1/update"))
def test_create_update_validate(client, auth, path):
    auth.login()
    response = client.post(path, data={"title": "", "body": ""})
    assert b"Title is required." in response.data


def test_delete(client, auth, app):
    auth.login()
    response = client.post("/1/delete")
    assert response.headers["Location"] == "/"

    with app.app_context():
        db = get_db()
        post = db.execute("SELECT * FROM post WHERE id = 1").fetchone()
        assert post is None



##->file:.\tutorial\tests\test_db.py:
import sqlite3

import pytest

from flaskr.db import get_db


def test_get_close_db(app):
    with app.app_context():
        db = get_db()
        assert db is get_db()

    with pytest.raises(sqlite3.ProgrammingError) as e:
        db.execute("SELECT 1")

    assert "closed" in str(e.value)


def test_init_db_command(runner, monkeypatch):
    class Recorder:
        called = False

    def fake_init_db():
        Recorder.called = True

    monkeypatch.setattr("flaskr.db.init_db", fake_init_db)
    result = runner.invoke(args=["init-db"])
    assert "Initialized" in result.output
    assert Recorder.called



##->file:.\tutorial\tests\test_factory.py:
from flaskr import create_app


def test_config():
    """Test create_app without passing test config."""
    assert not create_app().testing
    assert create_app({"TESTING": True}).testing


def test_hello(client):
    response = client.get("/hello")
    assert response.data == b"Hello, World!"


            
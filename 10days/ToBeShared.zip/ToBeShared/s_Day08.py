ML introduction 
Linear Regression and regression metrics 
PCA
Purpose of Cross validation
Describe Pipeline  and GridSearch and FeatureUnion 
Validation curve 
Learning curve 
Feature Extraction from text 
Feature Selection 
Transformation 
Logistic Regression 
SVM 
--------------------------





###ML introduction from PPT 

###All import 
from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt


###Linear Regression and regression metrics 
        
##Simple OLS 
boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
Y = boston["target"]
X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)
m = LinearRegression().fit(X_train,y_train)
m.coef_, m.intercept_
m.score(X_train,y_train)  #R^2 
m.score(X_test, y_test)
mean_squared_error(y_test, m.predict(X_test))

#scatter_matrix
from pandas.plotting import scatter_matrix
scatter_matrix(pd.DataFrame(X, columns=boston.feature_names), 
    diagonal='kde')
plt.show()


#Residual plot 
from yellowbrick.regressor import *
visualizer = ResidualsPlot(m)
visualizer.fit(X_train, y_train)  # Fit the training data to the model
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
visualizer.poof()                 # Draw/show/poof the data
#visualizer.poof(outpath="pcoords.png") #sve to file, ext determines file type 

#NOTE 
X and Y need to be two-dimensional arrays  and one dimensional of shape (n_samples, n_features)
and (n_sample, ) respectively. 
This is the case even if you only have one feature and one target.

Do you know the difference between an array of shape (6, 1) and an array of shape (6,)? 
the first is a true 2-dimensional array that happens to have one column, 
and the second is a completely 1-dimensional array.

Here's how to convert  data to 2d arrays. 

ages_train = np.array([20, 22, 25, 27, 30, 31, 31, 34, 42, 50])
ages_train[:, np.newaxis]


#Note 
https://scikit-learn.org/stable/modules/linear_model.html#generalized-linear-models
The choice of the distribution depends on the problem at hand:

If the target values are counts (non-negative integer valued) 
or relative frequencies (non-negative), you might use a Poisson distribution with a log-link.

If the target values are positive valued and skewed, you might try a Gamma distribution with a log-link.

If the target values seem to be heavier tailed than a Gamma distribution, 
you might try an Inverse Gaussian distribution 
(or even higher variance powers of the Tweedie family).

If the target values are probabilities, you can use the Bernoulli distribution. 
The Bernoulli distribution with a logit link can be used for binary classification. 
The Categorical distribution with a softmax link can be used for multiclass classification.

TweedieRegressor implements a generalized linear model 



##Lasso and Ridge and ElasticNet Regression
##Example - boston - With alpha and Lasso , coefficients are sparse 
#Execute - 3.0.linear_regression.py


##Regression Diagnostics 
#Execute 3.0.linear_regression.py

   





###Logistic Regression 
#Check 
#https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html

#Note l2 penalty 
#good for overfitting (Ridge) and highly correlated data(as coef shrinkage)
#l1 penalty
#many coef is zero, so feature selection , good for large no of features 

X, y = load_iris(return_X_y=True)
scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

clf = LogisticRegression(random_state=0, solver='lbfgs',
    multi_class='multinomial').fit(X_train, y_train)

clf.predict(X_test)
clf.predict_proba(X_test)  #predicted prob in each class 
clf.score(X_train, y_train)
clf.score(X_test, y_test)

##Clasification metrics 

#check meaning of average 
#https://scikit-learn.org/stable/modules/model_evaluation.html#from-binary-to-multiclass-and-multilabel 
#use weighted 

y_pred = clf.predict(X_test)
accuracy_score(y_test, y_pred)
confusion_matrix(y_test, y_pred)
precision_recall_fscore_support(y_test, y_pred, average='weighted')
precision_score(y_test, y_pred, average='weighted') 	
recall_score(y_test, y_pred, average='weighted') 	
f1_score(y_test, y_pred, average='weighted')
#It is possible to compute per-label precisions, recalls, F1-scores and supports 
#instead of averaging:
precision_recall_fscore_support(y_test, y_pred, average=None)

##Confusion_matric plot 
import seaborn as sns
sns.heatmap(confusion_matrix(y_test,y_pred),annot=True)

##More understanding - Clasification metrics 
false positive or false negative from prediction point of view 
Total case = N = a+b+c+d

        Actual True                             False 
Predicted 
True        a                                   b (false positive/false Alarm) - Type 1/alpha

False       c(false negative)(type-II/beta)     d

false alarm is Type 1/alpha - FAA
Accuracy = (a+d)/N 

recall,sensitivity, probability of detection = a/(a+c) = works with Actual T-SensitivityActualTrueBeta-SeATB
specificity= d/(b+d) = works with Actual F = SpecificityActualFalseAlpha - SpAFA

precision = a/(a+b) - No false alarm - PrecisionPredictedTrueAlha - PPTA
Fbeta = 1/(1/pre + 1/sen)

Since Classification model predicts probabilities of each class, 
there is some threashold required for calculating True and False. 
Hence for one threshold, we get one pair of Sensitivity and Specificity

Ideally we want to maximize both Sensitivity & Specificity. 
But this is not possible. 

Sometimes we want to be 100% sure on Predicted negatives, 
(specificity = 100%, no false alarm/positive - Actual F tested T)
Specificity(eg Testing a medicine is good(Actual T) or poisonous(actual F) ) 
ie false positive/aram is zero,
(predicted positive is zero for condition negative)

sometimes we want to be 100% sure on Predicted positives, 
(sensitivity = 100%, no false negative - Actual T tested F)
Sensitivity(eg Predicting a customers good or bad before issuing the loan ) 
ie false negative is zero (predicted negative is zero for condition positive)

The threshold is set based on business problem

Sensitivity and Specificity are inversely proportional to each other. 
So when we increase Sensitivity, Specificity decreases 
When we decrease the threshold, we get more positive values 
thus it increases the sensitivity and decreasing the specificity.

As FPR is 1 - specificity. So when we increase TPR(sensitivity), 
FPR also increases and vice versa
(FPR - False positive rate-false alarm/alpha, TPR-true positive rate)

ROC Curve
Consider all the possible threshold values 
and the corresponding specificity and sensitivity rate
ROC(Receiver operating characteristic) curve is drawn by taking 
(1- specificity) on X-axis and sensitivity on Y- axis.
    

ROC and AUC
We want that curve to be far away from the straight line. 
Ideally, we want the area under the curve as high as possible. 
ie AUC. Area Under the Curve needs to be 1

ROC Curve Gives us an idea on the performance of the model 
under all possible values of threshold.

AUC=1.0, It is perfectly able to distinguish between positive class and negative class.

AUC=0.7, it means there is 70% chance that model will be able 
to distinguish between positive class and negative class.

AUC=0.5, model has no discrimination capacity to distinguish 
between positive class and negative class.

AUC=0.0, model is actually reciprocating the classes. 
It means, model is predicting negative class as a positive class and vice versa

##Understanding macro 
Multiclass classification
    a classification task with more than two classes;
    e.g., classify a set of images of fruits which may be oranges, apples, or pears.
    Multiclass classification makes the assumption that each sample is assigned to one and only one label
    a fruit can be either an apple or a pear but not both at the same time .
    All classifiers in scikit-learn do multiclass classification out-of-the-box
    Other than inherently multiclass classifier, there are strategies for reducing the problem of multiclass
    classification to multiple binary classification - One Vs the Rest and One vs One
    
One-vs-One: Here, you pick 2 classes at a time, and train a two-class-classifier using samples 
from the selected two classes only (other samples are ignored in this step). 
You repeat this for all the two class combinations. 
So you end up with N(N-1)/2 classifiers. 
And while testing, you do voting among these classifiers.

One-vs-Rest: Here, you pick one class and train a two-class-classifier 
with the samples of the selected class on one side and all the other samples on the other side. 
Thus, you end up with N classifiers. While testing, you simply classify the sample 
as belonging to the class with maximum score among the N classifiers.


    
"macro" (average of all averages)
    calculates the mean of the binary metrics, giving equal weight to each class. 
    For example, for precision PrA=TpA/(TpA+FpA) for class A, ... for other classes 
    macro = (PrA+PrB+...)/No_of_classes, where PrA means Precision of class A
    
    In problems where infrequent classes are nonetheless important,     
    macro-averaging may be a means of highlighting their performance. 
    On the other hand, the assumption that all classes are equally important is often untrue, 
    such that macro-averaging will over-emphasize the typically low performance 
    on an infrequent class.

"weighted" (wt average of all averages, wt comes from no of support)
    accounts for class imbalance by computing the average of binary metrics 
    in which each class's score is weighted by its presence in the true data sample.
    (recommended to use this)
    wt = (SupportA*PrA + .....)/Total_Support

"micro" ( average of actual data)
    gives each sample-class pair an equal contribution to the overall metric 
    (except as a result of sample-weight).
    micro = (TpA + TpB + ....)/(TpA + FpA + TpB + FpB + ......)
    
    Rather than summing the metric per class, this sums the dividends and divisors 
    that make up the per-class metrics to calculate an overall quotient. 
    Micro-averaging may be preferred in multilabel settings, 
    including multiclass classification where a majority class is to be ignored.
    
    Support     Sensitivity
A 100 cases     90%  = 900/(900+100)
B 100 cases     80%  = 800/(800+200)
C 100 cases     90%  = 900/(900+100)

macro = (90%+80%+90%)/3 
wt = (100*90%+100*80%+100*90%)/300
micro = (900+800+900)/(900+100+800+200+900+100)


##Understand Conditional Probability 
One example 
in a class , boy wearing hat is 30%, girl wearing hat is 10% 
boy is of 40% and girl is of 60% 
Now hat is seen what is the prob that is on boy  or girl 
Pr(Boy|hat) = p(hat|Boy)*P(boy)/P(hat) = (0.3 * .4)/(.3*4 + .6*.1)
Pr(Girl|hat) =(.6*.1)/(.3*4 + .6*.1)

            hat .3
     boy, .4---
           no hat .7
class -- 
            hat .1
     girl, .6
            nohat .9
            

#Another example 
        symptom    Yes  No     Total 
--------------------------------------------
       Yes          1    0      1
cancer No          10    99989  99999
       total       11    99989  100000


                        P(Symp|Cancer)*P(Cancer)
P(Cancer|Symp) = -------------------------------------------------------------------
                 P(Symp) = P(Symp|Cancer)*P(Cancer) + P(Symp|NOCancer) * P(NOCancer)
     
              = (1 * 1/1e5)/(1*1/1e5 + 10/99999 * 99999/1e5) = 1/11 ~ 9.1%
              
Cancer=Actual, Symptoms = Tested 
Sensitivity = Cancer T Symp T /(Above + Cancer T Symp F=beta) = 1/1 = 100% 
specifity =   Cancer F Symp F / (above + Cancer F symp T) = 99989/(99989+10)=99.99%
accuracy = (Cancer T Symp T + Cancer F Symp F)/T = (1+99989)/100000 = 99.99%
Precesion = Cancer T Symp T/(above + Cancer F Symp T) = 1/(1+10)= 9%
Fbeta = 1/(1/precision + 1/sensitivity) = 8%


###ADVANCED: 
##Multicollinearity and Individual Impact of Variables
#Execute - 4.1.logistic_regression_vif_feature_importance.py 

##PCA
#execute 2.1.plot_pca.py


##Overfit vs underfit 
#Execute 2.3.plot_underfitting_overfitting.py

##Bias ,Variance and it's Tradeoff
#Execute 2.2.plot_train_error_vs_test_error.py



###Purpose of Cross validation
#https://scikit-learn.org/stable/modules/cross_validation.html

lr = LinearRegression()
boston = load_boston()
y = boston.target
CV= KFold(n_splits=10,shuffle=True)
scores = cross_val_score(lr, boston.data, y, cv=CV) 
print(scores.mean(), scores.std() )


##ADVANCED: Execute 2.4.plot_cv_predict.py


###ADVANCED:Feature Extraction from text 
#Extraction from Text , CountVectorizer - tokenization and count frequency 
#This model has many parameters, however the default values are quite reasonable 
#TfidfVectorizer - Equivalent to CountVectorizer followed by TfidfTransformer
#Tf means term-frequency while tf–idf means term-frequency times inverse document-frequency


vectorizer = CountVectorizer()
tf = TfidfVectorizer()
>>> vectorizer                     
CountVectorizer(analyzer=...'word', binary=False, decode_error=...'strict',
        dtype=<... 'numpy.int64'>, encoding=...'utf-8', input=...'content',
        lowercase=True, max_df=1.0, max_features=None, min_df=1,
        ngram_range=(1, 1), preprocessor=None, stop_words=None,
        strip_accents=None, token_pattern=...'(?u)\\b\\w\\w+\\b',
        tokenizer=None, vocabulary=None)

#corpus is list of Sentences or line 
import glob
#list of list 
lst = [open(name, "rt").readlines() for name in glob.glob("data/corpus/*")]
corpus = [ line.strip() for inner in lst for line in inner]

X = vectorizer.fit_transform(corpus)
>>> X                              
<4x9 sparse matrix of type '<... 'numpy.int64'>'
    with 19 stored elements in Compressed Sparse ... format>

vectorizer.get_feature_names()#see the feature name 
X.toarray()       

X = tf.fit_transform(corpus)
>>> X                              
<4x9 sparse matrix of type '<... 'numpy.int64'>'
    with 19 stored elements in Compressed Sparse ... format>

tf.get_feature_names()#see the feature name 
X.toarray() 




###Feature Selection and Pipeline 
iris = load_iris()
X, y = iris.data, iris.target 

# This dataset is way too high-dimensional. Better do PCA:
X_new = PCA(n_components=1).fit_transform(X,y)
>>> X_new.shape
(150, 1)

# Maybe some original features where good, too?
selection = SelectKBest(chi2, k=1).fit_transform(X,y)
>>> X_new.shape
(150, 1)

Chi-square (Χ2) distributions are a family of continuous probability distributions. They’re widely used 
in hypothesis tests, including the chi-square goodness of fit test and the chi-square test 
of independence.

Imagine taking a random sample of a standard normal distribution (Z). 
If you squared all the values in the sample, you would have the chi-square distribution with k = 1.


#OR Build estimator from PCA and Univariate selection:
pca = PCA(n_components=1)
selection = SelectKBest(chi2, k=1)
combined_features = FeatureUnion([("pca", pca),  
    ("univ_select", selection)])

lr = LogisticRegression()
pipeline = Pipeline([("features", combined_features), 
("lr", lr)])

pipeline.steps[0]
pipeline.named_steps['lr']
pipeline.get_params()
pipeline.get_params().keys()
pipeline.set_params(lr__C=10) 
pipeline.set_params(features__kernel_pca__kernel='rbf')


param_grid = dict(features__pca__n_components=[1, 2, 3],
                  features__univ_select__k=[1, 2],
                  lr__C=[0.1, 1, 10])

grid_search = RandomizedSearchCV(pipeline, 
    param_grid=param_grid, cv=5, verbose=10)
grid_search.fit(X_train, y_train)
final_model = grid_search.best_estimator_
grid_search.best_params_ 
print(final_model)
y_pred = final_model.predict(X_test)
final_model.score(X_train, y_train)
accuracy_score(y_test, y_pred) #y_true, y_pred




###transformation 

iris = pd.read_csv('data/iris.csv')
#For compatbility reasons, to work with pandas , convert pandas DF to ndArray 
#Note latest version of sklearn can directly take pandas(coerce with np.array())
#but , if pandas has all numeric, then OK, else, convert to ndArray as object- which is NotOK
#can convert to ndarray.astype(floaf64) etc 
dataset_array = iris.values[:, 0:4].astype(float64)
dataset_array.dtype
#or 
np.array(iris.iloc[:, 0:4])
#or 
mat = iris.iloc[:, 0:4].as_matrix()

#How ever sklearn preprocessing works on full array, not individual features 
#Note .fit(X), then .transform(X), .inverse_transform(transformed)
#each column of X is one feature 
y = string or numeric categorical 
    Use LabelEncoder(takes 1D/vector ie (n,)) to convert to integer 0...No_Of_classes,
    Note, one hot encoding (LabelBinarizer()) is not required for y at all
    (but LabelBinarizer() exists for converting binary classification to multi-class, 
    which done by sklearn by default)
X = string categorical , must be one hot encoded 
        Use LabelEncoder(1D/vector) , convert to (n,1) 
        ( reshape(-1,1)  or reshape(n,1) or [:, np.newaxis]
        and then use OneHotEncoder(takes 2D)
    numeric categorical - must be one hot encoded 
        Use OneHotEncoder(takes 2D)

All other values can be directly used
But X may require some below (all, .fit() takes 2D, first four takes 1D as well), all has default parameters
    sklearn.preprocessing.StandardScaler for mean=0, unit std , feature/columnwise 
        Check with .mean(axis=0), .std(axis=0)
    MinMaxScaler for [min,max] or MaxAbsScaler for [0,1], feature/columnwise 
    RobustScaler  for data with outlier , feature/columnwise
    If feature independence is required, 
        Put it with sklearn.decomposition.PCA(whiten=True) #ie n_components=None
    QuantileTransformer puts all features into the same, known range or distribution.
    PowerTransformer to Normal distribution featurewise 
    Normalizer  for each samples to have unit norm (row wise)
    Binarizer(threshold=..)thresholding numerical features to get boolean values
    PolynomialFeatures(n) to add a + b + ... + a*a +... + a*b + b*c+... (including iteraction term) 
        interaction_only=True, only interaction term 
    SimpleImputer(missing_values=np.nan, strategy='mean') for imputing missing value   

Feature Selection , fit(X,y) 
    SelectKBest removes all but the highest scoring features
    SelectFromModel is a meta-transformer that can be used along with any estimator that has a coef_ or feature_importances_ attribute after fitting.
    
Feature Extraction from text 
    CountVectorizer implements both tokenization and occurrence counting in a single class:
    TfidfVectorizer that combines all the options of CountVectorizer and TfidfTransformer in a single model:
    
    
##iris transformation 
iris = pd.read_csv('iris.csv')
X_raw = iris.iloc[:, 0:4].astype(np.float64)
y_raw = iris.iloc[:, 4]
lenc = LabelEncoder()
std = StandardScaler()
X = std.fit_transform(X_raw)
y = lenc.fit_transform(y_raw)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0) #DF
clf = LogisticRegression()
clf.fit(X_train, y_train)
clf.score(X_test, y_test)

y_pred = clf.predict(X_test)
accuracy_score(y_test, y_pred) #y_true, y_pred
confusion_matrix(y_test, y_pred)

list(lenc.inverse_transform(y_pred))

#or with pipeline 


###Example -  Titanic Data processing 
#Let's go through an example from Kaggle, the Titanic dataset. 
#The task here is to predict who will survive on Titanic, 
#based on a subset of whole dataset.
0. Note survived is 'y', rest all are 'X' 
1. Replace nan values of embarked, fare by mode of embarked, fare 
2. Create a transformer with following transformation 
   String categorical - embarked, pclass, sex, Title
                        FamilyID
   Take as it is - fare, parch , sibsp , FamiliySize, AgeOriginallyNaN
                   AgeFilledMedianByTitle   
   Create following columns as 
        Title - get Title portion from name
        LastName  - get last name ftom name 
        FamilySize - total of sibsp and parch + 1 
        FamilyID  - String of "LastName:FamiliySize"
                    If FamiliySize <=2 , then "Small_Family"
        AgeOriginallyNaN - new column where 0 = age is NaN, 1 = age is not NaN 
            Hint: Use .isnull() and convert to int 
        AgeFilledMedianByTitle , median age for that Title 
            Find median age for each title(groupby)
            then merge that with original DF on Title 
            
 

#Solutions 
from sklearn_pandas import *

df_train = pd.read_csv('toBeShared/data/titanic_train.csv', header = 0, index_col = 'ticket')
df_test = pd.read_csv('toBeShared/data/titanic_test.csv', header = 0, index_col = 'ticket')

#axis=0 , means vertical(row) stacking , axis=1, columnwise append 
df = pd.concat([df_train, df_test], keys=["train", "test"])

df.index.get_level_values(0)  #train, test 
df.index.get_level_values(1)  #ticket
df.index.names # [None, 'ticket']
df.index.names = ['type', 'ticket']
df.index.get_level_values('type')
df.index.get_level_values('ticket')
df.columns 
>>> df['sex'].reset_index()
       type              ticket     sex
0     train           A/5 21171    male
1     train            PC 17599  female

#get back 
df.loc['train', :]
df.loc['test', :]
df.loc[:, 'name' : 'sibsp']  #for all index 
df.loc[('train', '113803') , :] #one row 
df.iloc[3:4, :]  #DF 

#df.mode() gives DF of most frequent , take first col 
#replace NaN of 'fare' by mode of that 
df.loc[df['fare'].isnull(), 'fare'] = df['fare'].mode()[0]
#or could be used fillna as well 
df.fillna({'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] }, inplace=True)
#or could use replace 
df.replace({'fare':np.nan, 'embarked': np.nan}, {'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] }, inplace=True)

#drop cabin 
df.drop(columns='cabin', inplace=True)

#check any more null 
df[df.isnull().any(axis=1)]  #axis=1 is row 
df[df.isnull().any(axis=1)].loc['train',:]


#Setting up 
#Series.apply can take py fn or ufun, py fn- operates on eah element 
#df.apply has to be ufunc , if python func, vectorise with np.vectorize 
df['Title'] = df['name'].apply(lambda c: c[c.index(',') + 2 : c.index('.')])
df['LastName'] = df['name'].apply(lambda n: n[0:n.index(',')])

df['FamilySize'] = df['sibsp'] + df['parch'] + 1

df['FamilyID'] = df['LastName'] + ':' + df['FamilySize'].apply(str) #python fn, so operates on each element 
#if family size is <=2 
df.loc[df['FamilySize'] <= 2, 'FamilyID'] = 'Small_Family'

#convert age to 0 or 1 based on age is NaN or present 
df['AgeOriginallyNaN'] = df['age'].isnull().astype(int)

#for each title, get median age , and rename that column as AgeFilledMedianByTitle
medians_by_title = pd.DataFrame(df.groupby('Title')['age'].median()) \
  .rename(columns = {'age': 'AgeFilledMedianByTitle'}) #index is Title 
  
#Then for each row, fill AgeFilledMedianByTitle column 
#ie merge with df.Title with medians_by_title.index
#that merge would hamper original [train, test] sort order , hence sort_index 
df = df.merge(medians_by_title, left_on = 'Title', right_index = True) \
  .sort_index(level = 0).sort_index(level = 1) #by level 0 and the level=1 
  
#after processing , split 
df_train = df.ix['train']
df_test  = df.ix['test'].drop(columns=['survived'])

#Note Categoricals are embarked, pclass, sex , title, FamilyIDD 


#to create dummy variables out of categorical ones. 
#In Scikit ,algorithms accept only float variables.


transformations = [
                      ('embarked', LabelBinarizer()),
                      ('fare', None),
                      ('parch', None),
                      ('pclass', LabelBinarizer()),
                      ('sex', LabelBinarizer()),
                      ('sibsp', None),                                       
                      ('Title', LabelBinarizer()),
                      ('FamilySize', None),
                      ('FamilyID', LabelBinarizer()),
                      ('AgeOriginallyNaN', None),
                      ('AgeFilledMedianByTitle', None)]
                      
                      
%pip pip install sklearn-pandas
The mapper takes a list of tuples. 
Each tuple has three elements:
    column name(s): The first element is a column name from the pandas DataFrame, 
    or a list containing one or multiple columns 
    or an instance of a callable function such as make_column_selector.
    transformer(s): The second element is an object which will perform the transformation 
    which will be applied to that column.
    attributes: The third one is optional and is a dictionary containing the transformation options, 
    if applicable 
    #Example 
    >>> mapper = DataFrameMapper([
    ...     ('pet', sklearn.preprocessing.LabelBinarizer()),
    ...     (['children'], sklearn.preprocessing.StandardScaler())
    ... ])
    The difference between specifying the column selector as 'column' (as a simple string) 
    and ['column'] (as a list with one element) is the shape of the array that is passed to the transformer.
    In the first case, a one dimensional array will be passed, 
    while in the second case it will be a 2-dimensional array with one column, i.e. a column vector.



        
mapper = DataFrameMapper(transformations)

arr = mapper.fit_transform(df_train)


#Create pipeline 
pipeline = Pipeline([('featurize', mapper), ('forest', RandomForestClassifier())])

X = df_train[df_train.columns.drop('survived')]
y = df_train['survived']
model = pipeline.fit(X = X, y = y)
model.score(X, y)
#prediction
prediction = model.predict(df_test)  #their is no truth value 


###Example - mushroom 
mush = pd.read_csv("data/mushroom.csv")
mush.head()
lenc = LabelEncoder()
oh = OneHotEncoder()
X_raw = mush.iloc[:, 1:]
y_raw = mush.iloc[:, 0]
y = lenc.fit_transform(y_raw)
X_raw1 = X_raw.apply(lambda col: lenc.fit_transform(col)) #3
X_raw1.head() 
X = oh.fit_transform(X_raw1) #20 features
X.toarray()
X_raw1['shape'].unique()
X_raw1['surface'].unique()
X_raw1['color'].unique()

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
param_grid = dict(C= [0.001, 0.1, 1, 10, 100])
clf= LogisticRegression()
gs = GridSearchCV(clf, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) #{'C': 100, 'penalty': 'l1'}
from yellowbrick.classifier import *
vis = ROCAUC(LogisticRegression(**gs.best_params_))
vis.fit(X_train, y_train)
vis.score(X_test, y_test)
vis.poof()
y_pred = gs.predict(X_test)

###Example - spam/Ham
sp = pd.read_csv("data/spam.csv", encoding='latin-1')
sp.head()
lenc = LabelEncoder()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]
y = lenc.fit_transform(y_raw)
tf = TfidfVectorizer()
X = tf.fit_transform(X_raw )

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
param_grid = dict(C= [0.001, 0.1, 1, 10, 100])
clf= LogisticRegression()
gs = GridSearchCV(clf, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)


#with ngrams 1,2 
sp = pd.read_csv("data/spam.csv", encoding='latin-1')
sp.head()
lenc = LabelEncoder()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]
y = lenc.fit_transform(y_raw)

tf = TfidfVectorizer(ngram_range=(1,2))
X = tf.fit_transform(X_raw ) #very high now 

pca = TruncatedSVD(n_components=1000)
lr = LogisticRegression()

X_train, X_test, y_train, y_test = train_test_split(
        X_raw,y, random_state=0) 
        
pipeline = Pipeline([
    ("tf", tf), 
    ('pca', TruncatedSVD(n_components=1000)),  
    ("lr", lr)])

param_grid = dict(lr__C=[100,500])
gs = GridSearchCV(pipeline, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)


###Example - MNIST DATABASE
from PIL import Image

im = Image.open("data/4.jpg").convert('L')
im.thumbnail( (28,28) )
data = np.asarray(im)
#invert such that 0 becomes 255 
data = 255-data 
#im.show()
plt.imshow(data, cmap=plt.cm.gray_r, interpolation='nearest')
plt.show()
one_row=data.ravel()
one_row.shape
#Image dataset - this is 8x8 
digits = load_digits() #['DESCR', 'data', 'images', 'target', 'target_names']
print(digits.DESCR)
n_samples = len(digits.images)  #2D
plt.axis('off')
plt.imshow(digits.images[1], cmap=plt.cm.gray_r, interpolation='nearest')
plt.title('digit: %i' % digits.target[1])

#minst - 28x28     
from keras.datasets import mnist
(x_train, y_train), (x_test, y_test) = mnist.load_data()
plt.axis('off')
plt.imshow(x_train[0], cmap=plt.cm.gray_r, interpolation='nearest')
plt.title('digit: %i' % y_train[0])
#convert to 2D 
x_train.reshape(x_train.shape[0],-1).shape

#Anyway 
X_train, X_test, y_train, y_test = train_test_split(
        digits.data,digits.target, random_state=0) 
C_range = np.logspace(-2, 10, 3)
gamma_range = np.logspace(-9, 3, 3)
params = dict(gamma=gamma_range, C=C_range, kernel=['linear', 'rbf'])
gs = RandomizedSearchCV(SVC(), params)
gs.fit(X_train, y_train)
gs.score(X_train, y_train)
gs.score(X_test, y_test)






###Model Saving and loading 
import pickle
s = pickle.dumps(final_model) #or pickle.dump(final_model, open("final","wb"))
clf = pickle.loads(s)         #clf = pickle.load(open("final", "rb"))
accuracy_score(y_test, clf.predict(X_test))





###Validation curve 
#Execute 3.1.validation_curve_linear_regression.py

###Learning curve 
#Execute 3.2.learning_curve_linear_regression.py




Decision Trees 
Ensemble Methods 
CatBoost vs. Light GBM vs. XGBoost
Linear Discriminant Analysis
Naive Bayes Classifier,Gaussian Naïve Bayes Classifier
Clustering with KMeans    
K-mode for classifications
------------------------


### SVM 

#Execute 
#5.1.plot_svm_kernels.py

###Example - Describe Pipeline  and GridSearch and FeatureUnion with SVC 

from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.datasets import load_digits

digits = load_digits()
pca1 = PCA()
svm1 = SVC(gamma='scale')
pipe = Pipeline([('reduce_dim', pca1), ('clf', svm1)])
>>> pipe.fit(digits.data, digits.target)
Pipeline(memory=None,
         steps=[('reduce_dim', PCA(...)), ('clf', SVC(...))])
# The pca instance can be inspected directly
>>> print(pca1.components_) 
    [[-1.77484909e-19  ... 4.07058917e-18]]

>>> pipe 
Pipeline(memory=None,
         steps=[('reduce_dim', PCA(copy=True,...)),
                ('clf', SVC(C=1.0,...))])
                
#The estimators of a pipeline are stored as a list in the steps attribute:
>>> pipe.steps[0]
('reduce_dim', PCA(copy=True, iterated_power='auto', n_components=None, random_state=None,
  svd_solver='auto', tol=0.0, whiten=False))

#and as a dict in named_steps:
>>> pipe.named_steps['reduce_dim']
PCA(copy=True, iterated_power='auto', n_components=None, random_state=None,
  svd_solver='auto', tol=0.0, whiten=False)

#Parameters of the estimators , <estimator>__<parameter> 
>>> pipe.set_params(clf__C=10) 
Pipeline(memory=None,
         steps=[('reduce_dim', PCA(copy=True, iterated_power='auto',...)),
                ('clf', SVC(C=10, cache_size=200, class_weight=None,...))])

#Attributes of named_steps map to keys
pipe.named_steps.reduce_dim is pipe.named_steps['reduce_dim']

#for Grid search 
from sklearn.model_selection import GridSearchCV
param_grid = dict(reduce_dim__n_components=[2, 5, 10], 
                    clf__C=[0.1, 10, 100])
grid_search = GridSearchCV(pipe, param_grid=param_grid)

#Individual steps may also be replaced as parameters, 
#and non-final steps may be ignored by setting them to None:
from sklearn.linear_model import LogisticRegression
param_grid = dict(reduce_dim=[None, PCA(5), PCA(10)],
              clf=[SVC(), LogisticRegression()], 
              clf__C=[0.1, 10, 100])
grid_search = RandomizedSearchCV(pipe, param_grid=param_grid)

print("Best param for Pipeline ", grid_search.best_params_ )
print("Best Model")
best_model = search.best_estimator_
print(best_model)


#FeatureUnion combines several transformer objects into a new transformer 
#that combines their output
#FeatureUnion and Pipeline can be combined to create complex models.

from sklearn.pipeline import FeatureUnion
from sklearn.decomposition import PCA
from sklearn.decomposition import KernelPCA
estimators = [('linear_pca', PCA()), 
('kernel_pca', KernelPCA())]
combined = FeatureUnion(estimators)
>>> combined 
FeatureUnion(n_jobs=None,
             transformer_list=[('linear_pca', PCA(copy=True,...)),
                               ('kernel_pca', KernelPCA(alpha=1.0,...))],
             transformer_weights=None)

#individual steps may be replaced using set_params, 
#and ignored by setting to 'drop':
>>> combined.set_params(kernel_pca='drop')
FeatureUnion(n_jobs=None,
             transformer_list=[('linear_pca', PCA(copy=True,...)),
                               ('kernel_pca', 'drop')],
             transformer_weights=None)


pipe = Pipeline([('reduce_dim', combined), ('clf', SVC())])

pipe.steps[0]
pipe.named_steps['reduce_dim']
pipe.get_params()
pipe.get_params().keys()
pipe.set_params(clf__C=10) 
pipe.set_params(reduce_dim__kernel_pca__kernel='rbf')




##Advanced 
#Fitting transformers may be computationally expensive. 
#With its memory parameter set, 
#Pipeline will cache each transformer after calling fit.

#Warning - Side effect of caching transformers 
#with Cache enabled, original instances of estimators can not be accessed 

from tempfile import mkdtemp
from shutil import rmtree
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
estimators = [('reduce_dim', PCA()), ('clf', SVC())]
cachedir = mkdtemp()
pipe = Pipeline(estimators, memory=cachedir)
>>> pipe 
Pipeline(...,
         steps=[('reduce_dim', PCA(copy=True,...)),
                ('clf', SVC(C=1.0,...))])
# Clear the cache directory when you don't need it anymore
rmtree(cachedir)


###Example - taiwan credits defaults uci data
#last column default- Yes=1, no=0
X2: Gender (1 = male; 2 = female).
X3: Education(0-6) (1 = graduate school; 2 = university; 3 = high school; 4 = others).
X4: Marital status(0-3) (1 = married; 2 = single; 3 = others)

#convert to OnhotEncoding 
#https://archive.ics.uci.edu/dataset/350/default+of+credit+card+clients
df = pd.read_excel("data/default of credit card clients.xls", header=1)
oh = OneHotEncoder()
y = df.iloc[:, -1]

#from here 
X_one = df.iloc[:, [2,3,4]]
#X_one1 = X_one.applymap(lambda e: e-1)
#or 
#X_one2 =X_one.replace([1,2,3,4,5],[0,1,2,3,4])
X_other = pd.concat([df['LIMIT_BAL'], df.iloc[:,5:-1]]   ,axis=1)
#>>> X_one1.SEX.unique()
#array([1, 0], dtype=int64)
#>>> X_one1.EDUCATION.unique()
#array([ 1,  0,  2,  4,  3,  5, -1], dtype=int64)
#>>> X_one.EDUCATION.unique()
#array([2, 1, 3, 5, 4, 6, 0], dtype=int64)
#>>> X_one.MARRIAGE.unique()
#array([1, 2, 3, 0], dtype=int64)
X = pd.concat([pd.DataFrame(oh.fit_transform(X_one).toarray()),X_other], axis=1)


X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
# C_range = np.logspace(-2, 10, 2)
# gamma_range = np.logspace(-9, 3, 2)
# params = dict(gamma=gamma_range, C=C_range, kernel=['rbf']) #grid search takes long time 
# gs = RandomizedSearchCV(SVC(), params, n_jobs=-1)
#gs = SVC(kernel='linear', random_state=0) #takes long time 
gs1 = SGDClassifier(loss='hinge', random_state=0) #linear SVM 
gs1.fit(X_train, y_train)
#print(gs1.best_params_)
gs1.score(X_train, y_train)
gs1.score(X_test, y_test)
#Then save themodel 
import pickle 
pickle.dump(gs.best_estimator_, open("final","wb"))
clf = pickle.load(open("final", "rb"))
clf.score(X_test, y_test)

#OR with pipeline 
df = pd.read_excel("data/default of credit card clients.xls", header=1)

y = df.iloc[:, -1]
def process(arr):
    X_one = arr[:, 2:5]
    X_other = np.concatenate([arr[:,1:2], arr[:,5:-1]]   , axis=1) #requires 2D
    oh = OneHotEncoder()
    X = np.concatenate([oh.fit_transform(X_one).toarray(),X_other], axis=1)
    return X 

ft = FunctionTransformer(process)
X = ft.fit_transform(df.values)

pipe = Pipeline([('ft', ft),('clf', SGDClassifier(loss='hinge', random_state=0))])

X_train, X_test, y_train, y_test = train_test_split(
        df.values,y, random_state=0) 
alpha = np.logspace(-4, 10, 10)
params = dict(clf__alpha=alpha)
gs = RandomizedSearchCV(pipe, params, random_state=0)
gs.fit(X_train, y_train)
print(gs.best_params_)
gs.score(X_train, y_train)
gs.score(X_test, y_test)


###Advanced 
#understanding decision_function and predict 
#Note SVM does not provide Pr ie predict_proba 

import numpy as np
X = np.array([[-1, -1], [-2, -1], [1, 1], [2, 1]])
y = np.array([1, 1, 2, 2])
from sklearn.svm import SVC
clf = SVC() #default , decision_function_shape='ovr'
clf.fit(X, y) 
#each value is proportional to the distance of the each sample to the separating hyperplane

>>> clf.decision_function(X)

array([[-1.00052254],
       [-1.00006594],
       [ 1.00029424],
       [ 1.00029424]])
>>> clf.predict(X)
array([1, 1, 2, 2])

#'classes_', 'coef_' 'support_', 'support_vectors_'
clf.classes_
clf.coef_       #only for linear problem
clf.support_    #SupportVectorIndices — Vector of indices that specify the rows in the training data(X_train), that were selected as support vectors 
clf.support_vectors_  #are subset of features (rows of X_train) which are used for decision boundary
#X.tolist().index([6.8, 3. , 5.5, 2.1])  # 112 
clf.n_support_ # get number of support vectors for each class

clf.score(X, y)  #Returns the mean accuracy on the given test data and labels.
#OR 
from sklearn.metrics import f1_score
f1_score(y, clf.predict(X), average='macro')

#plot hyperplan  
def make_meshgrid(x_min, x_max, y_min,y_max, h=.02):
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
        np.arange(y_min, y_max, h))
    return xx, yy

#plot computed support vector x, y ie nearest vectors to the plane
#s = marker size , so support vectors are bigger 
plt.scatter(clf.support_vectors_[:, 0], 
     clf.support_vectors_[:, 1], 
     zorder=10, s=80,
     facecolors='none',edgecolors='k')
#Plot original x, y, c=index to cmap, which is Paired ie has two colors based on true Y 
#s = default size 
plt.scatter(X[:, 0], X[:, 1], c= y==2, 
    zorder=10,
    cmap=plt.cm.Paired,
    edgecolors='k')
plt.axis('tight')
x_min = -3
x_max = 3
y_min = -3
y_max = 3

XX, YY = make_meshgrid(x_min,x_max,y_min,y_max)
Z = clf.decision_function(np.c_[XX.ravel(), 
    YY.ravel()])

# Put the result into a color plot
Z = Z.reshape(XX.shape)
#plt.cm.Paired for two color, 'k' means black 
#Since it is binary with hyperplan 0,0, hence Z>0 means one side or Z <0 means other side 
plt.pcolormesh(XX, YY, Z>0 , cmap=plt.cm.Paired)
plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)
plt.show()

#ovo multiclass 
clf = SVC(decision_function_shape='ovo')
clf.fit(X, y) 

>>> clf.decision_function(X)
array([-1.00052254, -1.00006594,  1.00029424,  1.00029424])
clf.predict(X)


#Multiclass 
import numpy as np
X = np.array([[-1, -1], [-2, -1], [1, 1], [2, 1], [1, -1], [2, -1], [-1, 1], [-2, 1]])
y = np.array([1, 1, 2, 2, 3,3,4,4])
from sklearn.svm import SVC
clf = SVC(decision_function_shape='ovr') #default 
clf.fit(X, y) 

>>> clf.decision_function(X)  # nsamples x nclasses=4
array([[ 3.49993658, -0.20445551,  0.84138923,  1.8631297 ],
       [ 3.49996196, -0.19038267,  0.81322323,  1.87719749],
       [-0.20441746,  3.49989853,  1.86314567,  0.84137326],
       [-0.19042072,  3.5       ,  1.87719259,  0.81322813],
       [ 0.84137011,  1.86312959,  3.49995569, -0.2044554 ],
       [ 0.81324234,  1.87720255,  3.49994284, -0.19038774],
       [ 1.86314556,  0.84135415, -0.20441736,  3.49991765],
       [ 1.87719766,  0.81324724, -0.19042578,  3.49998089]])
       
>>> clf.predict(X)
array([1, 1, 2, 2, 3, 3, 4, 4])

clf = SVC(decision_function_shape='ovo')
clf.fit(X, y) 

>>> clf.decision_function(X) #nsamples x n_classes * (n_classes-1) / 2 = 6
array([[ 1.00052254,  0.99954879,  0.99999999, -0.091113  , -0.13528231, -0.0433722 ],
       [ 1.00006594,  0.99977817,  1.0003795 , -0.00711987, -0.13528231, -0.12817112],
       [-1.00029424, -0.13528231, -0.091113  ,  0.99999999,  0.99954879, 0.04346801],
       [-1.00029424, -0.13528231, -0.00711987,  1.0003795 ,  0.99977817, 0.12814175],
       [-0.0433722 , -0.99966348,  0.091113  , -0.99999999,  0.13528165, 1.00052254],
       [-0.12817112, -0.99966348,  0.00711987, -1.0003795 ,  0.1353127 , 1.00006594],
       [ 0.04346801,  0.13528165, -0.99999999,  0.091113  , -0.99966348, -1.00029424],
       [ 0.12814175,  0.1353127 , -1.0003795 ,  0.00711987, -0.99966348, -1.00029424]])
array([1, 1, 2, 2, 3, 3, 4, 4])

#The decision function tells us on which side of the hyperplane generated 
#by the classifier we are (and how far we are away from it). 
#Based on that information, the estimator then label the examples 
#with the corresponding label.

#ie decision function that tells us how close to the seperating line we are 
#(close to the boundary means a low-confidence decision)
#This function Returns (n_samples, n_classes * (n_classes-1) / 2) for ovo, 
#for ovr, the shape is (n_samples, n_classes).
#each value is proportional to the distance of the each sample to the separating hyperplane

#Note SVC is inherently binary 
#to make it multiclass, by default OneVsOne ie requires to fit n_classes * (n_classes - 1) / 2 classifiers
#This strategy consists in fitting one classifier per class pair. 

#Note other methods is OneVsRest, this strategy consists in fitting one classifier per class. 
#For each classifier, the class is fitted against all the other classes.

#At prediction time, the class which received the most votes is selected
cs = list of class names
votes = [(i if decision[p] > 0 else j) for p,(i,j) in enumerate((i,j) 
                                           for i in range(len(cs))
                                           for j in range(i+1,len(cs)))]
return cs[max(set(votes), key=votes.count)]




#SVC Example with decision boundary 
#See and Execute 5.2.svc_iris.py

#and for digits recognition 
#See and Execute 5.2.svc.py


###Clustering with KMeans    

#Kmeans 
from sklearn.cluster import KMeans


iris = pd.read_csv('data/iris.csv')

iris_m = iris.assign( 
SepalRatio = lambda df: df.SepalWidth / df.SepalLength, 
PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')
plt.show()

features = iris_m[ ['SepalRatio','PetalRatio' ]]#.values not required 
kmeans = KMeans(n_clusters=2, random_state=0).fit(features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
       
#Execute - 10.1.cluster_elbow.py

#Execute - 10.5.plot_color_quantization.py



###Decision Trees 
#download graphviz and update 
#set PATH=C:\Program Files (x86)\Graphviz2.38\bin;%PATH%

#Execute 6.1.decision_tree.py

    
### Ensemble Methods 

##Loan data 
#The debt-to-income ratio is the percentage of your gross monthly income 
#that goes to paying your monthly debt payments.

#annual_inc	The self-reported annual income provided by the borrower during registration.
#A charge-off or chargeoff is the declaration by a creditor (usually a credit card account) 
#that an amount of debt is unlikely to be collected. 
#This occurs when a consumer becomes severely delinquent on a debt.
# Traditionally, creditors will make this declaration at the point of six months without payment.


#https://www.kaggle.com/wendykan/lending-club-loan-data
df = pd.read_csv('data/loan.csv')
df.index = df.id 
df = df.dropna(how='all',axis=1) #axis=0, rowwise, axis=1 columnswise 

# >>> df.loan_status.unique()
# array(['Fully Paid', 'Charged Off', 'Current', 'Default',
#        'Late (31-120 days)', 'In Grace Period', 'Late (16-30 days)'],
#       dtype=object)
df = df.loc[df.loan_status !=  'Current' , :] #remove current data 
df['target'] = df.loan_status.apply(lambda v: 1 if v == 'Fully Paid' else 0)
#Get subset 
y = df['target']
X = df[['annual_inc','loan_amnt', 'funded_amnt','dti']].dropna() 

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 

clf1 = DecisionTreeClassifier()
clf2 = RandomForestClassifier(n_estimators=100)
clf3 = ExtraTreesClassifier(n_estimators=100)
clf4 =  AdaBoostClassifier(n_estimators=100)
clf5 =  GradientBoostingClassifier(n_estimators=100)
names = [ 'DT', 'RF', 'ER', 'Ada', 'GBM']
pipe = Pipeline([('clf', clf1)])

grid = dict(
 clf=[clf1,clf2, clf3, clf4, clf5], 
)
search = GridSearchCV(pipe, param_grid=grid)
search.fit(X_train,y_train)
search.best_estimator_
search.best_params_
search.score(X_test, y_test)#.81 

#FImport 
clf5 #the best model or best_estimator_.named_steps['reg']
clf5.feature_importances_
df2 = pd.DataFrame(  
    clf5.feature_importances_,
    index=X.columns , columns=['FI'])
df2 = df2.reset_index().sort_values(by=['FI'],ascending=False)   
df2.index = df2['index']
df2.drop('index', axis=1, inplace=True)
df2['FI'] = df2.FI.apply(lambda e: "%d%%" %(e*100,))

#Advanced - Lets see wheather with these features, can we improve ?
#or should we increase any feature ?
#earlier - .81


clf5 =  GradientBoostingClassifier(n_estimators=100,
    validation_fraction=0.2, n_iter_no_change=5)
grid = dict( learning_rate =[ 0.1, 0.05, 0.001],
    subsample=[1,0.5,.3,.8],
    max_features=[2,4],
    max_depth=[4,8,16,32])

search = RandomizedSearchCV(clf5, grid, verbose=2)   
search.fit(X_train,y_train)
search.score(X_train,y_train)
best = search.best_params_
search.score(X_test, y_test)

#with more features 
#'total_pymnt' is hidden 
X = df[['annual_inc','loan_amnt', 'funded_amnt','dti', 'target']]

df['home_ownership_1'] = LabelEncoder().fit_transform(df.home_ownership)
df['application_type_1'] = LabelEncoder().fit_transform(df.application_type)
new_X = df[[ 'application_type_1', 'home_ownership_1']]
new_X1 = pd.DataFrame(OneHotEncoder().fit_transform(new_X).toarray(), index=X.index)
data = X.join(new_X1).dropna() #index-index joining
y = data.target 
X = data.drop('target', axis=1)
   
X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 

clf5 =  GradientBoostingClassifier(n_estimators=100,
    validation_fraction=0.2, n_iter_no_change=5, **best)         
clf5.fit(X_train,y_train)
clf5.score(X_train,y_train)
clf5.score(X_test, y_test)        
#with new features 
best = gs.best_params_
data['term'] = df.term.str.slice(0,3).astype(float)
new_features = ['int_rate', 'total_pymnt']
y = data.target 
X1 = data.drop('target', axis=1)
X = pd.concat([df[new_features],X1], axis=1)
X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0)        
clf5 = GradientBoostingClassifier(n_estimators=100,
    validation_fraction=0.2, n_iter_no_change=5, **best)
clf5.fit(X_train, y_train)
clf5.score(X_train, y_train) #??
clf5.score(X_test, y_test) 
df2 = pd.DataFrame(clf5.feature_importances_,
 index=X.columns.tolist(), columns=['FI'])
df2 = df2.reset_index().sort_values(by=['FI'],
    ascending=False)
df2.index = df2['index']
df2.drop('index', axis=1, inplace=True)
df2['FI'] = df2.FI.apply(lambda e: "%d%%" % (e*100,))     
      
        
        
## Regression
import time 
data = load_boston()
X, y = data.data, data.target 
CV= KFold(n_splits=5,shuffle=True)
X_train, X_test, y_train, y_test = train_test_split(X,y) #random splitting 

clf1 = DecisionTreeRegressor()
clf2 = RandomForestRegressor(n_estimators=100)
clf3 = ExtraTreesRegressor(n_estimators=100)
clf4 =  AdaBoostRegressor(n_estimators=100)
clf5 =  GradientBoostingRegressor(n_estimators=100)
names = [ 'DT', 'RF', 'ER', 'Ada', 'GBM']
pipe = Pipeline([('reg', clf1)])

grid = dict(
 reg=[clf1,clf2, clf3, clf4, clf5], 
)
search = GridSearchCV(pipe, param_grid=grid)
search.fit(X_train,y_train)
search.best_estimator_
search.best_params_
search.score(X_test, y_test)#.87 
#Additional 
search.cv_results_['params'] = names 
search.cv_results_['param_clf'] = names 
search.cv_results_['param_reg'] = names 
df = pd.DataFrame(search.cv_results_)
df
#FImport 
clf5 #the best model or best_estimator_.named_steps['reg']
clf5.feature_importances_
df2 = pd.DataFrame(  
    clf5.feature_importances_,
    index=data.feature_names, columns=['FI'])
df2 = df2.reset_index().sort_values(by=['FI'],ascending=False)   
df2.index = df2['index']
df2.drop('index', axis=1, inplace=True)
df2['FI'] = df2.FI.apply(lambda e: "%d%%" %(e*100,))







###Tpot 
https://towardsdatascience.com/tpot-automated-machine-learning-in-python-4c063b3e5de9
#Execute - 19.1.tpot_regression.py


###Artificial Neural Networks using keras 
Keras is now available for
JAX, TensorFlow, PyTorch, and OpenVINO!


#Tensorflow - Installation only on 3.5.2 x64 bit 
$ pip3 install --upgrade tensorflow
#https://stackoverflow.com/questions/47068709/your-cpu-supports-instructions-that-this-tensorflow-binary-was-not-compiled-to-u
#for AVX or GPU versions 

#MSVCP140.DLL  must be in system32 
#https://www.microsoft.com/en-us/download/details.aspxid=53587

$ pip install keras

You can export the environment variable KERAS_BACKEND 
or you can edit your local config file at ~/.keras/keras.json to configure your backend. 

Available backend options are: "jax", "tensorflow", "torch". Example:

export KERAS_BACKEND="jax"
set KERAS_BACKEND=tensorflow

https://keras.io/getting_started/


#Also, image algorithms works with float64, 0-1, not uint8
#To convert to and fro 
data = ...
info = np.iinfo(data.dtype) # Machine limits for integer types.
data = data.astype(np.float64) / info.max # normalize the data to 0 - 1
#convert to  uint8
data = 255 * data # Now scale by 255
img = data.astype(np.uint8)




#There are two types of models available in Keras: 
#the Sequential model and the Model class used with functional API.

#These models have many common methods 
model.summary()
    prints a summary representation of model. Shortcut for utils.print_summary
model.get_config()
    returns a dictionary containing the configuration of the model. 
    The model can be reinstantiated from its config via
    #Example 
    config = model.get_config()
    model = Model.from_config(config)
    # or, for Sequential:
    model = Sequential.from_config(config)
model.get_weights()
    returns a list of all weight tensors in the model, as Numpy arrays.
model.set_weights(weights)
    sets the values of the weights of the model, from a list of Numpy arrays. 
    The arrays in the list should have the same shape as those returned by get_weights().
model.to_json()
    returns a representation of the model as a JSON string. 
    Note that the representation does not include the weights, only the architecture. 
    You can reinstantiate the same model (with reinitialized weights) from the JSON string via:
    #Example 
    from models import model_from_json
    json_string = model.to_json()
    model = model_from_json(json_string)
model.save_weights(filepath)
    saves the weights of the model as a HDF5 file.
    HDF5:A versatile data model that can represent very complex data objects and a wide variety of metadata.
    Pandas support reading from HDF5 
    df_tl = pd.DataFrame(dict(A=list(range(5)), B=list(range(5))))
    df_tl.to_hdf('store_tl.h5','table',append=True)
    pd.read_hdf('store_tl.h5', 'table', where = ['index>2'])
model.load_weights(filepath, by_name=False)
    loads the weights of the model from a HDF5 file (created by save_weights).
    By default, the architecture is expected to be unchanged. 
    To load weights into a different architecture (with some layers in common), 
    use by_name=True to load only those layers with the same name.         
model.layers 
    a list of the layers added to the model.
model.get_layer( name=None, index=None)
    Retrieve a layer that is part of the model.
    Returns a layer based on either its name (unique) or its index in the graph. 
    Indices are based on order of horizontal graph traversal (bottom-up).
    Arguments
        name: string, name of layer.
        index: integer, index of layer.
    Returns
        A layer instance.  
        
#Methods at keras level       
keras.models.save_model(model, filepath, overwrite=True, include_optimizer=True):
    Save a model to a HDF5 file.
    The saved model contains:
        - the model's configuration (topology)
        - the model's weights
        - the model's optimizer's state (if any)        
keras.models.load_model(filepath, custom_objects=None, compile=True):
    Loads a model saved via `save_model`.    
    Returns
            A Keras model instance  
keras.models.model_from_json(json_string, custom_objects=None):
    Parses a JSON model configuration file and returns a model instance.    
keras.models.model_from_yaml(yaml_string, custom_objects=None):
    Parses a yaml model configuration file and returns a model instance.
        

#The neural network might give different results with different start weights
#use initializers https://keras.io/initializers/
from keras import initializers
model.add(Dense(64,
                kernel_initializer='random_uniform',
                bias_initializer='zeros'))

#Solution of Overfitting, use regularizers   or Dropout(.n) which randomly drops out neuron 
#https://keras.io/regularizers/
#l2 gives shrinkage, l1 gives sparse feature              
from keras import regularizers
model.add(Dense(64, input_dim=64,
                kernel_regularizer=regularizers.l2(0.01),
                activity_regularizer=regularizers.l1(0.01)))  
                
                
##Compatibility matrix
JAX compatibility

The following Keras + JAX versions are compatible with each other:
    jax==0.4.20 & keras~=3.0

TensorFlow compatibility

The following Keras + TensorFlow versions are compatible with each other:

To use Keras 2:
    tensorflow~=2.13.0 & keras~=2.13.0
    tensorflow~=2.14.0 & keras~=2.14.0
    tensorflow~=2.15.0 & keras~=2.15.0

To use Keras 3:
    tensorflow~=2.16.1 & keras~=3.0

PyTorch compatibility

The following Keras + PyTorch versions are compatible with each other:
    torch~=2.1.0 & keras~=3.0
    
##AutoKeras
Supported Tasks:
    Image Classification
    Image Regression
    Text Classification
    Text Regression




##Examples and resources 
https://github.com/markusschanta/awesome-keras
https://github.com/keras-team/keras-io


Computer Vision -Image classification
    Image classification from scratch
    Simple MNIST convnet
    Image classification via fine-tuning with EfficientNet
    Image classification with Vision Transformer
    Classification using Attention-based Deep Multiple Instance Learning
    Image classification with modern MLP models
    A mobile-friendly Transformer-based model for image classification
    Pneumonia Classification on TPU
    Compact Convolutional Transformers
    Image classification with ConvMixer
    Image classification with EANet (External Attention Transformer)
    Involutional neural networks
    Image classification with Perceiver
    Few-Shot learning with Reptile
    Semi-supervised image classification using contrastive pretraining with SimCLR
    Image classification with Swin Transformers
    Train a Vision Transformer on small datasets
    A Vision Transformer without Attention
    Image Classification using Global Context Vision Transformer
    When Recurrence meets Transformers
    Image Classification using BigTransfer (BiT)
Image segmentation
    Image segmentation with a U-Net-like architecture
    Multiclass semantic segmentation using DeepLab+
    Highly accurate boundaries segmentation using BASNet
    Image Segmentation using Composable Fully-Convolutional Networks
Object detection
    Object Detection with RetinaNet
    Keypoint Detection with Transfer Learning
    Object detection with Vision Transformers
3D
    3D image classification from CT scans
    Monocular depth estimation
    3D volumetric rendering with NeRF
    Point cloud segmentation with PointNet
    Point cloud classification
OCR
    OCR model for reading Captchas
    Handwriting recognition
Image enhancement
    Convolutional autoencoder for image denoising
    Low-light image enhancement using MIRNet
    Image Super-Resolution using an Efficient Sub-Pixel CNN
    Enhanced Deep Residual Networks for single-image super-resolution
    Zero-DCE for low-light image enhancement
Data augmentation
    CutMix data augmentation for image classification
    MixUp augmentation for image classification
    RandAugment for Image Classification for Improved Robustness
Image & Text
    Image captioning
    Natural language image search with a Dual Encoder
Vision models interpretability
    Visualizing what convnets learn
    Model interpretability with Integrated Gradients
    Investigating Vision Transformer representations
    Grad-CAM class activation visualization
Image similarity search
    Near-duplicate image search
    Semantic Image Clustering
    Image similarity estimation using a Siamese Network with a contrastive loss
    Image similarity estimation using a Siamese Network with a triplet loss
    Metric learning for image similarity search
    Metric learning for image similarity search using TensorFlow Similarity
    Self-supervised contrastive learning with NNCLR
Video
    Video Classification with a CNN-RNN Architecture
    Next-Frame Video Prediction with Convolutional LSTMs
    Video Classification with Transformers
    Video Vision Transformer
Performance recipes
    Gradient Centralization for Better Training Performance
    Learning to tokenize in Vision Transformers
    Knowledge Distillation
    FixRes: Fixing train-test resolution discrepancy
    Class Attention Image Transformers with LayerScale
    Augmenting convnets with aggregated attention
    Learning to Resize
Other
    Semi-supervision and domain adaptation with AdaMatch
    Barlow Twins for Contrastive SSL
    Consistency training with supervision
    Distilling Vision Transformers
    Focal Modulation: A replacement for Self-Attention
    Using the Forward-Forward Algorithm for Image Classification
    Masked image modeling with Autoencoders
    Segment Anything Model with 🤗Transformers
    Semantic segmentation with SegFormer and Hugging Face Transformers
    Self-supervised contrastive learning with SimSiam
    Supervised Contrastive Learning
    Efficient Object Detection with YOLOV8 and KerasCV
Natural Language Processing - Text classification
    Text classification from scratch
    Review Classification using Active Learning
    Text Classification using FNet
    Large-scale multi-label text classification
    Text classification with Transformer
    Text classification with Switch Transformer
    Text classification using Decision Forests and pretrained embeddings
    Using pre-trained word embeddings
    Bidirectional LSTM on IMDB
    Data Parallel Training with KerasHub and tf.distribute
Machine translation
    English-to-Spanish translation with KerasHub
    English-to-Spanish translation with a sequence-to-sequence Transformer
    Character-level recurrent sequence-to-sequence model
Entailment prediction
    Multimodal entailment
Named entity recognition
    Named Entity Recognition using Transformers
Sequence-to-sequence
    Text Extraction with BERT
    Sequence to sequence learning for performing number addition
Text similarity search
    Semantic Similarity with KerasHub
    Semantic Similarity with BERT
    Sentence embeddings using Siamese RoBERTa-networks
Language modeling
    End-to-end Masked Language Modeling with BERT
    Abstractive Text Summarization with BART
    Pretraining BERT with Hugging Face Transformers
Parameter efficient fine-tuning
    Parameter-efficient fine-tuning of GPT-2 with LoRA
Other
    MultipleChoice Task with Transfer Learning
    Question Answering with Hugging Face Transformers
    Abstractive Summarization with Hugging Face Transformers
Structured Data - Structured data classification
    Structured data classification with FeatureSpace
    FeatureSpace advanced use cases
    Imbalanced classification: credit card fraud detection
    Structured data classification from scratch
    Structured data learning with Wide, Deep, and Cross networks
    Classification with Gated Residual and Variable Selection Networks
    Classification with TensorFlow Decision Forests
    Classification with Neural Decision Forests
    Structured data learning with TabTransformer
Structured data regression
    Deep Learning for Customer Lifetime Value
Recommendation
    Collaborative Filtering for Movie Recommendations
    A Transformer-based recommendation system
Timeseries- Timeseries classification
    Timeseries classification from scratch
    Timeseries classification with a Transformer model
    Electroencephalogram Signal Classification for action identification
    Event classification for payment card fraud detection
Anomaly detection
    Timeseries anomaly detection using an Autoencoder
Timeseries forecasting
    Traffic forecasting using graph neural networks and LSTM
    Timeseries forecasting for weather prediction
Other
    Electroencephalogram Signal Classification for Brain-Computer Interface
Generative Deep Learning-Image generation
    Denoising Diffusion Implicit Models
    A walk through latent space with Stable Diffusion 3
    DreamBooth
    Denoising Diffusion Probabilistic Models
    Teach StableDiffusion new concepts via Textual Inversion
    Fine-tuning Stable Diffusion
    Variational AutoEncoder
    GAN overriding Model.train_step
    WGAN-GP overriding Model.train_step
    Conditional GAN
    CycleGAN
    Data-efficient GANs with Adaptive Discriminator Augmentation
    Deep Dream
    GauGAN for conditional image generation
    PixelCNN
    Face image generation with StyleGAN
    Vector-Quantized Variational Autoencoders
    A walk through latent space with Stable Diffusion
Style transfer
    Neural style transfer
    Neural Style Transfer with AdaIN
Text generation
    GPT2 Text Generation with KerasHub
    GPT text generation from scratch with KerasHub
    Text generation with a miniature GPT
    Character-level text generation with LSTM
    Text Generation using FNet
Audio generation
    Music Generation with Transformer Models
Graph generation
    Drug Molecule Generation with VAE
    WGAN-GP with R-GCN for the generation of small molecular graphs
Other
    Density estimation using Real NVP
Audio Data-Vocal track separation
    Vocal Track Separation with Encoder-Decoder Architecture
Speech recognition
    Automatic Speech Recognition with Transformer
Other
    Automatic Speech Recognition using CTC
    MelGAN-based spectrogram inversion using feature matching
    Speaker Recognition
    Audio Classification with the STFTSpectrogram layer
    English speaker accent recognition using Transfer Learning
    Audio Classification with Hugging Face Transformers
Reinforcement Learning
    Actor Critic Method
    Proximal Policy Optimization
    Deep Q-Learning for Atari Breakout
    Deep Deterministic Policy Gradient (DDPG)
Graph Data
    Graph attention network (GAT) for node classification
    Node Classification with Graph Neural Networks
    Message-passing neural network (MPNN) for molecular property prediction
    Graph representation learning with node2vec
Quick Keras Recipes-Keras usage tips
    Parameter-efficient fine-tuning of Gemma with LoRA and QLoRA
    Float8 training and inference with a simple Transformer model
    Keras debugging tips
    Customizing the convolution operation of a ConD layer
    Trainer pattern
    Endpoint layer pattern
    Reproducibility in Keras Models
    Writing Keras Models With TensorFlow NumPy
    Simple custom layer example: Antirectifier
    Packaging Keras models for wide distribution using Functional Subclassing
Serving
    Serving TensorFlow models with TFServing
ML best practices
    Estimating required sample size for model training
    Memory-efficient embeddings for recommendation systems
    Creating TFRecords
Other
    Approximating non-Function Mappings with Mixture Density Networks
    Probabilistic Bayesian Neural Networks
    Knowledge distillation recipes
    Evaluating and exporting scikit-learn metrics in a Keras callback
    How to train a Keras model on TFRecord files

##Reference -Keras 3 API documentation
https://keras.io/api/
Models API
    The Model class
    The Sequential class
    Model training APIs
    Saving & serialization
Layers API
    The base Layer class
    Layer activations
    Layer weight initializers
    Layer weight regularizers
    Layer weight constraints
    Core layers
    Convolution layers
    Pooling layers
    Recurrent layers
    Preprocessing layers
    Normalization layers
    Regularization layers
    Attention layers
    Reshaping layers
    Merging layers
    Activation layers
    Backend-specific layers
Callbacks API
    Base Callback class
    ModelCheckpoint
    BackupAndRestore
    TensorBoard
    EarlyStopping
    LearningRateScheduler
    ReduceLROnPlateau
    RemoteMonitor
    LambdaCallback
    TerminateOnNaN
    CSVLogger
    ProgbarLogger
    SwapEMAWeights
Ops API
    NumPy ops
    NN ops
    Linear algebra ops
    Core ops
    Image ops
    FFT ops
Optimizers
    SGD
    RMSprop
    Adam
    AdamW
    Adadelta
    Adagrad
    Adamax
    Adafactor
    Nadam
    Ftrl
    Lion
    Lamb
    Loss Scale Optimizer
Metrics
    Base Metric class
    Accuracy metrics
    Probabilistic metrics
    Regression metrics
    Classification metrics based on True/False positives & negatives
    Image segmentation metrics
    Hinge metrics for "maximum-margin" classification
    Metric wrappers and reduction metrics
Losses
    Probabilistic losses
    Regression losses
    Hinge losses for "maximum-margin" classification
Data loading
    Image data loading
    Timeseries data loading
    Text data loading
    Audio data loading
Built-in small datasets
    MNIST digits classification dataset
    CIFAR10 small images classification dataset
    CIFAR100 small images classification dataset
    IMDB movie review sentiment classification dataset
    Reuters newswire classification dataset
    Fashion MNIST dataset, an alternative to MNIST
    California Housing price regression dataset
Keras Applications
    Xception
    EfficientNet B0 to B7
    EfficientNetV2 B0 to B3 and S, M, L
    ConvNeXt Tiny, Small, Base, Large, XLarge
    VGG16 and VGG19
    ResNet and ResNetV2
    MobileNet, MobileNetV2, and MobileNetV3
    DenseNet
    NasNetLarge and NasNetMobile
    InceptionV3
    InceptionResNetV2
Mixed precision
    Mixed precision policy API
Multi-device distribution
    LayoutMap API
    DataParallel API
    ModelParallel API
    ModelParallel API
    Distribution utilities
RNG API
    SeedGenerator class
    Random operations
Utilities
    Experiment management utilities
    Model plotting utilities
    Structured data preprocessing utilities
    Tensor utilities
    Python & NumPy utilities
    Scikit-Learn API wrappers
    Keras configuration utilities

###Example -XOR Logic using MLP & Backpropagation
import numpy as np

from keras.models import Sequential
from keras.layers import Dense, Input 


#ie 0,0 => 0 
training_data = np.array([[0,0],[0,1],[1,0],[1,1]], "float32")
target_data = np.array([[0],[1],[1],[0]], "float32")

model = Sequential()
#Regular densely-connected NN layer.
#32 , dimensionality of the output space.
#activation: Activation function to use . 
#input_dim= n , for n features or (x,y) for 2D feature 
model.add(Input(shape=(2,)))
model.add(Dense(32,  activation='relu'))
#use relu for internal and for classification, use sigmoid or softmax 
model.add(Dense(1, activation='sigmoid'))

>>> model.summary()
Model: "sequential_3"
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ Layer (type)                    ┃ Output Shape            ┃       Param # ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ dense_4 (Dense)                 │ (None, 32)              │            96 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ dense_5 (Dense)                 │ (None, 1)               │            33 │
└─────────────────────────────────┴─────────────────────────┴───────────────┘
 Total params: 129 (516.00 B)
 Trainable params: 129 (516.00 B)
 Non-trainable params: 0 (0.00 B)
 

#https://keras.io/losses/
#for regression, use loss = mean_squared_error
#for classification, use categorical_crossentropy(multiclass) or binary_crossentropy(binary class)

#optimizer https://keras.io/optimizers/
#Use adam in general, for complex NN, use Nadam

#Metrics https://keras.io/metrics/, not used for training, only evaluation 
#Use any from losse as well 
#for regression, use metrics.mae  , mean absolute error 
#classification use metrics.binary_accuracy,metrics.categorical_accuracy(y_true, y_pred)

model.summary()
model.compile(loss='mean_squared_error', optimizer='adam', metrics=['binary_accuracy'])

#epoch - how many passes of full x,y data , 
model.fit(training_data, target_data, epochs=100, verbose=2)

model.predict(training_data) #in float64
#for binary, round it 
predictions = model.predict(training_data)
rounded = [round(x[0]) for x in predictions]
print(rounded)

scores = model.evaluate(training_data, target_data) #here metrics are used 
#returns [ test loss, accuracy]
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
#binary_accuracy: 100.00%


##Reference 
keras.Input(
    shape=None,
    batch_size=None,
    dtype=None,
    sparse=None,
    batch_shape=None,
    name=None,
    tensor=None,
    optional=False,
)

Used to instantiate a Keras tensor.

A Keras tensor is a symbolic tensor-like object, which we augment 
with certain attributes that allow us to build a Keras model just by knowing the inputs 
and outputs of the model.

For instance, if a, b and c are Keras tensors, it becomes possible to do: 
model = Model(input=[a, b], output=c)

Arguments
    shape: A shape tuple (tuple of integers or None objects), 
    not including the batch size. For instance, shape=(32,) indicates that the expected input will be batches of 32-dimensional vectors. Elements of this tuple can be None; None elements represent dimensions where the shape is not known and may vary (e.g. sequence length).
    batch_size: Optional static batch size (integer).
    dtype: The data type expected by the input, as a string (e.g. "float32", "int32"...)
    sparse: A boolean specifying whether the expected input will be sparse tensors. 
    Note that, if sparse is False, sparse tensors can still be passed into the input - 
    they will be densified with a default value of 0. This feature is only supported 
    with the TensorFlow backend. Defaults to False.
    batch_shape: Optional shape tuple (tuple of integers or None objects), including the batch size.
    name: Optional name string for the layer. Should be unique in a model (do not reuse the same name twice). It will be autogenerated if it isn't provided.
    tensor: Optional existing tensor to wrap into the Input layer. If set, the layer will use 
    this tensor rather than creating a new placeholder tensor.
    optional: Boolean, whether the input is optional or not. 
    An optional input can accept None values.

Returns

A Keras tensor.

Example

# This is a logistic regression in Keras
x = Input(shape=(32,))
y = Dense(16, activation='softmax')(x)
model = Model(x, y)


keras.layers.Dense(
    units,
    activation=None,
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="zeros",
    kernel_regularizer=None,
    bias_regularizer=None,
    activity_regularizer=None,
    kernel_constraint=None,
    bias_constraint=None,
    lora_rank=None,
    **kwargs
)
Just your regular densely-connected NN layer.

Dense implements the operation: 
output = activation(dot(input, kernel) + bias) 
where activation is the element-wise activation function passed as the activation argument, 

kernel is a weights matrix created by the layer, 
and bias is a bias vector created by the layer (only applicable if use_bias is True).

Note: If the input to the layer has a rank greater than 2, 
Dense computes the dot product between the inputs and the kernel along the last axis of the inputs 
and axis 0 of the kernel (using tf.tensordot). 
For example, if input has dimensions (batch_size, d0, d1), then we create a kernel 
with shape (d1, units), and the kernel operates along axis 2 of the input, 
on every sub-tensor of shape (1, 1, d1) (there are batch_size * d0 such sub-tensors). 
The output in this case will have shape (batch_size, d0, units).

Arguments

    units: Positive integer, dimensionality of the output space.
    activation: Activation function to use. If you don't specify anything, no activation is applied (ie. "linear" activation: a(x) = x).
    use_bias: Boolean, whether the layer uses a bias vector.
    kernel_initializer: Initializer for the kernel weights matrix.
    bias_initializer: Initializer for the bias vector.
    kernel_regularizer: Regularizer function applied to the kernel weights matrix.
    bias_regularizer: Regularizer function applied to the bias vector.
    activity_regularizer: Regularizer function applied to the output of the layer (its "activation").
    kernel_constraint: Constraint function applied to the kernel weights matrix.
    bias_constraint: Constraint function applied to the bias vector.
    lora_rank: Optional integer. If set, the layer's forward pass will implement LoRA (Low-Rank Adaptation) with the provided rank. LoRA sets the layer's kernel to non-trainable and replaces it with a delta over the original kernel, obtained via multiplying two lower-rank trainable matrices. This can be useful to reduce the computation cost of fine-tuning large dense layers. You can also enable LoRA on an existing Dense layer by calling layer.enable_lora(rank).

Input shape
N-D tensor with shape: (batch_size, ..., input_dim). 
The most common situation would be a 2D input with shape (batch_size, input_dim).

Output shape
N-D tensor with shape: (batch_size, ..., units). For instance, 
for a 2D input with shape (batch_size, input_dim), the output would have shape (batch_size, units).

    
###Keras - hello world  - A MNIST convnet

training a convnet to classify MNIST digits.


import numpy as np
import os
import keras
# Load the data and split it between train and test sets
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# Scale images to the [0, 1] range
x_train = x_train.astype("float32") / 255
x_test = x_test.astype("float32") / 255
# Make sure images have shape (28, 28, 1)
x_train = np.expand_dims(x_train, -1)
x_test = np.expand_dims(x_test, -1)
print("x_train shape:", x_train.shape)
print("y_train shape:", y_train.shape)
print(x_train.shape[0], "train samples")
print(x_test.shape[0], "test samples")

x_train shape: (60000, 28, 28, 1)
y_train shape: (60000,)
60000 train samples
10000 test samples

Here's our model.

Different model-building options that Keras offers include:
    The Sequential API (what we use below)
    The Functional API (most typical)
    Writing your own models yourself via subclassing (for advanced use cases)

# Model parameters
num_classes = 10
input_shape = (28, 28, 1)

model = keras.Sequential(
    [
        keras.layers.Input(shape=input_shape),
        keras.layers.Conv2D(64, kernel_size=(3, 3), activation="relu"),
        keras.layers.Conv2D(64, kernel_size=(3, 3), activation="relu"),
        keras.layers.MaxPooling2D(pool_size=(2, 2)),
        keras.layers.Conv2D(128, kernel_size=(3, 3), activation="relu"),
        keras.layers.Conv2D(128, kernel_size=(3, 3), activation="relu"),
        keras.layers.GlobalAveragePooling2D(),
        keras.layers.Dropout(0.5),
        keras.layers.Dense(num_classes, activation="softmax"),
    ]
)

Here's our model summary:

model.summary()

Model: "sequential"
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ Layer (type)                    ┃ Output Shape            ┃       Param # ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ conv2d (Conv2D)                 │ (None, 26, 26, 64)      │           640 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ conv2d_1 (Conv2D)               │ (None, 24, 24, 64)      │        36,928 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ max_pooling2d (MaxPooling2D)    │ (None, 12, 12, 64)      │             0 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ conv2d_2 (Conv2D)               │ (None, 10, 10, 128)     │        73,856 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ conv2d_3 (Conv2D)               │ (None, 8, 8, 128)       │       147,584 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ global_average_pooling2d        │ (None, 128)             │             0 │
│ (GlobalAveragePooling2D)        │                         │               │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ dropout (Dropout)               │ (None, 128)             │             0 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ dense (Dense)                   │ (None, 10)              │         1,290 │
└─────────────────────────────────┴─────────────────────────┴───────────────┘
 Total params: 260,298 (1016.79 KB)
 Trainable params: 260,298 (1016.79 KB)
 Non-trainable params: 0 (0.00 B)

We use the compile() method to specify the optimizer, loss function, 
and the metrics to monitor. Note that with the JAX and TensorFlow backends, XLA compilation 
is turned on by default.

model.compile(
    loss=keras.losses.SparseCategoricalCrossentropy(),
    optimizer=keras.optimizers.Adam(learning_rate=1e-3),
    metrics=[
        keras.metrics.SparseCategoricalAccuracy(name="acc"),
    ],
)

Let's train and evaluate the model. 
We'll set aside a validation split of 15% of the data during training to monitor generalization 
on unseen data.

batch_size = 128
epochs = 2  # 20  original 

callbacks = [
    keras.callbacks.ModelCheckpoint(filepath="model_at_epoch_{epoch}.keras"),
    keras.callbacks.EarlyStopping(monitor="val_loss", patience=2),
]

model.fit(
    x_train,
    y_train,
    batch_size=batch_size,
    epochs=epochs,
    validation_split=0.15,
    callbacks=callbacks,
)
score = model.evaluate(x_test, y_test, verbose=0)

Epoch 1/20
 399/399 ━━━━━━━━━━━━━━━━━━━━ 74s 184ms/step - acc: 0.4980 - loss: 1.3832 - val_acc: 0.9609 - val_loss: 0.1513


During training, we were saving a model at the end of each epoch. 
You can also save the model in its latest state like this:

model.save("final_model.keras")

And reload it like this:

model = keras.saving.load_model("final_model.keras")

Next, you can query predictions of class probabilities with predict():

predictions = model.predict(x_test)

 313/313 ━━━━━━━━━━━━━━━━━━━━ 3s 9ms/step

That's it for the basics!


##Reference 
keras.callbacks.EarlyStopping(
    monitor="val_loss",
    min_delta=0,
    patience=0,
    verbose=0,
    mode="auto",
    baseline=None,
    restore_best_weights=False,
    start_from_epoch=0,
)

Stop training when a monitored metric has stopped improving.

Assuming the goal of a training is to minimize the loss. 
With this, the metric to be monitored would be 'loss', and mode would be 'min'. 
A model.fit() training loop will check at end of every epoch whether the loss is no longer decreasing, 
considering the min_delta and patience if applicable. 
Once it's found no longer decreasing, model.stop_training is marked True and the training terminates.

The quantity to be monitored needs to be available in logs dict. 
To make it so, pass the loss or metrics at model.compile().

Arguments
    monitor: Quantity to be monitored. Defaults to "val_loss".
    min_delta: Minimum change in the monitored quantity to qualify as an improvement, i.e. an absolute change of less than min_delta, will count as no improvement. Defaults to 0.
    patience: Number of epochs with no improvement after which training will be stopped. Defaults to 0.
    verbose: Verbosity mode, 0 or 1. Mode 0 is silent, and mode 1 displays messages when the callback takes an action. Defaults to 0.
    mode: One of {"auto", "min", "max"}. In min mode, training will stop when the quantity monitored has stopped decreasing; in "max" mode it will stop when the quantity monitored has stopped increasing; in "auto" mode, the direction is automatically inferred from the name of the monitored quantity. Defaults to "auto".
    baseline: Baseline value for the monitored quantity. If not None, training will stop if the model doesn't show improvement over the baseline. Defaults to None.
    restore_best_weights: Whether to restore model weights from the epoch with the best value of the monitored quantity. If False, the model weights obtained at the last step of training are used. An epoch will be restored regardless of the performance relative to the baseline. If no epoch improves on baseline, training will run for patience epochs and restore weights from the best epoch in that set. Defaults to False.
    start_from_epoch: Number of epochs to wait before starting to monitor improvement. This allows for a warm-up period in which no improvement is expected and thus training will not be stopped. Defaults to 0.

Example

>>> callback = keras.callbacks.EarlyStopping(monitor='loss',
...                                               patience=3)
>>> # This callback will stop the training when there is no improvement in
>>> # the loss for three consecutive epochs.
>>> model = keras.models.Sequential([keras.layers.Dense(10)])
>>> model.compile(keras.optimizers.SGD(), loss='mse')
>>> history = model.fit(np.arange(100).reshape(5, 20), np.zeros(5),
...                     epochs=10, batch_size=1, callbacks=[callback],
...                     verbose=0)
>>> len(history.history['loss'])  # Only 4 epochs are run.
4



keras.Sequential(layers=None, trainable=True, name=None)
Sequential groups a linear stack of layers into a Model.

Examples

model = keras.Sequential()
model.add(keras.Input(shape=(16,)))
model.add(keras.layers.Dense(8))

# Note that you can also omit the initial `Input`.
# In that case the model doesn't have any weights until the first call
# to a training/evaluation method (since it isn't yet built):
model = keras.Sequential()
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(4))
# model.weights not created yet

# Whereas if you specify an `Input`, the model gets built
# continuously as you are adding layers:
model = keras.Sequential()
model.add(keras.Input(shape=(16,)))
model.add(keras.layers.Dense(8))
len(model.weights)  # Returns "2"

# When using the delayed-build pattern (no input shape specified), you can
# choose to manually build your model by calling
# `build(batch_input_shape)`:
model = keras.Sequential()
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(4))
model.build((None, 16))
len(model.weights)  # Returns "4"

# Note that when using the delayed-build pattern (no input shape specified),
# the model gets built the first time you call `fit`, `eval`, or `predict`,
# or the first time you call the model on some input data.
model = keras.Sequential()
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(1))
model.compile(optimizer='sgd', loss='mse')
# This builds the model for the first time:
model.fit(x, y, batch_size=32, epochs=10)



Sequential.add(layer, rebuild=True)
    Adds a layer instance on top of the layer stack.
    Arguments
        layer: layer instance.

Sequential.pop(rebuild=True)
    Removes the last layer in the model.



keras.layers.Conv2D(
    filters,
    kernel_size,
    strides=(1, 1),
    padding="valid",
    data_format=None,
    dilation_rate=(1, 1),
    groups=1,
    activation=None,
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="zeros",
    kernel_regularizer=None,
    bias_regularizer=None,
    activity_regularizer=None,
    kernel_constraint=None,
    bias_constraint=None,
    **kwargs
)

2D convolution layer.
This layer creates a convolution kernel that is convolved with the layer input over 
a 2D spatial (or temporal) dimension (height and width) to produce a tensor of outputs. 
If use_bias is True, a bias vector is created and added to the outputs. 
Finally, if activation is not None, it is applied to the outputs as well.

Arguments
    filters: int, the dimension of the output space (the number of filters in the convolution).
    kernel_size: int or tuple/list of 2 integer, specifying the size of the convolution window.
    strides: int or tuple/list of 2 integer, specifying the stride length of the convolution. strides > 1 is incompatible with dilation_rate > 1.
    padding: string, either "valid" or "same" (case-insensitive). "valid" means no padding. "same" results in padding evenly to the left/right or up/down of the input. When padding="same" and strides=1, the output has the same size as the input.
    data_format: string, either "channels_last" or "channels_first". The ordering of the dimensions in the inputs. "channels_last" corresponds to inputs with shape (batch_size, height, width, channels) while "channels_first" corresponds to inputs with shape (batch_size, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    dilation_rate: int or tuple/list of 2 integers, specifying the dilation rate to use for dilated convolution.
    groups: A positive int specifying the number of groups in which the input is split along the channel axis. Each group is convolved separately with filters // groups filters. The output is the concatenation of all the groups results along the channel axis. Input channels and filters must both be divisible by groups.
    activation: Activation function. If None, no activation is applied.
    use_bias: bool, if True, bias will be added to the output.
    kernel_initializer: Initializer for the convolution kernel. If None, the default initializer ("glorot_uniform") will be used.
    bias_initializer: Initializer for the bias vector. If None, the default initializer ("zeros") will be used.
    kernel_regularizer: Optional regularizer for the convolution kernel.
    bias_regularizer: Optional regularizer for the bias vector.
    activity_regularizer: Optional regularizer function for the output.
    kernel_constraint: Optional projection function to be applied to the kernel after being updated by an Optimizer (e.g. used to implement norm constraints or value constraints for layer weights). The function must take as input the unprojected variable and must return the projected variable (which must have the same shape). Constraints are not safe to use when doing asynchronous distributed training.
    bias_constraint: Optional projection function to be applied to the bias after being updated by an Optimizer.

Input shape
    If data_format="channels_last": A 4D tensor with shape: (batch_size, height, width, channels)
    If data_format="channels_first": A 4D tensor with shape: (batch_size, channels, height, width)

Output shape
    If data_format="channels_last": A 4D tensor with shape: (batch_size, new_height, new_width, filters)
    If data_format="channels_first": A 4D tensor with shape: (batch_size, filters, new_height, new_width)

Returns
A 4D tensor representing activation(conv2d(inputs, kernel) + bias).

Raises
    ValueError: when both strides > 1 and dilation_rate > 1.

Example
>>> x = np.random.rand(4, 10, 10, 128)
>>> y = keras.layers.Conv2D(32, 3, activation='relu')(x)
>>> print(y.shape)
(4, 8, 8, 32)
MaxPooling2D layer



keras.layers.MaxPooling2D(
    pool_size=(2, 2), strides=None, padding="valid", data_format=None, name=None, **kwargs
)

Max pooling operation for 2D spatial data.
Downsamples the input along its spatial dimensions (height and width) 
by taking the maximum value over an input window (of size defined by pool_size) 
for each channel of the input. The window is shifted by strides along each dimension.

The resulting output when using the "valid" padding option has a spatial shape 
(number of rows or columns) of: 
output_shape = math.floor((input_shape - pool_size) / strides) + 1 
(when input_shape >= pool_size)

The resulting output shape when using the "same" padding option is: 
output_shape = math.floor((input_shape - 1) / strides) + 1

Arguments
    pool_size: int or tuple of 2 integers, factors by which to downscale (dim1, dim2). If only one integer is specified, the same window length will be used for all dimensions.
    strides: int or tuple of 2 integers, or None. Strides values. If None, it will default to pool_size. If only one int is specified, the same stride size will be used for all dimensions.
    padding: string, either "valid" or "same" (case-insensitive). "valid" means no padding. "same" results in padding evenly to the left/right or up/down of the input such that output has the same height/width dimension as the input.
    data_format: string, either "channels_last" or "channels_first". The ordering of the dimensions in the inputs. "channels_last" corresponds to inputs with shape (batch, height, width, channels) while "channels_first" corresponds to inputs with shape (batch, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".

Input shape
    If data_format="channels_last": 4D tensor with shape (batch_size, height, width, channels).
    If data_format="channels_first": 4D tensor with shape (batch_size, channels, height, width).

Output shape
    If data_format="channels_last": 4D tensor with shape (batch_size, pooled_height, pooled_width, channels).
    If data_format="channels_first": 4D tensor with shape (batch_size, channels, pooled_height, pooled_width).

Examples
strides=(1, 1) and padding="valid":

>>> x = np.array([[1., 2., 3.],
...               [4., 5., 6.],
...               [7., 8., 9.]])
>>> x = np.reshape(x, [1, 3, 3, 1])
>>> max_pool_2d = keras.layers.MaxPooling2D(pool_size=(2, 2),
...    strides=(1, 1), padding="valid")
>>> max_pool_2d(x)

strides=(2, 2) and padding="valid":

>>> x = np.array([[1., 2., 3., 4.],
...               [5., 6., 7., 8.],
...               [9., 10., 11., 12.]])
>>> x = np.reshape(x, [1, 3, 4, 1])
>>> max_pool_2d = keras.layers.MaxPooling2D(pool_size=(2, 2),
...    strides=(2, 2), padding="valid")
>>> max_pool_2d(x)

stride=(1, 1) and padding="same":

>>> x = np.array([[1., 2., 3.],
...               [4., 5., 6.],
...               [7., 8., 9.]])
>>> x = np.reshape(x, [1, 3, 3, 1])
>>> max_pool_2d = keras.layers.MaxPooling2D(pool_size=(2, 2),
...    strides=(1, 1), padding="same")
>>> max_pool_2d(x)
GlobalAveragePooling2D class



keras.layers.GlobalAveragePooling2D(data_format=None, keepdims=False, **kwargs)
Global average pooling operation for 2D data.

Arguments
    data_format: string, either "channels_last" or "channels_first". 
    The ordering of the dimensions in the inputs. "channels_last" corresponds to inputs with shape 
    (batch, height, width, channels) while "channels_first" corresponds to inputs 
    with shape (batch, features, height, weight). I
    t defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. 
    If you never set it, then it will be "channels_last".
    keepdims: A boolean, whether to keep the temporal dimension or not. 
    If keepdims is False (default), the rank of the tensor is reduced for spatial dimensions. 
    If keepdims is True, the spatial dimension are retained with length 1. 
    The behavior is the same as for tf.reduce_mean or np.mean.

Input shape
    If data_format='channels_last': 4D tensor with shape: (batch_size, height, width, channels)
    If data_format='channels_first': 4D tensor with shape: (batch_size, channels, height, width)

Output shape
    If keepdims=False: 2D tensor with shape (batch_size, channels).
    If keepdims=True: - If data_format="channels_last": 4D tensor with shape (batch_size, 1, 1, channels) - If data_format="channels_first": 4D tensor with shape (batch_size, channels, 1, 1)

Example

>>> x = np.random.rand(2, 4, 5, 3)
>>> y = keras.layers.GlobalAveragePooling2D()(x)
>>> y.shape
(2, 3)
Dropout layer



keras.layers.Dropout(rate, noise_shape=None, seed=None, **kwargs)
Applies dropout to the input.
The Dropout layer randomly sets input units to 0 with a frequency of rate at each step during training time, 
which helps prevent overfitting. Inputs not set to 0 are scaled up 
by 1 / (1 - rate) such that the sum over all inputs is unchanged.

Note that the Dropout layer only applies when training is set to True in call(), 
such that no values are dropped during inference. When using model.fit, training 
will be appropriately set to True automatically. 
In other contexts, you can set the argument explicitly to True when calling the layer.

(This is in contrast to setting trainable=False for a Dropout layer. 
trainable does not affect the layer's behavior, as Dropout does not have any variables/weights 
that can be frozen during training.)

Arguments
    rate: Float between 0 and 1. Fraction of the input units to drop.
    noise_shape: 1D integer tensor representing the shape of the binary dropout mask that will be multiplied with the input. For instance, if your inputs have shape (batch_size, timesteps, features) and you want the dropout mask to be the same for all timesteps, you can use noise_shape=(batch_size, 1, features).
    seed: A Python integer to use as random seed.

Call arguments
    inputs: Input tensor (of any rank).
    training: Python boolean indicating whether the layer should behave in training mode (adding dropout) or in inference mode (doing nothing).


###KerasTuner 
KerasTuner is an easy-to-use, scalable hyperparameter optimization framework that solves 
the pain points of hyperparameter search. 

pip install keras-tuner --upgrade

##Quick introduction
Import KerasTuner and TensorFlow:

import keras_tuner
import keras

Write a function that creates and returns a Keras model. 
Use the hp argument to define the hyperparameters during model creation.

def build_model(hp):
  model = keras.Sequential()
  model.add(keras.layers.Dense(
      hp.Choice('units', [8, 16, 32]),
      activation='relu'))
  model.add(keras.layers.Dense(1, activation='relu'))
  model.compile(loss='mse')
  return model

Initialize a tuner (here, RandomSearch). 
We use objective to specify the objective to select the best models, 
and we use max_trials to specify the number of different models to try.

tuner = keras_tuner.RandomSearch(
    build_model,
    objective='val_loss',
    max_trials=5)

Start the search and get the best model:

tuner.search(x_train, y_train, epochs=5, validation_data=(x_val, y_val))
best_model = tuner.get_best_models()[0]

##Detailed studies 
The first thing we need to do is writing a function, which returns a compiled Keras model. 
It takes an argument hp for defining the hyperparameters while building the model.

##Define the search space
In the following code example, we define a Keras model with two Dense layers. 
We want to tune the number of units in the first Dense layer. 
We just define an integer hyperparameter with hp.Int('units', min_value=32, max_value=512, step=32), 
whose range is from 32 to 512 inclusive. 

When sampling from it, the minimum step for walking through the interval is 32.

import keras
from keras import layers


def build_model(hp):
    model = keras.Sequential()
    model.add(layers.Flatten())
    model.add(
        layers.Dense(
            # Define the hyperparameter.
            units=hp.Int("units", min_value=32, max_value=512, step=32),
            activation="relu",
        )
    )
    model.add(layers.Dense(10, activation="softmax"))
    model.compile(
        optimizer="adam",
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model

You can quickly test if the model builds successfully.

import keras_tuner

build_model(keras_tuner.HyperParameters())

<Sequential name=sequential, built=False>

There are many other types of hyperparameters as well. 
We can define multiple hyperparameters in the function. 

In the following code, we tune whether to use a Dropout layer with hp.Boolean(), 
tune which activation function to use with hp.Choice(), 
tune the learning rate of the optimizer with hp.Float().

def build_model(hp):
    model = keras.Sequential()
    model.add(layers.Flatten())
    model.add(
        layers.Dense(
            # Tune number of units.
            units=hp.Int("units", min_value=32, max_value=512, step=32),
            # Tune the activation function to use.
            activation=hp.Choice("activation", ["relu", "tanh"]),
        )
    )
    # Tune whether to use dropout.
    if hp.Boolean("dropout"):
        model.add(layers.Dropout(rate=0.25))
    model.add(layers.Dense(10, activation="softmax"))
    # Define the optimizer learning rate as a hyperparameter.
    learning_rate = hp.Float("lr", min_value=1e-4, max_value=1e-2, sampling="log")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


build_model(keras_tuner.HyperParameters())

<Sequential name=sequential_1, built=False>

As shown below, the hyperparameters are actual values. 
In fact, they are just functions returning actual values. 
For example, hp.Int() returns an int value. 
Therefore, you can put them into variables, for loops, or if conditions.

hp = keras_tuner.HyperParameters()
print(hp.Int("units", min_value=32, max_value=512, step=32))
32

You can also define the hyperparameters in advance and keep your Keras code in a separate function.

def call_existing_code(units, activation, dropout, lr):
    model = keras.Sequential()
    model.add(layers.Flatten())
    model.add(layers.Dense(units=units, activation=activation))
    if dropout:
        model.add(layers.Dropout(rate=0.25))
    model.add(layers.Dense(10, activation="softmax"))
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=lr),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def build_model(hp):
    units = hp.Int("units", min_value=32, max_value=512, step=32)
    activation = hp.Choice("activation", ["relu", "tanh"])
    dropout = hp.Boolean("dropout")
    lr = hp.Float("lr", min_value=1e-4, max_value=1e-2, sampling="log")
    # call existing model-building code with the hyperparameter values.
    model = call_existing_code(
        units=units, activation=activation, dropout=dropout, lr=lr
    )
    return model


build_model(keras_tuner.HyperParameters())

<Sequential name=sequential_2, built=False>


##Start the search
After defining the search space, we need to select a tuner class to run the search. 
You may choose from RandomSearch, BayesianOptimization and Hyperband, 
which correspond to different tuning algorithms. 

Here we use RandomSearch as an example.

To initialize the tuner, we need to specify several arguments in the initializer.
    hypermodel. The model-building function, which is build_model in our case.
    objective. The name of the objective to optimize (whether to minimize or maximize 
    is automatically inferred for built-in metrics). 
    We will introduce how to use custom metrics later in this tutorial.
    max_trials. The total number of trials to run during the search.
    executions_per_trial. The number of models that should be built and fit for each trial. Different trials have different hyperparameter values. The executions within the same trial have the same hyperparameter values. The purpose of having multiple executions per trial is to reduce results variance and therefore be able to more accurately assess the performance of a model. If you want to get results faster, you could set executions_per_trial=1 (single round of training for each model configuration).
    overwrite. Control whether to overwrite the previous results in the same directory or resume the previous search instead. Here we set overwrite=True to start a new search and ignore any previous results.
    directory. A path to a directory for storing the search results.
    project_name. The name of the sub-directory in the directory.

tuner = keras_tuner.RandomSearch(
    hypermodel=build_model,
    objective="val_accuracy",
    max_trials=3,
    executions_per_trial=2,
    overwrite=True,
    directory="my_dir",
    project_name="helloworld",
)

You can print a summary of the search space:

tuner.search_space_summary()

Search space summary
Default search space size: 5
num_layers (Int)
{'default': None, 'conditions': [], 'min_value': 1, 'max_value': 3, 'step': 1, 'sampling': 'linear'}
units_0 (Int)
{'default': None, 'conditions': [], 'min_value': 32, 'max_value': 512, 'step': 32, 'sampling': 'linear'}
activation (Choice)
{'default': 'relu', 'conditions': [], 'values': ['relu', 'tanh'], 'ordered': False}
dropout (Boolean)
{'default': False, 'conditions': []}
lr (Float)
{'default': 0.0001, 'conditions': [], 'min_value': 0.0001, 'max_value': 0.01, 'step': None, 'sampling': 'log'}

Before starting the search, let's prepare the MNIST dataset.

import keras
import numpy as np

(x, y), (x_test, y_test) = keras.datasets.mnist.load_data()

x_train = x[:-10000]
x_val = x[-10000:]
y_train = y[:-10000]
y_val = y[-10000:]

x_train = np.expand_dims(x_train, -1).astype("float32") / 255.0
x_val = np.expand_dims(x_val, -1).astype("float32") / 255.0
x_test = np.expand_dims(x_test, -1).astype("float32") / 255.0

num_classes = 10
y_train = keras.utils.to_categorical(y_train, num_classes)
y_val = keras.utils.to_categorical(y_val, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

Then, start the search for the best hyperparameter configuration. 
All the arguments passed to search is passed to model.fit() in each execution. 
Remember to pass validation_data to evaluate the model.

tuner.search(x_train, y_train, epochs=2, validation_data=(x_val, y_val))

Trial 3 Complete [00h 00m 19s]
val_accuracy: 0.9665500223636627

Best val_accuracy So Far: 0.9665500223636627
Total elapsed time: 00h 00m 40s

During the search, the model-building function is called with different hyperparameter 
values in different trial. In each trial, the tuner would generate a new set of hyperparameter values 
to build the model. The model is then fit and evaluated. The metrics are recorded. 
The tuner progressively explores the space and finally finds a good set of hyperparameter values.

##Query the results
When search is over, you can retrieve the best model(s). 
The model is saved at its best performing epoch evaluated on the validation_data.

# Get the top 2 models.
models = tuner.get_best_models(num_models=2)
best_model = models[0]
best_model.summary()

/usr/local/python/3.10.13/lib/python3.10/site-packages/keras/src/saving/saving_lib.py:388: UserWarning: Skipping variable loading for optimizer 'adam', because it has 2 variables whereas the saved optimizer has 18 variables. 
  trackable.load_own_variables(weights_store.get(inner_path))
/usr/local/python/3.10.13/lib/python3.10/site-packages/keras/src/saving/saving_lib.py:388: UserWarning: Skipping variable loading for optimizer 'adam', because it has 2 variables whereas the saved optimizer has 10 variables. 
  trackable.load_own_variables(weights_store.get(inner_path))

Model: "sequential"

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━┓
┃ Layer (type)                    ┃ Output Shape              ┃    Param # ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━┩
│ flatten (Flatten)               │ (32, 784)                 │          0 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense (Dense)                   │ (32, 416)                 │    326,560 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense_1 (Dense)                 │ (32, 512)                 │    213,504 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense_2 (Dense)                 │ (32, 32)                  │     16,416 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dropout (Dropout)               │ (32, 32)                  │          0 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense_3 (Dense)                 │ (32, 10)                  │        330 │
└─────────────────────────────────┴───────────────────────────┴────────────┘

 Total params: 556,810 (2.12 MB)

 Trainable params: 556,810 (2.12 MB)

 Non-trainable params: 0 (0.00 B)

You can also print a summary of the search results.

tuner.results_summary()

Results summary
Results in my_dir/helloworld
Showing 10 best trials
Objective(name="val_accuracy", direction="max")

Trial 2 summary
Hyperparameters:
num_layers: 3
units_0: 416
activation: relu
dropout: True
lr: 0.0001324166048504802
units_1: 512
units_2: 32
Score: 0.9665500223636627

Trial 0 summary
Hyperparameters:
num_layers: 1
units_0: 128
activation: tanh
dropout: False
lr: 0.001425162921397599
Score: 0.9623999893665314

Trial 1 summary
Hyperparameters:
num_layers: 2
units_0: 512
activation: tanh
dropout: True
lr: 0.0010584293918512798
units_1: 32
Score: 0.9606499969959259

You will find detailed logs, checkpoints, etc, in the folder my_dir/helloworld, i
.e. directory/project_name.



##Retrain the model
If you want to train the model with the entire dataset, 
you may retrieve the best hyperparameters and retrain the model by yourself.

# Get the top 2 hyperparameters.
best_hps = tuner.get_best_hyperparameters(5)
# Build the model with the best hp.
model = build_model(best_hps[0])
# Fit with the entire dataset.
x_all = np.concatenate((x_train, x_val))
y_all = np.concatenate((y_train, y_val))
model.fit(x=x_all, y=y_all, epochs=1)

1/1875 [37m━━━━━━━━━━━━━━━━━━━━  17:57 575ms/step - accuracy: 0.1250 - loss: 2.3113

<keras.src.callbacks.history.History at 0x7f31883d9e10>


##AutoKeras - Image Classification

!pip install autokeras

import numpy as np
import tensorflow as tf
from keras.datasets import mnist
import autokeras as ak


(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train = x_train[:100]
y_train = y_train[:100]
x_test = x_test[:100]
y_test = y_test[:100]
print(x_train.shape)  # (60000, 28, 28)
print(y_train.shape)  # (60000,)
print(y_train[:3])  # array([7, 2, 1], dtype=uint8)


The second step is to run the ImageClassifier. 
It is recommended have more trials for more complicated datasets. 
This is just a quick demo of MNIST, so we set max_trials to 1. For the same reason, 
we set epochs to 10. You can also leave the epochs unspecified for an adaptive number of epochs.

# Initialize the image classifier.
clf = ak.ImageClassifier(overwrite=True, max_trials=1)
# Feed the image classifier with training data.
clf.fit(x_train, y_train, epochs=1)
# Predict with the best model.
predicted_y = clf.predict(x_test)
print(predicted_y)
# Evaluate the best model with testing data.
print(clf.evaluate(x_test, y_test))


Validation Data
By default, AutoKeras use the last 20% of training data as validation data. 
As shown in the example below, you can use validation_split to specify the percentage.

clf.fit(
    x_train,
    y_train,
    # Split the training data and use the last 15% as validation data.
    validation_split=0.15,
    epochs=1,
)

You can also use your own validation set instead of splitting it from the training data 
with validation_data.

split = 50000
x_val = x_train[split:]
y_val = y_train[split:]
x_train = x_train[:split]
y_train = y_train[:split]
clf.fit(
    x_train,
    y_train,
    # Use your own validation set.
    validation_data=(x_val, y_val),
    epochs=1,
)


##AutoKeras - Text Classification

!pip install autokeras
import os
import keras
import numpy as np
import tensorflow as tf
from sklearn.datasets import load_files
import autokeras as ak



dataset = keras.utils.get_file(
    fname="aclImdb.tar.gz",
    origin="http://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz",
    extract=True,
)
# set path to dataset
IMDB_DATADIR = os.path.join(os.path.dirname(dataset), "aclImdb")
classes = ["pos", "neg"]
train_data = load_files(
    os.path.join(IMDB_DATADIR, "train"), shuffle=True, categories=classes
)
test_data = load_files(
    os.path.join(IMDB_DATADIR, "test"), shuffle=False, categories=classes
)
x_train = np.array(train_data.data)[:100]
y_train = np.array(train_data.target)[:100]
x_test = np.array(test_data.data)[:100]
y_test = np.array(test_data.target)[:100]
print(x_train.shape)  # (25000,)
print(y_train.shape)  # (25000, 1)
print(x_train[0][:50])  # this film was just brilliant casting


The second step is to run the TextClassifier. 
As a quick demo, we set epochs to 2. You can also leave the epochs unspecified 
for an adaptive number of epochs.


# Initialize the text classifier.
clf = ak.TextClassifier(
    overwrite=True, max_trials=1
)  # It only tries 1 model as a quick demo.
# Feed the text classifier with training data.
clf.fit(x_train, y_train, epochs=1, batch_size=2)
# Predict with the best model.
predicted_y = clf.predict(x_test)
# Evaluate the best model with testing data.
print(clf.evaluate(x_test, y_test))


Validation Data
By default, AutoKeras use the last 20% of training data as validation data. 
As shown in the example below, you can use validation_split to specify the percentage.

clf.fit(
    x_train,
    y_train,
    # Split the training data and use the last 15% as validation data.
    validation_split=0.15,
    epochs=1,
    batch_size=2,
)

You can also use your own validation set instead of splitting 
it from the training data with validation_data.

split = 5
x_val = x_train[split:]
y_val = y_train[split:]
x_train = x_train[:split]
y_train = y_train[:split]
clf.fit(
    x_train,
    y_train,
    epochs=1,
    # Use your own validation set.
    validation_data=(x_val, y_val),
    batch_size=2,
)

###Scikit-Learn API wrappers
keras.wrappers.SKLearnClassifier(
    model, warm_start=False, model_kwargs=None, fit_kwargs=None
)

scikit-learn compatible classifier wrapper for Keras models.

Note that there are sources of randomness in model initialization and training. 
Refer to Reproducibility in Keras Models on how to control randomness.

Arguments
    model: Model. An instance of Model, or a callable returning such an object. 
    Note that if input is a Model, it will be cloned using keras.models.clone_model before being fitted, 
    unless warm_start=True. The Model instance needs to be passed as already compiled. 
    If callable, it must accept at least X and y as keyword arguments. 
    Other arguments must be accepted if passed as model_kwargs by the user.
    
    warm_start: bool, defaults to False. Whether to reuse the model weights from the previous fit. 
    If True, the given model won't be cloned and the weights from the previous fit will be reused.
    
    model_kwargs: dict, defaults to None. Keyword arguments passed to model, if model is callable.
    
    fit_kwargs: dict, defaults to None. Keyword arguments passed to model.fit. 
    These can also be passed directly to the fit method of the scikit-learn wrapper. 
    The values passed directly to the fit method take precedence over these.

Attributes
    model_ : Model The fitted model.
    history_ : dict The history of the fit, returned by model.fit.
    classes_ : array-like, shape=(n_classes,) The classes labels.

Example
Here we use a function which creates a basic MLP model dynamically choosing the input and output shapes. 
We will use this to create our scikit-learn model.

from keras.src.layers import Dense, Input, Model

def dynamic_model(X, y, loss, layers=[10]):
    # Creates a basic MLP model dynamically choosing the input and
    # output shapes.
    n_features_in = X.shape[1]
    inp = Input(shape=(n_features_in,))

    hidden = inp
    for layer_size in layers:
        hidden = Dense(layer_size, activation="relu")(hidden)

    n_outputs = y.shape[1] if len(y.shape) > 1 else 1
    out = [Dense(n_outputs, activation="softmax")(hidden)]
    model = Model(inp, out)
    model.compile(loss=loss, optimizer="rmsprop")

    return model

You can then use this function to create a scikit-learn compatible model and fit it on some data.

from sklearn.datasets import make_classification
from keras.wrappers import SKLearnClassifier

X, y = make_classification(n_samples=1000, n_features=10, n_classes=3)
est = SKLearnClassifier(
    model=dynamic_model,
    model_kwargs={
        "loss": "categorical_crossentropy",
        "layers": [20, 20, 20],
    },
)

est.fit(X, y, epochs=5)



keras.wrappers.SKLearnRegressor(
    model, warm_start=False, model_kwargs=None, fit_kwargs=None
)
scikit-learn compatible regressor wrapper for Keras models.
Attributes
    model_ : Model The fitted model.

Example

Here we use a function which creates a basic MLP model dynamically choosing the input and output shapes. 
We will use this to create our scikit-learn model.

from keras.src.layers import Dense, Input, Model

def dynamic_model(X, y, loss, layers=[10]):
    # Creates a basic MLP model dynamically choosing the input and
    # output shapes.
    n_features_in = X.shape[1]
    inp = Input(shape=(n_features_in,))

    hidden = inp
    for layer_size in layers:
        hidden = Dense(layer_size, activation="relu")(hidden)

    n_outputs = y.shape[1] if len(y.shape) > 1 else 1
    out = [Dense(n_outputs, activation="softmax")(hidden)]
    model = Model(inp, out)
    model.compile(loss=loss, optimizer="rmsprop")

    return model

You can then use this function to create a scikit-learn compatible model and fit it on some data.

from sklearn.datasets import make_regression
from keras.wrappers import SKLearnRegressor

X, y = make_regression(n_samples=1000, n_features=10)
est = SKLearnRegressor(
    model=dynamic_model,
    model_kwargs={
        "loss": "mse",
        "layers": [20, 20, 20],
    },
)

est.fit(X, y, epochs=5)

[source]
SKLearnTransformer class


###Scikit-API  - Iris-csv with Early stoping and inpu scaling 
#with tensorflow 
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Input 
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier
import tensorflow.keras.utils 
from tensorflow.keras.callbacks import * 
#original
from keras.models import Sequential, load_model
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
import keras.utils 
from keras.callbacks import * 


dataframe   = pd.read_csv("data/iris.csv")
dataset     = dataframe.values

X = dataset[:,0:4].astype(float)
Y = dataset[:,4]

encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)

# to_categorical converts the numbered labels into a one-hot vector
#Classifier must use x or y as one hot encoded 
dummy_y = keras.utils.to_categorical(encoded_Y)
#so creates 3 output variable 

#StratifiedKFold does not work with multioutput 
kfold = KFold(n_splits=10, shuffle=True)

# define baseline model
def baseline_model():
    # create model
    model = Sequential()
    #input_dim= n , for n features or (x,y) for 2D feature 
    model.add(Input(shape=(4,))
    model.add(Dense(8, activation='relu'))
    #for binary , final layer with one output, activation='sigmoid' and loss='binary_crossentropy'.
    #but we have three classe classifier, so output=3 
    model.add(Dense(3, activation='softmax'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
    

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5, verbose=0)


results = cross_val_score(estimator, X, dummy_y, cv=kfold)
print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))
#Baseline: 97.33% (4.42%)


#Check 
X_train, X_test, y_train, y_test, enc_y_train, enc_y_test = train_test_split(X, dummy_y, encoded_Y, random_state=0)

#fit
estimator.fit( X_train, y_train)

#score 
print(" train, test accuracy", estimator.score( X_train, y_train), estimator.score( X_test, y_test))
#0.9732142873108387
#0.9736842120948591

#predict 
predictions = estimator.predict( X_test)
print("predict as per numerical class\n", predictions)
#array([2, 2, 0, 2, 0, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 0, 0, 2, 2,  0, 0, 2, 0, 0, 2, 1, 0, 2, 2, 0, 2, 2, 2, 0, 2])
#With LabelEncoded Y 
print("confusion metrics\n", confusion_matrix(enc_y_test, predictions))
# array([[13,  0,  0],
       # [ 0, 14,  2],
       # [ 0,  0,  9]], dtype=int64)
       
             


print("""  --------------- GridSearch -----------------
accuracy is very sensitive of below Hyperparameters 
batch_size = sample size preferably to be multiple of batch size
epochs 
Dense - output no , 
        activation
""")


params = dict(
    epochs = [ 100, 200, 300],
    batch_size = [5,15,30],
    dense1_out = [8,16,32],
    dense1_activation = [ 'relu', 'tanh']
)

def search_model(dense1_out=8, dense1_activation='relu' ):
    # create model
    model = Sequential()
    model.add(Input(shape=(4,))
    model.add(Dense(dense1_out, activation=dense1_activation))
    model.add(Dense(3, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

clf = KerasClassifier(build_fn=search_model, verbose=0)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(clf, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
print("Time taken: ", time.time()-st, " secs")  #175.9128041267395

print("Best param: ", search.best_params_ ) #{'epochs': 200, 'dense1_activation': 'tanh', 'batch_size': 30, 'dense1_out': 16}
print(" train, test accuracy", search.score( X_train, y_train), #0.9821428624647004
search.score( X_test, y_test)) #0.9736842105263158



print("""
Reducton of overfitting 
1.Setup Early Stopping
    Use EarlyStopping(monitor='val_loss', patience=2) 
        to define that we wanted to monitor the test (validation) loss at each epoch 
        and after the test loss has not improved after two epochs, training is interrupted. 
        However, since we set patience=2, we won't get the best model, 
        but the model two epochs after the best model. 
        Therefore, optionally, we can include a second operation, 
        ModelCheckpoint which saves the model to a file after every checkpoint 
        (which can be useful in case a multi-day training session is interrupted for some reason. 
        Helpful for us, if we set save_best_only=True then ModelCheckpoint will only save 
        the best model.
    And 
    Use validation_split=0.3 or validation_data=(val_x, val_y)
2.Use MinMaxscalar to scale the data also to reduce overfitting 
(dont use StandardScalar as data might not be normal)

""")
callbacks = [EarlyStopping(monitor='val_loss', patience=2),
             ModelCheckpoint(filepath='best_model.h5', monitor='val_loss', save_best_only=True)]
             
scaler = MinMaxScaler(feature_range=(-1,1))
X = scaler.fit(X).transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, dummy_y,  random_state=0)

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5,                       
                      verbose=1, # Print description after each epoch(0)+some addl  
                      callbacks=callbacks, # Early stopping
                      validation_data=(X_test, y_test) # Data for evaluation                      
                      )
estimator.fit( X_train, y_train)
    
#Load the best model from best_model.h5 which is compiled as well 
model = load_model('best_model.h5')
estimator1 = KerasClassifier(build_fn=lambda : model)
results = cross_val_score(estimator1, X, dummy_y, cv=kfold, scoring='roc_auc')
print("AUC with reduce overfitting: %3.2f (%3.2f)" % (results.mean(), results.std()))

    
    
###Example - Keras - Example -Boston housing price regression 
'''
Target : The last column MEDV is a median value of owner-occupied homes in $1000
Features:
CRIM per capita crime rate by town
ZN proportion of residential land zoned for lots over 25,000 sq.ft.
INDUS proportion of non-retail business acres per town
CHAS Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
NOX nitric oxides concentration (parts per 10 million)
RM average number of rooms per dwelling
AGE proportion of owner-occupied units built prior to 1940
DIS weighted distances to five Boston employment centres
RAD index of accessibility to radial highways
TAX full-value property-tax rate per $10,000
PTRATIO pupil-teacher ratio by town
B 1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
LSTAT % lower status of the population
'''

# Read dataset into X and Y
df = pd.read_csv('tobeShared/data/boston.csv')
dataset = df.values

X = dataset[:, 0:13]
Y = dataset[:, 13]

#print "X: ", X
#print "Y: ", Y


# Define the neural network
from keras.models import Sequential
from keras.layers import Dense, Input

#13 feature/input, one output

#Note Activation 
#Regression: linear (because values are unbounded)
#Classification: softmax (simple sigmoid works too but softmax works better)
#for binary, sigmoid is also ok , but the output is not a probability distribution (does not need to sum to 1).

#Sigmoid and tanh should not be used as activation function for the hidden layer. 
#This is because of the vanishing gradient problem, i.e., if your input is on a higher side (where sigmoid goes flat) then the gradient will be near zero. 
#The best function for hidden layers is thus ReLu.

def build_nn(dense1_out=20, dense1_activation='relu', dense1_init="normal"):
    model = Sequential()
    model.add(Input(shape(13,))
    model.add(Dense(dense1_out,  kernel_initializer=dense1_init, activation=dense1_activation))
    # No activation needed in output layer (because regression)
    model.add(Dense(1, kernel_initializer=dense1_init))
    model.add(Activation("linear")) #by default, so no need to add 
    # Compile Model
    model.compile(loss='mean_squared_error', optimizer='adam', metrics=['mse'])
    return model


# Evaluate model (kFold cross validation)
from keras.wrappers.scikit_learn import KerasRegressor

#batch_size < n_samples 
#note Network parameters get updated (forward and backword ie one pass)
#only n_samples/batch_size (if not divisible, then last batch is only delta)
#hence per pass, requires less memory and multiple updates are done for whole data set 

#if batch_size == n_samples, only 1 update, but high memory is required 

# Before feeding the i/p into neural-network, standardise the dataset because all input variables vary in their scales
estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, epochs=100, batch_size=5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=5, shuffle=True)
results = cross_val_score(pipeline, X, Y, cv=kfold)

#MSE 
print("Mean: ", results.mean()) #-16.17353722710814
print("StdDev: ", results.std()) #StdDev:  6.191083824421029

#initializers are used to thwart local minimum 
params = dict(
    mlp__epochs = [ 500, 1000],
    mlp__dense1_out = [20,48, 64],
    mlp__dense1_activation = ['relu'],
    mlp__dense1_init = ['glorot_normal', 'normal']
)

X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)

estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, batch_size = 5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(pipeline, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
time.time()-st  #705.3032658100128 sec

search.best_params_  #{'mlp__dense1_init': 'glorot_normal', 'mlp__batch_size': 5, 'mlp__epochs': 300,'mlp__dense1_activation': 'relu', 'mlp__dense1_out': 48}
search.score( X_train, y_train)  #3.2275988869270735
search.score( X_test, y_test) #15.513392695409106

predictions = search.predict( X_test)
r2_score(y_test, predictions) #0.8101153048345232


















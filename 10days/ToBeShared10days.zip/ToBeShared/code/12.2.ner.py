
print("NER: Using NLTK")

import nltk
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag

#Information Extraction
ex = 'European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices'

print("Information Extraction from following sentence\n", ex)

print("""
\n\nNow apply word tokenization and part-of-speech tagging to the sentence

Returns list of tuples containing the individual words in the sentence 
and their associated part-of-speech.
#Example 
CC, a coordinating conjunction; 
RB, or adverbs; 
IN, a preposition; 
NN, a noun; 
JJ, an adjective.
VBP present tense verb 
DT  determiner
PRP pronoun, personal
TO  "to" as preposition or infinitive marker


#Check help 
import nltk
nltk.help.upenn_tagset('RB')
nltk.help.upenn_tagset('NN.*')
#for all 
nltk.help.upenn_tagset()

OUTPUT:
""")

def preprocess(sent):
    sent = nltk.word_tokenize(sent)
    sent = nltk.pos_tag(sent)
    return sent

sent = preprocess(ex)
print(sent)




print("""
Chunking

Text chunking, also referred to as shallow parsing, is a task 
that follows Part-Of-Speech Tagging and that adds more structure to the sentence. 
The result is a grouping of the words in 'chunks'

Deep-parsing creates the full parse tree, 
shallow parsing adds a single extra level to the tree

Chinking is a lot like chunking, 
it is basically a way  to remove a chunk from a chunk. 
The chunk that you remove from your chunk is your chink.

#Rule syntax 
{regexp}         # chunk rule
}regexp{         # chink rule
regexp}{regexp   # split rule
regexp{}regexp   # merge rule
Where regexp is a regular expression for the rule. 
Any text following the comment marker (#) will be used as the rule's description:

The differences between regular expression patterns and tag patterns are:
1.In tag patterns, '<' and '>' act as parentheses; 
  so '<NN>+' matches one or more repetitions of '<NN>', 
  not '<NN' followed by one or more repetitions of '>'.
2.Whitespace in tag patterns is ignored. 
  So '<DT> | <NN>' is equivalant to '<DT>|<NN>'
3.In tag patterns, '.' is equivalant to '[^{}<>]'; 
so '<NN.*>' matches any single tag starting with 'NN'.

Our Task 
Implement noun phrase chunking to identify named entities using 
a regular expression consisting of rules that indicate 
how sentences should be chunked.

Our chunk pattern(like regex) consists of one rule, that a noun phrase, NP, 
should be formed whenever the chunker finds an optional determiner, DT, 
followed by any number of adjectives, JJ, and then a noun, NN.

pattern = 'NP: {<DT>?<JJ>*<NN>}'
""")

pattern = 'NP: {<DT>?<JJ>*<NN>}'

cp = nltk.RegexpParser(pattern)
cs = cp.parse(sent)
print(cs)

print("""
The output can be read as a tree or a hierarchy with S as the first level, 
denoting sentence. we can also display it graphically.
""")

NPChunker = nltk.RegexpParser(pattern) 
result = NPChunker.parse(sent)
result.draw()

print("""
IOB tags have become the standard way to represent chunk structures in files,

In this representation, there is one token per line, 
each with its part-of-speech tag and its named entity tag. 

Tag	ID	Description
------------------------
"I"	1	Token is inside an entity.
"O"	2	Token is outside an entity.
"B"	3	Token begins an entity.
""	0	No entity tag is set (missing value).
""")

from nltk.chunk import conlltags2tree, tree2conlltags
from pprint import pprint

iob_tagged = tree2conlltags(cs)
pprint(iob_tagged)


print("""
Alternatively:
With the function nltk.ne_chunk(), NLTK recognize named entities 
using a classifier, the classifier adds category labels such 
as PERSON, ORGANIZATION, and GPE.

#Google is recognized as a person. It's quite disappointing
""")

ne_tree = nltk.ne_chunk(pos_tag(word_tokenize(ex)))
print(ne_tree)

print("""
-------------------NER: Using SpaCy-------------------------

SpaCy's named entity recognition has been trained on the OntoNotes 5 corpus 
and it supports the following entity types:

Type	Description
--------------------
PERSON      People, including fictional.
NORP	    Nationalities or religious or political groups.
FAC	    Buildings, airports, highways, bridges, etc.
ORG	    Companies, agencies, institutions, etc.
GPE	    Countries, cities, states.
LOC	    Non-GPE locations, mountain ranges, bodies of water.
PRODUCT	    Objects, vehicles, foods, etc. (Not services.)
EVENT	    Named hurricanes, battles, wars, sports events, etc.
WORK_OF_ART	Titles of books, songs, etc.
LAW	    Named documents made into laws.
LANGUAGE    Any named language.
DATE	    Absolute or relative dates or periods.
TIME	    Times smaller than a day.
PERCENT	    Percentage, including '%'.
MONEY	    Monetary values, including unit.
QUANTITY    Measurements, as of weight or distance.
ORDINAL	    'first', 'second', etc.
CARDINAL    Numerals that do not fall under another type.

OUTPUT:
""")

import spacy
from spacy import displacy
from collections import Counter
import en_core_web_sm
nlp = en_core_web_sm.load()

#'European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices')
doc = nlp(ex)
#NER is in ents 
print("Information Extraction from following sentence\n", ex)
pprint([(X.text, X.label_) for X in doc.ents])

print("""
During the above example, we were working on entity level, 
in the following example, we are demonstrating token-level entity annotation 
using the BILUO tagging scheme to describe the entity boundaries

Tag	Description
------------------
B EGIN	The first token of a multi-token entity.
I N	    An inner token of a multi-token entity.
L AST	The final token of a multi-token entity.
U NIT	A single-token entity.
O UT	A non-entity token.

OUTPUT: 
""")
pprint([(X, X.ent_iob_, X.ent_type_) for X in doc])


print("""
Extracting named entity from an from a New York Times article
------------------------------------------------------------------
""")

from bs4 import BeautifulSoup
import requests
import re

def url_to_string(url):
    res = requests.get(url)
    html = res.text
    soup = BeautifulSoup(html, 'html5lib')
    for script in soup(["script", "style", 'aside']):
        script.extract() #removes a tag or string from the tree. It returns the tag or string that was extracted:
    return " ".join(re.split(r'[\n\t]+', soup.get_text()))

ny_bb = url_to_string('https://www.nytimes.com/2018/08/13/us/politics/peter-strzok-fired-fbi.html?hp&action=click&pgtype=Homepage&clickSource=story-heading&module=first-column-region&region=top-news&WT.nav=top-news')
article = nlp(ny_bb)
print("Length of Entities extracted", len(article.ents))
print("unique labels:")
labels = [x.label_ for x in article.ents]
print(Counter(labels))

print("three most frequent tokens:")
items = [x.text for x in article.ents]
print(Counter(items).most_common(3))

print("\nRandomly select one sentence to learn more:")
sentences = [x for x in article.sents]
def ify(s):
    return str(s).encode("ascii", "ignore").decode()
    
text = ify(sentences[20])
print(text)

print("\n\nGenerate the raw markup of this string, check http://localhost:5000/")
#displacy.render(nlp(str(sentences[20])), jupyter=True, style='ent')
displacy.serve(nlp(text), style='ent')

print("DRAW its dependencies, check http://localhost:5000/")
#displacy.render(nlp(str(sentences[20])), style='dep', jupyter = True, options = {'distance': 120})
displacy.serve(nlp(text), style='dep', options = {'distance': 120})

print("\n\nextract part-of-speech and lemmatize this sentence:")

res = [(x.orth_,x.pos_, x.lemma_) for x in [y 
                                      for y
                                      in nlp(text) 
                                      if not y.is_stop and y.pos_ != 'PUNCT']]

print(res)
print("\n\nOR:")
res = dict([(str(x), x.label_) for x in nlp(text).ents])

print(res)



print("\n\nOR in BILUO format :")
print([(ify(x), ify(x.ent_iob_), ify(x.ent_type_)) for x in sentences[20]])


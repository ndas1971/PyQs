import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
from sklearn_pandas import DataFrameMapper, gen_features #don't bring other methods 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline


print("--------------LogisticRegression on mushroom data(edible/poisonous) ---------------")

dataset = pd.read_csv('data/mushroom.csv')
names = [
    'class',
    'cap-shape',
    'cap-surface',
    'cap-color'
]
dataset.columns = names
print(dataset.head())

#pause 
input()


features = ['cap-shape', 'cap-surface', 'cap-color']
target   = ['class']

X = dataset[features]
y = dataset[target]

'''
precision = true positives / (true positives + false positives)
recall = true positives / (false negatives + true positives)
F1 score = 2 * ((precision * recall) / (precision + recall))
'''






def model_selection(X, y, estimator, return_model=False):
    #transformer for each column 
    feature_def = gen_features(
        columns=features,
        classes=[LabelEncoder]  #scikit_pandas can not handle OneHotEncoder after LabelEncoder as LabelEncoder expects 1D, oneHotEncoder expects 2D 
    )                           #Can use LabelBinarizer which is same as LabelEncoder, then OneHotEncoder
    X_mapper = DataFrameMapper(feature_def)
    y = LabelEncoder().fit_transform(y.values.ravel())
    #Note features categorical, so, convert them to OneHotEncoding 
    model = Pipeline([
        ('mapper', X_mapper),
        ('hotencoder', OneHotEncoder()), #OneHotEncoder requires numerical categorical 
        ('estimator', estimator)
    ])
    #
    model.fit(X, y)
    expected  = y
    predicted = model.predict(X)
    # Compute and return the F1 score (the harmonic mean of precision and recall)
    if not return_model:
        return (f1_score(expected, predicted))
    else:
        return (model, y)

# Try them all!
from sklearn.linear_model import LogisticRegressionCV, LogisticRegression, SGDClassifier

print("f1 score from LogisticRegressionCV: ",  model_selection(X, y, LogisticRegressionCV()) )
print("f1 score from LogisticRegression: ",  model_selection(X, y, LogisticRegression()) )

#pause 
input()

print("------------------ confusion matrix ------------")
from yellowbrick.classifier import ConfusionMatrix

def visual_model_selection(X, y, estimator):
    model, y_ = model_selection(X, y, estimator, return_model=True)
    # Create a new figure to draw the classification report on
    _, ax = plt.subplots()
    # Instantiate the classification model and visualizer
    visualizer = ConfusionMatrix( model, ax=ax, classes=['edible', 'poisonous'] )
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.poof()
    
    
visual_model_selection(X, y, LogisticRegressionCV())

#pause 
input()

from yellowbrick.classifier import ClassificationReport

print('''
precision
    what % of predicted positive are actually positves?
Recall, Sensitivity 
    what % of actual positives are predicted positives?
f1 score
    The F1 score is a weighted harmonic mean of precision and recall 
    such that the best score is 1.0 and the worst is 0.0. 
support
    Support is the number of actual occurrences of the class in the specified dataset. 
    Imbalanced support in the training data may indicate structural weaknesses 
    in the reported scores of the classifier 
    and could indicate the need for stratified sampling or rebalancing. 
    Support doesn't change between models but instead diagnoses the evaluation process.
    
F1 score methods 
"macro" 
    simply calculates the mean of the binary metrics, giving equal weight to each class. 
"micro" 
    gives each sample-class pair an equal contribution to the overall metric 
    Rather than summing the metric per class, 
    this sums the dividends and divisors that make up the per-class metrics 
    to calculate an overall quotient. 
    Micro-averaging may be preferred in multilabel settings, 
    including multiclass classification   
''')

def visual_model_selection(X, y, estimator):
    model,y_ = model_selection(X, y, estimator, return_model=True)
    # Create a new figure to draw the classification report on
    _, ax = plt.subplots()
    # Instantiate the classification model and visualizer
    visualizer = ClassificationReport( model, ax=ax, classes=['edible', 'poisonous'] )
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.poof()

    
#visual_model_selection(X, y, LinearSVC())
#visual_model_selection(X, y, NuSVC())
#visual_model_selection(X, y, SVC())
#visual_model_selection(X, y, SGDClassifier())
#visual_model_selection(X, y, KNeighborsClassifier())
print("-------------------- ClassificationReport ---------------")
visual_model_selection(X, y, LogisticRegressionCV())
#visual_model_selection(X, y, LogisticRegression())

#visual_model_selection(X, y, BaggingClassifier())
#visual_model_selection(X, y, ExtraTreesClassifier())
#visual_model_selection(X, y, RandomForestClassifier())
#pause 
input()
    
print(""" 
ROCAUC
A ROCAUC (Receiver Operating Characteristic/Area Under the Curve) plot allows the user 
to visualize the tradeoff between the classifier's sensitivity and specificity.
true curve would be full square in graph such that area under the curve is 1 
""")

#ROC curves are typically used in binary classification
from yellowbrick.classifier import ROCAUC

logistic, y_ = model_selection(X, y, LogisticRegression(), True)
visualizer = ROCAUC(logistic, classes=['edible', 'poisonous'])

visualizer.fit(X, y)  # Fit the training data to the visualizer
visualizer.score(X, y)  # Evaluate the model on the test data
g = visualizer.poof()   # Draw/show/poof the data, mention path to store in that 

##Example DB 
from sqlalchemy import * 
from flask import jsonify, g
DATABASE = "people.db"
def get_db():
    db = getattr(g, '_database', None)  #do import g, g is global object in FLASK
    if db is None:
        db = g._database = create_engine("sqlite:///"+DATABASE)
    return db     
    
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        pass #db.close()
        
        
def getage(name):
    eg = get_db()
    q = eg.execute("select age from people where name = ?" ,name)
    return q.fetchone()[0]

@app.route("/json", methods=['POST'])   # http://localhost:5000/json with jsondata
def js():
    user = dict(username='nobody', age="nonefound")
    if 'Content-Type' in request.headers and request.headers['Content-Type'].lower() == 'application/json':
        user['username'] = request.json.get("username", "nobody")
    try:
        user['age'] = getage(user['username'])
    except:
        pass
    resp = jsonify(user)
    resp.status_code = 200
    return resp  
    
'''
headers = {'Content-Type': 'application/json'}
import json
import requests as r 
obj = {'username' : 'das'}
res = r.post("http://localhost:5000/json", data=json.dumps(obj),headers=headers)
res.json() 
''' 

#Some data creation 
from sqlalchemy import * 
DATABASE = "people.db"
db = create_engine("sqlite:///"+DATABASE)
db.execute("""create table if not exists people (name string, age int)""")
db.execute("""insert into people values(?,?)""", ["das", 20])

q = db.execute("select age from people where name=?", "das")
q.fetchone()




##Example Login 
from flask import session, redirect, url_for #NEW
app.secret_key = b"jhdkjhdkhshd"  #NEW

from functools import wraps
def auth_required(f):
    @wraps(f)
    def _inner(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))  #login is method name 
        return f(*args, **kwargs)
    return _inner

    
@app.route("/")
@auth_required  #NEW, should be inner 
def home():   # http://localhost:5000/
    return """
            <html><body>
                <h1 id="some" class="cl2">Hello there!!! </h1>
                <h1 id="some2" class="cl2">Welcome</h1>
            </body></html>
        """

def check_auth(user, password):
    return user == 'admin' and password == 'secret'
   
@app.route("/login", methods=['GET', 'POST'])  # http://localhost:5000/login
def login():  
    if request.method == 'POST':
        name = request.form.get('name', 'all')
        password = request.form.get('pass', 'all')
        if check_auth(name, password):
            session['username'] = name
            return redirect(url_for('home'))  #home is method name 
        else:
            return "<h1>Error</h1>"
    else:
        return """
                <html><body>
                <form action="/login" method="post">
                 Name: <br/>
                 <input type="text" name="name" value="" />
                 Password: <br/>
                 <input type="password" name="pass" value="" />
                 <br/><br/>
                 <input type="submit" value="Submit" />
                </form>
                </body></html>
            """
        
'''
s = r.Session()
cred = {'name': 'admin', 'pass': 'secret'}
r1 = s.post("http://127.0.0.1:5000/login", cred)
r2 = s.get("http://127.0.0.1:5000/")
r2.text   
'''        
        
##Example upload 
import os
from flask import Flask, flash, request, redirect, url_for
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/upload', methods=['GET', 'POST']) #http://127.0.0.1:5000/upload
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file.filename:
            filename = secure_filename(file.filename) #normalizes the file path 
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('download',filename=filename))
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''
    
from flask import send_from_directory
#mimetype: str

#as_attachment: bool, attachment_filename:str, mimetype: str
@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)    
    
  
#with file upload and download 
files = {'file': open('copy.txt','rb')} #'file' same as form's name for type=file 
other_form_data = {'DB': 'photcat', 'OUT': 'csv', 'SHORT': 'short'}
r = requests.post("http://127.0.0.1:5000/upload", files=files, data=other_form_data)
r.request.url #'http://127.0.0.1:5000/download/copy.txt' , the redirected one 
r.status_code
r.headers.get('content-disposition') #'attachment; filename=copy.txt'
local_filename = r.headers.get('content-disposition').split("=")[-1]
with open(local_filename+".bak", 'wb') as f:
    f.write(r.content)

            
#for big file 
import shutil
with requests.get('http://127.0.0.1:5000/download/copy.txt', stream=True) as r:
    with open(local_filename+".bak2", 'wb') as f:
        shutil.copyfileobj(r.raw, f)           
        
        
###Middleware
The WSGI application above is a callable that behaves in a certain way. 
Middleware is a WSGI application that wraps another WSGI application. 

The outermost middleware will be called by the server. 
It can modify the data passed to it, then call the WSGI application (or further middleware) 
that it wraps, and so on. And it can take the return value of that call and modify it further.

From the WSGI server's perspective, there is one WSGI application, the one it calls directly. 
Typically, Flask is the "real" application at the end of the chain of middleware. 
But even Flask can call further WSGI applications, although that's an advanced, uncommon use case.

A common middleware you'll see used with Flask is Werkzeug's ProxyFix, 
which modifies the request to look like it came directly from a client even if it passed through 
HTTP proxies on the way. 

There are other middleware that can handle serving static files, authentication, etc.

###Flask-HTTPAuth

Flask-HTTPAuth is a Flask extension that simplifies the use of HTTP authentication with Flask routes.
Basic authentication examples

The following example application uses HTTP Basic authentication to protect route '/':

from flask import Flask
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
auth = HTTPBasicAuth()

users = {
    "john": generate_password_hash("hello"),
    "susan": generate_password_hash("bye")
}

@auth.verify_password
def verify_password(username, password):
    if username in users and \
            check_password_hash(users.get(username), password):
        return username

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.current_user())

if __name__ == '__main__':
    app.run()

The function decorated with the verify_password decorator receives the username and password sent by the client. If the credentials belong to a user, then the function should return the user object. If the credentials are invalid the function can return None or False. The user object can then be queried from the current_user() method of the authentication instance.
Digest authentication example

The following example uses HTTP Digest authentication:

from flask import Flask
from flask_httpauth import HTTPDigestAuth

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret key here'
auth = HTTPDigestAuth()

users = {
    "john": "hello",
    "susan": "bye"
}

@auth.get_password
def get_pw(username):
    if username in users:
        return users.get(username)
    return None

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.username())

if __name__ == '__main__':
    app.run()

Token Authentication Example

The following example application uses a custom HTTP authentication scheme to protect route '/' with a token:

from flask import Flask
from flask_httpauth import HTTPTokenAuth

app = Flask(__name__)
auth = HTTPTokenAuth(scheme='Bearer')

tokens = {
    "secret-token-1": "john",
    "secret-token-2": "susan"
}

@auth.verify_token
def verify_token(token):
    if token in tokens:
        return tokens[token]

@app.route('/')
@auth.login_required
def index():
    return "Hello, {}!".format(auth.current_user())

if __name__ == '__main__':
    app.run()

The HTTPTokenAuth is a generic authentication handler that can be used with non-standard authentication schemes, with the scheme name given as an argument in the constructor. In the above example, the WWW-Authenticate header provided by the server will use Bearer as scheme:

WWW-Authenticate: Bearer realm="Authentication Required"

The verify_token callback receives the authentication credentials provided by the client on the Authorization header. This can be a simple token, or can contain multiple arguments, which the function will have to parse and extract from the string. As with the verify_password, the function should return the user object if the token is valid.

In the examples directory you can find a complete example that uses JWS tokens. JWS tokens are similar to JWT tokens. However using JWT tokens would require an external dependency.
Using Multiple Authentication Schemes

Applications sometimes need to support a combination of authentication methods. For example, a web application could be authenticated by sending client id and secret over basic authentication, while third party API clients use a JWS or JWT bearer token. The MultiAuth class allows you to protect a route with more than one authentication object. To grant access to the endpoint, one of the authentication methods must validate.

In the examples directory you can find a complete example that uses basic and token authentication.
User Roles

Flask-HTTPAuth includes a simple role-based authentication system that can optionally be added to provide an additional layer of granularity in filtering accesses to routes. To enable role support, write a function that returns the list of roles for a given user and decorate it with the get_user_roles decorator:

@auth.get_user_roles
def get_user_roles(user):
    return user.get_roles()

To restrict access to a route to users having a given role, add the role argument to the login_required decorator:

@app.route('/admin')
@auth.login_required(role='admin')
def admins_only():
    return "Hello {}, you are an admin!".format(auth.current_user())

The role argument can take a list of roles, in which case users who have any of the given roles will be granted access:

@app.route('/admin')
@auth.login_required(role=['admin', 'moderator'])
def admins_only():
    return "Hello {}, you are an admin or a moderator!".format(auth.current_user())

In the most advanced usage, users can be filtered by having multiple roles:

@app.route('/admin')
@auth.login_required(role=['user', ['moderator', 'contributor']])
def admins_only():
    return "Hello {}, you are a user or a moderator/contributor!".format(auth.current_user())

Deployment Considerations

Be aware that some web servers do not pass the Authorization headers to the WSGI application by default. For example, if you use Apache with mod_wsgi, you have to set option WSGIPassAuthorization On as documented here.


###SQLAlchemy
Quick Start

Flask-SQLAlchemy simplifies using SQLAlchemy by automatically handling creating, using, and cleaning up the SQLAlchemy objects you’d normally work with. While it adds a few useful features, it still works like SQLAlchemy.

This page will walk you through the basic use of Flask-SQLAlchemy. For full capabilities and customization, see the rest of these docs, including the API docs for the SQLAlchemy object.
Check the SQLAlchemy Documentation

Flask-SQLAlchemy is a wrapper around SQLAlchemy. You should follow the SQLAlchemy Tutorial to learn about how to use it, and consult its documentation for detailed information about its features. These docs show how to set up Flask-SQLAlchemy itself, not how to use SQLAlchemy. Flask-SQLAlchemy sets up the engine and scoped session automatically, so you can skip those parts of the SQLAlchemy tutorial.

This guide assumes you are using SQLAlchemy 2.x, which has a new API for defining models and better support for Python type hints and data classes. If you are using SQLAlchemy 1.x, see Legacy Quickstart.
Installation

Flask-SQLAlchemy is available on PyPI and can be installed with various Python tools. For example, to install or update the latest version using pip:

$ pip install -U Flask-SQLAlchemy

Initialize the Extension

First create the db object using the SQLAlchemy constructor.

Pass a subclass of either DeclarativeBase or DeclarativeBaseNoMeta to the constructor.

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
  pass

db = SQLAlchemy(model_class=Base)

Learn more about customizing the base model class in Models and Tables.
About the SQLAlchemy object

Once constructed, the db object gives you access to the db.Model class to define models, and the db.session to execute queries.

The SQLAlchemy object also takes additional arguments to customize the objects it manages.
Configure the Extension

The next step is to connect the extension to your Flask app. The only required Flask app config is the SQLALCHEMY_DATABASE_URI key. That is a connection string that tells SQLAlchemy what database to connect to.

Create your Flask application object, load any config, and then initialize the SQLAlchemy extension class with the application by calling db.init_app. This example connects to a SQLite database, which is stored in the app’s instance folder.

# create the app
app = Flask(__name__)
# configure the SQLite database, relative to the app instance folder
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
# initialize the app with the extension
db.init_app(app)

See Configuration for an explanation of connections strings and what other configuration keys are used.
Define Models

Subclass db.Model to define a model class. The model will generate a table name by converting the CamelCase class name to snake_case.

from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

class User(db.Model):
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(unique=True)
    email: Mapped[str]

See Models and Tables for more information about defining and creating models and tables.
Create the Tables

After all models and tables are defined, call SQLAlchemy.create_all() to create the table schema in the database. This requires an application context. Since you’re not in a request at this point, create one manually.

with app.app_context():
    db.create_all()

If you define models in other modules, you must import them before calling create_all, otherwise SQLAlchemy will not know about them.

create_all does not update tables if they are already in the database. If you change a model’s columns, use a migration library like Alembic with Flask-Alembic or Flask-Migrate to generate migrations that update the database schema.
Query the Data

Within a Flask view or CLI command, you can use db.session to execute queries and modify model data.

SQLAlchemy automatically defines an __init__ method for each model that assigns any keyword arguments to corresponding database columns and other attributes.

db.session.add(obj) adds an object to the session, to be inserted. Modifying an object’s attributes updates the object. db.session.delete(obj) deletes an object. Remember to call db.session.commit() after modifying, adding, or deleting any data.

db.session.execute(db.select(...)) constructs a query to select data from the database. Building queries is the main feature of SQLAlchemy, so you’ll want to read its tutorial on select to learn all about it. You’ll usually use the Result.scalars() method to get a list of results, or the Result.scalar() method to get a single result.

@app.route("/users")
def user_list():
    users = db.session.execute(db.select(User).order_by(User.username)).scalars()
    return render_template("user/list.html", users=users)

@app.route("/users/create", methods=["GET", "POST"])
def user_create():
    if request.method == "POST":
        user = User(
            username=request.form["username"],
            email=request.form["email"],
        )
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("user_detail", id=user.id))

    return render_template("user/create.html")

@app.route("/user/<int:id>")
def user_detail(id):
    user = db.get_or_404(User, id)
    return render_template("user/detail.html", user=user)

@app.route("/user/<int:id>/delete", methods=["GET", "POST"])
def user_delete(id):
    user = db.get_or_404(User, id)

    if request.method == "POST":
        db.session.delete(user)
        db.session.commit()
        return redirect(url_for("user_list"))

    return render_template("user/delete.html", user=user)

You may see uses of Model.query to build queries. This is an older interface for queries that is considered legacy in SQLAlchemy. Prefer using db.session.execute(db.select(...)) instead.

See Modifying and Querying Data for more information about queries.
What to Remember

For the most part, you should use SQLAlchemy as usual. The SQLAlchemy extension instance creates, configures, and gives access to the following things:

    SQLAlchemy.Model declarative model base class. It sets the table name automatically instead of needing __tablename__.

    SQLAlchemy.session is a session that is scoped to the current Flask application context. It is cleaned up after every request.

    SQLAlchemy.metadata and SQLAlchemy.metadatas gives access to each metadata defined in the config.

    SQLAlchemy.engine and SQLAlchemy.engines gives access to each engine defined in the config.

    SQLAlchemy.create_all() creates all tables.

    You must be in an active Flask application context to execute queries and to access the session and engine.

Logo of Flask-SQLAlchemy
Contents

    Quick Start
        Check the SQLAlchemy Documentation
        Installation
        Initialize the Extension
            About the SQLAlchemy object
        Configure the Extension
        Define Models
        Create the Tables
        Query the Data
        What to Remember

Navigation

    Overview
        Previous: Flask-SQLAlchemy
        Next: Configuration 

Quick search

        
        
###Packaging 
STEP1: CREATE below 
poetry new flaskr
cd flaskr



#ONLy for Office PC 
Given index-url = https://<<SERVER>>/artifactory/api/pypi/<<LOCATION>>/simple/
pip config list 

poetry source add --priority=default ourpypi index-url
poetry source add --priority=supplemental PyPI

#where venv to be created 
poetry config virtualenvs.in-project true 

#STEP1.1
poetry add flask gevent

Copy static, templates and quick_server.py inside flaskr\flaskr

STEP2: UPDATE
#flaskr\flaskr\__init__.py
from flask import Flask
app = Flask(__name__)
from . import quick_server
#Update flaskr\flaskr\quick_server.py
#app = Flask(__name__)  #comment this line 
from flaskr import app

STEP3: TEST 
poetry env info
poetry shell
set FLASK_APP=flaskr 
flask run   # run whatever set in FLASK_APP

STEP4:
exit
poetry build -v
#You can find the file in dist/flaskr-0.1.0-py3-none-any.whl

FURTHER TEST 
cd ..
python -m venv .\env 
.\env\Scripts\activate
pip install flaskr/dist/flaskr-0.1.0-py3-none-any.whl
set FLASK_APP=flaskr 
flask run 


Install 
$ pip install --force-reinstall --no-dependencies dist/flaskr-0.1.0-py3-none-any.whl

STEP4:
##Deployment
#https://flask.palletsprojects.com/en/1.1.x/deploying/wsgi-standalone/

# For example to deploy via  Gevent 
pip install gevent 
#Gevent is a coroutine-based Python networking library 
#that uses greenlet to provide a high-level synchronous API on top of libev event loop:

#Execute by 'python gevent_server.py'
#gevent_server.py
from gevent.pywsgi import WSGIServer
from flaskr import app

# http_server = WSGIServer(('localhost', 443), app, keyfile='key.pem', certfile='cert.pem')
http_server = WSGIServer(('localhost', 8080), app)
http_server.serve_forever()

##To generate self signed certificate 
Note cert.pem may have public ip or localhost 
But whatever it has , must be the same as given in above 'http_server'

import requests
r = requests.get("https://localhost/helloj?name=das&format=json", verify=False)
r = requests.get("https://localhost/helloj?name=das&format=json", verify="./cert.pem")

#Create - instead of localhost, gives public IP 
#-nodes (short for no DES) for no  passphrase(else min 4 character passphrase) 
(check by 'where openssl.exe' ) 
$ openssl req -x509 -subj '/CN=localhost' -nodes -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365


Note for subjectAltName error
Check 
https://gist.github.com/KeithYeh/bb07cadd23645a6a62509b1ec8986bbc
https://serverfault.com/questions/845766/generating-a-self-signed-cert-with-openssl-that-works-in-chrome-58


            
###Install 
pip install   scikit-learn scipy pillow  pylint pytest scikit-image seaborn sympy tornado xlwt xlrd yellowbrick
pip install lightgbm
pip install  xgboost tpot
pip install pytest-cov tables stanfordcorenlp sumy
pip install sparkit-learn sklearn-pandas gensim pmdarima
pip install prophet pandas-datareader
pip install streamlit 
pip install pycausalimpact
pip install pandas flask sqlalchemy 
pip install  pytest pytest-cov requests  beautifulsoup4 flask sqlalchemy numpy  pandas  openpyxl xlrd matplotlib wheel gevent

pip install --upgrade pip
pip install tensorflow
pip3 install torch torchvision torchaudio
pip install --upgrade keras-cv
pip install --upgrade keras-hub
pip install --upgrade keras

You can export the environment variable KERAS_BACKEND or you can edit your local config file at ~/.keras/keras.json to configure your backend. Available backend options are: "jax", "tensorflow", "torch". Example:

export KERAS_BACKEND="jax"

In Colab, you can do:

import os
os.environ["KERAS_BACKEND"] = "jax"
import keras

pip install fastapi httpx "uvicorn[standard]"
pip install "fastapi[standard]"
pip install email-validator
pip install "pydantic[email]"
pip install python-multipart
pip install sqlmodel
pip install httpx
pip install pyjwt[crypto]
pip install "passlib[bcrypt]"
pip install --upgrade orjson
pip install jinja2
pip install websockets
pip install pydantic-settings
pip install python-dotenv

    
###Introduction to FastAPI & differences from Flask
pip install fastapi httpx "uvicorn[standard]"
pip install "fastapi[standard]"


Run as 
fastapi dev main.py

    module    main.py

      code   Importing the FastAPI app object from the module with the
             following code:

             from main import app

       app   Using import string: main:app
       
    server   Server started at http://127.0.0.1:8000
    server   Documentation at http://127.0.0.1:8000/docs
    Alternative API docs http://127.0.0.1:8000/redoc
    raw OpenAPI schema  http://127.0.0.1:8000/openapi.json
    
    
       tip   Running in development mode, for production use:
             fastapi run
             
For azure , check 
https://techcommunity.microsoft.com/blog/appsonazureblog/deploy-streamlit-on-azure-web-app/4276108
To deploy a fastapi application on Azure App Service, follow these steps:
    Create an Azure App Service with B1 SKU or higher, as the free version does not support fastapi.
    Choose Python v3.12 or above for fastapi in the App Service.
    Choose Linux as the operating system for the App Service.
    Make sure your code folder has a requirements.txt file with all the dependencies.
    Create a bash script run.sh, and write the following command in it:
    Bash 
        python -m fastapi run ui/app.py --server.port 8000 --server.address 0.0.0.0

    Replace ui/app.py with your application name.
    Use port 8000 because Azure App Service by default exposes only 8000 and 443 ports.

    Open Visual Studio Code and install the Azure Extension Pack.
    Log in to Visual Studio Code with your Azure account.
    Use the Azure App Service: 
        Deploy to Web App command in Visual Studio Code and select your App Service name.
    Wait for deployment to be finished.
    Go to the Azure portal and update the Startup Command configuration for the App Service 
    and set the value to run.sh. You can find this configuration inside App Service > Settings > Configurations > General settings.
    Wait for some seconds and visit the application URL. 
    You have successfully deployed your fastapi application to the Azure App Service.

OR 
    az login
    az group create --name ResourceGroupName --location Region
    az appservice plan create --name PlanName --resource-group ResourceGroupName --sku B1 --is-linux
    az webapp create --name AppName --resource-group ResourceGroupName --plan PlanName --runtime "python|3.12"
    Deploy your fastapi app to Azure using Git. 
    git init
    git remote add azure <git-url-from-azure>

    Now finally push your code to azure.
    Bash
    git add .
    git commit -m "Initial commit"
    git push azure master

    

https://fastapi.tiangolo.com/fastapi-cli/
FastAPI CLI uses Uvicorn, a high-performance, production-ready, ASGI server

There are several alternatives, including:
    Uvicorn: a high performance ASGI server.
    Hypercorn: an ASGI server compatible with HTTP/2 and Trio among other features.
    Daphne: the ASGI server built for Django Channels.
    Granian: A Rust HTTP server for Python applications.
    NGINX Unit: NGINX Unit is a lightweight and versatile web application runtime.

    
$ uvicorn main:app --host 0.0.0.0 --port 80

Uvicorn and other servers support a --reload option that is useful during development.

#Multipl workers 
fastapi run --workers 4 main.py

uvicorn main:app --host 0.0.0.0 --port 8080 --workers 4

##With Docker and Path & Query parameters 
Start Docker app, which is based wsl - DOcker Desktop

For example, your requirements.txt could look like:

fastapi[standard]>=0.113.0,<0.114.0
pydantic>=2.7.0,<3.0.0

$ pip install -r requirements.txt

.
+-- app
�   +-- __init__.py
�   +-- main.py
+-- Dockerfile
+-- requirements.txt


#app\__init__.py 

#app\main.py 
from typing import Union

from fastapi import FastAPI

app = FastAPI()


@app.get("/")
def read_root():
    return {"Hello": "World"}

#Note no Return Type, but argument has type 
#means return type is Any , which is std practice 
@app.get("/items/{item_id}")  #Path 
def read_item(item_id: int, q: Union[str, None] = None): #item_id is Path and rest are Query 
    return {"item_id": item_id, "q": q}
    
#Dockerfile
FROM python:3.9
WORKDIR /code
COPY ./requirements.txt /code/requirements.txt
RUN pip install --no-cache-dir --upgrade -r /code/requirements.txt
COPY ./app /code/app
CMD ["fastapi", "run", "app/main.py", "--port", "80"]

#Behind a TLS Termination Proxy
CMD ["fastapi", "run", "app/main.py", "--proxy-headers", "--port", "80"]

You can also use the other operations:
    @app.post()
    @app.put()
    @app.delete()

And the more exotic ones:
    @app.options()
    @app.head()
    @app.patch()
    @app.trace()

#Build 
docker build -t myimage .
docker run -d --name mycontainer -p 80:80 myimage

http://192.168.99.100/items/5?q=somequery 
or http://127.0.0.1/items/5?q=somequery 

You will see something like:
{"item_id": 5, "q": "somequery"}

http://192.168.99.100/docs or http://127.0.0.1/docs

##Docker help 
for Windows10 Pro , install from 
https://store.docker.com/editions/community/docker-ce-desktop-windows

docker command line 
https://docs.docker.com/engine/reference/commandline/run/

dockerFile reference 
https://docs.docker.com/engine/reference/builder/

docker Hub 
https://hub.docker.com/

Basic commands 
https://docs.docker.com/reference/cli/docker/

Docker cheatsheet 
https://docs.docker.com/get-started/docker_cheatsheet.pdf

#List the hello-world container 
> docker container ls --all

#Explore the Docker help pages by running some help commands:
> docker --help
> docker container --help
> docker container ls --help
> docker run --help

##Pull an image of the Ubuntu OS and run an interactive terminal 
#inside the spawned container:

> docker run --interactive --tty ubuntu bash  #pulls ubuntu:latest
#or 
> docker run -it  ubuntu bash

root@8aea0acb7423:$ hostname
8aea0acb7423

#Notice that the hostname is assigned as the container ID 
#(and is also used in the prompt).

#Exit the shell with the exit command (which also stops the container):
root@8aea0acb7423:/$ exit
>

#eg The password is 'ubuntu' for the 'ubuntu' user (at least in docker for ubuntu :14.04.03).
#NB: 'ubuntu' is created after the startup of the container so, below would directly take to root 
$ docker run -i -t --entrypoint /bin/bash  ubuntu  

#The hello-world container (randomly named, relaxed_sammet) stopped 
#after displaying its message. 
#The ubuntu container (randomly named, laughing_kowalevski) stopped when you exited the container.

> docker container ls --all
CONTAINER ID    IMAGE          COMMAND     CREATED          STATUS                      PORTS    NAMES
8aea0acb7423    ubuntu         "bash"      2 minutes ago    Exited (0) 2 minutes ago             laughing_kowalevski
45f77eb48e78    hello-world    "/hello"    3 minutes ago    Exited (0) 3 minutes ago             relaxed_sammet


#Pull and run a Dockerized nginx web server that we name, webserver:
#expose port 80 on the container(nginx) to port 8080(public) on the host
#--rm is must as it would delete old container or change the name 
#(upping takes min 3 min)
> docker run --rm --detach --publish 8080:80 --name webserver nginx #host:guest
#or 
> docker run --rm -d -p 8080:80 --name webserver nginx

Point your web browser at http://192.168.99.101:8080 to display the nginx start page. 
(localhost does not work)
192.168.99.101 is the docker VM displayed during cmd start up 
or docker-machine ip or $DOCKER_HOST

#List only your running containers:
> docker container ls
CONTAINER ID    IMAGE    COMMAND                   CREATED          STATUS          PORTS                 NAMES
0e788d8e4dfd    nginx    "nginx -g 'daemon of�"    2 minutes ago    Up 2 minutes    0.0.0.0:80->80/tcp    webserver

#Stop the running nginx container by the name we assigned it, webserver:
>  docker container stop webserver 

#Remove all three containers by their names -- the latter two names will differ for you:
#below is must to rerun with same name 
> docker container rm webserver laughing_kowalevski relaxed_sammet docker-nginx


##With Async 
If you are using third party libraries that tell you to call them with await, like:

results = await some_library()

Then, declare your path operation functions with async def like:

@app.get('/')
async def read_results():
    results = await some_library()
    return results
    
    
###Reference 
https://fastapi.tiangolo.com/reference/fastapi/#fastapi.FastAPI
https://fastapi.tiangolo.com/reference/parameters/
https://fastapi.tiangolo.com/reference/dependencies/#fastapi.Depends



FastAPI(
    *,
    debug=False,
    routes=None,
    title="FastAPI",
    summary=None,
    description="",
    version="0.1.0",
    openapi_url="/openapi.json",
    openapi_tags=None,
    servers=None,
    dependencies=None,
    default_response_class=Default(JSONResponse),
    redirect_slashes=True,
    docs_url="/docs",
    redoc_url="/redoc",
    swagger_ui_oauth2_redirect_url="/docs/oauth2-redirect",
    swagger_ui_init_oauth=None,
    middleware=None,
    exception_handlers=None,
    on_startup=None,
    on_shutdown=None,
    lifespan=None,
    terms_of_service=None,
    contact=None,
    license_info=None,
    openapi_prefix="",
    root_path="",
    root_path_in_servers=True,
    responses=None,
    callbacks=None,
    webhooks=None,
    deprecated=None,
    include_in_schema=True,
    swagger_ui_parameters=None,
    generate_unique_id_function=Default(generate_unique_id),
    separate_input_output_schemas=True,
    **extra
)


Query(                                  Path(                           Body(                               Form(
    default=Undefined,                      default=...,                    default=Undefined,                  default=Undefined,
    *,                                      *,                              *,                                  *,
    default_factory=_Unset,                 default_factory=_Unset,         default_factory=_Unset,             default_factory=_Unset,
    alias=None,                             alias=None,                     embed=None,                         media_type="application/x-www-form-urlen
    alias_priority=_Unset,                  alias_priority=_Unset,          media_type="application/json"       alias=None,
    validation_alias=None,                  validation_alias=None,          alias=None,                         alias_priority=_Unset,
    serialization_alias=None,               serialization_alias=None,       alias_priority=_Unset,              validation_alias=None,
    title=None,                             title=None,                     validation_alias=None,              serialization_alias=None,
    description=None,                       description=None,               serialization_alias=None,           title=None,
    gt=None,                                gt=None,                        title=None,                         description=None,
    ge=None,                                ge=None,                        description=None,                   gt=None,
    lt=None,                                lt=None,                        gt=None,                            ge=None,
    le=None,                                le=None,                        ge=None,                            lt=None,
    min_length=None,                        min_length=None,                lt=None,                            le=None,
    max_length=None,                        max_length=None,                le=None,                            min_length=None,
    pattern=None,                           pattern=None,                   min_length=None,                    max_length=None,
    regex=None,                             regex=None,                     max_length=None,                    pattern=None,
    discriminator=None,                     discriminator=None,             pattern=None,                       regex=None,
    strict=_Unset,                          strict=_Unset,                  regex=None,                         discriminator=None,
    multiple_of=_Unset,                     multiple_of=_Unset,             discriminator=None,                 strict=_Unset,
    allow_inf_nan=_Unset,                   allow_inf_nan=_Unset,           strict=_Unset,                      multiple_of=_Unset,
    max_digits=_Unset,                      max_digits=_Unset,              multiple_of=_Unset,                 allow_inf_nan=_Unset,
    decimal_places=_Unset,                  decimal_places=_Unset,          allow_inf_nan=_Unset,               max_digits=_Unset,
    examples=None,                          examples=None,                  max_digits=_Unset,                  decimal_places=_Unset,
    example=_Unset,                         example=_Unset,                 decimal_places=_Unset,              examples=None,
    openapi_examples=None,                  openapi_examples=None,          examples=None,                      example=_Unset,
    deprecated=None,                        deprecated=None,                example=_Unset,                     openapi_examples=None,
    include_in_schema=True,                 include_in_schema=True,         openapi_examples=None,              deprecated=None,
    json_schema_extra=None,                 json_schema_extra=None,         deprecated=None,                    include_in_schema=True,
    **extra                                 **extra                         include_in_schema=True,             json_schema_extra=None,
)                                       )                                   json_schema_extra=None,             **extra
                                                                            **extra                         )
                                                                          )

File(
    default=Undefined,
    *,
    default_factory=_Unset,
    media_type="multipart/form-data",
    alias=None,
    alias_priority=_Unset,
    validation_alias=None,
    serialization_alias=None,
    title=None,
    description=None,
    gt=None,
    ge=None,
    lt=None,
    le=None,
    min_length=None,
    max_length=None,
    pattern=None,
    regex=None,
    discriminator=None,
    strict=_Unset,
    multiple_of=_Unset,
    allow_inf_nan=_Unset,
    max_digits=_Unset,
    decimal_places=_Unset,
    examples=None,
    example=_Unset,
    openapi_examples=None,
    deprecated=None,
    include_in_schema=True,
    json_schema_extra=None,
    **extra
)

###Other Response  

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI()


@app.get("/items/", response_class=HTMLResponse)
async def read_items():
    return """
    <html>
        <head>
            <title>Some HTML in here</title>
        </head>
        <body>
            <h1>Look ma! HTML!</h1>
        </body>
    </html>
    """


The main Response class, all the other responses inherit from it.

You can return it directly.

It accepts the following parameters:

    content - A str or bytes.
    status_code - An int HTTP status code.
    headers - A dict of strings.
    media_type - A str giving the media type. E.g. "text/html".

@app.get("/legacy/")
def get_legacy_data():
    data = """<?xml version="1.0"?>
    <shampoo>
    <Header>
        Apply shampoo here.
    </Header>
    <Body>
        You'll have to use soap here.
    </Body>
    </shampoo>
    """
    return Response(content=data, media_type="application/xml")
    
@app.get("/", response_class=PlainTextResponse)
async def main():
    return "Hello World"
    
@app.get("/typer")
async def redirect_typer():
    return RedirectResponse("https://typer.tiangolo.com")
    
@app.get("/pydantic", response_class=RedirectResponse, status_code=302)
async def redirect_pydantic():
    return "https://docs.pydantic.dev/"
    
async def fake_video_streamer():
    for i in range(10):
        yield b"some fake video bytes"


@app.get("/")
async def main():
    return StreamingResponse(fake_video_streamer())
    
some_file_path = "large-video-file.mp4"
app = FastAPI()


@app.get("/")
def main():
    def iterfile():  # (1)
        with open(some_file_path, mode="rb") as file_like:  # (2)
            yield from file_like  # (3)

    return StreamingResponse(iterfile(), media_type="video/mp4")
    
some_file_path = "large-video-file.mp4"
app = FastAPI()


@app.get("/")
async def main():
    return FileResponse(some_file_path)
    
@app.get("/", response_class=FileResponse)
async def main():
    return some_file_path
    
Handle in requests 
r = requests.get('https://api.github.com/events', stream=True)

with open(filename, 'wb') as fd:
    for chunk in r.iter_content(chunk_size=128):
        fd.write(chunk)
        
        
        
##additional Response 
Keep in mind that you have to return the JSONResponse directly.


from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class Item(BaseModel):
    id: str
    value: str


class Message(BaseModel):
    message: str


app = FastAPI()


@app.get("/items/{item_id}", response_model=Item, responses={404: {"model": Message}})
async def read_item(item_id: str):
    if item_id == "foo":
        return {"id": "foo", "value": "there goes my hero"}
    return JSONResponse(status_code=404, content={"message": "Item not found"})

    
##Additional media types for the main response
class Item(BaseModel):
    id: str
    value: str


@app.get(
    "/items/{item_id}",
    response_model=Item,
    responses={
        200: {
            "content": {"image/png": {}},
            "description": "Return the JSON item or an image.",
        }
    },
)
async def read_item(item_id: str, img: Union[bool, None] = None):
    if img:
        return FileResponse("image.png", media_type="image/png")
    else:
        return {"id": "foo", "value": "there goes my hero"}
        
        
You can also combine response information from multiple places, including the response_model, status_code, and responses parameters.
You can declare a response_model, using the default status code 200 (or a custom one if you need), 
and then declare additional information for that same response in responses, directly in the OpenAPI schema.

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class Item(BaseModel):
    id: str
    value: str


class Message(BaseModel):
    message: str


app = FastAPI()


@app.get(
    "/items/{item_id}",
    response_model=Item,
    responses={
        404: {"model": Message, "description": "The item was not found"},
        200: {
            "description": "Item requested by ID",
            "content": {
                "application/json": {
                    "example": {"id": "bar", "value": "The bar tenders"}
                }
            },
        },
    },
)
async def read_item(item_id: str):
    if item_id == "foo":
        return {"id": "foo", "value": "there goes my hero"}
    else:
        return JSONResponse(status_code=404, content={"message": "Item not found"})
        
        
class Item(BaseModel):
    id: str
    value: str


responses = {
    404: {"description": "Item not found"},
    302: {"description": "The item was moved"},
    403: {"description": "Not enough privileges"},
}

@app.get(
    "/items/{item_id}",
    response_model=Item,
    responses={**responses, 200: {"content": {"image/png": {}}}},
)
async def read_item(item_id: str, img: Union[bool, None] = None):
    if img:
        return FileResponse("image.png", media_type="image/png")
    else:
        return {"id": "foo", "value": "there goes my hero"}
        
        
        
###Path parameters with types
@app.get("/items/{item_id}")
async def read_item(item_id: int):

If you run this example and open your browser at http://127.0.0.1:8000/items/3, you will see a response of:

{"item_id":3}


Data validation:But if you go to the browser at http://127.0.0.1:8000/items/foo, you will see a nice HTTP error of:

{
  "detail": [
    {
      "type": "int_parsing",
      "loc": [
        "path",
        "item_id"
      ],
      "msg": "Input should be a valid integer, unable to parse string as an integer",
      "input": "foo",
      "url": "https://errors.pydantic.dev/2.1/v/int_parsing"
    }
  ]
}
##Order matters
When creating path operations, you can find situations where you have a fixed path.

Like /users/me, let's say that it's to get data about the current user.

And then you can also have a path /users/{user_id} to get data about a specific user by some user ID.

Because path operations are evaluated in order, 
you need to make sure that the path for /users/me is declared before the one for /users/{user_id}:


from fastapi import FastAPI

app = FastAPI()


@app.get("/users/me")
async def read_user_me():
    return {"user_id": "the current user"}


@app.get("/users/{user_id}")
async def read_user(user_id: str):
    return {"user_id": user_id}


Similarly, you cannot redefine a path operation:


from fastapi import FastAPI

app = FastAPI()


@app.get("/users")
async def read_users():
    return ["Rick", "Morty"]


@app.get("/users")
async def read_users2():
    return ["Bean", "Elfo"]

The first one will always be used since the path matches first.

##Path Predefined values
from enum import Enum

from fastapi import FastAPI


class ModelName(str, Enum):
    alexnet = "alexnet"
    resnet = "resnet"
    lenet = "lenet"


app = FastAPI()


@app.get("/models/{model_name}")
async def get_model(model_name: ModelName):
    if model_name is ModelName.alexnet:
        return {"model_name": model_name, "message": "Deep Learning FTW!"}

    if model_name.value == "lenet":
        return {"model_name": model_name, "message": "LeCNN all the images"}

    return {"model_name": model_name, "message": "Have some residuals"}
    
##Path parameters containing paths

Let's say you have a path operation with a path /files/{file_path}.

But you need file_path itself to contain a path, like home/johndoe/myfile.txt.

So, the URL for that file would be something like: /files/home/johndoe/myfile.txt.

@app.get("/files/{file_path:path}")
async def read_file(file_path: str):
    return {"file_path": file_path}
    
    
You could need the parameter to contain /home/johndoe/myfile.txt, with a leading slash (/).

In that case, the URL would be: /files//home/johndoe/myfile.txt, with a double slash (//) between files 
and home.

##Optional Path 
Not possible as per doc, but could be defined like below 
Note Query param with default None 

from typing import Optional

from fastapi import FastAPI, Query, status

app = FastAPI()


@app.get(
    "/{job_id}/{event_id}",
    status_code=status.HTTP_200_OK,
    summary="Retrieve the events related to a job.",
)
@app.get(
    "/{job_id}",
    status_code=status.HTTP_200_OK,
    summary="Retrieve ALL events related to a job.",
)
def events_by_job_id(
    job_id: str = Path(..., description="Job id to be retrieved."),
    event_id: Optional[str] = Query(None, description="Event id to be retrieved."),
):
    return {"job_id": job_id, "event_id": event_id}
    
    
###More Query 
from fastapi import FastAPI

app = FastAPI()

fake_items_db = [{"item_name": "Foo"}, {"item_name": "Bar"}, {"item_name": "Baz"}]


@app.get("/items/")
async def read_item(skip: int = 0, limit: int = 10):
    return fake_items_db[skip : skip + limit]

The query is the set of key-value pairs that go after the ? in a URL, separated by & characters.

For example, in the URL:

http://127.0.0.1:8000/items/?skip=0&limit=10

##Optional Query
@app.get("/items/{item_id}")
async def read_item(item_id: str, q: str | None = None):
    if q:
        return {"item_id": item_id, "q": q}
    return {"item_id": item_id}
    
You can also declare bool types, and they will be converted:

async def read_item(item_id: str, q: str | None = None, short: bool = False)

http://127.0.0.1:8000/items/foo?short=1

or

http://127.0.0.1:8000/items/foo?short=True

or

http://127.0.0.1:8000/items/foo?short=true

or

http://127.0.0.1:8000/items/foo?short=on

or

http://127.0.0.1:8000/items/foo?short=yes

Multiple 
@app.get("/users/{user_id}/items/{item_id}")
async def read_user_item(user_id: int, item_id: str, q: str | None = None, short: bool = False):

##Required Query
async def read_user_item(item_id: str, needy: str):

If you open in your browser a URL like:

http://127.0.0.1:8000/items/foo-item

...without adding the required parameter needy, you will see an error like:

{
  "detail": [
    {
      "type": "missing",
      "loc": [
        "query",
        "needy"
      ],
      "msg": "Field required",
      "input": null,
      "url": "https://errors.pydantic.dev/2.1/v/missing"
    }
  ]
}

some parameters as required, some as having a default value, and some entirely optional:

async def read_user_item(item_id: str, needy: str, skip: int = 0, limit: int | None = None):


###Request Body - POST 
from fastapi import FastAPI
from pydantic import BaseModel


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None


app = FastAPI()


@app.post("/items/")
async def create_item(item: Item):
    #return item
    item_dict = item.dict()
    if item.tax is not None:
        price_with_tax = item.price + item.tax
        item_dict.update({"price_with_tax": price_with_tax})
    return item_dict
    

FastAPI will recognize that the function parameters that match path parameters should be taken 
from the path, and that function parameters that are declared to be Pydantic models should be taken 
from the request body

@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Item):
    return {"item_id": item_id, **item.dict()}

##Request body + path + query parameters
@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Item, q: str | None = None):

###Response Model - function Return Type

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None
    tags: list[str] = []


@app.post("/items/")
async def create_item(item: Item) -> Item:
    return item


@app.get("/items/")
async def read_items() -> list[Item]:
    return [
        Item(name="Portal Gun", price=42.0),
        Item(name="Plumbus", price=32.0),
    ]
    
FastAPI will use this return type to:
    Validate the returned data.
        If the data is invalid (e.g. you are missing a field), it means that your app code is broken, 
        not returning what it should, and it will return a server error instead of returning incorrect data. 
        This way you and your clients can be certain that they will receive the data and the data shape expected.
    Add a JSON Schema for the response, in the OpenAPI path operation.
        This will be used by the automatic docs.
        It will also be used by automatic client code generation tools.

But most importantly:
    It will limit and filter the output data to what is defined in the return type.
        This is particularly important for security, we'll see more of that below.

##response_model Parameter
If you declare both a return type and a response_model, 
the response_model will take priority and be used by FastAPI.
Purpose is similar to Return type 

You can use the response_model parameter in any of the path operations:
    @app.get()
    @app.post()
    @app.put()
    @app.delete()
    etc.

from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None
    tags: list[str] = []


@app.post("/items/", response_model=Item)
async def create_item(item: Item) -> Any:
    return item


@app.get("/items/", response_model=list[Item])
async def read_items() -> Any:
    return [
        {"name": "Portal Gun", "price": 42.0},
        {"name": "Plumbus", "price": 32.0},
    ]
## Data filtering in Response 
Make sure you create a virtual environment, activate it, and then install it, for example:

$ pip install email-validator

or with:

$ pip install "pydantic[email]"

from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel, EmailStr

app = FastAPI()


class UserIn(BaseModel):
    username: str
    password: str
    email: EmailStr
    full_name: str | None = None


class UserOut(BaseModel):
    username: str
    email: EmailStr
    full_name: str | None = None


@app.post("/user/", response_model=UserOut)
async def create_user(user: UserIn) -> Any:
    return user
    
Here, even though our path operation function is returning the same input user t
hat contains the password,we declared the response_model to be our model UserOut, that doesn't 
include the password

OR use like 
class BaseUser(BaseModel):
    username: str
    email: EmailStr
    full_name: str | None = None


class UserIn(BaseUser):
    password: str


@app.post("/user/")
async def create_user(user: UserIn) -> BaseUser:
    return user
    
##Return a Response Directly
from fastapi import FastAPI, Response
from fastapi.responses import JSONResponse, RedirectResponse

app = FastAPI()


@app.get("/portal")
async def get_portal(teleport: bool = False) -> Response:
    if teleport:
        return RedirectResponse(url="https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    return JSONResponse(content={"message": "Here's your interdimensional portal."})
    
async def get_teleport() -> RedirectResponse:
    return RedirectResponse(url="https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    
##Invalid Return Type Annotations
But when you return some other arbitrary object that is not a valid Pydantic type (e.g. a database object) 
and you annotate it like that in the function, FastAPI will try to create a Pydantic response model 
from that type annotation, and will fail.
    
async def get_portal(teleport: bool = False) -> Response | dict:
    if teleport:
        return RedirectResponse(url="https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    return {"message": "Here's your interdimensional portal."}
    
    
Continuing from the example above, you might not want to have the default data validation, 
documentation, filtering, etc. that is performed by FastAPI.

But you might want to still keep the return type annotation in the function to get the support 
from tools like editors and type checkers (e.g. mypy).

In this case, you can disable the response model generation by setting response_model=None

@app.get("/portal", response_model=None)
async def get_portal(teleport: bool = False) -> Response | dict:
    if teleport:
        return RedirectResponse(url="https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    return {"message": "Here's your interdimensional portal."}
    
##Response Model encoding parameters
Your response model could have default values, like:

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float = 10.5
    tags: list[str] = []


items = {
    "foo": {"name": "Foo", "price": 50.2},
    "bar": {"name": "Bar", "description": "The bartenders", "price": 62, "tax": 20.2},
    "baz": {"name": "Baz", "description": None, "price": 50.2, "tax": 10.5, "tags": []},
}


@app.get("/items/{item_id}", response_model=Item, response_model_exclude_unset=True)
async def read_item(item_id: str):
    return items[item_id]

    
You can set the path operation decorator parameter response_model_exclude_unset=True
and those default values won't be included in the response, only the values actually set.

So, if you send a request to that path operation for the item with ID foo, the response 
(not including default values) will be:

{
    "name": "Foo",
    "price": 50.2
}

You can also use:

    response_model_exclude_defaults=True
    response_model_exclude_none=True

If the data has the same values as the default ones, like the item with ID baz:

{
    "name": "Baz",
    "description": None,
    "price": 50.2,
    "tax": 10.5,
    "tags": []
}

FastAPI is smart enough (actually, Pydantic is smart enough) to realize that, even though description, tax, 
and tags have the same values as the defaults, they were set explicitly (instead of taken from the defaults).
    

You can also use the path operation decorator parameters response_model_include 
and response_model_exclude.

They take a set of str with the name of the attributes to include (omitting the rest) 
or to exclude (including the rest).

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float = 10.5


items = {
    "foo": {"name": "Foo", "price": 50.2},
    "bar": {"name": "Bar", "description": "The Bar fighters", "price": 62, "tax": 20.2},
    "baz": {
        "name": "Baz",
        "description": "There goes my baz",
        "price": 50.2,
        "tax": 10.5,
    },
}


@app.get(
    "/items/{item_id}/name",
    response_model=Item,
    response_model_include={"name", "description"},
)
async def read_item_name(item_id: str):
    return items[item_id]


@app.get("/items/{item_id}/public", response_model=Item, response_model_exclude={"tax"})
async def read_item_public_data(item_id: str):
    return items[item_id]
    
##Using lists instead of sets
If you forget to use a set and use a list or tuple instead, FastAPI will still convert it to a set 
and it will work correctly:
response_model_include=["name", "description"],

##Multiple models
Here's a general idea of how the models could look like with their password fields a
nd the places where they are used:

from fastapi import FastAPI
from pydantic import BaseModel, EmailStr

app = FastAPI()


class UserIn(BaseModel):
    username: str
    password: str
    email: EmailStr
    full_name: str | None = None


class UserOut(BaseModel):
    username: str
    email: EmailStr
    full_name: str | None = None


class UserInDB(BaseModel):
    username: str
    hashed_password: str
    email: EmailStr
    full_name: str | None = None


def fake_password_hasher(raw_password: str):
    return "supersecret" + raw_password


def fake_save_user(user_in: UserIn):
    hashed_password = fake_password_hasher(user_in.password)
    user_in_db = UserInDB(**user_in.dict(), hashed_password=hashed_password)
    print("User saved! ..not really")
    return user_in_db


@app.post("/user/", response_model=UserOut)
async def create_user(user_in: UserIn):
    user_saved = fake_save_user(user_in)
    return user_saved
    
    
##Path Parameters and Numeric Validations
from typing import Annotated

from fastapi import FastAPI, Path, Query

app = FastAPI()


@app.get("/items/{item_id}")
async def read_items(
    item_id: Annotated[int, Path(title="The ID of the item to get")],
    q: Annotated[str | None, Query(alias="item-query")] = None,
):
    results = {"item_id": item_id}
    if q:
        results.update({"q": q})
    return results
    
Number validation 
item_id: Annotated[int, Path(title="The ID of the item to get", ge=1)], q: str

And you can also declare numeric validations:
    gt: greater than
    ge: greater than or equal
    lt: less than
    le: less than or equal

Query, Path, and other classes you will see later are subclasses of a common Param class.
All of them share the same parameters for additional validation and metadata you have seen.

When you import Query, Path and others from fastapi, they are actually functions.

That when called, return instances of classes of the same name.

So, you import Query, which is a function. And when you call it, it returns an instance of 
a class also named Query.

These functions are there (instead of just using the classes directly) so that your editor doesn't mark 
errors about their types.

That way you can use your normal editor and coding tools without having to add custom configurations 
to disregard those errors.

##Query Parameters and String Validations
async def read_items(q: Annotated[str | None, Query(max_length=50)] = None):
#REGEX
async def read_items(
    q: Annotated[
        str | None, Query(min_length=3, max_length=50, pattern="^fixedquery$")
    ] = None,
):
Before Pydantic version 2 and before FastAPI 0.100.0, the parameter was called regex instead of pattern, but it's now deprecated.

##Query Default 
async def read_items(q: Annotated[str, Query(min_length=3)] = "fixedquery"):

So, when you need to declare a value as required while using Query, you can simply not declare
a default value:

async def read_items(q: Annotated[str, Query(min_length=3)]):

##Required, can be None
You can declare that a parameter can accept None, but that it's still required. 
This would force clients to send a value, even if the value is None.

To do that, you can declare that None is a valid type but simply do not declare a default value:

async def read_items(q: Annotated[str | None, Query(min_length=3)]):

##Query parameter list / multiple values
When you define a query parameter explicitly with Query you can also declare it to receive a list of 
values, or said in another way, to receive multiple values.

async def read_items(q: Annotated[list[str] | None, Query()] = None):

Then, with a URL like:

http://localhost:8000/items/?q=foo&q=bar

you would receive the multiple q query parameters' values (foo and bar) in a Python list 
inside your path operation function, in the function parameter q.

So, the response to that URL would be:

{
  "q": [
    "foo",
    "bar"
  ]
}

Query parameter list / multiple values with defaults
async def read_items(q: Annotated[list[str], Query()] = ["foo", "bar"]):

If you go to:

http://localhost:8000/items/

the default of q will be: ["foo", "bar"] and your response will be:

{
  "q": [
    "foo",
    "bar"
  ]
}

You can also use list directly instead of list[str]:
async def read_items(q: Annotated[list, Query()] = []):

##More Metadata 
async def read_items(
    q: Annotated[str | None, Query(title="Query string", min_length=3)] = None,
):
##Alias parameters

Imagine that you want the parameter to be item-query.

Like in:

http://127.0.0.1:8000/items/?item-query=foobaritems

But item-query is not a valid Python variable name.
Then you can declare an alias, and that alias is what will be used to find the parameter value:

async def read_items(q: Annotated[str | None, Query(alias="item-query")] = None):

##Deprecating parameters and example of all metadata 
from typing import Annotated

from fastapi import FastAPI, Query

app = FastAPI()


@app.get("/items/")
async def read_items(
    q: Annotated[
        str | None,   # default type 
        Query(
            alias="item-query",
            title="Query string",
            description="Query string for the items to search in the database that have a good match",
            min_length=3,
            max_length=50,
            pattern="^fixedquery$",
            deprecated=True,
        ),
    ] = None,
):
    results = {"items": [{"item_id": "Foo"}, {"item_id": "Bar"}]}
    if q:
        results.update({"q": q})
    return results
    
To exclude a query parameter from the generated OpenAPI schema

async def read_items(
    hidden_query: Annotated[str | None, Query(include_in_schema=False)] = None,
):

Generic validations and metadata:
    alias
    title
    description
    deprecated

Validations specific for strings:
    min_length
    max_length
    pattern

##Query Parameters with a Pydantic Model

from typing import Annotated, Literal

from fastapi import FastAPI, Query
from pydantic import BaseModel, Field

app = FastAPI()


class FilterParams(BaseModel):
    limit: int = Field(100, gt=0, le=100)
    offset: int = Field(0, ge=0)
    order_by: Literal["created_at", "updated_at"] = "created_at"
    tags: list[str] = []


@app.get("/items/")
async def read_items(filter_query: Annotated[FilterParams, Query()]):
    return filter_query
    
In some special use cases (probably not very common), you might want to restrict 
the query parameters that you want to receive.

You can use Pydantic's model configuration to forbid any extra fields:

class FilterParams(BaseModel):
    model_config = {"extra": "forbid"}

    limit: int = Field(100, gt=0, le=100)
    offset: int = Field(0, ge=0)
    order_by: Literal["created_at", "updated_at"] = "created_at"
    tags: list[str] = []

For example, if the client tries to send a tool query parameter with a value of plumbus, like:

https://example.com/items/?limit=10&tool=plumbus

They will receive an error response telling them that the query parameter tool is not allowed:
{
    "detail": [
        {
            "type": "extra_forbidden",
            "loc": ["query", "tool"],
            "msg": "Extra inputs are not permitted",
            "input": "plumbus"
        }
    ]
}

##Body - Multiple Parameters
First, of course, you can mix Path, Query and request body parameter declarations freely 
and FastAPI will know what to do.

And you can also declare body parameters as optional, by setting the default to None:
Python 3.10+

from typing import Annotated

from fastapi import FastAPI, Path
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None


@app.put("/items/{item_id}")
async def update_item(
    item_id: Annotated[int, Path(title="The ID of the item to get", ge=0, le=1000)],
    q: str | None = None,
    item: Item | None = None,
):
    results = {"item_id": item_id}
    if q:
        results.update({"q": q})
    if item:
        results.update({"item": item})
    return results


In the previous example, the path operations would expect a JSON body with the attributes 
of an Item, like:

{
    "name": "Foo",
    "description": "The pretender",
    "price": 42.0,
    "tax": 3.2
}

But you can also declare multiple body parameters, e.g. item and user:


from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None


class User(BaseModel):
    username: str
    full_name: str | None = None


@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Item, user: User):
    results = {"item_id": item_id, "item": item, "user": user}
    return results

In this case, FastAPI will notice that there is more than one body parameter in the function 
(there are two parameters that are Pydantic models).

So, it will then use the parameter names as keys (field names) in the body, and expect a body like:

{
    "item": {
        "name": "Foo",
        "description": "The pretender",
        "price": 42.0,
        "tax": 3.2
    },
    "user": {
        "username": "dave",
        "full_name": "Dave Grohl"
    }
}


FastAPI will do the automatic conversion from the request, 
so that the parameter item receives its specific content and the same for user.

It will perform the validation of the compound data, and will document it like that 
for the OpenAPI schema and automatic docs.


The same way there is a Query and Path to define extra data for query and path parameters, 
FastAPI provides an equivalent Body.

For example, extending the previous model, you could decide that you want to have another 
key importance in the same body, besides the item and user.

If you declare it as is, because it is a singular value, FastAPI will assume that it is a query parameter.

But you can instruct FastAPI to treat it as another body key using Body:


from typing import Annotated

from fastapi import Body, FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None


class User(BaseModel):
    username: str
    full_name: str | None = None


@app.put("/items/{item_id}")
async def update_item(
    item_id: int, item: Item, user: User, importance: Annotated[int, Body()]
):
    results = {"item_id": item_id, "item": item, "user": user, "importance": importance}
    return results


In this case, FastAPI will expect a body like:
{
    "item": {
        "name": "Foo",
        "description": "The pretender",
        "price": 42.0,
        "tax": 3.2
    },
    "user": {
        "username": "dave",
        "full_name": "Dave Grohl"
    },
    "importance": 5
}

Again, it will convert the data types, validate, document, etc.


Of course, you can also declare additional query parameters whenever you need, 
additional to any body parameters.

As, by default, singular values are interpreted as query parameters, 
you don't have to explicitly add a Query, you can just do:

q: Union[str, None] = None

Or in Python 3.10 and above:

q: str | None = None

For example:
@app.put("/items/{item_id}")
async def update_item(
    *,
    item_id: int,
    item: Item,
    user: User,
    importance: Annotated[int, Body(gt=0)],
    q: str | None = None,
):
    results = {"item_id": item_id, "item": item, "user": user, "importance": importance}
    if q:
        results.update({"q": q})
    return results

Let's say you only have a single item body parameter from a Pydantic model Item.

By default, FastAPI will then expect its body directly.

But if you want it to expect a JSON with a key item and inside of it the model contents,
 as it does when you declare extra body parameters, you can use the special Body parameter embed:

item: Item = Body(embed=True)

async def update_item(item_id: int, item: Annotated[Item, Body(embed=True)]):

In this case FastAPI will expect a body like:

{
    "item": {
        "name": "Foo",
        "description": "The pretender",
        "price": 42.0,
        "tax": 3.2
    }
}

instead of:

{
    "name": "Foo",
    "description": "The pretender",
    "price": 42.0,
    "tax": 3.2
}

##Body - Fields
The same way you can declare additional validation and metadata in path operation function parameters 
with Query, Path and Body, you can declare validation and metadata inside of Pydantic models 
using Pydantic's Field.

from typing import Annotated

from fastapi import Body, FastAPI
from pydantic import BaseModel, Field

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = Field(
        default=None, title="The description of the item", max_length=300
    )
    price: float = Field(gt=0, description="The price must be greater than zero")
    tax: float | None = None


@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Annotated[Item, Body(embed=True)]):
    results = {"item_id": item_id, "item": item}
    return results
    
##Body - Nested Models
With FastAPI, you can define, validate, document, and use arbitrarily deeply nested models (thanks to Pydantic).

List fields

You can define an attribute to be a subtype. For example, a Python list:

class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None
    tags: list = []
    
OR with type 
from typing import List, Union
 tags: List[str] = []
OR 
In Python 3.9 it would be:

my_list: list[str]

OR set 
 tags: set[str] = set()
 
OR with submodel 
 class Image(BaseModel):
    url: str
    name: str


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None
    tags: set[str] = set()
    image: Image | None = None
    
This would mean that FastAPI would expect a body similar to:

{
    "name": "Foo",
    "description": "The pretender",
    "price": 42.0,
    "tax": 3.2,
    "tags": ["rock", "metal", "bar"],
    "image": {
        "url": "http://example.com/baz.jpg",
        "name": "The Foo live"
    }
}

Again, doing just that declaration, with FastAPI you get:

    Editor support (completion, etc.), even for nested models
    Data conversion
    Data validation
    Automatic documentation

##Special types and validation�\
Apart from normal singular types like str, int, float, etc. you can use more complex singular types that inherit from str.
https://docs.pydantic.dev/latest/concepts/types/

from pydantic import BaseModel, HttpUrl
class Image(BaseModel):
    url: HttpUrl
    name: str

with list of submodels 
class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None
    tags: set[str] = set()
    images: list[Image] | None = None
    
@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Item):
    results = {"item_id": item_id, "item": item}
    return results
    
This will expect (convert, validate, document, etc.) a JSON body like:

{
    "name": "Foo",
    "description": "The pretender",
    "price": 42.0,
    "tax": 3.2,
    "tags": [
        "rock",
        "metal",
        "bar"
    ],
    "images": [
        {
            "url": "http://example.com/baz.jpg",
            "name": "The Foo live"
        },
        {
            "url": "http://example.com/dave.jpg",
            "name": "The Baz"
        }
    ]
}

##Bodies of pure lists
class Image(BaseModel):
    url: HttpUrl
    name: str

    
async def create_multiple_images(images: list[Image]):

Bodies of arbitrary dict
@app.post("/index-weights/")
async def create_index_weights(weights: dict[int, float]):
    return weights
    
##Declare Request Example Data
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "name": "Foo",
                    "description": "A very nice Item",
                    "price": 35.4,
                    "tax": 3.2,
                }
            ]
        }
    }


@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Item):
    results = {"item_id": item_id, "item": item}
    return results
    
##Extra Data Types
Up to now, you have been using common data types, like:
    int
    float
    str
    bool

But you can also use more complex data types.

And you will still have the same features as seen up to now:

    Great editor support.
    Data conversion from incoming requests.
    Data conversion for response data.
    Data validation.
    Automatic annotation and documentation.


Here are some of the additional data types you can use:

    UUID:
        A standard "Universally Unique Identifier", common as an ID in many databases and systems.
        In requests and responses will be represented as a str.
    datetime.datetime:
        A Python datetime.datetime.
        In requests and responses will be represented as a str in ISO 8601 format, like: 2008-09-15T15:53:00+05:00.
    datetime.date:
        Python datetime.date.
        In requests and responses will be represented as a str in ISO 8601 format, like: 2008-09-15.
    datetime.time:
        A Python datetime.time.
        In requests and responses will be represented as a str in ISO 8601 format, like: 14:23:55.003.
    datetime.timedelta:
        A Python datetime.timedelta.
        In requests and responses will be represented as a float of total seconds.
        Pydantic also allows representing it as a "ISO 8601 time diff encoding", see the docs for more info.
    frozenset:
        In requests and responses, treated the same as a set:
            In requests, a list will be read, eliminating duplicates and converting it to a set.
            In responses, the set will be converted to a list.
            The generated schema will specify that the set values are unique (using JSON Schema's uniqueItems).
    bytes:
        Standard Python bytes.
        In requests and responses will be treated as str.
        The generated schema will specify that it's a str with binary "format".
    Decimal:
        Standard Python Decimal.
        In requests and responses, handled the same as a float.
    You can check all the valid Pydantic data types here: Pydantic data types.



Here's an example path operation with parameters using some of the above types.

from datetime import datetime, time, timedelta
from typing import Annotated
from uuid import UUID

from fastapi import Body, FastAPI

app = FastAPI()


@app.put("/items/{item_id}")
async def read_items(
    item_id: UUID,
    start_datetime: Annotated[datetime, Body()],
    end_datetime: Annotated[datetime, Body()],
    process_after: Annotated[timedelta, Body()],
    repeat_at: Annotated[time | None, Body()] = None,
):
    start_process = start_datetime + process_after
    duration = end_datetime - start_process
    return {
        "item_id": item_id,
        "start_datetime": start_datetime,
        "end_datetime": end_datetime,
        "process_after": process_after,
        "repeat_at": repeat_at,
        "start_process": start_process,
        "duration": duration,
    }


Note that the parameters inside the function have their natural data type, and you can, 
for example, perform normal date manipulations, like:


from datetime import datetime, time, timedelta
from typing import Annotated
from uuid import UUID

from fastapi import Body, FastAPI

app = FastAPI()


@app.put("/items/{item_id}")
async def read_items(
    item_id: UUID,
    start_datetime: Annotated[datetime, Body()],
    end_datetime: Annotated[datetime, Body()],
    process_after: Annotated[timedelta, Body()],
    repeat_at: Annotated[time | None, Body()] = None,
):
    start_process = start_datetime + process_after
    duration = end_datetime - start_process
    return {
        "item_id": item_id,
        "start_datetime": start_datetime,
        "end_datetime": end_datetime,
        "process_after": process_after,
        "repeat_at": repeat_at,
        "start_process": start_process,
        "duration": duration,
    }
    
##Cookie Parameters

from typing import Annotated

from fastapi import Cookie, FastAPI

app = FastAPI()


@app.get("/items/")
async def read_items(ads_id: Annotated[str | None, Cookie()] = None):
    return {"ads_id": ads_id}
    
    
##Header Parameters

from typing import Annotated

from fastapi import FastAPI, Header

app = FastAPI()


@app.get("/items/")
async def read_items(user_agent: Annotated[str | None, Header()] = None):
    return {"User-Agent": user_agent}
    
##Headers With models 
from typing import Annotated

from fastapi import FastAPI, Header
from pydantic import BaseModel

app = FastAPI()


class CommonHeaders(BaseModel):
    host: str
    save_data: bool
    if_modified_since: str | None = None
    traceparent: str | None = None
    x_tag: list[str] = []


@app.get("/items/")
async def read_items(headers: Annotated[CommonHeaders, Header()]):
    return headers
    
    
##Response Status Code
The same way you can specify a response model, you can also declare the HTTP status code used 
for the response with the parameter status_code in any of the path operations:

    @app.get()
    @app.post()
    @app.put()
    @app.delete()
    etc.


from fastapi import FastAPI

app = FastAPI()


@app.post("/items/", status_code=201)
async def create_item(name: str):
    return {"name": name}
    
Notice that status_code is a parameter of the "decorator" method (get, post, etc). 
Not of your path operation function, like all the parameters and body.

##Form Data

To use forms, first install python-multipart.

Make sure you create a virtual environment, activate it, and then install it, for example:

$ pip install python-multipart

from typing import Annotated

from fastapi import FastAPI, Form

app = FastAPI()


@app.post("/login/")
async def login(username: Annotated[str, Form()], password: Annotated[str, Form()]):
    return {"username": username}
    
    
OR with Model 


from typing import Annotated

from fastapi import FastAPI, Form
from pydantic import BaseModel

app = FastAPI()


class FormData(BaseModel):
    username: str
    password: str


@app.post("/login/")
async def login(data: Annotated[FormData, Form()]):
    return data
    
##Request files 
from typing import Annotated

from fastapi import FastAPI, File, UploadFile

app = FastAPI()


@app.post("/files/")
async def create_file(file: Annotated[bytes, File()]):
    return {"file_size": len(file)}


@app.post("/uploadfile/")
async def create_upload_file(file: UploadFile):
    return {"filename": file.filename}
    
    
File is a class that inherits directly from Form.

But remember that when you import Query, Path, File and others from fastapi, 
those are actually functions that return special classes.


To declare File bodies, you need to use File, because otherwise the parameters would be interpreted 
as query parameters or body (JSON) parameters.


The files will be uploaded as "form data".

If you declare the type of your path operation function parameter as bytes, 
FastAPI will read the file for you and you will receive the contents as bytes.

Keep in mind that this means that the whole contents will be stored in memory. 
This will work well for small files.

But there are several cases in which you might benefit from using UploadFile.

Using UploadFile has several advantages over bytes:
    You don't have to use File() in the default value of the parameter.
    It uses a "spooled" file:
        A file stored in memory up to a maximum size limit, and after passing this limit it will be stored in disk.
    This means that it will work well for large files like images, videos, large binaries, etc. without consuming all the memory.
    You can get metadata from the uploaded file.
    It has a file-like async interface.
    It exposes an actual Python SpooledTemporaryFile object that you can pass directly to other libraries that expect a file-like object.


UploadFile has the following attributes:
    filename: A str with the original file name that was uploaded (e.g. myimage.jpg).
    content_type: A str with the content type (MIME type / media type) (e.g. image/jpeg).
    file: A SpooledTemporaryFile (a file-like object). This is the actual Python file object that you can pass directly to other functions or libraries that expect a "file-like" object.

UploadFile has the following async methods. 
They all call the corresponding file methods underneath (using the internal SpooledTemporaryFile).

    write(data): Writes data (str or bytes) to the file.
    read(size): Reads size (int) bytes/characters of the file.
    seek(offset): Goes to the byte position offset (int) in the file.
        E.g., await myfile.seek(0) would go to the start of the file.
        This is especially useful if you run await myfile.read() once and then need to read the contents again.
    close(): Closes the file.

As all these methods are async methods, you need to "await" them.

For example, inside of an async path operation function you can get the contents with:

contents = await myfile.read()

If you are inside of a normal def path operation function, you can access the UploadFile.file directly, for example:

contents = myfile.file.read()

You can define files and form fields at the same time using File and Form.

from typing import Annotated

from fastapi import FastAPI, File, Form, UploadFile

app = FastAPI()


@app.post("/files/")
async def create_file(
    file: Annotated[bytes, File()],
    fileb: Annotated[UploadFile, File()],
    token: Annotated[str, Form()],
):
    return {
        "file_size": len(file),
        "token": token,
        "fileb_content_type": fileb.content_type,
    }

##Handling Errors
There are many situations in which you need to notify an error to a client that is using your API.

This client could be a browser with a frontend, a code from someone else, an IoT device, etc.

You could need to tell the client that:
    The client doesn't have enough privileges for that operation.
    The client doesn't have access to that resource.
    The item the client was trying to access doesn't exist.
    etc.

In these cases, you would normally return an HTTP status code in the range of 400 (from 400 to 499).

This is similar to the 200 HTTP status codes (from 200 to 299). 
Those "200" status codes mean that somehow there was a "success" in the request.

The status codes in the 400 range mean that there was an error from the client.

##Errors Use HTTPException

To return HTTP responses with errors to the client you use HTTPException.


from fastapi import FastAPI, HTTPException

app = FastAPI()

items = {"foo": "The Foo Wrestlers"}


@app.get("/items/{item_id}")
async def read_item(item_id: str):
    if item_id not in items:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"item": items[item_id]}

##Body - Updates -Update replacing with PUT

To update an item you can use the HTTP PUT operation.

You can use the jsonable_encoder to convert the input data to data that can be stored as JSON (e.g. with a NoSQL database). For example, converting datetime to str.
Python 3.10+

from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str | None = None
    description: str | None = None
    price: float | None = None
    tax: float = 10.5
    tags: list[str] = []


items = {
    "foo": {"name": "Foo", "price": 50.2},
    "bar": {"name": "Bar", "description": "The bartenders", "price": 62, "tax": 20.2},
    "baz": {"name": "Baz", "description": None, "price": 50.2, "tax": 10.5, "tags": []},
}


@app.get("/items/{item_id}", response_model=Item)
async def read_item(item_id: str):
    return items[item_id]


@app.put("/items/{item_id}", response_model=Item)
async def update_item(item_id: str, item: Item):
    update_item_encoded = jsonable_encoder(item)
    items[item_id] = update_item_encoded
    return update_item_encoded


PUT is used to receive data that should replace the existing data.

Warning about replacing

That means that if you want to update the item bar using PUT with a body containing:

{
    "name": "Barz",
    "price": 3,
    "description": None,
}

because it doesn't include the already stored attribute "tax": 20.2, 
the input model would take the default value of "tax": 10.5.

And the data would be saved with that "new" tax of 10.5.

##Middleware

You can add middleware to FastAPI applications.

A "middleware" is a function that works with every request before it is processed 
by any specific path operation. And also with every response before returning it.

    It takes each request that comes to your application.
    It can then do something to that request or run any needed code.
    Then it passes the request to be processed by the rest of the application (by some path operation).
    It then takes the response generated by the application (by some path operation).
    It can do something to that response or run any needed code.
    Then it returns the response.


If you have dependencies with yield, the exit code will run after the middleware.

If there were any background tasks (documented later), they will run after all the middleware.


To create a middleware you use the decorator @app.middleware("http") on top of a function.

The middleware function receives:
    The request.
    A function call_next that will receive the request as a parameter.
        This function will pass the request to the corresponding path operation.
        Then it returns the response generated by the corresponding path operation.
    You can then further modify the response before returning it.



import time

from fastapi import FastAPI, Request

app = FastAPI()


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.perf_counter()
    response = await call_next(request)
    process_time = time.perf_counter() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

##Dependency injection - Classes as Dependencies


from typing import Annotated

from fastapi import Depends, FastAPI

app = FastAPI()


async def common_parameters(q: str | None = None, skip: int = 0, limit: int = 100):
    return {"q": q, "skip": skip, "limit": limit}


@app.get("/items/")
async def read_items(commons: Annotated[dict, Depends(common_parameters)]): #DI 
    return commons


@app.get("/users/")
async def read_users(commons: Annotated[dict, Depends(common_parameters)]):
    return commons

OR Use Classes as dependencies

from typing import Annotated

from fastapi import Depends, FastAPI

app = FastAPI()


fake_items_db = [{"item_name": "Foo"}, {"item_name": "Bar"}, {"item_name": "Baz"}]


class CommonQueryParams:
    def __init__(self, q: str | None = None, skip: int = 0, limit: int = 100):
        self.q = q
        self.skip = skip
        self.limit = limit


@app.get("/items/")
async def read_items(commons: Annotated[CommonQueryParams, Depends(CommonQueryParams)]):
#OR 
#async def read_items(commons: Annotated[Any, Depends(CommonQueryParams)]):
#OR 
#commons: Annotated[CommonQueryParams, Depends()]
    response = {}
    if commons.q:
        response.update({"q": commons.q})
    items = fake_items_db[commons.skip : commons.skip + commons.limit]
    response.update({"items": items})
    return response

Pay attention to the __init__ method used to create the instance of the class

In both cases, it will have:
    An optional q query parameter that is a str.
    A skip query parameter that is an int, with a default of 0.
    A limit query parameter that is an int, with a default of 100.
    
##Subdependencies 
from typing import Annotated

from fastapi import Cookie, Depends, FastAPI

app = FastAPI()


def query_extractor(q: str | None = None):
    return q


def query_or_cookie_extractor(
    q: Annotated[str, Depends(query_extractor)],
    last_query: Annotated[str | None, Cookie()] = None,
):
    if not q:
        return last_query
    return q


@app.get("/items/")
async def read_query(
    query_or_default: Annotated[str, Depends(query_or_cookie_extractor)],
):
    return {"q_or_cookie": query_or_default}
    
    
##Dependencies in path operation decorators
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException

app = FastAPI()


async def verify_token(x_token: Annotated[str, Header()]):
    if x_token != "fake-super-secret-token":
        raise HTTPException(status_code=400, detail="X-Token header invalid")


async def verify_key(x_key: Annotated[str, Header()]):
    if x_key != "fake-super-secret-key":
        raise HTTPException(status_code=400, detail="X-Key header invalid")
    return x_key


@app.get("/items/", dependencies=[Depends(verify_token), Depends(verify_key)])
async def read_items():
    return [{"item": "Foo"}, {"item": "Bar"}]
    
##Global Dependencies
For some types of applications you might want to add dependencies to the whole application.

Similar to the way you can add dependencies to the path operation decorators, 
you can add them to the FastAPI application.

In that case, they will be applied to all the path operations in the application:


from fastapi import Depends, FastAPI, Header, HTTPException
from typing_extensions import Annotated


async def verify_token(x_token: Annotated[str, Header()]):
    if x_token != "fake-super-secret-token":
        raise HTTPException(status_code=400, detail="X-Token header invalid")


async def verify_key(x_key: Annotated[str, Header()]):
    if x_key != "fake-super-secret-key":
        raise HTTPException(status_code=400, detail="X-Key header invalid")
    return x_key


app = FastAPI(dependencies=[Depends(verify_token), Depends(verify_key)])


@app.get("/items/")
async def read_items():
    return [{"item": "Portal Gun"}, {"item": "Plumbus"}]


@app.get("/users/")
async def read_users():
    return [{"username": "Rick"}, {"username": "Morty"}]

##Dependencies with yield

FastAPI supports dependencies that do some extra steps after finishing.

To do this, use yield instead of return, and write the extra steps (code) after.

async def get_db():
    db = DBSession()
    try:
        yield db
    finally:
        db.close()
        
#Examples 

from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException

app = FastAPI()


data = {
    "plumbus": {"description": "Freshly pickled plumbus", "owner": "Morty"},
    "portal-gun": {"description": "Gun to create portals", "owner": "Rick"},
}


class OwnerError(Exception):
    pass


def get_username():
    try:
        yield "Rick"
    except OwnerError as e:
        raise HTTPException(status_code=400, detail=f"Owner error: {e}")


@app.get("/items/{item_id}")
def get_item(item_id: str, username: Annotated[str, Depends(get_username)]):
    if item_id not in data:
        raise HTTPException(status_code=404, detail="Item not found")
    item = data[item_id]
    if item["owner"] != username:
        raise OwnerError(username)
    return item
    

    
##SQL (Relational) Databases - SQLModel
SQLModel is built on top of SQLAlchemy and Pydantic. 

pip install sqlmodel

#Code 
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Query
from sqlmodel import Field, Session, SQLModel, create_engine, select


class Hero(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(index=True)
    age: int | None = Field(default=None, index=True)
    secret_name: str


sqlite_file_name = "database.db"
sqlite_url = f"sqlite:///{sqlite_file_name}"

connect_args = {"check_same_thread": False}
engine = create_engine(sqlite_url, connect_args=connect_args)


def create_db_and_tables():
    SQLModel.metadata.create_all(engine)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]

app = FastAPI()


@app.on_event("startup")
def on_startup():
    create_db_and_tables()


@app.post("/heroes/")
def create_hero(hero: Hero, session: SessionDep) -> Hero:
    session.add(hero)
    session.commit()
    session.refresh(hero)
    return hero


@app.get("/heroes/")
def read_heroes(
    session: SessionDep,
    offset: int = 0,
    limit: Annotated[int, Query(le=100)] = 100,
) -> list[Hero]:
    heroes = session.exec(select(Hero).offset(offset).limit(limit)).all()
    return heroes


@app.get("/heroes/{hero_id}")
def read_hero(hero_id: int, session: SessionDep) -> Hero:
    hero = session.get(Hero, hero_id)
    if not hero:
        raise HTTPException(status_code=404, detail="Hero not found")
    return hero


@app.delete("/heroes/{hero_id}")
def delete_hero(hero_id: int, session: SessionDep):
    hero = session.get(Hero, hero_id)
    if not hero:
        raise HTTPException(status_code=404, detail="Hero not found")
    session.delete(hero)
    session.commit()
    return {"ok": True}
    
    
There are a few differences:
    table=True tells SQLModel that this is a table model, it should represent a table in the SQL database, 
    it's not just a data model (as would be any other regular Pydantic class).

    Field(primary_key=True) tells SQLModel that the id is the primary key in the SQL database 
    (you can learn more about SQL primary keys in the SQLModel docs).

    By having the type as int | None, SQLModel will know that this column should be an INTEGER 
    in the SQL database and that it should be NULLABLE.

    Field(index=True) tells SQLModel that it should create a SQL index for this column, 
    that would allow faster lookups in the database when reading data filtered by this column.

    SQLModel will know that something declared as str will be a SQL column of type 
    TEXT (or VARCHAR, depending on the database).

    
In SQLModel, any model class that has table=True is a table model.

And any model class that doesn't have table=True is a data model, 
these ones are actually just Pydantic models (with a couple of small extra features). 

With SQLModel, we can use inheritance to avoid duplicating all the fields in all the cases.

from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Query
from sqlmodel import Field, Session, SQLModel, create_engine, select


class HeroBase(SQLModel):
    name: str = Field(index=True)
    age: int | None = Field(default=None, index=True)


class Hero(HeroBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    secret_name: str


class HeroPublic(HeroBase):
    id: int


class HeroCreate(HeroBase):
    secret_name: str


class HeroUpdate(HeroBase):
    name: str | None = None
    age: int | None = None
    secret_name: str | None = None


sqlite_file_name = "database.db"
sqlite_url = f"sqlite:///{sqlite_file_name}"

connect_args = {"check_same_thread": False}
engine = create_engine(sqlite_url, connect_args=connect_args)


def create_db_and_tables():
    SQLModel.metadata.create_all(engine)


def get_session():
    with Session(engine) as session:
        yield session


SessionDep = Annotated[Session, Depends(get_session)]
app = FastAPI()


@app.on_event("startup")
def on_startup():
    create_db_and_tables()


@app.post("/heroes/", response_model=HeroPublic)
def create_hero(hero: HeroCreate, session: SessionDep):
    db_hero = Hero.model_validate(hero)
    session.add(db_hero)
    session.commit()
    session.refresh(db_hero)
    return db_hero


@app.get("/heroes/", response_model=list[HeroPublic])
def read_heroes(
    session: SessionDep,
    offset: int = 0,
    limit: Annotated[int, Query(le=100)] = 100,
):
    heroes = session.exec(select(Hero).offset(offset).limit(limit)).all()
    return heroes


@app.get("/heroes/{hero_id}", response_model=HeroPublic)
def read_hero(hero_id: int, session: SessionDep):
    hero = session.get(Hero, hero_id)
    if not hero:
        raise HTTPException(status_code=404, detail="Hero not found")
    return hero


@app.patch("/heroes/{hero_id}", response_model=HeroPublic)
def update_hero(hero_id: int, hero: HeroUpdate, session: SessionDep):
    hero_db = session.get(Hero, hero_id)
    if not hero_db:
        raise HTTPException(status_code=404, detail="Hero not found")
    hero_data = hero.model_dump(exclude_unset=True)
    hero_db.sqlmodel_update(hero_data)
    session.add(hero_db)
    session.commit()
    session.refresh(hero_db)
    return hero_db


@app.delete("/heroes/{hero_id}")
def delete_hero(hero_id: int, session: SessionDep):
    hero = session.get(Hero, hero_id)
    if not hero:
        raise HTTPException(status_code=404, detail="Hero not found")
    session.delete(hero)
    session.commit()
    return {"ok": True}
    
##Bigger Applications - Multiple Files - APIRouter


.
+-- app                  # "app" is a Python package
�   +-- __init__.py      # this file makes "app" a "Python package"
�   +-- main.py          # "main" module, e.g. import app.main
�   +-- dependencies.py  # "dependencies" module, e.g. import app.dependencies
�   +-- routers          # "routers" is a "Python subpackage"
�   �   +-- __init__.py  # makes "routers" a "Python subpackage"
�   �   +-- items.py     # "items" submodule, e.g. import app.routers.items
�   �   +-- users.py     # "users" submodule, e.g. import app.routers.users
�   +-- internal         # "internal" is a "Python subpackage"
�       +-- __init__.py  # makes "internal" a "Python subpackage"
�       +-- admin.py     # "admin" submodule, e.g. import app.internal.admin


#app/main.py

from fastapi import Depends, FastAPI

from .dependencies import get_query_token, get_token_header
from .internal import admin
from .routers import items, users

app = FastAPI(dependencies=[Depends(get_query_token)])


app.include_router(users.router)
app.include_router(items.router)
app.include_router(
    admin.router,
    prefix="/admin",
    tags=["admin"],
    dependencies=[Depends(get_token_header)],
    responses={418: {"description": "I'm a teapot"}},
)


@app.get("/")
async def root():
    return {"message": "Hello Bigger Applications!"}
    
#app/internal/admin.py

from fastapi import APIRouter

router = APIRouter()


@router.post("/")
async def update_admin():
    return {"message": "Admin getting schwifty"}
    
    
The result is that in our app, each of the path operations from the admin module will have:
    The prefix /admin.
    The tag admin.
    The dependency get_token_header.
    The response 418. ??

#app/routers/items.py

from fastapi import APIRouter, Depends, HTTPException

from ..dependencies import get_token_header

router = APIRouter(
    prefix="/items",
    tags=["items"],
    dependencies=[Depends(get_token_header)],
    responses={404: {"description": "Not found"}},
)


fake_items_db = {"plumbus": {"name": "Plumbus"}, "gun": {"name": "Portal Gun"}}


@router.get("/")
async def read_items():
    return fake_items_db


@router.get("/{item_id}")
async def read_item(item_id: str):
    if item_id not in fake_items_db:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"name": fake_items_db[item_id]["name"], "item_id": item_id}


@router.put(
    "/{item_id}",
    tags=["custom"],
    responses={403: {"description": "Operation forbidden"}},
)
async def update_item(item_id: str):
    if item_id != "plumbus":
        raise HTTPException(
            status_code=403, detail="You can only update the item: plumbus"
        )
    return {"item_id": item_id, "name": "The great Plumbus"}
    
#app/dependencies.py

from typing import Annotated

from fastapi import Header, HTTPException


async def get_token_header(x_token: Annotated[str, Header()]):
    if x_token != "fake-super-secret-token":
        raise HTTPException(status_code=400, detail="X-Token header invalid")


async def get_query_token(token: str):
    if token != "jessica":
        raise HTTPException(status_code=400, detail="No Jessica token provided")
        
#app/routers/users.py
You can think of APIRouter as a "mini FastAPI" class.

from fastapi import APIRouter

router = APIRouter()


@router.get("/users/", tags=["users"])
async def read_users():
    return [{"username": "Rick"}, {"username": "Morty"}]


@router.get("/users/me", tags=["users"])
async def read_user_me():
    return {"username": "fakecurrentuser"}


@router.get("/users/{username}", tags=["users"])
async def read_user(username: str):
    return {"username": username}
    
    

##Static Files
You can serve static files automatically from a directory using StaticFiles.


from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")


##Testing
Thanks to Starlette, testing FastAPI applications is easy and enjoyable.

It is based on HTTPX, which in turn is designed based on Requests, so it's very familiar and intuitive.

With it, you can use pytest directly with FastAPI.
$ pip install httpx.


from fastapi import FastAPI
from fastapi.testclient import TestClient

app = FastAPI()


@app.get("/")
async def read_main():
    return {"msg": "Hello World"}


client = TestClient(app)


def test_read_main():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"msg": "Hello World"}


##Debugging
You can connect the debugger in your editor, for example with Visual Studio Code or PyCharm.


In your FastAPI application, import and run uvicorn directly:


import uvicorn
from fastapi import FastAPI

app = FastAPI()


@app.get("/")
def root():
    a = "a"
    b = "b" + a
    return {"hello world": b}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
    
python myapp.py

##Return a Response Directly

from datetime import datetime
from typing import Union

from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class Item(BaseModel):
    title: str
    timestamp: datetime
    description: Union[str, None] = None


app = FastAPI()


@app.put("/items/{id}")
def update_item(id: str, item: Item):
    json_compatible_item_data = jsonable_encoder(item)
    return JSONResponse(content=json_compatible_item_data)
    
##With Response Header 

from fastapi import FastAPI, Response

app = FastAPI()


@app.get("/headers-and-object/")
def get_headers(response: Response):
    response.headers["X-Cat-Dog"] = "alone in the world"
    return {"message": "Hello World"}
    

##Security

OAuth2
    OAuth2 is a specification that defines several ways to handle authentication and authorization.

    It is quite an extensive specification and covers several complex use cases.

    It includes ways to authenticate using a "third party".

    That's what all the systems with "login with Facebook, Google, Twitter, GitHub" use underneath.
    
OAuth 1
    There was an OAuth 1, which is very different from OAuth2, and more complex, 
    as it included direct specifications on how to encrypt the communication.

    It is not very popular or used nowadays.

    OAuth2 doesn't specify how to encrypt the communication, 
    it expects you to have your application served with HTTPS.

OpenID Connect
    OpenID Connect is another specification, based on OAuth2.

    It just extends OAuth2 specifying some things that are relatively ambiguous in OAuth2, 
    to try to make it more interoperable.

    For example, Google login uses OpenID Connect (which underneath uses OAuth2).

    But Facebook login doesn't support OpenID Connect. It has its own flavor of OAuth2.
    
OpenID (not "OpenID Connect")
    There was also an "OpenID" specification. That tried to solve the same thing as OpenID Connect, 
    but was not based on OAuth2.

    So, it was a complete additional system.

    It is not very popular or used nowadays.
    
OpenAPI
    OpenAPI (previously known as Swagger) is the open specification for building APIs 
    (now part of the Linux Foundation).

    FastAPI is based on OpenAPI.

    That's what makes it possible to have multiple automatic interactive documentation interfaces, code generation, etc.

    OpenAPI has a way to define multiple security "schemes".

    By using them, you can take advantage of all these standard-based tools, 
    including these interactive documentation systems.

    OpenAPI defines the following security schemes:

        apiKey: an application specific key that can come from:
            A query parameter.
            A header.
            A cookie.
        http: standard HTTP authentication systems, including:
            bearer: a header Authorization with a value of Bearer plus a token. 
            This is inherited from OAuth2.
            HTTP Basic authentication.
            HTTP Digest, etc.
        oauth2: all the OAuth2 ways to handle security (called "flows").
            Several of these flows are appropriate for building an OAuth 2.0 authentication provider 
            (like Google, Facebook, Twitter, GitHub, etc):
                implicit
                clientCredentials
                authorizationCode
            But there is one specific "flow" that can be perfectly used for handling authentication 
            in the same application directly:
                password: some next chapters will cover examples of this.
        openIdConnect: has a way to define how to discover OAuth2 authentication data automatically.
            This automatic discovery is what is defined in the OpenID Connect specification.

Integrating other authentication/authorization providers like Google, Facebook, Twitter, GitHub, etc. 
is also possible and relatively easy.

The most complex problem is building an authentication/authorization provider like those, 
but FastAPI gives you the tools to do it easily, while doing the heavy lifting for you.


##The password flow
The password "flow" is one of the ways ("flows") defined in OAuth2, to handle security and authentication.

OAuth2 was designed so that the backend or API could be independent of the server 
that authenticates the user.

But in this case, the same FastAPI application will handle the API and the authentication.

So, let's review it from that simplified point of view:
    The user types the username and password in the frontend, and hits Enter.
    The frontend (running in the user's browser) sends that username and password 
        to a specific URL in our API (declared with tokenUrl="token").
    The API checks that username and password, and responds with a "token" 
        A "token" is just a string with some content that we can use later to verify this user.
        Normally, a token is set to expire after some time.
            So, the user will have to log in again at some point later.
            And if the token is stolen, the risk is less. 
            It is not like a permanent key that will work forever (in most of the cases).
    The frontend stores that token temporarily somewhere.
    The user clicks in the frontend to go to another section of the frontend web app.
    The frontend needs to fetch some more data from the API.
        But it needs authentication for that specific endpoint.
        So, to authenticate with our API, it sends a header Authorization with a value of 
        Bearer plus the token.
        If the token contains foobar, the content of the Authorization header would be: 
            Bearer foobar.


FastAPI provides several tools, at different levels of abstraction, to implement these security features.

In this example we are going to use OAuth2, with the Password flow, using a Bearer token.
We do that using the OAuth2PasswordBearer class.

A "bearer" token is not the only option.

When we create an instance of the OAuth2PasswordBearer class we pass in the tokenUrl parameter. 
This parameter contains the URL that the client (the frontend running in the user's browser) 
will use to send the username and password in order to get a token.

It will go and look in the request for that Authorization header, 
check if the value is Bearer plus some token, and will return the token as a str.

If it doesn't see an Authorization header, or the value doesn't have a Bearer token, 
it will respond with a 401 status code error (UNAUTHORIZED) directly.

You don't even have to check if the token exists to return an error. 
You can be sure that if your function is executed, it will have a str in that token.

In generated doc 
You already have a shiny new "Authorize" button.

And your path operation has a little lock in the top-right corner that you can click.

And if you click it, you have a little authorization form to type a username and password 
(and other optional fields

 
from typing import Annotated

from fastapi import Depends, FastAPI
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel

app = FastAPI()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token") # not implemented tokenUrl  as of now 


class User(BaseModel):
    username: str
    email: str | None = None
    full_name: str | None = None
    disabled: bool | None = None


def fake_decode_token(token):
    return User(
        username=token + "fakedecoded", email="john@example.com", full_name="John Doe"
    )


async def get_current_user(token: Annotated[str, Depends(oauth2_scheme)]):
    user = fake_decode_token(token)
    return user


@app.get("/users/me")
async def read_users_me(current_user: Annotated[User, Depends(get_current_user)]):
    return current_user


##Get the username and password�

We are going to use FastAPI security utilities to get the username and password.

OAuth2 specifies that when using the "password flow" (that we are using) the client/user 
must send a username and password fields as form data.

And the spec says that the fields have to be named like that. So user-name or email wouldn't work.

The spec also states that the username and password must be sent as form data (so, no JSON here).

##Understanding scope

The spec also says that the client can send another form field "scope".

The form field name is scope (in singular), but it is actually a long string 
with "scopes" separated by spaces.

Each "scope" is just a string (without spaces).

They are normally used to declare specific security permissions, for example:
    users:read or users:write are common examples.
    instagram_basic is used by Facebook / Instagram.
    https://www.googleapis.com/auth/drive is used by Google.

In OAuth2 a "scope" is just a string that declares a specific permission required.

It doesn't matter if it has other characters like : or if it is a URL.

Those details are implementation specific.

For OAuth2 they are just strings.


from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel

fake_users_db = {
    "johndoe": {
        "username": "johndoe",
        "full_name": "John Doe",
        "email": "johndoe@example.com",
        "hashed_password": "fakehashedsecret",
        "disabled": False,
    },
    "alice": {
        "username": "alice",
        "full_name": "Alice Wonderson",
        "email": "alice@example.com",
        "hashed_password": "fakehashedsecret2",
        "disabled": True,
    },
}

app = FastAPI()


def fake_hash_password(password: str):
    return "fakehashed" + password


oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


class User(BaseModel):
    username: str
    email: str | None = None
    full_name: str | None = None
    disabled: bool | None = None


class UserInDB(User):
    hashed_password: str


def get_user(db, username: str):
    if username in db:
        user_dict = db[username]
        return UserInDB(**user_dict)


def fake_decode_token(token):
    # This doesn't provide any security at all
    # Check the next version
    user = get_user(fake_users_db, token)
    return user


async def get_current_user(token: Annotated[str, Depends(oauth2_scheme)]):
    user = fake_decode_token(token)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


async def get_current_active_user(
    current_user: Annotated[User, Depends(get_current_user)],
):
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user


@app.post("/token")  #tokenUrl now implemented 
async def login(form_data: Annotated[OAuth2PasswordRequestForm, Depends()]):
    user_dict = fake_users_db.get(form_data.username)
    if not user_dict:
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    user = UserInDB(**user_dict)
    hashed_password = fake_hash_password(form_data.password)
    if not hashed_password == user.hashed_password:
        raise HTTPException(status_code=400, detail="Incorrect username or password")

    return {"access_token": user.username, "token_type": "bearer"}


@app.get("/users/me")
async def read_users_me(
    current_user: Annotated[User, Depends(get_current_active_user)],
):
    return current_user


OAuth2PasswordRequestForm is a class dependency that declares a form body with:
    The username.
    The password.
    An optional scope field as a big string, composed of strings separated by spaces.
    An optional grant_type.

        The OAuth2 spec actually requires a field grant_type with a fixed value of password, 
        but OAuth2PasswordRequestForm doesn't enforce it.

        If you need to enforce it, use OAuth2PasswordRequestFormStrict instead of OAuth2PasswordRequestForm.

    An optional client_id (we don't need it for our example).
    An optional client_secret (we don't need it for our example).


The OAuth2PasswordRequestForm is not a special class for FastAPI as is OAuth2PasswordBearer.

OAuth2PasswordBearer makes FastAPI know that it is a security scheme. 
So it is added that way to OpenAPI.

But OAuth2PasswordRequestForm is just a class dependency that you could have written yourself, 
or you could have declared Form parameters directly.

But as it's a common use case, it is provided by FastAPI directly, just to make it easier.


Open the interactive docs: http://127.0.0.1:8000/docs.

Click the "Authorize" button.

Use the credentials:

User: johndoe

Password: secret

Now use the operation GET with the path /users/me.

You will get your user's data, like:

{
  "username": "johndoe",
  "email": "johndoe@example.com",
  "full_name": "John Doe",
  "disabled": false,
  "hashed_password": "fakehashedsecret"
}


Now try with an inactive user, authenticate with:

User: alice
Password: secret2

And try to use the operation GET with the path /users/me.

You will get an "Inactive user" error, like:

{
  "detail": "Inactive user"
}

##OAuth2 with Password (and hashing), Bearer with JWT tokens

JWT means "JSON Web Tokens".

It's a standard to codify a JSON object in a long dense string without spaces. It looks like this:

eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c

It is not encrypted, so, anyone could recover the information from the contents.

But it's signed. So, when you receive a token that you emitted, you can verify that you actually emitted it.

That way, you can create a token with an expiration of, let's say, 1 week. 
And then when the user comes back the next day with the token, you know that user is still logged 
in to your system.

After a week, the token will be expired and the user will not be authorized and will have to sign in again to 
get a new token. And if the user (or a third party) tried to modify the token to change the expiration, 
you would be able to discover it, because the signatures would not match.

If you want to play with JWT tokens and see how they work, check https://jwt.io.

We need to install PyJWT to generate and verify the JWT tokens in Python.


pip install pyjwt

If you are planning to use digital signature algorithms like RSA or ECDSA, 
you should install the cryptography library dependency pyjwt[crypto].

##Password hashing
"Hashing" means converting some content (a password in this case) into a sequence of bytes (
just a string) that looks like gibberish.

Whenever you pass exactly the same content (exactly the same password) you get exactly the same gibberish.

But you cannot convert from the gibberish back to the password.

If your database is stolen, the thief won't have your users' plaintext passwords, only the hashes.

So, the thief won't be able to try to use that password in another system (as many users 
use the same password everywhere, this would be dangerous).


PassLib is a great Python package to handle password hashes.

It supports many secure hashing algorithms and utilities to work with them.

The recommended algorithm is "Bcrypt".

pip install "passlib[bcrypt]"


Tip

With passlib, you could even configure it to be able to read passwords created by Django, 
a Flask security plug-in or many others.

So, you would be able to, for example, share the same data from a Django application in a database 
with a FastAPI application. Or gradually migrate a Django application using the same database.

And your users would be able to login from your Django app or from your FastAPI app, 
at the same time.




Import the tools we need from passlib.
Create a PassLib "context". This is what will be used to hash and verify passwords.

The PassLib context also has functionality to use different hashing algorithms, 
including deprecated old ones only to allow verifying them, etc.

For example, you could use it to read and verify passwords generated by another system 
(like Django) but hash any new passwords with a different algorithm like Bcrypt.

And be compatible with all of them at the same time.

Create a utility function to hash a password coming from the user.

And another utility to verify if a received password matches the hash stored.

And another one to authenticate and return a user.

To generate a secure random secret key use the command:

openssl rand -hex 32
09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7

#Code 

from datetime import datetime, timedelta, timezone
from typing import Annotated

import jwt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jwt.exceptions import InvalidTokenError
from passlib.context import CryptContext
from pydantic import BaseModel

# to get a string like this run:
# openssl rand -hex 32
SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30


fake_users_db = {
    "johndoe": {
        "username": "johndoe",
        "full_name": "John Doe",
        "email": "johndoe@example.com",
        "hashed_password": "$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW",
        "disabled": False,
    }
}


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: str | None = None


class User(BaseModel):
    username: str
    email: str | None = None
    full_name: str | None = None
    disabled: bool | None = None


class UserInDB(User):
    hashed_password: str


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

app = FastAPI()


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    return pwd_context.hash(password)


def get_user(db, username: str):
    if username in db:
        user_dict = db[username]
        return UserInDB(**user_dict)


def authenticate_user(fake_db, username: str, password: str):
    user = get_user(fake_db, username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


async def get_current_user(token: Annotated[str, Depends(oauth2_scheme)]):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except InvalidTokenError:
        raise credentials_exception
    user = get_user(fake_users_db, username=token_data.username)
    if user is None:
        raise credentials_exception
    return user


async def get_current_active_user(
    current_user: Annotated[User, Depends(get_current_user)],
):
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user


@app.post("/token")
async def login_for_access_token(
    form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
) -> Token:
    user = authenticate_user(fake_users_db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return Token(access_token=access_token, token_type="bearer")


@app.get("/users/me/", response_model=User)
async def read_users_me(
    current_user: Annotated[User, Depends(get_current_active_user)],
):
    return current_user


@app.get("/users/me/items/")
async def read_own_items(
    current_user: Annotated[User, Depends(get_current_active_user)],
):
    return [{"item_id": "Foo", "owner": current_user.username}]



If you check the new (fake) database fake_users_db, you will see how the hashed password looks like now: "$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW".


##Technical details about the JWT "subject" sub

The JWT specification says that there's a key sub, with the subject of the token.

It's optional to use it, but that's where you would put the user's identification, so we are using it here.

JWT might be used for other things apart from identifying a user and allowing them 
to perform operations directly on your API.

For example, you could identify a "car" or a "blog post".

Then you could add permissions about that entity, like "drive" (for the car) or "edit" (for the blog).

And then, you could give that JWT token to a user (or bot), and they could use it to perform those actions (
drive the car, or edit the blog post) without even needing to have an account, just 
with the JWT token your API generated for that.

Using these ideas, JWT can be used for way more sophisticated scenarios.

In those cases, several of those entities could have the same ID, let's say foo (a user foo, 
a car foo, and a blog post foo).

So, to avoid ID collisions, when creating the JWT token for the user, you could prefix the value 
of the sub key, e.g. with username:. So, in this example, the value of sub could have been: username:johndoe.

The important thing to keep in mind is that the sub key should have a unique identifier 
across the entire application, and it should be a string.

Check it

Run the server and go to the docs: http://127.0.0.1:8000/docs.

You'll see the user interface like:

Authorize the application the same way as before.

Using the credentials:

Username: johndoe Password: secret

Check

Notice that nowhere in the code is the plaintext password "secret", 
we only have the hashed version.
Call the endpoint /users/me/, you will get the response as:

{
  "username": "johndoe",
  "email": "johndoe@example.com",
  "full_name": "John Doe",
  "disabled": false
}

If you open the developer tools, you could see how the data sent only includes the token, the password is only sent in the first request to authenticate the user and get that access token, but not afterwards:



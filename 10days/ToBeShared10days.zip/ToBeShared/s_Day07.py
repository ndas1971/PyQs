###Introducing IPython and the Jupyter Notebook
JupyterLab also comes with a visual debugger that lets you interactively set 
breakpoints, step into functions, and inspect variables.
https://jupyterlab.readthedocs.io/en/stable/user/debugger.html
The debugger can be enabled by toggling the bug button 
on in the upper-right corner of the notebook(before Python3 (ipykernel)


So in the old days, there is just one Jupyter Notebook, 
and now with JupyterLab (and in the future), Notebook is just one of the core 
applications in JupyterLab (along with others like code Console, 
command-line Terminal, and a Text Editor).

    View Files, running kernels, Commands, Notebook Tools, 
    Open Tabs or Extension manager
    Run cells using, among other options, Ctrl+Enter
    Run single expression, line or highlighted text using menu options 
    or keyboard shortcuts
    Run code directly in a console using Shift+Enter
    Inspect variables, dataframes or plots quickly 
    and easily in a console without cluttering your notebook output.

    
JupyterLab
https://jupyterlab.readthedocs.io/en/latest/

pip install jupyterlab

Once installed, launch JupyterLab with:

jupyter lab --notebook-dir=E:/ --preferred-dir E:/Documents/Somewhere/Else

JupyterLab’s file navigation URLs adopts the nomenclature 
of the classic notebook; these URLs are /tree URLs:

http(s)://<server:port>/<lab-location>/lab/tree/path/to/notebook.ipynb

By default, the file browser will navigate to the folder containing 
the requested file. 
This behavior can be changed with the optional file-browser-path query parameter:

http(s)://<server:port>/<lab-location>/lab/tree/path/to/notebook.ipynb?file-browser-path=/

Entering the above URL will show the workspace root folder instead 
of the /path/to/ folder in the file browser.

#Linking Notebook Sections
To create an URL which will scroll to a specific heading in the notebook 
append a hash (#) followed by the heading text with spaces replaced 
by minus characters (-), for example:

/lab/tree/path/to/notebook.ipynb?#my-heading

To get a link for a specific heading, hover over it in a rendered markdown cell 
until you see a pilcrow mark (¶) which will contain the desired anchor link:


Jupyter Notebook
pip install notebook

https://github.com/voila-dashboards/voila
Voilà turns Jupyter notebooks into standalone web applications.
Unlike the usual HTML-converted notebooks, each user connecting to the Voilà 
tornado application gets a dedicated Jupyter kernel 
which can execute the callbacks to changes in Jupyter interactive widgets.

pip install voila

To render the bqplot example notebook as a standalone app, 
run voila bqplot.ipynb. 
To serve a directory of jupyter notebooks, run voila with no argument.



$ C:\Anaconda3\Scripts\activate aiml
$ jupyter notebook --notebook-dir='D:/Desktop/PPT/python/Jupyter/code'


#Step-1  , Run - Shift+Enter 
print("Hello world!")

#Step-2
2 + 2

#Step-3: access last result 
_ * 3

#step-4: execute shell command 
!dir

#step-5: Magic command 
#https://ipython.readthedocs.io/en/stable/interactive/magics.html
%lsmagic
Help on any magic , put ? or ??
%timeit?

Line magics apply to the current line and start with %, 
while cell magics apply to the entire cell and start with %%. 

    %lsmagic: Shows a list of all available magic commands.
    %history -n: Displays the last n commands with their line numbers.
    %time Time execution of a Python statement or expression.
        This function can be used both as a line and cell magic:
    %timeit (more control) Time execution of a Python statement or expression
    Usage, in line mode:
        %timeit [-n<N> -r<R> [-t|-c] -q -p<P> -o] statement
    or in cell mode:
        %%timeit [-n<N> -r<R> [-t|-c] -q -p<P> -o] setup_code code code…
        -n<N>: execute the given statement <N> times in a loop. 
        If <N> is not provided, <N> is determined so as to get sufficient accuracy.
        -r<R>: number of repeats <R>, each consisting of <N> loops, 
        and take the average result. Default: 7
        -p<P>: use a precision of <P> digits to display the timing result. Default: 3
        -q: Quiet, do not print result.
        -o: return a TimeitResult that can be stored in a variable to inspect
    %quickref: Provides a quick reference of common magic commands and their descriptions.
    %env: Displays a list of all environment variables.
    %load and %run: Load and execute external Python scripts, respectively.
    %debug: Activates the interactive debugger for error analysis. 
    %magic    Print information about the magic function system.
    Supported formats: -latex, -brief, -rest

    
    Example 
     
    In [1]: %alias_magic t timeit
    Created `%t` as an alias for `%timeit`.
    Created `%%t` as an alias for `%%timeit`.

    In [2]: %t -n1 pass
    107 ns ± 43.6 ns per loop (mean ± std. dev. of 7 runs, 1 loop each)

    In [3]: %%t -n1
       ...: pass
       ...:
    107 ns ± 58.3 ns per loop (mean ± std. dev. of 7 runs, 1 loop each)

    In [4]: %alias_magic --cell whereami pwd
    UsageError: Cell magic function `%%pwd` not found.
    In [5]: %alias_magic --line whereami pwd
    Created `%whereami` as an alias for `%pwd`.

    In [6]: %whereami
    Out[6]: '/home/testuser'

    In [7]: %alias_magic h history -p "-l 30" --line
    Created `%h` as an alias for `%history -l 30`.

#Step-51:Use 
%pwd  #look at the current work dir
%cd   #change to the dir you want 
    
#Step-6: Use cell magic 
%%writefile test.txt
Hello world!


# Let's check what this file contains.
with open('test.txt', 'r') as f:
    print(f.read())

#Or 
%pycat test.txt

#List all variables 
a = 2
%who 
#Store any variable and read in any other notebook 
%store a 

#other notebook 
%store -r a 
print(a)

#Execute Html script 
%%html
<html>
<body>
<table>
        <tr> 
            <th>Name</th> 
            <th>Country</th> 
            <th>Age</th> 
        </tr> 
        <tr> 
            <td>Sid</td> 
            <td>India</td> 
            <td>22</td> 
        </tr>
        <tr> 
            <td>Dave</td> 
            <td>UK</td> 
            <td>28</td> 
        </tr>
</table>
</body>
</html>

#Get env 
%env PATH 

#Set env var 
%env variable value

#Object detail info 
a = "The World Makes Sense!"
%pinfo a


#find more information about any command by adding ? after it
#eg running external program 
%run?

#Step-7 : Create Markdown cell
press Esc and then press M (can be done with Menu as well)
    #Command 
    Toggle between edit and command mode with Esc and Enter, respectively.
    Once in command mode:
        Scroll up and down your cells with your Up and Down keys.
        Press A or B to insert a new cell above or below the active cell.
        M will transform the active cell to a Markdown cell.
        Y will set the active cell to a code cell.
        D + D (D twice) will delete the active cell.
        Z will undo cell deletion.
        Hold Shift and press Up or Down to select multiple cells at once.
            With multple cells selected, Shift + M will merge your selection.
    Ctrl + Shift + -, in edit mode, will split the active cell at the cursor.
    You can also click and Shift + Click in the margin to the left of your cells to select them.
Markdown  can be written with HTML tags as well as below github commands 
To edit markdown cell, double click it 
To show, click run or Shift+ENTER (there should not be any whitespace in the begining)

# This is a level 1 heading
## This is a level 2 heading
This is some plain text that forms a paragraph.
Add emphasis via **bold** and __bold__, or *italic* and _italic_.

Paragraphs must be separated by an empty line.

* Sometimes we want to include lists.
 * Which can be indented.

1. Lists can also be numbered.
2. For ordered lists.

[It is possible to include hyperlinks](https://www.example.com)

Inline code uses single backticks: `foo()`, and code blocks use triple backticks:

```
bar()
```

Or can be intented by 4 spaces:

    foo()

And finally, adding images is easy: ![Alt text](https://www.example.com/image.jpg)

Also mathematical equation [check Latex link](http://ctan.math.ca/tex-archive/info/symbols/comprehensive/SYMLIST) 
$$\hat{f}(\xi) = \int_{-\infty}^{+\infty} f(x) \, \exp \left(-2i\pi x \xi \right) dx $$


#Step-9: Sophisticated display 
from IPython.display import HTML, SVG, YouTubeVideo

#Step-10. HTML table dynamically with Python
HTML('''
<table style="border: 2px solid black;">
''' +
     ''.join(['<tr>' +
              ''.join([f'<td>{row},{col}</td>'
                       for col in range(5)]) +
              '</tr>' for row in range(5)]) +
     '''
</table>
''')

#create an SVG graphics dynamically:

SVG('''<svg width="600" height="80">''' +
    ''.join([f'''<circle
              cx="{(30 + 3*i) * (10 - i)}"
              cy="30"
              r="{3. * float(i)}"
              fill="red"
              stroke-width="2"
              stroke="black">
        </circle>''' for i in range(10)]) +
    '''</svg>''')



#display a Youtube video 
YouTubeVideo('VQBZ2MqWBZI')

#details of magic 
%quickref
IPython -- An enhanced Interactive Python - Quick Reference Card
================================================================

obj?, obj??      : Get help, or more help for object (also works as
                   ?obj, ??obj).
?foo.*abc*       : List names in 'foo' containing 'abc' in them.
%magic           : Information about IPython's 'magic' % functions.

Magic functions are prefixed by % or %%, and typically take their arguments
without parentheses, quotes or even commas for convenience.  Line magics take a
single % and cell magics are prefixed with two %%.

Example magic function calls:

%alias d ls -F   : 'd' is now an alias for 'ls -F'
alias d ls -F    : Works if 'alias' not a python name
alist = %alias   : Get list of aliases to 'alist'
cd /usr/share    : Obvious. cd -<tab> to choose from visited dirs.
%cd??            : See help AND source for magic %cd
%timeit x=10     : time the 'x=10' statement with high precision.
%%timeit x=2**100
x**100           : time 'x**100' with a setup of 'x=2**100'; setup code is not
                   counted.  This is an example of a cell magic.

System commands:

!cp a.txt b/     : System command escape, calls os.system()
cp a.txt b/      : after %rehashx, most system commands work without !
cp ${f}.txt $bar : Variable expansion in magics and system commands
files = !ls /usr : Capture system command output
files.s, files.l, files.n: "a b c", ['a','b','c'], 'a\nb\nc'

History:

_i, _ii, _iii    : Previous, next previous, next next previous input
_i4, _ih[2:5]    : Input history line 4, lines 2-4
exec(_i81)       : Execute input history line #81 again
%rep 81          : Edit input history line #81
_, __, ___       : previous, next previous, next next previous output
_dh              : Directory history
_oh              : Output history
%hist            : Command history of current session.
%hist -g foo     : Search command history of (almost) all sessions for 'foo'.
%hist -g         : Command history of (almost) all sessions.
%hist 1/2-8      : Command history containing lines 2-8 of session 1.
%hist 1/ ~2/     : Command history of session 1 and 2 sessions before current.
%hist ~8/1-~6/5  : Command history from line 1 of 8 sessions ago to
                   line 5 of 6 sessions ago.
%edit 0/         : Open editor to execute code with history of current session.

Autocall:

f 1,2            : f(1,2)  # Off by default, enable with %autocall magic.
/f 1,2           : f(1,2) (forced autoparen)
,f 1 2           : f("1","2")
;f 1 2           : f("1 2")

Remember: TAB completion works in many contexts, not just file names
or python names.

The following magic functions are currently available:

%alias:
    Define an alias for a system command.
%alias_magic:
    ::
%autoawait:
    
%autocall:
    Make functions callable without having to type parentheses.
%automagic:
    Make magic functions callable without having to type the initial %.
%autosave:
    Set the autosave interval in the notebook (in seconds).
%bookmark:
    Manage IPython's bookmark system.
%cd:
    Change the current working directory.
%clear:
    Clear the terminal.
%cls:
    Clear the terminal.
%colors:
    Switch color scheme for prompts, info system and exception handlers.
%conda:
    Run the conda package manager within the current kernel.
%config:
    configure IPython
%connect_info:
    Print information for connecting other clients to this kernel
%copy:
    Alias for `!copy`
%ddir:
    Alias for `!dir /ad /on`
%debug:
    ::
%dhist:
    Print your history of visited directories.
%dirs:
    Return the current directory stack.
%doctest_mode:
    Toggle doctest mode on and off.
%echo:
    Alias for `!echo`
%ed:
    Alias for `%edit`.
%edit:
    Bring up an editor and execute the resulting code.
%env:
    Get, set, or list environment variables.
%gui:
    Enable or disable IPython GUI event loop integration.
%hist:
    Alias for `%history`.
%history:
    ::
%killbgscripts:
    Kill all BG processes started by %%script and its family.
%ldir:
    Alias for `!dir /ad /on`
%less:
    Show a file through the pager.
%load:
    Load code into the current frontend.
%load_ext:
    Load an IPython extension by its module name.
%loadpy:
    Alias of `%load`
%logoff:
    Temporarily stop logging.
%logon:
    Restart logging.
%logstart:
    Start logging anywhere in a session.
%logstate:
    Print the status of the logging system.
%logstop:
    Fully stop logging and close log file.
%ls:
    Alias for `!dir /on`
%lsmagic:
    List currently available magic functions.
%macro:
    Define a macro for future re-execution. It accepts ranges of history,
%magic:
    Print information about the magic function system.
%matplotlib:
    ::
%mkdir:
    Alias for `!mkdir`
%more:
    Show a file through the pager.
%notebook:
    ::
%page:
    Pretty print the object and display it through a pager.
%pastebin:
    Upload code to dpaste.com, returning the URL.
%pdb:
    Control the automatic calling of the pdb interactive debugger.
%pdef:
    Print the call signature for any callable object.
%pdoc:
    Print the docstring for an object.
%pfile:
    Print (or run through pager) the file where an object is defined.
%pinfo:
    Provide detailed information about an object.
%pinfo2:
    Provide extra detailed information about an object.
%pip:
    Run the pip package manager within the current kernel.
%popd:
    Change to directory popped off the top of the stack.
%pprint:
    Toggle pretty printing on/off.
%precision:
    Set floating point precision for pretty printing.
%prun:
    Run a statement through the python code profiler.
%psearch:
    Search for object in namespaces by wildcard.
%psource:
    Print (or run through pager) the source code for an object.
%pushd:
    Place the current dir on stack and change directory.
%pwd:
    Return the current working directory path.
%pycat:
    Show a syntax-highlighted file through a pager.
%pylab:
    ::
%qtconsole:
    Open a qtconsole connected to this kernel.
%quickref:
    Show a quick reference sheet 
%recall:
    Repeat a command, or get command to input line for editing.
%rehashx:
    Update the alias table with all executable files in $PATH.
%reload_ext:
    Reload an IPython extension by its module name.
%ren:
    Alias for `!ren`
%rep:
    Alias for `%recall`.
%rerun:
    Re-run previous input
%reset:
    Resets the namespace by removing all names defined by the user, if
%reset_selective:
    Resets the namespace by removing names defined by the user.
%rmdir:
    Alias for `!rmdir`
%run:
    Run the named file inside IPython as a program.
%save:
    Save a set of lines or a macro to a given filename.
%sc:
    Shell capture - run shell command and capture output (DEPRECATED use !).
%set_env:
    Set environment variables.  Assumptions are that either "val" is a
%store:
    Lightweight persistence for python variables.
%sx:
    Shell execute - run shell command and capture output (!! is short-hand).
%system:
    Shell execute - run shell command and capture output (!! is short-hand).
%tb:
    Print the last traceback.
%time:
    Time execution of a Python statement or expression.
%timeit:
    Time execution of a Python statement or expression
%unalias:
    Remove an alias
%unload_ext:
    Unload an IPython extension by its module name.
%who:
    Print all interactive variables, with some minimal formatting.
%who_ls:
    Return a sorted list of all interactive variables.
%whos:
    Like %who, but gives some extra information about each variable.
%xdel:
    Delete a variable, trying to clear it from anywhere that
%xmode:
    Switch modes for the exception handlers.
%%!:
    Shell execute - run shell command and capture output (!! is short-hand).
%%HTML:
    Alias for `%%html`.
%%SVG:
    Alias for `%%svg`.
%%bash:
    %%bash script magic
%%capture:
    ::
%%cmd:
    %%cmd script magic
%%debug:
    ::
%%file:
    Alias for `%%writefile`.
%%html:
    ::
%%javascript:
    Run the cell block of Javascript code
%%js:
    Run the cell block of Javascript code
%%latex:
    Render the cell as a block of LaTeX
%%markdown:
    Render the cell as Markdown text block
%%perl:
    %%perl script magic
%%prun:
    Run a statement through the python code profiler.
%%pypy:
    %%pypy script magic
%%python:
    %%python script magic
%%python2:
    %%python2 script magic
%%python3:
    %%python3 script magic
%%ruby:
    %%ruby script magic
%%script:
    ::
%%sh:
    %%sh script magic
%%svg:
    Render the cell as an SVG literal
%%sx:
    Shell execute - run shell command and capture output (!! is short-hand).
%%system:
    Shell execute - run shell command and capture output (!! is short-hand).
%%time:
    Time execution of a Python statement or expression.
%%timeit:
    Time execution of a Python statement or expression
%%writefile:
    ::

#Notebooks are saved as structured text files (JSON format), 
nbconvert is a tool that can convert notebooks to other formats: raw text, 
Markdown, HTML, LaTeX/PDF

There is a free online service, nbviewer Lets renders notebook into HTML 
check https://nbviewer.jupyter.org/ 
When you give it a URL, it fetches the notebook from that URL, converts it to HTML, 
and serves that HTML to you.
nbviewer only supports launching notebooks stored on GitHub or as Gists on Binder. 
Binder(https://mybinder.org)does support other providers directly on the mybinder.org site.

Locally to get the same functionality (and more)
Check help 
$ jupyter nbconvert 

#To html 
$ jupyter nbconvert first.ipynb

#display this html 
from IPython.display import IFrame
IFrame('first.html', 600, 200)

To save jupyter nootbook as pdf, install pandoc(anaconda brings it) and MikTex 
https://github.com/jgm/pandoc/releases/latest
https://miktex.org/download (check where miktex-tex.exe)
then start jupyter - Note first time while saving, it may download many files, 
hence may fail couple of time, but keep on trying 

$ jupyter nbconvert --to pdf first.ipynb


###Linear algebra using numpy, 

## Rules of Broadcasting 
1. Shape manipulation 
   Convert lower rank array's shape to higher rank shape 
   'by prepending 1'(always prepend)
   For example vector with shape (3,) 
   is converted to rank 2 array as (1,3) or rank 3 as (1,1,3)
   array with (2,3) is converted to rank 3 by (1,2,3)
						
2. Compatibility of arrays 
   Compatible if they have the same size in a dimension, 
   or if one of the arrays has size 1 in that dimension.
   For example , shape (2,3) is compatible with other array 
   with shape (2,3) or (1,3) or (2,1) or (1,1) or (1,) 
   then Broadcasting is possible for other array  

3. Broadcasting  
   If a dimesion is 1 , other dimesions are copied along that dimension 
   when doing operations between arrays 
   eg (1,3) is stacked 2 times to get (2,3) ie np.tile(x13,(2,1))
   (2,1) is stacked three times to get (2,3) ie  np.tile(x21, (1,3)) or np.repeat(x21, 3, axis=1) 
   (1,1) or (1,) can be tiled ie np.tile(x11, (2,3))
   #Example:
   If a.shape is (5,1), b.shape is (1,6), c.shape is (6,) 
   and d.shape is () (ie d scalar), 
   then a, b, c, and d are all broadcastable to dimension (5,6); 
    •a acts like a (5,6) array where a[:,0] is broadcast to the other columns,
    •b acts like a (5,6) array where b[0,:] is broadcast to the other rows,
    •c acts like a (1,6) array and therefore like a (5,6) array where c[:] is broadcast to every row
    •d acts like a (5,6) array where the single value is repeated.

import numpy as np

x = np.array([1,2,3])
y = np.linspace(2.0, 3.0, num=3)
z = np.arange(12).reshape(2,6)
ru = np.random.random((2,6))
rn = np.random.normal(0,1,(6,4)) #mu, sigma 

x.shape 
x.ndim 
z.shape
ru.ndim 
x[0]
z[0,0]
z[:, 0:2]
z[z>2]
z[ (z>2) & (z<4) ] #parentesis must 
z[0,0] = 20
y.shape 
y1 = y[:, None] #becomes 2D 
y1.shape 
np.squeeze(y1)
#broadcasting 
x + y1 # x[None, :] + y1 
#otherwise all 
np.sqrt(z)
x + 2 
x / y 
z * ru 
#matrix mul 
np.mat(z) * np.mat(rn) 
np.mat(rn).I 
rn.T
#sum like axis =0, row varying 
np.sum(z, axis=0)
np.sum(z,axis=1)
#conversion 
z.astype(str)
#stacking
a = np.array([1,2,3])
b = np.array([2,3,4])
>>> np.c_[a,b]  #columnwise stack
array([[1, 2],
       [2, 3],
       [3, 4]])
#or
>>> np.stack((a,b), axis=1)
array([[1, 2],
       [2, 3],
       [3, 4]])

#rowwise stack
>>> np.stack((a,b), axis=0)
array([[1, 2, 3],
       [2, 3, 4]])
#or
>>> np.vstack((a,b))
array([[1, 2, 3],
       [2, 3, 4]])

#
>>> np.hstack((a,b))
array([1, 2, 3, 2, 3, 4])

#title 
>>> np.tile(x, (2,2))  #row=2, col=2
array([[1, 2, 3, 1, 2, 3],
       [1, 2, 3, 1, 2, 3]])
>>> np.tile(x, (2,1))  #row=2, col=1
array([[1, 2, 3],
       [1, 2, 3]])
       
#Solve the system of equations 3 * x0 + x1 = 9 
#and x0 + 2 * x1 = 8:

a = np.array([[3,1], [1,2]])
b = np.array([9,8])
x = np.linalg.solve(a, b)
>>> x
array([ 2.,  3.])
#Check that the solution is correct:
>>> np.allclose(np.dot(a, x), b)
True     
       

##few Other Operations 
#Execute - 0.1.numpy_operations.py
   
#Scipy 
import numpy as np
from scipy.optimize import minimize

#https://docs.scipy.org/doc/scipy/reference/tutorial/optimize.html
f(x) = SUM( 100*(x_i+1-x_i^2)^2 + (1-x_i)^2 ) from i=1..n-1
ie with 0 based, i = 0..n-2

#code 
def rosen(x):
    return sum(100.0*(x[1:]-x[:-1]**2.0)**2.0 + (1-x[:-1])**2.0)

x0 = np.array([1.3, 0.7, 0.8, 1.9, 1.2])
res = minimize(rosen, x0, method='nelder-mead',
    options={'xtol': 1e-8, 'disp': True})

>>> print(res.x)
[1. 1. 1. 1. 1.]

#Also have many Testing 
H0 = base assumptions, Each test has one H0 
#understanding 
If p value <= .01    -> 'not significant'  #reject H0
If p value <= .05   -> 'marginally significant'
If p value >= .10   -> 'significant'
If p value > .10   -> 'highly significant.'  #accept H0

#Problem 
A soft drink company has invented a new drink, 
and would like to find out if it will be as popular as the existing favorite drink. 
For this purpose, its research department arranges 18 participants for taste testing. 
Each participant tries both drinks in random order before giving his or her opinion. 

It turns out that 5 of the participants like the new drink better, 
and the rest prefer the old one. 
Are two drinks equally popular? 

#H0 : two drinks are equally popular ie p=0.5 
import scipy.stats
> scipy.stats.binom_test(5, 18)              
0.096252441406249986             #>0.05, accept H0
 
#Another 
A car manufacturer claims that no more than 10% of their cars are unsafe.
15 cars are inspected for safety, 3 were found to be unsafe. Test the
manufacturer's claim:

#H0 = < 10% are unsafe 
>>> stats.binom_test(3, n=15, p=0.1, alternative='greater')
0.18406106910639114  #accept H0 
 
#Ho: g1, g2, g3 have same median 
g1 = [10, 14, 14, 18, 20, 22, 24, 25, 31, 31, 32, 39, 43, 43, 48, 49]
g2 = [28, 30, 31, 33, 34, 35, 36, 40, 44, 55, 57, 61, 91, 92, 99]
g3 = [0, 3, 9, 22, 23, 25, 25, 33, 34, 34, 40, 45, 46, 48, 62, 67, 84]
from scipy.stats import median_test
stat, p, med, tbl = median_test(g1, g2, g3)
#The median is
>>> med
34.0
>>> p
0.12609082774093244  #>0.5, don't reject H0 


Gender  Right handed    Left handed     Total
Male        43          9               52
Female      44          4               48 
Total       87          13              100 

#H0: male-female's  right or left handed are independent 
obs = np.array([[43,9], [44,4]])
>>> stats.chi2_contingency(obs)
(1.0724852071005921, 
0.300384770390566,  #>0.05, accept H0 
1, array([[45.24,  6.76],
       [41.76,  6.24]]))
       
 
###Plotting using matplotlib 
#There are three layers to the matplotlib API. 
1.The matplotlib.backend_bases.FigureCanvas 
    is the area  onto which the figure is drawn, 
2.The matplotlib.backend_bases.Renderer 
    is the object  which knows how to draw on the FigureCanvas, 
    The FigureCanvas and Renderer handle all the details of talking 
    to user interface toolkits like wxPython or drawing languages like PostScript®
3.The matplotlib.artist.Artist 
    is the object that knows how to use a renderer to paint onto the canvas. 
    The Artist handles all the high level constructs 
    like representing and laying out the figure, text, and lines. 
    The typical user will spend 95% of their time working with the Artists.  
    There are two types of Artists: primitives and containers. 
    #check class hierarchy https://matplotlib.org/api/artist_api.html  
    The primitives represent the standard graphical objects 
    eg  Line2D, Rectangle, Text, AxesImage, etc.(subclass of Artist)
    and the containers are places to put primitives (Axis, Axes and Figure)(subclass of Artist) 

##With multiple x, y pairs in same plot
import numpy as np
import matplotlib.pyplot as plt

# evenly sampled time at 200ms intervals
t = np.arange(0., 5., 0.2)

# red solid, blue dashed and green triangles
plt.plot(t, t, 'r-', t, t**2, 'b--', t, t**3, 'g^')
plt.show()




#options - Open and Read must 
#Execute - 0.2.plt_options.py




##Various other methods on plt 
#Execute - 0.2.plt_methods.py
#OR 
#Example
import matplotlib.pyplot as plt
#x,y , red and line 
plt.plot([1,2,3,4], [1,2,3,4],'r-', lw=2)                #y values , x is taken as 0,1,2,3
plt.xlabel('x axis label', fontsize=14, color='red')
plt.ylabel('y axis label')
plt.title('My first plot ')
plt.legend(['Straight Line'], loc='best')
plt.grid(True)
plt.yscale('linear') #log, symlog, logit
plt.xscale('linear')
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.axis.html
plt.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
#or 
plt.ylim(0, 4)
plt.xlim(0, 10)

#x, y are graph/data co-ordinates
plt.text(2, 2, r'$\mu=100,\ \sigma=15$')  #Any text  or  '$any LaTex code$'

#put a rectangular box around the text 
plt.text(1,1, "Another text", bbox=dict(facecolor='red', alpha=0.5))

#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.annotate.html
#text with arrow 
plt.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
plt.show()


## Working with multiple figures and axes
#Plots may contain many Figure, 
#each figure is one display window
#each Figure may contain many Axes
#Figure contains set/get of figure related attributes 
#eg get_figheight(),get_figwidth()
#Axes contains plot() and set/get of xlabel, ylabel etc


#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplots.html 
##Option-1 
#note subplots(..) returns (figure,axes)
#where axes is numpy.ndarray, hence access like axes[0,0], axes[0,1],... for complex subplots 
#for simple , can destructure immediately

#sharex=True, means only one X ticks value printing , similarly for sharey
#figsize : (float, float), optional, default: None
#width, height in inches. 
#If not provided, defaults to rcParams["figure.figsize"] = [6.4, 4.8].

figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, sharex=False, sharey=True, figsize=(15,15))
t = np.arange(0., 5., 0.2)

ax1.plot(t, t, 'r-')  
ax1.set_title('Sharing Y axis')
ax2.scatter(t, t**2, color='b')
#then show 
plt.show()

#Others 
#Execute - 0.2.plt_multi.py
#3x3 grid , 
fig1= plt.figure(1)
ax1 = plt.subplot2grid((3,3), (0,0), colspan=3) #for (0,0), 3 columns 
ax2 = plt.subplot2grid((3,3), (1,0), colspan=2) #for (1,0), 2 columns 
ax3 = plt.subplot2grid((3,3), (1, 2), rowspan=2) #for (1,2), 2 rows 
ax4 = plt.subplot2grid((3,3), (2, 0))  #one row and col
ax5 = plt.subplot2grid((3,3), (2, 1))   #one row and col 
#Now use ax1.plot() to direct commands to ax1, etc
x = np.linspace(-5,5,20)
y = np.sin(x)
ax1.plot(x,y,"r-")
ax1.set_title("one title")
ax2.plot(x,y,"b-")
ax3.plot(x,y,"r-")
ax4.plot(x,y,"b-")
ax5.plot(x,y,"b-")
plt.suptitle("Example of subplots") #,  y=1.05, fontsize=18)
plt.tight_layout(rect=[0, 0.03, 1, 0.95]) 
#tight_layout automatically adjusts subplot params so that the subplot(s) fits in to the figure area
#with arg, ax title and figure title overlaps 
plt.show()

##Saving to a file
#output format is deduced from the extension of the filename
plt.savefig(file_name)

    
##Few other plotting command than plot 
#Execute - 0.2.plt_other_plot.py

##ColorMaps 
#Colourmap - Setting a range of colors for various items 
#select by 
#https://matplotlib.org/gallery/color/colormap_reference.html
from matplotlib import cm 
cmap=plt.get_cmap('Dark2')  #string_name 
>>> cmap.colors
((0.10588235294117647, 0.6196078431372549, 0.4666666666666667), ...)
#or 
cmap=cm.Dark2
#see all 
dir(cm)

##HandsON - understanding polyfit 
x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])

z = np.polyfit(x, y, 3)  #Polynomial coefficients, highest power first,0th index 
>>> z
array([ 0.08703704, -0.81349206,  1.69312169, -0.03968254])

>>> p = np.poly1d(z) #highest power first,0th index 
>>> print(p)
         3          2
0.08704 x - 0.8135 x + 1.693 x - 0.03968

>>> p(0.5)   #evaluate 
0.6143849206349179

>>> p.r #roots
array([6.24151464, 3.08128307, 0.02370685])
#+,-,*,**,/ are overloaded , np.methods() can be called 

>> p**2
poly1d([ 7.57544582e-03, -1.41607878e-01,  9.56497928e-01, -2.76158982e+00,
       2.93122393e+00, -1.34374738e-01,  1.57470396e-03])
>> np.sin(p)
array([ 0.08692719, -0.72669053,  0.99252758, -0.03967213])


#High-order polynomials may oscillate wildly:
p30 = np.poly1d(np.polyfit(x, y, 30))
>>> p30(4)
-0.80000000000000204

##HandsON - Create equal spaced 100 points between -2 and 6 and 
#then plot above p and p30 graphs for those x points 

#plot 
import matplotlib.pyplot as plt
xp = np.linspace(-2, 6, 100)
_ = plt.plot(x, y, '.', xp, p(xp), '-', xp, p30(xp), '--')
plt.ylim(-2,2)
plt.show()





##3D plots 
#3D plots require x,y (create from meshgrid) and Z 
#Z points are mapped to color  from ColorMap 


from matplotlib import cm 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np

X = np.arange(-5, 5, 0.25)
Y = np.arange(-5, 5, 0.25)
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)



fig = plt.figure(figsize=(10,6))
ax = fig.add_subplot(111, projection='3d')  #requires Axes3D
#rstride 	Array row stride (step size)
#cstride 	Array column stride (step size)
surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, 
    linewidth=0, antialiased=False)
ax.set_zlim(-1.01, 1.01)
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=10)

fig.show()

#understanding pcolormesh, contour, imshow and contourf 
#Execute 0.2.plt_3dr_plot_understanding.py

#Others 
#Execute - 0.2.plt_3dr_plot.py




###Pandas and CSV  
import pandas as pd 
import matplotlib.pyplot as plt
path = r"data\iris.csv"
iris = pd.read_csv(path)
iris.head()
iris.columns
len(iris.columns)
len(iris.index)
iris.dtypes
iris['SepalRatio'] = iris.SepalLength/iris['SepalWidth']
iris['PetalRatio'] = iris.PetalLength/iris.PetalWidth
iris['dummy'] = iris.SepalRatio * 2 + iris.PetalRatio
iris[['SepalLength', 'PetalLength']]

iris.SepalRatio.mean()
iris.loc[iris.SepalRatio > iris.SepalRatio.mean(), :]

iris.iloc[100:150, ['SepalLength', 'PetalLength']]

#Return new DF 
>>> (iris.assign(sepal_ratio = iris['SepalWidth'] / iris['SepalLength']).head())
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200


#Or use function of one argument which is the  DF
>>> iris.assign(sepal_ratio = lambda df: (df['SepalWidth'] /df['SepalLength'])).head()
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200



#Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:

(iris.query('SepalLength > 5').assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength,            
                     PetalRatio = lambda df: df.PetalWidth / df.PetalLength)   
                .plot(kind='scatter', x='SepalRatio', y='PetalRatio'))
plt.show()

#Clearly two clusters 
iris_m = iris.assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength, PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')

##Quick K-Means - Find those two clusters 
from sklearn.cluster import KMeans
numpy_features = iris_m[ ['SepalRatio','PetalRatio' ]].values
kmeans = KMeans(n_clusters=2, random_state=0).fit(numpy_features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
       
#unique Name 
iris.Name.unique()
#many str methods 
iris.Name.str.lower()
iris.Name.str.split("-") #gives a column with list of strings 
df = iris.Name.str.split("-", expand=True) #each list element becomes one column 
df.columns = ['part1', 'par2']
#merge 
pd.concat([iris, df], axis=1)  #columnwise stack 

#transforming- use apply or transform as lambda returns same size 
iris.Name.str.split("-", expand=True).apply(lambda s: np.char.lower(s.to_list()))
#T means transpose 
(iris.Name.str.split("-", 
                expand=True)[[0]].T.transform(
                lambda s: np.char.lower(s.to_list()))
                .shape
            )

>>> np.unique(iris.Name.apply(lambda x: un.tolist().index(x)))
array([0, 1, 2], dtype=int64)
#apply for Series, fn takes each element, 
#for DF, fn takes each col if axis=0 else takes each row if axis=1
iris["target"] = iris.Name.apply(lambda x: un.tolist().index(x))

#Get the first five rows of a column by name
iris['SepalLength'][:5]                     #Series
iris[ [ 'SepalLength', 'SepalWidth'] ][:5]  #DF 


#Create categorical ranges for numerical data. 14 is number of bins
sl_bin = pd.cut(iris['SepalLength'], 14)
sl_bin[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(sl_bin)
sl_bin.value_counts()

#Access through .cat 
iris["category"] = sl_bin
iris.category.cat.categories
#to get index of each bin 
iris.category.cat.rename_categories(range(14))

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
iris.ix[0,0:6]

#Order the data by specified column
iris['SepalLength'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = iris.sort_values(by=['SepalLength', 'PetalLength'])  #DF
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
iris['PetalLength'].value_counts()

#to obtain the datatype 
iris.dtypes

#Get the unique values for a column by name.
iris['Name'].unique()

#Get a count of the unique values of a column
len(iris['Name'].unique())

#Index into a column and get the first four rows
iris.ix[0:3,'Name']

#Obtain True/False  values which could be used inside iloc, loc etc 
iris.ix[:,'Name'] == 'Iris-setosa'
#Can get any columns , use  | , &, ~ for boolean conjunction, disjunction and inverse 
iris.loc[iris['Name'] == 'Iris-setosa', 'SepalLength']  #Series
iris.ix[iris['Name'] == 'Iris-setosa', 0] #note .iloc with boolean not available 
iris.loc[iris['Name'] == 'Iris-setosa', ['SepalLength','PetalLength']] #DF

#Query the data
qry1 = iris.query('Name == "Iris-setosa"')  #returns DF of original only where cond is valid 
qry1.head(10)

#Check a boolean condition
(iris.ix[:,'SepalLength'] > 4.3).any()


#Return descriptive statistics of the dataset- mean, std etc is calculated for each colu mn
>>> iris.describe()
       SepalLength
count   150.000000
mean      5.843333
std       0.828066
min       4.300000
25%       5.100000
50%       5.800000
75%       6.400000
max       7.900000
>>> iris.Name.describe()
count                 150
unique                  3
top       Iris-versicolor
freq                   50
Name: Name, dtype: object

#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(iris['category'],iris['target']) #DF, multiindex 

#Which same as merge 
#merge(right, how='inner', on=None, left_on=None, right_on=None, left_index=False, right_index=False)
iris.merge(df, right_index=True, left_index=True)

#value counts : value vs count  
iris['PetalLength'].value_counts()
#mean 
iris.mean() #columnwise 
iris.mean(axis=1) #rowwise 
#aggregation 
gr1 = iris.groupby('Name')
gr1.mean()  #DF of each column mean for each Name 
gr1.agg({'SepalLength':
    ['mean', 'max']}).to_csv("processed.csv")
#open data/processed.csv 

#Using UDF 
#drop
df2 = iris.drop(columns='Name')
df2.head()
iris.replace({'Name':{np.nan:0}})

#Conditionally update 
iris['dummy'] = 2
iris.loc[iris['Name'] == 'Iris-setosa', 'dummy'] = 0
#if true, then x else y , where(condition, x, y)
df['dummy'] = np.where(iris['Name'] == 'Iris-setosa', 0, df['dummy'])


#apply with index based access - check reference for axis meaning
iris.iloc[:, 0:4].apply(np.sum)  #columnwise #end exclusive, s-> each column ie pd.Series
iris.iloc[:, 0:4].apply(np.sum, axis=1) #rowwise 
Note apply can return Series or scalar , but transform must return same length series 

#similar to transform when single series is operated upon 
df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 

#If transofrm can not return same length series, it raises ValueError: Function did not transform
>>> iris.iloc[:, 0:4].transform(['sqrt'])
    SepalLength SepalWidth PetalLength PetalWidth
           sqrt       sqrt        sqrt       sqrt
0      2.258318   1.870829    1.183216   0.447214
1      2.213594   1.732051    1.183216   0.447214
2      2.167948   1.788854    1.140175   0.447214
3      2.144761   1.760682    1.224745   0.447214
4      2.236068   1.897367    1.183216   0.447214
..          ...        ...         ...        ...
145    2.588436   1.732051    2.280351   1.516575
146    2.509980   1.581139    2.236068   1.378405
147    2.549510   1.732051    2.280351   1.414214
148    2.489980   1.843909    2.323790   1.516575
149    2.428992   1.732051    2.258318   1.341641

[150 rows x 4 columns]
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp], axis=1)
          SepalLength  SepalWidth  PetalLength  PetalWidth
0   sqrt     2.258318    1.870829     1.183216    0.447214
    exp    164.021907   33.115452     4.055200    1.221403
1   sqrt     2.213594    1.732051     1.183216    0.447214
    exp    134.289780   20.085537     4.055200    1.221403
2   sqrt     2.167948    1.788854     1.140175    0.447214
...               ...         ...          ...         ...
147 exp    665.141633   20.085537   181.272242    7.389056
148 sqrt     2.489980    1.843909     2.323790    1.516575
    exp    492.749041   29.964100   221.406416    9.974182
149 sqrt     2.428992    1.732051     2.258318    1.341641
    exp    365.037468   20.085537   164.021907    6.049647

[300 rows x 4 columns]
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp], axis=1).index
MultiIndex([(  0, 'sqrt'),
            (  0,  'exp'),
            (  1, 'sqrt'),
            (  1,  'exp'),
            (  2, 'sqrt'),
            (  2,  'exp'),
            (  3, 'sqrt'),
            (  3,  'exp'),
            (  4, 'sqrt'),
            (  4,  'exp'),
            ...
            (145, 'sqrt'),
            (145,  'exp'),
            (146, 'sqrt'),
            (146,  'exp'),
            (147, 'sqrt'),
            (147,  'exp'),
            (148, 'sqrt'),
            (148,  'exp'),
            (149, 'sqrt'),
            (149,  'exp')],
           length=300)
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp]).index
RangeIndex(start=0, stop=150, step=1)
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp])
    SepalLength             SepalWidth  ... PetalLength PetalWidth
           sqrt         exp       sqrt  ...         exp       sqrt       exp
0      2.258318  164.021907   1.870829  ...    4.055200   0.447214  1.221403
1      2.213594  134.289780   1.732051  ...    4.055200   0.447214  1.221403
2      2.167948  109.947172   1.788854  ...    3.669297   0.447214  1.221403
3      2.144761   99.484316   1.760682  ...    4.481689   0.447214  1.221403
4      2.236068  148.413159   1.897367  ...    4.055200   0.447214  1.221403
..          ...         ...        ...  ...         ...        ...       ...
145    2.588436  812.405825   1.732051  ...  181.272242   1.516575  9.974182
146    2.509980  544.571910   1.581139  ...  148.413159   1.378405  6.685894
147    2.549510  665.141633   1.732051  ...  181.272242   1.414214  7.389056
148    2.489980  492.749041   1.843909  ...  221.406416   1.516575  9.974182
149    2.428992  365.037468   1.732051  ...  164.021907   1.341641  6.049647

[150 rows x 8 columns]
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp]).columns
MultiIndex([('SepalLength', 'sqrt'),
            ('SepalLength',  'exp'),
            ( 'SepalWidth', 'sqrt'),
            ( 'SepalWidth',  'exp'),
            ('PetalLength', 'sqrt'),
            ('PetalLength',  'exp'),
            ( 'PetalWidth', 'sqrt'),
            ( 'PetalWidth',  'exp')],
           )
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp])[('SepalLength', 'sqrt')]
0      2.258318
1      2.213594
2      2.167948
3      2.144761
4      2.236068
         ...
145    2.588436
146    2.509980
147    2.549510
148    2.489980
149    2.428992
Name: (SepalLength, sqrt), Length: 150, dtype: float64
>>> iris.iloc[:, 0:4].transform(['sqrt', np.exp])[[('SepalLength', 'sqrt'), ('PetalLength', 'sqrt')]]
    SepalLength PetalLength
           sqrt        sqrt
0      2.258318    1.183216
1      2.213594    1.183216
2      2.167948    1.140175
3      2.144761    1.224745
4      2.236068    1.183216
..          ...         ...
145    2.588436    2.280351
146    2.509980    2.236068
147    2.549510    2.280351
148    2.489980    2.323790
149    2.428992    2.258318

[150 rows x 2 columns]
>>>








#In groupby, there is some difference 
There are two major differences between the transform and apply groupby methods.
Input:
    apply implicitly passes all the columns for each group as a DataFrame 
        to the custom function.
        so below works as x is full DF 
        > df.groupby('A').apply(lambda x: (x['C'] - x['D']))
        > df.groupby('A').apply(lambda x: (x['C'] - x['D']).mean())
    transform passes each column for each group individually as a Series 
        to the custom function.
        so below can not work as x is individual Series 
        > df.groupby('A').transform(lambda x: (x['C'] - x['D']))
        > df.groupby('A').transform(lambda x: (x['C'] - x['D']).mean())
            TypeError: cannot concatenate a non-NDFrame object
Output:
    The custom function passed to apply can return a scalar, 
        or a Series or DataFrame (or numpy array or even list).
    The custom function passed to transform must return a sequence 
        (a one dimensional Series, array or list) the same length(no of rows) as the group.

So, transform works on just one Series at a time 
and apply works on the entire DataFrame at once

#plot
iris.Name.value_counts().plot(kind='bar')
plt.show()

#How Many Factors - 3 
iris['index'] = iris.index
iris.plot(x='index', y='SepalLength', kind='scatter')
plt.show()

iris.plot(x='SepalWidth', y='SepalLength', kind='scatter')
plt.show()
iris.iloc[:,0:4].plot(kind='line')
#dont dow below as many plots 
plt.show()
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#or 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.savefig('plot.png')
#or in one plot 
#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label, title='SepalLength')

plt.tight_layout()
plt.legend()
plt.show()

#To sql 
from sqlalchemy import create_engine
engine = create_engine('sqlite:///iris.db', echo=False)

iris.to_sql('iris', con=engine,if_exists='replace') 
#{'fail', 'replace', 'append'}, default 'fail'
#index : bool, default True

engine.execute("select * from iris").fetchall()

engine.execute("SELECT max(SepalLength) , count(*) FROM iris group by Name").fetchall()

pd.read_sql('iris', con=engine) 
pd.read_sql('select * from iris', con=engine) 



##More Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, pip install seaborn

iris.Name.value_counts().plot(kind='bar')
plt.show()
#with x and y 
iris.plot(x=None, y='SepalWidth', kind='line')
plt.show()
#full DF 
iris.plot( kind='line')
plt.show()
#for sub DF 
iris.iloc[:,0:4].plot(kind='line')
plt.show()
#with groupby 
iris.groupby('Name').plot(kind='line')
plt.show()
#as subplots 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#for partial DF 
iris.iloc[:,0:5].groupby('Name')['SepalLength'].plot(kind='line', subplots=True)
plt.show()

#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label)
plt.legend()
plt.show()

#all 
#https://matplotlib.org/users/colormaps.html
cm =['Blues', 'Greens', 'Reds']
fig, ax = plt.subplots(figsize=(8,6))
x_label = []
for i,(label, df) in enumerate(iris.groupby('Name')):
    x_label.append(label)
    df.plot(kind='line', ax=ax, colormap=cm[i])

plt.xlabel(x_label)
plt.legend()
plt.show()

#note 
iris.plot(kind='line') 
#is equivalent to 
iris.plot.line()
#and similarly for others 

#with subplots 
#multiple in one plot 
iris.plot(kind='line', y=['SepalLength','PetalLength'] )
#with subplots 
iris.plot(kind='line', y=['SepalLength','PetalLength'], subplots=True )

#Bar plot of median values
iris.groupby('Name')['SepalLength'].agg(np.mean).plot(kind = 'bar')
plt.show()

#Scatter_matrix or sns.pairplot
#hue is categorical data and for each hue, scatter_matrix is done
sns.pairplot(iris.iloc[:,0:5], hue='Name', size=2.5)
plt.show()

from pandas.plotting import scatter_matrix
scatter_matrix(iris.iloc[:,0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#for only one Name 
scatter_matrix(iris.ix[iris.Name=='Iris-virginica',0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#only density plot 
iris.SepalLength.plot.kde()
plt.show()
#or 
sns.kdeplot(iris.SepalLength)
sns.kdeplot(iris.SepalWidth)
plt.show()
#or
sns.distplot(iris.SepalLength)
plt.show()
#for bivariate kernel density estimate
sns.kdeplot(iris.iloc[:,0:4]) #bivariate kernel density estimate
plt.show()
#joint distribution of x,y and the marginal distributions (joit distribution with one const)
#For this plot, we'll set the style to a white background
#pearsonr = correlation coefficient  , -1 to 1, 0= not correlated, H0:not correlated 
#kind : { “scatter” | “reg” | “resid” | “kde” | “hex” }, optional
with sns.axes_style('white'):
    sns.jointplot(x="SepalLength", y="PetalLength", data=iris.iloc[:,0:4], kind='kde');

plt.show()

#Box plot - x= x axis categorical data, y= box plot variable  , hue=categorical data, for each, x vs y box plot is done 
#box plot - box-25%,median, 75%(third quartiles), min-max data - some convension of min and max - https://en.wikipedia.org/wiki/Box_plot, outliers
#seaborn.factorplot(x=None, y=None, hue=None, data=None, row=None, col=None, col_wrap=None, estimator=<function mean>, ci=95, n_boot=1000, units=None, order=None, hue_order=None, row_order=None, col_order=None, kind='point', size=4, aspect=1, orient=None, color=None, palette=None, legend=True, legend_out=True, sharex=True, sharey=True, margin_titles=False, facet_kws=None, **kwargs)
#kind : {point, bar, count, box, violin, strip}
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Barplot 
g = sns.factorplot(x="Name", data=iris.iloc[:,0:5], aspect=2,  kind="count", color='steelblue')


##Other Plots 
##scatter_matrix 
#https://pandas.pydata.org/pandas-docs/stable/visualization.html

from pandas.plotting import scatter_matrix
df = pd.DataFrame(np.random.randn(1000, 4), columns=['a', 'b', 'c', 'd'])
scatter_matrix(ver, alpha=0.2, figsize=(6, 6), diagonal='kde')
#only density plot 
df.a.plot.kde()

##lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.a)

##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for any and all time-lag separations
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.a)

#Bootstrap plots are used to visually assess the uncertainty of a statistic, 
#such as mean, median, midrange, etc. 
#A random subset of a specified size is selected from a data set, 
#the statistic in question is computed for this subset 
#and the process is repeated a specified number of times. 
#Resulting plots and histograms are what constitutes the bootstrap plot.
from pandas.plotting import bootstrap_plot
bootstrap_plot(df.a, size=50, samples=500, color='grey')


##Time/Date Plot 
ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2000', periods=1000))
ts = ts.cumsum()
ts.plot()

df = pd.DataFrame(np.random.randn(1000, 4), index=ts.index, columns=list('ABCD'))
df = df.cumsum()
plt.figure(); 
df.plot();

#with subplots 
df.plot(subplots=True, figsize=(6, 6));
#means 2 rows and 3 columns , each one is 6x6 
df.plot(subplots=True, layout=(2, 3), figsize=(6, 6), sharex=False);

#or maximum control 
fig, axes = plt.subplots(4, 4, figsize=(6, 6));
plt.subplots_adjust(wspace=0.5, hspace=0.5);
target1 = [axes[0][0], axes[1][1], axes[2][2], axes[3][3]]
target2 = [axes[3][0], axes[2][1], axes[1][2], axes[0][3]]
df.plot(subplots=True, ax=target1, legend=False, sharex=False, sharey=False);
(-df).plot(subplots=True, ax=target2, legend=False, sharex=False, sharey=False);
#or 
fig, axes = plt.subplots(nrows=2, ncols=2)
df['A'].plot(ax=axes[0,0]); axes[0,0].set_title('A');
df['B'].plot(ax=axes[0,1]); axes[0,1].set_title('B');
df['C'].plot(ax=axes[1,0]); axes[1,0].set_title('C');
df['D'].plot(ax=axes[1,1]); axes[1,1].set_title('D');



###then DB api 
rowsd = iris.values.tolist() #from DF 

#Note ? for sqlite, %s for mysql 

from sqlite3 import connect
con = connect(r"iris.db")
cur = con.cursor()
cur.execute("""create table iris (sl double, sw double,
        pl double, pw double, name string)""")
for r in rowsd:
    cur.execute("""insert into iris values(?,?,?,?,?) """, r)

con.commit()
q = cur.execute("""select name, max(sl) from iris group by name""")
result = list(q.fetchall())
print(result)
cur.execute("""drop table if exists iris""")

con.close()

#With sqlAlchemy 
#classical ORM is complex( Table, mapper(), and class objects), 
#declarative base simplfies that 
#https://docs.sqlalchemy.org/en/13/orm/extensions/declarative/basic_use.html
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import *
Base = declarative_base()

class Row(Base):
    __tablename__ = 'iris'
    # id = Column("some_table_id", Integer, primary_key=True)
    id = Column(Integer, primary_key=True)
    sl = Column(Float)
    sw = Column(Float)
    pl = Column(Float)
    pw = Column(Float)
    name = Column(String(36))
    def __repr__(self):
        return "Row(%.2f,%.2f,%.2f,%.2f,%s)" % (self.sl,self.sw, self.pl, self.pw, self.name)

engine = create_engine('sqlite:///iris1.db', echo=True)
#generates the Schema:
Base.metadata.create_all(engine)

from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)
session = Session()

#Add 
for sl,sw,pl,pw,n in rowsd:
    session.add(Row(sl=sl, sw=sw, pl=pl, pw=pw, name=n))

session.commit()
session.query(Row).count()
session.query(Row).all()
session.query(Row).first()
session.query(Row).filter(Row.sl < 5.1).all()

from sqlalchemy.sql import func, desc 
#func is pseduo object, use sql max\min  etc 
session.query(func.max(Row.sl), func.count(Row.name)) \
    .group_by(Row.name) \
    .order_by(desc(Row.name)) \
    .all()

    

##Update
otu = session.query(Row).filter(Row.name == 'Iris-virginica').first()
otu.sl = otu.sl + 10
session.commit()

##Delete
session.delete(otu)
session.commit()

##Using text - then we dont have to use ? or %s 
from sqlalchemy import text

stmt = text("insert into iris values(:sl,:sw,:pl,:pw,:n)")
result = engine.execute(stmt, dict(sl=1.0,sw=1.0,pl=1.0,pw=1.0,n="dummy"))

#for mysql, we can call proceedure as well 
#start MYSQL56
mysql -u root    -h 127.0.0.1 -p 
password : root 
> use python;


#simple 
mysql> 
DROP PROCEDURE IF EXISTS simpleproc;

delimiter //

CREATE PROCEDURE simpleproc (IN param0 INT, OUT param1 INT)
BEGIN
    SELECT param0 * COUNT(*) INTO param1 FROM DUAL;
END//
delimiter ;

CALL simpleproc(1, @a);
SELECT @a;

#in sqlalchemy 
# define parameters to be passed in and out
from sqlalchemy import create_engine
engine = create_engine('mysql+mysqlconnector://root:root@localhost/python', echo=False)


parameterIn = 1
parameterOut = "@parameterOut"
#DBAPI cursor 
connection = engine.raw_connection()
try:
    cursor = connection.cursor()
    results = cursor.callproc("simpleproc", [parameterIn, parameterOut])
    #results = list(cursor.fetchall())
    cursor.close()
    connection.commit()
finally:
    connection.close()
    
#with pymysql 
from sqlalchemy import create_engine
engine = create_engine('mysql+pymysql://root:root@localhost/python', echo=False)

The server variables are named @_procname_n, where procname is the parameter above 
and n is the position of the parameter (from zero).
 Once all result sets generated by the procedure have been fetched, 
 you can issue a SELECT @_procname_0, … query using .execute() to get any OUT or INOUT values.


parameterIn = 1
parameterOut = "@parameterOut"
#DBAPI cursor 
connection = engine.raw_connection()
try:
    cursor = connection.cursor()
    cursor.callproc("simpleproc", [parameterIn, parameterOut])
    #this is pymysql specific behaviour 
    cursor.execute("select @_simpleproc_1")
    results = list(cursor.fetchall())
    cursor.close()
    connection.commit()
finally:
    connection.close()

mysql>
DROP PROCEDURE IF EXISTS multiply;

delimiter //

CREATE PROCEDURE multiply(IN pFac1 INT, IN pFac2 INT, OUT pProd INT)
BEGIN
  SET pProd := pFac1 * pFac2;
END//

delimiter ;
CALL multiply(1,2, @a);
SELECT @a;

#python code 
import mysql.connector
con = mysql.connector.connect(user='root', password='root',
    host='127.0.0.1',database='python')             
cur = con.cursor()
args = (5, 6, 0) # 0 is to hold value of the OUT parameter pProd
>>> cursor.callproc('multiply', args)
('5', '6', 30L)
args = (1,0) # 0 is to hold value of the OUT parameter 
cur.callproc('simpleproc', args)


##Transaction - ORM session has commit/rollback 
#but DBAPI below is always autocommits 
cur.execute("""insert into iris values(?,?,?,?,?) """, r)
#To use transaction 
with engine.connect() as connection:
    with connection.begin() as trx: #trx.rollback()
        r1 = connection.execute("select query")
        connection.execute("insert query", data)
    #here autocommits, trx.commit()    


##Sqlite 
SQLite is not designed for a high level of write concurrency. 
The database itself, being a file, is locked completely during write operations 
within transactions, meaning exactly one “connection” (in reality a file handle) 
has exclusive access to the database during this period - all other “connections” 
will be blocked during this time.
https://docs.sqlalchemy.org/en/14/dialects/sqlite.html#sqlite-isolation-level

df = pd.read_csv(r"data/iris.csv")
rowsd = df.values.tolist() #from DF 
engine = create_engine('sqlite:///iris.db', echo=False)

#only once commit , use %s for mysql 
with engine.connect() as connection:
    with connection.begin() as trx:
        connection.execute("""create table iris (sl double, sw double,
                pl double, pw double, name string)""")
        for r in rowsd:
            connection.execute("""insert into iris values(?,?,?,?,?) """, r)

To get exclusive access for a specific period 
(not just while an individual query/trasaction is taking place) you need to do;

con = sqlite3.connect()
con.isolation_level = 'EXCLUSIVE'
con.execute('BEGIN EXCLUSIVE')
#exclusive access starts here. Nothing else can r/w the db, do your magic here.
con.commit()
con.close()



##Mysql 
https://docs.sqlalchemy.org/en/14/dialects/mysql.html#mysql-isolation-level

#Per engine 
eng = create_engine(
    url,
    execution_options={
        "isolation_level": "REPEATABLE READ"
    }
)

An application that frequently chooses to run operations within different isolation levels 
may wish to create multiple “sub-engines” of a lead Engine, 
each of which will be configured to a different isolation level
eg 
eng = create_engine("postgresql://scott:tiger@localhost/test")
autocommit_engine = eng.execution_options(isolation_level="AUTOCOMMIT")


#per connection 
with engine.connect().execution_options(isolation_level="REPEATABLE READ") as connection:
    with connection.begin():
        connection.execute(<statement>)


Valid values for isolation_level include:
    READ COMMITTED
        Each consistent read, even within the same transaction, sets and reads its own fresh snapshot. 
        So each read sees latest committed data 
    READ UNCOMMITTED
        quick and dirty read, might see old data 
    REPEATABLE READ
        Each consistent read, even within the same transaction, reads the first read data (ie select query used first time)
        So each read sees first read data 
    SERIALIZABLE
        This level is like REPEATABLE READ,
        check https://dev.mysql.com/doc/refman/8.0/en/innodb-transaction-isolation-levels.html
    AUTOCOMMIT
        Specific to sqlalchemy which commits each query 



###Excel-pandas 
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parse_dates=True, index_col=0, header=0)
# date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
#from pandas.tseries.offsets import *
#dft.index.freq = Day() #set freq as D 
##if above does not work 
#dft.index.freq = pd.tseries.frequencies.to_offset(Day())
#
dft = dft.asfreq('D')


dft['Open'] #OK 
dft[0:5]

import datetime
#For specific exact index for DF , use .loc 
#dft['2000-06-01'] #ERROR 
#dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
dft.loc['2000-06-01']
dft.loc['2000-06-01', 'Open']

dft.iloc[0]
dft.loc[datetime.date(2000, 6, 1)] 
#for both DF and Series- any partial date string or slice of exact index works 
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day

dft.Close.plot(kind='line')
plt.show()

#which year , stock market crashed 
dft_s = dft.resample('Y')  #'M' , for version <19.2, it is 'A'
dir(dft_s)
#month value would be mean()
dft_s['Open'].mean()   #
sr = dft_s[['Open', 'Close']].first() 
#shift one and drop na 
sr['Close'] = sr.Close.shift(-1)
sr.dropna(how='any', axis=0, inplace=True)
import numpy as np 
sr['diff'] = np.abs(sr.Close - sr.Open)
sr['diff'].idxmax()
sr.loc[[sr['diff'].idxmax()]].index.year.tolist() #DF required 

##other
dft_s = dft.resample('M')
dft_s.mean() #DF 
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})
sr = dft_s['Open'].first().to_frame() #series to DF 
sr.loc[sr['diff'].idxmax()]
sr['Year'] = sr.index.year  #date.astype(np.datetime64)


#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')



#Excel - Example 
df = pd.read_excel("data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225


#Q= "What percentage of the order total does each order represent?"
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]

#Or using openpyxl 
from openpyxl import load_workbook

wb = load_workbook(filename =r"data\Nifty-17_Years_Data-V1.xlsx", 
    data_only=True) #default false, so only read formula 
wb.get_sheet_names()

sheet = wb['Sheet1'] #or wb.worksheets[0]
sheet['A18'].value #datetime 
[(c1.value, c2.value) for c1, c2 in sheet['A1': 'B6']]
data  = []
#Iterating by rows, ie row by row 
#index from 1
for row in sheet.iter_rows(min_row=2):  #sheet.max_row, sheet.max_column
    r = []
    for cell in row:
        r.append(cell.value)
    data.append(r)

rows = sheet.rows #generator, can not remove header 
###Handson - Exploring a dataset with pandas and matplotlib
#Use dataset containing all ATP matches played by the Swiss tennis player Roger Federer until 2012.

from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline

#Use 
player = 'Roger Federer'
df = pd.read_csv("https://raw.githubusercontent.com/ndas1971/Misc/master/federer.csv",
                 parse_dates=['start date'],
                 dayfirst=True)

df.head(3)

#select some 
df['win'] = df['winner'] == player
df['win'].tail()

#Calculate some 
won = 100 * df['win'].mean()
print(f"{player} has won {won:.0f}% of his matches.")

#Check some time dependent data 
date = df['start date']

#eg  proportion of double faults in each match 
df['dblfaults'] = (df['player1 double faults'] /
                   df['player1 total points total'])

#check 
df['dblfaults'].tail()

#stats 
df['dblfaults'].describe()

#Win per surface 
df.groupby('surface')['win'].mean()


#display the proportion of double faults as a function of the tournament date
gb = df.groupby('year')

#use the matplotlib plot_date() function because the x-axis contains dates:

fig, ax = plt.subplots(1, 1)
ax.plot_date(date.astype(datetime), df['dblfaults'], alpha=.25, lw=0)
ax.plot_date(gb['start date'].max().astype(datetime),  gb['dblfaults'].mean(), '-', lw=3)
ax.set_xlabel('Year')
ax.set_ylabel('Double faults per match')
ax.set_ylim(0)

#Reference 
pandas website at https://pandas.pydata.org/
pandas tutorial at http://pandas.pydata.org/pandas-docs/stable/10min.html
Python for Data Analysis, 2nd Edition, Wes McKinney, O'Reilly Media, at http://shop.oreilly.com/product/0636920050896.do


###ADAVANCED:  Storms database -- INTERNAL 
$ activate aiml 
$ conda install -c conda-forge cartopy

# www.ncdc.noaa.gov/ibtracs/index.php?name=wmo-data
url = "https://raw.githubusercontent.com/ndas1971/Misc/master/Allstorms.ibtracs_wmo.v03r05.csv"

The dataset contains information about most storms since 1848. 
A single storm may appear multiple times across several consecutive days.
1.Take Serial_Num,Season,Basin,Latitude,Longitude,

2. Obtain the average location of every storm

3. Use cartopy and draw the storm with stock image 

#Import 
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
%matplotlib inline

2.  Let's open the data with pandas:

# www.ncdc.noaa.gov/ibtracs/index.php?name=wmo-data
df = pd.read_csv("https://raw.githubusercontent.com/ndas1971/Misc/master/Allstorms.ibtracs_wmo.v03r05.csv")

#The dataset contains information about most storms since 1848. 
#A single storm may appear multiple times across several consecutive days.
Serial_Num,Season,Num,Basin,Sub_basin,Name,ISO_time,Nature,Latitude,Longitude,Wind(WMO),Pres(WMO),Center,Wind(WMO) Percentile,Pres(WMO) Percentile,Track_type
#Take Serial_Num,Season,Basin,Latitude,Longitude,
df[df.columns[[0, 1, 3, 8, 9]]].head()

#use pandas' groupby() function to obtain the average location of every storm:
dfs = df.groupby('Serial_Num')
pos = dfs[['Latitude', 'Longitude']].mean()
x = pos.Longitude.values
y = pos.Latitude.values
pos.head()

#display the storms on a map with cartopy. 
#This toolkit allows us to easily project the geographical coordinates on the map.
#the geodetic coordinate system (longitude and latitude) into the map's coordinate system, 
#called plate carrée

# We use a simple equirectangular projection,
# also called Plate Carree.
geo = ccrs.Geodetic()
crs = ccrs.PlateCarree()
# We create the map plot.
ax = plt.axes(projection=crs)
# We display the world map picture.
ax.stock_img()
# We display the storm locations.
ax.scatter(x, y, color='r', s=.5, alpha=.25, transform=geo)



###Many Other pandas Operations 



#other operations 
#Execute -0.3.pd_ops.py

Creation 
    list of dict, columnName:value,.. for each row
    numpy 2D, columns=list of columns , index?= list of index , optional 
    list of list(rows), columns=...
    columnName:list of col values
For conversion use, 
    pd.to_numeric(Series), 
    pd.to_datetime(Series, ,format='%Y %m %d'), 
    pd.to_timedelta(Series, unit='ns')
drop a column 
    df1.drop('C', inplace=True, axis=1) #axis=0, for row, axis=1 for column , default is row  
    df1.drop(0,  axis=0)  #0th row    
Rename 
    df1.rename(columns={'CC': 'C'}, inplace=True)
    df1.rename(columns=n_cols) # new column names 
Rename index 
    df1.index 
    df1.index  = [10,20]
    #or
    df1.index = [0,1]
    df1r = df1.rename({0:20, 1:30}, axis='index')
Copy and append 
    df1.copy()
    pd.concat([df1,df2], axis=0) #rowwise stack , same index repeated 
    pd.concat([df1,df2], axis=0).reset_index() #reseting index 
    pd.concat([df1,df2], axis=0, ignore_index=True) #reseting index 
    #or 
    df2.append(df1)    #index copied 
    df2.append(df1, ignore_index=True) #equivlent to reset_index
    #columnwise 
    res = pd.concat([df1,df11], axis=1)  #columnwise stack for same index
    res=pd.concat([df1,df1r], axis=1) #creates Nan
    res.columns =list( "ABCDEFGHIJ") #change column names(earlier has duplicates)
    
dropna, fillna , inplace=False 
    df5.dropna(axis=0, how='all') #row wise, if row consists of 'all' or 'any' Nan
    df5.dropna(axis=0, how='any')
    df5.dropna(axis=1, how='any')  #columnwise 
    df5.fillna(0)          #nan by 0 
    df5.fillna({'A': 0})   #only A column 
    
replace 
    df1.replace('1', 20)            #one valye by one value 
    df1.replace({'A':'1'}, 20)      #only for A 
    df1.replace({'A':{'1':20}})     #Only for A, '1'
    df1.replace({'A':'1'}, {'A':20}) #Another way 
    df1.replace(['1','2'], 20)      #multiple values 
    df1.replace(['1','2'], [20,30])
threeways replace 
    df5.fillna({'A': 0})
    df5.replace({'A':{np.nan:0}})
    df5.loc[df5.A.isnull(), 'A'] = 0 #df5.A.isnull() returns True/False for each row 
   
map(only for series, convert one value to other)
    df1.A.map({'1': 'cat', '2':'dog'}) #missing  = Nan 
    #or takes a fun (each element)
    df1.A.map(lambda e: 'cat', na_action='ignore') #NaN values would not be passed to fn 
    
apply for Series(fn takes each element) 
    df1.A.apply(lambda e: len(e))
    #or fn takes an ufunc 
    df1.AA.apply(np.log)

Conversion 
    df1.AA.apply(str)
    #or
    df1.AA.astype('str')
    df1.A.astype(np.float64) #conversion 
    df1[['A', 'A']].astype(np.float64) #works with DF as well 

applymap:DF (fn takes each element)
    df1[['A','B']].applymap(lambda e: len(e))

apply/agg(func_takes_eachCol)- axis=0/Col, 1/Row ,returns Series/DF ie each Column/row trnsfrmed to another scalar(eg np.sum)/column/row 
    df1[['A','B']].apply(lambda col : len(col)) #column wise , ie get each column value
    df1[['A','B']].apply(lambda col : len(col), axis=1) #rowwise, ie get each row value 
    df1[['AA', 'AA']].apply(np.sum)  #columnwise 
    df1[['AA', 'AA']].apply(np.sum, axis=1) #rowwise  
    #agg can take below type as well which is not possible with apply 
    df.agg("mean", axis=1) #rowwise 
    df.agg({'A' : ['sum', 'min'], 'B' : ['min', 'max']})
    df.agg(['sum', 'min'])

transform(func_takes_eachCol) - axis=0/Col, 1/Row ,returns DF ie each Column/row trnsfrmed to another column/row 
    df1.transform(np.log) #each column by np.log 
    (-df1).transform('abs')  #string function , must exist on Series/column 
    df1.transform({'A': np.log, 'B': 'abs'})
    df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 
    
pandas.merge(left, right,.../DataFrame.merge(right,...
    how='inner', 
    on=None/sameColName, left_on=None/LeftCOL, right_on=None/RightCol,      
    left_index=False/IsLeftSideWithIndexMerge, right_index=IsRightSideWithIndexMerge, 
    indicator=False)
sortcut - DataFrame.join(other, on=None, how='left', lsuffix='', rsuffix='', sort=False)
    indicator,If True, adds a column to output DataFrame called '_merge' with 
    information on the source of each row    
    #Example     
    pd.merge(ydf, zdf)
        Rows that appear in both ydf and zdf (Intersection).
    pd.merge(ydf, zdf, how='outer')
        Rows that appear in either or both ydf and zdf(Union).
    pd.merge(ydf, zdf, how='outer',indicator=True).query('_merge == "left_only"').drop(columns=['_merge'])
        Rows that appear in ydf but not zdf (Setdiff).
    
    
##Other Plots 
https://pandas.pydata.org/pandas-docs/stable/user_guide/visualization.html

#Execute - 0.3.pd_other_plots.py


###ADVANCED: advanced operations 
##Melt 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data, columns=['weekday',
        'Person 1', 'Person 2', 'Person 3'])
#output 
     weekday  Person 1  Person 2  Person 3
0     Monday        12        10         8
1    Tuesday         6         6         5
2  Wednesday         5        11         7

#How can you do group by on person 
#this is not normalized table 
#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
#output 
     weekday    Person  Score
0     Monday  Person 1     12
1    Tuesday  Person 1      6
2  Wednesday  Person 1      5

#umpivot 
#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
#output 
Person    Person 1  Person 2  Person 3
weekday
Friday          11         8         7
Monday          12        10         8
#reset_index()
pm2 = pm.reset_index()



##excel style pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

#or to get to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])

##Stack and Unstack 
DataFrame.unstack(level=-1, fill_value=None)
DataFrame.stack(level=-1, dropna=True)
    level : int, string, or list of these, default -1 (last level)
        Level(s) of index to unstack, can pass level name
    fill_value : replace NaN with this value if the unstack produces missing values
    dropna : boolean, default True
        Whether to drop rows in the resulting Frame/Series with no valid values

#Meanings 
stack(column->row): Move last level(default) or 'level' of MultiIndex column labels 
       into last level of row labels
unstack(row->column): Move last level(default) or 'level' of MultiIndex row labels 
       into last level of column labels

#The stack function moves out a level in the DataFrame's columns 
#to produce either:
    •A Series, in the case of a simple column Index
    •A DataFrame, in the case of a MultiIndex in the columns

#Example 
tuples = list(zip(*[['bar', 'bar', 'baz', 'baz',
                    'foo', 'foo', 'qux', 'qux'],
                   ['one', 'two', 'one', 'two',
                    'one', 'two', 'one', 'two']]))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 2), index=index, columns=['A', 'B'])
df2 = df[:4]
>>> df2
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401
      
stacked = df2.stack() #(column->row)
>>> stacked
first  second   
bar    one     A    0.721555
               B   -0.706771
       two     A   -1.039575
               B    0.271860
baz    one     A   -0.424972
               B    0.567020
       two     A    0.276232
               B   -1.087401
dtype: float64

>>> stacked.unstack() #(row->column)
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401

>>> stacked.unstack(1) #(row->column), level=1 (0-based) moved to column 
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

>>> stacked.unstack(0) #(row->column), level=0 (0-based)
first          bar       baz
second                      
one    A  0.721555 -0.424972
       B -0.706771  0.567020
two    A -1.039575  0.276232
       B  0.271860 -1.087401

#If the indexes have names
>>> stacked.unstack('second')#(row->column), level=1 (0-based)
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

##Combining stack/unstack with stats and GroupBy
columns = pd.MultiIndex.from_tuples([('A', 'cat'), ('B', 'dog'),
                                     ('B', 'cat'), ('A', 'dog')],
                                    names=['exp', 'animal'])
index = pd.MultiIndex.from_product([('bar', 'baz', 'foo', 'qux'),
                                    ('one', 'two')],
                                   names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 4), index=index, columns=columns)
>>> df
exp                  A         B                   A
animal             cat       dog       cat       dog
first second                                        
bar   one     0.895717  0.805244 -1.206412  2.565646
      two     1.431256  1.340309 -1.170299 -0.226169
baz   one     0.410835  0.813850  0.132003 -0.827317
      two    -0.076467 -1.187678  1.130127 -1.436737
foo   one    -1.413681  1.607920  1.024180  0.569605
      two     0.875906 -2.211372  0.974466 -2.006747
qux   one    -0.410001 -0.078638  0.545952 -1.219217
      two    -1.226825  0.769804 -1.281247 -0.727707
      
#(column->row), then mean rowwise (index (0), columns (1)), then (row->column)
#here axis=0 means columnwise , =1 mean rowwise
>>> df.stack().mean(1).unstack() 
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048

# same result, another way
#axis : int, default 0, axis=0 means columnwise , =1 mean rowwise
#level : int, level name, or sequence of such, default None
#If the axis is a MultiIndex (hierarchical), group by a particular level or levels
>>> df.groupby(level=1, axis=1).mean()
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048
#(column->row),
>>> df.stack().groupby(level=1).mean()
exp            A         B
second                    
one     0.071448  0.455513
two    -0.424186 -0.204486
#(row->column)
>>> df.mean().unstack(0)
exp            A         B
animal                    
cat     0.060843  0.018596
dog    -0.413580  0.232430



##Compute a simple cross-tabulation of two (or more) factors
pandas.crosstab(index, columns, values=None, rownames=None, colnames=None, 
        aggfunc=None, margins=False, margins_name='All', 
        dropna=True, normalize=False)
    index : array-like, Series, or list of arrays/Series
        Values to group by in the rows
    columns : array-like, Series, or list of arrays/Series
        Values to group by in the columns
    values : array-like, optional
        Array of values to aggregate according to the factors. 
        Requires aggfunc be specified.
    aggfunc : function, optional
        If specified, requires values be specified as well
    rownames : sequence, default None
        If passed, must match number of row arrays passed
    colnames : sequence, default None
        If passed, must match number of column arrays passed
    margins : boolean, default False
        Add row/column margins (subtotals)
    margins_name : string, default 'All'
        Name of the row / column that will contain the totals when margins is True.
    dropna : boolean, default True
        Do not include columns whose entries are all NaN
    normalize : boolean, {'all', 'index', 'columns'}, or {0,1}, default False
        Normalize by dividing all values by the sum of values.
        •If passed 'all' or True, will normalize over all values.
        •If passed 'index' will normalize over each row.
        •If passed 'columns' will normalize over each column.
        •If margins is True, will also normalize margin values.

#Example 
df = pd.DataFrame({'A': [1, 2, 2, 2, 2], 'B': [3, 3, 4, 4, 4],
                   'C': [1, 1, np.nan, 1, 1]})
>>> df
   A  B    C
0  1  3  1.0
1  2  3  1.0
2  2  4  NaN
3  2  4  1.0
4  2  4  1.0
>>> pd.crosstab(df.A, df.B)
B  3  4
A      
1  1  0
2  1  3
>>> pd.crosstab(df.A, df.B, values=df.C, aggfunc=np.sum, normalize=True,margins=True)
B       3    4   All
A                   
1    0.25  0.0  0.25
2    0.25  0.5  0.75
All  0.50  0.5  1.00

foo = pd.Categorical(['a', 'b'], categories=['a', 'b', 'c'])
bar = pd.Categorical(['d', 'e'], categories=['d', 'e', 'f'])
>>> pd.crosstab(foo, bar)
col_0  d  e  f
row_0         
a      1  0  0
b      0  1  0
c      0  0  0
    

DataFrame.groupby(by=None, axis=0, level=None, as_index=True, sort=True, group_keys=True, squeeze=False, **kwargs)
    Returns DataFrameGroupBy or SeriesGroupBy
    When aggregation function is applied on returned type,
    final return would be DataFrame or Series respectively 
    Parameters:
    by can be 
        •A Python function, to be called on the axis labels(axis=0, with Index, axis=1, with Columns)
        •A list or NumPy array of the same length as the selected axis
        •A dict or Series, providing a label -> group name mapping
        •For DataFrame objects, a string indicating a column to be used to group. 
         df.groupby('A') is just syntactic sugar for df.groupby(df['A']), 
        •For DataFrame objects, a string indicating an index level to be used to group.
        •A list of any of the above things
        •A Grouper object 
    axis : int, default 0(index, columnwise)
    level : int, level name, or sequence of such, default None
        If the axis is a MultiIndex (hierarchical), group by a particular level or levels
    as_index : boolean, default True
        For aggregated output, return object with group labels as the index. 
        Only relevant for DataFrame input. as_index=False is effectively "SQL-style' grouped output
    sort : boolean, default True
        Sort group keys. Get better performance by turning this off. 
    group_keys : boolean, default True
        When calling apply, add group keys to index to identify pieces
    squeeze : boolean, default False
        reduce the dimensionality of the return type if possible, 
        otherwise return a consistent type
        
# default is axis=0,columnwise
>>> grouped = obj.groupby(key)
>>> grouped = obj.groupby(key, axis=1)
>>> grouped = obj.groupby([key1, key2])

#Example 
#DataFrame results
>>> data.groupby(func, axis=0).mean()
>>> data.groupby(['col1', 'col2'])['col3'].mean() #


#Example 
df = pd.read_excel("./data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225
>>> g =df.groupby('order')
>>> g.groups  #[row lables for group]
{10001: Int64Index([0, 1, 2], dtype='int64'), 10005: Int64Index([3,4,5,6,7], dtype='int64'), 10006: Int64Index([8, 9, 10, 11], dtype='int64

>>> g.indices
{10001: array([0, 1, 2], dtype=int64), 10005: array([3, 4, 5, 6]...), 10006: array([ 8,  9, 10, 11], dtype=int64)}

>>> g.ngroup()  #row_index vs group_index 
0     0
1     0
2     0
3     1
4     1
5     1
6     1
7     1
8     2
9     2
10    2
11    2
dtype: int64
>>> g.size() #group size
order
10001    3
10005    5
10006    4
dtype: int64



#Q= "What percentage of the order total does each sku represent?"
#First Approach - Merging(joining like SQL JOIN)
#Series with index =order 
>>> df.groupby('order')["ext price"].sum().rename("Order_Total")
order
10001     576.12
10005    8185.49
10006    3724.49
Name: Order_Total, dtype: float64

>>> df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
   order  Order_Total
0  10001       576.12
1  10005      8185.49
2  10006      3724.49

#how to combine this data back with the original dataframe. 
order_total = df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
df_1 = df.merge(order_total, on='order')
>>> df_1.head(3)
   account      name  order       sku  quantity  unit price  ext price  \
0   383080  Will LLC  10001  B1-20000         7       33.69     235.83
1   383080  Will LLC  10001  S1-27722        11       21.12     232.32
2   383080  Will LLC  10001  B1-86481         3       35.99     107.97

   Order_Total
0       576.12
1       576.12
2       576.12
df_1["Percent_of_Order"] = df_1["ext price"] / df_1["Order_Total"]


#Second Approach - Using Transform
>>> df.groupby('order')["ext price"]
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]



DataFrameGroupBy.agg(arg, *args, **kwargs)
    Aggregate using callable, string, dict, or list of string/callables
    Check further description from DataFrame.aggregate
    Parameters:
    func : callable, string, dictionary, or list of string/callables
        Accepted Combinations are:
        •string function name
        •function
        •list of functions
        •dict of column names -> functions (or list of functions)
 
#Examples
df = pd.DataFrame({'A': [1, 1, 2, 2],
                    'B': [1, 2, 3, 4],
                    'C': np.random.randn(4)})
>>> df
   A  B         C
0  1  1  0.362838
1  1  2  0.227877
2  2  3  1.267767
3  2  4 -0.562860

#The aggregation is for each column.
>>> df.groupby('A').agg('min')
   B         C
A
1  1  0.227877
2  3 -0.562860
#Multiple aggregations
>>> df.groupby('A').agg(['min', 'max'])
    B             C
  min max       min       max
A
1   1   2  0.227877  0.362838
2   3   4 -0.562860  1.267767

#Select a column for aggregation
>>> df.groupby('A').B.agg(['min', 'max'])
   min  max
A
1    1    2
2    3    4

#Different aggregations per column
>>> df.groupby('A').agg({'B': ['min', 'max'], 'C': 'sum'})
    B             C
  min max       sum
A
1   1   2  0.590716
2   3   4  0.704907




GroupBy.apply(func, *args, **kwargs)
    Apply function func group-wise and combine the results together.
    The function passed to apply must take a dataframe as its first argument 
    and return a dataframe, a series or a scalar. 
    Parameters:
        func : function
            A callable that takes a dataframe as its first argument, 
            and returns a dataframe, a series or a scalar. 
            In addition the callable may take positional and keyword arguments
            Note dataframe is each group with remaining columns 
        args, kwargs : tuple and dict
            Optional positional and keyword arguments to pass to func
 

#In the current implementation apply calls func twice on the first group to decide 
#whether it can take a fast or slow code path. 
#Examples
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})
g = df.groupby('A')

#Example 1: below the function passed to apply takes a dataframe as its argument 
#and returns a dataframe. Dataframe is each group with remaining columns 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x / x.sum())
          B    C
0  0.333333  0.4
1  0.666667  0.6
2  1.000000  1.0

#Example 2: The function passed to apply takes a dataframe as its argument 
#and returns a series. 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x.max() - x.min())
   B  C
A
a  1  2
b  0  0

#Example 3: The function passed to apply takes a dataframe as its argument 
#and returns a scalar. 
#apply combines the result for each group together into a series, 
#including setting the index as appropriate:
>>> g.apply(lambda x: x.C.max() - x.B.min())
A
a    5
b    2
dtype: int64


GroupBy.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) of each group one by one 
        Accepted Combinations are:
            •string function name
            •function
            •list of functions
            •dict of column names -> functions (or list of functions)
    * apply implicitly passes all the columns for each group as a DataFrame to the custom function,
      while transform passes each column for each group as a Series to the custom function
    * The custom function passed to apply can return a scalar, or a Series or DataFrame (or numpy array or even list). 
      The custom function passed to transform must return a sequence (a one dimensional Series, array or list) 
      the same length as the group.
    
#Example 
df = pd.read_clipboard()
    A      B         C         D
0  foo    one  0.162003  0.087469
1  bar    one -1.156319 -1.526272
2  foo    two  0.833892 -1.666304
3  bar  three -2.026673 -0.322057
4  foo    two  0.411452 -0.954371
5  bar    two  0.765878 -0.095968
6  foo    one -0.654890  0.678091
7  foo  three -1.789842 -1.130922


#OK as X is each group as DF and see bothe C and D 
> df.groupby('A').apply(lambda x: (x['C'] - x['D']))
> df.groupby('A').apply(lambda x: (x['C'] - x['D']).mean())


#But below is not OK , 
> df.groupby('A').transform(lambda x: (x['C'] - x['D']))
ValueError: could not broadcast input array from shape (5) into shape (5,3)

> df.groupby('A').transform(lambda x: (x['C'] - x['D']).mean())
 TypeError: cannot concatenate a non-NDFrame object
 
#Actual usage of Transform ,  
zscore = lambda x: (x - x.mean()) / x.std() # Note that it does not reference anything outside of 'x' and for transform 'x' is one column.
>>> df.groupby('A').transform(zscore) #for each column of each group 

       C      D
0  0.989  0.128
1 -0.478  0.489
2  0.889 -0.589
3 -0.671 -1.150
4  0.034 -0.285
5  1.149  0.662
6 -1.404 -0.907
7 -0.509  1.653
#But 
>>> df.groupby('A').apply(zscore) 
ValueError: operands could not be broadcast together with shapes (6,) (2,)

#Which is exactly the same 
>>> df.groupby('A')['C'].transform(zscore)
#or 
>>> (df.groupby('A')['C'].apply(zscore))
0    0.989
1   -0.478
2    0.889
3   -0.671
4    0.034
5    1.149
6   -1.404
7   -0.509

#Another Usecase:- trying to assign results of reduction function back to original dataframe.
df['sum_C'] = df.groupby('A')['C'].transform(sum)
df.sort('A') # to clearly see the scalar ('sum') applies to the whole column of the group
#Output 
     A      B      C      D  sum_C
1  bar    one  1.998  0.593  3.973
3  bar  three  1.287 -0.639  3.973
5  bar    two  0.687 -1.027  3.973
4  foo    two  0.205  1.274  4.373
2  foo    two  0.128  0.924  4.373
6  foo    one  2.113 -0.516  4.373
7  foo  three  0.657 -1.179  4.373
0  foo    one  1.270  0.201  4.373

#Trying the same with .apply would give NaNs in sum_C. 
#Because .apply would return a reduced Series, which it does not know how to broadcast back:
df.groupby('A')['C'].apply(sum)
#Output 
A
bar    3.973
foo    4.373

#There are also cases when .transform is used to filter the data:
df[df.groupby(['B'])['D'].transform(sum) < -1]

     A      B      C      D
3  bar  three  1.287 -0.639
7  foo  three  0.657 -1.179







GroupBy.pipe(func, *args, **kwargs)
    Apply a function with arguments to this GroupBy object,
    Parameters:
    func : callable or tuple of (callable, string)
        Function to apply to this GroupBy object or, 
        alternatively, a (callable, data_keyword) tuple 
        where data_keyword is a string indicating the keyword of callable that expects the GroupBy object.
        Note function gets full groupedBy dataframe with it's groupby column as index 
    args : iterable, optional
        positional arguments passed into func.
    kwargs : dict, optional
        a dictionary of keyword arguments passed into func.
 
#Use .pipe when chaining together functions that expect Series, DataFrames or GroupBy objects. 
#Instead of writing
>>> f(g(h(df.groupby('group')), arg1=a), arg2=b, arg3=c)
#You can write
>>> (df
        .groupby('group')
        .pipe(f, arg1)
        .pipe(g, arg2)
        .pipe(h, arg3))
        

df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})
>>> df
   A  B
0  a  1
1  b  2
2  a  3
3  b  4


#To get the difference between each groups maximum and minimum value in one pass, you can do
>>> df.groupby('A').pipe(lambda g: g.max() - g.min()) #g is groupedFataframe 
   B
A
a  2
b  2


##Difference between pipe and apply 
#Pipe function takes entire Groupby result DataFrame including groupby columns as index 
#Apply function takes only DF of each group's remaining columns (excluding groupby columns)

df = pd.DataFrame(dict(
    A=list('XXXXYYYYYY'),
    B=range(10)
))

   A  B
0  X  0
1  X  1
2  X  2
3  X  3
4  Y  4
5  Y  5
6  Y  6
7  Y  7
8  Y  8
9  Y  9

#Example 1
#Make the entire 'B' column sum to 1 while each sub-group sums to the same amount. 
#This requires that the calculation be aware of how many groups exist. 
#This is something we can't do with apply because apply wouldn't know how many groups exist.
s = df.groupby('A').B.pipe(lambda g: df.B / g.transform('sum') / g.ngroups)
s

0    0.000000
1    0.083333
2    0.166667
3    0.250000
4    0.051282
5    0.064103
6    0.076923
7    0.089744
8    0.102564
9    0.115385
Name: B, dtype: float64

#Note:
s.sum()

0.99999999999999989

#And:
s.groupby(df.A).sum()

A
X    0.5
Y    0.5
Name: B, dtype: float64


#Example 2 -  Subtract the mean of one group from the values of another. 
#Again, this can't be done with apply because apply doesn't know about other groups.
df.groupby('A').B.pipe(
    lambda g: (
        g.get_group('X') - g.get_group('Y').mean()
    ).append(
        g.get_group('Y') - g.get_group('X').mean()
    )
)

0   -6.5
1   -5.5
2   -4.5
3   -3.5
4    2.5
5    3.5
6    4.5
7    5.5
8    6.5
9    7.5
Name: B, dtype: float64



DataFrameGroupBy.filter(func, dropna=True, *args, **kwargs)
    Return a copy of a DataFrame excluding elements from groups 
    that do not satisfy the boolean criterion specified by func.
    Parameters:
        f : function
            Function to apply to each subframe. Should return True or False.
            f takes full DF 
        dropna : Drop groups that do not pass the filter. True by default;
            if False, groups that evaluate False are filled with NaNs.
    Returns:
    filtered : DataFrame 


#Example 
import pandas as pd
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})
grouped = df.groupby('A')
>>> grouped.filter(lambda x: x['B'].mean() > 3.)
     A  B    C
1  bar  2  5.0
3  bar  4  1.0
5  bar  6  9.0



###Seaborn 
https://seaborn.pydata.org/
Seaborn is a library for making statistical graphics in Python. 
It builds on top of matplotlib and integrates closely with pandas data structures.


An introduction to seaborn
https://seaborn.pydata.org/tutorial/introduction.html
API 
https://seaborn.pydata.org/api.html


Terminologies 
'hue' is used to visualize the data of different categories in one plot. 
'palette' is used to change the colour of the plot.


Most functions accept data represented with objects from the pandas 
or numpy libraries as well as built-in Python types like lists and dictionaries.
https://seaborn.pydata.org/tutorial/data_structure.html
    When plotting x against y, each variable should be a vector. 
    
    A long-form data(normal 2D data) table has the following characteristics:
        Each variable is a column
        Each observation is a row
        #Example 
        flights = sns.load_dataset("flights")
        flights.head()
        #For example, making a monthly plot of the number of passengers per year looks like this:
        sns.relplot(data=flights, x="year", y="passengers", hue="month", kind="line")
        
        Many pandas operations, such as the split-apply-combine operations of a group-by, 
        will produce a dataframe where information has moved from the columns of the input dataframe 
        to the index of the output. 
        So long as the name is retained, you can still reference the data as normal:

        flights_avg = flights.groupby("year").mean(numeric_only=True)
        sns.relplot(data=flights_avg, x="year", y="passengers", kind="line")

        Additionally, it's possible to pass vectors of data directly as arguments to x, y, 
        and other plotting variables. 
        If these vectors are pandas objects, the name attribute will be used to label the plot:

        year = flights_avg.index
        passengers = flights_avg["passengers"]
        sns.relplot(x=year, y=passengers, kind="line")

        Numpy arrays and other objects that implement the Python sequence interface work too, 
        but if they don't have names, the plot will not be as informative without further tweaking:

        sns.relplot(x=year.to_numpy(), y=passengers.to_list(), kind="line")

        
        
    A wide form  is generally meant for spreadsheet, where the columns and rows 
        contain levels of different variables
        #Example 
        flights_wide = flights.pivot(index="year", columns="month", values="passengers")
        flights_wide.head()
        month 	Jan 	Feb 	Mar 	Apr 	May 	Jun 	Jul 	Aug 	Sep 	Oct 	Nov 	Dec
        year 												
        1949 	112 	118 	132 	129 	121 	135 	148 	148 	136 	119 	104 	118
        1950 	115 	126 	141 	135 	125 	149 	170 	170 	158 	133 	114 	140
        1951 	145 	150 	178 	163 	172 	178 	199 	199 	184 	162 	146 	166
        1952 	171 	180 	193 	181 	183 	218 	230 	242 	209 	191 	172 	194
        1953 	196 	196 	236 	235 	229 	243 	264 	272 	237 	211 	180 	201
        
        Seaborn treats the argument to data as wide form when neither x nor y are assigned.
        #Example of above Long form 
        sns.relplot(data=flights_wide, kind="line")
        
        Seaborn has assigned the index of the dataframe to x, the values of the dataframe to y, 
        and it has drawn a separate line for each month
        
        #Equivalent to 
        #Long form 
        sns.relplot(data=flights, x="month", y="passengers", hue="year", kind="line")
        #wide form 
        sns.relplot(data=flights_wide.transpose(), kind="line")
        
        The example we saw above used a rectangular pandas.DataFrame, as a collection of its columns. 
        A dict or list of pandas objects will also work, but we'll lose the axis labels:

        flights_wide_list = [col for _, col in flights_wide.items()]
        sns.relplot(data=flights_wide_list, kind="line")

        The vectors in a collection do not need to have the same length. 
        If they have an index, it will be used to align them:

        two_series = [flights_wide.loc[:1955, "Jan"], flights_wide.loc[1952:, "Aug"]]
        sns.relplot(data=two_series, kind="line")

        Whereas an ordinal index will be used for numpy arrays or simple Python sequences:

        two_arrays = [s.to_numpy() for s in two_series]
        sns.relplot(data=two_arrays, kind="line")

        But a dictionary of such vectors will at least use the keys:

        two_arrays_dict = {s.name: s.to_numpy() for s in two_series}
        sns.relplot(data=two_arrays_dict, kind="line")

        Rectangular numpy arrays are treated just like a dataframe without index information, 
        so they are viewed as a collection of column vectors. 
        Note that this is different from how numpy indexing operations work, 
        where a single indexer will access a row. 
        But it is consistent with how pandas would turn the array into a dataframe 
        or how matplotlib would plot it:

        flights_array = flights_wide.to_numpy()
        sns.relplot(data=flights_array, kind="line")


        
    Some dataset are messy 
        If datasets that are clearly long-form or wide-form are 'tidy',
        we might say that these more ambiguous datasets are 'messy'
        #Example 
        anagrams = sns.load_dataset("anagrams")
        anagrams

          subidr attnr 	  num1 	num2 	num3
        0 	1 	divided 	2 	4.0 	7
        1 	2 	divided 	3 	4.0 	5
        2 	3 	divided 	3 	5.0 	6
        3 	4 	divided 	5 	7.0 	5
        4 	5 	divided 	4 	5.0 	8
        ....
        12 	13 	focused 	6 	5.0 	9
        13 	14 	focused 	8 	8.0 	7
        14 	15 	focused 	8 	8.0 	7
        15 	16 	focused 	6 	8.0 	7
        
        The attention variable is between-subjects, 
        but there is also a within-subjects variable: the number of possible solutions 
        to the anagrams, which varied from 1 to 3
        
        How might we tell seaborn to plot the average score as a function 
        of attention and number of solutions?
        #Example 
        anagrams_long = anagrams.melt(id_vars=["subidr", "attnr"], var_name="solutions", value_name="score")
        anagrams_long.head()

          subidr attnr 	solutions 	score
        0 	1 	divided 	num1 	2.0
        1 	2 	divided 	num1 	3.0
        
        sns.catplot(data=anagrams_long, x="solutions", y="score", hue="attnr", kind="point")
        
        
https://seaborn.pydata.org/tutorial/objects_interface.html
The seaborn.objects namespace was introduced in version 0.12 
    as a completely new interface for making seaborn plots  
    he seaborn.objects namespace will provide access to all of the relevant classes. The most important is Plot
    #Example 
    import seaborn.objects as so    
            (
        so.Plot(penguins, x="bill_length_mm", y="bill_depth_mm")
        .add(so.Dot(color="g", pointsize=4))
    )
    (
        so.Plot(
            penguins, x="bill_length_mm", y="bill_depth_mm",
            edgecolor="sex", edgewidth="body_mass_g",
        )
        .add(so.Dot(color=".8"))
    )
    The Dot class is an example of a Mark
    See the Mark properties 
    https://seaborn.pydata.org/tutorial/properties.html
    
    The Dot mark represents each data point independently, so the assignment of a variable 
    to a property only has the effect of changing each dot's appearance. 
    #Example 
    (
    so.Plot(healthexp, x="Year", y="Life_Expectancy", color="Country")
    .add(so.Line())
    )
    
    As with many seaborn functions, the objects interface supports statistical transformations. 
    These are performed by Stat objects, such as Agg:
    (
        so.Plot(penguins, x="species", y="body_mass_g")
        .add(so.Bar(), so.Agg())
    )
    
    The objects interface more cleanly separates representation and transformation, 
    allowing you to compose Mark and Stat objects:
    (
        so.Plot(penguins, x="species", y="body_mass_g")
        .add(so.Dot(pointsize=10), so.Agg())
    )


seaborn functions as 'axes-level' or 'figure-level'. 

Figure level 
    Each module has a single figure-level function, which offers a unitary interface 
    to its various axes-level functions. 
    eg 
    relational - relplot (Figure level)
    https://seaborn.pydata.org/tutorial/relational.html
        how variables in a dataset relate to each other 
        and how those relationships depend on other variables. 
    axes-level
        scatterplot() (with kind="scatter"; the default)
        lineplot() (with kind="line")
    #Example 
    sns.relplot( data=tips, x="total_bill", y="tip", hue="smoker", style="time")

        
    Distributions- jointplot(),  pairplot(), displot (Figure-level)
    https://seaborn.pydata.org/tutorial/distributions.html
    histplot(), kdeplot(), ecdfplot(), and rugplot() (axes-level)
        What range do the observations cover? What is their central tendency? 
        Are they heavily skewed in one direction? 
        Is there evidence for bimodality? 
        Are there significant outliers?    
    #Example (Figure-level)
    penguins = sns.load_dataset("penguins")
    sns.displot(data=penguins, x="flipper_length_mm", hue="species", multiple="stack")
    
    https://seaborn.pydata.org/tutorial/function_overview.html#combining-multiple-views-on-the-data
    jointplot() plots the relationship or joint distribution of two variables 
    while adding marginal axes that show the univariate distribution of each one separately:
    
    sns.jointplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", hue="species")
    sns.jointplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", hue="species", kind="hist")

    pairplot() is similar — it combines joint and marginal views — 
    but rather than focusing on a single relationship, 
    it visualizes every pairwise combination of variables simultaneously:

    sns.pairplot(data=penguins, hue="species")
    
        
   Categorical - catplot(Figurelevel)
   https://seaborn.pydata.org/tutorial/categorical.html
   when one of the main variables is 'categorical' (divided into discrete groups)
   which is independent,x and depending on y
   Axes-level
       Categorical scatterplots:
            stripplot() (with kind="strip"; the default)
            swarmplot() (with kind="swarm")
        Categorical distribution plots:
            boxplot() (with kind="box")
            violinplot() (with kind="violin")
            boxenplot() (with kind="boxen")
        Categorical estimate plots:
            pointplot() (with kind="point")
            barplot() (with kind="bar")
            countplot() (with kind="count")
    #Example 
    tips = sns.load_dataset("tips")
    sns.catplot(data=tips, x="day", y="total_bill", hue="smoker", kind="box")
    
    Note figure-level functions cannot (easily) be composed with other plots. 
    By design, they 'own' their own figure, including its initialization
    
    The figure-level functions return a FacetGrid instance,
    https://seaborn.pydata.org/generated/seaborn.FacetGrid.html#seaborn.FacetGrid
    g = sns.FacetGrid(penguins, col="sex", height=3.5, aspect=.75)
    
    #EXample 
    tips = sns.load_dataset("tips")
    g = sns.relplot(data=tips, x="total_bill", y="tip")
    g.ax.axline(xy1=(10, 2), slope=.2, color="b", dashes=(5, 2))
    
    FacetGrid has few methods for customizing 
    g = sns.relplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", col="sex")
    g.set_axis_labels("Flipper length (mm)", "Bill length (mm)")

            
axes-level
    #Example 
    f, axs = plt.subplots(1, 2, figsize=(8, 4), gridspec_kw=dict(width_ratios=[4, 3]))
    sns.scatterplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", hue="species", ax=axs[0])
    sns.histplot(data=penguins, x="species", hue="species", shrink=.8, alpha=.8, legend=False, ax=axs[1])
    f.tight_layout()
    
Functions for drawing linear regression models
    regplot()-axieslevel and lmplot()-figurelevel(lmplot has hue)
    draw a scatterplot of two variables, x and y, 
    and then fit the regression model y ~ x and plot the resulting regression line 
    and a 95% confidence interval for that regression:
    
    #Example - regplot accepts simple numpy arrays, pandas.Series objects, 
    #or as references to variables in a pandas.DataFrame object passed to data
    tips = sns.load_dataset("tips")
    sns.regplot(x="total_bill", y="tip", data=tips);
    #OR - lmplot must have data=data and xy are string of column name 
    sns.lmplot(x="total_bill", y="tip", data=tips);
    
    It's possible to fit a linear regression when one of the variables takes discrete values
    But it does not look good
    
    One option is to add some random noise ('jitter') to the discrete values 
    to make the distribution of those values more clear. 
    Note that jitter is applied only to the scatterplot data 
    and does not influence the regression line fit itself:

    sns.lmplot(x="size", y="tip", data=tips, x_jitter=.05);

    OR it is good to collapse over the observations in each discrete bin to plot 
    an estimate of central tendency along with a confidence interval
    
    sns.lmplot(x="size", y="tip", data=tips, x_estimator=np.mean);
    
    #Fitting different kinds of models
    anscombe = sns.load_dataset("anscombe")
    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'II'"), ci=None, scatter_kws={"s": 80})
    
    the plot clearly shows that this is not a good model
    
    lmplot() and regplot() can fit a polynomial regression model to explore 
    simple kinds of nonlinear trends in the dataset(order=2):

    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'II'"),order=2, ci=None, scatter_kws={"s": 80})

    A different problem is posed by 'outlier' observations that deviate for some reason 
    other than the main relationship under study:

    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'III'"), ci=None, scatter_kws={"s": 80})

    In the presence of outliers, it can be useful to fit a robust regression, 
    which uses a different loss function to downweight relatively large residuals:

    sns.lmplot(x="x", y="y", data=anscombe.query("dataset == 'III'"), robust=True, ci=None, scatter_kws={"s": 80});

    When the y variable is binary, simple linear regression also 'works' 
    but provides implausible predictions:

    tips["big_tip"] = (tips.tip / tips.total_bill) > .15
    sns.lmplot(x="total_bill", y="big_tip", data=tips, y_jitter=.03);

    The solution in this case is to fit a logistic regression, 
    such that the regression line shows the estimated probability of y = 1 for a given value of x:

    sns.lmplot(x="total_bill", y="big_tip", data=tips, logistic=True, y_jitter=.03);

    As the confidence interval around the regression line is computed using a bootstrap procedure, 
    you may wish to turn this off for faster iteration (using ci=None).

    An altogether different approach is to fit a nonparametric regression using a lowess smoother. 
    This approach has the fewest assumptions, although it is computationally intensive 
    and so currently confidence intervals are not computed at all:

    sns.lmplot(x="total_bill", y="tip", data=tips,lowess=True, line_kws={"color": "C1"});

    The residplot() function can be a useful tool for checking whether 
    the simple regression model is appropriate for a dataset. 
    It fits and removes a simple linear regression and then plots the residual values 
    for each observation. 

    Ideally, these values should be randomly scattered around y = 0:

    sns.residplot(x="x", y="y", data=anscombe.query("dataset == 'I'"), scatter_kws={"s": 80});

    If there is structure in the residuals, 
    it suggests that simple linear regression is not appropriate:

    sns.residplot(x="x", y="y", data=anscombe.query("dataset == 'II'"),scatter_kws={"s": 80});

    #Conditioning on other variables
    how does the relationship between these two variables change as a function of a third variable?

    This is where the main differences between regplot() and lmplot() appear. 
    While regplot() always shows a single relationship, 
    lmplot() combines regplot() with FacetGrid to show multiple fits using hue mapping or faceting.

    The best way to separate out a relationship is to plot both levels on the same axes 
    and to use color to distinguish them:

    sns.lmplot(x="total_bill", y="tip", hue="smoker", data=tips);

    Unlike relplot(), it's not possible to map a distinct variable to the style properties 
    of the scatter plot, but you can redundantly code the hue variable with marker shape:

    sns.lmplot(x="total_bill", y="tip", hue="smoker", data=tips,  markers=["o", "x"], palette="Set1");

    To add another variable, you can draw multiple 'facets' with each level of the variable 
    appearing in the rows or columns of the grid:

    sns.lmplot(x="total_bill", y="tip", hue="smoker", col="time", data=tips);
    sns.lmplot(x="total_bill", y="tip", hue="smoker", col="time", row="sex", data=tips, height=3);

    #Plotting a regression in other contexts
    A few other seaborn functions use regplot() in the context of a larger, more complex plot. 
    The first is the jointplot() function . jointplot() can use regplot() to show the linear regression 
    fit on the joint axes by passing kind="reg":

    sns.jointplot(x="total_bill", y="tip", data=tips, kind="reg");

    Using the pairplot() function with kind="reg" combines regplot() and PairGrid 
    to show the linear relationship between variables in a dataset. 

    Take care to note how this is different from lmplot(). In the figure below, 
    the two axes don't show the same relationship conditioned on two levels of a third variable; 
    rather, PairGrid() is used to show multiple relationships between different pairings 
    of the variables in a dataset:

    sns.pairplot(tips, x_vars=["total_bill", "size"], y_vars=["tip"], height=5, aspect=.8, kind="reg");

    Conditioning on an additional categorical variable is built into both of these functions 
    using the hue parameter:

    sns.pairplot(tips, x_vars=["total_bill", "size"], y_vars=["tip"], hue="smoker", height=5, aspect=.8, kind="reg");



Statistical estimation and error bars
    When showing a summary statistic(mean/median), it is usually appropriate to add error bars, 
    which provide a visual cue about how well the summary represents the underlying data points.

    The error bars around an estimate of central tendency can show one of two general things: 
    either the range of uncertainty about the estimate 
    or the spread of the underlying data around it. 
    
    These measures are related: given the same sample size, 
    estimates will be more uncertain when data has a broader spread. 
    But uncertainty will decrease as sample sizes grow, whereas spread will not.

    In seaborn, there are two approaches for constructing each kind of error bar.
    
    One approach is parametric, using a formula that relies on assumptions 
    about the shape of the distribution. 
    The other approach is nonparametric, using only the data that you provide.

    Your choice is made with the errorbar parameter, This parameter accepts the name 
    of the method to use and, optionally, a parameter that controls the size of the interval. 
    
    The choices can be defined in a 2D taxonomy that depends on what is shown and how it is constructed:

                    spread                              Uncertainity 
    Parametric      std dev, errorbar=('sd', scale)     std error , errorbar=('se', scale)

    Non-parametric   percentile interval                confidence interval 
                      errorbar=('pi', width)            errorbar=('ci', width)

    You will note that the size parameter is defined differently 
    for the parametric and nonparametric approaches. 
    
    For parametric error bars, it is a scalar factor that is multiplied 
    by the statistic defining the error (standard error or standard deviation). 
    
    For nonparametric error bars, it is a percentile width.

    Error bars that represent data spread present a compact display of the distribution, 
    using three numbers where boxplot() would use 5 or more a
    nd violinplot() would use a complicated algorithm.
    
    #Example 
    def plot_errorbars(arg, **kws):
        np.random.seed(sum(map(ord, "error_bars")))
        x = np.random.normal(0, 1, 100)
        f, axs = plt.subplots(2, figsize=(7, 2), sharex=True, layout="tight")
        sns.pointplot(x=x, errorbar=arg, **kws, capsize=.3, ax=axs[0])
        sns.stripplot(x=x, jitter=.3, ax=axs[1])
    
    #Standard deviation error bars
    By default, errorbar="sd" will draw error bars at +/- 1 sd around the estimate,
    but the range can be increased by passing a scaling size parameter. 
    
    Note that, assuming normally-distributed data, ~68% of the data will lie 
    within one standard deviation, ~95% will lie within two, a
    nd ~99.7% will lie within three:
    
    plot_errorbars("sd")

    #Percentile interval error bars
    Percentile intervals also represent the range where some amount of the data fall, 
    but they do so by computing those percentiles directly from your sample. 
    
    By default, errorbar="pi" will show a 95% interval, ranging from the 2.5 to the 97.5 percentiles. 
    You can choose a different range by passing a size parameter, 
    e.g., to show the inter-quartile range:

    plot_errorbars(("pi", 50))

    The standard deviation error bars will always be symmetrical around the estimate. 
    This can be a problem when the data are skewed, especially if there are natural bounds 
    (e.g., if the data represent a quantity that can only be positive). 
    
    In some cases, standard deviation error bars may extend to 'impossible' values. 
    The nonparametric approach does not have this problem, 
    because it can account for asymmetrical spread 
    and will never extend beyond the range of the data.

    #Measures of estimate uncertainty
    If your data are a random sample from a larger population, 
    then the mean (or other estimate) will be an imperfect measure of the true population average. 
    Error bars that show estimate uncertainty try to represent the range of likely values 
    for the true parameter.
    
    #Standard error bars
    The standard error statistic is related to the standard deviation:
    in fact it is just the standard deviation divided by the square root of the sample size. 
    The default, with errorbar="se", draws an interval +/-1 standard error from the mean:

    plot_errorbars("se")

    #Confidence interval error bars
    The nonparametric approach to representing uncertainty uses bootstrapping: 
    a procedure where the dataset is randomly resampled with replacement a number of times, 
    and the estimate is recalculated from each resample. 
    This procedure creates a distribution of statistics approximating 
    the distribution of values that you could have gotten for your estimate
    if you had a different sample.

    The confidence interval is constructed by taking a percentile interval 
    of the bootstrap distribution. 
    By default errorbar="ci" draws a 95% confidence interval:

    plot_errorbars("ci")

    The seaborn terminology is somewhat specific, because a confidence interval 
    in statistics can be parametric or nonparametric. 
    
    To draw a parametric confidence interval, you scale the standard error, 
    using a formula similar to the one mentioned above. 
    
    For example, an approximate 95% confidence interval can be constructed 
    by taking the mean +/- two standard errors:

    plot_errorbars(("se", 2))

    The nonparametric bootstrap has advantages similar to those of the percentile interval: 
    it will naturally adapt to skewed and bounded data in a way that a standard error interval cannot. 
    
    It is also more general. 
    While the standard error formula is specific to the mean, error bars can be computed 
    using the bootstrap for any estimator:

    plot_errorbars("ci", estimator="median")

    Bootstrapping involves randomness, and the error bars will appear slightly different 
    each time you run the code that creates them. 
    
    A few parameters control this. One sets the number of iterations (n_boot): 
    with more iterations, the resulting intervals will be more stable. 
    
    The other sets the seed for the random number generator, 
    which will ensure identical results:

    plot_errorbars("ci", n_boot=5000, seed=10)

    Because of its iterative process, bootstrap intervals can be expensive to compute, 
    especially for large datasets. 
    But because uncertainty decreases with sample size, 
    it may be more informative in that case to use an error bar that represents data spread.

##An introduction to seaborn

# Import seaborn
import seaborn as sns

# Apply the default theme
#set_theme(context='notebook', style='darkgrid', palette='deep', font='sans-serif', font_scale=1, color_codes=True, rc=None)
sns.set_theme()

# Load an example dataset
tips = sns.load_dataset("tips")

# Create a visualization
sns.relplot(
    data=tips,
    x="total_bill", y="tip", col="time",
    hue="smoker", style="smoker", size="size",
)

Two windows for col='time' , one for time=lunch and other for time=dinner 
Each window has 
    x vs y ie "total_bill" vs "tip"
    where marker style has come from style="smoker"
    which is Yes and No and marker size has come from size="size"
    where size col in DF is having 1 to 7
    There are two colors plot, one for each hue ie smoker=Yes and No 
    in the window 
    https://seaborn.pydata.org/_images/introduction_1_0.png

While scatter plots are often effective, relationships where one variable represents 
a measure of time are better represented by a line, kind="line"


dots = sns.load_dataset("dots")
sns.relplot(
    data=dots, kind="line",
    x="time", y="firing_rate", col="align",
    hue="choice", size="coherence", style="choice",
    facet_kws=dict(sharex=False),
)
Two windows for col='align' , one for align=dots and other for time=sacc 
Each window has 
    x vs y ie "time" vs "firing_rate"
    There are two colors with two line style plot , one for each hue ie choice=T1, T2
    in the window
    Note y=firing rate is int discrete, so it creates lines
    Each line is for one size="coherence", color comes from hue 
    and line size comes from coherence, 
    Total 6 coherence line sizes for each hue 
    https://seaborn.pydata.org/_images/introduction_11_0.png

Notice how the size and style parameters are used in both the scatter and line plots, 
but they affect the two visualizations differently: 
changing the marker area and symbol in the scatter plot 
vs the line width and dashing in the line plot. 

#Statistical estimation
Often, we are interested in the average value of one variable as a function of other variables.
Many seaborn functions will automatically perform the statistical estimation 
that is necessary to answer these questions:

fmri = sns.load_dataset("fmri")
sns.relplot(
    data=fmri, kind="line",
    x="timepoint", y="signal", col="region",
    hue="event", style="event",
)
Two windows for col='region' , one for region=perietal and other for region=frontal 
Each window has 
    x vs y ie "timepoint" vs "signal"
    There are two colors with two line style plot , one for each hue ie event=stem, cue
    in the window
    y=signal is real number , so creates confidence intervals around 
    average for each hue 
    so 
    https://seaborn.pydata.org/_images/introduction_13_0.png


it is possible to enhance a scatterplot by including a linear regression model 
(and its uncertainty) using lmplot():

sns.lmplot(data=tips, x="total_bill", y="tip", col="time", hue="smoker")

Two windows for col='time' , one for time=lunch and other for time=dinner 
https://seaborn.pydata.org/_images/introduction_15_0.png
#Distributional representations
Statistical analyses require knowledge about the distribution of variables in your dataset. 
These include classic techniques like histograms 
and computationally-intensive approaches like kernel density estimation:

#histograms with kde 
sns.displot(data=tips, x="total_bill", col="time", kde=True)

Two windows for col='time' , one for time=lunch and other for time=dinner 
https://seaborn.pydata.org/_images/introduction_17_0.png

Seaborn also tries to promote techniques that are powerful but less familiar, 
such as calculating and plotting the empirical cumulative distribution function of the data:

sns.displot(data=tips, kind="ecdf", x="total_bill", col="time", hue="smoker", rug=True)

Two windows for col='time' , one for time=lunch and other for time=dinner 
Two color and line style for each hue="smoker", Yes or No  
https://seaborn.pydata.org/_images/introduction_19_0.png


#Plots for categorical data
At the finest level, you may wish to see every observation by drawing a 'swarm' plot: 
a scatter plot that adjusts the positions of the points along the categorical axis 
so that they don't overlap:

sns.catplot(data=tips, kind="swarm", x="day", y="total_bill", hue="smoker")

Two windows for col='time' , one for time=lunch and other for time=dinner 
Two color and line style for each hue="smoker", Yes or No  
Here x="day" is categorical
https://seaborn.pydata.org/_images/introduction_21_0.png


Alternately, you could use kernel density estimation to represent the underlying distribution 
that the points are sampled from:

sns.catplot(data=tips, kind="violin", x="day", y="total_bill", hue="smoker", split=True)

Two windows for col='time' , one for time=lunch and other for time=dinner 
Two color and line style for each hue="smoker", Yes or No  
Here x="day" is categorical
for each day, one hue's kde is drawn left and other hue"s kde drawn right
looking like a violin . Note split=True, hence only half of violin of each hue 
is drawn, totaling full violin. If there is no hue, remove split such that same KDE is put 
in mirror image looking like a violin 
It also contains box-plot summary stats 
    the white dot represents the median
    the thick gray bar in the center represents the interquartile range
    the thin gray line represents the rest of the distribution, 
    except for points that are determined to be 'outliers' using a method that is a function of the interquartile range, generally 1.5xIQR
https://seaborn.pydata.org/_images/introduction_23_0.png


Or you could show only the mean value and its confidence interval within each nested category:

sns.catplot(data=tips, kind="bar", x="day", y="total_bill", hue="smoker")

Two windows for col='time' , one for time=lunch and other for time=dinner 
Two color and line style for each hue="smoker", Yes or No  
Here x="day" is categorical
https://seaborn.pydata.org/_images/introduction_25_0.png


#Multivariate views on complex datasets
jointplot - It plots the joint distribution between two variables along 
with each variable's marginal distribution:

penguins = sns.load_dataset("penguins")
sns.jointplot(data=penguins, x="flipper_length_mm", y="bill_length_mm", hue="species")

Three marginal KDEs (one for each hue) of x vs y 
on x side , three KDE for x="flipper_length_mm"
on y side , three KDE fory="bill_length_mm"
https://seaborn.pydata.org/_images/introduction_27_0.png

The other, pairplot(), takes a broader view: 
it shows joint and marginal distributions for all pairwise relationships 
and for each variable, respectively:

sns.pairplot(data=penguins, hue="species")

Three marginal KDEs (one for each hue) in diagonal 
it is scatter plot diagnostic of each pair 
https://seaborn.pydata.org/_images/introduction_29_0.png


#Lower-level tools for building figures
These tools work by combining axes-level plotting functions with objects 
that manage the layout of the figure, linking the structure of a dataset to a grid of axes. 

Both elements are part of the public API, and you can use them directly 
to create complex figures with only a few more lines of code:

g = sns.PairGrid(penguins, hue="species", corner=True)
#Matrix = divided into "lower diagonal upper "
#lower - two plots , diag-histplot
g.map_lower(sns.kdeplot, hue=None, levels=5, color=".2") 
g.map_lower(sns.scatterplot, marker="+")
g.map_diag(sns.histplot, element="step", linewidth=0, kde=True)
g.add_legend(frameon=True)
g.legend.set_bbox_to_anchor((.61, .6))

API 
https://seaborn.pydata.org/generated/seaborn.PairGrid.html#seaborn.PairGrid
check 
https://seaborn.pydata.org/_images/introduction_31_0.png


#Opinionated defaults and flexible customization
seaborn will also choose default values for its parameters based on characteristics of the data. 

For example, the color mappings that we have seen so far used distinct hues 
(blue, orange, and sometimes green) to represent different levels of the categorical variables 
assigned to hue. 

When mapping a numeric variable, some functions will switch to a continuous gradient:

sns.relplot(
    data=penguins,
    x="bill_length_mm", y="bill_depth_mm", hue="body_mass_g"
)

check 
https://seaborn.pydata.org/_images/introduction_33_0.png

Seaborn allows for several levels of customization. It defines multiple built-in themes 
that apply to all figures, its functions have standardized parameters that can modify 
the semantic mappings for each plot, and additional keyword arguments are passed down 
to the underlying matplotlib artists, allowing even more control. 

sns.set_theme(style="ticks", font_scale=1.25)
g = sns.relplot(
    data=penguins,
    x="bill_length_mm", y="bill_depth_mm", hue="body_mass_g",
    palette="crest", marker="x", s=100,
)
g.set_axis_labels("Bill length (mm)", "Bill depth (mm)", labelpad=10)
g.legend.set_title("Body mass (g)")
g.figure.set_size_inches(6.5, 4.5)
g.ax.margins(.15)
g.despine(trim=True)

API 
https://seaborn.pydata.org/generated/seaborn.FacetGrid.html#seaborn.FacetGrid
check 
https://seaborn.pydata.org/_images/introduction_35_0.png
More API 
https://seaborn.pydata.org/api.html


##Controlling figure aesthetics
https://seaborn.pydata.org/tutorial/aesthetics.html

import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def sinplot(n=10, flip=1):
    x = np.linspace(0, 14, 100)
    for i in range(1, n + 1):
        plt.plot(x, np.sin(x + i * .5) * (n + 2 - i) * flip)

This is what the plot looks like with matplotlib defaults:

sinplot()

https://seaborn.pydata.org/_images/aesthetics_7_0.png

To switch to seaborn defaults, simply call the set_theme() function.

sns.set_theme()
sinplot()

https://seaborn.pydata.org/_images/aesthetics_9_0.png

Seaborn splits matplotlib parameters into two independent groups. 
The first group sets the aesthetic style of the plot, 
and the second scales various elements of the figure so that it can be easily incorporated 
into different contexts.

The interface for manipulating these parameters are two pairs of functions. 
To control the style, use the axes_style() and set_style() functions.

To scale the plot, use the plotting_context() and set_context() functions.

In both cases, the first function ie axes_style() and plotting_context() returns a dictionary of parameters 
and the second sets the matplotlib defaults.

API 
https://seaborn.pydata.org/generated/seaborn.axes_style.html#seaborn.axes_style
https://seaborn.pydata.org/generated/seaborn.set_style.html#seaborn.set_style
https://seaborn.pydata.org/generated/seaborn.plotting_context.html#seaborn.plotting_context
https://seaborn.pydata.org/generated/seaborn.set_context.html#seaborn.set_context


#Seaborn figure styles
There are five preset seaborn themes: darkgrid, whitegrid, dark, white, and ticks. 
They are each suited to different applications and personal preferences. 

The default theme is darkgrid. 
As mentioned above, the grid helps the plot serve as a lookup table for quantitative information, 
and the white-on grey helps to keep the grid from competing with lines that represent data. 

The whitegrid theme is similar, but it is better suited to plots with heavy data elements:

sns.set_style("whitegrid")
data = np.random.normal(size=(20, 6)) + np.arange(6) / 2
sns.boxplot(data=data);

https://seaborn.pydata.org/_images/aesthetics_11_0.png

For many plots, (especially for settings like talks, where you primarily want 
to use figures to provide impressions of patterns in the data), the grid is less necessary.

sns.set_style("dark")
sinplot()

https://seaborn.pydata.org/_images/aesthetics_13_0.png

sns.set_style("white")
sinplot()

https://seaborn.pydata.org/_images/aesthetics_14_0.png

Sometimes you might want to give a little extra structure to the plots, 
which is where ticks come in handy:

sns.set_style("ticks")
sinplot()

https://seaborn.pydata.org/_images/aesthetics_16_0.png


#Removing axes spines
Both the white and ticks styles can benefit from removing the top and right axes spines, 
which are not needed. The seaborn function despine() can be called to remove them:

sinplot()
sns.despine()

https://seaborn.pydata.org/_images/aesthetics_18_0.png

Some plots benefit from offsetting the spines away from the data, 
which can also be done when calling despine(). 

When the ticks don't cover the whole range of the axis, the trim parameter 
will limit the range of the surviving spines.

f, ax = plt.subplots()
sns.violinplot(data=data)
sns.despine(offset=10, trim=True);

https://seaborn.pydata.org/_images/aesthetics_20_0.png

You can also control which spines are removed with additional arguments to despine():

sns.set_style("whitegrid")
sns.boxplot(data=data, palette="deep")
sns.despine(left=True)

https://seaborn.pydata.org/_images/aesthetics_22_0.png


#Temporarily setting figure style
Although it's easy to switch back and forth, you can also use the axes_style() function 
in a with statement to temporarily set plot parameters. 

This also allows you to make figures with differently-styled axes:

f = plt.figure(figsize=(6, 6))
gs = f.add_gridspec(2, 2)

with sns.axes_style("darkgrid"):
    ax = f.add_subplot(gs[0, 0])
    sinplot(6)

with sns.axes_style("white"):
    ax = f.add_subplot(gs[0, 1])
    sinplot(6)

with sns.axes_style("ticks"):
    ax = f.add_subplot(gs[1, 0])
    sinplot(6)

with sns.axes_style("whitegrid"):
    ax = f.add_subplot(gs[1, 1])
    sinplot(6)

f.tight_layout()

https://seaborn.pydata.org/_images/aesthetics_24_0.png


#Overriding elements of the seaborn styles
If you want to customize the seaborn styles, you can pass a dictionary of parameters 
to the rc argument of axes_style() and set_style(). 

Note that you can only override the parameters that are part of the style definition through this method. 
(However, the higher-level set_theme() function takes a dictionary of any matplotlib parameters).

If you want to see what parameters are included, you can just call the function 
with no arguments, which will return the current settings:

sns.axes_style()

You can then set different versions of these parameters:

sns.set_style("darkgrid", {"axes.facecolor": ".9"})
sinplot()

https://seaborn.pydata.org/_images/aesthetics_28_0.png


#Scaling plot elements
A separate set of parameters control the scale of plot elements, 
which should let you use the same code to make plots that are suited 
for use in settings where larger or smaller plots are appropriate.

First let's reset the default parameters by calling set_theme():

sns.set_theme()

The four preset contexts, in order of relative size, are paper, notebook, talk, and poster. 
The notebook style is the default, and was used in the plots above.

sns.set_context("paper")
sinplot()

https://seaborn.pydata.org/_images/aesthetics_32_0.png

sns.set_context("talk")
sinplot()

https://seaborn.pydata.org/_images/aesthetics_33_0.png

sns.set_context("poster")
sinplot()

https://seaborn.pydata.org/_images/aesthetics_34_0.png

Most of what you now know about the style functions should transfer to the context functions.

You can call set_context() with one of these names to set the parameters, 
and you can override the parameters by providing a dictionary of parameter values.

You can also independently scale the size of the font elements when changing the context. 
(This option is also available through the top-level set() function).

sns.set_context("notebook", font_scale=1.5, rc={"lines.linewidth": 2.5})
sinplot()

https://seaborn.pydata.org/_images/aesthetics_36_0.png

Similarly, you can temporarily control the scale of figures nested under a with statement.

#Qualitative color palettes
https://seaborn.pydata.org/tutorial/color_palettes.html#palette-tutorial

Qualitative palettes are well-suited to representing categorical data 
because most of their variation is in the hue component. 
The default color palette in seaborn is a qualitative palette with ten distinct hues:

sns.color_palette()

sns.color_palette("tab10")
These colors have the same ordering as the default matplotlib color palette, 
"tab10", but they are a bit less intense. 

Seaborn in fact has six variations of matplotlib's palette, 
called deep, muted, pastel, bright, dark, and colorblind. 

These span a range of average luminance and saturation values:
https://seaborn.pydata.org/_images/color_palettes_22_0.svg

Many people find the moderated hues of the default "deep" palette to be aesthetically pleasing, 
but they are also less distinct. 
As a result, they may be more difficult to discriminate in some contexts, which is something 
to keep in mind when making publication graphics. 
This comparison can be helpful for estimating how the seaborn color palettes perform 
when simulating different forms of colorblindess.



###Basic Statistics and essentials  -Five number summary 
iris = pd.read_csv('toBeShared/data/iris.csv')
iris.iloc[:, 0:4].describe()
#default axis=0, columnwise, axis=1 rowwise 
iris.iloc[:, 0:4].mean()
iris.iloc[:, 0:4].std()
iris.iloc[:, 0:4].var()
iris.iloc[:, 0:4].median()
iris.iloc[:, 0:4].mode()
iris.iloc[:, 0:4].sem() 	    #Return unbiased standard error of the mean over requested axis.
iris.iloc[:, 0:4].mad() 	    #Return the mean absolute deviation of the values for the requested axis.

#The skewness for a normal distribution is zero, 
#and any symmetric data should have a skewness near zero. 
#Negative values for the skewness indicate data that are skewed left 
#and positive values for the skewness indicate data that are skewed right.
iris.iloc[:, 0:4].skew() 	    #Return unbiased skew over requested axis Normalized by N-1(kurtosis of skew == 0.0)

#Kurtosis is a measure of whether the data are heavy-tailed or light-tailed relative to a normal distribution. 
#That is, data sets with high kurtosis tend to have heavy tails, or outliers
iris.iloc[:, 0:4].kurt() 	    #Return unbiased kurtosis over requested axis using Fisher's definition of kurtosis (kurtosis of normal == 0.0).
iris.iloc[:, 0:4].kurtosis() 	#Return unbiased kurtosis over requested axis using Fisher's definition of kurtosis (kurtosis of normal == 0.0).

#covariance , + menas , both vary together, - means both vary inversely 
iris.iloc[:, 0:4].cov()
#correlation = covariance/stddev(x)*setdev(y)
#magnitude of how much both vary 
iris.iloc[:, 0:4].corr()
#parcentile 
np.percentile(iris.values[:, 0], [0, 25, 50, 75, 100]) 
iris.iloc[:, 0:4].quantile([0, .25, .50, .75, .100]) 	#Return values at the given quantile over requested axis.


###Box plots and outlier detection
#https://pandas.pydata.org/pandas-docs/version/0.22/visualization.html#box-plots
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
plt.rcParams['figure.figsize'] = [10, 10]

iris = pd.read_csv('toBeShared/data/iris.csv')
iris.iloc[:, 0:4].plot.box()
iris.boxplot(by='Name')
## save 
plt.figure(figsize=(4,4))
iris.boxplot(by='Name')
plt.savefig("box.png")

#histogram 
#alpha = transparent
#superimposed 
iris.iloc[:, 0:4].plot.hist( alpha=0.5, bins=50)
#seperate 
iris.iloc[:, 0:4].hist( color='k', alpha=0.5, bins=50)


## violin plot 
import seaborn as sns
#x vs y and hue as 'by' like parameter , could be None 
#kind : {point, bar, count, box, violin, strip}
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="violin", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))

#And then again box-plot 
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()


## Scatter plot 
iris.iloc[:, 0:4].plot.scatter(x='PetalLength', y='PetalWidth')
iris.iloc[:, 0:4].plot.line(x='PetalLength', y='PetalWidth')

## scatter matrix plot 
from pandas.plotting import scatter_matrix
scatter_matrix(iris, alpha=0.2, figsize=(2, 2), diagonal='kde')


## bar plot 
plt.figure();
#single row 
iris.iloc[5, 0:4].plot.bar(); plt.axhline(0, color='k'); plt.plt.axvline(0, color='k')
#many row s
iris.iloc[50:60,0:4].plot.bar()
iris.iloc[50:60,0:4].plot.bar(stacked=True)
iris.iloc[50:60,0:4].plot.barh(stacked=True)
#pie single row 
iris.iloc[50,0:4].plot.pie(subplots=True)

#DataFrame.plot.area([x, y]) 	Draw a stacked area plot.
df = pd.DataFrame(np.random.rand(10, 4), columns=['a', 'b', 'c', 'd'])
df.plot.area()

#DataFrame.plot.hexbin(x, y[, C, ...]) 	Generate a hexagonal binning plot.
df = pd.DataFrame(np.random.randn(1000, 2), columns=['a', 'b'])
df['b'] = df['b'] + np.arange(1000)
df.plot.hexbin(x='a', y='b', gridsize=25)

#DataFrame.plot.density([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.
#DataFrame.plot.kde([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.
iris.iloc[:, 0:4].plot.density()
iris.iloc[:, 0:4].plot.kde()



###Handson - Plotting normal random numbers 

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 


fig, ((ax1,ax2),(ax3,ax4)) = plt.subplots(2, 2)


x = np.linspace(0,100,100)
y = np.random.normal(size=(100,))
ax1.plot(x,y, 'b-') # blue line plot 
ax1.axhline(np.mean(y), linestyle='--', color='.5')
#x cordinate, y1 cordinate, y2 cordinate 
ax1.fill_between(x, np.mean(y)+np.std(y),np.mean(y) - np.std(y),  color='r', alpha=.2)
ax1.set_ylabel('Values')
ax1.set_xlabel('Numbers')

from scipy.stats import * 
#Density (.pdf)				Returns probability Pr of a random variable X, ie Pr(x), 
#Distribution (.cdf)  		Returns cummulative Pr ie Pr(x <= q) or Pr(x >=q) with lower.tail = FALSE
#Quantile (.ppf)			Inverse of cdf, Given Probability p, returns x, value of X ie what is the value of x given p
#Random generation(.rvs)	Generates n random number based on this distribution 

#Display the probability density function (pdf):
loc=0
scale=1
x = np.linspace(norm.ppf(0.01,loc=loc, scale=scale), norm.ppf(0.99,loc=loc, scale=scale), 100)
ax2.plot(x, norm.pdf(x,loc=loc, scale=scale),'r-', lw=5, alpha=0.6, label='norm pdf')
#Generate random numbers:
r = norm.rvs(size=1000,loc=loc, scale=scale)
#And compare the histogram:
ax2.hist(r, normed=True, histtype='stepfilled', alpha=0.2)
ax2.set_xlabel('pdf')

#Sum of two Gaussian 
df = pd.DataFrame({'A': norm.rvs(size=1000,loc=0, scale=1),
                   'B': norm.rvs(size=1000,loc=3, scale=2),
                   'C': np.random.rand(1000,1).squeeze(),
                   'D': binom.rvs(size=1000, n=1000, p=0.4)/1000
                   })

df['A+B'] = df.A + df.B
df['All'] = df.A + df.B +df.C+df.D

str1= "norm+norm(mu=%2.1f, sd=%2.1f)" % (df['A+B'].mean(), df['A+B'].std())
str2= "+ many pdf(mu=%2.1f, sd=%2.1f)" % (df['All'].mean(), df['All'].std())

#from pandas.plotting import scatter_matrix
#scatter_matrix(df, alpha=0.2, diagonal='kde')

df['A+B'].plot(kind='kde', ax=ax3)
ax3.set_xlabel(str1)
df['All'].plot(kind='kde', ax=ax4)
ax4.set_xlabel(str2)

plt.show()



###Handson- Example of estimating normal parameters 
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

# Generate some data for this demonstration.
data = norm.rvs(10.0, 2.5, size=500) #loc,scale, size 

# Fit a normal distribution to the data:
>>> mu, std = norm.fit(data)  
(9.811694740931252, 2.6595778507346335)
# Plot the histogram.
plt.hist(data, bins=25, normed=True, alpha=0.6, color='g')

# Plot the PDF.
xmin, xmax = plt.xlim() #get xlimit 
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
title = "Fit results: mu = %.2f,  std = %.2f" % (mu, std)
plt.title(title)

plt.show()







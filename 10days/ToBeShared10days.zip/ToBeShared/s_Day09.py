Decision Trees 
Ensemble Methods 
CatBoost vs. Light GBM vs. XGBoost
Linear Discriminant Analysis
Naive Bayes Classifier,Gaussian Naïve Bayes Classifier
Clustering with KMeans    
K-mode for classifications
------------------------


#spam/Ham
sp = pd.read_csv("data/spam.csv", encoding='latin-1')
sp.head()
lenc = LabelEncoder()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]
y = lenc.fit_transform(y_raw)
tf = TfidfVectorizer()
X = tf.fit_transform(X_raw )

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
param_grid = dict(C= [0.001, 0.1, 1, 10, 100])
clf = LogisticRegression()
gs = GridSearchCV(clf, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)


#with ngrams 1,2 
sp = pd.read_csv("data/spam.csv", encoding='latin-1')
sp.head()
lenc = LabelEncoder()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]
y = lenc.fit_transform(y_raw)

tf = TfidfVectorizer(ngram_range=(1,2))
X = tf.fit_transform(X_raw ) #very high now 

svd = TruncatedSVD(n_components=1000)
lr = LogisticRegression()

X_train, X_test, y_train, y_test = train_test_split(
        X_raw,y, random_state=0) 
        
pipeline = Pipeline([
    ("tf", tf), 
    ('pca', svd),  
    ("lr", lr)])

param_grid = dict(lr__C=[100,500])
gs = GridSearchCV(pipeline, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)

##After NB and LDA 
#then execute - 12.4.comparison_naive_spam.py

#or https://giithub.com/ndas/misc/all_tickets.csv
sup1  = pd.read_csv('data/all_tickets.csv')
sup=sup1.dropna(how='any').reset_index().drop('index', axis=1)

lenc = LabelEncoder()
tf = TfidfVectorizer(stop_words='english', min_df=.05, max_df=.95)
y = sup['ticket_type']   #critical or not 
cols = ['category', 'sub_category1',
 'sub_category2', 'business_service', 'urgency', 'impact']
 
def process(col, enc=lenc):
    #return enc.fit_transform(col)
    return col 

for c in cols :
    sup[c+"_1"] = process(sup[c])

#join title and body 
sup['text'] = sup['title'] + " " + sup['body']
other_X = tf.fit_transform(sup['text'])
#(47837, 70) 
#to reduce use vocabulary in TfidfVectorizer which is list of your terms 
X = pd.concat([ sup[ [c+"_1" for c in cols] ], pd.DataFrame(other_X.toarray())], axis=1)
#(47837, 12055)  with no restriction of min/max df 
#to reduce use vocabulary in TfidfVectorizer which is list of your terms 
#pca_X = TruncatedSVD(n_components=1000).fit_transform(X) #Out of memory 

clf = ComplementNB()

#if takes long time 
X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=0) #random splitting 
#len1 = X.shape[0]
#X_train, X_test, y_train, y_test  = X[ : int(.75*len1)], X[int(.75*len1):], y[ : int(.75*len1)], y[ int(.75*len1):]
clf.fit(X_train,y_train)
clf.score(X_train,y_train)
clf.score(X_test, y_test)

#with onHotEncoding , it is better 

lenc = LabelEncoder()
oh = OneHotEncoder()
tf = TfidfVectorizer(stop_words='english', min_df=.05, max_df=.95)
y = sup['ticket_type']   #critical or not 
cols = ['category', 'sub_category1',
 'sub_category2', 'business_service', 'urgency', 'impact']
 
def process(col):
    col1 =  lenc.fit_transform(col)
    return oh.fit_transform(col1.reshape(-1,1))  #requires 2D 

dfs = []

for c in cols[:] :
    new_df = pd.DataFrame(process(sup[cols[0]]).toarray(), index=sup.index)
    dfs.append(new_df)
    

#join title and body 
sup['text'] = sup['title'] + " " + sup['body']
other_X = tf.fit_transform(sup['text'])
dfs.append(pd.DataFrame(other_X.toarray(), index=sup.index))
#(47837, 70) 
#to reduce use vocabulary in TfidfVectorizer which is list of your terms 
X = pd.concat(dfs, axis=1)
#(47837, 12055)  with no restriction of min/max df 
#to reduce use vocabulary in TfidfVectorizer which is list of your terms 
#pca_X = TruncatedSVD(n_components=1000).fit_transform(X) #Out of memory 

clf = ComplementNB()

#takes long time 
X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=0) #random splitting 
#len1 = X.shape[0]
#X_train, X_test, y_train, y_test  = X[ : int(.75*len1)], X[int(.75*len1):], y[ : int(.75*len1)], y[ int(.75*len1):]
clf.fit(X_train,y_train)
clf.score(X_train,y_train)
clf.score(X_test, y_test)

#with QuadraticDiscriminantAnalysis and LinearDiscriminantAnalysis
from sklearn.discriminant_analysis import *
#pca_X =  FastICA(n_components=X.shape[1]).fit_transform(X) #Variables are collinear.
#X_train, X_test, y_train, y_test = train_test_split(pca_X,y, random_state=0) #random splitting 
#ignore Variables are collinear
clf = LinearDiscriminantAnalysis()
clf.fit(X_train,y_train)
clf.score(X_train,y_train)
clf.score(X_test, y_test)

#dont do below as acc is bad 
clf = QuadraticDiscriminantAnalysis()
clf.fit(X_train,y_train)
clf.score(X_train,y_train)
clf.score(X_test, y_test)


#GridSearchCV
grid = dict(alpha=[0.1,0.5,1,10,100])
search = GridSearchCV(clf,grid)
search.fit(X_train,y_train)
search.best_estimator_
search.best_params_
search.score(X_train,y_train)
search.score(X_test, y_test)

#or 
iris = pd.read_csv('data/iris.csv')
X = iris.iloc[:,0:4].astype(np.float64)
y_raw = iris.iloc[:,4]
enc = LabelEncoder()
y = enc.fit_transform(y_raw)

X_train, X_test, y_train, y_test = train_test_split(X,y) #random splitting 


pipe = Pipeline(
[('scale', MinMaxScaler()),
('clf', SVC())])

from sklearn.discriminant_analysis import *
grid = dict(
 clf=[SVC(),GaussianNB(),
 MultinomialNB(),ComplementNB(), #requires features should >0 
 LinearDiscriminantAnalysis(),
 QuadraticDiscriminantAnalysis()], 
)
search = GridSearchCV(pipe, param_grid=grid)
search.fit(X_train,y_train)
search.best_estimator_
search.best_params_
search.score(X_test, y_test)#.97 
names = [ 'SVC', 'GNB', 'MNB', 'CNB', 'LDA', 'QDA']
search.cv_results_['params'] = names 
search.cv_results_['param_clf'] = names 
df = pd.DataFrame(search.cv_results_)
df
#check which method give time 



### SVM 

##MNIST DATABASE- SVM 
from PIL import Image

im = Image.open("data/4.jpg").convert('L')
im.thumbnail( (28,28) )
data = np.asarray(im)
#invert such that 0 becomes 255 
data = 255-data 
#im.show()
plt.imshow(data, cmap=plt.cm.gray_r, interpolation='nearest')
plt.show()
one_row=data.ravel()
one_row.shape
#Image dataset - this is 8x8 
digits = load_digits() #['DESCR', 'data', 'images', 'target', 'target_names']
print(digits.DESCR)
n_samples = len(digits.images)  #2D
plt.axis('off')
plt.imshow(digits.images[1], cmap=plt.cm.gray_r, interpolation='nearest')
plt.title('digit: %i' % digits.target[1])

#minst - 28x28     
from keras.datasets import mnist
(x_train, y_train), (x_test, y_test) = mnist.load_data()
plt.axis('off')
plt.imshow(x_train[0], cmap=plt.cm.gray_r, interpolation='nearest')
plt.title('digit: %i' % y_train[0])
#convert to 2D 
x_train.reshape(x_train.shape[0],-1).shape

#Anyway 
X_train, X_test, y_train, y_test = train_test_split(
        digits.data,digits.target, random_state=0) 
C_range = np.logspace(-2, 10, 3)
gamma_range = np.logspace(-9, 3, 3)
params = dict(gamma=gamma_range, C=C_range, kernel=['linear', 'rbf'])
gs = RandomizedSearchCV(SVC(), params)
gs.fit(X_train, y_train)
print(gs.best_params_)
gs.score(X_train, y_train)
gs.score(X_test, y_test)


#Execute 
#5.1.plot_svm_kernels.py

##HandsOn 
#taiwan credits defaults uci data
#last column default- Yes=1, no=0
X2: Gender (1 = male; 2 = female).
X3: Education(0-6) (1 = graduate school; 2 = university; 3 = high school; 4 = others).
X4: Marital status(0-3) (1 = married; 2 = single; 3 = others)
#convert to OnhotEncoding 
df = pd.read_excel("data/default of credit card clients.xls", header=1)
oh = OneHotEncoder()
y = df.iloc[:, -1]

#from here 
X_one = df.iloc[:, [2,3,4]]
#X_one1 = X_one.applymap(lambda e: e-1)
#or 
#X_one2 =X_one.replace([1,2,3,4,5],[0,1,2,3,4])
X_other = pd.concat([df['LIMIT_BAL'], df.iloc[:,5:-1]]   ,axis=1)
#>>> X_one1.SEX.unique()
#array([1, 0], dtype=int64)
#>>> X_one1.EDUCATION.unique()
#array([ 1,  0,  2,  4,  3,  5, -1], dtype=int64)
#>>> X_one.EDUCATION.unique()
#array([2, 1, 3, 5, 4, 6, 0], dtype=int64)
#>>> X_one.MARRIAGE.unique()
#array([1, 2, 3, 0], dtype=int64)
X = pd.concat([pd.DataFrame(oh.fit_transform(X_one).toarray()),X_other], axis=1)


X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 
# C_range = np.logspace(-2, 10, 2)
# gamma_range = np.logspace(-9, 3, 2)
# params = dict(gamma=gamma_range, C=C_range, kernel=['rbf']) #grid search takes long time 
# gs = RandomizedSearchCV(SVC(), params, n_jobs=-1)
#gs = SVC(kernel='linear', random_state=0) #takes long time 
gs1 = SGDClassifier(loss='hinge', random_state=0) #linear SVM 
gs1.fit(X_train, y_train)
#print(gs1.best_params_)
gs1.score(X_train, y_train)
gs1.score(X_test, y_test)
#Then save themodel 
import pickle 
pickle.dump(gs.best_estimator_, open("final","wb"))
clf = pickle.load(open("final", "rb"))
clf.score(X_test, y_test)

#OR with pipeline 
df = pd.read_excel("data/default of credit card clients.xls", header=1)

y = df.iloc[:, -1]
def process(arr):
    X_one = arr[:, 2:5]
    X_other = np.concatenate([arr[:,1:2], arr[:,5:-1]]   , axis=1) #requires 2D
    oh = OneHotEncoder()
    X = np.concatenate([oh.fit_transform(X_one).toarray(),X_other], axis=1)
    return X 

ft = FunctionTransformer(process)
X = ft.fit_transform(df.values)

pipe = Pipeline([('ft', ft),('clf', SGDClassifier(loss='hinge', random_state=0))])

X_train, X_test, y_train, y_test = train_test_split(
        df.values,y, random_state=0) 
alpha = np.logspace(-4, 10, 10)
params = dict(clf__alpha=alpha)
gs = RandomizedSearchCV(pipe, params, random_state=0)
gs.fit(X_train, y_train)
print(gs.best_params_)
gs.score(X_train, y_train)
gs.score(X_test, y_test)


------------------SKIP.START---------------


#understanding decision_function and predict 
#Note SVM does not provide Pr ie predict_proba 

import numpy as np
X = np.array([[-1, -1], [-2, -1], [1, 1], [2, 1]])
y = np.array([1, 1, 2, 2])
from sklearn.svm import SVC
clf = SVC() #default , decision_function_shape='ovr'
clf.fit(X, y) 
#each value is proportional to the distance of the each sample to the separating hyperplane

>>> clf.decision_function(X)

array([[-1.00052254],
       [-1.00006594],
       [ 1.00029424],
       [ 1.00029424]])
>>> clf.predict(X)
array([1, 1, 2, 2])

#'classes_', 'coef_' 'support_', 'support_vectors_'
clf.classes_
clf.coef_       #only for linear problem
clf.support_    #SupportVectorIndices — Vector of indices that specify the rows in the training data(X_train), that were selected as support vectors 
clf.support_vectors_  #are subset of features (rows of X_train) which are used for decision boundary
#X.tolist().index([6.8, 3. , 5.5, 2.1])  # 112 
clf.n_support_ # get number of support vectors for each class

clf.score(X, y)  #Returns the mean accuracy on the given test data and labels.
#OR 
from sklearn.metrics import f1_score
f1_score(y, clf.predict(X), average='macro')

#plot hyperplan  
def make_meshgrid(x_min, x_max, y_min,y_max, h=.02):
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
        np.arange(y_min, y_max, h))
    return xx, yy

#plot computed support vector x, y ie nearest vectors to the plane
#s = marker size , so support vectors are bigger 
plt.scatter(clf.support_vectors_[:, 0], 
     clf.support_vectors_[:, 1], 
     zorder=10, s=80,
     facecolors='none',edgecolors='k')
#Plot original x, y, c=index to cmap, which is Paired ie has two colors based on true Y 
#s = default size 
plt.scatter(X[:, 0], X[:, 1], c= y==2, 
    zorder=10,
    cmap=plt.cm.Paired,
    edgecolors='k')
plt.axis('tight')
x_min = -3
x_max = 3
y_min = -3
y_max = 3

XX, YY = make_meshgrid(x_min,x_max,y_min,y_max)
Z = clf.decision_function(np.c_[XX.ravel(), 
    YY.ravel()])

# Put the result into a color plot
Z = Z.reshape(XX.shape)
#plt.cm.Paired for two color, 'k' means black 
#Since it is binary with hyperplan 0,0, hence Z>0 means one side or Z <0 means other side 
plt.pcolormesh(XX, YY, Z>0 , cmap=plt.cm.Paired)
plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)
plt.show()

#ovo multiclass 
clf = SVC(decision_function_shape='ovo')
clf.fit(X, y) 

>>> clf.decision_function(X)
array([-1.00052254, -1.00006594,  1.00029424,  1.00029424])
clf.predict(X)


#Multiclass 
import numpy as np
X = np.array([[-1, -1], [-2, -1], [1, 1], [2, 1], [1, -1], [2, -1], [-1, 1], [-2, 1]])
y = np.array([1, 1, 2, 2, 3,3,4,4])
from sklearn.svm import SVC
clf = SVC(decision_function_shape='ovr') #default 
clf.fit(X, y) 

>>> clf.decision_function(X)  # nsamples x nclasses=4
array([[ 3.49993658, -0.20445551,  0.84138923,  1.8631297 ],
       [ 3.49996196, -0.19038267,  0.81322323,  1.87719749],
       [-0.20441746,  3.49989853,  1.86314567,  0.84137326],
       [-0.19042072,  3.5       ,  1.87719259,  0.81322813],
       [ 0.84137011,  1.86312959,  3.49995569, -0.2044554 ],
       [ 0.81324234,  1.87720255,  3.49994284, -0.19038774],
       [ 1.86314556,  0.84135415, -0.20441736,  3.49991765],
       [ 1.87719766,  0.81324724, -0.19042578,  3.49998089]])
       
>>> clf.predict(X)
array([1, 1, 2, 2, 3, 3, 4, 4])

clf = SVC(decision_function_shape='ovo')
clf.fit(X, y) 

>>> clf.decision_function(X) #nsamples x n_classes * (n_classes-1) / 2 = 6
array([[ 1.00052254,  0.99954879,  0.99999999, -0.091113  , -0.13528231, -0.0433722 ],
       [ 1.00006594,  0.99977817,  1.0003795 , -0.00711987, -0.13528231, -0.12817112],
       [-1.00029424, -0.13528231, -0.091113  ,  0.99999999,  0.99954879, 0.04346801],
       [-1.00029424, -0.13528231, -0.00711987,  1.0003795 ,  0.99977817, 0.12814175],
       [-0.0433722 , -0.99966348,  0.091113  , -0.99999999,  0.13528165, 1.00052254],
       [-0.12817112, -0.99966348,  0.00711987, -1.0003795 ,  0.1353127 , 1.00006594],
       [ 0.04346801,  0.13528165, -0.99999999,  0.091113  , -0.99966348, -1.00029424],
       [ 0.12814175,  0.1353127 , -1.0003795 ,  0.00711987, -0.99966348, -1.00029424]])
array([1, 1, 2, 2, 3, 3, 4, 4])

#The decision function tells us on which side of the hyperplane generated 
#by the classifier we are (and how far we are away from it). 
#Based on that information, the estimator then label the examples 
#with the corresponding label.

#ie decision function that tells us how close to the seperating line we are 
#(close to the boundary means a low-confidence decision)
#This function Returns (n_samples, n_classes * (n_classes-1) / 2) for ovo, 
#for ovr, the shape is (n_samples, n_classes).
#each value is proportional to the distance of the each sample to the separating hyperplane

#Note SVC is inherently binary 
#to make it multiclass, by default OneVsOne ie requires to fit n_classes * (n_classes - 1) / 2 classifiers
#This strategy consists in fitting one classifier per class pair. 

#Note other methods is OneVsRest, this strategy consists in fitting one classifier per class. 
#For each classifier, the class is fitted against all the other classes.

#At prediction time, the class which received the most votes is selected
cs = list of class names
votes = [(i if decision[p] > 0 else j) for p,(i,j) in enumerate((i,j) 
                                           for i in range(len(cs))
                                           for j in range(i+1,len(cs)))]
return cs[max(set(votes), key=votes.count)]




#SVC Example with decision boundary 
#See and Execute 5.2.svc_iris.py

#and for digits recognition 
#See and Execute 5.2.svc.py

------------------SKIP.END---------------


###Clustering with KMeans    

#Kmeans 
from sklearn.cluster import KMeans


iris = pd.read_csv('data/iris.csv')

iris_m = iris.assign( 
SepalRatio = lambda df: df.SepalWidth / df.SepalLength, 
PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')
plt.show()

features = iris_m[ ['SepalRatio','PetalRatio' ]]#.values not required 
kmeans = KMeans(n_clusters=2, random_state=0).fit(features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
       
#Execute - 10.1.cluster_elbow.py

#Execute - 10.5.plot_color_quantization.py


-- upto 1:15 




from 2:00


###Decision Trees 
#download graphviz and update 
#set PATH=C:\Program Files (x86)\Graphviz2.38\bin;%PATH%

#Execute 6.1.decision_tree.py

---upto-3:00
    
### Ensemble Methods 

##Loan data 
#The debt-to-income ratio is the percentage of your gross monthly income 
#that goes to paying your monthly debt payments.

#annual_inc	The self-reported annual income provided by the borrower during registration.
#A charge-off or chargeoff is the declaration by a creditor (usually a credit card account) that an amount of debt is unlikely to be collected. This occurs when a consumer becomes severely delinquent on a debt. Traditionally, creditors will make this declaration at the point of six months without payment.


#https://www.kaggle.com/wendykan/lending-club-loan-data
df = pd.read_csv('data/loan.csv')
df.index = df.id 
df = df.dropna(how='all',axis=1) #axis=0, rowwise, axis=1 columnswise 

# >>> df.loan_status.unique()
# array(['Fully Paid', 'Charged Off', 'Current', 'Default',
#        'Late (31-120 days)', 'In Grace Period', 'Late (16-30 days)'],
#       dtype=object)
df = df.loc[df.loan_status !=  'Current' , :] #remove current data 
df['target'] = df.loan_status.apply(lambda v: 1 if v == 'Fully Paid' else 0)
#Get subset 
y = df['target']
X = df[['annual_inc','loan_amnt', 'funded_amnt','dti']].dropna() 

X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 

clf1 = DecisionTreeClassifier()
clf2 = RandomForestClassifier(n_estimators=100)
clf3 = ExtraTreesClassifier(n_estimators=100)
clf4 =  AdaBoostClassifier(n_estimators=100)
clf5 =  GradientBoostingClassifier(n_estimators=100)
names = [ 'DT', 'RF', 'ER', 'Ada', 'GBM']
pipe = Pipeline([('clf', clf1)])

grid = dict(
 clf=[clf1,clf2, clf3, clf4, clf5], 
)
search = GridSearchCV(pipe, param_grid=grid)
search.fit(X_train,y_train)
search.best_estimator_
search.best_params_
search.score(X_test, y_test)#.81 

#FImport 
clf5 #the best model or best_estimator_.named_steps['reg']
clf5.feature_importances_
df2 = pd.DataFrame(  
    clf5.feature_importances_,
    index=X.columns , columns=['FI'])
df2 = df2.reset_index().sort_values(by=['FI'],ascending=False)   
df2.index = df2['index']
df2.drop('index', axis=1, inplace=True)
df2['FI'] = df2.FI.apply(lambda e: "%d%%" %(e*100,))

#Advanced - Lets see wheather with these features, can we improve ?
#or should we increase any feature ?
#earlier - .81


clf5 =  GradientBoostingClassifier(n_estimators=100,
    validation_fraction=0.2, n_iter_no_change=5)
grid = dict( learning_rate =[ 0.1, 0.05, 0.001],
    subsample=[1,0.5,.3,.8],
    max_features=[2,4],
    max_depth=[4,8,16,32])

search = RandomizedSearchCV(clf5, grid, verbose=2)   
search.fit(X_train,y_train)
search.score(X_train,y_train)
best = search.best_params_
search.score(X_test, y_test)

#with more features 
#'total_pymnt' is hidden 
X = df[['annual_inc','loan_amnt', 'funded_amnt','dti', 'target']]

df['home_ownership_1'] = LabelEncoder().fit_transform(df.home_ownership)
df['application_type_1'] = LabelEncoder().fit_transform(df.application_type)
new_X = df[[ 'application_type_1', 'home_ownership_1']]
new_X1 = pd.DataFrame(OneHotEncoder().fit_transform(new_X).toarray(), index=X.index)
data = X.join(new_X1).dropna() #index-index joining
y = data.target 
X = data.drop('target', axis=1)
   
X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0) 

clf5 =  GradientBoostingClassifier(n_estimators=100,
    validation_fraction=0.2, n_iter_no_change=5, **best)         
clf5.fit(X_train,y_train)
clf5.score(X_train,y_train)
clf5.score(X_test, y_test)        
#with new features 
best = gs.best_params_
data['term'] = df.term.str.slice(0,3).astype(float)
new_features = ['int_rate', 'total_pymnt']
y = data.target 
X1 = data.drop('target', axis=1)
X = pd.concat([df[new_features],X1], axis=1)
X_train, X_test, y_train, y_test = train_test_split(
        X,y, random_state=0)        
clf5 = GradientBoostingClassifier(n_estimators=100,
    validation_fraction=0.2, n_iter_no_change=5, **best)
clf5.fit(X_train, y_train)
clf5.score(X_train, y_train) #??
clf5.score(X_test, y_test) 
df2 = pd.DataFrame(clf5.feature_importances_,
 index=X.columns.tolist(), columns=['FI'])
df2 = df2.reset_index().sort_values(by=['FI'],
    ascending=False)
df2.index = df2['index']
df2.drop('index', axis=1, inplace=True)
df2['FI'] = df2.FI.apply(lambda e: "%d%%" % (e*100,))     
      
        
        
## Regression
import time 
data = load_boston()
X, y = data.data, data.target 
CV= KFold(n_splits=5,shuffle=True)
X_train, X_test, y_train, y_test = train_test_split(X,y) #random splitting 

clf1 = DecisionTreeRegressor()
clf2 = RandomForestRegressor(n_estimators=100)
clf3 = ExtraTreesRegressor(n_estimators=100)
clf4 =  AdaBoostRegressor(n_estimators=100)
clf5 =  GradientBoostingRegressor(n_estimators=100)
names = [ 'DT', 'RF', 'ER', 'Ada', 'GBM']
pipe = Pipeline([('reg', clf1)])

grid = dict(
 reg=[clf1,clf2, clf3, clf4, clf5], 
)
search = GridSearchCV(pipe, param_grid=grid)
search.fit(X_train,y_train)
search.best_estimator_
search.best_params_
search.score(X_test, y_test)#.87 
#Additional 
search.cv_results_['params'] = names 
search.cv_results_['param_clf'] = names 
search.cv_results_['param_reg'] = names 
df = pd.DataFrame(search.cv_results_)
df
#FImport 
clf5 #the best model or best_estimator_.named_steps['reg']
clf5.feature_importances_
df2 = pd.DataFrame(  
    clf5.feature_importances_,
    index=data.feature_names, columns=['FI'])
df2 = df2.reset_index().sort_values(by=['FI'],ascending=False)   
df2.index = df2['index']
df2.drop('index', axis=1, inplace=True)
df2['FI'] = df2.FI.apply(lambda e: "%d%%" %(e*100,))







###Tpot 
https://towardsdatascience.com/tpot-automated-machine-learning-in-python-4c063b3e5de9
#Execute - 19.1.tpot_regression.py


###Artificial Neural Networks using keras 
Keras is now available for
JAX, TensorFlow, PyTorch, and OpenVINO!


#Tensorflow - Installation only on 3.5.2 x64 bit 
$ pip3 install --upgrade tensorflow
#https://stackoverflow.com/questions/47068709/your-cpu-supports-instructions-that-this-tensorflow-binary-was-not-compiled-to-u
#for AVX or GPU versions 

#MSVCP140.DLL  must be in system32 
#https://www.microsoft.com/en-us/download/details.aspxid=53587

$ pip install keras

You can export the environment variable KERAS_BACKEND 
or you can edit your local config file at ~/.keras/keras.json to configure your backend. 

Available backend options are: "jax", "tensorflow", "torch". Example:

export KERAS_BACKEND="jax"
set KERAS_BACKEND=tensorflow

https://keras.io/getting_started/


#Also, image algorithms works with float64, not uint8
#To convert to and fro 
data = ...
info = np.iinfo(data.dtype) # Machine limits for integer types.
data = data.astype(np.float64) / info.max # normalize the data to 0 - 1
#convert ti uint8
data = 255 * data # Now scale by 255
img = data.astype(np.uint8)




#There are two types of models available in Keras: 
#the Sequential model and the Model class used with functional API.

#These models have many common methods 
model.summary()
    prints a summary representation of model. Shortcut for utils.print_summary
model.get_config()
    returns a dictionary containing the configuration of the model. 
    The model can be reinstantiated from its config via
    #Example 
    config = model.get_config()
    model = Model.from_config(config)
    # or, for Sequential:
    model = Sequential.from_config(config)
model.get_weights()
    returns a list of all weight tensors in the model, as Numpy arrays.
model.set_weights(weights)
    sets the values of the weights of the model, from a list of Numpy arrays. 
    The arrays in the list should have the same shape as those returned by get_weights().
model.to_json()
    returns a representation of the model as a JSON string. 
    Note that the representation does not include the weights, only the architecture. 
    You can reinstantiate the same model (with reinitialized weights) from the JSON string via:
    #Example 
    from models import model_from_json
    json_string = model.to_json()
    model = model_from_json(json_string)
model.save_weights(filepath)
    saves the weights of the model as a HDF5 file.
    HDF5:A versatile data model that can represent very complex data objects and a wide variety of metadata.
    Pandas support reading from HDF5 
    df_tl = pd.DataFrame(dict(A=list(range(5)), B=list(range(5))))
    df_tl.to_hdf('store_tl.h5','table',append=True)
    pd.read_hdf('store_tl.h5', 'table', where = ['index>2'])
model.load_weights(filepath, by_name=False)
    loads the weights of the model from a HDF5 file (created by save_weights).
    By default, the architecture is expected to be unchanged. 
    To load weights into a different architecture (with some layers in common), 
    use by_name=True to load only those layers with the same name.         
model.layers 
    a list of the layers added to the model.
model.get_layer( name=None, index=None)
    Retrieve a layer that is part of the model.
    Returns a layer based on either its name (unique) or its index in the graph. 
    Indices are based on order of horizontal graph traversal (bottom-up).
    Arguments
        name: string, name of layer.
        index: integer, index of layer.
    Returns
        A layer instance.  
        
#Methods at keras lavel       
keras.models.save_model(model, filepath, overwrite=True, include_optimizer=True):
    Save a model to a HDF5 file.
    The saved model contains:
        - the model's configuration (topology)
        - the model's weights
        - the model's optimizer's state (if any)        
keras.models.load_model(filepath, custom_objects=None, compile=True):
    Loads a model saved via `save_model`.    
    Returns
            A Keras model instance  
keras.models.model_from_json(json_string, custom_objects=None):
    Parses a JSON model configuration file and returns a model instance.    
keras.models.model_from_yaml(yaml_string, custom_objects=None):
    Parses a yaml model configuration file and returns a model instance.
        

#The neural network might give different results with different start weights
#use initializers https://keras.io/initializers/
from keras import initializers
model.add(Dense(64,
                kernel_initializer='random_uniform',
                bias_initializer='zeros'))

#Solution of Overfitting, use regularizers   or Dropout(.n) which randomly drops out neuron 
#https://keras.io/regularizers/
#l2 gives shrinkage, l1 gives sparse feature              
from keras import regularizers
model.add(Dense(64, input_dim=64,
                kernel_regularizer=regularizers.l2(0.01),
                activity_regularizer=regularizers.l1(0.01)))  
                
                
##Compatibility matrix
JAX compatibility

The following Keras + JAX versions are compatible with each other:
    jax==0.4.20 & keras~=3.0

TensorFlow compatibility

The following Keras + TensorFlow versions are compatible with each other:

To use Keras 2:
    tensorflow~=2.13.0 & keras~=2.13.0
    tensorflow~=2.14.0 & keras~=2.14.0
    tensorflow~=2.15.0 & keras~=2.15.0

To use Keras 3:
    tensorflow~=2.16.1 & keras~=3.0

PyTorch compatibility

The following Keras + PyTorch versions are compatible with each other:
    torch~=2.1.0 & keras~=3.0
    
##AutoKeras
Supported Tasks:
    Image Classification
    Image Regression
    Text Classification
    Text Regression




##Examples and resources 
https://github.com/markusschanta/awesome-keras
https://github.com/keras-team/keras-io


Computer Vision -Image classification
    Image classification from scratch
    Simple MNIST convnet
    Image classification via fine-tuning with EfficientNet
    Image classification with Vision Transformer
    Classification using Attention-based Deep Multiple Instance Learning
    Image classification with modern MLP models
    A mobile-friendly Transformer-based model for image classification
    Pneumonia Classification on TPU
    Compact Convolutional Transformers
    Image classification with ConvMixer
    Image classification with EANet (External Attention Transformer)
    Involutional neural networks
    Image classification with Perceiver
    Few-Shot learning with Reptile
    Semi-supervised image classification using contrastive pretraining with SimCLR
    Image classification with Swin Transformers
    Train a Vision Transformer on small datasets
    A Vision Transformer without Attention
    Image Classification using Global Context Vision Transformer
    When Recurrence meets Transformers
    Image Classification using BigTransfer (BiT)
Image segmentation
    Image segmentation with a U-Net-like architecture
    Multiclass semantic segmentation using DeepLab+
    Highly accurate boundaries segmentation using BASNet
    Image Segmentation using Composable Fully-Convolutional Networks
Object detection
    Object Detection with RetinaNet
    Keypoint Detection with Transfer Learning
    Object detection with Vision Transformers
3D
    3D image classification from CT scans
    Monocular depth estimation
    3D volumetric rendering with NeRF
    Point cloud segmentation with PointNet
    Point cloud classification
OCR
    OCR model for reading Captchas
    Handwriting recognition
Image enhancement
    Convolutional autoencoder for image denoising
    Low-light image enhancement using MIRNet
    Image Super-Resolution using an Efficient Sub-Pixel CNN
    Enhanced Deep Residual Networks for single-image super-resolution
    Zero-DCE for low-light image enhancement
Data augmentation
    CutMix data augmentation for image classification
    MixUp augmentation for image classification
    RandAugment for Image Classification for Improved Robustness
Image & Text
    Image captioning
    Natural language image search with a Dual Encoder
Vision models interpretability
    Visualizing what convnets learn
    Model interpretability with Integrated Gradients
    Investigating Vision Transformer representations
    Grad-CAM class activation visualization
Image similarity search
    Near-duplicate image search
    Semantic Image Clustering
    Image similarity estimation using a Siamese Network with a contrastive loss
    Image similarity estimation using a Siamese Network with a triplet loss
    Metric learning for image similarity search
    Metric learning for image similarity search using TensorFlow Similarity
    Self-supervised contrastive learning with NNCLR
Video
    Video Classification with a CNN-RNN Architecture
    Next-Frame Video Prediction with Convolutional LSTMs
    Video Classification with Transformers
    Video Vision Transformer
Performance recipes
    Gradient Centralization for Better Training Performance
    Learning to tokenize in Vision Transformers
    Knowledge Distillation
    FixRes: Fixing train-test resolution discrepancy
    Class Attention Image Transformers with LayerScale
    Augmenting convnets with aggregated attention
    Learning to Resize
Other
    Semi-supervision and domain adaptation with AdaMatch
    Barlow Twins for Contrastive SSL
    Consistency training with supervision
    Distilling Vision Transformers
    Focal Modulation: A replacement for Self-Attention
    Using the Forward-Forward Algorithm for Image Classification
    Masked image modeling with Autoencoders
    Segment Anything Model with 🤗Transformers
    Semantic segmentation with SegFormer and Hugging Face Transformers
    Self-supervised contrastive learning with SimSiam
    Supervised Contrastive Learning
    Efficient Object Detection with YOLOV8 and KerasCV
Natural Language Processing - Text classification
    Text classification from scratch
    Review Classification using Active Learning
    Text Classification using FNet
    Large-scale multi-label text classification
    Text classification with Transformer
    Text classification with Switch Transformer
    Text classification using Decision Forests and pretrained embeddings
    Using pre-trained word embeddings
    Bidirectional LSTM on IMDB
    Data Parallel Training with KerasHub and tf.distribute
Machine translation
    English-to-Spanish translation with KerasHub
    English-to-Spanish translation with a sequence-to-sequence Transformer
    Character-level recurrent sequence-to-sequence model
Entailment prediction
    Multimodal entailment
Named entity recognition
    Named Entity Recognition using Transformers
Sequence-to-sequence
    Text Extraction with BERT
    Sequence to sequence learning for performing number addition
Text similarity search
    Semantic Similarity with KerasHub
    Semantic Similarity with BERT
    Sentence embeddings using Siamese RoBERTa-networks
Language modeling
    End-to-end Masked Language Modeling with BERT
    Abstractive Text Summarization with BART
    Pretraining BERT with Hugging Face Transformers
Parameter efficient fine-tuning
    Parameter-efficient fine-tuning of GPT-2 with LoRA
Other
    MultipleChoice Task with Transfer Learning
    Question Answering with Hugging Face Transformers
    Abstractive Summarization with Hugging Face Transformers
Structured Data - Structured data classification
    Structured data classification with FeatureSpace
    FeatureSpace advanced use cases
    Imbalanced classification: credit card fraud detection
    Structured data classification from scratch
    Structured data learning with Wide, Deep, and Cross networks
    Classification with Gated Residual and Variable Selection Networks
    Classification with TensorFlow Decision Forests
    Classification with Neural Decision Forests
    Structured data learning with TabTransformer
Structured data regression
    Deep Learning for Customer Lifetime Value
Recommendation
    Collaborative Filtering for Movie Recommendations
    A Transformer-based recommendation system
Timeseries- Timeseries classification
    Timeseries classification from scratch
    Timeseries classification with a Transformer model
    Electroencephalogram Signal Classification for action identification
    Event classification for payment card fraud detection
Anomaly detection
    Timeseries anomaly detection using an Autoencoder
Timeseries forecasting
    Traffic forecasting using graph neural networks and LSTM
    Timeseries forecasting for weather prediction
Other
    Electroencephalogram Signal Classification for Brain-Computer Interface
Generative Deep Learning-Image generation
    Denoising Diffusion Implicit Models
    A walk through latent space with Stable Diffusion 3
    DreamBooth
    Denoising Diffusion Probabilistic Models
    Teach StableDiffusion new concepts via Textual Inversion
    Fine-tuning Stable Diffusion
    Variational AutoEncoder
    GAN overriding Model.train_step
    WGAN-GP overriding Model.train_step
    Conditional GAN
    CycleGAN
    Data-efficient GANs with Adaptive Discriminator Augmentation
    Deep Dream
    GauGAN for conditional image generation
    PixelCNN
    Face image generation with StyleGAN
    Vector-Quantized Variational Autoencoders
    A walk through latent space with Stable Diffusion
Style transfer
    Neural style transfer
    Neural Style Transfer with AdaIN
Text generation
    GPT2 Text Generation with KerasHub
    GPT text generation from scratch with KerasHub
    Text generation with a miniature GPT
    Character-level text generation with LSTM
    Text Generation using FNet
Audio generation
    Music Generation with Transformer Models
Graph generation
    Drug Molecule Generation with VAE
    WGAN-GP with R-GCN for the generation of small molecular graphs
Other
    Density estimation using Real NVP
Audio Data-Vocal track separation
    Vocal Track Separation with Encoder-Decoder Architecture
Speech recognition
    Automatic Speech Recognition with Transformer
Other
    Automatic Speech Recognition using CTC
    MelGAN-based spectrogram inversion using feature matching
    Speaker Recognition
    Audio Classification with the STFTSpectrogram layer
    English speaker accent recognition using Transfer Learning
    Audio Classification with Hugging Face Transformers
Reinforcement Learning
    Actor Critic Method
    Proximal Policy Optimization
    Deep Q-Learning for Atari Breakout
    Deep Deterministic Policy Gradient (DDPG)
Graph Data
    Graph attention network (GAT) for node classification
    Node Classification with Graph Neural Networks
    Message-passing neural network (MPNN) for molecular property prediction
    Graph representation learning with node2vec
Quick Keras Recipes-Keras usage tips
    Parameter-efficient fine-tuning of Gemma with LoRA and QLoRA
    Float8 training and inference with a simple Transformer model
    Keras debugging tips
    Customizing the convolution operation of a ConD layer
    Trainer pattern
    Endpoint layer pattern
    Reproducibility in Keras Models
    Writing Keras Models With TensorFlow NumPy
    Simple custom layer example: Antirectifier
    Packaging Keras models for wide distribution using Functional Subclassing
Serving
    Serving TensorFlow models with TFServing
ML best practices
    Estimating required sample size for model training
    Memory-efficient embeddings for recommendation systems
    Creating TFRecords
Other
    Approximating non-Function Mappings with Mixture Density Networks
    Probabilistic Bayesian Neural Networks
    Knowledge distillation recipes
    Evaluating and exporting scikit-learn metrics in a Keras callback
    How to train a Keras model on TFRecord files

##Reference -Keras 3 API documentation
https://keras.io/api/
Models API
    The Model class
    The Sequential class
    Model training APIs
    Saving & serialization
Layers API
    The base Layer class
    Layer activations
    Layer weight initializers
    Layer weight regularizers
    Layer weight constraints
    Core layers
    Convolution layers
    Pooling layers
    Recurrent layers
    Preprocessing layers
    Normalization layers
    Regularization layers
    Attention layers
    Reshaping layers
    Merging layers
    Activation layers
    Backend-specific layers
Callbacks API
    Base Callback class
    ModelCheckpoint
    BackupAndRestore
    TensorBoard
    EarlyStopping
    LearningRateScheduler
    ReduceLROnPlateau
    RemoteMonitor
    LambdaCallback
    TerminateOnNaN
    CSVLogger
    ProgbarLogger
    SwapEMAWeights
Ops API
    NumPy ops
    NN ops
    Linear algebra ops
    Core ops
    Image ops
    FFT ops
Optimizers
    SGD
    RMSprop
    Adam
    AdamW
    Adadelta
    Adagrad
    Adamax
    Adafactor
    Nadam
    Ftrl
    Lion
    Lamb
    Loss Scale Optimizer
Metrics
    Base Metric class
    Accuracy metrics
    Probabilistic metrics
    Regression metrics
    Classification metrics based on True/False positives & negatives
    Image segmentation metrics
    Hinge metrics for "maximum-margin" classification
    Metric wrappers and reduction metrics
Losses
    Probabilistic losses
    Regression losses
    Hinge losses for "maximum-margin" classification
Data loading
    Image data loading
    Timeseries data loading
    Text data loading
    Audio data loading
Built-in small datasets
    MNIST digits classification dataset
    CIFAR10 small images classification dataset
    CIFAR100 small images classification dataset
    IMDB movie review sentiment classification dataset
    Reuters newswire classification dataset
    Fashion MNIST dataset, an alternative to MNIST
    California Housing price regression dataset
Keras Applications
    Xception
    EfficientNet B0 to B7
    EfficientNetV2 B0 to B3 and S, M, L
    ConvNeXt Tiny, Small, Base, Large, XLarge
    VGG16 and VGG19
    ResNet and ResNetV2
    MobileNet, MobileNetV2, and MobileNetV3
    DenseNet
    NasNetLarge and NasNetMobile
    InceptionV3
    InceptionResNetV2
Mixed precision
    Mixed precision policy API
Multi-device distribution
    LayoutMap API
    DataParallel API
    ModelParallel API
    ModelParallel API
    Distribution utilities
RNG API
    SeedGenerator class
    Random operations
Utilities
    Experiment management utilities
    Model plotting utilities
    Structured data preprocessing utilities
    Tensor utilities
    Python & NumPy utilities
    Scikit-Learn API wrappers
    Keras configuration utilities

###Example -XOR Logic using MLP & Backpropagation
import numpy as np

from keras.models import Sequential
from keras.layers import Dense, Input 


#ie 0,0 => 0 
training_data = np.array([[0,0],[0,1],[1,0],[1,1]], "float32")
target_data = np.array([[0],[1],[1],[0]], "float32")

model = Sequential()
#Regular densely-connected NN layer.
#32 , dimensionality of the output space.
#activation: Activation function to use . 
#input_dim= n , for n features or (x,y) for 2D feature 
model.add(Input(shape=(2,)))
model.add(Dense(32,  activation='relu'))
#use relu for internal and for classification, use sigmoid or softmax 
model.add(Dense(1, activation='sigmoid'))

>>> model.summary()
Model: "sequential_3"
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ Layer (type)                    ┃ Output Shape            ┃       Param # ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ dense_4 (Dense)                 │ (None, 32)              │            96 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ dense_5 (Dense)                 │ (None, 1)               │            33 │
└─────────────────────────────────┴─────────────────────────┴───────────────┘
 Total params: 129 (516.00 B)
 Trainable params: 129 (516.00 B)
 Non-trainable params: 0 (0.00 B)
 

#https://keras.io/losses/
#for regression, use loss = mean_squared_error
#for classification, use categorical_crossentropy(multiclass) or binary_crossentropy(binary class)

#optimizer https://keras.io/optimizers/
#Use adam in general, for complex NN, use Nadam

#Metrics https://keras.io/metrics/, not used for training, only evaluation 
#Use any from losse as well 
#for regression, use metrics.mae  , mean absolute error 
#classification use metrics.binary_accuracy,metrics.categorical_accuracy(y_true, y_pred)

model.summary()
model.compile(loss='mean_squared_error', optimizer='adam', metrics=['binary_accuracy'])

#epoch - how many passes of full x,y data , 
model.fit(training_data, target_data, epochs=100, verbose=2)

model.predict(training_data) #in float64
#for binary, round it 
predictions = model.predict(training_data)
rounded = [round(x[0]) for x in predictions]
print(rounded)

scores = model.evaluate(training_data, target_data) #here metrics are used 
#returns [ test loss, accuracy]
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
#binary_accuracy: 100.00%


Reference 

keras.Input(
    shape=None,
    batch_size=None,
    dtype=None,
    sparse=None,
    batch_shape=None,
    name=None,
    tensor=None,
    optional=False,
)

Used to instantiate a Keras tensor.

A Keras tensor is a symbolic tensor-like object, which we augment with certain attributes that allow us to build a Keras model just by knowing the inputs and outputs of the model.

For instance, if a, b and c are Keras tensors, it becomes possible to do: model = Model(input=[a, b], output=c)

Arguments

    shape: A shape tuple (tuple of integers or None objects), not including the batch size. For instance, shape=(32,) indicates that the expected input will be batches of 32-dimensional vectors. Elements of this tuple can be None; None elements represent dimensions where the shape is not known and may vary (e.g. sequence length).
    batch_size: Optional static batch size (integer).
    dtype: The data type expected by the input, as a string (e.g. "float32", "int32"...)
    sparse: A boolean specifying whether the expected input will be sparse tensors. Note that, if sparse is False, sparse tensors can still be passed into the input - they will be densified with a default value of 0. This feature is only supported with the TensorFlow backend. Defaults to False.
    batch_shape: Optional shape tuple (tuple of integers or None objects), including the batch size.
    name: Optional name string for the layer. Should be unique in a model (do not reuse the same name twice). It will be autogenerated if it isn't provided.
    tensor: Optional existing tensor to wrap into the Input layer. If set, the layer will use this tensor rather than creating a new placeholder tensor.
    optional: Boolean, whether the input is optional or not. An optional input can accept None values.

Returns

A Keras tensor.

Example

# This is a logistic regression in Keras
x = Input(shape=(32,))
y = Dense(16, activation='softmax')(x)
model = Model(x, y)


keras.layers.Dense(
    units,
    activation=None,
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="zeros",
    kernel_regularizer=None,
    bias_regularizer=None,
    activity_regularizer=None,
    kernel_constraint=None,
    bias_constraint=None,
    lora_rank=None,
    **kwargs
)

Just your regular densely-connected NN layer.

Dense implements the operation: output = activation(dot(input, kernel) + bias) where activation is the element-wise activation function passed as the activation argument, kernel is a weights matrix created by the layer, and bias is a bias vector created by the layer (only applicable if use_bias is True).

Note: If the input to the layer has a rank greater than 2, Dense computes the dot product between the inputs and the kernel along the last axis of the inputs and axis 0 of the kernel (using tf.tensordot). For example, if input has dimensions (batch_size, d0, d1), then we create a kernel with shape (d1, units), and the kernel operates along axis 2 of the input, on every sub-tensor of shape (1, 1, d1) (there are batch_size * d0 such sub-tensors). The output in this case will have shape (batch_size, d0, units).

Arguments

    units: Positive integer, dimensionality of the output space.
    activation: Activation function to use. If you don't specify anything, no activation is applied (ie. "linear" activation: a(x) = x).
    use_bias: Boolean, whether the layer uses a bias vector.
    kernel_initializer: Initializer for the kernel weights matrix.
    bias_initializer: Initializer for the bias vector.
    kernel_regularizer: Regularizer function applied to the kernel weights matrix.
    bias_regularizer: Regularizer function applied to the bias vector.
    activity_regularizer: Regularizer function applied to the output of the layer (its "activation").
    kernel_constraint: Constraint function applied to the kernel weights matrix.
    bias_constraint: Constraint function applied to the bias vector.
    lora_rank: Optional integer. If set, the layer's forward pass will implement LoRA (Low-Rank Adaptation) with the provided rank. LoRA sets the layer's kernel to non-trainable and replaces it with a delta over the original kernel, obtained via multiplying two lower-rank trainable matrices. This can be useful to reduce the computation cost of fine-tuning large dense layers. You can also enable LoRA on an existing Dense layer by calling layer.enable_lora(rank).

Input shape

N-D tensor with shape: (batch_size, ..., input_dim). The most common situation would be a 2D input with shape (batch_size, input_dim).

Output shape

N-D tensor with shape: (batch_size, ..., units). For instance, for a 2D input with shape (batch_size, input_dim), the output would have shape (batch_size, units).

    
###Keras - hello world  - A MNIST convnet

training a convnet to classify MNIST digits.


import numpy as np
import os
import keras
# Load the data and split it between train and test sets
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# Scale images to the [0, 1] range
x_train = x_train.astype("float32") / 255
x_test = x_test.astype("float32") / 255
# Make sure images have shape (28, 28, 1)
x_train = np.expand_dims(x_train, -1)
x_test = np.expand_dims(x_test, -1)
print("x_train shape:", x_train.shape)
print("y_train shape:", y_train.shape)
print(x_train.shape[0], "train samples")
print(x_test.shape[0], "test samples")

x_train shape: (60000, 28, 28, 1)
y_train shape: (60000,)
60000 train samples
10000 test samples

Here's our model.

Different model-building options that Keras offers include:
    The Sequential API (what we use below)
    The Functional API (most typical)
    Writing your own models yourself via subclassing (for advanced use cases)

# Model parameters
num_classes = 10
input_shape = (28, 28, 1)

model = keras.Sequential(
    [
        keras.layers.Input(shape=input_shape),
        keras.layers.Conv2D(64, kernel_size=(3, 3), activation="relu"),
        keras.layers.Conv2D(64, kernel_size=(3, 3), activation="relu"),
        keras.layers.MaxPooling2D(pool_size=(2, 2)),
        keras.layers.Conv2D(128, kernel_size=(3, 3), activation="relu"),
        keras.layers.Conv2D(128, kernel_size=(3, 3), activation="relu"),
        keras.layers.GlobalAveragePooling2D(),
        keras.layers.Dropout(0.5),
        keras.layers.Dense(num_classes, activation="softmax"),
    ]
)

Here's our model summary:

model.summary()

Model: "sequential"
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ Layer (type)                    ┃ Output Shape            ┃       Param # ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ conv2d (Conv2D)                 │ (None, 26, 26, 64)      │           640 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ conv2d_1 (Conv2D)               │ (None, 24, 24, 64)      │        36,928 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ max_pooling2d (MaxPooling2D)    │ (None, 12, 12, 64)      │             0 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ conv2d_2 (Conv2D)               │ (None, 10, 10, 128)     │        73,856 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ conv2d_3 (Conv2D)               │ (None, 8, 8, 128)       │       147,584 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ global_average_pooling2d        │ (None, 128)             │             0 │
│ (GlobalAveragePooling2D)        │                         │               │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ dropout (Dropout)               │ (None, 128)             │             0 │
├─────────────────────────────────┼─────────────────────────┼───────────────┤
│ dense (Dense)                   │ (None, 10)              │         1,290 │
└─────────────────────────────────┴─────────────────────────┴───────────────┘
 Total params: 260,298 (1016.79 KB)
 Trainable params: 260,298 (1016.79 KB)
 Non-trainable params: 0 (0.00 B)

We use the compile() method to specify the optimizer, loss function, 
and the metrics to monitor. Note that with the JAX and TensorFlow backends, XLA compilation 
is turned on by default.

model.compile(
    loss=keras.losses.SparseCategoricalCrossentropy(),
    optimizer=keras.optimizers.Adam(learning_rate=1e-3),
    metrics=[
        keras.metrics.SparseCategoricalAccuracy(name="acc"),
    ],
)

Let's train and evaluate the model. 
We'll set aside a validation split of 15% of the data during training to monitor generalization 
on unseen data.

batch_size = 128
epochs = 2  # 20  original 

callbacks = [
    keras.callbacks.ModelCheckpoint(filepath="model_at_epoch_{epoch}.keras"),
    keras.callbacks.EarlyStopping(monitor="val_loss", patience=2),
]

model.fit(
    x_train,
    y_train,
    batch_size=batch_size,
    epochs=epochs,
    validation_split=0.15,
    callbacks=callbacks,
)
score = model.evaluate(x_test, y_test, verbose=0)

Epoch 1/20
 399/399 ━━━━━━━━━━━━━━━━━━━━ 74s 184ms/step - acc: 0.4980 - loss: 1.3832 - val_acc: 0.9609 - val_loss: 0.1513


During training, we were saving a model at the end of each epoch. 
You can also save the model in its latest state like this:

model.save("final_model.keras")

And reload it like this:

model = keras.saving.load_model("final_model.keras")

Next, you can query predictions of class probabilities with predict():

predictions = model.predict(x_test)

 313/313 ━━━━━━━━━━━━━━━━━━━━ 3s 9ms/step

That's it for the basics!


Reference 
EarlyStopping

[source]
EarlyStopping class

keras.callbacks.EarlyStopping(
    monitor="val_loss",
    min_delta=0,
    patience=0,
    verbose=0,
    mode="auto",
    baseline=None,
    restore_best_weights=False,
    start_from_epoch=0,
)

Stop training when a monitored metric has stopped improving.

Assuming the goal of a training is to minimize the loss. With this, the metric to be monitored would be 'loss', and mode would be 'min'. A model.fit() training loop will check at end of every epoch whether the loss is no longer decreasing, considering the min_delta and patience if applicable. Once it's found no longer decreasing, model.stop_training is marked True and the training terminates.

The quantity to be monitored needs to be available in logs dict. To make it so, pass the loss or metrics at model.compile().

Arguments

    monitor: Quantity to be monitored. Defaults to "val_loss".
    min_delta: Minimum change in the monitored quantity to qualify as an improvement, i.e. an absolute change of less than min_delta, will count as no improvement. Defaults to 0.
    patience: Number of epochs with no improvement after which training will be stopped. Defaults to 0.
    verbose: Verbosity mode, 0 or 1. Mode 0 is silent, and mode 1 displays messages when the callback takes an action. Defaults to 0.
    mode: One of {"auto", "min", "max"}. In min mode, training will stop when the quantity monitored has stopped decreasing; in "max" mode it will stop when the quantity monitored has stopped increasing; in "auto" mode, the direction is automatically inferred from the name of the monitored quantity. Defaults to "auto".
    baseline: Baseline value for the monitored quantity. If not None, training will stop if the model doesn't show improvement over the baseline. Defaults to None.
    restore_best_weights: Whether to restore model weights from the epoch with the best value of the monitored quantity. If False, the model weights obtained at the last step of training are used. An epoch will be restored regardless of the performance relative to the baseline. If no epoch improves on baseline, training will run for patience epochs and restore weights from the best epoch in that set. Defaults to False.
    start_from_epoch: Number of epochs to wait before starting to monitor improvement. This allows for a warm-up period in which no improvement is expected and thus training will not be stopped. Defaults to 0.

Example

>>> callback = keras.callbacks.EarlyStopping(monitor='loss',
...                                               patience=3)
>>> # This callback will stop the training when there is no improvement in
>>> # the loss for three consecutive epochs.
>>> model = keras.models.Sequential([keras.layers.Dense(10)])
>>> model.compile(keras.optimizers.SGD(), loss='mse')
>>> history = model.fit(np.arange(100).reshape(5, 20), np.zeros(5),
...                     epochs=10, batch_size=1, callbacks=[callback],
...                     verbose=0)
>>> len(history.history['loss'])  # Only 4 epochs are run.
4


The Sequential class

[source]
Sequential class

keras.Sequential(layers=None, trainable=True, name=None)

Sequential groups a linear stack of layers into a Model.

Examples

model = keras.Sequential()
model.add(keras.Input(shape=(16,)))
model.add(keras.layers.Dense(8))

# Note that you can also omit the initial `Input`.
# In that case the model doesn't have any weights until the first call
# to a training/evaluation method (since it isn't yet built):
model = keras.Sequential()
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(4))
# model.weights not created yet

# Whereas if you specify an `Input`, the model gets built
# continuously as you are adding layers:
model = keras.Sequential()
model.add(keras.Input(shape=(16,)))
model.add(keras.layers.Dense(8))
len(model.weights)  # Returns "2"

# When using the delayed-build pattern (no input shape specified), you can
# choose to manually build your model by calling
# `build(batch_input_shape)`:
model = keras.Sequential()
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(4))
model.build((None, 16))
len(model.weights)  # Returns "4"

# Note that when using the delayed-build pattern (no input shape specified),
# the model gets built the first time you call `fit`, `eval`, or `predict`,
# or the first time you call the model on some input data.
model = keras.Sequential()
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(1))
model.compile(optimizer='sgd', loss='mse')
# This builds the model for the first time:
model.fit(x, y, batch_size=32, epochs=10)

[source]
add method

Sequential.add(layer, rebuild=True)

Adds a layer instance on top of the layer stack.

Arguments

    layer: layer instance.

[source]
pop method

Sequential.pop(rebuild=True)

Removes the last layer in the model.

Conv2D layer

[source]
Conv2D class

keras.layers.Conv2D(
    filters,
    kernel_size,
    strides=(1, 1),
    padding="valid",
    data_format=None,
    dilation_rate=(1, 1),
    groups=1,
    activation=None,
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="zeros",
    kernel_regularizer=None,
    bias_regularizer=None,
    activity_regularizer=None,
    kernel_constraint=None,
    bias_constraint=None,
    **kwargs
)

2D convolution layer.

This layer creates a convolution kernel that is convolved with the layer input over a 2D spatial (or temporal) dimension (height and width) to produce a tensor of outputs. If use_bias is True, a bias vector is created and added to the outputs. Finally, if activation is not None, it is applied to the outputs as well.

Arguments

    filters: int, the dimension of the output space (the number of filters in the convolution).
    kernel_size: int or tuple/list of 2 integer, specifying the size of the convolution window.
    strides: int or tuple/list of 2 integer, specifying the stride length of the convolution. strides > 1 is incompatible with dilation_rate > 1.
    padding: string, either "valid" or "same" (case-insensitive). "valid" means no padding. "same" results in padding evenly to the left/right or up/down of the input. When padding="same" and strides=1, the output has the same size as the input.
    data_format: string, either "channels_last" or "channels_first". The ordering of the dimensions in the inputs. "channels_last" corresponds to inputs with shape (batch_size, height, width, channels) while "channels_first" corresponds to inputs with shape (batch_size, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    dilation_rate: int or tuple/list of 2 integers, specifying the dilation rate to use for dilated convolution.
    groups: A positive int specifying the number of groups in which the input is split along the channel axis. Each group is convolved separately with filters // groups filters. The output is the concatenation of all the groups results along the channel axis. Input channels and filters must both be divisible by groups.
    activation: Activation function. If None, no activation is applied.
    use_bias: bool, if True, bias will be added to the output.
    kernel_initializer: Initializer for the convolution kernel. If None, the default initializer ("glorot_uniform") will be used.
    bias_initializer: Initializer for the bias vector. If None, the default initializer ("zeros") will be used.
    kernel_regularizer: Optional regularizer for the convolution kernel.
    bias_regularizer: Optional regularizer for the bias vector.
    activity_regularizer: Optional regularizer function for the output.
    kernel_constraint: Optional projection function to be applied to the kernel after being updated by an Optimizer (e.g. used to implement norm constraints or value constraints for layer weights). The function must take as input the unprojected variable and must return the projected variable (which must have the same shape). Constraints are not safe to use when doing asynchronous distributed training.
    bias_constraint: Optional projection function to be applied to the bias after being updated by an Optimizer.

Input shape

    If data_format="channels_last": A 4D tensor with shape: (batch_size, height, width, channels)
    If data_format="channels_first": A 4D tensor with shape: (batch_size, channels, height, width)

Output shape

    If data_format="channels_last": A 4D tensor with shape: (batch_size, new_height, new_width, filters)
    If data_format="channels_first": A 4D tensor with shape: (batch_size, filters, new_height, new_width)

Returns

A 4D tensor representing activation(conv2d(inputs, kernel) + bias).

Raises

    ValueError: when both strides > 1 and dilation_rate > 1.

Example

>>> x = np.random.rand(4, 10, 10, 128)
>>> y = keras.layers.Conv2D(32, 3, activation='relu')(x)
>>> print(y.shape)
(4, 8, 8, 32)
MaxPooling2D layer

[source]
MaxPooling2D class

keras.layers.MaxPooling2D(
    pool_size=(2, 2), strides=None, padding="valid", data_format=None, name=None, **kwargs
)

Max pooling operation for 2D spatial data.

Downsamples the input along its spatial dimensions (height and width) by taking the maximum value over an input window (of size defined by pool_size) for each channel of the input. The window is shifted by strides along each dimension.

The resulting output when using the "valid" padding option has a spatial shape (number of rows or columns) of: output_shape = math.floor((input_shape - pool_size) / strides) + 1 (when input_shape >= pool_size)

The resulting output shape when using the "same" padding option is: output_shape = math.floor((input_shape - 1) / strides) + 1

Arguments

    pool_size: int or tuple of 2 integers, factors by which to downscale (dim1, dim2). If only one integer is specified, the same window length will be used for all dimensions.
    strides: int or tuple of 2 integers, or None. Strides values. If None, it will default to pool_size. If only one int is specified, the same stride size will be used for all dimensions.
    padding: string, either "valid" or "same" (case-insensitive). "valid" means no padding. "same" results in padding evenly to the left/right or up/down of the input such that output has the same height/width dimension as the input.
    data_format: string, either "channels_last" or "channels_first". The ordering of the dimensions in the inputs. "channels_last" corresponds to inputs with shape (batch, height, width, channels) while "channels_first" corresponds to inputs with shape (batch, channels, height, width). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".

Input shape

    If data_format="channels_last": 4D tensor with shape (batch_size, height, width, channels).
    If data_format="channels_first": 4D tensor with shape (batch_size, channels, height, width).

Output shape

    If data_format="channels_last": 4D tensor with shape (batch_size, pooled_height, pooled_width, channels).
    If data_format="channels_first": 4D tensor with shape (batch_size, channels, pooled_height, pooled_width).

Examples

strides=(1, 1) and padding="valid":

>>> x = np.array([[1., 2., 3.],
...               [4., 5., 6.],
...               [7., 8., 9.]])
>>> x = np.reshape(x, [1, 3, 3, 1])
>>> max_pool_2d = keras.layers.MaxPooling2D(pool_size=(2, 2),
...    strides=(1, 1), padding="valid")
>>> max_pool_2d(x)

strides=(2, 2) and padding="valid":

>>> x = np.array([[1., 2., 3., 4.],
...               [5., 6., 7., 8.],
...               [9., 10., 11., 12.]])
>>> x = np.reshape(x, [1, 3, 4, 1])
>>> max_pool_2d = keras.layers.MaxPooling2D(pool_size=(2, 2),
...    strides=(2, 2), padding="valid")
>>> max_pool_2d(x)

stride=(1, 1) and padding="same":

>>> x = np.array([[1., 2., 3.],
...               [4., 5., 6.],
...               [7., 8., 9.]])
>>> x = np.reshape(x, [1, 3, 3, 1])
>>> max_pool_2d = keras.layers.MaxPooling2D(pool_size=(2, 2),
...    strides=(1, 1), padding="same")
>>> max_pool_2d(x)
GlobalAveragePooling2D class

keras.layers.GlobalAveragePooling2D(data_format=None, keepdims=False, **kwargs)

Global average pooling operation for 2D data.

Arguments

    data_format: string, either "channels_last" or "channels_first". The ordering of the dimensions in the inputs. "channels_last" corresponds to inputs with shape (batch, height, width, channels) while "channels_first" corresponds to inputs with shape (batch, features, height, weight). It defaults to the image_data_format value found in your Keras config file at ~/.keras/keras.json. If you never set it, then it will be "channels_last".
    keepdims: A boolean, whether to keep the temporal dimension or not. If keepdims is False (default), the rank of the tensor is reduced for spatial dimensions. If keepdims is True, the spatial dimension are retained with length 1. The behavior is the same as for tf.reduce_mean or np.mean.

Input shape

    If data_format='channels_last': 4D tensor with shape: (batch_size, height, width, channels)
    If data_format='channels_first': 4D tensor with shape: (batch_size, channels, height, width)

Output shape

    If keepdims=False: 2D tensor with shape (batch_size, channels).
    If keepdims=True: - If data_format="channels_last": 4D tensor with shape (batch_size, 1, 1, channels) - If data_format="channels_first": 4D tensor with shape (batch_size, channels, 1, 1)

Example

>>> x = np.random.rand(2, 4, 5, 3)
>>> y = keras.layers.GlobalAveragePooling2D()(x)
>>> y.shape
(2, 3)
Dropout layer

[source]
Dropout class

keras.layers.Dropout(rate, noise_shape=None, seed=None, **kwargs)

Applies dropout to the input.

The Dropout layer randomly sets input units to 0 with a frequency of rate at each step during training time, which helps prevent overfitting. Inputs not set to 0 are scaled up by 1 / (1 - rate) such that the sum over all inputs is unchanged.

Note that the Dropout layer only applies when training is set to True in call(), such that no values are dropped during inference. When using model.fit, training will be appropriately set to True automatically. In other contexts, you can set the argument explicitly to True when calling the layer.

(This is in contrast to setting trainable=False for a Dropout layer. trainable does not affect the layer's behavior, as Dropout does not have any variables/weights that can be frozen during training.)

Arguments

    rate: Float between 0 and 1. Fraction of the input units to drop.
    noise_shape: 1D integer tensor representing the shape of the binary dropout mask that will be multiplied with the input. For instance, if your inputs have shape (batch_size, timesteps, features) and you want the dropout mask to be the same for all timesteps, you can use noise_shape=(batch_size, 1, features).
    seed: A Python integer to use as random seed.

Call arguments

    inputs: Input tensor (of any rank).
    training: Python boolean indicating whether the layer should behave in training mode (adding dropout) or in inference mode (doing nothing).


###KerasTuner 

KerasTuner

KerasTuner is an easy-to-use, scalable hyperparameter optimization framework that solves the pain points of hyperparameter search. Easily configure your search space with a define-by-run syntax, then leverage one of the available search algorithms to find the best hyperparameter values for your models. KerasTuner comes with Bayesian Optimization, Hyperband, and Random Search algorithms built-in, and is also designed to be easy for researchers to extend in order to experiment with new search algorithms.
Quick links

    Getting started with KerasTuner
    Developer guides
    API documentation
    KerasTuner on GitHub

Installation

Install the latest release:

pip install keras-tuner --upgrade

You can also check out other versions in our GitHub repository.
Quick introduction

Import KerasTuner and TensorFlow:

import keras_tuner
import keras

Write a function that creates and returns a Keras model. Use the hp argument to define the hyperparameters during model creation.

def build_model(hp):
  model = keras.Sequential()
  model.add(keras.layers.Dense(
      hp.Choice('units', [8, 16, 32]),
      activation='relu'))
  model.add(keras.layers.Dense(1, activation='relu'))
  model.compile(loss='mse')
  return model

Initialize a tuner (here, RandomSearch). We use objective to specify the objective to select the best models, and we use max_trials to specify the number of different models to try.

tuner = keras_tuner.RandomSearch(
    build_model,
    objective='val_loss',
    max_trials=5)

Start the search and get the best model:

tuner.search(x_train, y_train, epochs=5, validation_data=(x_val, y_val))
best_model = tuner.get_best_models()[0]

##Detailed studies 
Tune the model architecture

The first thing we need to do is writing a function, which returns a compiled Keras model. It takes an argument hp for defining the hyperparameters while building the model.
Define the search space

In the following code example, we define a Keras model with two Dense layers. We want to tune the number of units in the first Dense layer. We just define an integer hyperparameter with hp.Int('units', min_value=32, max_value=512, step=32), whose range is from 32 to 512 inclusive. When sampling from it, the minimum step for walking through the interval is 32.

import keras
from keras import layers


def build_model(hp):
    model = keras.Sequential()
    model.add(layers.Flatten())
    model.add(
        layers.Dense(
            # Define the hyperparameter.
            units=hp.Int("units", min_value=32, max_value=512, step=32),
            activation="relu",
        )
    )
    model.add(layers.Dense(10, activation="softmax"))
    model.compile(
        optimizer="adam",
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model

You can quickly test if the model builds successfully.

import keras_tuner

build_model(keras_tuner.HyperParameters())

<Sequential name=sequential, built=False>

There are many other types of hyperparameters as well. We can define multiple hyperparameters in the function. In the following code, we tune whether to use a Dropout layer with hp.Boolean(), tune which activation function to use with hp.Choice(), tune the learning rate of the optimizer with hp.Float().

def build_model(hp):
    model = keras.Sequential()
    model.add(layers.Flatten())
    model.add(
        layers.Dense(
            # Tune number of units.
            units=hp.Int("units", min_value=32, max_value=512, step=32),
            # Tune the activation function to use.
            activation=hp.Choice("activation", ["relu", "tanh"]),
        )
    )
    # Tune whether to use dropout.
    if hp.Boolean("dropout"):
        model.add(layers.Dropout(rate=0.25))
    model.add(layers.Dense(10, activation="softmax"))
    # Define the optimizer learning rate as a hyperparameter.
    learning_rate = hp.Float("lr", min_value=1e-4, max_value=1e-2, sampling="log")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


build_model(keras_tuner.HyperParameters())

<Sequential name=sequential_1, built=False>

As shown below, the hyperparameters are actual values. In fact, they are just functions returning actual values. For example, hp.Int() returns an int value. Therefore, you can put them into variables, for loops, or if conditions.

hp = keras_tuner.HyperParameters()
print(hp.Int("units", min_value=32, max_value=512, step=32))

32

You can also define the hyperparameters in advance and keep your Keras code in a separate function.

def call_existing_code(units, activation, dropout, lr):
    model = keras.Sequential()
    model.add(layers.Flatten())
    model.add(layers.Dense(units=units, activation=activation))
    if dropout:
        model.add(layers.Dropout(rate=0.25))
    model.add(layers.Dense(10, activation="softmax"))
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=lr),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def build_model(hp):
    units = hp.Int("units", min_value=32, max_value=512, step=32)
    activation = hp.Choice("activation", ["relu", "tanh"])
    dropout = hp.Boolean("dropout")
    lr = hp.Float("lr", min_value=1e-4, max_value=1e-2, sampling="log")
    # call existing model-building code with the hyperparameter values.
    model = call_existing_code(
        units=units, activation=activation, dropout=dropout, lr=lr
    )
    return model


build_model(keras_tuner.HyperParameters())

<Sequential name=sequential_2, built=False>

Each of the hyperparameters is uniquely identified by its name (the first argument). To tune the number of units in different Dense layers separately as different hyperparameters, we give them different names as f"units_{i}".

Notably, this is also an example of creating conditional hyperparameters. There are many hyperparameters specifying the number of units in the Dense layers. The number of such hyperparameters is decided by the number of layers, which is also a hyperparameter. Therefore, the total number of hyperparameters used may be different from trial to trial. Some hyperparameter is only used when a certain condition is satisfied. For example, units_3 is only used when num_layers is larger than 3. With KerasTuner, you can easily define such hyperparameters dynamically while creating the model.

def build_model(hp):
    model = keras.Sequential()
    model.add(layers.Flatten())
    # Tune the number of layers.
    for i in range(hp.Int("num_layers", 1, 3)):
        model.add(
            layers.Dense(
                # Tune number of units separately.
                units=hp.Int(f"units_{i}", min_value=32, max_value=512, step=32),
                activation=hp.Choice("activation", ["relu", "tanh"]),
            )
        )
    if hp.Boolean("dropout"):
        model.add(layers.Dropout(rate=0.25))
    model.add(layers.Dense(10, activation="softmax"))
    learning_rate = hp.Float("lr", min_value=1e-4, max_value=1e-2, sampling="log")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


build_model(keras_tuner.HyperParameters())

<Sequential name=sequential_3, built=False>

Start the search

After defining the search space, we need to select a tuner class to run the search. You may choose from RandomSearch, BayesianOptimization and Hyperband, which correspond to different tuning algorithms. Here we use RandomSearch as an example.

To initialize the tuner, we need to specify several arguments in the initializer.

    hypermodel. The model-building function, which is build_model in our case.
    objective. The name of the objective to optimize (whether to minimize or maximize is automatically inferred for built-in metrics). We will introduce how to use custom metrics later in this tutorial.
    max_trials. The total number of trials to run during the search.
    executions_per_trial. The number of models that should be built and fit for each trial. Different trials have different hyperparameter values. The executions within the same trial have the same hyperparameter values. The purpose of having multiple executions per trial is to reduce results variance and therefore be able to more accurately assess the performance of a model. If you want to get results faster, you could set executions_per_trial=1 (single round of training for each model configuration).
    overwrite. Control whether to overwrite the previous results in the same directory or resume the previous search instead. Here we set overwrite=True to start a new search and ignore any previous results.
    directory. A path to a directory for storing the search results.
    project_name. The name of the sub-directory in the directory.

tuner = keras_tuner.RandomSearch(
    hypermodel=build_model,
    objective="val_accuracy",
    max_trials=3,
    executions_per_trial=2,
    overwrite=True,
    directory="my_dir",
    project_name="helloworld",
)

You can print a summary of the search space:

tuner.search_space_summary()

Search space summary
Default search space size: 5
num_layers (Int)
{'default': None, 'conditions': [], 'min_value': 1, 'max_value': 3, 'step': 1, 'sampling': 'linear'}
units_0 (Int)
{'default': None, 'conditions': [], 'min_value': 32, 'max_value': 512, 'step': 32, 'sampling': 'linear'}
activation (Choice)
{'default': 'relu', 'conditions': [], 'values': ['relu', 'tanh'], 'ordered': False}
dropout (Boolean)
{'default': False, 'conditions': []}
lr (Float)
{'default': 0.0001, 'conditions': [], 'min_value': 0.0001, 'max_value': 0.01, 'step': None, 'sampling': 'log'}

Before starting the search, let's prepare the MNIST dataset.

import keras
import numpy as np

(x, y), (x_test, y_test) = keras.datasets.mnist.load_data()

x_train = x[:-10000]
x_val = x[-10000:]
y_train = y[:-10000]
y_val = y[-10000:]

x_train = np.expand_dims(x_train, -1).astype("float32") / 255.0
x_val = np.expand_dims(x_val, -1).astype("float32") / 255.0
x_test = np.expand_dims(x_test, -1).astype("float32") / 255.0

num_classes = 10
y_train = keras.utils.to_categorical(y_train, num_classes)
y_val = keras.utils.to_categorical(y_val, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

Then, start the search for the best hyperparameter configuration. All the arguments passed to search is passed to model.fit() in each execution. Remember to pass validation_data to evaluate the model.

tuner.search(x_train, y_train, epochs=2, validation_data=(x_val, y_val))

Trial 3 Complete [00h 00m 19s]
val_accuracy: 0.9665500223636627

Best val_accuracy So Far: 0.9665500223636627
Total elapsed time: 00h 00m 40s

During the search, the model-building function is called with different hyperparameter values in different trial. In each trial, the tuner would generate a new set of hyperparameter values to build the model. The model is then fit and evaluated. The metrics are recorded. The tuner progressively explores the space and finally finds a good set of hyperparameter values.
Query the results

When search is over, you can retrieve the best model(s). The model is saved at its best performing epoch evaluated on the validation_data.

# Get the top 2 models.
models = tuner.get_best_models(num_models=2)
best_model = models[0]
best_model.summary()

/usr/local/python/3.10.13/lib/python3.10/site-packages/keras/src/saving/saving_lib.py:388: UserWarning: Skipping variable loading for optimizer 'adam', because it has 2 variables whereas the saved optimizer has 18 variables. 
  trackable.load_own_variables(weights_store.get(inner_path))
/usr/local/python/3.10.13/lib/python3.10/site-packages/keras/src/saving/saving_lib.py:388: UserWarning: Skipping variable loading for optimizer 'adam', because it has 2 variables whereas the saved optimizer has 10 variables. 
  trackable.load_own_variables(weights_store.get(inner_path))

Model: "sequential"

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━┓
┃ Layer (type)                    ┃ Output Shape              ┃    Param # ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━┩
│ flatten (Flatten)               │ (32, 784)                 │          0 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense (Dense)                   │ (32, 416)                 │    326,560 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense_1 (Dense)                 │ (32, 512)                 │    213,504 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense_2 (Dense)                 │ (32, 32)                  │     16,416 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dropout (Dropout)               │ (32, 32)                  │          0 │
├─────────────────────────────────┼───────────────────────────┼────────────┤
│ dense_3 (Dense)                 │ (32, 10)                  │        330 │
└─────────────────────────────────┴───────────────────────────┴────────────┘

 Total params: 556,810 (2.12 MB)

 Trainable params: 556,810 (2.12 MB)

 Non-trainable params: 0 (0.00 B)

You can also print a summary of the search results.

tuner.results_summary()

Results summary
Results in my_dir/helloworld
Showing 10 best trials
Objective(name="val_accuracy", direction="max")

Trial 2 summary
Hyperparameters:
num_layers: 3
units_0: 416
activation: relu
dropout: True
lr: 0.0001324166048504802
units_1: 512
units_2: 32
Score: 0.9665500223636627

Trial 0 summary
Hyperparameters:
num_layers: 1
units_0: 128
activation: tanh
dropout: False
lr: 0.001425162921397599
Score: 0.9623999893665314

Trial 1 summary
Hyperparameters:
num_layers: 2
units_0: 512
activation: tanh
dropout: True
lr: 0.0010584293918512798
units_1: 32
Score: 0.9606499969959259

You will find detailed logs, checkpoints, etc, in the folder my_dir/helloworld, i.e. directory/project_name.

You can also visualize the tuning results using TensorBoard and HParams plugin. For more information, please following this link.
Retrain the model

If you want to train the model with the entire dataset, you may retrieve the best hyperparameters and retrain the model by yourself.

# Get the top 2 hyperparameters.
best_hps = tuner.get_best_hyperparameters(5)
# Build the model with the best hp.
model = build_model(best_hps[0])
# Fit with the entire dataset.
x_all = np.concatenate((x_train, x_val))
y_all = np.concatenate((y_train, y_val))
model.fit(x=x_all, y=y_all, epochs=1)

1/1875 [37m━━━━━━━━━━━━━━━━━━━━  17:57 575ms/step - accuracy: 0.1250 - loss: 2.3113

<keras.src.callbacks.history.History at 0x7f31883d9e10>

Tune model training

To tune the model building process, we need to subclass the HyperModel class, which also makes it easy to share and reuse hypermodels.

We need to override HyperModel.build() and HyperModel.fit() to tune the model building and training process respectively. A HyperModel.build() method is the same as the model-building function, which creates a Keras model using the hyperparameters and returns it.

In HyperModel.fit(), you can access the model returned by HyperModel.build(),hp and all the arguments passed to search(). You need to train the model and return the training history.

In the following code, we will tune the shuffle argument in model.fit().

It is generally not needed to tune the number of epochs because a built-in callback is passed to model.fit() to save the model at its best epoch evaluated by the validation_data.

    Note: The **kwargs should always be passed to model.fit() because it contains the callbacks for model saving and tensorboard plugins.

class MyHyperModel(keras_tuner.HyperModel):
    def build(self, hp):
        model = keras.Sequential()
        model.add(layers.Flatten())
        model.add(
            layers.Dense(
                units=hp.Int("units", min_value=32, max_value=512, step=32),
                activation="relu",
            )
        )
        model.add(layers.Dense(10, activation="softmax"))
        model.compile(
            optimizer="adam",
            loss="categorical_crossentropy",
            metrics=["accuracy"],
        )
        return model

    def fit(self, hp, model, *args, **kwargs):
        return model.fit(
            *args,
            # Tune whether to shuffle the data in each epoch.
            shuffle=hp.Boolean("shuffle"),
            **kwargs,
        )

Again, we can do a quick check to see if the code works correctly.

hp = keras_tuner.HyperParameters()
hypermodel = MyHyperModel()
model = hypermodel.build(hp)
hypermodel.fit(hp, model, np.random.rand(100, 28, 28), np.random.rand(100, 10))


<keras.src.callbacks.history.History at 0x7f318865c100>

Tune data preprocessing

To tune data preprocessing, we just add an additional step in HyperModel.fit(), where we can access the dataset from the arguments. In the following code, we tune whether to normalize the data before training the model. This time we explicitly put x and y in the function signature because we need to use them.

class MyHyperModel(keras_tuner.HyperModel):
    def build(self, hp):
        model = keras.Sequential()
        model.add(layers.Flatten())
        model.add(
            layers.Dense(
                units=hp.Int("units", min_value=32, max_value=512, step=32),
                activation="relu",
            )
        )
        model.add(layers.Dense(10, activation="softmax"))
        model.compile(
            optimizer="adam",
            loss="categorical_crossentropy",
            metrics=["accuracy"],
        )
        return model

    def fit(self, hp, model, x, y, **kwargs):
        if hp.Boolean("normalize"):
            x = layers.Normalization()(x)
        return model.fit(
            x,
            y,
            # Tune whether to shuffle the data in each epoch.
            shuffle=hp.Boolean("shuffle"),
            **kwargs,
        )


hp = keras_tuner.HyperParameters()
hypermodel = MyHyperModel()
model = hypermodel.build(hp)
hypermodel.fit(hp, model, np.random.rand(100, 28, 28), np.random.rand(100, 10))

<keras.src.callbacks.history.History at 0x7f31ba836200>

If a hyperparameter is used both in build() and fit(), you can define it in build() and use hp.get(hp_name) to retrieve it in fit(). We use the image size as an example. It is both used as the input shape in build(), and used by data prerprocessing step to crop the images in fit().

class MyHyperModel(keras_tuner.HyperModel):
    def build(self, hp):
        image_size = hp.Int("image_size", 10, 28)
        inputs = keras.Input(shape=(image_size, image_size))
        outputs = layers.Flatten()(inputs)
        outputs = layers.Dense(
            units=hp.Int("units", min_value=32, max_value=512, step=32),
            activation="relu",
        )(outputs)
        outputs = layers.Dense(10, activation="softmax")(outputs)
        model = keras.Model(inputs, outputs)
        model.compile(
            optimizer="adam",
            loss="categorical_crossentropy",
            metrics=["accuracy"],
        )
        return model

    def fit(self, hp, model, x, y, validation_data=None, **kwargs):
        if hp.Boolean("normalize"):
            x = layers.Normalization()(x)
        image_size = hp.get("image_size")
        cropped_x = x[:, :image_size, :image_size, :]
        if validation_data:
            x_val, y_val = validation_data
            cropped_x_val = x_val[:, :image_size, :image_size, :]
            validation_data = (cropped_x_val, y_val)
        return model.fit(
            cropped_x,
            y,
            # Tune whether to shuffle the data in each epoch.
            shuffle=hp.Boolean("shuffle"),
            validation_data=validation_data,
            **kwargs,
        )


tuner = keras_tuner.RandomSearch(
    MyHyperModel(),
    objective="val_accuracy",
    max_trials=3,
    overwrite=True,
    directory="my_dir",
    project_name="tune_hypermodel",
)

tuner.search(x_train, y_train, epochs=2, validation_data=(x_val, y_val))

Trial 3 Complete [00h 00m 04s]
val_accuracy: 0.9567000269889832

Best val_accuracy So Far: 0.9685999751091003
Total elapsed time: 00h 00m 13s

Retrain the model

Using HyperModel also allows you to retrain the best model by yourself.

hypermodel = MyHyperModel()
best_hp = tuner.get_best_hyperparameters()[0]
model = hypermodel.build(best_hp)
hypermodel.fit(best_hp, model, x_all, y_all, epochs=1)

1/1875 [37m━━━━━━━━━━━━━━━━━━━━  9:00 289ms/step - accuracy: 0.0000e+00 - loss: 2.4352

<keras.src.callbacks.history.History at 0x7f31884b3070>

Specify the tuning objective

In all previous examples, we all just used validation accuracy ("val_accuracy") as the tuning objective to select the best model. Actually, you can use any metric as the objective. The most commonly used metric is "val_loss", which is the validation loss.
Built-in metric as the objective

There are many other built-in metrics in Keras you can use as the objective. Here is a list of the built-in metrics.

To use a built-in metric as the objective, you need to follow these steps:

    Compile the model with the the built-in metric. For example, you want to use MeanAbsoluteError(). You need to compile the model with metrics=[MeanAbsoluteError()]. You may also use its name string instead: metrics=["mean_absolute_error"]. The name string of the metric is always the snake case of the class name.

    Identify the objective name string. The name string of the objective is always in the format of f"val_{metric_name_string}". For example, the objective name string of mean squared error evaluated on the validation data should be "val_mean_absolute_error".

    Wrap it into keras_tuner.Objective. We usually need to wrap the objective into a keras_tuner.Objective object to specify the direction to optimize the objective. For example, we want to minimize the mean squared error, we can use keras_tuner.Objective("val_mean_absolute_error", "min"). The direction should be either "min" or "max".

    Pass the wrapped objective to the tuner.

You can see the following barebone code example.

def build_regressor(hp):
    model = keras.Sequential(
        [
            layers.Dense(units=hp.Int("units", 32, 128, 32), activation="relu"),
            layers.Dense(units=1),
        ]
    )
    model.compile(
        optimizer="adam",
        loss="mean_squared_error",
        # Objective is one of the metrics.
        metrics=[keras.metrics.MeanAbsoluteError()],
    )
    return model


tuner = keras_tuner.RandomSearch(
    hypermodel=build_regressor,
    # The objective name and direction.
    # Name is the f"val_{snake_case_metric_class_name}".
    objective=keras_tuner.Objective("val_mean_absolute_error", direction="min"),
    max_trials=3,
    overwrite=True,
    directory="my_dir",
    project_name="built_in_metrics",
)

tuner.search(
    x=np.random.rand(100, 10),
    y=np.random.rand(100, 1),
    validation_data=(np.random.rand(20, 10), np.random.rand(20, 1)),
)

tuner.results_summary()

Trial 3 Complete [00h 00m 01s]
val_mean_absolute_error: 0.39589792490005493

Best val_mean_absolute_error So Far: 0.34321871399879456
Total elapsed time: 00h 00m 03s
Results summary
Results in my_dir/built_in_metrics
Showing 10 best trials
Objective(name="val_mean_absolute_error", direction="min")

Trial 1 summary
Hyperparameters:
units: 32
Score: 0.34321871399879456

Trial 2 summary
Hyperparameters:
units: 128
Score: 0.39589792490005493

Trial 0 summary
Hyperparameters:
units: 96
Score: 0.5005304217338562

Custom metric as the objective

You may implement your own metric and use it as the hyperparameter search objective. Here, we use mean squared error (MSE) as an example. First, we implement the MSE metric by subclassing keras.metrics.Metric. Remember to give a name to your metric using the name argument of super().__init__(), which will be used later. Note: MSE is actually a build-in metric, which can be imported with keras.metrics.MeanSquaredError. This is just an example to show how to use a custom metric as the hyperparameter search objective.

For more information about implementing custom metrics, please see this tutorial. If you would like a metric with a different function signature than update_state(y_true, y_pred, sample_weight), you can override the train_step() method of your model following this tutorial.

from keras import ops


class CustomMetric(keras.metrics.Metric):
    def __init__(self, **kwargs):
        # Specify the name of the metric as "custom_metric".
        super().__init__(name="custom_metric", **kwargs)
        self.sum = self.add_weight(name="sum", initializer="zeros")
        self.count = self.add_weight(name="count", dtype="int32", initializer="zeros")

    def update_state(self, y_true, y_pred, sample_weight=None):
        values = ops.square(y_true - y_pred)
        count = ops.shape(y_true)[0]
        if sample_weight is not None:
            sample_weight = ops.cast(sample_weight, self.dtype)
            values *= sample_weight
            count *= sample_weight
        self.sum.assign_add(ops.sum(values))
        self.count.assign_add(count)

    def result(self):
        return self.sum / ops.cast(self.count, "float32")

    def reset_state(self):
        self.sum.assign(0)
        self.count.assign(0)

Run the search with the custom objective.

def build_regressor(hp):
    model = keras.Sequential(
        [
            layers.Dense(units=hp.Int("units", 32, 128, 32), activation="relu"),
            layers.Dense(units=1),
        ]
    )
    model.compile(
        optimizer="adam",
        loss="mean_squared_error",
        # Put custom metric into the metrics.
        metrics=[CustomMetric()],
    )
    return model


tuner = keras_tuner.RandomSearch(
    hypermodel=build_regressor,
    # Specify the name and direction of the objective.
    objective=keras_tuner.Objective("val_custom_metric", direction="min"),
    max_trials=3,
    overwrite=True,
    directory="my_dir",
    project_name="custom_metrics",
)

tuner.search(
    x=np.random.rand(100, 10),
    y=np.random.rand(100, 1),
    validation_data=(np.random.rand(20, 10), np.random.rand(20, 1)),
)

tuner.results_summary()

Trial 3 Complete [00h 00m 01s]
val_custom_metric: 0.2830956280231476

Best val_custom_metric So Far: 0.2529197633266449
Total elapsed time: 00h 00m 02s
Results summary
Results in my_dir/custom_metrics
Showing 10 best trials
Objective(name="val_custom_metric", direction="min")

Trial 0 summary
Hyperparameters:
units: 32
Score: 0.2529197633266449

Trial 2 summary
Hyperparameters:
units: 128
Score: 0.2830956280231476

Trial 1 summary
Hyperparameters:
units: 96
Score: 0.4656866192817688

If your custom objective is hard to put into a custom metric, you can also evaluate the model by yourself in HyperModel.fit() and return the objective value. The objective value would be minimized by default. In this case, you don't need to specify the objective when initializing the tuner. However, in this case, the metric value will not be tracked in the Keras logs by only KerasTuner logs. Therefore, these values would not be displayed by any TensorBoard view using the Keras metrics.

class HyperRegressor(keras_tuner.HyperModel):
    def build(self, hp):
        model = keras.Sequential(
            [
                layers.Dense(units=hp.Int("units", 32, 128, 32), activation="relu"),
                layers.Dense(units=1),
            ]
        )
        model.compile(
            optimizer="adam",
            loss="mean_squared_error",
        )
        return model

    def fit(self, hp, model, x, y, validation_data, **kwargs):
        model.fit(x, y, **kwargs)
        x_val, y_val = validation_data
        y_pred = model.predict(x_val)
        # Return a single float to minimize.
        return np.mean(np.abs(y_pred - y_val))


tuner = keras_tuner.RandomSearch(
    hypermodel=HyperRegressor(),
    # No objective to specify.
    # Objective is the return value of `HyperModel.fit()`.
    max_trials=3,
    overwrite=True,
    directory="my_dir",
    project_name="custom_eval",
)
tuner.search(
    x=np.random.rand(100, 10),
    y=np.random.rand(100, 1),
    validation_data=(np.random.rand(20, 10), np.random.rand(20, 1)),
)

tuner.results_summary()

Trial 3 Complete [00h 00m 01s]
default_objective: 0.6571611521766413

Best default_objective So Far: 0.40719249752993525
Total elapsed time: 00h 00m 02s
Results summary
Results in my_dir/custom_eval
Showing 10 best trials
Objective(name="default_objective", direction="min")

Trial 1 summary
Hyperparameters:
units: 128
Score: 0.40719249752993525

Trial 0 summary
Hyperparameters:
units: 96
Score: 0.4992297225533352

Trial 2 summary
Hyperparameters:
units: 32
Score: 0.6571611521766413

If you have multiple metrics to track in KerasTuner, but only use one of them as the objective, you can return a dictionary, whose keys are the metric names and the values are the metrics values, for example, return {"metric_a": 1.0, "metric_b", 2.0}. Use one of the keys as the objective name, for example, keras_tuner.Objective("metric_a", "min").

class HyperRegressor(keras_tuner.HyperModel):
    def build(self, hp):
        model = keras.Sequential(
            [
                layers.Dense(units=hp.Int("units", 32, 128, 32), activation="relu"),
                layers.Dense(units=1),
            ]
        )
        model.compile(
            optimizer="adam",
            loss="mean_squared_error",
        )
        return model

    def fit(self, hp, model, x, y, validation_data, **kwargs):
        model.fit(x, y, **kwargs)
        x_val, y_val = validation_data
        y_pred = model.predict(x_val)
        # Return a dictionary of metrics for KerasTuner to track.
        return {
            "metric_a": -np.mean(np.abs(y_pred - y_val)),
            "metric_b": np.mean(np.square(y_pred - y_val)),
        }


tuner = keras_tuner.RandomSearch(
    hypermodel=HyperRegressor(),
    # Objective is one of the keys.
    # Maximize the negative MAE, equivalent to minimize MAE.
    objective=keras_tuner.Objective("metric_a", "max"),
    max_trials=3,
    overwrite=True,
    directory="my_dir",
    project_name="custom_eval_dict",
)
tuner.search(
    x=np.random.rand(100, 10),
    y=np.random.rand(100, 1),
    validation_data=(np.random.rand(20, 10), np.random.rand(20, 1)),
)

tuner.results_summary()

Trial 3 Complete [00h 00m 01s]
metric_a: -0.39470441501524833

Best metric_a So Far: -0.3836997988261662
Total elapsed time: 00h 00m 02s
Results summary
Results in my_dir/custom_eval_dict
Showing 10 best trials
Objective(name="metric_a", direction="max")

Trial 1 summary
Hyperparameters:
units: 64
Score: -0.3836997988261662

Trial 2 summary
Hyperparameters:
units: 32
Score: -0.39470441501524833

Trial 0 summary
Hyperparameters:
units: 96
Score: -0.46081380465766364

Tune end-to-end workflows

In some cases, it is hard to align your code into build and fit functions. You can also keep your end-to-end workflow in one place by overriding Tuner.run_trial(), which gives you full control of a trial. You can see it as a black-box optimizer for anything.
Tune any function

For example, you can find a value of x, which minimizes f(x)=x*x+1. In the following code, we just define x as a hyperparameter, and return f(x) as the objective value. The hypermodel and objective argument for initializing the tuner can be omitted.

class MyTuner(keras_tuner.RandomSearch):
    def run_trial(self, trial, *args, **kwargs):
        # Get the hp from trial.
        hp = trial.hyperparameters
        # Define "x" as a hyperparameter.
        x = hp.Float("x", min_value=-1.0, max_value=1.0)
        # Return the objective value to minimize.
        return x * x + 1


tuner = MyTuner(
    # No hypermodel or objective specified.
    max_trials=20,
    overwrite=True,
    directory="my_dir",
    project_name="tune_anything",
)

# No need to pass anything to search()
# unless you use them in run_trial().
tuner.search()
print(tuner.get_best_hyperparameters()[0].get("x"))

Trial 20 Complete [00h 00m 00s]
default_objective: 1.6547719581194267

Best default_objective So Far: 1.0013236767905302
Total elapsed time: 00h 00m 00s
0.03638236922645777

Keep Keras code separate

You can keep all your Keras code unchanged and use KerasTuner to tune it. It is useful if you cannot modify the Keras code for some reason.

It also gives you more flexibility. You don't have to separate the model building and training code apart. However, this workflow would not help you save the model or connect with the TensorBoard plugins.

To save the model, you can use trial.trial_id, which is a string to uniquely identify a trial, to construct different paths to save the models from different trials.

import os


def keras_code(units, optimizer, saving_path):
    # Build model
    model = keras.Sequential(
        [
            layers.Dense(units=units, activation="relu"),
            layers.Dense(units=1),
        ]
    )
    model.compile(
        optimizer=optimizer,
        loss="mean_squared_error",
    )

    # Prepare data
    x_train = np.random.rand(100, 10)
    y_train = np.random.rand(100, 1)
    x_val = np.random.rand(20, 10)
    y_val = np.random.rand(20, 1)

    # Train & eval model
    model.fit(x_train, y_train)

    # Save model
    model.save(saving_path)

    # Return a single float as the objective value.
    # You may also return a dictionary
    # of {metric_name: metric_value}.
    y_pred = model.predict(x_val)
    return np.mean(np.abs(y_pred - y_val))


class MyTuner(keras_tuner.RandomSearch):
    def run_trial(self, trial, **kwargs):
        hp = trial.hyperparameters
        return keras_code(
            units=hp.Int("units", 32, 128, 32),
            optimizer=hp.Choice("optimizer", ["adam", "adadelta"]),
            saving_path=os.path.join("/tmp", f"{trial.trial_id}.keras"),
        )


tuner = MyTuner(
    max_trials=3,
    overwrite=True,
    directory="my_dir",
    project_name="keep_code_separate",
)
tuner.search()
# Retraining the model
best_hp = tuner.get_best_hyperparameters()[0]
keras_code(**best_hp.values, saving_path="/tmp/best_model.keras")

Trial 3 Complete [00h 00m 00s]
default_objective: 0.18014027375230962

Best default_objective So Far: 0.18014027375230962
Total elapsed time: 00h 00m 03s

1/4 ━━━━━[37m━━━━━━━━━━━━━━━ 0s 172ms/step - loss: 0.5030



4/4 ━━━━━━━━━━━━━━━━━━━━ 0s 60ms/step - loss: 0.5288



4/4 ━━━━━━━━━━━━━━━━━━━━ 0s 61ms/step - loss: 0.5367

1/1 ━━━━━━━━━━━━━━━━━━━━ 0s 27ms/step



1/1 ━━━━━━━━━━━━━━━━━━━━ 0s 28ms/step

0.5918120126201316

KerasTuner includes pre-made tunable applications: HyperResNet and HyperXception

These are ready-to-use hypermodels for computer vision.

They come pre-compiled with loss="categorical_crossentropy" and metrics=["accuracy"].

from keras_tuner.applications import HyperResNet

hypermodel = HyperResNet(input_shape=(28, 28, 1), classes=10)

tuner = keras_tuner.RandomSearch(
    hypermodel,
    objective="val_accuracy",
    max_trials=2,
    overwrite=True,
    directory="my_dir",
    project_name="built_in_hypermodel",
)

##AutoKeras - Image Classification

!pip install autokeras

import numpy as np
import tensorflow as tf
from keras.datasets import mnist
import autokeras as ak


(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train = x_train[:100]
y_train = y_train[:100]
x_test = x_test[:100]
y_test = y_test[:100]
print(x_train.shape)  # (60000, 28, 28)
print(y_train.shape)  # (60000,)
print(y_train[:3])  # array([7, 2, 1], dtype=uint8)


The second step is to run the ImageClassifier. 
It is recommended have more trials for more complicated datasets. 
This is just a quick demo of MNIST, so we set max_trials to 1. For the same reason, 
we set epochs to 10. You can also leave the epochs unspecified for an adaptive number of epochs.

# Initialize the image classifier.
clf = ak.ImageClassifier(overwrite=True, max_trials=1)
# Feed the image classifier with training data.
clf.fit(x_train, y_train, epochs=1)
# Predict with the best model.
predicted_y = clf.predict(x_test)
print(predicted_y)
# Evaluate the best model with testing data.
print(clf.evaluate(x_test, y_test))


Validation Data
By default, AutoKeras use the last 20% of training data as validation data. 
As shown in the example below, you can use validation_split to specify the percentage.

clf.fit(
    x_train,
    y_train,
    # Split the training data and use the last 15% as validation data.
    validation_split=0.15,
    epochs=1,
)

You can also use your own validation set instead of splitting it from the training data 
with validation_data.

split = 50000
x_val = x_train[split:]
y_val = y_train[split:]
x_train = x_train[:split]
y_train = y_train[:split]
clf.fit(
    x_train,
    y_train,
    # Use your own validation set.
    validation_data=(x_val, y_val),
    epochs=1,
)

Customized Search Space
For advanced users, you may customize your search space by using AutoModel instead of ImageClassifier. 
You can configure the ImageBlock for some high-level configurations, 
e.g., block_type for the type of neural network to search, normalize 
for whether to do data normalization, augment for whether to do data augmentation. 
You can also do not specify these arguments, which would leave the different choices to be tuned 
automatically. See the following example for detail.


input_node = ak.ImageInput()
output_node = ak.ImageBlock(
    # Only search ResNet architectures.
    block_type="resnet",
    # Normalize the dataset.
    normalize=True,
    # Do not do data augmentation.
    augment=False,
)(input_node)
output_node = ak.ClassificationHead()(output_node)
clf = ak.AutoModel(
    inputs=input_node, outputs=output_node, overwrite=True, max_trials=1
)

clf.fit(x_train, y_train, epochs=1)


The usage of AutoModel is similar to the functional API of Keras. 
Basically, you are building a graph, whose edges are blocks and the nodes are intermediate outputs of blocks. 
To add an edge from input_node to output_node with output_node = ak.some_block(input_node).

You can even also use more fine grained blocks to customize the search space even further. 
See the following example.


input_node = ak.ImageInput()
output_node = ak.Normalization()(input_node)
output_node = ak.ImageAugmentation(horizontal_flip=False)(output_node)
output_node = ak.ResNetBlock(version="v2")(output_node)
output_node = ak.ClassificationHead()(output_node)
clf = ak.AutoModel(
    inputs=input_node, outputs=output_node, overwrite=True, max_trials=1
)
clf.fit(x_train, y_train, epochs=1)


Data Format
The AutoKeras ImageClassifier is quite flexible for the data format.
For the image, it accepts data formats both with and without the channel dimension. 
The images in the MNIST dataset do not have the channel dimension. 
Each image is a matrix with shape (28, 28). AutoKeras also accepts images of three dimensions 
with the channel dimension at last, e.g., (32, 32, 3), (28, 28, 1).
For the classification labels, AutoKeras accepts both plain labels, i.e. strings or integers, 
and one-hot encoded encoded labels, i.e. vectors of 0s and 1s.

So if you prepare your data in the following way, the ImageClassifier should still work.

(x_train, y_train), (x_test, y_test) = mnist.load_data()
# Reshape the images to have the channel dimension.
x_train = x_train.reshape(x_train.shape + (1,))
x_test = x_test.reshape(x_test.shape + (1,))
# One-hot encode the labels.
eye = np.eye(10)
y_train = eye[y_train]
y_test = eye[y_test]
print(x_train.shape)  # (60000, 28, 28, 1)
print(y_train.shape)  # (60000, 10)
print(y_train[:3])
# array([[0., 0., 0., 0., 0., 1., 0., 0., 0., 0.],
#        [1., 0., 0., 0., 0., 0., 0., 0., 0., 0.],
#        [0., 0., 0., 0., 1., 0., 0., 0., 0., 0.]])

We also support using tf.data.Dataset format for the training data.

train_set = tf.data.Dataset.from_tensor_slices(((x_train,), (y_train,)))
test_set = tf.data.Dataset.from_tensor_slices(((x_test,), (y_test,)))
clf = ak.ImageClassifier(overwrite=True, max_trials=1)
# Feed the tensorflow Dataset to the classifier.
clf.fit(train_set, epochs=1)
# Predict with the best model.
predicted_y = clf.predict(test_set)
# Evaluate the best model with testing data.
print(clf.evaluate(test_set))

##AutoKeras - Text Classification

!pip install autokeras
import os
import keras
import numpy as np
import tensorflow as tf
from sklearn.datasets import load_files
import autokeras as ak



dataset = keras.utils.get_file(
    fname="aclImdb.tar.gz",
    origin="http://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz",
    extract=True,
)
# set path to dataset
IMDB_DATADIR = os.path.join(os.path.dirname(dataset), "aclImdb")
classes = ["pos", "neg"]
train_data = load_files(
    os.path.join(IMDB_DATADIR, "train"), shuffle=True, categories=classes
)
test_data = load_files(
    os.path.join(IMDB_DATADIR, "test"), shuffle=False, categories=classes
)
x_train = np.array(train_data.data)[:100]
y_train = np.array(train_data.target)[:100]
x_test = np.array(test_data.data)[:100]
y_test = np.array(test_data.target)[:100]
print(x_train.shape)  # (25000,)
print(y_train.shape)  # (25000, 1)
print(x_train[0][:50])  # this film was just brilliant casting


The second step is to run the TextClassifier. 
As a quick demo, we set epochs to 2. You can also leave the epochs unspecified 
for an adaptive number of epochs.


# Initialize the text classifier.
clf = ak.TextClassifier(
    overwrite=True, max_trials=1
)  # It only tries 1 model as a quick demo.
# Feed the text classifier with training data.
clf.fit(x_train, y_train, epochs=1, batch_size=2)
# Predict with the best model.
predicted_y = clf.predict(x_test)
# Evaluate the best model with testing data.
print(clf.evaluate(x_test, y_test))


Validation Data
By default, AutoKeras use the last 20% of training data as validation data. 
As shown in the example below, you can use validation_split to specify the percentage.

clf.fit(
    x_train,
    y_train,
    # Split the training data and use the last 15% as validation data.
    validation_split=0.15,
    epochs=1,
    batch_size=2,
)

You can also use your own validation set instead of splitting 
it from the training data with validation_data.

split = 5
x_val = x_train[split:]
y_val = y_train[split:]
x_train = x_train[:split]
y_train = y_train[:split]
clf.fit(
    x_train,
    y_train,
    epochs=1,
    # Use your own validation set.
    validation_data=(x_val, y_val),
    batch_size=2,
)


Customized Search Space
For advanced users, you may customize your search space by using AutoModel instead of TextClassifier. 
You can configure the TextBlock for some high-level configurations. 
You can also do not specify these arguments, which would leave the different choices to be tuned 
automatically. See the following example for detail.

input_node = ak.TextInput()
output_node = ak.TextBlock()(input_node)
output_node = ak.ClassificationHead()(output_node)
clf = ak.AutoModel(
    inputs=input_node, outputs=output_node, overwrite=True, max_trials=1
)
clf.fit(x_train, y_train, epochs=1, batch_size=2)


Data Format
The AutoKeras TextClassifier is quite flexible for the data format.
For the text, the input data should be one-dimensional For the classification labels, 
AutoKeras accepts both plain labels, i.e. strings or integers, and one-hot encoded encoded labels, 
i.e. vectors of 0s and 1s.

We also support using tf.data.Dataset format for the training data.


train_set = tf.data.Dataset.from_tensor_slices(((x_train,), (y_train,))).batch(
    2
)
test_set = tf.data.Dataset.from_tensor_slices(((x_test,), (y_test,))).batch(2)
clf = ak.TextClassifier(overwrite=True, max_trials=1)
# Feed the tensorflow Dataset to the classifier.
clf.fit(train_set.take(2), epochs=1)
# Predict with the best model.
predicted_y = clf.predict(test_set.take(2))
# Evaluate the best model with testing data.
print(clf.evaluate(test_set.take(2)))



###Scikit-Learn API wrappers

[source]
SKLearnClassifier class

keras.wrappers.SKLearnClassifier(
    model, warm_start=False, model_kwargs=None, fit_kwargs=None
)

scikit-learn compatible classifier wrapper for Keras models.

Note that there are sources of randomness in model initialization and training. Refer to Reproducibility in Keras Models on how to control randomness.

Arguments

    model: Model. An instance of Model, or a callable returning such an object. Note that if input is a Model, it will be cloned using keras.models.clone_model before being fitted, unless warm_start=True. The Model instance needs to be passed as already compiled. If callable, it must accept at least X and y as keyword arguments. Other arguments must be accepted if passed as model_kwargs by the user.
    warm_start: bool, defaults to False. Whether to reuse the model weights from the previous fit. If True, the given model won't be cloned and the weights from the previous fit will be reused.
    model_kwargs: dict, defaults to None. Keyword arguments passed to model, if model is callable.
    fit_kwargs: dict, defaults to None. Keyword arguments passed to model.fit. These can also be passed directly to the fit method of the scikit-learn wrapper. The values passed directly to the fit method take precedence over these.

Attributes

    model_ : Model The fitted model.
    history_ : dict The history of the fit, returned by model.fit.
    classes_ : array-like, shape=(n_classes,) The classes labels.

Example

Here we use a function which creates a basic MLP model dynamically choosing the input and output shapes. We will use this to create our scikit-learn model.

from keras.src.layers import Dense, Input, Model

def dynamic_model(X, y, loss, layers=[10]):
    # Creates a basic MLP model dynamically choosing the input and
    # output shapes.
    n_features_in = X.shape[1]
    inp = Input(shape=(n_features_in,))

    hidden = inp
    for layer_size in layers:
        hidden = Dense(layer_size, activation="relu")(hidden)

    n_outputs = y.shape[1] if len(y.shape) > 1 else 1
    out = [Dense(n_outputs, activation="softmax")(hidden)]
    model = Model(inp, out)
    model.compile(loss=loss, optimizer="rmsprop")

    return model

You can then use this function to create a scikit-learn compatible model and fit it on some data.

from sklearn.datasets import make_classification
from keras.wrappers import SKLearnClassifier

X, y = make_classification(n_samples=1000, n_features=10, n_classes=3)
est = SKLearnClassifier(
    model=dynamic_model,
    model_kwargs={
        "loss": "categorical_crossentropy",
        "layers": [20, 20, 20],
    },
)

est.fit(X, y, epochs=5)

[source]
SKLearnRegressor class

keras.wrappers.SKLearnRegressor(
    model, warm_start=False, model_kwargs=None, fit_kwargs=None
)

scikit-learn compatible regressor wrapper for Keras models.

Note that there are sources of randomness in model initialization and training. Refer to Reproducibility in Keras Models on how to control randomness.

Arguments

    model: Model. An instance of Model, or a callable returning such an object. Note that if input is a Model, it will be cloned using keras.models.clone_model before being fitted, unless warm_start=True. The Model instance needs to be passed as already compiled. If callable, it must accept at least X and y as keyword arguments. Other arguments must be accepted if passed as model_kwargs by the user.
    warm_start: bool, defaults to False. Whether to reuse the model weights from the previous fit. If True, the given model won't be cloned and the weights from the previous fit will be reused.
    model_kwargs: dict, defaults to None. Keyword arguments passed to model, if model is callable.
    fit_kwargs: dict, defaults to None. Keyword arguments passed to model.fit. These can also be passed directly to the fit method of the scikit-learn wrapper. The values passed directly to the fit method take precedence over these.

Attributes

    model_ : Model The fitted model.

Example

Here we use a function which creates a basic MLP model dynamically choosing the input and output shapes. We will use this to create our scikit-learn model.

from keras.src.layers import Dense, Input, Model

def dynamic_model(X, y, loss, layers=[10]):
    # Creates a basic MLP model dynamically choosing the input and
    # output shapes.
    n_features_in = X.shape[1]
    inp = Input(shape=(n_features_in,))

    hidden = inp
    for layer_size in layers:
        hidden = Dense(layer_size, activation="relu")(hidden)

    n_outputs = y.shape[1] if len(y.shape) > 1 else 1
    out = [Dense(n_outputs, activation="softmax")(hidden)]
    model = Model(inp, out)
    model.compile(loss=loss, optimizer="rmsprop")

    return model

You can then use this function to create a scikit-learn compatible model and fit it on some data.

from sklearn.datasets import make_regression
from keras.wrappers import SKLearnRegressor

X, y = make_regression(n_samples=1000, n_features=10)
est = SKLearnRegressor(
    model=dynamic_model,
    model_kwargs={
        "loss": "mse",
        "layers": [20, 20, 20],
    },
)

est.fit(X, y, epochs=5)

[source]
SKLearnTransformer class

keras.wrappers.SKLearnTransformer(
    model, warm_start=False, model_kwargs=None, fit_kwargs=None
)

scikit-learn compatible transformer wrapper for Keras models.

Note that this is a scikit-learn compatible transformer, and not a transformer in the deep learning sense.

Also note that there are sources of randomness in model initialization and training. Refer to Reproducibility in Keras Models on how to control randomness.

Arguments

    model: Model. An instance of Model, or a callable returning such an object. Note that if input is a Model, it will be cloned using keras.models.clone_model before being fitted, unless warm_start=True. The Model instance needs to be passed as already compiled. If callable, it must accept at least X and y as keyword arguments. Other arguments must be accepted if passed as model_kwargs by the user.
    warm_start: bool, defaults to False. Whether to reuse the model weights from the previous fit. If True, the given model won't be cloned and the weights from the previous fit will be reused.
    model_kwargs: dict, defaults to None. Keyword arguments passed to model, if model is callable.
    fit_kwargs: dict, defaults to None. Keyword arguments passed to model.fit. These can also be passed directly to the fit method of the scikit-learn wrapper. The values passed directly to the fit method take precedence over these.

Attributes

    model_ : Model The fitted model.
    history_ : dict The history of the fit, returned by model.fit.

Example

A common use case for a scikit-learn transformer, is to have a step which gives you the embedding of your data. Here we assume my_package.my_model is a Keras model which takes the input and gives embeddings of the data, and my_package.my_data is your dataset loader.

from my_package import my_model, my_data
from keras.wrappers import SKLearnTransformer
from sklearn.frozen import FrozenEstimator # requires scikit-learn>=1.6
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import HistGradientBoostingClassifier

X, y = my_data()

trs = FrozenEstimator(SKLearnTransformer(model=my_model))
pipe = make_pipeline(trs, HistGradientBoostingClassifier())
pipe.fit(X, y)

Note that in the above example, FrozenEstimator prevents any further training of the transformer step in the pipeline, which can be the case if you don't want to change the embedding model at hand.

###Python & NumPy utilities

[source]
set_random_seed function

keras.utils.set_random_seed(seed)

Sets all random seeds (Python, NumPy, and backend framework, e.g. TF).

You can use this utility to make almost any Keras program fully deterministic. Some limitations apply in cases where network communications are involved (e.g. parameter server distribution), which creates additional sources of randomness, or when certain non-deterministic cuDNN ops are involved.

Calling this utility is equivalent to the following:

import random
random.seed(seed)

import numpy as np
np.random.seed(seed)

import tensorflow as tf  # Only if TF is installed
tf.random.set_seed(seed)

import torch  # Only if the backend is 'torch'
torch.manual_seed(seed)

Note that the TensorFlow seed is set even if you're not using TensorFlow as your backend framework, since many workflows leverage tf.data pipelines (which feature random shuffling). Likewise many workflows might leverage NumPy APIs.

Arguments

    seed: Integer, the random seed to use.

[source]
split_dataset function

keras.utils.split_dataset(
    dataset, left_size=None, right_size=None, shuffle=False, seed=None
)

Splits a dataset into a left half and a right half (e.g. train / test).

Arguments

    dataset: A tf.data.Dataset, a torch.utils.data.Dataset object, or a list/tuple of arrays with the same length.
    left_size: If float (in the range [0, 1]), it signifies the fraction of the data to pack in the left dataset. If integer, it signifies the number of samples to pack in the left dataset. If None, defaults to the complement to right_size. Defaults to None.
    right_size: If float (in the range [0, 1]), it signifies the fraction of the data to pack in the right dataset. If integer, it signifies the number of samples to pack in the right dataset. If None, defaults to the complement to left_size. Defaults to None.
    shuffle: Boolean, whether to shuffle the data before splitting it.
    seed: A random seed for shuffling.

Returns

    A tuple of two tf.data.Dataset objects: the left and right splits.

Example

>>> data = np.random.random(size=(1000, 4))
>>> left_ds, right_ds = keras.utils.split_dataset(data, left_size=0.8)
>>> int(left_ds.cardinality())
800
>>> int(right_ds.cardinality())
200

[source]
pack_x_y_sample_weight function

keras.utils.pack_x_y_sample_weight(x, y=None, sample_weight=None)

Packs user-provided data into a tuple.

This is a convenience utility for packing data into the tuple formats that Model.fit() uses.

Example

>>> x = ops.ones((10, 1))
>>> data = pack_x_y_sample_weight(x)
>>> isinstance(data, ops.Tensor)
True
>>> y = ops.ones((10, 1))
>>> data = pack_x_y_sample_weight(x, y)
>>> isinstance(data, tuple)
True
>>> x, y = data

Arguments

    x: Features to pass to Model.
    y: Ground-truth targets to pass to Model.
    sample_weight: Sample weight for each element.

Returns

Tuple in the format used in Model.fit().

[source]
get_file function

keras.utils.get_file(
    fname=None,
    origin=None,
    untar=False,
    md5_hash=None,
    file_hash=None,
    cache_subdir="datasets",
    hash_algorithm="auto",
    extract=False,
    archive_format="auto",
    cache_dir=None,
    force_download=False,
)

Downloads a file from a URL if it not already in the cache.

By default the file at the url origin is downloaded to the cache_dir ~/.keras, placed in the cache_subdir datasets, and given the filename fname. The final location of a file example.txt would therefore be ~/.keras/datasets/example.txt. Files in .tar, .tar.gz, .tar.bz, and .zip formats can also be extracted.

Passing a hash will verify the file after download. The command line programs shasum and sha256sum can compute the hash.

Example

path_to_downloaded_file = get_file(
    origin="https://storage.googleapis.com/download.tensorflow.org/example_images/flower_photos.tgz",
    extract=True,
)

Arguments

    fname: If the target is a single file, this is your desired local name for the file. If None, the name of the file at origin will be used. If downloading and extracting a directory archive, the provided fname will be used as extraction directory name (only if it doesn't have an extension).
    origin: Original URL of the file.
    untar: Deprecated in favor of extract argument. Boolean, whether the file is a tar archive that should be extracted.
    md5_hash: Deprecated in favor of file_hash argument. md5 hash of the file for file integrity verification.
    file_hash: The expected hash string of the file after download. The sha256 and md5 hash algorithms are both supported.
    cache_subdir: Subdirectory under the Keras cache dir where the file is saved. If an absolute path, e.g. "/path/to/folder" is specified, the file will be saved at that location.
    hash_algorithm: Select the hash algorithm to verify the file. options are "md5', "sha256', and "auto'. The default 'auto' detects the hash algorithm in use.
    extract: If True, extracts the archive. Only applicable to compressed archive files like tar or zip.
    archive_format: Archive format to try for extracting the file. Options are "auto', "tar', "zip', and None. "tar" includes tar, tar.gz, and tar.bz files. The default "auto" corresponds to ["tar", "zip"]. None or an empty list will return no matches found.
    cache_dir: Location to store cached files, when None it defaults ether $KERAS_HOME if the KERAS_HOME environment variable is set or ~/.keras/.
    force_download: If True, the file will always be re-downloaded regardless of the cache state.

Returns

Path to the downloaded file.

⚠️ Warning on malicious downloads ⚠️

Downloading something from the Internet carries a risk. NEVER download a file/archive if you do not trust the source. We recommend that you specify the file_hash argument (if the hash of the source file is known) to make sure that the file you are getting is the one you expect.

[source]
Progbar class

keras.utils.Progbar(
    target, width=20, verbose=1, interval=0.05, stateful_metrics=None, unit_name="step"
)

Displays a progress bar.

Arguments

    target: Total number of steps expected, None if unknown.
    width: Progress bar width on screen.
    verbose: Verbosity mode, 0 (silent), 1 (verbose), 2 (semi-verbose)
    stateful_metrics: Iterable of string names of metrics that should not be averaged over time. Metrics in this list will be displayed as-is. All others will be averaged by the progbar before display.
    interval: Minimum visual progress update interval (in seconds).
    unit_name: Display name for step counts (usually "step" or "sample").

[source]
PyDataset class

keras.utils.PyDataset(workers=1, use_multiprocessing=False, max_queue_size=10)

Base class for defining a parallel dataset using Python code.

Every PyDataset must implement the __getitem__() and the __len__() methods. If you want to modify your dataset between epochs, you may additionally implement on_epoch_end(), or on_epoch_begin to be called at the start of each epoch. The __getitem__() method should return a complete batch (not a single sample), and the __len__ method should return the number of batches in the dataset (rather than the number of samples).

Arguments

    workers: Number of workers to use in multithreading or multiprocessing.
    use_multiprocessing: Whether to use Python multiprocessing for parallelism. Setting this to True means that your dataset will be replicated in multiple forked processes. This is necessary to gain compute-level (rather than I/O level) benefits from parallelism. However it can only be set to True if your dataset can be safely pickled.
    max_queue_size: Maximum number of batches to keep in the queue when iterating over the dataset in a multithreaded or multiprocessed setting. Reduce this value to reduce the CPU memory consumption of your dataset. Defaults to 10.

Notes:

    PyDataset is a safer way to do multiprocessing. This structure guarantees that the model will only train once on each sample per epoch, which is not the case with Python generators.
    The arguments workers, use_multiprocessing, and max_queue_size exist to configure how fit() uses parallelism to iterate over the dataset. They are not being used by the PyDataset class directly. When you are manually iterating over a PyDataset, no parallelism is applied.

Example

from skimage.io import imread
from skimage.transform import resize
import numpy as np
import math

# Here, `x_set` is list of path to the images
# and `y_set` are the associated classes.

class CIFAR10PyDataset(keras.utils.PyDataset):

    def __init__(self, x_set, y_set, batch_size, **kwargs):
        super().__init__(**kwargs)
        self.x, self.y = x_set, y_set
        self.batch_size = batch_size

    def __len__(self):
        # Return number of batches.
        return math.ceil(len(self.x) / self.batch_size)

    def __getitem__(self, idx):
        # Return x, y for batch idx.
        low = idx * self.batch_size
        # Cap upper bound at array length; the last batch may be smaller
        # if the total number of items is not a multiple of batch size.
        high = min(low + self.batch_size, len(self.x))
        batch_x = self.x[low:high]
        batch_y = self.y[low:high]

        return np.array([
            resize(imread(file_name), (200, 200))
               for file_name in batch_x]), np.array(batch_y)

[source]
to_categorical function

keras.utils.to_categorical(x, num_classes=None)

Converts a class vector (integers) to binary class matrix.

E.g. for use with categorical_crossentropy.

Arguments

    x: Array-like with class values to be converted into a matrix (integers from 0 to num_classes - 1).
    num_classes: Total number of classes. If None, this would be inferred as max(x) + 1. Defaults to None.

Returns

A binary matrix representation of the input as a NumPy array. The class axis is placed last.

Example

>>> a = keras.utils.to_categorical([0, 1, 2, 3], num_classes=4)
>>> print(a)
[[1. 0. 0. 0.]
 [0. 1. 0. 0.]
 [0. 0. 1. 0.]
 [0. 0. 0. 1.]]

>>> b = np.array([.9, .04, .03, .03,
...               .3, .45, .15, .13,
...               .04, .01, .94, .05,
...               .12, .21, .5, .17],
...               shape=[4, 4])
>>> loss = keras.ops.categorical_crossentropy(a, b)
>>> print(np.around(loss, 5))
[0.10536 0.82807 0.1011  1.77196]

>>> loss = keras.ops.categorical_crossentropy(a, a)
>>> print(np.around(loss, 5))
[0. 0. 0. 0.]

[source]
normalize function

keras.utils.normalize(x, axis=-1, order=2)

Normalizes an array.

If the input is a NumPy array, a NumPy array will be returned. If it's a backend tensor, a backend tensor will be returned.

Arguments

    x: Array to normalize.
    axis: axis along which to normalize.
    order: Normalization order (e.g. order=2 for L2 norm).

Returns

A normalized copy of the array.
###Structured data preprocessing utilities

[source]
FeatureSpace class

keras.utils.FeatureSpace(
    features,
    output_mode="concat",
    crosses=None,
    crossing_dim=32,
    hashing_dim=32,
    num_discretization_bins=32,
    name=None,
)

One-stop utility for preprocessing and encoding structured data.

Arguments

    feature_names: Dict mapping the names of your features to their type specification, e.g. {"my_feature": "integer_categorical"} or {"my_feature": FeatureSpace.integer_categorical()}. For a complete list of all supported types, see "Available feature types" paragraph below.
    output_mode: One of "concat" or "dict". In concat mode, all features get concatenated together into a single vector. In dict mode, the FeatureSpace returns a dict of individually encoded features (with the same keys as the input dict keys).
    crosses: List of features to be crossed together, e.g. crosses=[("feature_1", "feature_2")]. The features will be "crossed" by hashing their combined value into a fixed-length vector.
    crossing_dim: Default vector size for hashing crossed features. Defaults to 32.
    hashing_dim: Default vector size for hashing features of type "integer_hashed" and "string_hashed". Defaults to 32.
    num_discretization_bins: Default number of bins to be used for discretizing features of type "float_discretized". Defaults to 32.

Available feature types:

Note that all features can be referred to by their string name, e.g. "integer_categorical". When using the string name, the default argument values are used.

# Plain float values.
FeatureSpace.float(name=None)

# Float values to be preprocessed via featurewise standardization
# (i.e. via a [`keras.layers.Normalization`](/api/layers/preprocessing_layers/numerical/normalization#normalization-class) layer).
FeatureSpace.float_normalized(name=None)

# Float values to be preprocessed via linear rescaling
# (i.e. via a [`keras.layers.Rescaling`](/api/layers/preprocessing_layers/image_preprocessing/rescaling#rescaling-class) layer).
FeatureSpace.float_rescaled(scale=1., offset=0., name=None)

# Float values to be discretized. By default, the discrete
# representation will then be one-hot encoded.
FeatureSpace.float_discretized(
    num_bins, bin_boundaries=None, output_mode="one_hot", name=None)

# Integer values to be indexed. By default, the discrete
# representation will then be one-hot encoded.
FeatureSpace.integer_categorical(
    max_tokens=None, num_oov_indices=1, output_mode="one_hot", name=None)

# String values to be indexed. By default, the discrete
# representation will then be one-hot encoded.
FeatureSpace.string_categorical(
    max_tokens=None, num_oov_indices=1, output_mode="one_hot", name=None)

# Integer values to be hashed into a fixed number of bins.
# By default, the discrete representation will then be one-hot encoded.
FeatureSpace.integer_hashed(num_bins, output_mode="one_hot", name=None)

# String values to be hashed into a fixed number of bins.
# By default, the discrete representation will then be one-hot encoded.
FeatureSpace.string_hashed(num_bins, output_mode="one_hot", name=None)

Examples

Basic usage with a dict of input data:

raw_data = {
    "float_values": [0.0, 0.1, 0.2, 0.3],
    "string_values": ["zero", "one", "two", "three"],
    "int_values": [0, 1, 2, 3],
}
dataset = tf.data.Dataset.from_tensor_slices(raw_data)

feature_space = FeatureSpace(
    features={
        "float_values": "float_normalized",
        "string_values": "string_categorical",
        "int_values": "integer_categorical",
    },
    crosses=[("string_values", "int_values")],
    output_mode="concat",
)
# Before you start using the FeatureSpace,
# you must `adapt()` it on some data.
feature_space.adapt(dataset)

# You can call the FeatureSpace on a dict of data (batched or unbatched).
output_vector = feature_space(raw_data)

Basic usage with tf.data:

# Unlabeled data
preprocessed_ds = unlabeled_dataset.map(feature_space)

# Labeled data
preprocessed_ds = labeled_dataset.map(lambda x, y: (feature_space(x), y))

Basic usage with the Keras Functional API:

# Retrieve a dict Keras Input objects
inputs = feature_space.get_inputs()
# Retrieve the corresponding encoded Keras tensors
encoded_features = feature_space.get_encoded_features()
# Build a Functional model
outputs = keras.layers.Dense(1, activation="sigmoid")(encoded_features)
model = keras.Model(inputs, outputs)

Customizing each feature or feature cross:

feature_space = FeatureSpace(
    features={
        "float_values": FeatureSpace.float_normalized(),
        "string_values": FeatureSpace.string_categorical(max_tokens=10),
        "int_values": FeatureSpace.integer_categorical(max_tokens=10),
    },
    crosses=[
        FeatureSpace.cross(("string_values", "int_values"), crossing_dim=32)
    ],
    output_mode="concat",
)

Returning a dict of integer-encoded features:

feature_space = FeatureSpace(
    features={
        "string_values": FeatureSpace.string_categorical(output_mode="int"),
        "int_values": FeatureSpace.integer_categorical(output_mode="int"),
    },
    crosses=[
        FeatureSpace.cross(
            feature_names=("string_values", "int_values"),
            crossing_dim=32,
            output_mode="int",
        )
    ],
    output_mode="dict",
)

Specifying your own Keras preprocessing layer:

# Let's say that one of the features is a short text paragraph that
# we want to encode as a vector (one vector per paragraph) via TF-IDF.
data = {
    "text": ["1st string", "2nd string", "3rd string"],
}

# There's a Keras layer for this: TextVectorization.
custom_layer = layers.TextVectorization(output_mode="tf_idf")

# We can use FeatureSpace.feature to create a custom feature
# that will use our preprocessing layer.
feature_space = FeatureSpace(
    features={
        "text": FeatureSpace.feature(
            preprocessor=custom_layer, dtype="string", output_mode="float"
        ),
    },
    output_mode="concat",
)
feature_space.adapt(tf.data.Dataset.from_tensor_slices(data))
output_vector = feature_space(data)

Retrieving the underlying Keras preprocessing layers:

# The preprocessing layer of each feature is available in `.preprocessors`.
preprocessing_layer = feature_space.preprocessors["feature1"]

# The crossing layer of each feature cross is available in `.crossers`.
# It's an instance of keras.layers.HashedCrossing.
crossing_layer = feature_space.crossers["feature1_X_feature2"]

Saving and reloading a FeatureSpace:

feature_space.save("featurespace.keras")
reloaded_feature_space = keras.models.load_model("featurespace.keras")
###Model plotting utilities

[source]
plot_model function

keras.utils.plot_model(
    model,
    to_file="model.png",
    show_shapes=False,
    show_dtype=False,
    show_layer_names=False,
    rankdir="TB",
    expand_nested=False,
    dpi=200,
    show_layer_activations=False,
    show_trainable=False,
    **kwargs
)

Converts a Keras model to dot format and save to a file.

Example

inputs = ...
outputs = ...
model = keras.Model(inputs=inputs, outputs=outputs)

dot_img_file = '/tmp/model_1.png'
keras.utils.plot_model(model, to_file=dot_img_file, show_shapes=True)

Arguments

    model: A Keras model instance
    to_file: File name of the plot image.
    show_shapes: whether to display shape information.
    show_dtype: whether to display layer dtypes.
    show_layer_names: whether to display layer names.
    rankdir: rankdir argument passed to PyDot, a string specifying the format of the plot: "TB" creates a vertical plot; "LR" creates a horizontal plot.
    expand_nested: whether to expand nested Functional models into clusters.
    dpi: Image resolution in dots per inch.
    show_layer_activations: Display layer activations (only for layers that have an activation property).
    show_trainable: whether to display if a layer is trainable.

Returns

A Jupyter notebook Image object if Jupyter is installed. This enables in-line display of the model plots in notebooks.

[source]
model_to_dot function

keras.utils.model_to_dot(
    model,
    show_shapes=False,
    show_dtype=False,
    show_layer_names=True,
    rankdir="TB",
    expand_nested=False,
    dpi=200,
    subgraph=False,
    show_layer_activations=False,
    show_trainable=False,
    **kwargs
)

Convert a Keras model to dot format.

Arguments

    model: A Keras model instance.
    show_shapes: whether to display shape information.
    show_dtype: whether to display layer dtypes.
    show_layer_names: whether to display layer names.
    rankdir: rankdir argument passed to PyDot, a string specifying the format of the plot: "TB" creates a vertical plot; "LR" creates a horizontal plot.
    expand_nested: whether to expand nested Functional models into clusters.
    dpi: Image resolution in dots per inch.
    subgraph: whether to return a pydot.Cluster instance.
    show_layer_activations: Display layer activations (only for layers that have an activation property).
    show_trainable: whether to display if a layer is trainable.

Returns

A pydot.Dot instance representing the Keras model or a pydot.Cluster instance representing nested model if subgraph=True.


###Scikit-API  - Iris-csv with Early stoping and inpu scaling 
#with tensorflow 
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Input 
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier
import tensorflow.keras.utils 
from tensorflow.keras.callbacks import * 
#original
from keras.models import Sequential, load_model
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
import keras.utils 
from keras.callbacks import * 


dataframe   = pd.read_csv("data/iris.csv")
dataset     = dataframe.values

X = dataset[:,0:4].astype(float)
Y = dataset[:,4]

encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)

# to_categorical converts the numbered labels into a one-hot vector
#Classifier must use x or y as one hot encoded 
dummy_y = keras.utils.to_categorical(encoded_Y)
#so creates 3 output variable 

#StratifiedKFold does not work with multioutput 
kfold = KFold(n_splits=10, shuffle=True)

# define baseline model
def baseline_model():
    # create model
    model = Sequential()
    #input_dim= n , for n features or (x,y) for 2D feature 
    model.add(Input(shape=(4,))
    model.add(Dense(8, activation='relu'))
    #for binary , final layer with one output, activation='sigmoid' and loss='binary_crossentropy'.
    #but we have three classe classifier, so output=3 
    model.add(Dense(3, activation='softmax'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
    

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5, verbose=0)


results = cross_val_score(estimator, X, dummy_y, cv=kfold)
print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))
#Baseline: 97.33% (4.42%)


#Check 
X_train, X_test, y_train, y_test, enc_y_train, enc_y_test = train_test_split(X, dummy_y, encoded_Y, random_state=0)

#fit
estimator.fit( X_train, y_train)

#score 
print(" train, test accuracy", estimator.score( X_train, y_train), estimator.score( X_test, y_test))
#0.9732142873108387
#0.9736842120948591

#predict 
predictions = estimator.predict( X_test)
print("predict as per numerical class\n", predictions)
#array([2, 2, 0, 2, 0, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 0, 0, 2, 2,  0, 0, 2, 0, 0, 2, 1, 0, 2, 2, 0, 2, 2, 2, 0, 2])
#With LabelEncoded Y 
print("confusion metrics\n", confusion_matrix(enc_y_test, predictions))
# array([[13,  0,  0],
       # [ 0, 14,  2],
       # [ 0,  0,  9]], dtype=int64)
       
             


print("""  --------------- GridSearch -----------------
accuracy is very sensitive of below Hyperparameters 
batch_size = sample size preferably to be multiple of batch size
epochs 
Dense - output no , 
        activation
""")


params = dict(
    epochs = [ 100, 200, 300],
    batch_size = [5,15,30],
    dense1_out = [8,16,32],
    dense1_activation = [ 'relu', 'tanh']
)

def search_model(dense1_out=8, dense1_activation='relu' ):
    # create model
    model = Sequential()
    model.add(Dense(dense1_out, input_dim=4, activation=dense1_activation))
    model.add(Dense(3, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

clf = KerasClassifier(build_fn=search_model, verbose=0)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(clf, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
print("Time taken: ", time.time()-st, " secs")  #175.9128041267395

print("Best param: ", search.best_params_ ) #{'epochs': 200, 'dense1_activation': 'tanh', 'batch_size': 30, 'dense1_out': 16}
print(" train, test accuracy", search.score( X_train, y_train), #0.9821428624647004
search.score( X_test, y_test)) #0.9736842105263158



print("""
Reducton of overfitting 
1.Setup Early Stopping
    Use EarlyStopping(monitor='val_loss', patience=2) 
        to define that we wanted to monitor the test (validation) loss at each epoch 
        and after the test loss has not improved after two epochs, training is interrupted. 
        However, since we set patience=2, we won't get the best model, 
        but the model two epochs after the best model. 
        Therefore, optionally, we can include a second operation, 
        ModelCheckpoint which saves the model to a file after every checkpoint 
        (which can be useful in case a multi-day training session is interrupted for some reason. 
        Helpful for us, if we set save_best_only=True then ModelCheckpoint will only save 
        the best model.
    And 
    Use validation_split=0.3 or validation_data=(val_x, val_y)
2.Use MinMaxscalar to scale the data also to reduce overfitting 
(dont use StandardScalar as data might not be normal)

""")
callbacks = [EarlyStopping(monitor='val_loss', patience=2),
             ModelCheckpoint(filepath='best_model.h5', monitor='val_loss', save_best_only=True)]
             
scaler = MinMaxScaler(feature_range=(-1,1))
X = scaler.fit(X).transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, dummy_y,  random_state=0)

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5,                       
                      verbose=1, # Print description after each epoch(0)+some addl  
                      callbacks=callbacks, # Early stopping
                      validation_data=(X_test, y_test) # Data for evaluation                      
                      )
estimator.fit( X_train, y_train)
    
#Load the best model from best_model.h5 which is compiled as well 
model = load_model('best_model.h5')
estimator1 = KerasClassifier(build_fn=lambda : model)
results = cross_val_score(estimator1, X, dummy_y, cv=kfold, scoring='roc_auc')
print("AUC with reduce overfitting: %3.2f (%3.2f)" % (results.mean(), results.std()))

    
    
###+++Keras - Example -Boston housing price regression 
'''
Target : The last column MEDV is a median value of owner-occupied homes in $1000
Features:
CRIM per capita crime rate by town
ZN proportion of residential land zoned for lots over 25,000 sq.ft.
INDUS proportion of non-retail business acres per town
CHAS Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
NOX nitric oxides concentration (parts per 10 million)
RM average number of rooms per dwelling
AGE proportion of owner-occupied units built prior to 1940
DIS weighted distances to five Boston employment centres
RAD index of accessibility to radial highways
TAX full-value property-tax rate per $10,000
PTRATIO pupil-teacher ratio by town
B 1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
LSTAT % lower status of the population
'''

# Read dataset into X and Y
df = pd.read_csv('tobeShared/data/boston.csv')
dataset = df.values

X = dataset[:, 0:13]
Y = dataset[:, 13]

#print "X: ", X
#print "Y: ", Y


# Define the neural network
from keras.models import Sequential
from keras.layers import Dense, Input

#13 feature/input, one output

#Note Activation 
#Regression: linear (because values are unbounded)
#Classification: softmax (simple sigmoid works too but softmax works better)
#for binary, sigmoid is also ok , but the output is not a probability distribution (does not need to sum to 1).

#Sigmoid and tanh should not be used as activation function for the hidden layer. 
#This is because of the vanishing gradient problem, i.e., if your input is on a higher side (where sigmoid goes flat) then the gradient will be near zero. 
#The best function for hidden layers is thus ReLu.

def build_nn(dense1_out=20, dense1_activation='relu', dense1_init="normal"):
    model = Sequential()
    model.add(Input(shape(13,))
    model.add(Dense(dense1_out,  kernel_initializer=dense1_init, activation=dense1_activation))
    # No activation needed in output layer (because regression)
    model.add(Dense(1, kernel_initializer=dense1_init))
    model.add(Activation("linear")) #by default, so no need to add 
    # Compile Model
    model.compile(loss='mean_squared_error', optimizer='adam', metrics=['mse'])
    return model


# Evaluate model (kFold cross validation)
from keras.wrappers.scikit_learn import KerasRegressor

#batch_size < n_samples 
#note Network parameters get updated (forward and backword ie one pass)
#only n_samples/batch_size (if not divisible, then last batch is only delta)
#hence per pass, requires less memory and multiple updates are done for whole data set 

#if batch_size == n_samples, only 1 update, but high memory is required 

# Before feeding the i/p into neural-network, standardise the dataset because all input variables vary in their scales
estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, epochs=100, batch_size=5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=5, shuffle=True)
results = cross_val_score(pipeline, X, Y, cv=kfold)

#MSE 
print("Mean: ", results.mean()) #-16.17353722710814
print("StdDev: ", results.std()) #StdDev:  6.191083824421029

#initializers are used to thwart local minimum 
params = dict(
    mlp__epochs = [ 500, 1000],
    mlp__dense1_out = [20,48, 64],
    mlp__dense1_activation = ['relu'],
    mlp__dense1_init = ['glorot_normal', 'normal']
)

X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)

estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, batch_size = 5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(pipeline, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
time.time()-st  #705.3032658100128 sec

search.best_params_  #{'mlp__dense1_init': 'glorot_normal', 'mlp__batch_size': 5, 'mlp__epochs': 300,'mlp__dense1_activation': 'relu', 'mlp__dense1_out': 48}
search.score( X_train, y_train)  #3.2275988869270735
search.score( X_test, y_test) #15.513392695409106

predictions = search.predict( X_test)
r2_score(y_test, predictions) #0.8101153048345232




###HandsON- Diabetes Data Predictive Analysis using DNN(use one hidden layer)
from keras.models import Sequential
from keras.layers import Dense, Input



dataset = pd.read_csv("tobeShared/data/pima-indians-diabetes.csv")

#Binary classification 
Z = dataset.values[:,0:8].astype(np.float64)
Q = dataset.values[:,8]

#Simple model - 8 feature/input , 1 output 
#but one hidden layer 
model = Sequential()
model.add(Input(shape=(8,)))
model.add(Dense(256, activation='relu'))
#model.add(Dense(64, activation='relu'))
model.add(Dense(1, activation='sigmoid')) #or sigmoid as binary 

model.summary()
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['binary_accuracy'])
model.fit(Z, Q, epochs=20, batch_size=5)

predictions = model.predict(Z)
rounded = [round(x[0]) for x in predictions]
print(rounded)

scores = model.evaluate(Z, Q)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))













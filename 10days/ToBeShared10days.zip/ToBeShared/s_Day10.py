
###Free AI tier 
1. HuggingFace Models
HuggingFace is often compared to a massive public library for AI models, where anyone can come in, 
browse different sections, and pick the models that best suit their needs. 
You can view documentation, usage examples, and even user discussions for each model, 
all in one place. 

FLAN-T5 (small to XXL)
    - Developed by Google. Known for good instruction-following.
    - Good for: Summaries, question-answering, general tasks.
    - Hardware Note: Larger sizes need tens of GB of memory or a powerful GPU.

from langchain.llms import HuggingFaceHub
llm = HuggingFaceHub(repo_id="google/flan-t5-large")

BLOOMZ
    - Multilingual. Built by BigScience.
    - Good for: Projects involving various languages.

llm = HuggingFaceHub(repo_id="bigscience/bloomz-560m")

Falcon
    - Created by the Technology Innovation Institute. Known for balanced performance.
    - Good for: General text generation, chat-like tasks.

llm = HuggingFaceHub(repo_id="tiiuae/falcon-7b")

GPT-Neo/GPT-J (by EleutherAI)
    - Early open-source attempts to match GPT-like performance.
    - Good for: Basic chatbots, text generation (may lag behind newer models).

Things to watch out for:

    You need a HuggingFace token if you use their Hub inference API.
    For local inference, check VRAM/CPU load.
    Model licenses wil vary. Read the license if you’re going commercial.

2. Local Models (Self-Hosted)
Hosting on your own hardware or server involves running the entire inference process locally 
instead of sending any data to a third-party API. 

    LlamaCpp
    - Runs LLaMA-based models via CPU or GPU. LLaMA is Meta’s family of advanced language models.
    - Pros: No cloud needed, complete data control.
    - Cons: Might be slow if you don’t have a robust GPU.

from langchain_community.llms import LlamaCpp
llm = LlamaCpp(
    model_path="path/to/local/model.bin",
    max_tokens=2000,
    temperature=0.7
)

    LocalAI
    - Emulates an OpenAI-like API. Makes it easier to switch if your code was built for OpenAI’s endpoints.
    - Pros: Minimal code refactoring, no data leaves your server.
    - Cons: Requires careful hardware and environment setup.

from langchain_community.llms import LocalAI
llm = LocalAI(
    base_url="http://localhost:8080/v1",
    model="local-model"
)

    Dolly (Databricks)
    - Open-source model for enterprise use. Fine-tuned on instruction data.
    - Pros: Tailored for business tasks, well-documented.
    - Cons: Might not match GPT-4-level reasoning.

Technical Points:

    GPU vs. CPU is huge. For local inference that’s not glacial, you’ll likely need a decent GPU.
    Quantization: Tools like bitsandbytes can reduce 16-bit floats to 4-bit, cutting memory usage.

    
##Mistrial ***
https://python.langchain.com/docs/integrations/chat/mistralai/
pip install -qU langchain_mistralai

Use free models or Research model 
https://docs.mistral.ai/getting-started/models/models_overview/
For all models that are compatible with the Free-tier, the following limits apply:
    1 request per second
    500,000 tokens per minute
    1 billion tokens per month

from langchain_mistralai import ChatMistralAI

llm = ChatMistralAI(
    model="open-mistral-nemo",
    temperature=0,
    max_retries=2,
    # other params...
)
messages = [
    (
        "system",
        "You are a helpful assistant that translates English to French. Translate the user sentence.",
    ),
    ("human", "I love programming."),
]
ai_msg = llm.invoke(messages)
ai_msg
AIMessage(content="I love programming. = J'aime la programmation.\n\nHere's a breakdown:\n- 
I love = J'aime\n- programming = la programmation", additional_kwargs={}, 
response_metadata={'token_usage': {'prompt_tokens': 27, 'total_tokens': 66, 
'completion_tokens': 39}, 'model': 'mistral-large-latest', 'finish_reason': 'stop'}, 
id='run-ba6838c8-3fb8-43b0-ad4f-69106edb3a42-0', 
usage_metadata={'input_tokens': 27, 'output_tokens': 39, 'total_tokens': 66})


Free models- Max Tokens	API Endpoints	Version
32k	mistral-small-latest	25.01
131k	pixtral-12b-2409	24.09

Research models Max Tokens	API Endpoints	Version
131k	open-mistral-nemo	24.07
256k	open-codestral-mamba	v0.1
32k


###langchain 
pip install langchain langgraph langchain-cli langsmith

langgraph and langsmith requires API key 

Integration package 
https://python.langchain.com/docs/integrations/providers/
pip install langchain-openai
pip install langchain-community

fastapi-cli 0.0.7 requires typer>=0.12.3, but you have typer 0.9.4 which is incompatible.
fastapi and langchain conflict

Create openai key 
https://platform.openai.com/api-keys
https://openai.com/api/pricing/

Uderstand 
https://platform.openai.com/docs/guides/rate-limits?context=tier-free
Free - Explore how AI can help with everyday tasks
    Access to GPT-4o mini
    Real-time data from the web with search
    Limited access to GPT-4o and o3-mini
    Limited access to file uploads, data analysis, image generation, and voice mode
    Use custom GPTs
    
'Free tier' is if you were granted API credits through a promotion or trial.
OpenAI is no longer giving any credits to pay for use simply for those that sign up.
You will need to prepay for credits in order to use the API services, 
which are billed by the amount of language data used.
Min $5 payment is required 
https://platform.openai.com/settings/organization/billing/overview

yes, you only need to register with Meta on hugging face then you can use llama 2 model 

LangSmith
Many of the applications you build with LangChain will contain multiple steps with multiple invocations 
of LLM calls. As these applications get more and more complex, it becomes crucial to be able 
to inspect what exactly is going on inside your chain or agent. 
The best way to do this is with LangSmith.
https://smith.langchain.com/
https://github.com/LangChain-OpenTutorial/LangChain-OpenTutorial/blob/main/01-Basic/04-LangSmith-Tracking-Setup.ipynb


For me 
https://smith.langchain.com/onboarding?organizationId=f6e05b9d-4d69-48e9-bddc-e9d69ad4ae27&step=1

For Langgraph 
https://langchain-ai.github.io/langgraph/how-tos/deploy-self-hosted/#build-the-docker-image

LANGSMITH_TRACING=true
LANGSMITH_ENDPOINT="https://api.smith.langchain.com"
LANGSMITH_API_KEY="<your-api-key>"
LANGSMITH_PROJECT="pr-tart-assistance-57"
OPENAI_API_KEY="<your-openai-api-key>"

Jupyter Notebook only offers a very simple interface using which users can open notebooks, terminals, 
and text files. JupyterLab offers a very interactive interface that includes notebooks, 
consoles, terminals, CSV editors, markdown editors, interactive maps, and more.


jupyter lab --notebook-dir="."
JupyterLab will open automatically in your browser.

jupyter notebook  --notebook-dir="."

pip install nbconvert
jupyter notebook notebook.ipynb
jupyter execute notebook.ipynb notebook2.ipynb
jupyter nbconvert --to html notebook.ipynb


Enable tracking in your Jupyter notebook or code

Enabling tracking is very simple. All you need to do is set an environment variable.

Copy the contents of .env_sample and load it into your .env with the key you set

%%capture --no-stderr
%pip install python-dotenv
#.env contains those 
from dotenv import load_dotenv

load_dotenv(override=True)

True

As long as your traces are enabled and your API key and project name are set correctly, 
tracking will work properly.




#code 
import getpass
import os

if not os.environ.get("OPENAI_API_KEY"):
  os.environ["OPENAI_API_KEY"] = getpass.getpass("Enter API key for OpenAI: ")

from langchain.chat_models import init_chat_model

#https://python.langchain.com/api_reference/langchain/chat_models/langchain.chat_models.base.init_chat_model.html
model = init_chat_model("gpt-4o-mini", model_provider="openai")

from langchain_core.messages import HumanMessage, SystemMessage

messages = [
    SystemMessage("Translate the following from English into Italian"),
    HumanMessage("hi!"),
]

model.invoke(messages)
#Output 
AIMessage(content='Ciao!', additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 3, 'prompt_tokens': 20, 'total_tokens': 23, 'completion_tokens_details': {'accepted_prediction_tokens': 0, 'audio_tokens': 0, 'reasoning_tokens': 0, 'rejected_prediction_tokens': 0}, 'prompt_tokens_details': {'audio_tokens': 0, 'cached_tokens': 0}}, 'model_name': 'gpt-4o-mini-2024-07-18', 'system_fingerprint': 'fp_0705bf87c0', 'finish_reason': 'stop', 'logprobs': None}, id='run-32654a56-627c-40e1-a141-ad9350bbfd3e-0', usage_metadata={'input_tokens': 20, 'output_tokens': 3, 'total_tokens': 23, 'input_token_details': {'audio': 0, 'cache_read': 0}, 'output_token_details': {'audio': 0, 'reasoning': 0}})

LangChain also supports chat model inputs via strings or OpenAI format. The following are equivalent:

model.invoke("Hello")
model.invoke([{"role": "user", "content": "Hello"}])
model.invoke([HumanMessage("Hello")])



ChatModels are instances of LangChain Runnables
Ref:
https://python.langchain.com/docs/concepts/chat_models/
https://python.langchain.com/docs/concepts/runnables/
https://python.langchain.com/docs/concepts/messages/
https://python.langchain.com/docs/concepts/chat_models/#standard-parameters

Class hierarchy:
BaseLanguageModel --> BaseChatModel --> <name>  # Examples: ChatOpenAI, ChatGooglePalm

Main helpers:
AIMessage, BaseMessage, HumanMessage


https://python.langchain.com/api_reference/
https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.base.Runnable.html
https://python.langchain.com/api_reference/core/language_models/langchain_core.language_models.chat_models.BaseChatModel.html
https://python.langchain.com/api_reference/core/language_models/langchain_core.language_models.base.BaseLanguageModel.html

https://python.langchain.com/api_reference/core/messages/langchain_core.messages.ai.AIMessage.html
https://python.langchain.com/api_reference/core/messages/langchain_core.messages.human.HumanMessage.html
https://python.langchain.com/api_reference/core/messages/langchain_core.messages.system.SystemMessage.html


If we've enabled LangSmith, we can see that this run is logged to LangSmith, and can see the LangSmith trace. 
The LangSmith trace reports token usage information, latency, standard model parameters 
(such as temperature), and other information.
https://smith.langchain.com/public/88baa0b2-7c1a-4d09-ba30-a47985dde2ea/r


##More Ref 

https://python.langchain.com/api_reference/langchain/index.html
    Main entrypoint into package.

https://python.langchain.com/api_reference/text_splitters/index.html
    Text Splitters are classes for splitting text.

    Class hierarchy:
    BaseDocumentTransformer --> TextSplitter --> <name>TextSplitter  # Example: CharacterTextSplitter
                                                 RecursiveCharacterTextSplitter -->  <name>TextSplitter

    Note: MarkdownHeaderTextSplitter and **HTMLHeaderTextSplitter do not derive from TextSplitter.

    Main helpers:

    Document, Tokenizer, Language, LineType, HeaderType

https://python.langchain.com/api_reference/openai/index.html
    chat_models
    chat_models.azure.AzureChatOpenAI       Azure OpenAI chat model integration.
    chat_models.base.BaseChatOpenAI
    chat_models.base.ChatOpenAI             OpenAI chat model integration.
    chat_models.base.OpenAIRefusalError     Error raised when OpenAI Structured Outputs API returns a refusal.
    embeddings
    embeddings.azure.AzureOpenAIEmbeddings      AzureOpenAI embedding model integration.
    embeddings.base.OpenAIEmbeddings            OpenAI embedding model integration.
    llms
    llms.azure.AzureOpenAI                      Azure-specific OpenAI large language models.
    llms.base.BaseOpenAI                        Base OpenAI large language model class.
    llms.base.OpenAI                            OpenAI completion model integration.

https://python.langchain.com/api_reference/core/index.html#
langchain-core defines the base abstractions for the LangChain ecosystem.
The interfaces for core components like chat models, LLMs, vector stores, retrievers, 
and more are defined here. The universal invocation protocol (Runnables) along 
with a syntax for combining components (LangChain Expression Language) are also defined here.

class langchain_core.runnables.base.Runnable
    A unit of work that can be invoked, batched, streamed, transformed and composed.
    Key Methods
        invoke/ainvoke: Transforms a single input into an output.
        batch/abatch: Efficiently transforms multiple inputs into outputs.
        stream/astream: Streams output from a single input as it’s produced.
        astream_log: Streams output and selected intermediate results from an input.

    Built-in optimizations:
        Batch: By default, batch runs invoke() in parallel using a thread pool executor. Override to optimize batching.
        Async: Methods with 'a' suffix are asynchronous. 
        By default, they execute the sync counterpart using asyncio’s thread pool. Override for native async.

    All methods accept an optional config argument, which can be used to configure execution, add tags and metadata for tracing and debugging etc.
    Runnables expose schematic information about their input, output and config via the input_schema property, 
    the output_schema property and config_schema method.

        abatch(inputs[, config, return_exceptions])
            Default implementation runs ainvoke in parallel using asyncio.gather.
        abatch_as_completed()
            Run ainvoke in parallel on a list of inputs, yielding results as they complete.
        ainvoke(input[, config])
            Default implementation of ainvoke, calls invoke from a thread.
        as_tool([args_schema, name, description, ...])
        assign(**kwargs)
            Assigns new fields to the dict output of this Runnable.
        astream(input[, config])
            Default implementation of astream, which calls ainvoke.
        astream_events(input[, config, version, ...])
            Generate a stream of events.
        astream_log()
                Stream all output from a Runnable, as reported to the callback system.
        atransform(input[, config])
            Default implementation of atransform, which buffers input and calls astream.
        batch(inputs[, config, return_exceptions])
            Default implementation runs invoke in parallel using a thread pool executor.
        batch_as_completed()
            Run invoke in parallel on a list of inputs, yielding results as they complete.
        bind(**kwargs)
            Bind arguments to a Runnable, returning a new Runnable.
        config_schema(*[, include])
            The type of config this Runnable accepts specified as a pydantic model.
        get_config_jsonschema(*[, include])
            Get a JSON schema that represents the config of the Runnable.
        get_graph([config])
            Return a graph representation of this Runnable.
        get_input_jsonschema([config])
            Get a JSON schema that represents the input to the Runnable.
        get_input_schema([config])
            Get a pydantic model that can be used to validate input to the Runnable.
        get_name([suffix, name])
            Get the name of the Runnable.
        get_output_jsonschema([config])
            Get a JSON schema that represents the output of the Runnable.
        get_output_schema([config])
            Get a pydantic model that can be used to validate output to the Runnable.
        get_prompts([config])
            Return a list of prompts used by this Runnable.
        invoke(input[, config])
            Transform a single input into an output.
        map()
            Return a new Runnable that maps a list of inputs to a list of outputs, by calling invoke() with each input.
        pick(keys)
            Pick keys from the output dict of this Runnable.
        pipe(*others[, name])
            Compose this Runnable with Runnable-like objects to make a RunnableSequence.
        stream(input[, config])
            Default implementation of stream, which calls invoke.
        transform(input[, config])
            Default implementation of transform, which buffers input and calls astream.
        with_alisteners(*[, on_start, on_end, on_error])
            Bind async lifecycle listeners to a Runnable, returning a new Runnable.
        with_config([config])
            Bind config to a Runnable, returning a new Runnable.
        with_fallbacks(fallbacks, *[, ...])
            Add fallbacks to a Runnable, returning a new Runnable.
        with_listeners(*[, on_start, on_end, on_error])
            Bind lifecycle listeners to a Runnable, returning a new Runnable.
        with_retry(*[, retry_if_exception_type, ...])
            Create a new Runnable that retries the original Runnable on exceptions.
        with_types(*[, input_type, output_type])
            Bind input and output types to a Runnable, returning a new Runnable.


##Streaming
Because chat models are Runnables, they expose a standard interface that includes async 
and streaming modes of invocation. This allows us to stream individual tokens from a chat model:

for token in model.stream(messages):
    print(token.content, end="|")
    
Prompt templates are a concept in LangChain designed to assist with this transformation. 
They take in raw user input and return data (a prompt) that is ready to pass into a language model.

Let's create a prompt template here. It will take in two user variables:
    language: The language to translate text into
    text: The text to translate
https://python.langchain.com/api_reference/core/prompts/langchain_core.prompts.chat.ChatPromptTemplate.html
    
from langchain_core.prompts import ChatPromptTemplate

system_template = "Translate the following from English into {language}"

prompt_template = ChatPromptTemplate.from_messages(
    [("system", system_template), ("user", "{text}")]
)

Note that ChatPromptTemplate supports multiple message roles in a single template. 
We format the language parameter into the system message, and the user text into a user message.

The input to this prompt template is a dictionary. 
We can play around with this prompt template by itself to see what it does by itself

prompt = prompt_template.invoke({"language": "Italian", "text": "hi!"})

prompt
#ChatPromptValue(messages=[SystemMessage(content='Translate the following from English into Italian', additional_kwargs={}, response_metadata={}), HumanMessage(content='hi!', additional_kwargs={}, response_metadata={})])

We can see that it returns a ChatPromptValue that consists of two messages. 
If we want to access the messages directly we do:

prompt.to_messages()

#OUTPUT 
[SystemMessage(content='Translate the following from English into Italian', additional_kwargs={}, response_metadata={}),
 HumanMessage(content='hi!', additional_kwargs={}, response_metadata={})]

Finally, we can invoke the chat model on the formatted prompt:

response = model.invoke(prompt)
print(response.content)

ERROR -OUTPUT with gpt-4o-mini
at some point I got the output as Sei addestrato su dati fino a ottobre 2023. instead of Ciao
change to model to gpt-4 , NOT FREE


Check Langsmith trace in 
https://smith.langchain.com/o/f6e05b9d-4d69-48e9-bddc-e9d69ad4ae27/projects?paginationState=%7B%22pageIndex%22%3A0%2C%22pageSize%22%3A10%7D


##Log your trace
We provide multiple ways to log traces to LangSmith.

import openai
from langsmith import wrappers, traceable

# Auto-trace LLM calls in-context
client = wrappers.wrap_openai(openai.Client())

@traceable # Auto-trace this function
def pipeline(user_input: str):
    result = client.chat.completions.create(
        messages=[{"role": "user", "content": user_input}],
        model="gpt-4o-mini"
    )
    return result.choices[0].message.content

pipeline("Hello, world!")
# Out:  Hello there! How can I assist you today?

###LCEL Interface 
https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.base.ChatOpenAI.html
class langchain_openai.chat_models.base.ChatOpenAI
Bases: BaseChatOpenAI
model: str
    Name of OpenAI model to use.
temperature: float
    Sampling temperature.
max_tokens: Optional[int]
    Max number of tokens to generate.
logprobs: Optional[bool]
    Whether to return logprobs.
stream_options: Dict
    Configure streaming outputs, like whether to return token usage when streaming ({"include_usage": True}).

    
    
Create a chain using LCEL syntax.

from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Instantiate the ChatOpenAI model.
model = ChatOpenAI()
# Create a prompt template that asks for jokes on a given topic.
prompt = PromptTemplate.from_template("Describe the {topic} in 3 sentences.")
# Connect the prompt and model to create a conversation chain.
chain = prompt | model | StrOutputParser()

##LCEL -  stream: real-time output
This function uses the chain.stream method to create a stream of data for a given topic, 
iterating over it and immediately outputting the content of each piece of data. The end="" 
argument disables newlines after output, and the flush=True argument causes the output buffer to be emptied immediately.

# Use the chain.stream method to create a stream of data for a given topic, iterating over it 
#and immediately outputting the content of each piece of data. 
for token in chain.stream({"topic": "multimodal"}):
    # Output the content of each piece of data without newlines.
    print(token, end="", flush=True)

# example output 


##LCEL -  Invoke
The invoke method of a chain object takes a topic as an argument and performs processing on that topic.

# Call the invoke method of the chain object, passing a dictionary with the topic 'ChatGPT'.
chain.invoke({"topic": "ChatGPT"})

##LCEL -  batch: unit execution
The function chain.batch takes a list containing multiple dictionaries as arguments 
and performs batch processing using the values of the topic key in each dictionary.

# Call a function to batch process a given list of topics
chain.batch([{"topic": "ChatGPT"}, {"topic": "Instagram"}])

You can use the max_concurrency parameter to set the number of concurrent requests | 
The config dictionary uses the max_concurrency key to set the maximum number of operations 
that can be processed concurrently. Here, it is set to process up to three jobs concurrently.

chain.batch(
    [
        {"topic": "ChatGPT"},
        {"topic": "Instagram"},
        {"topic": "multimodal"},
        {"topic": "programming"},
        {"topic": "machineLearning"},
    ],
    config={"max_concurrency": 3},
)
##LCEL -  async stream
The function chain.astream creates an asynchronous stream and processes messages for a given topic asynchronously.

It uses an asynchronous for loop (async for) to sequentially receive messages from the stream, 
and the print function to immediately print the contents of the messages (s.content). end="" 
disables line wrapping after printing, and flush=True forces the output buffer to be emptied to ensure immediate printing.

# Use an asynchronous stream to process messages in the 'YouTube' topic.
async for token in chain.astream({"topic": "YouTube"}):
    # Print the message content. Outputs directly without newlines and empties the buffer.
    print(token, end="", flush=True)

##LCEL -  async invoke
The ainvoke method of a chain object performs an operation asynchronously with the given arguments. 
Here, we are passing a dictionary with a key named topic and a value named NVDA (NVIDIA's ticker) 
as arguments. This method can be used to asynchronously request processing for a specific topic.

# Handle the 'NVDA' topic by calling the 'ainvoke' method of the asynchronous chain object.
my_process = chain.ainvoke({"topic": "NVDA"})

# Wait for the asynchronous process to complete.
await my_process

##LCEL -  async batch
The function abatch batches a series of actions asynchronously.

In this example, we are using the abatch method of the chain object to asynchronously process actions on topic .

The await keyword is used to wait for those asynchronous tasks to complete.

# Performs asynchronous batch processing on a given topic.
my_abatch_process = chain.abatch(
    [{"topic": "YouTube"}, {"topic": "Instagram"}, {"topic": "Facebook"}]
)

# Wait for the asynchronous batch process to complete.
await my_abatch_process

##LCEL -  Parallel
when you use RunnableParallel (often written in dictionary form), you execute each element in parallel.

Create two chains (chain1, chain2) that use the ChatPromptTemplate.from_template method 
to get the capital and area for a given country.

These chains are connected via the model and pipe (|) operators, respectively. 
Finally, we use the RunnableParallel class to combine these two chains with the keys capital 
and area to create a combined object that can be run in parallel.

from langchain_core.runnables import RunnableParallel

# Create a chain that asks for the capital of {country}.
chain1 = (
    PromptTemplate.from_template("What is the capital of {country}?")
    | model
    | StrOutputParser()
)

# Create a chain that asks for the area of {country}.
chain2 = (
    PromptTemplate.from_template("What is the area of {country}?")
    | model
    | StrOutputParser()
)

# Create a parallel execution chain that generates the above two chains in parallel.
combined = RunnableParallel(capital=chain1, area=chain2)

The chain1.invoke() function calls the invoke method of the chain1 object.

As an argument, it passes a dictionary with the value Canada in the key named country.

# Run chain1 .
chain1.invoke({"country": "Canada"})

Call chain2.invoke(), this time passing a different country, the United States, for the country key.

# Run chain2 .
chain2.invoke({"country": "USA"})

The invoke method of the combined object performs the processing for the given country.

In this example, the topic USA is passed to the invoke method to run.

# Run a parallel execution chain.
combined.invoke({"country": "USA"})

##LCEL -  Parallelism in batches
Parallelism can be combined with other executable code. Let's try using parallelism with batch.

The chain1.batch function takes a list containing multiple dictionaries as an argument, 
and processes the values corresponding to the "topic" key in each dictionary. 
In this example, we're batch processing two topics, "Canada" and "United States".

# Perform batch processing.
chain1.batch([{"country": "Canada"}, {"country": "USA"}])

The chain2.batch function takes in multiple dictionaries as a list and performs batch processing.

In this example, we request processing for two countries, Canada and the United States.

# Perform batch processing.
chain2.batch([{"country": "Canada"}, {"country": "USA"}])

The combined.batch function is used to process the given data in batches.

In this example, it takes a list containing two dictionary objects as arguments and batches data 
for two countries, Canada and the United States, respectively.

# Processes the given data in batches.
combined.batch([{"country": "Canada"}, {"country": "USA"}])


###Output Parser
An Output Parser is a tool designed to transform or process the responses from an AI model 
into a specific format. 

Since the model's output is typically provided as free-form text, 
an Output Parser is essential to convert it 
into a structured format or extract the required data.

from langchain_core.output_parsers import StrOutputParser

output_parser = (
    StrOutputParser()
)  # Directly returns the model's response as a string without modification.

An output parser is added to the chain.

# A processing chain is constructed by connecting the prompt, model, and output parser.
chain = prompt | model | output_parser

# Use the invoke method of the chain object to pass the input
chain.invoke(input)


# Request for Streaming Output
answer = chain.stream(input)

# Streaming Output
for token in answer:
    print(token, end="", flush=True)
    

##Applying and Modifying Templates
The prompt content below can be modified as needed for testing purposes.
The model_name can also be adjusted for testing.

template = """
You are a seasoned English teacher with 10 years of experience. 
Please write an English conversation suitable for the given situation.  
Refer to the [FORMAT] for the structure.

#SITUATION:
{question}

#FORMAT:
- Dialogue in English:
- Explanation of the Dialogue: 
"""

# Generate the prompt using the PromptTemplate
prompt = PromptTemplate.from_template(template)

# Initialize the ChatOpenAI model.
model = ChatOpenAI(model_name="gpt-4o-mini")

# Initialize the string output parser.
output_parser = StrOutputParser()

# Construct the chain.
chain = prompt | model | output_parser

# Execute the completed Chain to obtain a response.
print(chain.invoke({"question": "I want to go to a restaurant and order food."}))

#Output 
 Dialogue in English:
**Waiter:** Good evening! Welcome to La Bella Italia. How many are in your party?  
**Customer:** Just one, please.  
**Waiter:** Right this way. Here’s your menu. Can I get you something to drink while you look? 

- Explanation of the Dialogue: 
In this conversation, the customer arrives at a restaurant and interacts with the waiter. 
The waiter greets the customer and asks how many people are dining,

# Execute the completed Chain to obtain a response
# Request for Streaming Output
answer = chain.stream({"question": "I want to go to a restaurant and order food."})

# Streaming Output
for token in answer:
    print(token, end="", flush=True)
    
# This time, set the question to 'Ordering Pizza in the US' and execute it.
# Request for Streaming Output
answer = chain.stream({"question": "Ordering Pizza in the US"})

# Streaming Output
for token in answer:
    print(token, end="", flush=True)
    
###Understanding Runnables 
LangChain's Runnable objects provide a modular and flexible approach 
to designing workflows by enabling the chaining, parallel execution, 
and transformation of data. 

Key Components is:
    RunnableLambda: A lightweight utility that enables the application of custom logic 
        through lambda functions, ideal for dynamic and quick data transformations.
    RunnablePassthrough: Designed to pass input data unchanged or augment it 
        with additional attributes when paired with the .assign() method.
    itemgetter: A Python operator module utility for efficiently extracting specific keys 
        or indices from structured data such as dictionaries or tuples.
        
##More example 
from langchain_core.runnables import (
    RunnableLambda,
    RunnableParallel,
    RunnablePassthrough,
)
#Note RunnableParallel takes keyword args 
#each key is key of the output and value should be Runnable 
#if lambda is passed , coerced into RunnableLambda 
runnable = RunnableParallel(
    origin=RunnablePassthrough(), # takes input as it is, here number but could be any type from invoke calling 
    modified=lambda x: (print(x), x+1 if type(x) is int else x)[-1]        # x type is based on invoke calling 
)

runnable.invoke(1) # {'origin': 1, 'modified': 2}


def fake_llm(prompt: str) -> str: # Fake LLM for the example
    return "completion"

chain = RunnableLambda(fake_llm) | {  # dict is Coerced into RunnableParallel ,args - check above  
    'original': RunnablePassthrough(), # Original LLM output
    'parsed': lambda text: text[::-1] # Parsing logic # takes output of fake_llm 
}

chain.invoke('hello') # {'original': 'completion', 'parsed': 'noitelpmoc'}

from langchain_core.runnables import RunnablePassthrough

def fake_llm(prompt: str) -> str: # Fake LLM for the example
    return "completion"

runnable = {   #Coerced into RunnableParallel 
    'llm1':  fake_llm,
    'llm2':  fake_llm,
} | RunnablePassthrough.assign(  #function gets a dict of llm1 and llm2 with values calling of fake_llm 
    total_chars=lambda inputs: len(inputs['llm1'] + inputs['llm2'])
)

runnable.invoke('hello')
# {'llm1': 'completion', 'llm2': 'completion', 'total_chars': 20}

##RunnablePassthrough
https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.passthrough.RunnablePassthrough.html

RunnablePassthrough(
#These functiions are called with inputs and then inputs are passed through 
    func: Optional[
            Union[
                Union[Callable[[Other], None], Callable[[Other, RunnableConfig], None]],
                Union[
                    Callable[[Other], Awaitable[None]],
                    Callable[[Other, RunnableConfig], Awaitable[None]],
                ],
            ]
        ] = None,
        afunc: Optional[
            Union[
                Callable[[Other], Awaitable[None]],
                Callable[[Other, RunnableConfig], Awaitable[None]],
            ]
        ] = None,
        *,
        input_type: Optional[type[Other]] = None,
        **kwargs: Any,
    )
        @classmethod
        def assign(
            cls,
            **kwargs: Union[
                Runnable[dict[str, Any], Any],
                Callable[[dict[str, Any]], Any],
                Mapping[
                    str,
                    Union[Runnable[dict[str, Any], Any], Callable[[dict[str, Any]], Any]],
                ],
            ],
        ) -> RunnableAssign:
            """Merge the Dict input with the output produced by the mapping argument.

            Args:
                **kwargs: Runnable, Callable or a Mapping from keys to Runnables
                    or Callables.

            Returns:
                A Runnable that merges the Dict input with the output produced by the
                mapping argument.
            """
            return RunnableAssign(RunnableParallel[dict[str, Any]](kwargs))


RunnablePassthrough can either pass the input unchanged or append additional keys to it.

When RunnablePassthrough() is called on its own, it simply takes the input and passes it as is.

When called using RunnablePassthrough.assign(...), it takes the input 
and adds additional arguments provided to the assign function.


from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

# Create the prompt and llm
prompt = PromptTemplate.from_template("What is 10 times {num}?")
llm = ChatOpenAI(temperature=0)

# Create the chain
chain = prompt | llm

When invoking the chain with invoke(), the input data must be of type dictionary.

# Execute the chain : input dtype as 'dictionary'
chain.invoke({"num": 5})
#Output 
AIMessage(content='10 times 5 is equal to 50.', 
additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 11, 
'prompt_tokens': 15, 'total_tokens': 26, 'completion_tokens_details': {'accepted_prediction_tokens': 0, 
'audio_tokens': 0, 'reasoning_tokens': 0, 'rejected_prediction_tokens': 0}, 'prompt_tokens_details': {'audio_tokens': 0, 'cached_tokens': 0}}, 'model_name': 'gpt-3.5-turbo-0125', 'system_fingerprint': None, 'finish_reason': 'stop', 'logprobs': None}, id='run-420bc9dc-12eb-4f7a-a2c4-8e521b3d952d-0', usage_metadata={'input_tokens': 15, 'output_tokens': 11, 'total_tokens': 26, 'input_token_details': {'audio': 0, 'cache_read': 0}, 'output_token_details': {'audio': 0, 'reasoning': 0}})

However, with the update to the LangChain library, 
if the template includes only one variable, it is also possible to pass just the value directly.

# Execute the chain : input value directly
chain.invoke(5)


RunnablePassthrough is a runnable object

from langchain_core.runnables import RunnablePassthrough

# Runnable
RunnablePassthrough().invoke({"num": 10})
#{'num': 10}

Here is an example of creating a chain using RunnablePassthrough.

runnable_chain = {"num": RunnablePassthrough()} | prompt | ChatOpenAI()

# The dict value has been updated with RunnablePassthrough().
runnable_chain.invoke(10)

RunnablePassthrough.assign()
    Combines the key/value pairs from the input with the newly assigned key/value pairs.

# Input key: num, Assigned key: new_num, x is input dict 
(RunnablePassthrough.assign(new_num=lambda x: x["num"] * 3)).invoke({"num": 1})
#{'num': 1, 'new_num': 3}




##Efficient Parallel Execution with RunnableParallel
RunnableParallel is a utility designed to execute multiple Runnable objects concurrently, 
streamlining workflows that require parallel processing. 

It distributes input data across different components, collects their results, 
and combines them into a unified output dict 

    Concurrent Execution
        Executes multiple Runnable objects simultaneously, reducing the time required 
        for tasks that can be parallelized.

    Unified Output Management
        Combines the results from all parallel executions into a single, cohesive output, 
        simplifying downstream processing.

    Flexibility
        Can handle diverse input types and support complex workflows by distributing 
        the workload efficiently.

from langchain_core.runnables import RunnableParallel

# Create an instance of RunnableParallel. 
#This instance allows multiple Runnable objects to be executed in parallel.
#Take keyword args, each key = output dict key, value is Runnable eg ChatOpenAI()
#if lambda , then coerced into RunnableLambda 
#Then calls .invoke of all in parallel eg .ainvoke 
runnable = RunnableParallel(
    # Pass a RunnablePassthrough instance as the 'passed' keyword argument. 
    #This simply passes the input data through without modification.
    passed=RunnablePassthrough(),
    # Use RunnablePassthrough.assign as the 'extra' keyword argument to assign a lambda function 'mult'. 
    # This function multiplies the value associated with the 'num' key in the input dictionary by 3.
    extra=RunnablePassthrough.assign(mult=lambda x: x["num"] * 3), # x is dict based on .invoke call 
    # Pass a lambda function as the 'modified' keyword argument. 
    # This function adds 1 to the value associated with the 'num' key in the input dictionary.
    modified=lambda x: x["num"] + 1, # x is dict based on .invoke call 
)

# Call the invoke method on the runnable instance, passing a dictionary {'num': 1} as input.
runnable.invoke({"num": 1})
#{'passed': {'num': 1}, 'extra': {'num': 1, 'mult': 3}, 'modified': 2}

##Chains can also be applied to RunnableParallel.
chain1 = (
    {"country": RunnablePassthrough()}
    | PromptTemplate.from_template("What is the capital of {country}?")
    | ChatOpenAI()
)
chain2 = (
    {"country": RunnablePassthrough()}
    | PromptTemplate.from_template("What is the area of {country}?")
    | ChatOpenAI()
)

combined_chain = RunnableParallel(capital=chain1, area=chain2)
combined_chain.invoke("United States of America")
#Output 
{'capital': AIMessage(content='The capital of the United States of America is Washington, D.C.', additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 15, 'prompt_tokens': 17, 'total_tokens': 32, 'completion_tokens_details': {'accepted_prediction_tokens': 0, 'audio_tokens': 0, 'reasoning_tokens': 0, 'rejected_prediction_tokens': 0}, 'prompt_tokens_details': {'audio_tokens': 0, 'cached_tokens': 0}}, 'model_name': 'gpt-3.5-turbo-0125', 'system_fingerprint': None, 'finish_reason': 'stop', 'logprobs': None}, id='run-29437a26-8661-4f15-a655-3b3ca6aa0e8c-0', usage_metadata={'input_tokens': 17, 'output_tokens': 15, 'total_tokens': 32, 'input_token_details': {'audio': 0, 'cache_read': 0}, 'output_token_details': {'audio': 0, 'reasoning': 0}}),
 'area': AIMessage(content='The total land area of the United States of America is approximately 3.8 million square miles.', additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 21, 'prompt_tokens': 17, 'total_tokens': 38, 'completion_tokens_details': {'accepted_prediction_tokens': 0, 'audio_tokens': 0, 'reasoning_tokens': 0, 'rejected_prediction_tokens': 0}, 'prompt_tokens_details': {'audio_tokens': 0, 'cached_tokens': 0}}, 'model_name': 'gpt-3.5-turbo-0125', 'system_fingerprint': None, 'finish_reason': 'stop', 'logprobs': None}, id='run-5004e08c-dd66-4c7c-bc3f-60821fecc403-0', usage_metadata={'input_tokens': 17, 'output_tokens': 21, 'total_tokens': 38, 'input_token_details': {'audio': 0, 'cache_read': 0}, 'output_token_details': {'audio': 0, 'reasoning': 0}})}

##Dynamic Processing with RunnableLambda
Can take async or def function with following type 
class langchain_core.runnables.base.RunnableLambda(func: Callable[[Input], Output] | 
    Callable[[Input], Iterator[Output]] | 
    Callable[[Input, RunnableConfig], Output] | 
    Callable[[Input, CallbackManagerForChainRun], Output] | 
    Callable[[Input, CallbackManagerForChainRun, RunnableConfig], Output] | 
    Callable[[Input], Awaitable[Output]] | Callable[[Input], AsyncIterator[Output]] | 
    Callable[[Input, RunnableConfig], Awaitable[Output]] | 
    Callable[[Input, AsyncCallbackManagerForChainRun], Awaitable[Output]] | 
    Callable[[Input, AsyncCallbackManagerForChainRun, RunnableConfig], Awaitable[Output]], 
    
    afunc: Callable[[Input], Awaitable[Output]] | 
    Callable[[Input], AsyncIterator[Output]] | 
    Callable[[Input, RunnableConfig], Awaitable[Output]] | 
    Callable[[Input, AsyncCallbackManagerForChainRun], Awaitable[Output]] | 
    Callable[[Input, AsyncCallbackManagerForChainRun, RunnableConfig], Awaitable[Output]] | 
    None = None, 
    
    name: str | None = None)


from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from datetime import datetime

#must be single arg function 
def get_today(a):
    # Get today's date
    return datetime.today().strftime("%b-%d")

# Print today's date
get_today(None)


from langchain_core.runnables import RunnableLambda, RunnablePassthrough

# Create the prompt and llm
prompt = PromptTemplate.from_template(
    "List {n} famous people whose birthday is on {today}. Include their date of birth."
)
llm = ChatOpenAI(temperature=0, model_name="gpt-4o-mini")
#OR 
from langchain_mistralai import ChatMistralAI

llm = ChatMistralAI( model="open-mistral-nemo", temperature=0, max_retries=2,)


# Create the chain
#calls get_today with arg from .invoke call 
#n gets .invoke arg 
chain = (
    {"today": RunnableLambda(get_today), "n": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

# Output
print(chain.invoke(3))

Here are three famous people born on January 4:

1. **Isaac Newton** - Born on January 4, 1643 (according to the Gregorian calendar; December 25, 1642, in the Julian calendar), he was an English mathematician, physicist, astronomer, and author who is widely recognized as one of the most influential scientists of all time.

##More example 
# This is a RunnableLambda
from langchain_core.runnables import RunnableLambda

def add_one(x: int) -> int:
    return x + 1

runnable = RunnableLambda(add_one)

runnable.invoke(1) # returns 2
runnable.batch([1, 2, 3]) # returns [2, 3, 4]

# Async is supported by default by delegating to the sync implementation
await runnable.ainvoke(1) # returns 2
await runnable.abatch([1, 2, 3]) # returns [2, 3, 4]


# Alternatively, can provide both synd and sync implementations
async def add_one_async(x: int) -> int:
    return x + 1

runnable = RunnableLambda(add_one, afunc=add_one_async)
runnable.invoke(1) # Uses add_one
await runnable.ainvoke(1) # Uses add_one_async

#More example 
from langchain_core.runnables import RunnableLambda

def add_one(x: int) -> int:
    return x + 1

def mul_two(x: int) -> int:
    return x * 2

def mul_three(x: int) -> int:
    return x * 3

runnable_1 = RunnableLambda(add_one)
runnable_2 = RunnableLambda(mul_two)
runnable_3 = RunnableLambda(mul_three)

sequence = runnable_1 | {  # this dict is coerced to a RunnableParallel
    "mul_two": runnable_2,
    "mul_three": runnable_3,
}
# Or equivalently:
# sequence = runnable_1 | RunnableParallel(
#     {"mul_two": runnable_2, "mul_three": runnable_3}
# )
# Also equivalently:
# sequence = runnable_1 | RunnableParallel(
#     mul_two=runnable_2,
#     mul_three=runnable_3,
# )

sequence.invoke(1)
await sequence.ainvoke(1)

sequence.batch([1, 2, 3])
await sequence.abatch([1, 2, 3])


##Extracting Specific Keys Using itemgetter
itemgetter is a utility function from Python's operator module
    Usage in LangChain
        Data filtering in chain compositions
        Selective extraction from complex input structures
        Combines with other Runnable objects for data preprocessing

from operator import itemgetter

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

def fake_llm(a):
    print(a)
    return a


# Function that returns the length of a sentence.
def length_function(text):
    return len(text)


# Function that returns the product of the lengths of two sentences.
def _multiple_length_function(text1, text2):
    return len(text1) * len(text2)


# Function that uses _multiple_length_function to return the product of the lengths of two sentences.
def multiple_length_function(_dict):
    return _multiple_length_function(_dict["text1"], _dict["text2"])


prompt = ChatPromptTemplate.from_template("What is {a} + {b}?")
#model = ChatOpenAI()
model = RunnableLambda(fake_llm)

chain1 = prompt | model

chain1.invoke({"a": "hello", "b": "world"})


chain = (
    {
        "a": itemgetter("word1") | RunnableLambda(length_function),
        "b": {"text1": itemgetter("word1"), "text2": itemgetter("word2")}
        | RunnableLambda(multiple_length_function),
    }
    | RunnablePassthrough(lambda input: print(input))
    | prompt
    | model
)

chain.invoke({"word1": "hello", "word2": "world"})
#Output 
{'a': 5, 'b': 25}
messages=[HumanMessage(content='What is 5 + 25?', additional_kwargs={}, response_metadata={})]
ChatPromptValue(messages=[HumanMessage(content='What is 5 + 25?', additional_kwargs={}, response_metadata={})])

###Prompt Template

##Creating a PromptTemplate Object
There are two ways to create a PromptTemplate object.
        Using the from_template() method
        Creating a PromptTemplate object and a prompt all at once

Method 1. Using the from_template() method
    Define template with variable as {variable} .

from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda

def fake_llm(a):
    def f():
        pass 
    f.content = str(a)
    return f

llm = RunnableLambda(fake_llm) 

# Define template. In this case, {country} is a variable
template = "What is the capital of {country}?"

# Create a `PromptTemplate` object using the `from_template` method
prompt = PromptTemplate.from_template(template)
prompt
#PromptTemplate(input_variables=['country'], input_types={}, partial_variables={}, template='What is the capital of {country}?')

You can complete the prompt by assigning a value to the variable country .

# Create prompt. Assign value to the variable using `format` method
prompt = prompt.format(country="United States of America")
prompt
#'What is the capital of United States of America?'

# Define template
template = "What is the capital of {country}?"

# Create a `PromptTemplate` object using the `from_template` method
prompt = PromptTemplate.from_template(template)

# Create chain
chain = prompt | llm

# Replace the country variable with a value of your choice
chain.invoke("United States of America").content

'The capital of the United States of America is Washington, D.C.'

Method 2. Creating a PromptTemplate object and a prompt all at once

Explicitly specify input_variables for additional validation.

Otherwise, a mismatch between such variables and the variables within the template string can raise an exception in instantiation.

# Define template
template = "What is the capital of {country}?"

# Create a prompt template with `PromptTemplate` object
prompt = PromptTemplate(
    template=template,
    input_variables=["country"],
)
prompt
#PromptTemplate(input_variables=['country'], input_types={}, partial_variables={}, template='What is the capital of {country}?')

# Create prompt
prompt.format(country="United States of America")
#'What is the capital of United States of America?'

# Define template
template = "What are the capitals of {country1} and {country2}, respectively?"

# Create a prompt template with `PromptTemplate` object
prompt = PromptTemplate(
    template=template,
    input_variables=["country1"],
    partial_variables={
        "country2": "United States of America"  # Pass `partial_variables` in dictionary form
    },
)
prompt
#PromptTemplate(input_variables=['country1'], input_types={}, partial_variables={'country2': 'United States of America'}, template='What are the capitals of {country1} and {country2}, respectively?')

prompt.format(country1="South Korea")
#'What are the capitals of South Korea and United States of America, respectively?'

prompt_partial = prompt.partial(country2="India")
prompt_partial
#PromptTemplate(input_variables=['country1'], input_types={}, partial_variables={'country2': 'India'}, template='What are the capitals of {country1} and {country2}, respectively?')

prompt_partial.format(country1="South Korea")
#'What are the capitals of South Korea and India, respectively?'

chain = prompt_partial | llm

chain.invoke("United States of America").content
#'The capital of the United States of America is Washington, D.C., and the capital of India is New Delhi.'

chain.invoke({"country1": "United States of America", "country2": "India"}).content
#'The capital of the United States of America is Washington, D.C., and the capital of India is New Delhi.'

##Using partial_variables
Using partial_variables , you can partially apply functions. 
This is particularly useful when there are common variables to be shared.

Common examples are date or time.

Suppose you want to specify the current date in your prompt, 
hardcoding the date into the prompt or passing it along with other input variables may not be practical. 

In this case, using a function that returns the current date to modify the prompt partially 
is much more convenient.

from datetime import datetime

# Print the current date
datetime.now().strftime("%B %d")
#'January 14'

# Define function to return the current date
def get_today():
    return datetime.now().strftime("%B %d")

prompt = PromptTemplate(
    template="Today's date is {today}. Please list {n} celebrities whose birthday is today. Please specify their date of birth.",
    input_variables=["n"],
    partial_variables={
        "today": get_today  # Pass `partial_variables` in dictionary form
    },
)

# Create prompt
prompt.format(n=3)
#"Today's date is January 14. Please list 3 celebrities whose birthday is today. Please specify their date of birth."

# Create chain
chain = prompt | llm

# Invoke chain and check the result
print(chain.invoke(3).content)


# Invoke chain and check the result
print(chain.invoke({"today": "Jan 02", "n": 3}).content)


##Load Prompt Templates from YAML Files
You can manage prompt templates in seperate yaml files and load using load_prompt .

#fruit_color.yaml 
_type: "prompt"
template: "What is the color of {fruit}?"
input_variables: ["fruit"]

#capital.yaml 
_type: "prompt"
template: |
  Please provide information about the capital city of {country}.
  Summarize the characteristics of the capital in the following format, within 300 words.
  ----
  [Format]
  1. Area
  2. Population
  3. Historical Sites
  4. Regional Products
  
  #Answer:
input_variables: ["country"]


from langchain_core.prompts import load_prompt

prompt = load_prompt("prompts/fruit_color.yaml", encoding="utf-8")
prompt
#PromptTemplate(input_variables=['fruit'], input_types={}, partial_variables={}, template='What is the color of {fruit}?')

prompt.format(fruit="an apple")
#'What is the color of an apple?'

prompt2 = load_prompt("prompts/capital.yaml")
print(prompt2.format(country="United States of America"))

Please provide information about the capital city of United States of America.
Summarize the characteristics of the capital in the following format, within 300 words.
----
[Format]
1. Area
2. Population
3. Historical Sites
4. Regional Products

#Answer:

##ChatPromptTemplate
ChatPromptTemplate can be used to include a conversation history as a prompt.

Messages are structured as tuples in the format 
(role , message ) and are created as a list.

role
    system : A system setup message, typically used for global settings-related prompts.
    human : A user input message.
    ai : An AI response message.

from langchain_core.prompts import ChatPromptTemplate

chat_prompt = ChatPromptTemplate.from_template("What is the capital of {country}?")
chat_prompt
#Output 
ChatPromptTemplate(input_variables=['country'], input_types={}, partial_variables={}, 
messages=[HumanMessagePromptTemplate(prompt=PromptTemplate(input_variables=['country'],
 input_types={}, partial_variables={}, template='What is the capital of {country}?'),
 additional_kwargs={})])

chat_prompt.format(country="United States of America")
#'Human: What is the capital of United States of America?'

from langchain_core.prompts import ChatPromptTemplate

chat_template = ChatPromptTemplate.from_messages(
    [
        # role, message
        ("system", "You are a friendly AI assistant. Your name is {name}."),
        ("human", "Nice to meet you!"),
        ("ai", "Hello! How can I assist you?"),
        ("human", "{user_input}"),
    ]
)

# Create chat messages
messages = chat_template.format_messages(name="Teddy", user_input="What is your name?")
messages
#Output 
[SystemMessage(content='You are a friendly AI assistant. Your name is Teddy.', additional_kwargs={}, response_metadata={}),
 HumanMessage(content='Nice to meet you!', additional_kwargs={}, response_metadata={}),
 AIMessage(content='Hello! How can I assist you?', additional_kwargs={}, response_metadata={}),
 HumanMessage(content='What is your name?', additional_kwargs={}, response_metadata={})]

You can directly invoke LLM using the messages created above.

llm.invoke(messages).content
#'My name is Teddy. How can I help you today?'

You can also create a chain to execute.

chain = chat_template | llm

chain.invoke({"name": "Teddy", "user_input": "What is your name?"}).content
#'My name is Teddy. How can I help you today?'

##MessagePlaceholder
LangChain also provides a MessagePlaceholder , which provides complete control over rendering messages 
during formatting.

This can be useful if you’re unsure which roles to use in a message prompt template 
or if you want to insert a list of messages during formatting.

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

chat_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a summarization specialist AI assistant. 
            Your mission is to summarize conversations using key points.",
        ),
        MessagesPlaceholder(variable_name="conversation"),
        ("human", "Summarize the conversation so far in {word_count} words."),
    ]
)
chat_prompt

ChatPromptTemplate(input_variables=['conversation', 'word_count'], 
input_types={'conversation': list[typing.Annotated[typing.Union[typing.Annotated
[langchain_core.messages.ai.AIMessage, Tag(tag='ai')], 
typing.Annotated[langchain_core.messages.human.HumanMessage, Tag(tag='human')], 
typing.Annotated[langchain_core.messages.chat.ChatMessage, Tag(tag='chat')], 
typing.Annotated[langchain_core.messages.system.SystemMessage, Tag(tag='system')], 
typing.Annotated[langchain_core.messages.function.FunctionMessage, Tag(tag='function')], 
typing.Annotated[langchain_core.messages.tool.ToolMessage, Tag(tag='tool')], 
typing.Annotated[langchain_core.messages.ai.AIMessageChunk, Tag(tag='AIMessageChunk')], 
typing.Annotated[langchain_core.messages.human.HumanMessageChunk, Tag(tag='HumanMessageChunk')], 
typing.Annotated[langchain_core.messages.chat.ChatMessageChunk, Tag(tag='ChatMessageChunk')], typing.Annotated[langchain_core.messages.system.SystemMessageChunk, Tag(tag='SystemMessageChunk')], typing.Annotated[langchain_core.messages.function.FunctionMessageChunk, Tag(tag='FunctionMessageChunk')], typing.Annotated[langchain_core.messages.tool.ToolMessageChunk, Tag(tag='ToolMessageChunk')]], FieldInfo(annotation=NoneType, required=True, discriminator=Discriminator(discriminator=<function _get_type at 0x0000020B148D7E20>, custom_error_type=None, custom_error_message=None, custom_error_context=None))]]}, partial_variables={}, messages=[SystemMessagePromptTemplate(prompt=PromptTemplate(input_variables=[], input_types={}, partial_variables={}, template='You are a summarization specialist AI assistant. Your mission is to summarize conversations using key points.'), additional_kwargs={}), MessagesPlaceholder(variable_name='conversation'), HumanMessagePromptTemplate(prompt=PromptTemplate(input_variables=['word_count'], input_types={}, partial_variables={}, template='Summarize the conversation so far in {word_count} words.'), additional_kwargs={})])

You can use MessagesPlaceholder to add the conversation message list.

formatted_chat_prompt = chat_prompt.format(
    word_count=5,
    conversation=[
        ("human", "Hello! I’m Teddy. Nice to meet you."),
        ("ai", "Nice to meet you! I look forward to working with you."),
    ],
)

print(formatted_chat_prompt)
#output 
System: You are a summarization specialist AI assistant. Your mission is to summarize conversations using key points.
Human: Hello! I’m Teddy. Nice to meet you.
AI: Nice to meet you! I look forward to working with you.
Human: Summarize the conversation so far in 5 words.

# Create chain
chain = chat_prompt | llm | StrOutputParser()

# Invoke chain and check the result
chain.invoke(
    {
        "word_count": 5,
        "conversation": [
            (
                "human",
                "Hello! I'm Teddy. Nice to meet you.",
            ),
            ("ai", "Nice to meet you! I look forward to working with you."),
        ],
    }
)

'Teddy introduces himself, exchanges greetings.'

##LangchainHub 
https://github.com/LangChain-OpenTutorial/LangChain-OpenTutorial/blob/main/02-Prompt/03-LangChain-Hub.ipynb
This is an example of retrieving and executing prompts from LangChain Hub.

ou can retrieve prompts by using the prompt repo ID, and you can also get prompts 
for specific versions by adding the commit ID.



from langchain import hub 

# Get the latest version of the prompt
prompt = hub.pull("rlm/rag-prompt")
     

# Print the prompt content
print(prompt)
     
# To get a specific version of prompt, specify the version hash
prompt = hub.pull("rlm/rag-prompt:50442af1")
prompt
     
     
##Prompt Caching 
The easiest way to verify prompt caching is by including large amounts of context or background information.
To demonstrate this, I have provided a simple example using a long document retrieved from Wikipedia.

import urllib.parse
import urllib.request
import json

def fetch_wikipedia_page(title: str, lang: str = "en"):
    """
    Fetch the content of a Wikipedia page using the Wikipedia API.
    
    Args:
        title (str): The title of the Wikipedia page to fetch.
        lang (str): The language code for the Wikipedia (default: "en").
    
    Returns:
        str: The plain text content of the Wikipedia page.
    """
    # Wikipedia API endpoint
    endpoint = f"https://{lang}.wikipedia.org/w/api.php"
    
    # Query parameters
    params = {
        "action": "query",
        "format": "json",
        "prop": "extracts",
        "titles": title,
        "explaintext": True
    }
    
    # Encode the parameters and create the URL
    url = f"{endpoint}?{urllib.parse.urlencode(params)}"
    
    # Send the request and read the response
    with urllib.request.urlopen(url) as response:
        data = json.load(response)
    
    # Extract page content
    pages = data.get("query", {}).get("pages", {})
    for page_id, page in pages.items():
        if "extract" in page:
            return page["extract"]
    
    return "No content found for the given title."

# fetch data from wikipedia
title = "World War II"
content = fetch_wikipedia_page(title)

OpenAI Prompt Caching works automatically on all your API requests (no code changes required) 
and has no additional fees associated with it.

This can reduce latency by up to 80% and costs by 50% for long prompts.
 Caching is available for prompts containing 1024 tokens or more.
 
Models Supporting Prompt Caching

Model 	                    Text Input Cost 	Audio Input Cost
gpt-4o (excludes gpt-4o-2024-05-13 and chatgpt-4o-latest) 	50% less 	        n/a
gpt-4o-mini 	            50% less 	n/a
gpt-4o-realtime-preview 	50% less 	80% less
o1-preview 	                50% less 	n/a
o1-mini 	                50% less 	n/a

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

llm = ChatOpenAI(model="gpt-4o-mini")

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            #The {content} is sourced from the Wikipedia article mentioned above.
            "You are an assistant who answers questions based on the provided document.\n<document>{content}</document>"
        ),
        (
            "human",
            "{question}"
        )
    ]
)

chain = prompt | llm

#Note the content field - meant for caching as given in system message of prompt 
first_response = chain.invoke({"content": content,"question":"When did Australia and New Zealand join the war?"})
second_response = chain.invoke({"content": content,"question":"Where did the first battle between Australia, New Zealand, and Japan take place?"})

# You can see only cache read in 'prompt_tokens_details' -> 'cached_tokens' in langchain 0.3.29 OpenAI calls.
print(f"Answer: {first_response.content}")
print(f"Token Usage: {first_response.response_metadata}")
print()
print(f"Caching Answer: {second_response.content}")
print(f"Token Usage: {second_response.response_metadata}")


###Few-Shot Templates
LangChain's few-shot prompting provides a robust framework for guiding language models 
to generate high-quality outputs by supplying carefully selected examples. 

    Few-shot prompt templates : Define the structure and format of prompts by embedding 
    illustrative examples, guiding the model to produce consistent outputs.
    
    Example selection strategies : Dynamically select the most relevant examples for a given query, 
    enhancing the model's contextual understanding and response accuracy.
    
    Chroma vector store : A powerful utility for storing and retrieving examples based 
    on semantic similarity, enabling scalable and efficient prompt construction.


##FewShotPromptTemplate
Few-shot prompting is a powerful technique that guides language models to produce accurate 
and contextually relevant outputs by providing a small set of carefully designed examples. 

LangChain's FewShotPromptTemplate streamlines this process, 
allowing users to construct flexible and reusable prompts for various tasks like question answering, 
summarization, and correction.

    Designing Few-Shot Prompts
        Define examples that illustrate the desired structure and style of the output.
        Ensure examples cover edge cases to improve model understanding and performance.

    Dynamic Example Selection
        Use semantic similarity techniques or vector-based search to select the most relevant examples for a query.

    Integrating Few-Shot Prompts
        Combine prompt templates with language models to create robust chains for generating responses.


from langchain_openai import ChatOpenAI

# Initialize the language model
llm = ChatOpenAI(
    temperature=0,  # Creativity
    model_name="gpt-4o-mini",  # Use a valid model name
)

# User query
question = "What is the capital of United States of America?"

# Query the model
response = llm.predict(question)

# Print the response
print(response)
#The capital of the United States of America is Washington, D.C.

from langchain_core.prompts import PromptTemplate, FewShotPromptTemplate

# Define examples for the few-shot prompt
examples = [
    {
        "question": "Who lived longer, Steve Jobs or Einstein?",
        "answer": """Does this question require additional questions: Yes.
Additional Question: At what age did Steve Jobs die?
Intermediate Answer: Steve Jobs died at the age of 56.
Additional Question: At what age did Einstein die?
Intermediate Answer: Einstein died at the age of 76.
The final answer is: Einstein
""",
    },
    {
        "question": "When was the founder of Naver born?",
        "answer": """Does this question require additional questions: Yes.
Additional Question: Who is the founder of Naver?
Intermediate Answer: Naver was founded by Lee Hae-jin.
Additional Question: When was Lee Hae-jin born?
Intermediate Answer: Lee Hae-jin was born on June 22, 1967.
The final answer is: June 22, 1967
""",
    },
    {
        "question": "Who was the reigning king when Yulgok Yi's mother was born?",
        "answer": """Does this question require additional questions: Yes.
Additional Question: Who is Yulgok Yi's mother?
Intermediate Answer: Yulgok Yi's mother is Shin Saimdang.
Additional Question: When was Shin Saimdang born?
Intermediate Answer: Shin Saimdang was born in 1504.
Additional Question: Who was the king of Joseon in 1504?
Intermediate Answer: The king of Joseon in 1504 was Yeonsangun.
The final answer is: Yeonsangun
""",
    },
    {
        "question": "Are the directors of Oldboy and Parasite from the same country?",
        "answer": """Does this question require additional questions: Yes.
Additional Question: Who is the director of Oldboy?
Intermediate Answer: The director of Oldboy is Park Chan-wook.
Additional Question: Which country is Park Chan-wook from?
Intermediate Answer: Park Chan-wook is from South Korea.
Additional Question: Who is the director of Parasite?
Intermediate Answer: The director of Parasite is Bong Joon-ho.
Additional Question: Which country is Bong Joon-ho from?
Intermediate Answer: Bong Joon-ho is from South Korea.
The final answer is: Yes
""",
    },
]

# Create an example prompt template
example_prompt = PromptTemplate.from_template(
    "Question:\n{question}\nAnswer:\n{answer}"
)

# Print the first formatted example
print(example_prompt.format(**examples[0]))

Question:
Who lived longer, Steve Jobs or Einstein?
Answer:
Does this question require additional questions: Yes.
Additional Question: At what age did Steve Jobs die?
Intermediate Answer: Steve Jobs died at the age of 56.
Additional Question: At what age did Einstein die?
Intermediate Answer: Einstein died at the age of 76.
The final answer is: Einstein

# Initialize the FewShotPromptTemplate
few_shot_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    suffix="Question:\n{question}\nAnswer:",
    input_variables=["question"],
)

# Example question
question = "How old was Bill Gates when Google was founded?"

# Generate the final prompt
final_prompt = few_shot_prompt.format(question=question)
print(final_prompt)

# Query the model with the final prompt
response = llm.predict(final_prompt)
print(response)

Does this question require additional questions: Yes.  
Additional Question: When was Google founded?  
Intermediate Answer: Google was founded on September 4, 1998.  
Additional Question: What year was Bill Gates born?  
Intermediate Answer: Bill Gates was born on October 28, 1955.  
Additional Question: How old was Bill Gates on September 4, 1998?  
Intermediate Answer: Bill Gates was 42 years old when Google was founded.  
The final answer is: 42 years old.

##Dynamic Example Selection with Chroma
Sometimes we need to go through multiple steps of thinking to evaluate a single question. 
Breaking down the question into steps and guiding towards the desired answer can lead 
to better quality responses. 

Chroma provides an efficient way to store and retrieve examples based on semantic similarity, 
enabling dynamic example selection in workflows.

    Embedding and Vector Store Initialization
        Use OpenAIEmbeddings to embed examples.
        Store the embeddings in a Chroma vector store for efficient retrieval.

    Example Storage
        Examples are stored with both their content and metadata.
        Metadata can include details such as the question and answer, which are used 
        for further processing after retrieval.

    Similarity Search
        Query the vector store to retrieve the most similar examples based on the input.
        Enables context-aware dynamic prompt creation.

Import the necessary packages and create a vector store.
pip install langchain-chroma 
Chroma is an AI-native open-source vector database
pip install chromadb
Local client 
import chromadb
chroma_client = chromadb.Client()


To start the Chroma server, run the following command:
chroma run --path /db_path
Client code then 
import chromadb
chroma_client = chromadb.HttpClient(host='localhost', port=8000)


#langchain code 
class langchain_chroma.vectorstores.Chroma(collection_name: str = 'langchain', 
embedding_function: Embeddings | None = None, persist_directory: str | None = None, 
client_settings: Settings | None = None, collection_metadata: Dict | None = None, 
client: ClientAPI | None = None, relevance_score_fn: Callable[[float], float] | None = None, 
create_collection_if_not_exists: bool | None = True)
    Creates local chromadb store 
    
    from langchain_chroma import Chroma
    from langchain_openai import OpenAIEmbeddings

    vector_store = Chroma(
        collection_name="foo",
        embedding_function=OpenAIEmbeddings(),
        # other params...
    )

    Add Documents:

        from langchain_core.documents import Document

        document_1 = Document(page_content="foo", metadata={"baz": "bar"})
        document_2 = Document(page_content="thud", metadata={"bar": "baz"})
        document_3 = Document(page_content="i will be deleted :(")

        documents = [document_1, document_2, document_3]
        ids = ["1", "2", "3"]
        vector_store.add_documents(documents=documents, ids=ids)

    Update Documents:

        updated_document = Document(
            page_content="qux",
            metadata={"bar": "baz"}
        )

        vector_store.update_documents(ids=["1"],documents=[updated_document])

    Delete Documents:

        vector_store.delete(ids=["3"])

    Search:

        results = vector_store.similarity_search(query="thud",k=1)
        for doc in results:
            print(f"* {doc.page_content} [{doc.metadata}]")

    * thud [{'baz': 'bar'}]

    Search with filter:

        results = vector_store.similarity_search(query="thud",k=1,filter={"baz": "bar"})
        for doc in results:
            print(f"* {doc.page_content} [{doc.metadata}]")

    * foo [{'baz': 'bar'}]

    Search with score:

        results = vector_store.similarity_search_with_score(query="qux",k=1)
        for doc, score in results:
            print(f"* [SIM={score:3f}] {doc.page_content} [{doc.metadata}]")

    * [SIM=0.000000] qux [{'bar': 'baz', 'baz': 'bar'}]

    Async:

        # add documents
        # await vector_store.aadd_documents(documents=documents, ids=ids)

        # delete documents
        # await vector_store.adelete(ids=["3"])

        # search
        # results = vector_store.asimilarity_search(query="thud",k=1)

        # search with score
        results = await vector_store.asimilarity_search_with_score(query="qux",k=1)
        for doc,score in results:
            print(f"* [SIM={score:3f}] {doc.page_content} [{doc.metadata}]")

    * [SIM=0.335463] foo [{'baz': 'bar'}]

    Use as Retriever:

        retriever = vector_store.as_retriever(
            search_type="mmr",
            search_kwargs={"k": 1, "fetch_k": 2, "lambda_mult": 0.5},
        )
        retriever.invoke("thud")

    [Document(metadata={'baz': 'bar'}, page_content='thud')]


#Our code 
from langchain_openai.embeddings.base import OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.prompts.few_shot import FewShotPromptTemplate
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_openai import ChatOpenAI

# Initialize embeddings and vector store
embeddings = OpenAIEmbeddings()
chroma = Chroma(persist_directory="example_selector", embedding_function=embeddings)

#Create example question-answer processes needed to derive the answer.

examples = [
    {
        "question": "Who lived longer, Steve Jobs or Einstein?",
        "answer": """Does this question require additional questions: Yes.
Additional Question: At what age did Steve Jobs die?
Intermediate Answer: Steve Jobs died at the age of 56.
Additional Question: At what age did Einstein die?
Intermediate Answer: Einstein died at the age of 76.
The final answer is: Einstein
""",
    },
    {
        "question": "When was the founder of Google born?",
        "answer": """Does this question require additional questions: Yes.
Additional Question: Who is the founder of Google?
Intermediate Answer: Google was founded by Larry Page and Sergey Brin.
Additional Question: When was Larry Page born?
Intermediate Answer: Larry Page was born on March 26, 1973.
Additional Question: When was Sergey Brin born?
Intermediate Answer: Sergey Brin was born on August 21, 1973.
The final answer is: Larry Page was born on March 26, 1973, and Sergey Brin was born on August 21, 1973.
""",
    },
    {
        "question": "Who was the President when Donald Trump's mother was born?",  # 쉼표 추가
        "answer": """Does this question require additional questions: Yes.
Additional Question: Who is Donald Trump's mother?
Intermediate Answer: Donald Trump's mother is Mary Anne MacLeod Trump.
Additional Question: When was Mary Anne MacLeod Trump born?
Intermediate Answer: Mary Anne MacLeod Trump was born on May 10, 1912.
Additional Question: Who was the U.S. President in 1912?
Intermediate Answer: William Howard Taft was President in 1912.
The final answer is: William Howard Taft
""",
    },
    {
        "question": "Are the directors of Oldboy and Parasite from the same country?",
        "answer": """Does this question require additional questions: Yes.
Additional Question: Who is the director of Oldboy?
Intermediate Answer: The director of Oldboy is Park Chan-wook.
Additional Question: Which country is Park Chan-wook from?
Intermediate Answer: Park Chan-wook is from South Korea.
Additional Question: Who is the director of Parasite?
Intermediate Answer: The director of Parasite is Bong Joon-ho.
Additional Question: Which country is Bong Joon-ho from?
Intermediate Answer: Bong Joon-ho is from South Korea.
The final answer is: Yes
""",
    },
]

Create a vector store and define the DynamicFewShotLearning template.

# Add examples to the vector store
texts = [example["question"] for example in examples]
metadatas = [example for example in examples]
chroma.add_texts(texts=texts, metadatas=metadatas)

# Set up Example Selector
example_selector = SemanticSimilarityExampleSelector(
    vectorstore=chroma,  # Only vectorstore is needed
    k=1  # Number of examples to select
)

# Define Few-Shot Prompt Template
example_prompt_template = PromptTemplate.from_template(
    "Question:\n{question}\nAnswer:\n{answer}\n"
)
prompt = FewShotPromptTemplate(
    example_selector=example_selector,
    example_prompt=example_prompt_template,
    suffix="Question:\n{question}\nAnswer:",
    input_variables=["question"],
)

Let's run it to verify if it produces answers through our desired process.

# Query input and process
query = {"question": "How old was Elon Musk when he made Paypal?"}
formatted_prompt = prompt.format(**query)

# Print the constructed prompt
print("Constructed Prompt:\n")
print(formatted_prompt)

# Initialize the language model
llm = ChatOpenAI(model_name="gpt-4o-mini", temperature=0)

# Query the language model with the constructed prompt
response = llm.predict(formatted_prompt)
print("\nResponse:\n")
print(response)
#Similar to earlier 


##FewShotChatMessagePromptTemplate
Creating prompts for each situation is a complex and tedious task. 
The FewShotChatMessagePromptTemplate leverages a few-shot learning approach 
to dynamically generate chat-based prompts by combining relevant examples 
with a structured format. This method is especially effective for tasks like summarization, 
meeting minute creation, or document processing.

from langchain_core.prompts.chat import ChatPromptTemplate
from langchain_openai.embeddings.base import OpenAIEmbeddings
from langchain_chroma import Chroma

# Initialize OpenAI embeddings
embeddings = OpenAIEmbeddings()

# Initialize the Vector DB
chroma = Chroma(persist_directory="fewshot_chat", embedding_function=embeddings)

# Define examples for few-shot prompting : 
examples = [
    {
        "instruction": "You are an expert in writing meeting minutes. Please write meeting minutes based on the given information",
        "input": "On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.",
        "answer": """
Meeting Minutes: XYZ Company Marketing Strategy Meeting
Date: December 25, 2023
Location: XYZ Company Conference Room
Attendees: John Smith (Marketing Team Leader), Sarah Johnson (Digital Marketing Manager), Mike Wilson (Social Media Manager)

1. Opening
   - Meeting began with opening remarks by Team Leader John Smith.
   - Meeting purpose: Establish marketing strategies for H1 2024 and discuss new social media campaign ideas.

2. Market Trend Overview (John Smith)
   - Team Leader John Smith presented analysis of recent market trends.
   - Shared insights on consumer behavior changes and competitor strategies.

3. Digital Marketing Strategy (Sarah Johnson)
   - Sarah Johnson presented digital marketing strategy.
   - Focused on online advertising and SEO optimization methods.

4. Social Media Campaign (Mike Wilson)
   - Mike Wilson proposed ideas for new social media campaigns.
   - Explained plans for influencer marketing and content strategy.

5. Comprehensive Discussion
   - Team members shared and discussed ideas.
   - Discussed budget and resource allocation for each strategy.

6. Closing
   - Confirmed next meeting date and time.
   - Sarah Johnson assigned to compile and distribute meeting minutes.
""",
    },
    {
        "instruction": "You are a summarization expert. Please summarize the content based on the given information",
        "input": "This document is a 20-page report on 'Strategies for Sustainable Urban Development'. The report comprehensively covers the importance of sustainable urban development, current urbanization issues, and various strategies to make urban development sustainable. The report also introduces successful sustainable urban development cases from multiple countries and summarizes the lessons learned from these cases.",
        "answer": """
Document Summary: Strategy Report for Sustainable Urban Development

- Importance: Emphasizes the necessity of sustainable urban development and its social, economic, and environmental benefits.
- Current Issues: Analyzes major problems in current urbanization processes, such as environmental pollution, resource depletion, and increasing inequality.
- Strategies: Presents various strategies to achieve sustainable urban development. These include eco-friendly construction, public transportation improvements, energy efficiency enhancement, and strengthening community engagement.
- Case Studies: Introduces successful sustainable development cases from cities worldwide. For example, explains achievable strategies through cases like Copenhagen, Denmark and Yokohama, Japan.
- Lessons: Summarizes key lessons learned from these cases. Emphasized lessons include the importance of multi-faceted approaches, cooperation with local communities, and the need for long-term planning.

This report provides an in-depth analysis of how sustainable urban development can be realized in practical and effective forms.
""",
    },
    {
        "instruction": "You are a sentence correction expert. Please correct the following sentences",
        "input": "Our company is planning to introduce a new marketing strategy. Through this, communication with customers will become more effective.",
        "answer": "This company expects to improve customer communication more effectively by introducing a new marketing strategy.",
    },
]

# Add examples to the vector store
texts = [example["instruction"] + " " + example["input"] for example in examples]
metadatas = examples
chroma.add_texts(texts=texts, metadatas=metadatas)

# Example query
query = {
    "instruction": "Please write the meeting minutes",
    "input": "On December 26, 2023, the product development team of ABC Technology Company held a weekly progress meeting for a new mobile application project. The meeting was attended by Project Manager Choi Hyun-soo, Lead Developer Hwang Ji-yeon, and UI/UX Designer Kim Tae-young. The main purpose of the meeting was to review the current progress of the project and establish plans for upcoming milestones. Each team member provided updates on their respective areas of work, and the team set goals for the next week.",
}

# Perform similarity search
query_text = query["instruction"] + " " + query["input"]
results = chroma.similarity_search(query_text, k=1)
print(results)
#[Document(metadata={'answer': '\nMeeting Minutes: XYZ Company Marketing Strategy Meeting\nDate: December 25, 2023\nLocation: XYZ Company Conference Room\nAttendees: John Smith (Marketing Team Leader), Sarah Johnson (Digital Marketing Manager), Mike Wilson (Social Media Manager)\n\n1. Opening\n   - Meeting began with opening remarks by Team Leader John Smith.\n   - Meeting purpose: Establish marketing strategies for H1 2024 and discuss new social media campaign ideas.\n\n2. Market Trend Overview (John Smith)\n   - Team Leader John Smith presented analysis of recent market trends.\n   - Shared insights on consumer behavior changes and competitor strategies.\n\n3. Digital Marketing Strategy (Sarah Johnson)\n   - Sarah Johnson presented digital marketing strategy.\n   - Focused on online advertising and SEO optimization methods.\n\n4. Social Media Campaign (Mike Wilson)\n   - Mike Wilson proposed ideas for new social media campaigns.\n   - Explained plans for influencer marketing and content strategy.\n\n5. Comprehensive Discussion\n   - Team members shared and discussed ideas.\n   - Discussed budget and resource allocation for each strategy.\n\n6. Closing\n   - Confirmed next meeting date and time.\n   - Sarah Johnson assigned to compile and distribute meeting minutes.\n', 'input': "On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.", 'instruction': 'You are an expert in writing meeting minutes. Please write meeting minutes based on the given information'}, page_content="You are an expert in writing meeting minutes. Please write meeting minutes based on the given information On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.")]

# Print the most similar example
print(f"Most similar example to the input:\n{query_text}\n")
for result in results:
    print(f'Instruction:\n{result.metadata["instruction"]}')
    print(f'Input:\n{result.metadata["input"]}')
    print(f'Answer:\n{result.metadata["answer"]}')

Most similar example to the input:
Please write the meeting minutes On December 26, 2023, the product development team of ABC Technology Company held a weekly progress meeting for a new mobile application project. The meeting was attended by Project Manager Choi Hyun-soo, Lead Developer Hwang Ji-yeon, and UI/UX Designer Kim Tae-young. The main purpose of the meeting was to review the current progress of the project and establish plans for upcoming milestones. Each team member provided updates on their respective areas of work, and the team set goals for the next week.

Instruction:
You are an expert in writing meeting minutes. Please write meeting minutes based on the given information
Input:
On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.
Answer:

Meeting Minutes: XYZ Company Marketing Strategy Meeting
Date: December 25, 2023
Location: XYZ Company Conference Room
Attendees: John Smith (Marketing Team Leader), Sarah Johnson (Digital Marketing Manager), Mike Wilson (Social Media Manager)

1. Opening
   - Meeting began with opening remarks by Team Leader John Smith.
   - Meeting purpose: Establish marketing strategies for H1 2024 and discuss new social media campaign ideas.

2. Market Trend Overview (John Smith)
   - Team Leader John Smith presented analysis of recent market trends.
   - Shared insights on consumer behavior changes and competitor strategies.

3. Digital Marketing Strategy (Sarah Johnson)
   - Sarah Johnson presented digital marketing strategy.
   - Focused on online advertising and SEO optimization methods.

4. Social Media Campaign (Mike Wilson)
   - Mike Wilson proposed ideas for new social media campaigns.
   - Explained plans for influencer marketing and content strategy.

5. Comprehensive Discussion
   - Team members shared and discussed ideas.
   - Discussed budget and resource allocation for each strategy.

6. Closing
   - Confirmed next meeting date and time.
   - Sarah Johnson assigned to compile and distribute meeting minutes.

# Create the final prompt template
final_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful assistant.",
        ),
        (
            "human",
            "{instruction}:\n{input}",
        ),
    ]
)

# Combine the prompt and the best example
best_example = results[0].metadata
filled_prompt = final_prompt.format_messages(**best_example)

# Print the filled prompt
print("\nFilled Prompt:\n")
for message in filled_prompt:
    # Determine message type and extract content
    message_type = type(message).__name__  # e.g., SystemMessage, HumanMessage, AIMessage
    content = message.content
    print(f"{message_type}:\n{content}\n")

Filled Prompt:

SystemMessage:
You are a helpful assistant.

HumanMessage:
You are an expert in writing meeting minutes. Please write meeting minutes based on the given information:
On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.



# Query the model with the filled prompt
llm = ChatOpenAI(model_name="gpt-4o-mini", temperature=0)
formatted_prompt = "\n".join([f"{type(message).__name__}:\n{message.content}" for message in filled_prompt])
response = llm.predict(formatted_prompt)

# Print the model's response
print("\nResponse:\n")
print(response)

Response:

**Meeting Minutes**

**Date:** December 25, 2023  
**Time:** 3:00 PM  
**Location:** XYZ Company Conference Room  

**Attendees:**  
- John Smith, Marketing Team Leader  
- Sarah Johnson, Digital Marketing Manager  
- Mike Wilson, Social Media Manager  

**Agenda:**  
1. Overview of recent market trends  
2. Discussion of marketing strategies for the first half of 2024  
3. Ideas for new social media campaigns  

**Minutes:**  

1. **Call to Order:**  
   The meeting was called to order by John Smith at 3:00 PM.

2. **Overview of Recent Market Trends:**  
   - John Smith provided a brief overview of the current market trends affecting the industry. He highlighted key insights that will inform the marketing strategies for the upcoming year.

3. **Presentations on Strategic Ideas:**  
   - **Sarah Johnson (Digital Marketing Manager):**  
     - Presented her strategic ideas focusing on enhancing digital presence through targeted online advertising and SEO optimization.  
     - Suggested exploring partnerships with influencers to broaden reach.

   - **Mike Wilson (Social Media Manager):**  
     - Discussed potential new social media campaigns aimed at increasing engagement and brand awareness.  
     - Proposed a series of interactive posts and contests to drive user participation.

4. **Discussion:**  
   - The team engaged in a collaborative discussion regarding the proposed strategies and campaigns. Feedback was exchanged, and additional ideas were generated to refine the marketing approach.

5. **Next Steps:**  
   - Each team member will further develop their proposals and present a detailed plan in the next meeting scheduled for January 15, 2024.  
   - John Smith will compile the insights from this meeting and prepare a summary report for upper management.

6. **Adjournment:**  
   - The meeting was adjourned at 4:30 PM.

**Action Items:**  
- Sarah Johnson to refine digital marketing strategies.  
- Mike Wilson to develop a detailed plan for social media campaigns.  
- John Smith to prepare a summary report for management.

**Next Meeting:**  
- Date: January 15, 2024  
- Time: TBD  

**Minutes Prepared by:** [Your Name]  
**Date of Preparation:** December 25, 2023

##Resolving Similarity Search Issues in Example Selector
When calculating similarity, both instruction and input are used. 

However, searching based only on instruction does not yield accurate similarity results.

To resolve this, a custom class for similarity calculation is defined.

Below is an example of incorrectly retrieved results.

from langchain_openai.embeddings.base import OpenAIEmbeddings
from langchain_chroma import Chroma

# Initialize OpenAI embeddings
embeddings = OpenAIEmbeddings()

# Initialize the Vector DB
chroma = Chroma(persist_directory="fewshot_chat", embedding_function=embeddings)

from langchain_core.prompts.chat import ChatPromptTemplate
from langchain_openai.embeddings.base import OpenAIEmbeddings
from langchain_chroma import Chroma

# Initialize OpenAI embeddings
embeddings = OpenAIEmbeddings()

# Initialize the Vector DB
chroma = Chroma(persist_directory="fewshot_chat", embedding_function=embeddings)

# Define examples for few-shot prompting
examples = [
    {
        "instruction": "You are an expert in writing meeting minutes. Please write meeting minutes based on the given information",
        "input": "On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader Kim Su-jin, Digital Marketing Manager Park Ji-min, and Social Media Manager Lee Jun-ho. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader Kim Su-jin provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.",
        "answer": """
Meeting Minutes: XYZ Company Marketing Strategy Meeting
Date: December 25, 2023
Location: XYZ Company Conference Room
Attendees: Kim Su-jin (Marketing Team Leader), Park Ji-min (Digital Marketing Manager), Lee Jun-ho (Social Media Manager)

1. Opening
   - Meeting began with opening remarks by Team Leader Kim Su-jin.
   - Meeting purpose: Establish marketing strategies for H1 2024 and discuss new social media campaign ideas.

2. Market Trend Overview (Kim Su-jin)
   - Team Leader Kim Su-jin presented analysis of recent market trends.
   - Shared insights on consumer behavior changes and competitor strategies.

3. Digital Marketing Strategy (Park Ji-min)
   - Park Ji-min presented digital marketing strategy.
   - Focused on online advertising and SEO optimization methods.

4. Social Media Campaign (Lee Jun-ho)
   - Lee Jun-ho proposed ideas for new social media campaigns.
   - Explained plans for influencer marketing and content strategy.

5. Comprehensive Discussion
   - Team members shared and discussed ideas.
   - Discussed budget and resource allocation for each strategy.

6. Closing
   - Confirmed next meeting date and time.
   - Park Ji-min assigned to compile and distribute meeting minutes.
""",
    },
    {
        "instruction": "You are a summarization expert. Please summarize the content based on the given information",
        "input": "This document is a 20-page report on 'Strategies for Sustainable Urban Development'. The report comprehensively covers the importance of sustainable urban development, current urbanization issues, and various strategies to make urban development sustainable. The report also introduces successful sustainable urban development cases from multiple countries and summarizes the lessons learned from these cases.",
        "answer": """
Document Summary: Strategy Report for Sustainable Urban Development

- Importance: Emphasizes the necessity of sustainable urban development and its social, economic, and environmental benefits.
- Current Issues: Analyzes major problems in current urbanization processes, such as environmental pollution, resource depletion, and increasing inequality.
- Strategies: Presents various strategies to achieve sustainable urban development. These include eco-friendly construction, public transportation improvements, energy efficiency enhancement, and strengthening community engagement.
- Case Studies: Introduces successful sustainable development cases from cities worldwide. For example, explains achievable strategies through cases like Copenhagen, Denmark and Yokohama, Japan.
- Lessons: Summarizes key lessons learned from these cases. Emphasized lessons include the importance of multi-faceted approaches, cooperation with local communities, and the need for long-term planning.

This report provides an in-depth analysis of how sustainable urban development can be realized in practical and effective forms.
""",
    },
    {
        "instruction": "You are a sentence correction expert. Please correct the following sentences",
        "input": "Our company is planning to introduce a new marketing strategy. Through this, communication with customers will become more effective.",
        "answer": "This company expects to improve customer communication more effectively by introducing a new marketing strategy.",
    },
]

# Add examples to the vector store
texts = [example["instruction"] + " " + example["input"] for example in examples]
metadatas = examples
chroma.add_texts(texts=texts, metadatas=metadatas)

['d6022d36-36bd-4f7d-b60f-fdf3954141d8',
 '4596fe6f-b3c8-4184-9e47-cca4e6e749b6',
 '326ce3b0-8a76-4ad4-b83c-78e9af0728f1']

# Use Chroma for example selection
def select_examples(query):
    query_text = query["instruction"] + " " + query.get("input", "")
    results = chroma.similarity_search(query_text, k=1)
    print("\n[select_examples Output]")
    print(f"Query Text: {query_text}")
    for i, result in enumerate(results, start=1):
        print(f"Result {i}:")
        print(f"Page Content: {result.page_content}")
        print(f"Metadata: {result.metadata}")
    return results

# Example selector using Chroma
def custom_selector(query):
    results = select_examples(query)
    selected_examples = [
        {
            "instruction": result.metadata["instruction"],
            "input": result.metadata["input"],
            "answer": result.metadata["answer"],
        }
        for result in results
    ]
    print("\n[custom_selector Output]")
    for i, example in enumerate(selected_examples, start=1):
        print(f"Selected Example {i}:")
        print(f"Instruction: {example['instruction']}")
        print(f"Input: {example['input']}")
        print(f"Answer: {example['answer']}")
    return selected_examples

# Example query to test
query = {
    "instruction": "Please write the meeting minutes",
    "input": "On December 26, 2023, the product development team of ABC Technology Company held a weekly progress meeting for a new mobile application project. The meeting was attended by Project Manager Choi Hyun-soo, Lead Developer Hwang Ji-yeon, and UI/UX Designer Kim Tae-young. The main purpose of the meeting was to review the current progress of the project and establish plans for upcoming milestones. Each team member provided updates on their respective areas of work, and the team set goals for the next week.",
}

# Test the functions
custom_selector(query)
#OUTPUT

from langchain_core.prompts import FewShotPromptTemplate, PromptTemplate

# Define a new example prompt template with the custom selector
example_prompt = ChatPromptTemplate.from_messages(
    [
        ("human", "{instruction}:\n{input}"),
        ("ai", "{answer}"),
    ]
)

# Create a prompt template with selected examples
def create_fewshot_prompt(query):
    selected_examples = custom_selector(query)
    fewshot_prompt = ""
    for example in selected_examples:
        fewshot_prompt += example_prompt.format(
            instruction=example["instruction"],
            input=example["input"],
            answer=example["answer"],
        )
    return fewshot_prompt

# Create the final prompt for the chain
def create_final_prompt(query):
    fewshot_prompt = create_fewshot_prompt(query)
    final_prompt = (
        "You are a helpful professional assistant.\n\n" + fewshot_prompt + "\n\n"
        f"Human:\n{query['instruction']}:\n{query['input']}\nAssistant:"
    )
    return final_prompt

# Example queries
queries = [
    {
        "instruction": "Draft meeting minutes for the following discussion",
        "input": "On December 26, 2023, ABC Tech's product development team held their weekly progress meeting regarding the new mobile app project. Present were Project Manager John Davis, Lead Developer Emily Chen, and UI/UX Designer Michael Brown. The team reviewed current project milestones and established next steps. Each team member provided updates on their respective workstreams, and the team set deliverables for the upcoming week.",
    },
    {
        "instruction": "Please provide a summary of the following document",
        "input": "This comprehensive 30-page report titled 'Global Economic Outlook 2023' covers sustainable urban development trends, current urbanization challenges, and strategic approaches to sustainable city planning. The document includes case studies of successful urban development initiatives from various countries and key takeaways from these implementations.",
    },
    {
        "instruction": "Please review and correct these sentences",
        "input": "The company anticipates revenue growth this fiscal year. The new strategic initiatives are showing positive results.",
    },
]

# Process each query and print the responses
for query in queries:
    final_prompt = create_final_prompt(query)
    print("\nFinal Prompt:\n")
    print(final_prompt)
    response = llm.predict(final_prompt)
    print("\nModel Response:\n", response)
    print("\n---\n")
#OUTPUT
[select_examples Output]
Query Text: Draft meeting minutes for the following discussion On December 26, 2023, ABC Tech's product development team held their weekly progress meeting regarding the new mobile app project. Present were Project Manager John Davis, Lead Developer Emily Chen, and UI/UX Designer Michael Brown. The team reviewed current project milestones and established next steps. Each team member provided updates on their respective workstreams, and the team set deliverables for the upcoming week.
Result 1:
Page Content: You are an expert in writing meeting minutes. Please write meeting minutes based on the given information On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.
Metadata: {'answer': '\nMeeting Minutes: XYZ Company Marketing Strategy Meeting\nDate: December 25, 2023\nLocation: XYZ Company Conference Room\nAttendees: John Smith (Marketing Team Leader), Sarah Johnson (Digital Marketing Manager), Mike Wilson (Social Media Manager)\n\n1. Opening\n   - Meeting began with opening remarks by Team Leader John Smith.\n   - Meeting purpose: Establish marketing strategies for H1 2024 and discuss new social media campaign ideas.\n\n2. Market Trend Overview (John Smith)\n   - Team Leader John Smith presented analysis of recent market trends.\n   - Shared insights on consumer behavior changes and competitor strategies.\n\n3. Digital Marketing Strategy (Sarah Johnson)\n   - Sarah Johnson presented digital marketing strategy.\n   - Focused on online advertising and SEO optimization methods.\n\n4. Social Media Campaign (Mike Wilson)\n   - Mike Wilson proposed ideas for new social media campaigns.\n   - Explained plans for influencer marketing and content strategy.\n\n5. Comprehensive Discussion\n   - Team members shared and discussed ideas.\n   - Discussed budget and resource allocation for each strategy.\n\n6. Closing\n   - Confirmed next meeting date and time.\n   - Sarah Johnson assigned to compile and distribute meeting minutes.\n', 'input': "On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.", 'instruction': 'You are an expert in writing meeting minutes. Please write meeting minutes based on the given information'}

[custom_selector Output]
Selected Example 1:
Instruction: You are an expert in writing meeting minutes. Please write meeting minutes based on the given information
Input: On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.
Answer: 
Meeting Minutes: XYZ Company Marketing Strategy Meeting
Date: December 25, 2023
Location: XYZ Company Conference Room
Attendees: John Smith (Marketing Team Leader), Sarah Johnson (Digital Marketing Manager), Mike Wilson (Social Media Manager)

1. Opening
   - Meeting began with opening remarks by Team Leader John Smith.
   - Meeting purpose: Establish marketing strategies for H1 2024 and discuss new social media campaign ideas.

2. Market Trend Overview (John Smith)
   - Team Leader John Smith presented analysis of recent market trends.
   - Shared insights on consumer behavior changes and competitor strategies.

3. Digital Marketing Strategy (Sarah Johnson)
   - Sarah Johnson presented digital marketing strategy.
   - Focused on online advertising and SEO optimization methods.

4. Social Media Campaign (Mike Wilson)
   - Mike Wilson proposed ideas for new social media campaigns.
   - Explained plans for influencer marketing and content strategy.

5. Comprehensive Discussion
   - Team members shared and discussed ideas.
   - Discussed budget and resource allocation for each strategy.

6. Closing
   - Confirmed next meeting date and time.
   - Sarah Johnson assigned to compile and distribute meeting minutes.


Final Prompt:

You are a helpful professional assistant.

Human: You are an expert in writing meeting minutes. Please write meeting minutes based on the given information:
On December 25, 2023, XYZ Company's marketing strategy meeting began at 3 PM. The meeting was attended by Marketing Team Leader John Smith, Digital Marketing Manager Sarah Johnson, and Social Media Manager Mike Wilson. The main purpose of the meeting was to establish marketing strategies for the first half of 2024 and discuss ideas for new social media campaigns. Team Leader John Smith provided a brief overview of recent market trends, followed by presentations from each team member about strategic ideas in their respective fields.
AI: 
Meeting Minutes: XYZ Company Marketing Strategy Meeting
Date: December 25, 2023
Location: XYZ Company Conference Room
Attendees: John Smith (Marketing Team Leader), Sarah Johnson (Digital Marketing Manager), Mike Wilson (Social Media Manager)

1. Opening
   - Meeting began with opening remarks by Team Leader John Smith.
   - Meeting purpose: Establish marketing strategies for H1 2024 and discuss new social media campaign ideas.

2. Market Trend Overview (John Smith)
   - Team Leader John Smith presented analysis of recent market trends.
   - Shared insights on consumer behavior changes and competitor strategies.

3. Digital Marketing Strategy (Sarah Johnson)
   - Sarah Johnson presented digital marketing strategy.
   - Focused on online advertising and SEO optimization methods.

4. Social Media Campaign (Mike Wilson)
   - Mike Wilson proposed ideas for new social media campaigns.
   - Explained plans for influencer marketing and content strategy.

5. Comprehensive Discussion
   - Team members shared and discussed ideas.
   - Discussed budget and resource allocation for each strategy.

6. Closing
   - Confirmed next meeting date and time.
   - Sarah Johnson assigned to compile and distribute meeting minutes.


Human:
Draft meeting minutes for the following discussion:
On December 26, 2023, ABC Tech's product development team held their weekly progress meeting regarding the new mobile app project. Present were Project Manager John Davis, Lead Developer Emily Chen, and UI/UX Designer Michael Brown. The team reviewed current project milestones and established next steps. Each team member provided updates on their respective workstreams, and the team set deliverables for the upcoming week.
Assistant:

Model Response:
 Meeting Minutes: ABC Tech Product Development Team Weekly Progress Meeting  
Date: December 26, 2023  
Location: ABC Tech Conference Room  
Attendees: John Davis (Project Manager), Emily Chen (Lead Developer), Michael Brown (UI/UX Designer)  

1. Opening  
   - The meeting commenced at 10 AM with opening remarks by Project Manager John Davis.  
   - Purpose: Review progress on the new mobile app project and establish next steps.

2. Project Milestones Review  
   - The team reviewed current project milestones and assessed progress against the project timeline.  
   - Discussed any challenges encountered and potential impacts on the schedule.

3. Workstream Updates  
   - **Emily Chen (Lead Developer)**: Provided an update on the development progress, highlighting completed features and ongoing tasks.  
   - **Michael Brown (UI/UX Designer)**: Presented updates on the design aspects, including user feedback and adjustments made to the interface.

4. Next Steps and Deliverables  
   - The team established deliverables for the upcoming week, ensuring alignment on priorities and deadlines.  
   - Each member committed to specific tasks to be completed by the next meeting.

5. Closing  
   - John Davis summarized the key points discussed and confirmed the next meeting date and time.  
   - Action items were assigned, and the meeting adjourned at 11 AM.  

6. Action Items  
   - Emily Chen to continue development on assigned features.  
   - Michael Brown to finalize UI adjustments based on user feedback.  
   - John Davis to monitor overall project progress and address any emerging issues.  

**Next Meeting:** January 2, 2024, at 10 AM.  
**Minutes Prepared by:** [Your Name] (if applicable)

---
...

###Runnable and LangChain Expression Language 


##Understanding Runnable interface 
The Runnable interface is the foundation for working with LangChain components, 
and it's implemented across many of them, such as language models, output parsers, retrievers, 
compiled LangGraph graphs, tools and more.

The Runnable way defines a standard interface that allows a Runnable component to be:
    Invoked: A single input is transformed into an output.
    Batched: Multiple inputs are efficiently transformed into outputs.
    Streamed: Outputs are streamed as they are produced.
    Inspected: Schematic information about Runnable's input, output, and configuration can be accessed.
    Composed: Multiple Runnables can be composed to work together 
    using the LangChain Expression Language (LCEL) to create complex pipelines.


##Optimized parallel execution (batch)
LangChain Runnables offer a built-in batch (and batch_as_completed) API 
that allow you to process multiple inputs in parallel.

The two batching options are:
    batch: Process multiple inputs in parallel, returning results in the same order as the inputs.
    batch_as_completed: Process multiple inputs in parallel, returning results as they complete. 
    Results may arrive out of order, but each includes the input index for matching.

The default implementation of batch and batch_as_completed use a thread pool executor 
to run the invoke method in parallel. This allows for efficient parallel execution without the need 
for users to manage threads, and speeds up code that is I/O-bound (e.g., making API requests, 
reading files, etc.). It will not be as effective for CPU-bound operations, 
as the GIL (Global Interpreter Lock) in Python will prevent true parallel execution.

The async versions of abatch and abatch_as_completed relies on asyncio's gather 
and as_completed functions to run the ainvoke method in parallel.


When processing a large number of inputs using batch or batch_as_completed, users may want 
to control the maximum number of parallel calls. This can be done by setting the max_concurrency attribute 
in the RunnableConfig dictionary. 

Chat Models also have a built-in rate limiter that can be used to control the rate 
at which requests are made.

##Asynchronous support
Runnables expose an asynchronous API, allowing them to be called using the await syntax in Python. 
Asynchronous methods can be identified by the "a" prefix (e.g., ainvoke, abatch, astream, 
abatch_as_completed).

##Streaming APIs
Streaming is critical in making applications based on LLMs feel responsive to end-users.

Runnables expose the following three streaming APIs:
    sync stream and async astream: yields the output a Runnable as it is generated.
    The async astream_events: a more advanced streaming API that allows streaming intermediate steps 
    and final output
    The legacy async astream_log: a legacy streaming API that streams intermediate steps 
    and final output

##Input and output types
Every Runnable is characterized by an input and output type. 
These input and output types can be any Python object, and are defined by the Runnable itself.

Runnable methods that result in the execution of the Runnable 
(e.g., invoke, batch, stream, astream_events) work with these input and output types.
    invoke: Accepts an input and returns an output.
    batch: Accepts a list of inputs and returns a list of outputs.
    stream: Accepts an input and returns a generator that yields outputs.

The input type and output type vary by component:
Component	        Input Type	                Output Type
Prompt	            dictionary	                PromptValue
ChatModel	        a string,   
                    list of chat messages   
                    or a PromptValue	        ChatMessage
                        
LLM	                a string,   
                    list of chat messages   
                    or a PromptValue	        String
                    
OutputParser	    the output of an LLM    
                    or ChatModel	            Depends on the parser
Retriever	        a string	                List of Documents
Tool	            a string or dictionary, 
                    depending on the tool	    Depends on the tool


LLMs in LangChain refer to pure text completion models. 
The APIs they wrap take a string prompt as input and output a string completion. 
OpenAI's GPT-3 is implemented as an LLM.

While Chat Models use language models under the hood, the interface they expose is a bit different. 
Rather than expose a “text in, text out” API as in LLM, ChatModel expose an interface where
 “chat messages” are the inputs and outputs.
              
Chat models are often backed by LLMs but tuned specifically for having conversations. 
Crucially, their provider APIs use a different interface than pure text completion models. 
Instead of a single string, they take a list of chat messages as input and they return an AI message 
as output. 
GPT-4 and Anthropic's Claude-2 are both implemented as chat models.
                    
Additionally, not all models are the same. Different models have different prompting strategies that work 
best for them. For example, Anthropic's models work best with XML 
while OpenAI's work best with JSON. 
You should keep this in mind when designing your apps

Class hierarchy:
BaseLanguageModel --> BaseChatModel --> <name>  # Examples: ChatOpenAI, ChatGooglePalm

Main helpers:
AIMessage, BaseMessage, HumanMessage


## Inspecting schemas
In addition, to the input and output types, some Runnables have been set up with additional run time 
configuration options. There are corresponding APIs to get the Pydantic Schema and JSON Schema of the 
configuration options for the Runnable. Please see the Configurable Runnables section for more information.

Method	Description
get_input_schema	Gives the Pydantic Schema of the input schema for the Runnable.
get_output_schema	Gives the Pydantic Schema of the output schema for the Runnable.
config_schema	    Gives the Pydantic Schema of the config schema for the Runnable.
get_input_jsonschema	Gives the JSONSchema of the input schema for the Runnable.
get_output_jsonschema	Gives the JSONSchema of the output schema for the Runnable.
get_config_jsonschema	Gives the JSONSchema of the config schema for the Runnable.

##RunnableConfig
Any of the methods that are used to execute the runnable (e.g., invoke, batch, stream, astream_events) a
ccept a second argument called RunnableConfig (API Reference). T
his argument is a dictionary that contains configuration for the Runnable that will be used 
at run time during the execution of the runnable.

A RunnableConfig can have any of the following properties defined:

Attribute	Description
run_name	Name used for the given Runnable (not inherited).
run_id	    Unique identifier for this call. sub-calls will get their own unique run ids.
tags	    Tags for this call and any sub-calls.
metadata	Metadata for this call and any sub-calls.
callbacks	Callbacks for this call and any sub-calls.
max_concurrency	Maximum number of parallel calls to make (e.g., used by batch).
recursion_limit	Maximum number of times a call can recurse (e.g., used by Runnables that return Runnables)
configurable	Runtime values for configurable attributes of the Runnable.

Passing config to the invoke method is done like so:

some_runnable.invoke(
   some_input, 
   config={
      'run_name': 'my_run', 
      'tags': ['tag1', 'tag2'], 
      'metadata': {'key': 'value'}
      
   }
)

##Propagation of RunnableConfig
Many Runnables are composed of other Runnables, and it is important that the RunnableConfig is propagated 
to all sub-calls made by the Runnable. This allows providing run time configuration values 
to the parent Runnable that are inherited by all sub-calls.

If this were not the case, it would be impossible to set and propagate callbacks 
or other configuration values like tags and metadata which are expected to be inherited by all sub-calls.

There are two main patterns by which new Runnables are created:
    
Declaratively using LangChain Expression Language (LCEL):

    chain = prompt | chat_model | output_parser

Using a custom Runnable (e.g., RunnableLambda) or using the @tool decorator:

    def foo(input):
        # Note that .invoke() is used directly here
        return bar_runnable.invoke(input)
    foo_runnable = RunnableLambda(foo)

LangChain will try to propagate RunnableConfig automatically for both of the patterns.

For handling the second pattern, LangChain relies on Python's contextvars.

Propagating the RunnableConfig manually is done like so:

async def foo(input, config): # <-- Note the config argument
    return await bar_runnable.ainvoke(input, config=config)
    
foo_runnable = RunnableLambda(foo)

##Setting custom run name, tags, and metadata
The run_name, tags, and metadata attributes of the RunnableConfig dictionary can be used 
to set custom values for the run name, tags, and metadata for a given Runnable.

The run_name is a string that can be used to set a custom name for the run. 
This name will be used in logs and other places to identify the run. It is not inherited by sub-calls.

The tags and metadata attributes are lists and dictionaries, respectively, 
that can be used to set custom tags and metadata for the run. 
These values are inherited by sub-calls.

Using these attributes can be useful for tracking and debugging runs, 
as they will be surfaced in LangSmith as trace attributes that you can filter and search on.

The attributes will also be propagated to callbacks, and will appear in streaming APIs 
like astream_events as part of each event in the stream.


##Setting run id
The run_id MUST be a valid UUID string and unique for each run. 
It is used to identify the parent run, sub-class will get their own unique run ids automatically.

To set a custom run_id, you can pass it as a key-value pair in the config dictionary 
when invoking the Runnable:

import uuid

run_id = uuid.uuid4()

some_runnable.invoke(
   some_input, 
   config={
      'run_id': run_id
   }
)

# Do something with the run_id

##Setting recursion limit
Some Runnables may return other Runnables, which can lead to infinite recursion if not handled properly. 
To prevent this, you can set a recursion_limit in the RunnableConfig dictionary. 
This will limit the number of times a Runnable can recurse.

##Setting max concurrency
If using the batch or batch_as_completed methods, you can set the max_concurrency attribute 
in the RunnableConfig dictionary to control the maximum number of parallel calls to make. 
This can be useful when you want to limit the number of parallel calls to prevent overloading a server 
or API.

If you're trying to rate limit the number of requests made by a Chat Model, 
you can use the built-in rate limiter instead of setting max_concurrency, which will be more effective.

##Setting configurable
The configurable field is used to pass runtime values for configurable attributes of the Runnable.

It is used frequently in LangGraph with LangGraph Persistence and memory.

It is used for a similar purpose in RunnableWithMessageHistory to specify 
either a session_id / conversation_id to keep track of conversation history.

In addition, you can use it to specify any custom configuration options 
to pass to any Configurable Runnable that they create.

##Setting callbacks
Use this option to configure callbacks for the runnable at runtime. T
he callbacks will be passed to all sub-calls made by the runnable.

some_runnable.invoke(
   some_input,
   {
      "callbacks": [
         SomeCallbackHandler(),
         AnotherCallbackHandler(),
      ]
   }
)


##Invoke a runnable - Runnable.invoke() / Runnable.ainvoke()

from langchain_core.runnables import RunnableLambda

runnable = RunnableLambda(lambda x: str(x))
runnable.invoke(5)

# Async variant:
# await runnable.ainvoke(5)
'5'

##Batch a runnable - Runnable.batch() / Runnable.abatch()

from langchain_core.runnables import RunnableLambda

runnable = RunnableLambda(lambda x: str(x))
runnable.batch([7, 8, 9])

# Async variant:
# await runnable.abatch([7, 8, 9])
['7', '8', '9']

##Stream a runnable - Runnable.stream() / Runnable.astream()

from langchain_core.runnables import RunnableLambda


def func(x):
    for y in x:
        yield str(y)


runnable = RunnableLambda(func)

for chunk in runnable.stream(range(5)):
    print(chunk)

# Async variant:
# async for chunk in await runnable.astream(range(5)):
#     print(chunk)
0
1
2
3
4

##Compose runnables - Pipe operator |

from langchain_core.runnables import RunnableLambda

runnable1 = RunnableLambda(lambda x: {"foo": x})
runnable2 = RunnableLambda(lambda x: [x] * 2)

chain = runnable1 | runnable2

chain.invoke(2)
#[{'foo': 2}, {'foo': 2}]

##Invoke runnables in parallel - RunnableParallel

from langchain_core.runnables import RunnableLambda, RunnableParallel

runnable1 = RunnableLambda(lambda x: {"foo": x})
runnable2 = RunnableLambda(lambda x: [x] * 2)

chain = RunnableParallel(first=runnable1, second=runnable2)

chain.invoke(2)
{'first': {'foo': 2}, 'second': [2, 2]}

##Turn any function into a runnable - RunnableLambda

from langchain_core.runnables import RunnableLambda


def func(x):
    return x + 5


runnable = RunnableLambda(func)
runnable.invoke(2)
7

##Merge input and output dicts - RunnablePassthrough.assign

from langchain_core.runnables import RunnableLambda, RunnablePassthrough

runnable1 = RunnableLambda(lambda x: x["foo"] + 7)

chain = RunnablePassthrough.assign(bar=runnable1)

chain.invoke({"foo": 10})
#{'foo': 10, 'bar': 17}

##Include input dict in output dict - RunnablePassthrough

from langchain_core.runnables import (
    RunnableLambda,
    RunnableParallel,
    RunnablePassthrough,
)

runnable1 = RunnableLambda(lambda x: x["foo"] + 7)

chain = RunnableParallel(bar=runnable1, baz=RunnablePassthrough())

chain.invoke({"foo": 10})
{'bar': 17, 'baz': {'foo': 10}}

##Add default invocation args - Runnable.bind like partial application 

from typing import Optional

from langchain_core.runnables import RunnableLambda


def func(main_arg: dict, other_arg: Optional[str] = None) -> dict:
    if other_arg:
        return {**main_arg, **{"foo": other_arg}}
    return main_arg


runnable1 = RunnableLambda(func)
bound_runnable1 = runnable1.bind(other_arg="bye")

bound_runnable1.invoke({"bar": "hello"})
{'bar': 'hello', 'foo': 'bye'}

##Add fallbacks - Runnable.with_fallbacks

from langchain_core.runnables import RunnableLambda

runnable1 = RunnableLambda(lambda x: x + "foo")
runnable2 = RunnableLambda(lambda x: str(x) + "foo")

chain = runnable1.with_fallbacks([runnable2])

chain.invoke(5)
'5foo'

##Add retries - Runnable.with_retry

from langchain_core.runnables import RunnableLambda

counter = -1


def func(x):
    global counter
    counter += 1
    print(f"attempt with {counter=}")
    return x / counter


chain = RunnableLambda(func).with_retry(stop_after_attempt=2)

chain.invoke(2)
attempt with counter=0
attempt with counter=1
2.0

##Configure runnable execution - RunnableConfig

from langchain_core.runnables import RunnableLambda, RunnableParallel

runnable1 = RunnableLambda(lambda x: {"foo": x})
runnable2 = RunnableLambda(lambda x: [x] * 2)
runnable3 = RunnableLambda(lambda x: str(x))

chain = RunnableParallel(first=runnable1, second=runnable2, third=runnable3)

#Check for config dict keys 
#https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.config.RunnableConfig.html
chain.invoke(7, config={"max_concurrency": 2})
#{'first': {'foo': 7}, 'second': [7, 7], 'third': '7'}

##Add default config to runnable - Runnable.with_config

from langchain_core.runnables import RunnableLambda, RunnableParallel

runnable1 = RunnableLambda(lambda x: {"foo": x})
runnable2 = RunnableLambda(lambda x: [x] * 2)
runnable3 = RunnableLambda(lambda x: str(x))

chain = RunnableParallel(first=runnable1, second=runnable2, third=runnable3)
configured_chain = chain.with_config(max_concurrency=2)

chain.invoke(7)
{'first': {'foo': 7}, 'second': [7, 7], 'third': '7'}

##Make runnable attributes configurable -Runnable.with_configurable_fields

from typing import Any, Optional

from langchain_core.runnables import (
    ConfigurableField,
    RunnableConfig,
    RunnableSerializable,
)


class FooRunnable(RunnableSerializable[dict, dict]):
    output_key: str

    def invoke(
        self, input: Any, config: Optional[RunnableConfig] = None, **kwargs: Any
    ) -> list:
        return self._call_with_config(self.subtract_seven, input, config, **kwargs)

    def subtract_seven(self, input: dict) -> dict:
        return {self.output_key: input["foo"] - 7}


runnable1 = FooRunnable(output_key="bar")
configurable_runnable1 = runnable1.configurable_fields(
    output_key=ConfigurableField(id="output_key")
)

configurable_runnable1.invoke(
    {"foo": 10}, config={"configurable": {"output_key": "not bar"}}
)
{'not bar': 3}

configurable_runnable1.invoke({"foo": 10})
{'bar': 3}

##Make chain components configurable - Runnable.with_configurable_alternatives

from typing import Any, Optional

from langchain_core.runnables import RunnableConfig, RunnableLambda, RunnableParallel


class ListRunnable(RunnableSerializable[Any, list]):
    def invoke(
        self, input: Any, config: Optional[RunnableConfig] = None, **kwargs: Any
    ) -> list:
        return self._call_with_config(self.listify, input, config, **kwargs)

    def listify(self, input: Any) -> list:
        return [input]


class StrRunnable(RunnableSerializable[Any, str]):
    def invoke(
        self, input: Any, config: Optional[RunnableConfig] = None, **kwargs: Any
    ) -> list:
        return self._call_with_config(self.strify, input, config, **kwargs)

    def strify(self, input: Any) -> str:
        return str(input)


runnable1 = RunnableLambda(lambda x: {"foo": x})

configurable_runnable = ListRunnable().configurable_alternatives(
    ConfigurableField(id="second_step"), default_key="list", string=StrRunnable()
)
chain = runnable1 | configurable_runnable

chain.invoke(7, config={"configurable": {"second_step": "string"}})
"{'foo': 7}"

chain.invoke(7)
[{'foo': 7}]

##Build a chain dynamically based on input

from langchain_core.runnables import RunnableLambda, RunnableParallel

runnable1 = RunnableLambda(lambda x: {"foo": x})
runnable2 = RunnableLambda(lambda x: [x] * 2)

chain = RunnableLambda(lambda x: runnable1 if x > 6 else runnable2)

chain.invoke(7)
{'foo': 7}

chain.invoke(5)
[5, 5]

##Generate a stream of events - Runnable.astream_events
By design asyncio does not allow its event loop to be nested. 
This presents a practical problem: When in an environment where the event loop is already running 
it’s impossible to run tasks and wait for the result. 
Trying to do so will give the error “RuntimeError: This event loop is already running”.

The issue pops up in various environments, such as web servers, GUI applications and in Jupyter notebooks.

This module patches asyncio to allow nested use of asyncio.run and loop.run_until_complete.
pip install nest_asyncio

#code 
import nest_asyncio

nest_asyncio.apply()

from langchain_core.runnables import RunnableLambda, RunnableParallel

runnable1 = RunnableLambda(lambda x: {"foo": x}, name="first")


async def func(x):
    for _ in range(5):
        yield x


runnable2 = RunnableLambda(func, name="second")

chain = runnable1 | runnable2

async for event in chain.astream_events("bar", version="v2"):
    print(f"event={event['event']} | name={event['name']} | data={event['data']}")

#Output 
event=on_chain_start | name=RunnableSequence | data={'input': 'bar'}
event=on_chain_start | name=first | data={}
event=on_chain_stream | name=first | data={'chunk': {'foo': 'bar'}}
event=on_chain_start | name=second | data={}
event=on_chain_end | name=first | data={'output': {'foo': 'bar'}, 'input': 'bar'}
event=on_chain_stream | name=second | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=RunnableSequence | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=second | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=RunnableSequence | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=second | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=RunnableSequence | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=second | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=RunnableSequence | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=second | data={'chunk': {'foo': 'bar'}}
event=on_chain_stream | name=RunnableSequence | data={'chunk': {'foo': 'bar'}}
event=on_chain_end | name=second | data={'output': {'foo': 'bar'}, 'input': {'foo': 'bar'}}
event=on_chain_end | name=RunnableSequence | data={'output': {'foo': 'bar'}}

##Yield batched outputs as they complete - Runnable.batch_as_completed / Runnable.abatch_as_completed

import time

from langchain_core.runnables import RunnableLambda, RunnableParallel

runnable1 = RunnableLambda(lambda x: time.sleep(x) or print(f"slept {x}"))

for idx, result in runnable1.batch_as_completed([5, 1]):
    print(idx, result)

# Async variant:
# async for idx, result in runnable1.abatch_as_completed([5, 1]):
#     print(idx, result)

slept 1
1 None
slept 5
0 None

##Return subset of output dict - Runnable.pick

from langchain_core.runnables import RunnableLambda, RunnablePassthrough

runnable1 = RunnableLambda(lambda x: x["baz"] + 5)
chain = RunnablePassthrough.assign(foo=runnable1).pick(["foo", "bar"])

chain.invoke({"bar": "hi", "baz": 2})
{'foo': 7, 'bar': 'hi'}

##Declaratively make a batched version of a runnable - Runnable.map

from langchain_core.runnables import RunnableLambda

runnable1 = RunnableLambda(lambda x: list(range(x)))
runnable2 = RunnableLambda(lambda x: x + 5)

chain = runnable1 | runnable2.map()

chain.invoke(3)
[5, 6, 7]

##Get a graph representation of a runnable - Runnable.get_graph
pip install grandalf


from langchain_core.runnables import RunnableLambda, RunnableParallel

runnable1 = RunnableLambda(lambda x: {"foo": x})
runnable2 = RunnableLambda(lambda x: [x] * 2)
runnable3 = RunnableLambda(lambda x: str(x))

chain = runnable1 | RunnableParallel(second=runnable2, third=runnable3)
#https://python.langchain.com/api_reference/core/runnables/langchain_core.runnables.graph.Graph.html
chain.get_graph().print_ascii()


                             +-------------+                              
                             | LambdaInput |                              
                             +-------------+                              
                                    *                                     
                                    *                                     
                                    *                                     
                    +------------------------------+                      
                    | Lambda(lambda x: {'foo': x}) |                      
                    +------------------------------+                      
                                    *                                     
                                    *                                     
                                    *                                     
                     +-----------------------------+                      
                     | Parallel<second,third>Input |                      
                     +-----------------------------+                      
                        ****                  ***                         
                    ****                         ****                     
                  **                                 **                   
+---------------------------+               +--------------------------+  
| Lambda(lambda x: [x] * 2) |               | Lambda(lambda x: str(x)) |  
+---------------------------+               +--------------------------+  
                        ****                  ***                         
                            ****          ****                            
                                **      **                                
                    +------------------------------+                      
                    | Parallel<second,third>Output |                      
                    +------------------------------+

Note mermaid diagram can be drawn in Jupyter natively 
https://mermaid.js.org/intro/syntax-reference.html
import base64
from IPython.display import Image, display

def mm_ink(graphbytes):
  """Given a bytes object holding a Mermaid-format graph, return a URL that will generate the image."""
  base64_bytes = base64.b64encode(graphbytes)
  base64_string = base64_bytes.decode("ascii")
  return "https://mermaid.ink/img/" + base64_string

def mm_display(graphbytes):
  """Given a bytes object holding a Mermaid-format graph, display it."""
  display(Image(url=mm_ink(graphbytes)))

def mm(graph):
  """Given a string containing a Mermaid-format graph, display it."""
  graphbytes = graph.encode("ascii")
  mm_display(graphbytes)

def mm_link(graph):
  """Given a string containing a Mermaid-format graph, return URL for display."""
  graphbytes = graph.encode("ascii")
  return mm_ink(graphbytes)
  
def mm_path(path):
  """Given a path to a file containing a Mermaid-format graph, display it"""
  with open(path, 'rb') as f:
    graphbytes = f.read()
  mm_display(graphbytes)

mm("""
graph LR;
    A--> B & C & D;
    B--> A & E;
    C--> A & E;
    D--> A & E;
    E--> B & C & D;
""")
mm_path('test.mmd')              
mm_link("""
graph LR;
    A--> B & C & D;
    B--> A & E;
    C--> A & E;
    D--> A & E;
    E--> B & C & D;
""")
#'https://mermaid.ink/img/CmdyYXBoIExSOwogICAgQS0tPiBCICYgQyAmIEQ7CiAgICBCLS0+IEEgJiBFOwogICAgQy0tPiBBICYgRTsKICAgIEQtLT4gQSAmIEU7CiAgICBFLS0+IEIgJiBDICYgRDsK'

             
##Get all prompts in a chain - Runnable.get_prompts

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

prompt1 = ChatPromptTemplate.from_messages(
    [("system", "good ai"), ("human", "{input}")]
)
prompt2 = ChatPromptTemplate.from_messages(
    [
        ("system", "really good ai"),
        ("human", "{input}"),
        ("ai", "{ai_output}"),
        ("human", "{input2}"),
    ]
)
#note Prompt is also runnable 
fake_llm = RunnableLambda(lambda prompt: "i am good ai")
chain = prompt1.assign(ai_output=fake_llm) | prompt2 | fake_llm

for i, prompt in enumerate(chain.get_prompts()):
    print(f"**prompt {i=}**\n")
    print(prompt.pretty_repr())
    print("\n" * 3)


**prompt i=0**

================================ System Message ================================

good ai

================================ Human Message =================================

{input}




**prompt i=1**

================================ System Message ================================

really good ai

================================ Human Message =================================

{input}

================================== AI Message ==================================

{ai_output}

================================ Human Message =================================

{input2}

##Add lifecycle listeners - Runnable.with_listeners

import time

from langchain_core.runnables import RunnableLambda
from langchain_core.tracers.schemas import Run


def on_start(run_obj: Run):
    print("start_time:", run_obj.start_time)


def on_end(run_obj: Run):
    print("end_time:", run_obj.end_time)


runnable1 = RunnableLambda(lambda x: time.sleep(x))
chain = runnable1.with_listeners(on_start=on_start, on_end=on_end)
chain.invoke(2)

start_time: 2024-05-17 23:04:00.951065+00:00
end_time: 2024-05-17 23:04:02.958765+00:00

##How to add values to a chain's state

from langchain_core.runnables import RunnableParallel, RunnablePassthrough

runnable = RunnableParallel(
    extra=RunnablePassthrough.assign(mult=lambda x: x["num"] * 3),
    modified=lambda x: x["num"] + 1,
)

runnable.invoke({"num": 1})
{'extra': {'num': 1, 'mult': 3}, 'modified': 2}

One convenient feature of this method is that it allows values to pass through as soon 
as they are available. 

To show this off, we'll use RunnablePassthrough.assign() to immediately return source docs in a retrieval chain:

FAISS:
    FAISS vector store integration.
    https://arxiv.org/pdf/2401.08281) paper.
    Faiss is a library for efficient similarity search and clustering of dense vectors.
    https://github.com/facebookresearch/faiss
    pip install -qU langchain_community faiss-cpu

    
    
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

vectorstore = FAISS.from_texts(
    ["harrison worked at kensho"], embedding=OpenAIEmbeddings()
)
retriever = vectorstore.as_retriever()
template = """Answer the question based only on the following context:
{context}

Question: {question}
"""
prompt = ChatPromptTemplate.from_template(template)
model = ChatOpenAI()

generation_chain = prompt | model | StrOutputParser()

retrieval_chain = {
    "context": retriever,
    "question": RunnablePassthrough(),
} | RunnablePassthrough.assign(output=generation_chain)

stream = retrieval_chain.stream("where did harrison work?")

for chunk in stream:
    print(chunk)

#output 
{'question': 'where did harrison work?'}
{'context': [Document(page_content='harrison worked at kensho')]}
{'output': ''}
{'output': 'H'}
{'output': 'arrison'}
{'output': ' worked'}
{'output': ' at'}
{'output': ' Kens'}
{'output': 'ho'}
{'output': '.'}
{'output': ''}

We can see that the first chunk contains the original "question" since that is immediately available. The second chunk contains "context" since the retriever finishes second. Finally, the output from the generation_chain streams in chunks as soon as it is available.

FAISS
https://python.langchain.com/api_reference/community/vectorstores/langchain_community.vectorstores.faiss.FAISS.html

import faiss
from langchain_community.vectorstores import FAISS
from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_openai import OpenAIEmbeddings

index = faiss.IndexFlatL2(len(OpenAIEmbeddings().embed_query("hello world")))

vector_store = FAISS(
    embedding_function=OpenAIEmbeddings(),
    index=index,
    docstore= InMemoryDocstore(),
    index_to_docstore_id={}
)

Add Documents:

from langchain_core.documents import Document

document_1 = Document(page_content="foo", metadata={"baz": "bar"})
document_2 = Document(page_content="thud", metadata={"bar": "baz"})
document_3 = Document(page_content="i will be deleted :(")

documents = [document_1, document_2, document_3]
ids = ["1", "2", "3"]
vector_store.add_documents(documents=documents, ids=ids)

Delete Documents:

vector_store.delete(ids=["3"])

Search:

results = vector_store.similarity_search(query="thud",k=1)
for doc in results:
    print(f"* {doc.page_content} [{doc.metadata}]")

* thud [{'bar': 'baz'}]

Search with filter:

results = vector_store.similarity_search(query="thud",k=1,filter={"bar": "baz"})
for doc in results:
    print(f"* {doc.page_content} [{doc.metadata}]")

* thud [{'bar': 'baz'}]

Search with score:

results = vector_store.similarity_search_with_score(query="qux",k=1)
for doc, score in results:
    print(f"* [SIM={score:3f}] {doc.page_content} [{doc.metadata}]")

* [SIM=0.335304] foo [{'baz': 'bar'}]

Async:

# add documents
# await vector_store.aadd_documents(documents=documents, ids=ids)

# delete documents
# await vector_store.adelete(ids=["3"])

# search
# results = vector_store.asimilarity_search(query="thud",k=1)

# search with score
results = await vector_store.asimilarity_search_with_score(query="qux",k=1)
for doc,score in results:
    print(f"* [SIM={score:3f}] {doc.page_content} [{doc.metadata}]")

* [SIM=0.335304] foo [{'baz': 'bar'}]

Use as Retriever:

retriever = vector_store.as_retriever(
    search_type="mmr",
    search_kwargs={"k": 1, "fetch_k": 2, "lambda_mult": 0.5},
)
retriever.invoke("thud")

[Document(metadata={'bar': 'baz'}, page_content='thud')]

Note 
https://python.langchain.com/api_reference/langchain/retrievers.html
Retriever class returns Documents given a text query.

It is more general than a vector store. 
A retriever does not need to be able to store documents, only to return (or retrieve) it. 
Vector stores can be used as the backbone of a retriever, but there are other types of retrievers as well.

Class hierarchy:

BaseRetriever --> <name>Retriever  # Examples: ArxivRetriever, MergerRetriever

Main helpers:

Document, Serializable, Callbacks,
CallbackManagerForRetrieverRun, AsyncCallbackManagerForRetrieverRun


###How to run custom functions - RunnableLambda and equivalent  @chain decorator
Note that all inputs to these functions need to be a SINGLE argument. 
If you have a function that accepts multiple arguments, you should write a wrapper 
that accepts a single dict input and unpacks it into multiple arguments.

##Using the constructor

from operator import itemgetter

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_openai import ChatOpenAI


def length_function(text):
    return len(text)


def _multiple_length_function(text1, text2):
    return len(text1) * len(text2)


def multiple_length_function(_dict):
    return _multiple_length_function(_dict["text1"], _dict["text2"])


model = ChatOpenAI()

prompt = ChatPromptTemplate.from_template("what is {a} + {b}")

chain = (
    {
        "a": itemgetter("foo") | RunnableLambda(length_function),
        "b": {"text1": itemgetter("foo"), "text2": itemgetter("bar")}
        | RunnableLambda(multiple_length_function),
    }
    | prompt
    | model
)

chain.invoke({"foo": "bar", "bar": "gah"})
#output 
AIMessage(content='3 + 9 equals 12.', response_metadata={'token_usage': {'completion_tokens': 8, 'prompt_tokens': 14, 'total_tokens': 22}, 'model_name': 'gpt-3.5-turbo', 'system_fingerprint': 'fp_c2295e73ad', 'finish_reason': 'stop', 'logprobs': None}, id='run-73728de3-e483-49e3-ad54-51bd9570e71a-0')

##The convenience @chain decorator
This is functionally equivalent to wrapping the function in a RunnableLambda constructor as shown above. 


from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import chain

prompt1 = ChatPromptTemplate.from_template("Tell me a joke about {topic}")
prompt2 = ChatPromptTemplate.from_template("What is the subject of this joke: {joke}")

#all these are runnables 

@chain
def custom_chain(text):
    prompt_val1 = prompt1.invoke({"topic": text})
    output1 = ChatOpenAI().invoke(prompt_val1)
    parsed_output1 = StrOutputParser().invoke(output1)
    chain2 = prompt2 | ChatOpenAI() | StrOutputParser()
    return chain2.invoke({"joke": parsed_output1})


custom_chain.invoke("bears")
'The subject of the joke is the bear and his girlfriend.'

Above, the @chain decorator is used to convert custom_chain into a runnable, 
which we invoke with the .invoke() method.

If you are using a tracing with LangSmith, you should see a custom_chain trace in there, 
with the calls to OpenAI nested underneath.


##Automatic coercion in chains
When using custom functions in chains with the pipe operator (|), 
you can omit the RunnableLambda or @chain constructor and rely on coercion. 

Here's a simple example with a function that takes the output from the model 
and returns the first five letters of it:

prompt = ChatPromptTemplate.from_template("tell me a story about {topic}")

model = ChatOpenAI()

chain_with_coerced_function = prompt | model | (lambda x: x.content[:5])

chain_with_coerced_function.invoke({"topic": "bears"})
#'Once '

Note that we didn't need to wrap the custom function (lambda x: x.content[:5]) in a RunnableLambda 
constructor because the model on the left of the pipe operator is already a Runnable. 
The custom function is coerced into a runnable. See this section for more information.


##Passing run metadata
Runnable lambdas can optionally accept a RunnableConfig parameter, 
which they can use to pass callbacks, tags, and other configuration information to nested runs.

import json

from langchain_core.runnables import RunnableConfig


def parse_or_fix(text: str, config: RunnableConfig):
    fixing_chain = (
        ChatPromptTemplate.from_template(
            "Fix the following text:\n\n\`\`\`text\n{input}\n\`\`\`\nError: {error}"
            " Don't narrate, just respond with the fixed data."
        )
        | model
        | StrOutputParser()
    )
    for _ in range(3):
        try:
            return json.loads(text)
        except Exception as e:
            text = fixing_chain.invoke({"input": text, "error": e}, config)
    return "Failed to parse"


from langchain_community.callbacks import get_openai_callback

with get_openai_callback() as cb:
    output = RunnableLambda(parse_or_fix).invoke(
        "{foo: bar}", {"tags": ["my-tag"], "callbacks": [cb]}
    )
    print(output)
    print(cb)

#output 
{'foo': 'bar'}
Tokens Used: 62
	Prompt Tokens: 56
	Completion Tokens: 6
Successful Requests: 1
Total Cost (USD): $9.6e-05

Note callbacks are way to hook into LLms 

from typing import Any, Dict, List

from langchain_anthropic import ChatAnthropic
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import LLMResult
from langchain_core.prompts import ChatPromptTemplate


class LoggingHandler(BaseCallbackHandler):
    def on_chat_model_start(
        self, serialized: Dict[str, Any], messages: List[List[BaseMessage]], **kwargs
    ) -> None:
        print("Chat model started")

    def on_llm_end(self, response: LLMResult, **kwargs) -> None:
        print(f"Chat model ended, response: {response}")

    def on_chain_start(
        self, serialized: Dict[str, Any], inputs: Dict[str, Any], **kwargs
    ) -> None:
        print(f"Chain {serialized.get('name')} started")

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs) -> None:
        print(f"Chain ended, outputs: {outputs}")


callbacks = [LoggingHandler()]
llm = ChatAnthropic(model="claude-3-sonnet-20240229")
prompt = ChatPromptTemplate.from_template("What is 1 + {number}?")

chain = prompt | llm

chain.invoke({"number": "2"}, config={"callbacks": callbacks})

Other methods 
on_agent_action(action: AgentAction, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_agent_finish(finish: AgentFinish, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_chain_end(outputs: dict[str, Any], *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_chain_error(error: BaseException, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_chain_start(serialized: dict[str, Any], inputs: dict[str, Any], *, run_id: UUID, parent_run_id: UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) → Any
on_chat_model_start(serialized: dict[str, Any], messages: list[list[BaseMessage]], *, run_id: UUID, parent_run_id: UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) → Any
on_custom_event(name: str, data: Any, *, run_id: UUID, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) → Any
on_llm_end(response: LLMResult, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_llm_error(error: BaseException, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_llm_new_token(token: str, *, chunk: GenerationChunk | ChatGenerationChunk | None = None, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_llm_start(serialized: dict[str, Any], prompts: list[str], *, run_id: UUID, parent_run_id: UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) → Any
on_retriever_end(documents: Sequence[Document], *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_retriever_error(error: BaseException, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_retriever_start(serialized: dict[str, Any], query: str, *, run_id: UUID, parent_run_id: UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) → Any
on_retry(retry_state: RetryCallState, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_text(text: str, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_tool_end(output: Any, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_tool_error(error: BaseException, *, run_id: UUID, parent_run_id: UUID | None = None, **kwargs: Any) → Any
on_tool_start(serialized: dict[str, Any], input_str: str, *, run_id: UUID, parent_run_id: UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, inputs: dict[str, Any] | None = None, **kwargs: Any) → Any



##Streaming
RunnableLambda is best suited for code that does not need to support streaming. 
If you need to support streaming (i.e., be able to operate on chunks of inputs 
and yield chunks of outputs), use RunnableGenerator instead as in the example below.

The signature of these generators should be Iterator[Input] -> Iterator[Output]. 
Or for async generators: AsyncIterator[Input] -> AsyncIterator[Output].

These are useful for:
    implementing a custom output parser
    modifying the output of a previous step, while preserving streaming capabilities

Here's an example of a custom output parser for comma-separated lists. 
First, we create a chain that generates such a list as text:

from typing import Iterator, List

prompt = ChatPromptTemplate.from_template(
    "Write a comma-separated list of 5 animals similar to: {animal}. Do not include numbers"
)

str_chain = prompt | model | StrOutputParser()

for chunk in str_chain.stream({"animal": "bear"}):
    print(chunk, end="", flush=True)

lion, tiger, wolf, gorilla, panda

Next, we define a custom function that will aggregate the currently streamed output 
and yield it when the model generates the next comma in the list:

# This is a custom parser that splits an iterator of llm tokens
# into a list of strings separated by commas
def split_into_list(input: Iterator[str]) -> Iterator[List[str]]:
    # hold partial input until we get a comma
    buffer = ""
    for chunk in input:
        # add current chunk to buffer
        buffer += chunk
        # while there are commas in the buffer
        while "," in buffer:
            # split buffer on comma
            comma_index = buffer.index(",")
            # yield everything before the comma
            yield [buffer[:comma_index].strip()]
            # save the rest for the next iteration
            buffer = buffer[comma_index + 1 :]
    # yield the last chunk
    yield [buffer.strip()]


list_chain = str_chain | split_into_list

for chunk in list_chain.stream({"animal": "bear"}):
    print(chunk, flush=True)

['lion']
['tiger']
['wolf']
['gorilla']
['raccoon']

Invoking it gives a full array of values:

list_chain.invoke({"animal": "bear"})

['lion', 'tiger', 'wolf', 'gorilla', 'raccoon']

##Async version
If you are working in an async environment, here is an async version of the above example:

from typing import AsyncIterator


async def asplit_into_list(
    input: AsyncIterator[str],
) -> AsyncIterator[List[str]]:  # async def
    buffer = ""
    async for (
        chunk
    ) in input:  # `input` is a `async_generator` object, so use `async for`
        buffer += chunk
        while "," in buffer:
            comma_index = buffer.index(",")
            yield [buffer[:comma_index].strip()]
            buffer = buffer[comma_index + 1 :]
    yield [buffer.strip()]


list_chain = str_chain | asplit_into_list

async for chunk in list_chain.astream({"animal": "bear"}):
    print(chunk, flush=True)

['lion']
['tiger']
['wolf']
['gorilla']
['panda']

await list_chain.ainvoke({"animal": "bear"})

['lion', 'tiger', 'wolf', 'gorilla', 'panda']

###ADVANCED: Tools and structured output 
The tool abstraction in LangChain associates a Python function 
with a schema that defines the function's name, description and expected arguments.

Tools can be passed to chat models that support tool calling allowing the model 
to request the execution of a specific function with specific inputs.

The tool interface is defined in the BaseTool class which is a subclass of the Runnable Interface.

The key attributes that correspond to the tool's schema:
    name: The name of the tool.
    description: A description of what the tool does.
    args: Property that returns the JSON schema for the tool's arguments.

The key methods to execute the function associated with the tool:
    invoke: Invokes the tool with the given arguments.
    ainvoke: Invokes the tool with the given arguments, asynchronously. 
    Used for async programming with Langchain.

LangChain supports the creation of tools from:

    Functions;
    LangChain Runnables;
    By sub-classing from BaseTool -- 
    This is the most flexible method, it provides the largest degree of control, 
    at the expense of more effort and code.

##@tool decorator
This @tool decorator is the simplest way to define a custom tool. 
The decorator uses the function name as the tool name by default, 
but this can be overridden by passing a string as the first argument. 

Additionally, the decorator will use the function's docstring as the tool's description - 
so a docstring MUST be provided.

from langchain_core.tools import tool


@tool
def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


# Let's inspect some of the attributes associated with the tool.
print(multiply.name)
print(multiply.description)
print(multiply.args)

multiply
Multiply two numbers.
{'a': {'title': 'A', 'type': 'integer'}, 'b': {'title': 'B', 'type': 'integer'}}

Or create an async implementation, like this:

from langchain_core.tools import tool


@tool
async def amultiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


Note that @tool supports parsing of annotations, nested schemas, and other features:

from typing import Annotated, List

@tool
def multiply_by_max(
    a: Annotated[int, "scale factor"],
    b: Annotated[List[int], "list of ints over which to take maximum"],
) -> int:
    """Multiply a by the maximum of b."""
    return a * max(b)


print(multiply_by_max.args_schema.model_json_schema())

{'description': 'Multiply a by the maximum of b.',
 'properties': {'a': {'description': 'scale factor',
   'title': 'A',
   'type': 'string'},
  'b': {'description': 'list of ints over which to take maximum',
   'items': {'type': 'integer'},
   'title': 'B',
   'type': 'array'}},
 'required': ['a', 'b'],
 'title': 'multiply_by_maxSchema',
 'type': 'object'}

You can also customize the tool name and JSON args by passing them into the tool decorator.

from pydantic import BaseModel, Field


class CalculatorInput(BaseModel):
    a: int = Field(description="first number")
    b: int = Field(description="second number")


@tool("multiplication-tool", args_schema=CalculatorInput, return_direct=True)
def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


# Let's inspect some of the attributes associated with the tool.
print(multiply.name)
print(multiply.description)
print(multiply.args)
print(multiply.return_direct)

multiplication-tool
Multiply two numbers.
{'a': {'description': 'first number', 'title': 'A', 'type': 'integer'}, 'b': {'description': 'second number', 'title': 'B', 'type': 'integer'}}
True

##Docstring parsing
@tool can optionally parse Google Style docstrings and associate the docstring components 
(such as arg descriptions) to the relevant parts of the tool schema. 

To toggle this behavior, specify parse_docstring:

@tool(parse_docstring=True)
def foo(bar: str, baz: int) -> str:
    """The foo.

    Args:
        bar: The bar.
        baz: The baz.
    """
    return bar


print(foo.args_schema.model_json_schema())

{'description': 'The foo.',
 'properties': {'bar': {'description': 'The bar.',
   'title': 'Bar',
   'type': 'string'},
  'baz': {'description': 'The baz.', 'title': 'Baz', 'type': 'integer'}},
 'required': ['bar', 'baz'],
 'title': 'fooSchema',
 'type': 'object'}

By default, @tool(parse_docstring=True) will raise ValueError if the docstring does not parse correctly. 


##StructuredTool
The StructuredTool.from_function class method provides a bit more configurability 
than the @tool decorator, without requiring much additional code.

from langchain_core.tools import StructuredTool


def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


async def amultiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


calculator = StructuredTool.from_function(func=multiply, coroutine=amultiply)

print(calculator.invoke({"a": 2, "b": 3}))
print(await calculator.ainvoke({"a": 2, "b": 5}))

6
10

To configure it:

class CalculatorInput(BaseModel):
    a: int = Field(description="first number")
    b: int = Field(description="second number")


def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


calculator = StructuredTool.from_function(
    func=multiply,
    name="Calculator",
    description="multiply numbers",
    args_schema=CalculatorInput,
    return_direct=True,
    # coroutine= ... <- you can specify an async method if desired as well
)

print(calculator.invoke({"a": 2, "b": 3}))
print(calculator.name)
print(calculator.description)
print(calculator.args)

6
Calculator
multiply numbers
{'a': {'description': 'first number', 'title': 'A', 'type': 'integer'}, 'b': {'description': 'second number', 'title': 'B', 'type': 'integer'}}

##Creating tools from Runnables
LangChain Runnables that accept string or dict input can be converted to tools 
using the as_tool method, which allows for the specification of names, descriptions, 
and additional schema information for arguments.

class langchain_core.language_models.fake_chat_models.GenericFakeChatModel
Bases: BaseChatModel
Generic fake chat model that can be used to test the chat model interface.
    Chat model should be usable in both sync and async tests
    Invokes on_llm_new_token to allow for testing of callback related code for new tokens.
    Includes logic to break messages into message chunk to facilitate testing of streaming
    param messages: Iterator[AIMessage | str] [Required]
        Get an iterator over messages.
        if you want to pass a list, you can use iter to convert it to an iterator.

Example usage:

from langchain_core.language_models import GenericFakeChatModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_messages(
    [("human", "Hello. Please respond in the style of {answer_style}.")]
)

# Placeholder LLM
llm = GenericFakeChatModel(messages=iter(["hello matey"]))

chain = prompt | llm | StrOutputParser()

as_tool = chain.as_tool(
    name="Style responder", description="Description of when to use tool."
)
as_tool.args
{'answer_style': {'title': 'Answer Style', 'type': 'string'}}

##Subclass BaseTool
You can define a custom tool by sub-classing from BaseTool. 
This provides maximal control over the tool definition, but requires writing more code.

from typing import Optional, Type

from langchain_core.callbacks import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class CalculatorInput(BaseModel):
    a: int = Field(description="first number")
    b: int = Field(description="second number")


# Note: It's important that every field has type hints. BaseTool is a
# Pydantic class and not having type hints can lead to unexpected behavior.
class CustomCalculatorTool(BaseTool):
    name: str = "Calculator"
    description: str = "useful for when you need to answer questions about math"
    args_schema: Type[BaseModel] = CalculatorInput
    return_direct: bool = True

    def _run(
        self, a: int, b: int, run_manager: Optional[CallbackManagerForToolRun] = None
    ) -> str:
        """Use the tool."""
        return a * b

    async def _arun(
        self,
        a: int,
        b: int,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        """Use the tool asynchronously."""
        # If the calculation is cheap, you can just delegate to the sync implementation
        # as shown below.
        # If the sync calculation is expensive, you should delete the entire _arun method.
        # LangChain will automatically provide a better implementation that will
        # kick off the task in a thread to make sure it doesn't block other async code.
        return self._run(a, b, run_manager=run_manager.get_sync())


multiply = CustomCalculatorTool()
print(multiply.name)
print(multiply.description)
print(multiply.args)
print(multiply.return_direct)

print(multiply.invoke({"a": 2, "b": 3}))
print(await multiply.ainvoke({"a": 2, "b": 3}))

Calculator
useful for when you need to answer questions about math
{'a': {'description': 'first number', 'title': 'A', 'type': 'integer'}, 'b': {'description': 'second number', 'title': 'B', 'type': 'integer'}}
True
6
6

##How to create async tools
LangChain Tools implement the Runnable interface 

All Runnables expose the invoke and ainvoke methods 
(as well as other methods like batch, abatch, astream etc).

So even if you only provide an sync implementation of a tool, 
you could still use the ainvoke interface, but there are some important things to know:
    LangChain's by default provides an async implementation that assumes 
        that the function is expensive to compute, 
        so it'll delegate execution to another thread.
    If you're working in an async codebase, you should create async tools rather than sync tools, 
        to avoid incuring a small overhead due to that thread.
    If you need both sync and async implementations, use StructuredTool.from_function 
        or sub-class from BaseTool.
    If implementing both sync and async, and the sync code is fast to run, 
        override the default LangChain async implementation and simply call the sync code.
    You CANNOT and SHOULD NOT use the sync invoke with an async tool.

from langchain_core.tools import StructuredTool


def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


calculator = StructuredTool.from_function(func=multiply)

print(calculator.invoke({"a": 2, "b": 3}))
print(
    await calculator.ainvoke({"a": 2, "b": 5})
)  # Uses default LangChain async implementation incurs small overhead

6
10


##Handling Tool Errors
If you're using tools with agents, you will likely need an error handling strategy, 
so the agent can recover from the error and continue execution.

A simple strategy is to throw a ToolException from inside the tool 
and specify an error handler using handle_tool_error.

When the error handler is specified, the exception will be caught 
and the error handler will decide which output to return from the tool.

You can set handle_tool_error to True, a string value, or a function. 
If it's a function, the function should take a ToolException as a parameter and return a value.

Please note that only raising a ToolException won't be effective. 
You need to first set the handle_tool_error of the tool because its default value is False.

from langchain_core.tools import ToolException


def get_weather(city: str) -> int:
    """Get weather for the given city."""
    raise ToolException(f"Error: There is no city by the name of {city}.")


get_weather_tool = StructuredTool.from_function(
    func=get_weather,
    handle_tool_error=True,
)

get_weather_tool.invoke({"city": "foobar"})
'Error: There is no city by the name of foobar.'

We can set handle_tool_error to a string that will always be returned.

get_weather_tool = StructuredTool.from_function(
    func=get_weather,
    handle_tool_error="There is no such city, but it's probably above 0K there!",
)

get_weather_tool.invoke({"city": "foobar"})

"There is no such city, but it's probably above 0K there!"

Handling the error using a function:

def _handle_error(error: ToolException) -> str:
    return f"The following errors occurred during tool execution: `{error.args[0]}`"


get_weather_tool = StructuredTool.from_function(
    func=get_weather,
    handle_tool_error=_handle_error,
)

get_weather_tool.invoke({"city": "foobar"})

'The following errors occurred during tool execution: `Error: There is no city by the name of foobar.`'

##Returning artifacts of Tool execution
Sometimes there are artifacts of a tool's execution that we want to make accessible 
to downstream components in our chain or agent, but that we don't want to expose to the model itself. 

For example if a tool returns custom objects like Documents, 
we may want to pass some view or metadata about this output to the model 
without passing the raw output to the model. 

At the same time, we may want to be able to access this full output elsewhere, 
for example in downstream tools.

The Tool and ToolMessage interfaces make it possible to distinguish 
between the parts of the tool output meant for the model (this is the ToolMessage.content) 
and those parts which are meant for use outside the model (ToolMessage.artifact).

If we want our tool to distinguish between message content and other artifacts, 
we need to specify response_format="content_and_artifact" 
when defining our tool and make sure that we return a tuple of (content, artifact):

import random
from typing import List, Tuple

from langchain_core.tools import tool


@tool(response_format="content_and_artifact")
def generate_random_ints(min: int, max: int, size: int) -> Tuple[str, List[int]]:
    """Generate size random ints in the range [min, max]."""
    array = [random.randint(min, max) for _ in range(size)]
    content = f"Successfully generated array of {size} random ints in [{min}, {max}]."
    return content, array

If we invoke our tool directly with the tool arguments, we'll get back just the content part of the output:

generate_random_ints.invoke({"min": 0, "max": 9, "size": 10})
'Successfully generated array of 10 random ints in [0, 9].'

If we invoke our tool with a ToolCall (like the ones generated by tool-calling models),
we'll get back a ToolMessage that contains both the content and artifact generated by the Tool:

generate_random_ints.invoke(
    {
        "name": "generate_random_ints",
        "args": {"min": 0, "max": 9, "size": 10},
        "id": "123",  # required
        "type": "tool_call",  # required
    }
)

ToolMessage(content='Successfully generated array of 10 random ints in [0, 9].', 
name='generate_random_ints', tool_call_id='123', artifact=[4, 8, 2, 4, 1, 0, 9, 5, 8, 1])

We can do the same when subclassing BaseTool:

from langchain_core.tools import BaseTool


class GenerateRandomFloats(BaseTool):
    name: str = "generate_random_floats"
    description: str = "Generate size random floats in the range [min, max]."
    response_format: str = "content_and_artifact"

    ndigits: int = 2

    def _run(self, min: float, max: float, size: int) -> Tuple[str, List[float]]:
        range_ = max - min
        array = [
            round(min + (range_ * random.random()), ndigits=self.ndigits)
            for _ in range(size)
        ]
        content = f"Generated {size} floats in [{min}, {max}], rounded to {self.ndigits} decimals."
        return content, array

    # Optionally define an equivalent async method

    # async def _arun(self, min: float, max: float, size: int) -> Tuple[str, List[float]]:
    #     ...


rand_gen = GenerateRandomFloats(ndigits=4)

rand_gen.invoke(
    {
        "name": "generate_random_floats",
        "args": {"min": 0.1, "max": 3.3333, "size": 3},
        "id": "123",
        "type": "tool_call",
    }
)

ToolMessage(content='Generated 3 floats in [0.1, 3.3333], rounded to 4 decimals.', 
name='generate_random_floats', tool_call_id='123', artifact=[1.5566, 0.5134, 2.7914])

##Special type annotations
There are a number of special type annotations that can be used in the tool's function signature 
to configure the run time behavior of the tool.

The following type annotations will end up removing the argument from the tool's schema. 
This can be useful for arguments that should not be exposed to the model 
and that the model should not be able to control.
    InjectedToolArg: Value should be injected manually at runtime using .invoke or .ainvoke.
    RunnableConfig: Pass in the RunnableConfig object to the tool.
    InjectedState: Pass in the overall state of the LangGraph graph to the tool.
    InjectedStore: Pass in the LangGraph store object to the tool.

You can also use the Annotated type with a string literal to provide 
a description for the corresponding argument 
that WILL be exposed in the tool's schema.

    Annotated[..., "string literal"] -- Adds a description to the argument 
    that will be exposed in the tool's schema.

##InjectedToolArg
There are cases where certain arguments need to be passed to a tool at runtime 
but should not be generated by the model itself. 

For this, we use the InjectedToolArg annotation, 
which allows certain parameters to be hidden from the tool's schema.

For example, if a tool requires a user_id to be injected dynamically at runtime, 
it can be structured in this way:

from langchain_core.tools import tool, InjectedToolArg

@tool
def user_specific_tool(input_data: str, user_id: InjectedToolArg) -> str:
    """Tool that processes input data."""
    return f"User {user_id} processed {input_data}"

Annotating the user_id argument with InjectedToolArg tells LangChain that this argument 
should not be exposed as part of the tool's schema.

##RunnableConfig
You can use the RunnableConfig object to pass custom run time values to tools.

If you need to access the RunnableConfig object from within a tool. 
This can be done by using the RunnableConfig annotation in the tool's function signature.

from langchain_core.runnables import RunnableConfig

@tool
async def some_func(..., config: RunnableConfig) -> ...:
    """Tool that does something."""
    # do something with config
    ...

await some_func.ainvoke(..., config={"configurable": {"value": "some_value"}})

The config will not be part of the tool's schema and will be injected at runtime with appropriate values.

##Tool calling
Many AI applications interact directly with humans. In these cases, it is appropriate 
for models to respond in natural language. 

But what about cases where we want a model to also interact directly with systems, 
such as databases or an API? These systems often have a particular input schema; 
for example, APIs frequently have a required payload structure. 

This need motivates the concept of tool calling. 
You can use tool calling to request model responses that match a particular schema.

You will sometimes hear the term function calling. We use this term interchangeably with tool calling.

# Tool creation
tools = [my_tool]
# Tool binding
model_with_tools = model.bind_tools(tools)
# Tool calling 
response = model_with_tools.invoke(user_input)

Many model providers support tool calling.
https://python.langchain.com/docs/integrations/providers/
See our model integration page for a list of providers that support tool calling.

##Example of Tool calling 
from langchain_core.tools import tool

# The function name, type hints, and docstring are all part of the tool
# schema that's passed to the model. Defining good, descriptive schemas
# is an extension of prompt engineering and is an important part of
# getting models to perform well.
@tool("multiplication-tool", args_schema=add, return_direct=True)
#give either args_schema or docstring 
def add(a: int, b: int) -> int:
    """Add two integers.

    Args:
        a: First integer
        b: Second integer
    """
    return a + b

@tool 
def multiply(a: int, b: int) -> int:
    """Multiply two integers.

    Args:
        a: First integer
        b: Second integer
    """
    return a * b

#OR 
from pydantic import BaseModel, Field


class add(BaseModel):
    """Add two integers."""

    a: int = Field(..., description="First integer")
    b: int = Field(..., description="Second integer")


class multiply(BaseModel):
    """Multiply two integers."""

    a: int = Field(..., description="First integer")
    b: int = Field(..., description="Second integer")


Or using TypedDicts and annotations:

from typing_extensions import Annotated, TypedDict


class add(TypedDict):
    """Add two integers."""
    # Annotations must have the type and can optionally include a default value and description (in that order).
    a: Annotated[int, ..., "First integer"]
    b: Annotated[int, ..., "Second integer"]


class multiply(TypedDict):
    """Multiply two integers."""
    a: Annotated[int, ..., "First integer"]
    b: Annotated[int, ..., "Second integer"]


tools = [add, multiply]

from langchain.chat_models import init_chat_model

llm = init_chat_model("gpt-4o-mini", model_provider="openai")

llm_with_tools = llm.bind_tools(tools)

query = "What is 3 * 12?"

llm_with_tools.invoke(query)
AIMessage(content='', 
additional_kwargs={'tool_calls': [{'id': 'call_iXj4DiW1p7WLjTAQMRO0jxMs', 
'function': {'arguments': '{"a":3,"b":12}', 'name': 'multiply'}, 'type': 'function'}], 
'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 17, 'prompt_tokens': 80, 
'total_tokens': 97}, 'model_name': 'gpt-4o-mini-2024-07-18', 'system_fingerprint': 'fp_483d39d857', 
'finish_reason': 'tool_calls', 'logprobs': None}, id='run-0b620986-3f62-4df7-9ba3-4595089f9ad4-0', 
tool_calls=[{'name': 'multiply', 'args': {'a': 3, 'b': 12}, 
'id': 'call_iXj4DiW1p7WLjTAQMRO0jxMs', 'type': 'tool_call'}], 
usage_metadata={'input_tokens': 80, 'output_tokens': 17, 'total_tokens': 97})

See tool_calls key, it has automatically selected a function multiply  

A ToolCall is a typed dict that includes a tool name, dict of argument values,
and (optionally) an identifier. 
Messages with no tool calls default to an empty list for this attribute.

query = "What is 3 * 12? Also, what is 11 + 49?"

llm_with_tools.invoke(query).tool_calls

[{'name': 'multiply',
  'args': {'a': 3, 'b': 12},
  'id': 'call_1fyhJAbJHuKQe6n0PacubGsL',
  'type': 'tool_call'},
 {'name': 'add',
  'args': {'a': 11, 'b': 49},
  'id': 'call_fc2jVkKzwuPWyU7kS9qn1hyG',
  'type': 'tool_call'}]
  
Note as of now, tools are not called , only the AI could identify tools 

##Example of How to pass tool outputs to chat models

from langchain.chat_models import init_chat_model

llm = init_chat_model("gpt-4o-mini", model_provider="openai")

from langchain_core.tools import tool


@tool
def add(a: int, b: int) -> int:
    """Adds a and b."""
    return a + b


@tool
def multiply(a: int, b: int) -> int:
    """Multiplies a and b."""
    return a * b


tools = [add, multiply]

llm_with_tools = llm.bind_tools(tools)

from langchain_core.messages import HumanMessage

query = "What is 3 * 12? Also, what is 11 + 49?"

messages = [HumanMessage(query)]

ai_msg = llm_with_tools.invoke(messages)

print(ai_msg.tool_calls)

[{'name': 'multiply', 'args': {'a': 3, 'b': 12}, 'id': 'call_GPGPE943GORirhIAYnWv00rK', 'type': 'tool_call'}, 
{'name': 'add', 'args': {'a': 11, 'b': 49}, 'id': 'call_dm8o64ZrY3WFZHAvCh1bEJ6i', 'type': 'tool_call'}]

messages.append(ai_msg)

Next let's invoke the tool functions using the args the model populated!

you will need to extract the args field from the tool and construct a ToolMessage manually.

for tool_call in ai_msg.tool_calls:
    selected_tool = {"add": add, "multiply": multiply}[tool_call["name"].lower()]
    tool_msg = selected_tool.invoke(tool_call)
    messages.append(tool_msg)

messages

[HumanMessage(content='What is 3 * 12? Also, what is 11 + 49?'),
 AIMessage(content='', additional_kwargs={'tool_calls': [{'id': 'call_loT2pliJwJe3p7nkgXYF48A1', 'function': {'arguments': '{"a": 3, "b": 12}', 'name': 'multiply'}, 'type': 'function'}, {'id': 'call_bG9tYZCXOeYDZf3W46TceoV4', 'function': {'arguments': '{"a": 11, "b": 49}', 'name': 'add'}, 'type': 'function'}]}, response_metadata={'token_usage': {'completion_tokens': 50, 'prompt_tokens': 87, 'total_tokens': 137}, 'model_name': 'gpt-4o-mini-2024-07-18', 'system_fingerprint': 'fp_661538dc1f', 'finish_reason': 'tool_calls', 'logprobs': None}, id='run-e3db3c46-bf9e-478e-abc1-dc9a264f4afe-0', tool_calls=[{'name': 'multiply', 'args': {'a': 3, 'b': 12}, 'id': 'call_loT2pliJwJe3p7nkgXYF48A1', 'type': 'tool_call'}, {'name': 'add', 'args': {'a': 11, 'b': 49}, 'id': 'call_bG9tYZCXOeYDZf3W46TceoV4', 'type': 'tool_call'}], usage_metadata={'input_tokens': 87, 'output_tokens': 50, 'total_tokens': 137}),
 ToolMessage(content='36', name='multiply', tool_call_id='call_loT2pliJwJe3p7nkgXYF48A1'),
 ToolMessage(content='60', name='add', tool_call_id='call_bG9tYZCXOeYDZf3W46TceoV4')]

And finally, we'll invoke the model with the tool results.
 The model will use this information to generate a final answer to our original query:

llm_with_tools.invoke(messages)

AIMessage(content='The result of \\(3 \\times 12\\) is 36, 
and the result of \\(11 + 49\\) is 60.', 
response_metadata={'token_usage': {'completion_tokens': 31, 'prompt_tokens': 153, 
'total_tokens': 184}, 'model_name': 'gpt-4o-mini-2024-07-18', 'system_fingerprint': 'fp_661538dc1f', 'finish_reason': 'stop', 'logprobs': None}, id='run-87d1ef0a-1223-4bb3-9310-7b591789323d-0', usage_metadata={'input_tokens': 153, 'output_tokens': 31, 'total_tokens': 184})

Note that each ToolMessage must include a tool_call_id that matches an id in the original tool 
calls that the model generates. This helps the model match tool responses with tool calls.

Tool calling agents, like those in LangGraph and AgentExecutor, use this basic flow to answer queries and solve tasks.

##Example - How to inject runtime arg using InjectedToolArg
from langchain.chat_models import init_chat_model

llm = init_chat_model("gpt-4o-mini", model_provider="openai")

We can use the InjectedToolArg annotation to mark certain parameters of our Tool, 
like user_id as being injected at runtime, meaning they shouldn't be generated by the model

from typing import List

from langchain_core.tools import InjectedToolArg, tool
from typing_extensions import Annotated

user_to_pets = {}


@tool(parse_docstring=True)
def update_favorite_pets(
    pets: List[str], user_id: Annotated[str, InjectedToolArg]
) -> None:
    """Add the list of favorite pets.

    Args:
        pets: List of favorite pets to set.
        user_id: User's ID.
    """
    user_to_pets[user_id] = pets


@tool(parse_docstring=True)
def delete_favorite_pets(user_id: Annotated[str, InjectedToolArg]) -> None:
    """Delete the list of favorite pets.

    Args:
        user_id: User's ID.
    """
    if user_id in user_to_pets:
        del user_to_pets[user_id]


@tool(parse_docstring=True)
def list_favorite_pets(user_id: Annotated[str, InjectedToolArg]) -> None:
    """List favorite pets if any.

    Args:
        user_id: User's ID.
    """
    return user_to_pets.get(user_id, [])


If we look at the input schemas for these tools, we'll see that user_id is still listed:
type(update_favorite_pets)
dir(update_favorite_pets)

update_favorite_pets.get_input_schema().schema()

But if we look at the tool call schema, which is what is passed to the model for tool-calling, 
user_id has been removed:

update_favorite_pets.tool_call_schema.schema()

So when we invoke our tool, we need to pass in user_id:

user_id = "123"
update_favorite_pets.invoke({"pets": ["lizard", "dog"], "user_id": user_id})
print(user_to_pets)
print(list_favorite_pets.invoke({"user_id": user_id}))
#{'123': ['lizard', 'dog']}
#['lizard', 'dog']

But when the model calls the tool, no user_id argument will be generated:

tools = [
    update_favorite_pets,
    delete_favorite_pets,
    list_favorite_pets,
]
llm_with_tools = llm.bind_tools(tools)
ai_msg = llm_with_tools.invoke("my favorite animals are cats and parrots")
ai_msg.tool_calls
#output 
[{'name': 'update_favorite_pets',
  'args': {'pets': ['cats', 'parrots']},
  'id': 'call_pZ6XVREGh1L0BBSsiGIf1xVm',
  'type': 'tool_call'}]

#Injecting uer_id arguments at runtime

from copy import deepcopy

from langchain_core.runnables import chain

@chain
def inject_user_id(ai_msg):
    tool_calls = []
    for tool_call in ai_msg.tool_calls:
        tool_call_copy = deepcopy(tool_call)
        tool_call_copy["args"]["user_id"] = user_id  # for earlier user_id
        tool_calls.append(tool_call_copy)
    return tool_calls


inject_user_id.invoke(ai_msg)
#output 

[{'name': 'update_favorite_pets',
  'args': {'pets': ['cats', 'parrots'], 'user_id': '123'},
  'id': 'call_pZ6XVREGh1L0BBSsiGIf1xVm',
  'type': 'tool_call'}]

And now we can chain together our model, injection code, and the actual tools to create a tool-executing chain:

tool_map = {tool.name: tool for tool in tools}

@chain
def tool_router(tool_call):
    return tool_map[tool_call["name"]]  # returns StructuredTool

Note , inject_user_id gets ai_message from llm_with_tools
and converts to list of toolcall ie inject_user_id.invoke(ai_msg)
Then tool_router gets one toolcall and returns StructuredTool , which is executed 
as .invoke(tool_call), hence map is required which wud process each tool_call one by one 
from the output of inject_user_id
(If runnable outputs another runnable, that is also executed till the end )

chain = llm_with_tools | inject_user_id | tool_router.map()
chain.invoke("my favorite animals are cats and parrots")
[ToolMessage(content='null', name='update_favorite_pets', tool_call_id='call_oYCD0THSedHTbwNAY3NW6uUj')]

Looking at the user_to_pets dict, we can see that it's been updated to include cats and parrots:

user_to_pets
#{'123': ['cats', 'parrots']}

Note 
map() -> 'Runnable[list[Input], list[Output]]' 
    Return a new Runnable that maps a list of inputs to a list of outputs,
    by calling invoke() with each input.

    from langchain_core.runnables import RunnableLambda

    def _lambda(x: int) -> int:
        return x + 1

    runnable = RunnableLambda(_lambda)
    print(runnable.map().invoke([1, 2, 3])) # [2, 3, 4]
    
    from langchain_core.runnables import RunnableLambda

    def _g(x: int):
        return x + 1

    def _h(x: int):
        return RunnableLambda(_g)
    
    def _i(x: int):
        return RunnableLambda(_h)

    runnable = RunnableLambda(_i)
    print(runnable.map().invoke([1, 2, 3])) # [2, 3, 4]
    
    

##3rd party Tools 
LangChain has a large collection of 3rd party tools.
 Please visit Tool Integrations for a list of the available tools.
https://python.langchain.com/docs/integrations/tools/

When using 3rd party tools, make sure that you understand how the tool works, 
what permissions it has. Read over its documentation and check if anything is required from you 
from a security point of view. 
Please see our security guidelines for more information.

Let's try out the Wikipedia integration.

!pip install -qU langchain-community wikipedia

from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

api_wrapper = WikipediaAPIWrapper(top_k_results=1, doc_content_chars_max=100)
tool = WikipediaQueryRun(api_wrapper=api_wrapper)

print(tool.invoke({"query": "langchain"}))

The tool has the following defaults associated with it:
print(f"Name: {tool.name}")
print(f"Description: {tool.description}")
print(f"args schema: {tool.args}")
print(f"returns directly?: {tool.return_direct}")

##How to use built-in toolkits
Toolkits are collections of tools that are designed to be used together for specific tasks. 
They have convenient loading methods.

All Toolkits expose a get_tools method which returns a list of tools.

You're usually meant to use them this way:

# Initialize a toolkit
toolkit = ExampleTookit(...)

# Get list of tools
tools = toolkit.get_tools()

##Example - How to force models to call a tool even if not selected by model 
In order to force our LLM to select a specific tool, we can use the tool_choice parameter 
to ensure certain behavior. 

First, let's define our model and tools:

from langchain_core.tools import tool


@tool
def add(a: int, b: int) -> int:
    """Adds a and b."""
    return a + b


@tool
def multiply(a: int, b: int) -> int:
    """Multiplies a and b."""
    return a * b


tools = [add, multiply]

For example, we can force our tool to call the multiply tool by using the following code:

llm_forced_to_multiply = llm.bind_tools(tools, tool_choice="multiply")
llm_forced_to_multiply.invoke("what is 2 + 4")
#output 
AIMessage(content='', additional_kwargs={'tool_calls': [{'id': 'call_9cViskmLvPnHjXk9tbVla5HA', 'function': {'arguments': '{"a":2,"b":4}', 'name': 'Multiply'}, 'type': 'function'}]}, response_metadata={'token_usage': {'completion_tokens': 9, 'prompt_tokens': 103, 'total_tokens': 112}, 'model_name': 'gpt-4o-mini', 'system_fingerprint': None, 'finish_reason': 'stop', 'logprobs': None}, id='run-095b827e-2bdd-43bb-8897-c843f4504883-0', tool_calls=[{'name': 'Multiply', 'args': {'a': 2, 'b': 4}, 'id': 'call_9cViskmLvPnHjXk9tbVla5HA'}], usage_metadata={'input_tokens': 103, 'output_tokens': 9, 'total_tokens': 112})

Even if we pass it something that doesn't require multiplcation - 
it will still call the tool!

We can also just force our tool to select at least one of our tools 
by passing in the "any" (or "required" which is OpenAI specific) keyword to the tool_choice parameter.

llm_forced_to_use_tool = llm.bind_tools(tools, tool_choice="any")
llm_forced_to_use_tool.invoke("What day is today?")

AIMessage(content='', additional_kwargs={'tool_calls': [{'id': 'call_mCSiJntCwHJUBfaHZVUB2D8W', 'function': {'arguments': '{"a":1,"b":2}', 'name': 'Add'}, 'type': 'function'}]}, response_metadata={'token_usage': {'completion_tokens': 15, 'prompt_tokens': 94, 'total_tokens': 109}, 'model_name': 'gpt-4o-mini', 'system_fingerprint': None, 'finish_reason': 'stop', 'logprobs': None}, id='run-28f75260-9900-4bed-8cd3-f1579abb65e5-0', tool_calls=[{'name': 'Add', 'args': {'a': 1, 'b': 2}, 'id': 'call_mCSiJntCwHJUBfaHZVUB2D8W'}], usage_metadata={'input_tokens': 94, 'output_tokens': 15, 'total_tokens': 109})


##Example How to pass runtime secrets to runnables - Usage of RunnableConfig in tool 
Note tool converts a callable to Tool 
        Function must be of type (str) -> str
        Function must have a docstring

Tools are external callable with str 
        
We can pass in secrets to our runnables at runtime using the RunnableConfig. 
Specifically we can pass in secrets with a __ prefix to the configurable field. 
This will ensure that these secrets aren't traced as part of the invocation:

from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool


@tool
def foo(x: int, config: RunnableConfig) -> int:
    """Sum x and a secret int"""
    return x + config["configurable"]["__top_secret_int"]


foo.invoke({"x": 5}, {"configurable": {"__top_secret_int": 2, "traced_key": "bar"}})
7


##How to add ad-hoc tool calling capability to LLMs and Chat Models
Some models have been fine-tuned for tool calling and provide a dedicated API for tool calling. 
Generally, such models are better at tool calling than non-fine-tuned models, 
and are recommended for use cases that require tool calling.

Please see the how to use a chat model to call tools guide for more information.

%pip install --upgrade --quiet langchain langchain-community

You can select any of the given models for this how-to guide. 
Keep in mind that most of these models already support native tool calling, 
so using the prompting strategy shown here doesn't make sense for these models, 
and instead you should follow the how to use a chat model to call tools guide.

To illustrate the idea, we'll use phi3 via Ollama, 
which does NOT have native support for tool calling. 

from langchain_community.llms import Ollama

model = Ollama(model="phi3")

from langchain_core.tools import tool


@tool
def multiply(x: float, y: float) -> float:
    """Multiply two numbers together."""
    return x * y


@tool
def add(x: int, y: int) -> int:
    "Add two numbers."
    return x + y


tools = [multiply, add]

# Let's inspect the tools
for t in tools:
    print("--")
    print(t.name)
    print(t.description)
    print(t.args)


multiply.invoke({"x": 4, "y": 5})
#20.0

We'll want to write a prompt that specifies the tools the model has access to, 
the arguments to those tools, and the desired output format of the model. 

In this case we'll instruct it to output a JSON blob of the form {"name": "...", "arguments": {...}}.

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import render_text_description

rendered_tools = render_text_description(tools)
print(rendered_tools)
#output 
multiply(x: float, y: float) -> float - Multiply two numbers together.
add(x: int, y: int) -> int - Add two numbers.

system_prompt = f"""\
You are an assistant that has access to the following set of tools. 
Here are the names and descriptions for each tool:

{rendered_tools}

Given the user input, return the name and input of the tool to use. 
Return your response as a JSON blob with 'name' and 'arguments' keys.

The `arguments` should be a dictionary, with keys corresponding 
to the argument names and the values corresponding to the requested values.
"""

prompt = ChatPromptTemplate.from_messages(
    [("system", system_prompt), ("user", "{input}")]
)

chain = prompt | model
message = chain.invoke({"input": "what's 3 plus 1132"})

# Let's take a look at the output from the model
# if the model is an LLM (not a chat model), the output will be a string.
if isinstance(message, str):
    print(message)
else:  # Otherwise it's a chat model
    print(message.content)

{
    "name": "add",
    "arguments": {
        "x": 3,
        "y": 1132
    }
}


We'll use the JsonOutputParser for parsing our models output to JSON.

from langchain_core.output_parsers import JsonOutputParser

chain = prompt | model | JsonOutputParser()
chain.invoke({"input": "what's thirteen times 4"})
#output 
{'name': 'multiply', 'arguments': {'x': 13.0, 'y': 4.0}}

Now that the model can request that a tool be invoked, we need to write a function 
that can actually invoke the tool.

The function will select the appropriate tool by name, and pass to it the arguments chosen by the model.

from typing import Any, Dict, Optional, TypedDict

from langchain_core.runnables import RunnableConfig


class ToolCallRequest(TypedDict):
    """A typed dict that shows the inputs into the invoke_tool function."""

    name: str
    arguments: Dict[str, Any]


def invoke_tool(
    tool_call_request: ToolCallRequest, config: Optional[RunnableConfig] = None
):
    """A function that we can use the perform a tool invocation.

    Args:
        tool_call_request: a dict that contains the keys name and arguments.
            The name must match the name of a tool that exists.
            The arguments are the arguments to that tool.
        config: This is configuration information that LangChain uses that contains
            things like callbacks, metadata, etc.See LCEL documentation about RunnableConfig.

    Returns:
        output from the requested tool
    """
    tool_name_to_tool = {tool.name: tool for tool in tools}
    name = tool_call_request["name"]
    requested_tool = tool_name_to_tool[name]
    return requested_tool.invoke(tool_call_request["arguments"], config=config)


invoke_tool({"name": "multiply", "arguments": {"x": 3, "y": 5}})
#15.0

Let's put it together into a chain that creates a calculator with add and multiplication capabilities.

chain = prompt | model | JsonOutputParser() | invoke_tool
chain.invoke({"input": "what's thirteen times 4.14137281"})
#53.83784653


It can be helpful to return not only tool outputs but also tool inputs. 
We can easily do this with LCEL by RunnablePassthrough.assign-ing the tool output. 

from langchain_core.runnables import RunnablePassthrough

chain = (
    prompt | model | JsonOutputParser() | RunnablePassthrough.assign(output=invoke_tool)
)
chain.invoke({"input": "what's thirteen times 4.14137281"})

{'name': 'multiply',
 'arguments': {'x': 13, 'y': 4.14137281},
 'output': 53.83784653}
 
##Complete example, manual Tool callings and AgentExecutor for automatic calling 

import requests
from bs4 import BeautifulSoup
from langchain_core.tools import tool


# Define the tools
@tool
def get_word_length(word: str) -> int:
    """Return the length of the given text"""
    return len(word)


@tool
def add_function(a: float, b: float) -> float:
    """Add two numbers together"""
    return a + b


@tool
def bbc_news_crawl(news_url: str) -> str:
    """Crawl a news article from BBC"""
    response = requests.get(news_url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")

        # Extract the desired information from the article
        article = soup.find("article")
        if article:
            title = article.find("h1").get_text()  # Extract the title
            content_list = [
                tag.get_text()
                for tag in article.find_all(["h2", "p"])
                if (tag.name == "h2" and "sc-518485e5-0" in tag.get("class", []))
                or (tag.name == "p" and "sc-eb7bd5f6-0" in tag.get("class", []))
            ]  # Extract the content
            content = "\n\n".join(content_list)
    else:
        print(f"HTTP request failed. Response code: {response.status_code}")
    return f"{title}\n\n----------\n\n{content}"


tools = [get_word_length, add_function, bbc_news_crawl]

from langchain_openai import ChatOpenAI

# Create a model
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Tool binding
llm_with_tools = llm.bind_tools(tools)

# Execution result
llm_with_tools.invoke(
    "What is the length of the given text 'LangChain OpenTutorial'?"
).tool_calls


from langchain_core.output_parsers.openai_tools import JsonOutputToolsParser

# Tool Binding + Tool Parser
chain = llm_with_tools | JsonOutputToolsParser(tools=tools)

# Execution Result
tool_call_results = chain.invoke(
    "What is the length of the given text 'LangChain OpenTutorial'?"
)
print(tool_call_results)

[{'args': {'word': 'LangChain OpenTutorial'}, 'type': 'get_word_length'}]

print(tool_call_results)
print("\n==========\n")

# First tool call result
single_result = tool_call_results[0]

print(single_result["type"])
print(single_result["args"])


def execute_tool_calls(tool_call_results):
    """
    Function to execute the tool call results.

    :param tool_call_results: List of the tool call results
    :param tools: List of available tools
    """

    # Iterate over the list of the tool call results
    for tool_call_result in tool_call_results:
        # Tool name (function name)
        tool_name = tool_call_result["type"]
        # Tool arguments
        tool_args = tool_call_result["args"]

        # Find the tool that matches the name and execute it
        # Use the next() function to find the first matching tool
        matching_tool = next((tool for tool in tools if tool.name == tool_name), None)
        if matching_tool:
            # Execute the tool
            result = matching_tool.invoke(tool_args)
            print(
                f"[Executed Tool] {tool_name} [Args] {tool_args}\n[Execution Result] {result}"
            )
        else:
            print(f"Warning: Unable to find the tool corresponding to {tool_name}.")


# Execute the tool calls
execute_tool_calls(tool_call_results)


This time, we will combine the entire process of binding tools, parsing the results, 
and executing the tool calls into a single step.

    llm_with_tools : The LLM model with bound tools.
    JsonOutputToolsParser : The parser that processes the results of tool calls.
    execute_tool_calls : The function that executes the results of tool calls.



from langchain_core.output_parsers.openai_tools import JsonOutputToolsParser
# JsonOutputToolsParser = Parse tools from OpenAI response. 
# bind_tools + Parser + Execution
chain = llm_with_tools | JsonOutputToolsParser(tools=tools) | execute_tool_calls

# Execution Result 1
chain.invoke("What is the length of the given text 'LangChain OpenTutorial'?")

# Execution Result 2
chain.invoke("114.5 + 121.2")

# Execution Result 3
chain.invoke("Crawl the news article: https://www.bbc.com/news/articles/cew52g8p2lko")


AgentExecutor creates an execution loop for tasks such as invoking the LLM, 
routing to the appropriate tool, executing it, and re-invoking the model.


from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI

# Create an Agent prompt
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are very powerful assistant, but don't know current events",
        ),
        ("user", "{input}"),
        #This is required and it should be after user 
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ]
)

# Create a model
llm = ChatOpenAI(model="gpt-4o", temperature=0)

from langchain.agents import AgentExecutor, create_tool_calling_agent

# Use the tools defined previously
tools = [get_word_length, add_function, bbc_news_crawl]

# Create an Agent
agent = create_tool_calling_agent(llm, tools, prompt)

# Create an AgentExecutor
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    handle_parsing_errors=True,
)

Let's calculate the length of a word.

# Execute the Agent
result = agent_executor.invoke(
    {"input": "What is the length of the given text 'LangChain OpenTutorial'?"}
)

# Execution Result
print(result["output"])


Let's calculate the sum of two numbers.

# Execute the Agent
result = agent_executor.invoke({"input": "Calculate the result of 114.5 + 121.2"})

# Execution Result
print(result["output"])
print("\n==========\n")

# Execute the Agent
result = agent_executor.invoke(
    {"input": "Calculate the result of 114.5 + 121.2 + 34.2 + 110.1"}
)

# Execution Result
print(result["output"])
print("\n==========\n")


Finally, let's try using a tool to summarize a news article.

# Execute the Agent
result = agent_executor.invoke(
    {
        "input": "Summarize the news article: https://www.bbc.com/news/articles/cew52g8p2lko"
    }
)

# Execution Result
print(result["output"])


 
##Example - How to return structured data from a model
You can find a list of models that support this method here.
https://python.langchain.com/docs/integrations/chat/

from langchain.chat_models import init_chat_model

llm = init_chat_model("gpt-4o-mini", model_provider="openai")

Beyond just the structure of the Pydantic class, the name of the Pydantic class, the docstring, 
and the names and provided descriptions of parameters are very important. 
Most of the time with_structured_output is using a model's function/tool calling API, 
and you can effectively think of all of this information as being added to the model prompt.

from typing import Optional

from pydantic import BaseModel, Field


# Pydantic
class Joke(BaseModel):
    """Joke to tell user."""

    setup: str = Field(description="The setup of the joke")
    punchline: str = Field(description="The punchline to the joke")
    rating: Optional[int] = Field(
        default=None, description="How funny the joke is, from 1 to 10"
    )


structured_llm = llm.with_structured_output(Joke)

structured_llm.invoke("Tell me a joke about cats")
#Joke(setup='Why was the cat sitting on the computer?', 
punchline='Because it wanted to keep an eye on the mouse!', rating=7)

#OR USe TypedDict or JSON Schema - No validation 
If you don't want to use Pydantic, explicitly don't want validation of the arguments, 
or want to be able to stream the model outputs, you can define your schema using a TypedDict class. 


from typing import Optional

from typing_extensions import Annotated, TypedDict


# TypedDict
class Joke(TypedDict):
    """Joke to tell user."""

    setup: Annotated[str, ..., "The setup of the joke"]

    # Alternatively, we could have specified setup as:

    # setup: str                    # no default, no description
    # setup: Annotated[str, ...]    # no default, no description
    # setup: Annotated[str, "foo"]  # default, no description

    punchline: Annotated[str, ..., "The punchline of the joke"]
    rating: Annotated[Optional[int], None, "How funny the joke is, from 1 to 10"]


structured_llm = llm.with_structured_output(Joke)

structured_llm.invoke("Tell me a joke about cats")

{'setup': 'Why was the cat sitting on the computer?',
 'punchline': 'Because it wanted to keep an eye on the mouse!',
 'rating': 7}

Equivalently, we can pass in a JSON Schema dict. 

json_schema = {
    "title": "joke",
    "description": "Joke to tell user.",
    "type": "object",
    "properties": {
        "setup": {
            "type": "string",
            "description": "The setup of the joke",
        },
        "punchline": {
            "type": "string",
            "description": "The punchline to the joke",
        },
        "rating": {
            "type": "integer",
            "description": "How funny the joke is, from 1 to 10",
            "default": None,
        },
    },
    "required": ["setup", "punchline"],
}
structured_llm = llm.with_structured_output(json_schema)

structured_llm.invoke("Tell me a joke about cats")

{'setup': 'Why was the cat sitting on the computer?',
 'punchline': 'Because it wanted to keep an eye on the mouse!',
 'rating': 7}

##Choosing between multiple schemas
The simplest way to let the model choose from multiple schemas is to create a parent schema t
hat has a Union-typed attribute.


from typing import Union


class Joke(BaseModel):
    """Joke to tell user."""

    setup: str = Field(description="The setup of the joke")
    punchline: str = Field(description="The punchline to the joke")
    rating: Optional[int] = Field(
        default=None, description="How funny the joke is, from 1 to 10"
    )


class ConversationalResponse(BaseModel):
    """Respond in a conversational manner. Be kind and helpful."""

    response: str = Field(description="A conversational response to the user's query")


class FinalResponse(BaseModel):
    final_output: Union[Joke, ConversationalResponse]


structured_llm = llm.with_structured_output(FinalResponse)

structured_llm.invoke("Tell me a joke about cats")

FinalResponse(final_output=Joke(setup='Why was the cat sitting on the computer?', 
punchline='Because it wanted to keep an eye on the mouse!', rating=7))

structured_llm.invoke("How are you today?")

FinalResponse(final_output=ConversationalResponse(response="I'm just a computer program, so I don't have feelings, but I'm here and ready to help you with whatever you need!"))

Similar for TypedDict . 

class FinalResponse(TypedDict):
    final_output: Union[Joke, ConversationalResponse]

##Streaming
We can stream outputs from our structured model when the output type is a dict 
(i.e., when the schema is specified as a TypedDict class or JSON Schema dict).

Note that what's yielded is already aggregated chunks, not deltas.

from typing_extensions import Annotated, TypedDict


# TypedDict
class Joke(TypedDict):
    """Joke to tell user."""

    setup: Annotated[str, ..., "The setup of the joke"]
    punchline: Annotated[str, ..., "The punchline of the joke"]
    rating: Annotated[Optional[int], None, "How funny the joke is, from 1 to 10"]


structured_llm = llm.with_structured_output(Joke)

for chunk in structured_llm.stream("Tell me a joke about cats"):
    print(chunk)

{}
{'setup': ''}
{'setup': 'Why'}
{'setup': 'Why was'}
{'setup': 'Why was the'}
{'setup': 'Why was the cat'}
{'setup': 'Why was the cat sitting'}
{'setup': 'Why was the cat sitting on'}
{'setup': 'Why was the cat sitting on the'}
{'setup': 'Why was the cat sitting on the computer'}
{'setup': 'Why was the cat sitting on the computer?'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': ''}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep an'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep an eye'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep an eye on'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep an eye on the'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep an eye on the mouse'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep an eye on the mouse!'}
{'setup': 'Why was the cat sitting on the computer?', 'punchline': 'Because it wanted to keep an eye on the mouse!', 'rating': 7}

##Few-shot prompting
For more complex schemas it's very useful to add few-shot examples to the prompt. 
This can be done in a few ways.

The simplest and most universal way is to add examples to a system message in the prompt:

from langchain_core.prompts import ChatPromptTemplate

system = """You are a hilarious comedian. Your specialty is knock-knock jokes. \
Return a joke which has the setup (the response to "Who's there?") \
and the final punchline (the response to "<setup> who?").

Here are some examples of jokes:

example_user: Tell me a joke about planes
example_assistant: {{"setup": "Why don't planes ever get tired?", "punchline": "Because they have rest wings!", "rating": 2}}

example_user: Tell me another joke about planes
example_assistant: {{"setup": "Cargo", "punchline": "Cargo 'vroom vroom', but planes go 'zoom zoom'!", "rating": 10}}

example_user: Now about caterpillars
example_assistant: {{"setup": "Caterpillar", "punchline": "Caterpillar really slow, but watch me turn into a butterfly and steal the show!", "rating": 5}}"""

prompt = ChatPromptTemplate.from_messages([("system", system), ("human", "{input}")])

few_shot_structured_llm = prompt | structured_llm
few_shot_structured_llm.invoke("what's something funny about woodpeckers")


{'setup': 'Woodpecker',
 'punchline': "Woodpecker you a joke, but I'm afraid it might be too 'hole-some'!",
 'rating': 7}

When the underlying method for structuring outputs is tool calling, 
we can pass in our examples as explicit tool calls. 

You can check if the model you're using makes use of tool calling in its API reference.

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

examples = [
    HumanMessage("Tell me a joke about planes", name="example_user"),
    AIMessage(
        "",
        name="example_assistant",
        tool_calls=[
            {
                "name": "joke",
                "args": {
                    "setup": "Why don't planes ever get tired?",
                    "punchline": "Because they have rest wings!",
                    "rating": 2,
                },
                "id": "1",
            }
        ],
    ),
    # Most tool-calling models expect a ToolMessage(s) to follow an AIMessage with tool calls.
    ToolMessage("", tool_call_id="1"),
    # Some models also expect an AIMessage to follow any ToolMessages,
    # so you may need to add an AIMessage here.
    HumanMessage("Tell me another joke about planes", name="example_user"),
    AIMessage(
        "",
        name="example_assistant",
        tool_calls=[
            {
                "name": "joke",
                "args": {
                    "setup": "Cargo",
                    "punchline": "Cargo 'vroom vroom', but planes go 'zoom zoom'!",
                    "rating": 10,
                },
                "id": "2",
            }
        ],
    ),
    ToolMessage("", tool_call_id="2"),
    HumanMessage("Now about caterpillars", name="example_user"),
    AIMessage(
        "",
        tool_calls=[
            {
                "name": "joke",
                "args": {
                    "setup": "Caterpillar",
                    "punchline": "Caterpillar really slow, but watch me turn into a butterfly and steal the show!",
                    "rating": 5,
                },
                "id": "3",
            }
        ],
    ),
    ToolMessage("", tool_call_id="3"),
]
system = """You are a hilarious comedian. Your specialty is knock-knock jokes. \
Return a joke which has the setup (the response to "Who's there?") \
and the final punchline (the response to "<setup> who?")."""

prompt = ChatPromptTemplate.from_messages(
    [("system", system), ("placeholder", "{examples}"), ("human", "{input}")]
)
few_shot_structured_llm = prompt | structured_llm
few_shot_structured_llm.invoke({"input": "crocodiles", "examples": examples})

{'setup': 'Crocodile',
 'punchline': 'Crocodile be seeing you later, alligator!',
 'rating': 6}
 
 
class langchain_core.messages.ai.AIMessage
    Bases: BaseMessage
    Message from an AI.

    AIMessage is returned from a chat model as a response to a prompt.

    This message represents the output of the model and consists of both the raw output 
    as returned by the model together standardized fields (e.g., tool calls, usage metadata) 
    added by the LangChain framework.

    Pass in content as positional arg.
class langchain_core.messages.human.HumanMessage
    Bases: BaseMessage
    Message from a human.
    HumanMessages are messages that are passed in from a human to the model.

    Example

    from langchain_core.messages import HumanMessage, SystemMessage

    messages = [
        SystemMessage(
            content="You are a helpful assistant! Your name is Bob."
        ),
        HumanMessage(
            content="What is your name?"
        )
    ]
class langchain_core.messages.tool.ToolMessage
    Bases: BaseMessage, ToolOutputMixin
    Message for passing the result of executing a tool back to a model.
    ToolMessages contain the result of a tool invocation. 
    Typically, the result is encoded inside the content field.
    Example: A ToolMessage representing a result of 42 from a tool call with id
        from langchain_core.messages import ToolMessage
        ToolMessage(content='42', tool_call_id='call_Jja7J89XsjrOLA5r!MEOW!SL')

    
    
For more on few shot prompting when using tool calling, see here.
https://python.langchain.com/docs/how_to/tools_few_shot/


##Specifying the method for structuring outputs
For models that support more than one means of structuring outputs (i.e., they support both tool calling 
and JSON mode), you can specify which method to use with the method= argument.

If using JSON mode you'll have to still specify the desired schema in the model prompt.
The schema you pass to with_structured_output will only be used for parsing the model outputs, 
it will not be passed to the model the way it is with tool calling.

To see if the model you're using supports JSON mode, check its entry in the API reference.
https://python.langchain.com/api_reference/langchain/index.html

structured_llm = llm.with_structured_output(None, method="json_mode")

structured_llm.invoke(
    "Tell me a joke about cats, respond in JSON with `setup` and `punchline` keys"
)

{'setup': 'Why was the cat sitting on the computer?',
 'punchline': 'Because it wanted to keep an eye on the mouse!'}

## Raw outputs
structured_llm = llm.with_structured_output(Joke, include_raw=True)

structured_llm.invoke("Tell me a joke about cats")

{'raw': AIMessage(content='', additional_kwargs={'tool_calls': [{'id': 'call_f25ZRmh8u5vHlOWfTUw8sJFZ', 

##Prompting and parsing model outputs directly
Not all models support .with_structured_output(), since not all models have tool calling 
or JSON mode support. For such models you'll need to directly prompt the model to use a specific format, 
and use an output parser to extract the structured response from the raw model output.

Using PydanticOutputParser

The following example uses the built-in PydanticOutputParser to parse the output of a chat model prompted 
to match the given Pydantic schema.
 Note that we are adding format_instructions directly to the prompt from a method on the parser:

from typing import List

from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field


class Person(BaseModel):
    """Information about a person."""

    name: str = Field(..., description="The name of the person")
    height_in_meters: float = Field(
        ..., description="The height of the person expressed in meters."
    )


class People(BaseModel):
    """Identifying information about all people in a text."""

    people: List[Person]


# Set up a parser
parser = PydanticOutputParser(pydantic_object=People)

# Prompt
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Answer the user query. Wrap the output in `json` tags\n{format_instructions}",
        ),
        ("human", "{query}"),
    ]
).partial(format_instructions=parser.get_format_instructions())


query = "Anna is 23 years old and she is 6 feet tall"

print(prompt.invoke({"query": query}).to_string())

chain = prompt | llm | parser

chain.invoke({"query": query})

People(people=[Person(name='Anna', height_in_meters=1.8288)])

For a deeper dive into using output parsers with prompting techniques for structured output, see this guide.
https://python.langchain.com/docs/how_to/output_parser_structured/

##Custom Parsing
You can also create a custom prompt and parser with LangChain Expression Language (LCEL), 
using a plain function to parse the output from the model:

import json
import re
from typing import List

from langchain_core.messages import AIMessage
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field


class Person(BaseModel):
    """Information about a person."""

    name: str = Field(..., description="The name of the person")
    height_in_meters: float = Field(
        ..., description="The height of the person expressed in meters."
    )


class People(BaseModel):
    """Identifying information about all people in a text."""

    people: List[Person]


# Prompt
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Answer the user query. Output your answer as JSON that  "
            "matches the given schema: \`\`\`json\n{schema}\n\`\`\`. "
            "Make sure to wrap the answer in \`\`\`json and \`\`\` tags",
        ),
        ("human", "{query}"),
    ]
).partial(schema=People.schema())


# Custom parser
def extract_json(message: AIMessage) -> List[dict]:
    """Extracts JSON content from a string where JSON is embedded between \`\`\`json and \`\`\` tags.

    Parameters:
        text (str): The text containing the JSON content.

    Returns:
        list: A list of extracted JSON strings.
    """
    text = message.content
    # Define the regular expression pattern to match JSON blocks
    pattern = r"\`\`\`json(.*?)\`\`\`"

    # Find all non-overlapping matches of the pattern in the string
    matches = re.findall(pattern, text, re.DOTALL)

    # Return the list of matched JSON strings, stripping any leading or trailing whitespace
    try:
        return [json.loads(match.strip()) for match in matches]
    except Exception:
        raise ValueError(f"Failed to parse: {message}")


Here is the prompt sent to the model:

query = "Anna is 23 years old and she is 6 feet tall"

print(prompt.format_prompt(query=query).to_string())

chain = prompt | llm | extract_json

chain.invoke({"query": query})

[{'people': [{'name': 'Anna', 'height_in_meters': 1.8288}]}]

###ADVANCED: Advanced Prompts Usage 

##Key Summarization Techniques
In this tutorial, we will explore various document summarization techniques, discussing 
their approaches and applications.

    Stuff: Summarizing the entire document at once by feeding it directly into the LLM's context window. 
    This is the simplest and most straightforward method.

    Map-Reduce: Splitting a document into multiple chunks, summarizing each chunk individually (map), and 
    then merging the summaries into a final summary (reduce).

    Map-Refine: Splitting a document into chunks, summarizing each one, and then progressively refining the 
    summary by referencing previous summaries.

    Chain of Density: Repeatedly summarizing a document while filling in missing entities, progressively 
    improving the summary quality.

    Clustering-Map-Refine: Dividing a document into N clusters, summarizing a central document from each 
    cluster, and then refining the cluster summaries for a comprehensive result.
    
Check for all 
https://github.com/LangChain-OpenTutorial/LangChain-OpenTutorial/blob/main/14-Chains/01-Summary.ipynb


The primary approaches include:
    Stuff (Full Input): Placing the entire document into the context window at once. 
    Simple but limited when handling long documents.

    Map-Reduce (Chunk and Merge): Splitting the document into multiple chunks, summarizing each chunk, 
    and then merging the results into a final summary. Useful for handling large datasets.

    Refine (Sequential Improvement): Processing the document sequentially 
    and refining the summary by merging previous summaries with new content, 
    making it effective for detailed summarization needs.

##Stuff
The stuff documents chain (where "stuff" means "to fill" or "for filling") is the simplest type 
of document chain. It takes a list of documents, inserts them all into the prompt, 
and then sends that prompt to the LLM.

In other words, the context input directly receives Document objects. When using a retriever to search a 
vector_store, it returns a List[Document]. This chain automatically converts the documents into a format 
suitable for the LLM without requiring manual conversion to strings.

This chain is suitable for applications where documents are small, 
and only a few are passed in most calls.

# Loading the text data
from langchain_community.document_loaders import TextLoader

# Load news data
loader = TextLoader("data/news.txt")
docs = loader.load()
print(f"Total characters: {len(docs[0].page_content)}")
print("\n========= Preview =========\n")
print(docs[0].page_content[:500])

Total characters: 6235

========= Preview =========

The following prompt is designed to generate concise and effective summaries 
by guiding the language model with clear instructions.

from langchain_core.prompts import PromptTemplate

prompt = PromptTemplate(
    input_variables=["context"],
    template=(
        "Summarize the following text clearly and concisely.\n\n"
        "When summarizing, keep the following in mind:\n"
        "- Include key events, facts, and critical information.\n"
        "- Omit unnecessary details.\n"
        "- Limit the summary to three sentences.\n\n"
        "Text to summarize:\n{context}\n\n"
        "Summary:"
        )
    )
prompt.pretty_print()

The following function can be used for streaming token output, 
useful for callback handling when working with LLMs.

    A callback is a mechanism that allows specific actions to be executed each time a new token 
    is generated by the LLM. This can be useful for streaming token outputs in real-time.

from langchain_core.callbacks import BaseCallbackHandler

class StreamingCallback(BaseCallbackHandler):
    def __init__(self):
        self.buffer = ""  # Initialize sentence buffer

    def on_llm_new_token(self, token: str, **kwargs) -> None:
        self.buffer += token
        if token in {".", "!", "?"}:  # Print only when a sentence-ending character appears
            print(self.buffer.strip())
            self.buffer = ""  # Clear the buffer

from langchain_openai import ChatOpenAI
from langchain.chains.combine_documents import create_stuff_documents_chain

# Initialize the OpenAI object.
llm = ChatOpenAI(
    model_name="gpt-4o-mini",
    streaming=True,
    temperature=0,
    callbacks=[StreamingCallback()],
)

# Create a "stuff" document chain.
# This chain inserts all documents into the prompt and sends it to the LLM.
stuff_chain = create_stuff_documents_chain(llm, prompt)

# Execute the chain
answer = stuff_chain.invoke({"context": docs})

##Map-Reduce
Map-reduce summarization is an effective technique for condensing lengthy documents.
This method involves two primary stages:
    Map Stage: The document is divided into smaller chunks, 
    each of which is summarized independently.
    Reduce Stage: The individual summaries are then combined 
    to form a cohesive final summary.

This approach is particularly advantageous when dealing with extensive documents, 
as it allows for parallel processing of chunks during the map stage, thereby enhancing efficiency. 

Additionally, it helps circumvent the token limitations inherent in language models 
by ensuring that each chunk fits within the model's context window.

from langchain_community.document_loaders import PyPDFLoader

# Load the PDF file using PyPDFLoader
loader = PyPDFLoader("data/Artificial Intelligence Index Report.pdf")

# load the document
docs = loader.load()
docs = docs[3:8]  # Select only a portion of the document for summarization(pages 3 to 8))

print(f"Total number of pages: {len(docs)}")

Total number of pages: 5

##Map Stage
During the map stage, each chunk is typically processed by generating a summary.

While the standard approach involves summarizing the content of each chunk, 
an alternative method is to extract key information instead.

Since the reduce stage ultimately combines the outputs into a final summary, 
both approaches can be effective with minimal impact on the final result.

The choice between summarization and key information extraction 
during the map stage can be adjusted based on the specific goals and requirements of the task.

from langchain import hub
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser

# initialize the model
llm = ChatOpenAI(
    temperature=0,
    model_name="gpt-4o-mini",
)

# Download the map prompt from the LangChain hub
map_prompt = hub.pull("teddynote/map-prompt")

# print the content of the prompt
map_prompt.pretty_print()

================================ System Message ================================

You are a professional main thesis extractor.

================================ Human Message =================================

Your task is to extract main thesis from given documents. Answer should be in same language as given document. 

#Format: 
- thesis 1
- thesis 2
- thesis 3
- ...

Here is a given document: 
{doc}

Write 1~5 sentences.
#Answer:




# Create the map chain
map_chain = map_prompt | llm | StrOutputParser()

Generate summaries for each document using batch() processing

# Extract key content for a document
doc_summaries = map_chain.batch(docs)

# Generate summaries for each document using batch processing
len(doc_summaries)
5

# Display the summary of the first document
print(doc_summaries[0])

##Reduce Stage
To create a Reduce Chain, the results generated during the map stage are further processed 
to combine and refine them into a final cohesive summary.



from langchain import hub
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser

# Initialize the language model
llm = ChatOpenAI(temperature=0, model_name="gpt-4o-mini")

# Load the reduce prompt from the LangChain hub
reduce_prompt = hub.pull("teddynote/reduce-prompt")

reduce_prompt.pretty_print()

================================ System Message ================================
You are a professional summarizer. You are given a list of summaries of documents and you are asked to create a single summary of the documents.

================================ Human Message =================================

#Instructions: 
1. Extract main points from a list of summaries of documents
2. Make final summaries in bullet points format.
3. Answer should be written in {language}.

#Format: 
- summary 1
- summary 2
- summary 3
- ...

Here is a list of summaries of documents: 
{doc_summaries}

#SUMMARY:




# Create the reduce chain by combining the reduce prompt, LLM, and output parser
reduce_chain = reduce_prompt | llm | StrOutputParser()

# streaming using Reduce Chain
answer = reduce_chain.stream(
    {"doc_summaries": "\n".join(doc_summaries), # Combine summaries into a single string
     "language": "English"}
)
for chunk in answer:
    print(chunk, end="", flush = True)


##FUll Code of map reduce 

from langchain_core.runnables import chain
from langchain_openai import ChatOpenAI
from langchain import hub
from langchain_core.output_parsers import StrOutputParser

@chain  #makes any fn to Runnable 
def map_reduce_chain(docs):
    # Initialize the language model for the map stage
    map_llm = ChatOpenAI(
        temperature=0,
        model_name="gpt-4o-mini",
    )

    # Load the map prompt from the LangChain hub
    map_prompt = hub.pull("teddynote/map-prompt")

    # Create the map chain by combining the prompt, LLM, and output parser
    map_chain = map_prompt | map_llm | StrOutputParser()

    # Generate summaries for each document using batch processing
    doc_summaries = map_chain.batch(docs)

    # Load the reduce prompt from the LangChain hub
    reduce_prompt = hub.pull("teddynote/reduce-prompt")

    # Initialize the language model for the reduce stage with streaming enabled
    reduce_llm = ChatOpenAI(
        model_name="gpt-4o",
        temperature=0,
        callbacks=[StreamingCallback()],
        streaming=True,
    )

    # Create the reduce chain to combine document summaries into a final summary
    reduce_chain = reduce_prompt | reduce_llm | StrOutputParser()

    # Return the final summary by combining all document summaries
    return reduce_chain.invoke(
        {"doc_summaries": "\n".join(doc_summaries), "language": "English"}
    )

# print result
answer = map_reduce_chain.invoke(docs)

##Alternate implementation based on MapReduceDocumentsChain 
It implements a map-reduce strategy over (potentially long) texts. 
The strategy is as follows:
    Split a text into smaller documents;
    Map a process onto the smaller documents;
    Reduce or consolidate the results of the process into a final result.
    
from langchain.chat_models import init_chat_model

llm = init_chat_model("gpt-4o-mini", model_provider="openai")

from langchain_core.documents import Document

documents = [
    Document(page_content="Apples are red", metadata={"title": "apple_book"}),
    Document(page_content="Blueberries are blue", metadata={"title": "blueberry_book"}),
    Document(page_content="Bananas are yelow", metadata={"title": "banana_book"}),
]
    
from langchain.chains import MapReduceDocumentsChain, ReduceDocumentsChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
from langchain.chains.llm import LLMChain
from langchain_core.prompts import ChatPromptTemplate
from langchain_text_splitters import CharacterTextSplitter

# Map
map_template = "Write a concise summary of the following: {docs}."
map_prompt = ChatPromptTemplate([("human", map_template)])
map_chain = LLMChain(llm=llm, prompt=map_prompt)


# Reduce
reduce_template = """
The following is a set of summaries:
{docs}
Take these and distill it into a final, consolidated summary
of the main themes.
"""
reduce_prompt = ChatPromptTemplate([("human", reduce_template)])
reduce_chain = LLMChain(llm=llm, prompt=reduce_prompt)


# Takes a list of documents, combines them into a single string, and passes this to an LLMChain
combine_documents_chain = StuffDocumentsChain(
    llm_chain=reduce_chain, document_variable_name="docs"
)

# Combines and iteratively reduces the mapped documents
reduce_documents_chain = ReduceDocumentsChain(
    # This is final chain that is called.
    combine_documents_chain=combine_documents_chain,
    # If documents exceed context for `StuffDocumentsChain`
    collapse_documents_chain=combine_documents_chain,
    # The maximum number of tokens to group documents into.
    token_max=1000,
)

# Combining documents by mapping a chain over them, then combining results
map_reduce_chain = MapReduceDocumentsChain(
    # Map chain
    llm_chain=map_chain,
    # Reduce chain
    reduce_documents_chain=reduce_documents_chain,
    # The variable name in the llm_chain to put the documents in
    document_variable_name="docs",
    # Return the results of the map steps in the output
    return_intermediate_steps=False,
)
result = map_reduce_chain.invoke(documents)

print(result["output_text"])
    
##Full code for Map-Refine 
The Map-Refine method is another approach for document summarization, similar to Map-Reduce 
but with some key differences in how summaries are processed and combined.

    Map Stage:
        The document is divided into multiple smaller chunks.
        Each chunk is independently summarized.

    Refine Stage:
        The generated summaries are processed sequentially.
        In each iteration, the previous summary is combined with the next chunk's information to update and refine the summary.

    Iterative Process:
        The refine stage continues iteratively until all chunks have been processed.
        Each iteration enhances the summary by incorporating more information 
        while retaining previously captured details.

    Final Summary:
        Once all chunks have been processed, the final summary is obtained after the last refinement step.

from langchain_core.runnables import chain
from langchain import hub
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser

@chain
def map_refine_chain(docs):
    
    # 1. Map Phase (Initial Summarization)
    
    # Load the predefined map-summary prompt from LangChain Hub
    map_summary = hub.pull("teddynote/map-summary-prompt")

    # Create the map chain combining the prompt, language model, and output parser
    map_chain = (
        map_summary
        | ChatOpenAI(
            model_name="gpt-4o-mini",
            temperature=0,  # Set deterministic output for consistency
        )
        | StrOutputParser()
    )

    # Prepare the input documents with a language specification for batch processing
    input_doc = [{"documents": doc.page_content, "language": "English"} for doc in docs]

    # Generate initial summaries for all document chunks using batch processing
    doc_summaries = map_chain.batch(input_doc)

    # 2. Refine Phase (Progressive Refinement)
    
    # Load the predefined refine prompt from LangChain Hub
    refine_prompt = hub.pull("teddynote/refine-prompt")
    
    # Initialize the language model for the refine phase with streaming enabled
    refine_llm = ChatOpenAI(
        model_name="gpt-4o-mini",
        temperature=0,
        callbacks=[StreamingCallback()],  # Enables real-time streaming of outputs
        streaming=True,
    )

    # Create the refine chain combining the prompt, language model, and output parser
    refine_chain = refine_prompt | refine_llm | StrOutputParser()

    # Use the first generated summary as the starting point for the refinement process
    previous_summary = doc_summaries[0]

    # Sequentially refine the summary by incorporating new document chunks
    for current_summary in doc_summaries[1:]:
        previous_summary = refine_chain.invoke(
            {
                "previous_summary": previous_summary,  # Carry forward the latest refined summary
                "current_summary": current_summary,    # Add the next chunk's summary for refinement
                "language": "English",
            }
        )
        # Print a separator for clarity between iterations
        print("\n-----------------\n")

    # Return the final, most refined summary
    return previous_summary

Note About the Output:
    Clarity: The output progressively becomes clearer and more cohesive.
    Sequential Summarization: The results build on previous iterations.

Check the output below to see how the summaries evolve through each refinement step.

# Execute the map_refine_chain and generate the final refined summary
refined_summary = map_refine_chain.invoke(docs[:3])

##Understanding Map-Refine prompts 
# Create map chain 
map_summary = hub.pull("teddynote/map-summary-prompt")

# print prompt
map_summary.pretty_print()

================================ System Message ================================

You are an expert summarizer. Your task is to summarize the following document in {language}.

================================ Human Message =================================

Extract most important main thesis from the documents, then summarize in bullet points.

#Format:
- summary 1
- summary 2
- summary 3
-...

Here is a given document: 
{documents}

Write 1~5 sentences. Think step by step.
#Summary:




# Downlod refine prompt 
refine_prompt = hub.pull("teddynote/refine-prompt")

# print the prompt
refine_prompt.pretty_print()

================================ System Message ================================

You are an expert summarizer.

================================ Human Message =================================

Your job is to produce a final summary

We have provided an existing summary up to a certain point:
{previous_summary}

We have the opportunity to refine the existing summary(only if needed) with some more context below.
------------
{current_summary}
------------
Given the new context, refine the original summary in {language}.
If the context isn't useful, return the original summary.

##Alternate Implementation with RefineDocumentsChain

from langchain.chains import RefineDocumentsChain, LLMChain
from langchain_core.prompts import PromptTemplate
from langchain_community.llms import OpenAI

# This controls how each document will be formatted. Specifically,
# it will be passed to `format_document` - see that function for more
# details.
document_prompt = PromptTemplate(
    input_variables=["page_content"],
     template="{page_content}"
)
document_variable_name = "context"
llm = OpenAI()
# The prompt here should take as an input variable the
# `document_variable_name`
prompt = PromptTemplate.from_template(
    "Summarize this content: {context}"
)
initial_llm_chain = LLMChain(llm=llm, prompt=prompt)
initial_response_name = "prev_response"
# The prompt here should take as an input variable the
# `document_variable_name` as well as `initial_response_name`
prompt_refine = PromptTemplate.from_template(
    "Here's your first summary: {prev_response}. "
    "Now add to it based on the following context: {context}"
)
refine_llm_chain = LLMChain(llm=llm, prompt=prompt_refine)
chain = RefineDocumentsChain(
    initial_llm_chain=initial_llm_chain,
    refine_llm_chain=refine_llm_chain,
    document_prompt=document_prompt,
    document_variable_name=document_variable_name,
    initial_response_name=initial_response_name,
)


##Chain of Density (CoD)
    Paper: From Sparse to Dense

The Chain of Density (CoD) prompt is a technique developed to improve summary generation using GPT-4.

This method begins by generating an initial summary with minimal entities and then progressively incorporates 
missing key entities without increasing the summary's length. Studies have shown that summaries generated 
using CoD are more abstract, better at information fusion, and achieve a density similar to human-written 
summaries compared to standard prompts.


Input Parameter
    content_category : The type of content being summarized 
    (e.g., article, video transcript, blog post, research paper). Default: Article

    content: The content to be summarized.

    entity_range: The range of entities to be selected from the content and included in the summary. 
    Default: 1-3

    max_words: The maximum number of words included in the summary per iteration. Default: 80

    iterations: The number of entity densification rounds. The total number of summaries generated will be 
    iterations + 1. For an 80-word summary, 3 rounds are ideal. For longer summaries, 4-5 rounds may be 
    suitable, and adjusting the entity_range (e.g., 1-4) can further optimize the results. Default: 3

The code below creates a summarization chain using the Chain of Density (CoD) prompt, 
designed to progressively enhance the summary by increasing entity density 
while keeping the summary length constant.
    First Chain: Displays intermediate results after each iteration.
    Second Chain: Extracts only the final summary after all iterations.

# Download Chain of Density Prompt
cod_prompt = hub.pull("teddynote/chain-of-density-prompt")

cod_prompt.pretty_print()



================================ System Message ================================

As an expert copy-writer, you will write increasingly concise, entity-dense summaries of the user provided {content_category}. The initial summary should be under {max_words} words and contain {entity_range} informative Descriptive Entities from the {content_category}.

A Descriptive Entity is:
- Relevant: to the main story.
- Specific: descriptive yet concise (5 words or fewer).
- Faithful: present in the {content_category}.
- Anywhere: located anywhere in the {content_category}.

# Your Summarization Process
- Read through the {content_category} and the all the below sections to get an understanding of the task.
- Pick {entity_range} informative Descriptive Entities from the {content_category} (";" delimited, do not add spaces).
- In your output JSON list of dictionaries, write an initial summary of max {max_words} words containing the Entities.
- You now have `[{"missing_entities": "...", "denser_summary": "..."}]`

Then, repeat the below 2 steps {iterations} times:

- Step 1. In a new dict in the same list, identify {entity_range} new informative Descriptive Entities from the {content_category} which are missing from the previously generated summary.
- Step 2. Write a new, denser summary of identical length which covers every Entity and detail from the previous summary plus the new Missing Entities.

A Missing Entity is:
- An informative Descriptive Entity from the {content_category} as defined above.
- Novel: not in the previous summary.

# Guidelines
- The first summary should be long (max {max_words} words) yet highly non-specific, containing little information beyond the Entities marked as missing. Use overly verbose language and fillers (e.g., "this {content_category} discusses") to reach ~{max_words} words.
- Make every word count: re-write the previous summary to improve flow and make space for additional entities.
- Make space with fusion, compression, and removal of uninformative phrases like "the {content_category} discusses".
- The summaries should become highly dense and concise yet self-contained, e.g., easily understood without the {content_category}.
- Missing entities can appear anywhere in the new summary.
- Never drop entities from the previous summary. If space cannot be made, add fewer new entities.
- You're finished when your JSON list has 1+{iterations} dictionaries of increasing density.

# IMPORTANT
- Remember, to keep each summary to max {max_words} words.
- Never remove Entities or details. Only add more from the {content_category}.
- Do not discuss the {content_category} itself, focus on the content: informative Descriptive Entities, and details.
- Remember, if you're overusing filler phrases in later summaries, or discussing the {content_category} itself, not its contents, choose more informative Descriptive Entities and include more details from the {content_category}.
- Answer with a minified JSON list of dictionaries with keys "missing_entities" and "denser_summary".
- "denser_summary" should be written in the same language as the "content".

## Example output
[{"missing_entities": "ent1;ent2", "denser_summary": "<vague initial summary with entities 'ent1','ent2'>"}, {"missing_entities": "ent3", "denser_summary": "denser summary with 'ent1','ent2','ent3'"}, ...]

================================ Human Message =================================

{content_category}:
{content}



#Code 

import textwrap
from langchain import hub
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import SimpleJsonOutputParser

# Default values for all inputs except {content}
cod_chain_inputs = {
    "content": lambda d: d.get("content"),
    "content_category": lambda d: d.get("content_category", "Article"),
    "entity_range": lambda d: d.get("entity_range", "1-3"),
    "max_words": lambda d: int(d.get("max_words", 80)),
    "iterations": lambda d: int(d.get("iterations", 5)),
}

# Load the Chain of Density prompt from LangChain Hub
cod_prompt = hub.pull("teddynote/chain-of-density-prompt")

# Create the Chain of Density processing chain
cod_chain = (
    cod_chain_inputs
    | cod_prompt
    | ChatOpenAI(temperature=0, model="gpt-4o-mini")
    | SimpleJsonOutputParser()
)

# Create a second chain that extracts only the final summary (non-streaming)
cod_final_summary_chain = cod_chain | (
    lambda output: output[-1].get(
        "denser_summary", 'Error: The key "denser_summary" is missing in the final dictionary.'
    )
)

Review the data to be summarized.

content = docs[1].page_content
print(content)



Partial JSON Streaming with Overwriting Chunks

The code below demonstrates how to perform partial JSON streaming where each streamed chunk is a list of JSON dictionaries with additional entities added progressively.

To avoid simply concatenating outputs and instead overwrite previous chunks with each update, a carriage return (\r) is used.

import textwrap

# Initialize an empty list to store results
results: list[dict[str, str]] = []

# Execute the CoD chain in streaming mode and process partial JSON results
for partial_json in cod_chain.stream(
    {"content": content, "content_category": "Article"}
):
    # Update the results list with the latest streamed chunk
    results = partial_json

    # Print the updated results on the same line, overwriting the previous output
    print(results, end="\r", flush=True)

# Calculate the total number of generated summaries
total_summaries = len(results)
print("\n")  # Newline for better separation

# Loop through each summary and process the results
i = 1
for cod in results:
    # Extract and format the missing entities from the summary
    added_entities = ", ".join(
        [
            ent.strip()
            for ent in cod.get(
                "missing_entities", 'ERR: "missing_entities" key not found'
            ).split(";")
        ]
    )

    # Retrieve the denser summary
    summary = cod.get("denser_summary", 'ERR: missing key "denser_summary"')

    # Print summary information including order, total count, and added entities
    print(
        f"### CoD Summary {i}/{total_summaries}, Added Entities: {added_entities}\n"
    )

    # Print the summary with line wrapping at 80 characters for readability
    print(textwrap.fill(summary, width=80) + "\n")
    i += 1

# Print the final summary
print("\n============== [Final Summary] =================\n")
print(summary)



###ADVANCED:Personal Prompts for LangChain
This cookbook contains a comprehensive collection of specialized prompts designed 
for various professional domains using LangChain. 

The prompts are crafted to leverage the power of large language models while maintaining domain expertise 
and professional standards.

To use them, check example 
https://github.com/LangChain-OpenTutorial/LangChain-OpenTutorial/blob/main/14-Chains/01-Summary.ipynb


reference 
"- [Prompt Engineering Guide: Gemini](https://www.promptingguide.ai/models/gemini)\n",
"- [Google: Prompting Guide 101](https://services.google.com/fh/files/misc/gemini-for-google-workspace-prompting-guide-101.pdf)\n",
"- [Anthropic: Prompt Engineering - Use XML tags to structure your prompts\n",
"](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/use-xml-tags)\n",
"- [Anthropic: Prompt engineering overview](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview)\n",
"- [Anthropic: Anthropic's Prompt Engineering Interactive Tutorial](https://docs.google.com/spreadsheets/d/19jzLgRruG9kjUQNKtCg1ZjdD6l6weA6qRXG5zLIAhC8/edit?gid=1733615301#gid=1733615301)\n",
"- [Github: prompt-eng-interactive-tutorial](https://github.com/anthropics/prompt-eng-interactive-tutorial)\n",
"- [The Decoder: Chat GPT Guide](https://the-decoder.com/chatgpt-guide-prompt-strategies/)\n",
"- [Dorik: How to Write Prompts for ChatGPT (with Examples)](https://dorik.com/blog/how-to-write-prompts-for-chatgpt)\n",
"- [Coursera: How To Write ChatGPT Prompts: Your 2025 Guide](https://www.coursera.org/articles/how-to-write-chatgpt-prompts)\n",
"- [LangSmith: Prompt Hub](https://docs.smith.langchain.com/old/hub/dev-setup)\n",


Model Comparison at a Glance:
Feature 	ChatGPT 	
                Claude 	
                    Gemini
Strengths 	Conversational, logical reasoning 	
                Handles structured formats, logical responses 	
                        Works well with detailed tasks and examples
Best Practice 	Clear, focused prompts 	
                    XML-style structured prompts 	
                        Detailed instructions and examples
Example Use Case 	Writing emails, casual conversations 	
                        Analytical tasks, structured outputs 	
                            Summaries, detailed reports, multimodal tasks

By following these tailored tips, you can maximize the strengths of each model 
and achieve optimal performance in your LangChain projects.

1. ChatGPT (OpenAI's GPT-4)
ChatGPT is a powerful language model known for its conversational ability and logical reasoning.

  Prompt Tips:
    Keep it Clear and Focused: Clearly define what you want the model to do. 
        Don’t overload it with too much background information.
    Ask for a Specific Format: If you need the response in bullet points, 
        tables, or paragraphs, mention it.
    Assign a Role: Tell ChatGPT who it is (e.g., "You are a project manager") 
        to get more tailored answers.

# Example Prompt for GPT4
"You are a professional email writer. 
Write a polite email to a client informing them of a project delay of one month 
due to supply chain issues. The tone should be apologetic but confident."


2. Claude (Anthropic's Model)
Claude excels in structured thinking and understanding detailed tasks. 
It often works well with XML-style formatting for prompts.

    Prompt Tips:
    Use Structured Formats: Use XML tags to organize the instructions, 
        which helps Claude interpret them better.
    Provide Context and Examples: 
        Add a clear task and examples to guide the model's response.

# Example Prompt for Claude
"""
<context>
  <project>
    <name>Website Redesign</name>
    <deadline>March 15, 2025</deadline>
  </project>
</context>
<instructions>
  Write an email to the client explaining the project will be delayed by one month due 
  to supply chain issues. Apologize and propose a new deadline.
</instructions>
<example>
  Dear [Client Name],

  Due to supply chain challenges, we regret to inform you that the project will be delayed. 
  The new expected completion date is April 15, 2025. 
  We apologize for the inconvenience and appreciate your understanding.

  Best regards,
  [Your Name]
</example>
"""

3. Gemini (Google’s AI Model)
Gemini is a cutting-edge multimodal AI designed to work across text, images, and other data types. 
It handles detailed and structured tasks effectively.

    Prompt Tips:
    Be Detailed and Specific: Clearly explain the task and provide any necessary background details.
    Break Complex Tasks into Steps: If the task is complicated, split it into smaller, sequential steps.
    Add Examples: Providing examples helps Gemini align its output with your expectations.

# Exmple Prompt for Gemini
"You are a marketing strategist. Write a 200-word summary of the key milestones achieved in a 
project, emphasizing the team’s performance and results. Use a professional tone."

##Basic Prompts
The Basic Prompts chapter covers summarization tasks that are most commonly used across all domains. 
These prompts can be used individually or combined in a pipeline:

    Sequential Processing

    documents -> Summary Prompt -> Map Prompt -> Reduce Prompt -> Final Output

    Parallel Processing

    documents -> Multiple Summary Prompts (parallel)
             -> Map Prompts (parallel)
             -> Single Reduce Prompt
             -> Final Output

    Hybrid Processing

    documents -> Summary Prompt
             -> Map Prompt (for themes)
             -> Reduce Prompt (for final synthesis)
             -> Additional Summary Prompt (for final polish)

1. Summary Prompt

The Summary Prompt is designed to create concise, informative summaries of documents 
while maintaining key information and context.

PROMPT_OWNER = "eun"

from langchain import hub
from langchain.prompts import PromptTemplate

# Let's upload the prompt to the LangChain Hub.
# Don't forget to enter the LangSmith API as an environment variable.
prompt_title = "summarize_document"

summarize_prompt = """
Please summarize the sentence according to the following REQUEST.
REQUEST:
1. Summarize the main points in bullet points.
2. Each summarized sentence must start with an emoji that fits the meaning of the each sentence.
3. Use various emojis to make the summary more interesting.
4. DO NOT include any unnecessary information.

CONTEXT:
{context}

SUMMARY:"
"""
prompt = PromptTemplate.from_template(summarize_prompt)
prompt
#PromptTemplate(input_variables=['context'], input_types={}, partial_variables={}, template='\nPlease summarize the sentence according to the following REQUEST.\nREQUEST:\n1. Summarize the main points in bullet points.\n2. Each summarized sentence must start with an emoji that fits the meaning of the each sentence.\n3. Use various emojis to make the summary more interesting.\n4. DO NOT include any unnecessary information.\n\nCONTEXT:\n{context}\n\nSUMMARY:"\n')

# To upload a prompt to Hub:
#
# Private Repository:
# - Simply pass the prompt title as the first argument
# hub.push(prompt_title, prompt, new_repo_is_public=False)
#
# Public Repository:
# - First create a Hub Handle at LangSmith (smith.langchain.com)
# - Include your handle in the prompt title path
# hub.push(f"{PROMPT_OWNER}/{prompt_title}", prompt, new_repo_is_public=True)

hub.push(f"{PROMPT_OWNER}/{prompt_title}", prompt, new_repo_is_public=True)

'https://smith.langchain.com/prompts/summarize_document/129da0ee?organizationId=f2bffb3c-dd45-53ac-b23b-5d696451d11c'

You can find the uploaded prompt in your LangSmith. Please go to the site address as output.

# You can import and use prompts as follows.
prompt = hub.pull("eun/summarize_document:129da0ee")
prompt


2. Map Prompt
The Map Prompt is used to extract and organize main themes from documents, 
creating a structured representation of the content.

from langchain import hub
from langchain.prompts import PromptTemplate

prompt_title = "map-prompt"

map_prompt = """
You are a helpful expert journalist in extracting the main themes from a GIVEN DOCUMENTS below.
Please provide a comprehensive summary of the GIVEN DOCUMENTS in numbered list format.
The summary should cover all the key points and main ideas presented in the original text, while also condensing the information into a concise and easy-to-understand format.
Please ensure that the summary includes relevant details and examples that support the main ideas, while avoiding any unnecessary information or repetition.
The length of the summary should be appropriate for the length and complexity of the original text, providing a clear and accurate overview without omitting any important information.

GIVEN DOCUMENTS:
{docs}

FORMAT:
1. main theme 1
2. main theme 2
3. main theme 3
...

CAUTION:
- DO NOT list more than 5 main themes.

Helpful Answer:
"""
prompt = PromptTemplate.from_template(map_prompt)
prompt

hub.push(prompt_title, prompt, new_repo_is_public=False)


3. Reduce Prompt

The Reduce Prompt combines and synthesizes multiple summaries into a single, 
coherent output, particularly useful for processing large document sets.

from langchain import hub
from langchain.prompts import PromptTemplate

prompt_title = "reduce-prompt"

reduce_prompt = """
You are a helpful expert in summary writing.
You are given numbered lists of summaries.
Extract top 10 most important insights and create a unified summary.

LIST OF SUMMARIES:
{doc_summaries}

REQUIREMENTS:
1. Identify key insights across summaries
2. Maintain coherence and flow
3. Eliminate redundancy
4. Preserve important details
5. Create a unified narrative

OUTPUT FORMAT:
1. Main insights (bullet points)
2. Synthesized summary
3. Key takeaways
"""
prompt = PromptTemplate.from_template(reduce_prompt)
prompt


hub.push(prompt_title, prompt, new_repo_is_public=False)
'https://smith.langchain.com/prompts/reduce-prompt/17ed176f?organizationId=f2bffb3c-dd45-53ac-b23b-5d696451d11c'

##Advanced Prompts
The Advanced Prompts chapter explores sophisticated techniques that enhance the quality 
and specificity of language model outputs. These prompts are designed to handle complex tasks 
requiring deeper analysis and more nuanced responses.

##Advanced Prompts -  Chain of Density Summarization
Chain of Density Summarization iteratively refines summaries to achieve higher information density 
while maintaining readability and key insights.

from langchain import hub
from langchain.prompts import PromptTemplate

prompt_title = "chain-of-density"

chain_density_prompt = """
Given the input text, generate increasingly dense summaries through the following steps:

INPUT PARAMETERS:
- Text: {text}
- Iteration Count: {iterations}
- Target Length: {length}

PROCESS:
1. Initial Summary
2. Entity Identification
3. Density Enhancement
4. Quality Check

OUTPUT REQUIREMENTS:
1. Maintain consistent length
2. Increase information density
3. Preserve key entities
4. Ensure readability

Please provide the summary following this structure:

FORMAT:
{
    "initial_summary": str,
    "entity_map": list,
    "refined_summaries": list,
    "final_summary": str
}
"""

prompt = PromptTemplate.from_template(chain_density_prompt)

hub.push(prompt_title, prompt, new_repo_is_public=False)



##Advanced Prompts - Chain of Density Map (Multilingual)

Create mapped summaries with increasing density in any specified language, focusing on key entity extraction and relationship mapping.

from langchain import hub
from langchain.prompts import ChatPromptTemplate

prompt_title = "chain-of-density-map-multilingual"

chain_density_map_multilingual = """
Article: {ARTICLE}
Language: {LANGUAGE}

You will generate increasingly concise, entity-dense summaries of the above article in the specified language.

Repeat the following 2 steps 3 times.

Step 1. Identify 1-3 informative entities (";" delimited) from the article which are missing from the previous summary.
Step 2. Write a new, denser summary of identical length covering all previous entities plus new ones.

A missing entity is:
- relevant to the main story,
- specific yet concise (100 words or fewer),
- novel (not in the previous summary),
- faithful (present in the article),
- anywhere (can be located anywhere in the article).

Guidelines:
- First summary: 8-10 sentences (~200 words), non-specific with fillers
- Optimize word usage and improve flow
- Remove uninformative phrases
- Maintain density and self-containment
- Preserve all previous entities

OUTPUT FORMAT:
Text format for "Missing Entities" and "Denser_Summary"

Provide the output in the specified language: {LANGUAGE}
"""

prompt = ChatPromptTemplate.from_template(chain_density_map_multilingual)

# Usage Example:
response_map = chain_density_map_multilingual.format(
    ARTICLE="Your article text here", LANGUAGE="Japanese"  # or any other language
)

##Advanced Prompts - Key Information Extraction

Extract and structure critical information from various document types with high precision and consistency.

from langchain import hub
from langchain.prompts import PromptTemplate

prompt_title = "key-information-extraction"

extraction_prompt = """
Extract key information from the provided document according to these specifications:

INPUT:
- Document: {document}
- Target Fields: {fields}
- Context Requirements: {context}

EXTRACTION REQUIREMENTS:
1. Identify specified data points
2. Maintain contextual relationships
3. Validate extracted information
4. Format according to schema

OUTPUT FORMAT:
{
    "extracted_data": dict,
    "confidence_scores": dict,
    "validation_results": dict,
    "metadata": dict
}
"""

prompt = PromptTemplate.from_template(extraction_prompt)
hub.push(prompt_title, prompt, new_repo_is_public=False)

##Advanced Prompts - Metadata Tagging

Automatically generate relevant tags and metadata to enhance content organization and searchability.

from langchain import hub
from langchain.prompts import PromptTemplate

prompt_title = "metadata-tagger"

metadata_prompt = """
Generate comprehensive metadata tags for the given content:

CONTENT PARAMETERS:
- Type: {content_type}
- Domain: {domain}
- Context: {context}

TAGGING REQUIREMENTS:
1. Generate relevant tags
2. Create hierarchical categories
3. Identify key topics
4. Map relationships
5. Optimize for search

OUTPUT FORMAT:
{
    "primary_tags": list,
    "categories": dict,
    "relationships": dict,
    "search_terms": list
}
"""

prompt = PromptTemplate.from_template(metadata_prompt)
hub.push(prompt_title, prompt, new_repo_is_public=False)

'https://smith.langchain.com/prompts/metadata-tagger/9bf50dec?organizationId=f2bffb3c-dd45-53ac-b23b-5d696451d11c'

##Advanced Prompts -  RAG Document Analysis

Process and answer questions based on retrieved document contexts with high accuracy and relevance.

from langchain import hub
from langchain.prompts import ChatPromptTemplate

prompt_title = "rag-document-analysis"

system = """You are a precise and helpful AI assistant specializing in question-answering tasks based on provided context.
Your primary task is to:
1. Analyze the provided context thoroughly
2. Answer questions using ONLY the information from the context
3. Preserve technical terms and proper nouns exactly as they appear
4. If the answer cannot be found in the context, respond with: 'The provided context does not contain information to answer this question.'
5. Format responses in clear, readable paragraphs with relevant examples when available
6. Focus on accuracy and clarity in your responses
"""

human = """#Question:
{question}

#Context:
{context}

#Answer:
Please provide a focused, accurate response that directly addresses the question using only the information from the provided context."""

prompt = ChatPromptTemplate.from_messages([("system", system), ("human", human)])

prompt

ChatPromptTemplate(input_variables=['context', 'question'], input_types={}, partial_variables={}, messages=[SystemMessagePromptTemplate(prompt=PromptTemplate(input_variables=[], input_types={}, partial_variables={}, template="You are a precise and helpful AI assistant specializing in question-answering tasks based on provided context.\nYour primary task is to:\n1. Analyze the provided context thoroughly\n2. Answer questions using ONLY the information from the context\n3. Preserve technical terms and proper nouns exactly as they appear\n4. If the answer cannot be found in the context, respond with: 'The provided context does not contain information to answer this question.'\n5. Format responses in clear, readable paragraphs with relevant examples when available\n6. Focus on accuracy and clarity in your responses\n"), additional_kwargs={}), HumanMessagePromptTemplate(prompt=PromptTemplate(input_variables=['context', 'question'], input_types={}, partial_variables={}, template='#Question:\n{question}\n\n#Context:\n{context}\n\n#Answer:\nPlease provide a focused, accurate response that directly addresses the question using only the information from the provided context.'), additional_kwargs={})])

hub.push(prompt_title, prompt, new_repo_is_public=False)

'https://smith.langchain.com/prompts/rag-document-analysis/f7a42fa8?organizationId=f2bffb3c-dd45-53ac-b23b-5d696451d11c'

##Advanced Prompts - RAG with Source Attribution

Enhanced RAG implementation with detailed source tracking and citation for improved accountability and verification.

from langchain import hub
from langchain.prompts import ChatPromptTemplate

prompt_title = "rag-with-sources"

system = """You are a precise and thorough AI assistant that provides well-documented answers with source attribution.
Your responsibilities include:
1. Analyzing provided context thoroughly
2. Generating accurate answers based solely on the given context
3. Including specific source references for each key point
4. Preserving technical terminology exactly as presented
5. Maintaining clear citation format [source: page/document]
6. If information is not found in the context, state: 'The provided context does not contain information to answer this question.'

Format your response as:
1. Main Answer
2. Sources Used (with specific locations)
3. Confidence Level (High/Medium/Low)"""

human = """#Question:
{question}

#Context:
{context}

#Answer:
Please provide a detailed response with source citations using only information from the provided context."""

prompt = ChatPromptTemplate.from_messages([("system", system), ("human", human)])
PROMPT_OWNER = "eun"
hub.push(f"{PROMPT_OWNER}/{prompt_title}", prompt, new_repo_is_public=True)

'https://smith.langchain.com/prompts/rag-with-sources/67246bf3?organizationId=f2bffb3c-dd45-53ac-b23b-5d696451d11c'

##Advanced Prompts - LLM Response Evaluation

Comprehensive evaluation of LLM responses based on multiple quality metrics with detailed scoring methodology.

from langchain import hub
from langchain.prompts import PromptTemplate

prompt_title = "llm-response-evaluation"

evaluation_prompt = """Evaluate the LLM's response based on the following criteria:

INPUT:
Question: {question}
Context: {context}
LLM Response: {answer}

EVALUATION CRITERIA:
1. Accuracy (0-10)
- Perfect (10): Completely accurate, perfectly aligned with context
- Good (7-9): Minor inaccuracies
- Fair (4-6): Some significant inaccuracies
- Poor (0-3): Major inaccuracies or misalignment

2. Completeness (0-10)
- Perfect (10): Comprehensive coverage of all relevant points
- Good (7-9): Covers most important points
- Fair (4-6): Missing several key points
- Poor (0-3): Critically incomplete

3. Context Relevance (0-10)
- Perfect (10): Optimal use of context
- Good (7-9): Good use with minor omissions
- Fair (4-6): Partial use of relevant context
- Poor (0-3): Poor context utilization

4. Clarity (0-10)
- Perfect (10): Exceptionally clear and well-structured
- Good (7-9): Clear with minor issues
- Fair (4-6): Somewhat unclear
- Poor (0-3): Confusing or poorly structured

SCORING METHOD:
1. Calculate individual scores
2. Compute weighted average:
   - Accuracy: 40%
   - Completeness: 25%
   - Context Relevance: 25%
   - Clarity: 10%
3. Normalize to 0-1 scale

OUTPUT FORMAT:
{
    "individual_scores": {
        "accuracy": float,
        "completeness": float,
        "context_relevance": float,
        "clarity": float
    },
    "weighted_score": float,
    "normalized_score": float,
    "evaluation_notes": string
}

Return ONLY the normalized_score as a decimal between 0 and 1."""

prompt = PromptTemplate.from_template(evaluation_prompt)

##Advanced Prompts - Professional Domain Prompts
Each professional domain prompt is carefully crafted to address specific industry needs and requirements.

This part requires optimization of prompts, especially according to domain data and format. 
Therefore, it is recommended that you test multiple prompts with Playground on websites such as OpenAI 
or Anthropic and use the most appropriate prompts. Below is an example of prompts in each field.

1. Academic Research Analysis Prompt

PROMPT_TEMPLATE = """
As an expert academic researcher, analyze the academic content with:

INPUT:
- Content Type: {content_type}
- Field of Study: {field}
- Analysis Depth: {depth}

ANALYZE:
1. Research methodology and design
2. Key findings and significance
3. Theoretical framework
4. Statistical validity
5. Study limitations
6. Future directions

OUTPUT FORMAT:
{
    "executive_summary": str,
    "methodology_analysis": dict,
    "findings_analysis": dict,
    "quality_assessment": dict
}
"""

##Advanced Prompts - Clinical Case Analysis Prompt

PROMPT_TEMPLATE = """
As a medical professional, analyze clinical cases with:

INPUT:
- Patient Information: {patient_data}
- Clinical Notes: {clinical_notes}

PROVIDE:
1. Clinical Assessment
2. Diagnostic Process
3. Treatment Plan
4. Risk Assessment

OUTPUT FORMAT:
{
    "clinical_summary": str,
    "differential_diagnosis": list,
    "treatment_plan": dict,
    "risk_assessment": dict
}
"""

##Advanced Prompts - Market Research Analysis Prompt

PROMPT_TEMPLATE = """
As a market research analyst, analyze:

PARAMETERS:
- Industry: {industry}
- Market Segment: {segment}
- Region: {region}
- Time Period: {time_period}

COMPONENTS:
1. Market Overview
2. Competitive Analysis
3. Customer Analysis
4. SWOT Analysis
5. Financial Analysis
6. Recommendations

OUTPUT FORMAT:
{
    "market_overview": dict,
    "competitive_landscape": dict,
    "customer_insights": dict,
    "strategic_recommendations": list
}
"""

##Advanced Prompts - Educational Content Development Prompt

PROMPT_TEMPLATE = """
As an educational content developer, create:

PARAMETERS:
- Subject: {subject}
- Grade Level: {grade_level}
- Learning Objectives: {objectives}
- Duration: {duration}

DELIVER:
1. Course Structure
2. Learning Materials
3. Assessment Components
4. Differentiation Strategies
5. Support Resources

OUTPUT FORMAT:
{
    "course_outline": dict,
    "lesson_plans": list,
    "assessments": dict,
    "support_resources": dict
}
"""


###ADVANCED:Prompt for Agent
Unlike conventional prompts that focus on generating a single response, Agentic prompts include the use of 
tools and decision-making steps.

Agentic prompts can be described as a prompt structure designed to achieve purposes such as intelligent task 
processing (which autonomously breaks down complex goals into sub-steps and selects and utilizes the 
necessary tools for each step), adaptive learning systems (which evaluate intermediate results and reflect 
and remember them), and collaboration (which coordinates and mediates multiple agents).

##Basic Structure
The basic structure of agent prompts provides a foundation for task execution by incorporating agent 
roles and behavioral guidelines, state and memory management, and tool usage protocols.

                      +-------------------------------+
                      |        Agent Definition       |
                      |-------------------------------|
                      | - Role and Purpose           |
                      | - Behavioral Guidelines      |
                      | - Success Criteria           |
                      +-------------------------------+
                                   |
                                   v
+------------------------------------+    +-----------------------------+
|         State & Memory Management  |    |      Tool Integration       |
|------------------------------------|    |-----------------------------|
| - Working Memory                   |    | - Tool Selection            |
|   * Current Task Context           |    |   * Match tools to tasks    |
|   * Recent Interaction State       |    | - Execution Protocol        |
|   * Decision Queue                 |    |   * Validate inputs         |
|                                    |    |   * Monitor progress        |
| - Context Management               |    | - Result Processing         |
|   * Conversation Threading         |    |   * Validate outputs        |
|   * Knowledge Accumulation         |    +-----------------------------+
+------------------------------------+
                                   |
                                   v
                      +-------------------------------+
                      |  Intelligent Task Processing  |
                      |-------------------------------|
                      | - Break down complex goals    |
                      | - Select optimized tools      |
                      | - Adapt execution plans       |
                      +-------------------------------+

Agent Definition and Behavioral Guidelines

You are a specialized agent with the following identity and operational parameters:

Identity:
- Role: [Specific role description]
- Domain: [Area of expertise]
- Purpose: [Primary objectives]
- Interaction Style: [Communication parameters]

Behavioral Guidelines:
- Primary Goals: [List of main objectives]
- Constraints: [Operational limitations]
- Success Criteria: [Expected outcomes]
- Decision Framework:
  - Evaluation Criteria: [Assessment standards]
  - Priority Rules: [Priority determination methods]
  - Escalation Triggers: [Conditions for higher-level decision requests]

Example Implementation::

identity:
  role: "Research Assistant"
  domain: "Academic Literature Analysis"
  purpose: "Conduct comprehensive literature reviews"
  style: "Analytical and systematic"

behavioral_guidelines:
  primary_goals:
    - "Analyze academic papers"
    - "Synthesize research findings"
    - "Generate structured reports"
  constraints:
    - "Use peer-reviewed sources only"
    - "Maintain academic writing standards"
  success_criteria:
    - "Comprehensive coverage of topic"
    - "Clear synthesis of findings"
  decision_framework:
    evaluation_criteria:
      - "Relevance to research topic"
      - "Credibility of sources"
    priority_rules:
      - "Address critical questions first"
      - "Organize findings by importance"
    escalation_triggers:
      - "Ambiguity in source reliability"
      - "Conflicting data points"

State and Memory Management

State and memory management are crucial components for maintaining task consistency and context preservation in agent operations.

    Working Memory

Maintain active awareness of the following:

Current Task Context:
- Active objective: [Current primary goal in progress]
- Task progress: [Step-by-step progress status]
- Pending actions: [Tasks awaiting execution]

Recent Interaction State:
- Last user input: [Most recent user instructions]
- Previous responses: [Content of immediate past responses]
- Current conversation flow: [Dialogue progression]

Decision Queue:
- Unresolved questions: [Pending decisions]
- Required validations: [Items requiring verification]
- Next steps: [Planned subsequent actions]

    Context Management

Maintain contextual awareness through:

Conversation Threading:
- Topic hierarchy: [Relationships between topics]
- Reference points: [Key reference markers]
- Context switches: [Points of context transition]

Knowledge Accumulation:
- Established facts: [Verified information]
- User preferences: [User-specific preferences]
- Important constraints: [Key limitations]

Memory Refresh Triggers:
- Key milestones: [Critical progress points]
- Critical updates: [Essential information updates]
- Context revalidation: [Points for context verification]

Example Implementation::

state_management:
  working_memory:
    current_task_context:
      active_objective: "Summarize findings from recent papers"
      task_progress: "50% completed"
      pending_actions:
        - "Review additional sources for gaps"

    recent_interaction_state:
      last_user_input: "Focus on studies published after 2020."
      previous_responses: ["Summarized findings from 5 papers."]
      current_conversation_flow: ["Discussing trends in recent studies."]

    decision_queue:
      unresolved_questions:
        - "Are there any contradictory findings?"
        - "What are the most cited papers?"
      required_validations:
        - "Verify source credibility."
        - "Check for duplicate data."

Tool Access and Usage Parameters

Available tools and usage guidelines:

Authorized Tools:
- List of accessible tools with descriptions
- Access levels and permissions
- Tool-specific constraints and limitations

Usage Protocols:
1. Verify task requirements and tool suitability
2. Select appropriate tools based on scope and constraints
3. Execute tools with validated parameters

Output Handling:
4. Validate results for accuracy and relevance
5. Update memory state with new insights
6. Format responses for clarity and consistency

Example Implementation::

tools:
  authorized_tools:
    - name: "academic_search"
      description: "Search academic databases for relevant papers"
      scope: "Public research databases only"
      access_level: "Full access"
    - name: "citation_manager"
      description: "Organize references and generate citations"
      scope: "APA, MLA, Chicago formats"
      access_level: "Standard access"

  usage_protocols:
    steps_to_execute_tool:
      - step_1: "Verify source credibility before using data"
      - step_2: "Ensure tool outputs align with task objectives"
      - step_3: "Document tool execution parameters"
  
  output_handling_rules:
    validation_steps:
      - step_1: "Check results for completeness"
      - step_2: "Cross-reference findings with existing data"
      - step_3: "Verify data consistency"
    response_formatting_steps:
      - step_1: "Summarize key insights clearly"
      - step_2: "Organize outputs in a structured format"
      - step_3: "Apply standardized formatting guidelines"

This structure helps the agent clearly understand its role and guidelines for action, efficiently manage its state and memory, and effectively utilize tools to perform tasks.
Agent Definition and Behavioral Guidelines

Agent definition and behavioral guidelines are designed to ensure that agents clearly understand their roles and responsibilities while providing consistent and reliable results during task execution. This framework enables agents to maintain balance between autonomy and constraints while performing tasks efficiently.
Identity Setup

You are an agent with these core characteristics:

Role and Purpose:
- Primary Function: "Research Assistant specializing in academic analysis"
- Key Objectives:
  - Conduct comprehensive literature reviews
  - Summarize key findings in a clear and concise format
  - Provide actionable insights based on data
- Success Criteria:
  - Deliver accurate and well-organized outputs
  - Meet deadlines for task completion
  - Maintain user satisfaction through clarity and relevance

Behavioral Parameters:
- Decision Making Style: "Evidence-based, systematic, and logical"
- Communication Protocol: "Professional, concise, and user-focused"
- Response Format: "Structured text with bullet points or tables as needed"

Domain Boundaries:
- Areas of Expertise: "Academic research, data analysis, report writing"
- Knowledge Limitations: "No access to proprietary or restricted databases"
- Required Consultations: "Seek user input for ambiguous or undefined tasks"

Operating Guidelines

Your operational scope is defined as follows:

Task Processing:
- Independent Actions:
  - Retrieve and analyze publicly available data
  - Generate summaries and insights without supervision
- Approval Required:
  - Accessing external APIs beyond predefined tools
  - Performing tasks outside the defined domain expertise
- Prohibited Actions:
  - Sharing sensitive or confidential information
  - Making decisions without sufficient data validation

Decision Framework:
- Evaluation Criteria:
  - Prioritize accuracy over speed when processing complex tasks
  - Ensure all outputs are verifiable and traceable to original sources
- Priority Rules:
  - Address time-sensitive tasks first while maintaining quality standards
  - Defer non-critical tasks if resources are constrained
- Escalation Triggers:
  - Escalate tasks if required inputs are missing or ambiguous
  - Notify the user of potential errors or conflicting objectives

Quality Standards:
- Accuracy Requirements:
  - Maintain a minimum accuracy threshold of 95% for factual information
- Verification Steps:
  - Cross-check outputs against multiple reliable sources
  - Validate calculations or data transformations before finalizing results
- Error Handling:
  - Retry failed operations up to three times with adjusted parameters
  - Log errors and provide detailed explanations for unresolved issues

Summary

This prompt structure ensures that agents:

    Role and Purpose Clarity: Agents understand their roles and objectives precisely and perform tasks accordingly.
    Behavioral Guidelines: Provide consistent outputs through clear decision-making criteria and task processing protocols.
    Quality Control: Generate reliable results based on verified data and standards, with systematic responses to errors.

Through this framework, agents can build trust in user interactions and efficiently handle complex tasks while maintaining high standards of performance.
State and Memory Management

State and memory management are essential components that ensure task continuity and context preservation while generating accurate and consistent responses. The system requires systematic design of Working Memory and Context Management.
Working Memory

Working memory maintains and tracks information related to current tasks in real-time.

Maintain active awareness of the following:

Current Task Context:
- Active Objective: "Summarize the latest research on climate change."
- Task Progress: "Step 2 of 5 - Reviewing articles."
- Pending Actions: "Identify key findings from the next article."

Recent Interaction State:
- Last User Input: "Can you find more details on renewable energy?"
- Previous Responses: "I have summarized three articles on this topic."
- Current Conversation Flow: "You are discussing renewable energy's role in climate change."

Decision Queue:
- Unresolved Questions: "Should I include regional data?"
- Required Validations: "Verify the credibility of sources."
- Next Steps: "Compile data into a summary table."

Context Management

Context management maintains long-term conversation flow and task history, enabling agents to respond appropriately based on previous interactions and task outcomes.

Maintain contextual awareness through:

Conversation Threading:
- Topic Hierarchy: 
  - Main Topic: "Climate Change"
  - Subtopics: ["Renewable Energy", "Carbon Emissions"]
- Reference Points: 
  - "In the last summary, you mentioned solar energy's impact."
  - "User prefers concise bullet points for summaries."
- Context Switches:
  - From: "General climate change overview"
  - To: "Specific focus on renewable energy."

Knowledge Accumulation:
- Established Facts:
  - "Solar and wind energy are leading renewable sources."
  - "Global temperatures have risen by 1.1°C since pre-industrial levels."
- User Preferences:
  - "Prefers visual data representations like charts."
  - "Requests detailed citations for all sources."
- Important Constraints:
  - "Avoid outdated studies published before 2015."

Memory Refresh Triggers:
- Key Milestones:
  - Completion of article reviews.
  - Finalizing the summary draft.
- Critical Updates:
  - New user input requesting additional focus areas.
  - Discovery of new, relevant research data.
- Context Revalidation:
  - After a significant topic switch.
  - At the start of a new task session.

Summary

This memory management system ensures:

    Task Continuity: Track current status and progress to maintain uninterrupted workflow
    Contextual Adaptability: Provide appropriate responses based on conversation flow and task history
    Information Utilization: Generate consistent and reliable results through effective reference to accumulated information

Tool Integration Framework

Tool integration is a critical component that enhances the efficiency and accuracy of agent operations. This section provides specific prompt guidelines for tool selection, execution, and result processing.
Tool Selection and Execution

Follow these guidelines for tool utilization:

Analysis Phase:
- Identify task requirements:
  - Example: "Determine if text analysis or numerical computation is required."
- Evaluate available tools:
  - Example: "Choose between 'TextAnalyzer' or 'DataProcessor' based on input type."
- Consider resource constraints:
  - Example: "Ensure tool execution fits within allocated memory and time limits."

Selection Criteria:
- Tool capability match:
  - Example: "Select tools that support JSON input for structured data."
- Performance requirements:
  - Example: "Prioritize tools with faster processing times for large datasets."
- Resource efficiency:
  - Example: "Avoid high-memory tools for lightweight tasks."

Execution Protocol:
- Parameter validation:
  - Example: "Verify input format matches tool specifications (e.g., CSV for data analysis)."
- Error handling:
  - Example: "Retry failed operations up to 3 times or escalate if unresolved."
- Progress monitoring:
  - Example: "Log execution status every 10% of task completion."

Result Processing

Handle tool outputs according to these steps:

Validation Framework:
- Output verification:
  - Example: "Check if output contains expected fields (e.g., 'summary', 'keywords')."
- Quality assessment:
  - Example: "Ensure numerical results have a precision of at least two decimal places."
- Consistency check:
  - Example: "Compare output format with predefined schema."

Integration Process:
- Result synthesis:
  - Example: "Combine outputs from multiple tools into a unified report."
- Context updating:
  - Example: "Incorporate new findings into the current task context."
- Memory management:
  - Example: "Store validated results in long-term memory for future reference."

Response Generation:
- Format selection:
  - Example: "Convert raw outputs into user-friendly formats like tables or charts."
- Clarity optimization:
  - Example: "Simplify complex data into concise summaries for better readability."
- Delivery preparation:
  - Example: "Prepare the final response in Markdown format for user presentation."

Summary

The tool integration framework enables agents to select appropriate tools for task requirements and systematically process results to generate reliable responses. The next section will cover Example Prompts demonstrating the practical application of this framework.
Example Prompts
Basic Agent Setup

You are an agent with the following setup:

Identity:
- Role: "LangChain Data Pipeline Agent"
- Domain: "Data Processing and Analysis"
- Purpose: "Orchestrate data processing workflows using LangChain/LangGraph"
- Interaction Style: "Systematic and process-oriented"

Behavioral Guidelines:
- Primary Goals:
  - Execute data processing pipelines
  - Manage workflow transitions
  - Handle errors and exceptions gracefully
- Constraints:
  - Operate within defined memory limits
  - Follow rate limiting guidelines
  - Maintain data privacy standards
- Success Criteria:
  - Complete pipeline execution within {timeout_seconds}
  - Achieve {minimum_accuracy}% accuracy in results
  - Maintain state consistency across transitions
- Decision Framework:
  - Evaluation Criteria: "Pipeline step completion status"
  - Priority Rules: "Critical path operations first"
  - Escalation Triggers: "Memory overflow or API failures"

Memory Management

state_management:
  working_memory:
    current_task_context:
      active_objective: "Process {dataset_name} through {pipeline_steps}"
      task_progress: "Step {current_step} of {total_steps}"
      pending_actions:
        - "Execute {next_transform_operation}"
        - "Validate {output_schema}"

    recent_interaction_state:
      last_pipeline_output: "{previous_step_result}"
      current_chain_state: "{chain_status}"
      active_nodes: ["{node_id_1}", "{node_id_2}"]

    decision_queue:
      validation_checks:
        - "Schema validation for {output_format}"
        - "Data type consistency for {field_names}"
      next_operations:
        - "Transform {input_data} using {transform_function}"

  context_management:
    conversation_threading:
      workflow_state:
        current_graph: "{graph_id}"
        active_chains: ["{chain_id_1}", "{chain_id_2}"]
      state_transitions:
        from_state: "{previous_state}"
        to_state: "{next_state}"
        trigger: "{transition_event}"

    knowledge_accumulation:
      pipeline_metrics:
        processing_time: "{execution_time_ms}"
        memory_usage: "{memory_mb}"
      error_history:
        recent_failures: ["{error_id}", "{error_type}"]

Tool Integration

tools:
  authorized_tools:
    - name: "langchain_loader"
      description: "Load and initialize LangChain components"
      parameters:
        model_name: "{llm_model_name}"
        temperature: "{temperature_value}"
    
    - name: "graph_executor"
      description: "Execute LangGraph workflow steps"
      parameters:
        graph_config: "{graph_definition}"
        max_steps: "{max_iterations}"

  execution_protocols:
    initialization:
      step_1:
        action: "Initialize LangChain environment"
        parameters:
          api_key: "{api_key}"
          cache_config: "{cache_settings}"
      
    workflow_execution:
      step_1:
        action: "Create processing nodes"
        parameters:
          node_configs: "{node_definitions}"
      step_2:
        action: "Execute graph workflow"
        parameters:
          input_data: "{input_format}"
          output_schema: "{expected_schema}"

  result_processing:
    validation_rules:
      data_quality:
        - check: "Schema validation"
          criteria: "{validation_schema}"
        - check: "Type consistency"
          criteria: "{type_definitions}"
    
    output_formatting:
      format_type: "{output_format}"
      template: "{response_template}"
      metadata:
        timestamp: "{execution_timestamp}"
        version: "{pipeline_version}"

This example structure demonstrates how to implement the guidelines specifically for LangChain/LangGraph applications, with placeholders for dynamic values that would be injected during runtime. The setup includes specific considerations for chain execution, graph state management, and tool integration patterns common in LangChain/LangGraph workflows.
Practical Examples

PROMPT_QUALITY_EVALUATION_TEMPLATE

PROMPT_QUALITY_EVALUATION_TEMPLATE = ChatPromptTemplate.from_messages([
    (
        "system",
        """### Task
You are a Prompt Quality Reviewer tasked with verifying the effectiveness of agent prompts.

### Content to Review
{prompt_content}

### Verification Steps
1. Agent Identity Clarity
   - Is the agent's role and purpose clearly defined?
   - Are behavioral guidelines specific and actionable?
   - Are domain boundaries well-established?

2. Memory Management Structure
   - Is the working memory framework comprehensive?
   - Is context management properly structured?
   - Are state transitions clearly defined?

3. Tool Integration Framework
   - Are tool selection criteria well-defined?
   - Is the execution protocol clear and complete?
   - Are result processing steps properly specified?

4. Implementation Feasibility
   - Are the prompts technically implementable?
   - Do they align with LangChain/LangGraph capabilities?
   - Are external parameters properly marked with {placeholders}?

5. Error Handling and Safety
   - Are error scenarios adequately addressed?
   - Are safety checks and validations included?
   - Are escalation procedures clearly defined?

### Return Format
\```
{{
  "score": <integer_between_0_and_100>,
  "feedback": {{
    "identity_clarity": "<specific_feedback>",
    "memory_management": "<specific_feedback>",
    "tool_integration": "<specific_feedback>",
    "implementation": "<specific_feedback>",
    "safety": "<specific_feedback>",
    "improvement_suggestions": [
      "<suggestion_1>",
      "<suggestion_2>",
      "<suggestion_3>"
    ]
  }},
  "validation_status": "PASS|FAIL|NEEDS_REVISION"
}}
\```

### Example Response
\```
{{
  "score": 85,
  "feedback": {{
    "identity_clarity": "Agent role and behavioral guidelines well defined, but success criteria could be more specific",
    "memory_management": "Comprehensive working memory structure, but needs clearer cleanup protocols",
    "tool_integration": "Tool selection framework is robust, but error handling could be more detailed",
    "implementation": "Compatible with LangChain patterns, proper parameter placeholders used",
    "safety": "Good basic error handling, but needs more specific validation steps",
    "improvement_suggestions": [
      "Add specific memory cleanup triggers",
      "Include more detailed error recovery procedures",
      "Specify maximum retry attempts for failed operations"
    ]
  }},
  "validation_status": "NEEDS_REVISION"
}}
\```"""
    ),
    ("human", "{generated_prompt}")
])

    Every instance of a literal { and } inside the JSON block is replaced with {{ and }} so that Python’s .format() does not try to substitute those.



AI_CAREER_PLANNER_AGENT_PROMPT

AI_CAREER_PLANNER_AGENT_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """You are a specialized agent with the following identity and operational parameters:

Identity:
- Role: AI Career Planning Specialist
- Domain: AI Research and Engineering Education
- Purpose: Create personalized AI career preparation plans for users.
- Interaction Style: Structured, supportive, and detail-oriented.

Behavioral Guidelines:
- Primary Goals:
  - Analyze the user's current skill gaps in AI/ML.
  - Recommend targeted and accessible learning resources.
  - Generate a realistic study timeline with clear milestones.
- Constraints:
  - Use only verified and accessible resources.
  - Consider available study time and user’s current skill level.
- Success Criteria:
  - Provide a clear progression path with measurable milestones.
  - Deliver recommendations that align with the user's profile.

Working Memory Management:
- Current Task Context:
  - Active objective: "Create a personalized AI career study plan."
  - Task progress: "Analyzing user input and preparing recommendations."
  - Pending actions: "Match resources and generate timeline."
- Recent Interaction:
  - Last user input: {input}
  - Conversation history: {history}

Tool Integration:
- Resource Recommender: To identify learning resources based on skill gaps.
- Timeline Generator: To build a structured study schedule.

Output Requirements:
- Response must be in Markdown with the following sections:
  1. Skill Gap Analysis
  2. Recommended Resources (with URLs)
  3. Study Timeline with milestones
  4. Next steps and progress tracking

Current Date: February 12, 2025
Relevant Information:
{history}
""",
        ),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{input}"),
    ]
)

###ADVANCED: WebBaseLoader
WebBaseLoader is a specialized document loader in LangChain designed for processing web-based content.

It leverages the BeautifulSoup4 library to parse web pages effectively, offering customizable parsing options through SoupStrainer and additional bs4 parameters.


WebBaseLoader is a loader designed for loading web-based documents.

It uses the bs4 library to parse web pages.

Key Features:
    Uses bs4.SoupStrainer to specify elements to parse.
    Accepts additional arguments for bs4.SoupStrainer through the bs_kwargs parameter.

For more details, refer to the API documentation.

import bs4
from langchain_community.document_loaders import WebBaseLoader

# Load news article content using WebBaseLoader
loader = WebBaseLoader(
   web_paths=("https://techcrunch.com/2024/12/28/google-ceo-says-ai-model-gemini-will-the-companys-biggest-focus-in-2025/",),
   # Configure BeautifulSoup to parse only specific div elements
   bs_kwargs=dict(
       parse_only=bs4.SoupStrainer(
           "div",
           attrs={"class": ["entry-content wp-block-post-content is-layout-constrained wp-block-post-content-is-layout-constrained"]},
       )
   ),
   # Set user agent in request header to mimic browser
   header_template={
       "User_Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
   },
)

# Load and process the documents
docs = loader.load()
print(f"Number of documents: {len(docs)}")
docs[0]

Number of documents: 1

Document(metadata={'source': 'https://techcrunch.com/2024/12/28/google-ceo-says-ai-model-gemini-will-the-companys-biggest-focus-in-2025/'}, page_content='\nCEO Sundar Pichai reportedly told Google employees that 2025 will be a “critical” year for the company.\nCNBC reports that it obtained audio from a December 18 strategy meeting where Pichai and other executives put on ugly holiday sweaters and laid out their priorities for the coming year.\n\n\n\n\n\n\n\n\n“I think 2025 will be critical,” Pichai said. “I think it’s really important we internalize the urgency of this moment, and need to move faster as a company. The stakes are high.”\nThe moment, of course, is one where tech companies like Google are making heavy investments in AI, and often with mixed results. Pichai acknowledged that the company has some catching up to do on the AI side — he described the Gemini app (based on the company’s AI model of the same name) as having “strong momentum,” while also acknowledging “we have some work to do in 2025 to close the gap and establish a leadership position there as well.”\n“Scaling Gemini on the consumer side will be our biggest focus next year,” he said.\n')

To bypass SSL authentication errors, you can set the “verify” option.

# Bypass SSL certificate verification
loader.requests_kwargs = {"verify": False}

# Load documents from the web
docs = loader.load()
docs[0]

c:\Users\gram\AppData\Local\pypoetry\Cache\virtualenvs\langchain-opentutorial-RXtDr8w5-py3.11\Lib\site-packages\urllib3\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'techcrunch.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings
  warnings.warn(

Document(metadata={'source': 'https://techcrunch.com/2024/12/28/google-ceo-says-ai-model-gemini-will-the-companys-biggest-focus-in-2025/'}, page_content='\nCEO Sundar Pichai reportedly told Google employees that 2025 will be a “critical” year for the company.\nCNBC reports that it obtained audio from a December 18 strategy meeting where Pichai and other executives put on ugly holiday sweaters and laid out their priorities for the coming year.\n\n\n\n\n\n\n\n\n“I think 2025 will be critical,” Pichai said. “I think it’s really important we internalize the urgency of this moment, and need to move faster as a company. The stakes are high.”\nThe moment, of course, is one where tech companies like Google are making heavy investments in AI, and often with mixed results. Pichai acknowledged that the company has some catching up to do on the AI side — he described the Gemini app (based on the company’s AI model of the same name) as having “strong momentum,” while also acknowledging “we have some work to do in 2025 to close the gap and establish a leadership position there as well.”\n“Scaling Gemini on the consumer side will be our biggest focus next year,” he said.\n')

You can also load multiple webpages at once. To do this, you can pass a list of urls to the loader, 
which will return a list of documents in the order of the urls passed.

# Initialize the WebBaseLoader with web page paths and parsing configurations
loader = WebBaseLoader(
    web_paths=[
        # List of web pages to load
        "https://techcrunch.com/2024/12/28/revisiting-the-biggest-moments-in-the-space-industry-in-2024/",
        "https://techcrunch.com/2024/12/29/ai-data-centers-could-be-distorting-the-us-power-grid/",
    ],
    bs_kwargs=dict(
        # BeautifulSoup settings to parse only the specific content section
        parse_only=bs4.SoupStrainer(
            "div",
            attrs={"class": ["entry-content wp-block-post-content is-layout-constrained wp-block-post-content-is-layout-constrained"]},
        )
    ),
    header_template={
        # Custom HTTP headers for the request (e.g., User-Agent for simulating a browser)
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
    },
)

# Load the data from the specified web pages
docs = loader.load()

# Check and print the number of documents loaded
print(len(docs))

2

Output the results fetched from the web.

print(docs[0].page_content[:500])
print("===" * 10)
print(docs[1].page_content[:500])

##Load Multiple URLs Concurrently with alazy_load()
You can speed up the process of scraping and parsing multiple URLs by using asynchronous loading. This 
allows you to fetch documents concurrently, improving efficiency while adhering to rate limits.
Key Points:
    Rate Limit: The requests_per_second parameter controls how many requests are made per second. In this 
    example, it's set to 1 to avoid overloading the server.
    
    Asynchronous Loading: The alazy_load() function is used to load documents asynchronously, enabling 
    faster processing of multiple URLs.
    
    Jupyter Notebook Compatibility: If running in Jupyter Notebook, nest_asyncio is required to handle asynchronous tasks properly.

The code below demonstrates how to configure and load documents asynchronously:

# only for jupyter notebook (asyncio)
import nest_asyncio

nest_asyncio.apply()

# Set the requests per second rate limit
loader.requests_per_second = 1

# Load documents asynchronously
# The aload() is deprecated and alazy_load() is used since the langchain 3.14 update)
docs=[]
async for doc in loader.alazy_load():
    docs.append(doc)

# Display loaded documents
docs

[Document(metadata={'source': 'https://techcrunch.com/2024/12/28/google-ceo-says-ai-model-gemini-will-the-companys-biggest-focus-in-2025/'}, page_content='\nCEO Sundar Pichai reportedly told Google employees that 2025 will be a “critical” year for the company.\nCNBC reports that it obtained audio from a December 18 strategy meeting where Pichai and other executives put on ugly holiday sweaters and laid out their priorities for the coming year.\n\n\n\n\n\n\n\n\n“I think 2025 will be critical,” Pichai said. “I think it’s really important we internalize the urgency of this moment, and need to move faster as a company. The stakes are high.”\nThe moment, of course, is one where tech companies like Google are making heavy investments in AI, and often with mixed results. Pichai acknowledged that the company has some catching up to do on the AI side — he described the Gemini app (based on the company’s AI model of the same name) as having “strong momentum,” while also acknowledging “we have some work to do in 2025 to close the gap and establish a leadership position there as well.”\n“Scaling Gemini on the consumer side will be our biggest focus next year,” he said.\n')]

##Load XML Documents
WebBaseLoader can process XML files by specifying a different BeautifulSoup parser. This is particularly 
useful when working with structured XML content like sitemaps or government data.


The following example demonstrates loading an XML document from a government website:

from langchain_community.document_loaders import WebBaseLoader

# Initialize loader with XML document URL
loader = WebBaseLoader(
    "https://www.govinfo.gov/content/pkg/CFR-2018-title10-vol3/xml/CFR-2018-title10-vol3-sec431-86.xml"
)

# Set parser to XML mode
loader.default_parser = "xml"

# Load and process the document
docs = loader.load()

##Memory-Efficient Loading
For handling large documents, WebBaseLoader provides two memory-efficient loading methods:
    Lazy Loading - loads one page at a time
    Async Loading - asynchronous page loading for better performance

# Lazy Loading Example
pages = []
for doc in loader.lazy_load():
    pages.append(doc)

# Print first 100 characters and metadata of the first page
print(pages[0].page_content[:100])
print(pages[0].metadata)


10
Energy
3
2018-01-01
2018-01-01
false
Uniform test method for the measurement of energy efficien
{'source': 'https://www.govinfo.gov/content/pkg/CFR-2018-title10-vol3/xml/CFR-2018-title10-vol3-sec431-86.xml'}

# Async Loading Example
pages = []
async for doc in loader.alazy_load():
    pages.append(doc)

# Print first 100 characters and metadata of the first page
print(pages[0].page_content[:100])
print(pages[0].metadata)


10
Energy
3
2018-01-01
2018-01-01
false
Uniform test method for the measurement of energy efficien
{'source': 'https://www.govinfo.gov/content/pkg/CFR-2018-title10-vol3/xml/CFR-2018-title10-vol3-sec431-86.xml'}

##Load Web-based Document Using Proxies
Sometimes you may need to use proxies to bypass IP blocking.

To use a proxy, you can pass a proxy dictionary to the loader (and its underlying requests library).
    Replace {username}, {password}, and proxy.service.com with your actual proxy credentials 
    and server information.
    
    Without a valid proxy configuration, errors such as ProxyError or AuthenticationError may occur.

loader = WebBaseLoader(
   "https://www.google.com/search?q=parrots",
   proxies={
       "http": "http://{username}:{password}:@proxy.service.com:6666/",
       "https": "https://{username}:{password}:@proxy.service.com:6666/",
   },
   # Initialize the web loader with proxy settings
   # Configure proxy for both HTTP and HTTPS requests
)

# Load documents using the proxy
docs = loader.load()

##Simple Web Content Loading with MarkItDown
Unlike WebBaseLoader which uses BeautifulSoup4 for sophisticated HTML parsing, MarkItDown provides a naive 
but simpler approach to web content loading. It directly fetches web content using HTTP requests and 
transfrom it into markdown format without detailed parsing capabilities.

Below is a basic example of loading web content using MarkItDown:

from markitdown import MarkItDown

md = MarkItDown()
result = md.convert("https://techcrunch.com/2024/12/28/revisiting-the-biggest-moments-in-the-space-industry-in-2024/")
result_text = result.text_content

print(result_text[:1000])


[![](https://techcrunch.com/wp-content/uploads/2024/09/tc-lockup.svg) TechCrunch Desktop Logo](https://techcrunch.com)

[![](https://techcrunch.com/wp-content/uploads/2024/09/tc-logo-mobile.svg) TechCrunch Mobile Logo](https://techcrunch.com)

* [Latest](/latest/)
* [Startups](/category/startups/)
* [Venture](/category/venture/)
* [Apple](/tag/apple/)
* [Security](/category/security/)
* [AI](/category/artificial-intelligence/)
* [Apps](/category/apps/)

* [Events](/events/)
* [Podcasts](/podcasts/)
* [Newsletters](/newsletters/)

[Sign In](https://oidc.techcrunch.com/login/?dest=https%3A%2F%2Ftechcrunch.com%2F2024%2F12%2F28%2Frevisiting-the-biggest-moments-in-the-space-industry-in-2024%2F)
[![]()](https://techcrunch.com/my-account/)

SearchSubmit

Site Search Toggle

Mega Menu Toggle



###ADVANCED: TXT Loader

from langchain_community.document_loaders import TextLoader
class langchain_community.document_loaders.text.TextLoader(file_path: str | Path, encoding: str | None = None, autodetect_encoding: bool = False)
    load() → list[Document]
    Load data into Document object
    Document object has below fields 
    Document(
        page_content="Hello, world!",
        metadata={"source": "https://example.com"}
    )

# Create a text loader
loader = TextLoader("data/appendix-keywords.txt", encoding="utf-8")

# Load the document
docs = loader.load()
print(f"Number of documents: {len(docs)}\n")
print("[Metadata]\n")
print(docs[0].metadata)
print("\n========= [Preview - First 500 Characters] =========\n")
print(docs[0].page_content[:500])

Number of documents: 1

In this example, we explore several strategies for using the TextLoader class to efficiently 
load large batches of files from a directory with varying encodings.

To illustrate the problem, we’ll first attempt to load multiple text files with arbitrary encodings.
    silent_errors: By passing the silent_errors parameter to the DirectoryLoader, 
        you can skip files that cannot be loaded and continue the loading process without interruptions.
    autodetect_encoding: Additionally, you can enable automatic encoding detection by passing the 
        autodetect_encoding parameter to the loader class, allowing it to detect file encodings before failing.

from langchain_community.document_loaders import DirectoryLoader

path = "data/"

text_loader_kwargs = {"autodetect_encoding": True}

loader = DirectoryLoader(
    path,
    glob="**/*.txt",
    loader_cls=TextLoader,
    silent_errors=True,
    loader_kwargs=text_loader_kwargs,
)
docs = loader.load() #returns list[Document]

doc_sources = [doc.metadata["source"] for doc in docs]
doc_sources

print("[Metadata]\n")
print(docs[0].metadata)
print("\n========= [Preview - First 500 Characters] =========\n")
print(docs[0].page_content[:500])

print("[Metadata]\n")
print(docs[1].metadata)
print("\n========= [Preview - First 500 Characters] =========\n")
print(docs[1].page_content[:500])


print("[Metadata]\n")
print(docs[3].metadata)
print("\n========= [Preview - First 500 Characters] =========\n")
print(docs[3].page_content[:500])

###ADVANCED: Character Text Splitter
Text splitting is a crucial step in document processing with LangChain.

The CharacterTextSplitter offers efficient text chunking that provides several key benefits:
    Token Limits: Overcomes LLM context window size restrictions
    Search Optimization: Enables more precise chunk-level retrieval
    Memory Efficiency: Processes large documents effectively
    Context Preservation: Maintains textual coherence through chunk_overlap

This is the simplest method. 
This splits based on a given character sequence, which defaults to "\n\n". 

Chunk length is measured by number of characters.
    How the text is split: by single character separator.
    How the chunk size is measured: by number of characters.

To obtain the string content directly, use .split_text.
    split_text(text: str) → List[str]
To create LangChain Document objects (e.g., for use in downstream tasks), use .create_documents.
    split_documents(documents: Iterable[Document]) → List[Document]
    Document can be str, Document 
    class langchain_core.documents.base.Document
        from langchain_core.documents import Document
        document = Document(
            page_content="Hello, world!",
            metadata={"source": "https://example.com"}
        )

with open("./data/appendix-keywords.txt", encoding="utf-8") as f:
   file = f.read()

print(file[:500])

Create CharacterTextSplitter with parameters:

Parameters
    separator: String to split text on (e.g., newlines, spaces, custom delimiters)
    chunk_size: Maximum size of chunks to return
    chunk_overlap: Overlap in characters between chunks
    length_function: Function that measures the length of given chunks
    is_separator_regex: Boolean indicating whether separator should be treated as a regex pattern

from langchain_text_splitters import CharacterTextSplitter

text_splitter = CharacterTextSplitter(
   separator=" ",           # Splits whenever a space is encountered in text
   chunk_size=250,          # Each chunk contains maximum 250 characters
   chunk_overlap=50,        # Two consecutive chunks share 50 characters
   length_function=len,     # Counts total characters in each chunk
   is_separator_regex=False # Uses space as literal separator, not as regex
)


chunks = text_splitter.create_documents([file])
print(chunks[0])


Demonstrate metadata handling during document creation:
    create_documents accepts both text data and metadata lists
    Each chunk inherits metadata from its source document

# Define metadata for each document
metadatas = [
   {"document": 1},
   {"document": 2},
]

# Create documents with metadata
documents = text_splitter.create_documents(
   [file, file],  # List of texts to split
   metadatas=metadatas,  # Corresponding metadata
)

print(documents[0])  # Display first document with metadata


Split text using the split_text() method.
    text_splitter.split_text(file)[0] returns the first chunk of the split text

# Split the file text and return the first chunk
text_splitter.split_text(file)[0]

'Semantic Search\n\nDefinition: A vector store is a system that stores data converted to vector format. It is used for search, classification, and other data analysis tasks.\nExample: Vectors of word embeddings can be stored in a database for quick'

###ADVANCED: OpenAI Embeddings
It showcases how to generate embeddings for text queries and documents, reduce their dimensionality using PCA , and visualize them in 2D for better interpretability.

By analyzing relationships between the query and documents through cosine similarity, 
it provides insights into how embeddings can enhance workflows, including text analysis and data visualization.

Why Adjust Embedding Dimensions?
    Optimize Resources : Shortened embeddings use less memory and compute.
    Flexible Usage : Models like text-embedding-3-large allow size reduction with the dimensions API.
    Key Insight : Even at 256 dimensions, performance can surpass larger models 
    like text-embedding-ada-002.

This is a description of the models supported by OpenAI

Model 	            ~ Pages per Dollar 	Performance on MTEB Eval 	Max Input 	Available dimension
text-embedding-3-small 	62,500 	            62.3% 	                8191 	    512, 1536
text-embedding-3-large 	9,615 	            64.6% 	                8191 	    256, 1024, 3072
text-embedding-ada-002 	12,500 	            61.0% 	                8191 	    1536


from langchain_openai import OpenAIEmbeddings

# Set desired model
openai_embedding = OpenAIEmbeddings(model="text-embedding-3-large")

If dimension reduction is necessary, please set as below.

from langchain_openai import OpenAIEmbeddings

# Set desired model and dimension
openai_embedding = OpenAIEmbeddings(model="text-embedding-3-large", dimensions=1024)


query = "What is the Open AI's gpt embedding model?"

# Various embedding models
documents = [
    "all-mpnet-base-v2",
    "bert-base-nli-mean-tokens",
    "bert-large-nli-mean-tokens",
    "distilbert-base-nli-mean-tokens",
    "roberta-base-nli-stsb-mean-tokens",
    "roberta-large-nli-stsb-mean-tokens",
    "sentence-transformers/all-MiniLM-L12-v2",
    "sentence-transformers/all-distilroberta-v1",
    "sentence-transformers/paraphrase-MiniLM-L3-v2",
    "sentence-transformers/paraphrase-mpnet-base-v2",
    "sentence-transformers/msmarco-distilbert-base-v3",
    "sentence-transformers/msmarco-MiniLM-L6-cos-v5",
    "sentence-transformers/msmarco-roberta-base-v2",
    "xlnet-base-cased",
    "facebook/bart-large",
    "facebook/dpr-question_encoder-single-nq-base",
    "google/electra-small-discriminator",
    "google/electra-base-discriminator",
    "google/electra-large-discriminator",
    "deepset/sentence_bert",
    "deepset/roberta-base-squad2",
    "gpt-neo-125M",
    "gpt-neo-1.3B",
    "gpt-neo-2.7B",
    "gpt-j-6B",
    "text-embedding-ada-002",
    "text-embedding-3-small",
    "text-embedding-3-large",
    "all-MiniLM-L6-v2",
    "multilingual-e5-base",
]

Now we embed the query and document using the set embedding model.

The base Embeddings class in LangChain provides two methods: one for embedding documents a
nd one for embedding a query. 

The former, .embed_documents, takes as input multiple texts, while the latter, .embed_query, 
takes a single text. The reason for having these as two separate methods is that some embedding 
providers have different embedding methods for documents (to be searched over) 
vs queries (the search query itself)
Check embedding models 
https://python.langchain.com/docs/integrations/text_embedding/
        from langchain_mistralai import MistralAIEmbeddings
        embeddings = MistralAIEmbeddings(model="mistral-embed")
        
        There isa fake document embeddings as well 

        from langchain_core.embeddings import DeterministicFakeEmbedding

        embeddings_model = DeterministicFakeEmbedding(size=4096)
        #Example 
        embeddings = embeddings_model.embed_documents(
            [
                "Hi there!",
                "Oh, hello!",
                "What's your name?",
                "My friends call me World",
                "Hello World!"
            ]
        )
        embedded_query = embeddings_model.embed_query("What was the name mentioned in the conversation?")



#embed_query(text: str) → List[float]
#Call out to OpenAI’s embedding endpoint async for embedding query text.
query_vector = openai_embedding.embed_query(query)

#embed_documents(texts: List[str], chunk_size: int | None = 0) → List[List[float]]
#Call out to OpenAI’s embedding endpoint for embedding search docs.
docs_vector = openai_embedding.embed_documents(documents)

print("number of documents: " + str(len(docs_vector)))
print("dimension: " + str(len(docs_vector[0])))

# Part of the sliced ​​vector
print("query: " + str(query_vector[:5]))
print("documents[0]: " + str(docs_vector[0][:5]))
print("documents[1]: " + str(docs_vector[1][:5]))

number of documents: 30
dimension: 3072
query: [-0.00288043892942369, 0.020187586545944214, -0.011613684706389904, -0.02147459052503109, 0.02403634414076805]
documents[0]: [-0.03383158519864082, 0.004126258660107851, -0.025896472856402397, -0.013592381030321121, -0.0021926583722233772]
documents[1]: [0.0051429239101707935, -0.015500376932322979, -0.019089050590991974, -0.027715347707271576, -0.00695410929620266]

##Similarity Calculation (Cosine Similarity)
This code calculates the similarity between the query and the document through Cosine Similarity .

Find the documents similar (top 3) and (bottom 3) .

from sklearn.metrics.pairwise import cosine_similarity

# Calculate Cosine Similarity
similarity = cosine_similarity([query_vector], docs_vector)

# Sorting by in descending order
sorted_idx = similarity.argsort()[0][::-1]

# Display top 3 and bottom 3 documents based on similarity
print("Top 3 most similar document:")
for i in range(0, 3):
    print(
        f"[{i+1}] similarity: {similarity[0][sorted_idx[i]]:.3f} | {documents[sorted_idx[i]]}"
    )

print("\nBottom 3 least similar documents:")
for i in range(1, 4):
    print(
        f"[{i}] similarity: {similarity[0][sorted_idx[-i]]:.3f} | {documents[sorted_idx[-i]]}"
    )

Top 3 most similar document: these texts are similar to query text 
[1] similarity: 0.514 | text-embedding-3-large
[2] similarity: 0.467 | text-embedding-ada-002
[3] similarity: 0.457 | text-embedding-3-small

Bottom 3 least similar documents:
[1] similarity: 0.050 | facebook/bart-large
[2] similarity: 0.143 | multilingual-e5-base
[3] similarity: 0.171 | all-mpnet-base-v2

##Embeddings visualization(PCA)
Reduce the dimensionality of the embeddings for visualization purposes.

This code uses principal component analysis (PCA) to reduce high-dimensional embedding vectors 
to two dimensions.

The resulting 2D points are displayed in a scatterplot, with each point labeled for its corresponding document.
    Visually explore relationships between embeddings (e.g., clustering, grouping).
    Identify patterns or anomalies in the data that may not be obvious in high dimensions.
    Improve interpretability , making the data more accessible for human analysis and decision-making.

import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import numpy as np

# Combine documents and query for PCA
#Stack arrays in sequence vertically (row wise).
#docs_vector
#query_vector
all_vectors = np.vstack([docs_vector, query_vector])  # Stack query vector with docs
pca = PCA(n_components=2)
reduced_vectors = pca.fit_transform(all_vectors)

# Separate reduced vectors for documents and query
doc_vectors_2d = reduced_vectors[:-1]  # All but the last point (documents)
query_vector_2d = reduced_vectors[-1]  # Last point (query)

# Plot the reduced vectors
plt.scatter(doc_vectors_2d[:, 0], doc_vectors_2d[:, 1], color="blue", label="Documents")
plt.scatter(
    query_vector_2d[0],
    query_vector_2d[1],
    color="red",
    label="Query",
    marker="x",
    s=300,
)

# Annotate document points
for i, doc in enumerate(documents):
    plt.text(doc_vectors_2d[i, 0], doc_vectors_2d[i, 1], doc, fontsize=8)

# Add plot details
plt.title("2D Visualization of Embedding Vectors with Query")
plt.xlabel("PCA Dimension 1")
plt.ylabel("PCA Dimension 2")
plt.legend()
plt.show()

###ADVANCED: VectorStore-backed Retriever
It covers the foundational steps of creating a vector store with FAISS(Facebook AI Similarity Search) 
and explores advanced retrieval strategies for improving search accuracy and efficiency.

A VectorStore-backed retriever is a document retrieval system that leverages a vector store to search 
for documents based on their vector representations. 
This approach enables efficient similarity-based search for handling unstructured data.

RAG (Retrieval-Augmented Generation) Workflow - *** IMP
https://raw.githubusercontent.com/LangChain-OpenTutorial/LangChain-OpenTutorial/a148ed0be7412532ba9c1f1cb81cf8d8f9c9f79f/10-Retriever/assets/01-vectorstore-retriever-rag-flow.png


The steps include:
    Document Loading: Importing raw documents.
    Text Chunking: Splitting text into manageable chunks.
    Vector Embedding: Converting the text into numerical vectors using an embedding model.
    Store in Vector Database: Storing the generated embeddings in a vector database for efficient retrieval.

During the query phase:
    Steps: User Query -> Embedding -> Search in VectorStore 
        -> Relevant Chunks Retrieved -> LLM Generates Response
    The user's query is transformed into an embedding vector using an embedding model.
    This query embedding is compared against stored document vectors within the vector database 
        to retrieve the most relevant results.
    The retrieved chunks are passed to a Large Language Model (LLM), which generates 
        a final response based on the retrieved information.

pip install langchain_openai langchain_community langchain_text_splitters
pip install  langchain_core langchain_upstage faiss-cpu

requires UPSTAGE_API_KEY


##Initializing and Using VectorStoreRetriever
This section demonstrates how to load documents using OpenAI embeddings 
and create a vector database using FAISS.
    The example below showcases how to use OpenAI embeddings for document loading 
        and FAISS for vector database creation.
    Once the vector database is created, it can be loaded and queried using retrieval methods 
        such as Similarity Search and Maximal Marginal Relevance (MMR) 
        to search for relevant text within the vector store.


from langchain_community.vectorstores import FAISS
from langchain_openai.embeddings import OpenAIEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.document_loaders import TextLoader

# Load the file using TextLoader
#https://github.com/LangChain-OpenTutorial/LangChain-OpenTutorial/tree/main/10-Retriever/data
loader = TextLoader("./data/01-vectorstore-retriever-appendix-keywords.txt", encoding="utf-8")
documents = loader.load()

# split the text into chunks
text_splitter = CharacterTextSplitter(chunk_size=300, chunk_overlap=0)
split_docs = text_splitter.split_documents(documents) # Split into smaller chunks

# Initialize the OpenAI embedding model
embeddings = OpenAIEmbeddings()

# Create a FAISS vector database
db = FAISS.from_documents(split_docs, embeddings)

##1. Initializing and Using VectorStoreRetriever (as_retriever )
The as_retriever method allows you to convert a vector database into a retriever, 
enabling efficient document search and retrieval from the vector store.

How It Works:
    The as_retriever() method transforms a vector store (like FAISS) into a retriever object, 
    making it compatible with LangChain's retrieval workflows.
    
    This retriever can then be directly used with RAG pipelines or combined with Large Language Models 
    (LLMs) for building intelligent search systems.

# Basic Retriever Creation (Similarity Search)
retriever = db.as_retriever()

The as_retriever method allows you to configure advanced retrieval strategies, 
such as similarity search, MMR (Maximal Marginal Relevance), and similarity score threshold-based filtering.

Parameters:
    **kwargs : Keyword arguments passed to the retrieval function:
        search_type : Specifies the search method.
            "similarity" : Returns the most relevant documents based on cosine similarity.
            "mmr" : Utilizes the Maximal Marginal Relevance algorithm, balancing relevance and diversity.
            "similarity_score_threshold" : Returns documents with a similarity score above a specified threshold.
        search_kwargs : Additional search options for fine-tuning results:
            k : Number of documents to return (default: 4 ).
            score_threshold : Minimum similarity score for the "similarity_score_threshold" search type (e.g., 0.8 ).
            fetch_k : Number of documents initially retrieved during an MMR search (default: 20 ).
            lambda_mult : Controls diversity in MMR results (0 = maximum diversity, 1 = maximum relevance, default: 0.5 ).
            filter : Metadata filtering for selective document retrieval.

Return Value:
    VectorStoreRetriever: An initialized retriever object that can be directly queried 
    for document search tasks.

Notes:
    Supports multiple search strategies (similarity , MMR , similarity_score_threshold ).
    
    MMR improves result diversity while preserving relevance by reducing redundancy in results.
    
    Metadata filtering enables selective document retrieval based on document properties.
    
    The tags parameter can be used to label retrievers for better organization and easier identification.

Cautions:
    Diversity Control with MMR:
        Adjust both fetch_k (number of documents initially retrieved) and lambda_mult 
        (diversity control factor) carefully for optimal balance.
        lambda_mult
            Lower values (< 0.5) -> Prioritize diversity.
            Higher values (> 0.5) -> Prioritize relevance.            
        set fetch_k higher than k for effective diversity control.
        
    Threshold Settings:
        Using a high score_threshold (e.g., 0.95) can lead to zero results.
        
    Metadata Filtering:
        Ensure the metadata structure is well-defined before applying filters.
        
    Balanced Configuration:
        Maintain a proper balance between search_type and search_kwargs settings 
        for optimal retrieval performance.

retriever = db.as_retriever(
    search_type="similarity_score_threshold", 
    search_kwargs={
        "k": 5,  # Return the top 5 most relevant documents
        "score_threshold": 0.7  # Only return documents with a similarity score of 0.7 or higher
    }
)
# Perform the search
query = "Explain the concept of vector search."
results = retriever.invoke(query)

# Display search results
for doc in results:
    print(doc.page_content)

The invoke() method is the primary entry point for interacting with a Retriever. 
It is used to search and retrieve relevant documents based on a given query.

How It Works :
    Query Submission: A user query is provided as input.
    
    Embedding Generation: The query is converted into a vector representation (if necessary).
    
    Search Process: The retriever searches the vector database using the specified 
    search strategy (similarity, MMR, etc.).
    
    Results Return: The method returns a list of relevant document chunks.

Parameters:
    input (Required):
        The query string provided by the user.
        The query is converted into a vector and compared with stored document vectors 
        for similarity-based retrieval.

    config (Optional):
        Allows for fine-grained control over the retrieval process.
        Can be used to specify tags, metadata insertion, and search strategies.

    **kwargs (Optional):
        Enables direct passing of search_kwargs for advanced configuration.
        Example options include:
            k : Number of documents to return.
            score_threshold : Minimum similarity score for a document to be included.
            fetch_k : Number of documents initially retrieved in MMR searches.

Return Value:
    List[Document]:
        Returns a list of document objects containing the retrieved text and metadata.
        Each document object includes:
            page_content : The main content of the document.
            metadata : Associated metadata with the document (e.g., source, tags).

docs = retriever.invoke("What is an embedding?")

for doc in docs:
    print(doc.page_content)
    print("=========================================================")


Usage Example 2: Search with Options ( search_kwargs )

# search options: top 5 results with a similarity score ≥ 0.7
docs = retriever.invoke(
    "What is a vector database?",
    search_kwargs={"k": 5, "score_threshold": 0.7}
)
for doc in docs:
    print(doc.page_content)
    print("=========================================================")



Usage Example 3: Using config and **kwargs (Advanced Configuration)

from langchain_core.runnables.config import RunnableConfig

# Create a RunnableConfig with tags and metadata
config = RunnableConfig(
    tags=["retrieval", "faq"],  # Adding tags for query categorization
    metadata={"project": "vectorstore-tutorial"}  # Project-specific metadata for traceability
)
# Perform a query using advanced configuration settings
docs = retriever.invoke(
    input="What is a DataFrame?", 
    config=config,  # Applying the config with tags and metadata
    search_kwargs={
        "k": 3,                   
        "score_threshold": 0.8   
    }
)
#  Display the search results
for idx, doc in enumerate(docs):
    print(f"\n🔍 [Search Result {idx + 1}]")
    print("📄 Document Content:", doc.page_content)
    print("🗂️ Metadata:", doc.metadata)
    print("=" * 60)


##Max Marginal Relevance (MMR)
The Maximal Marginal Relevance (MMR) search method is a document retrieval algorithm designed 
to reduce redundancy by balancing relevance and diversity when returning results.

How MMR Works: Unlike basic similarity-based searches that return the most relevant documents 
based solely on similarity scores, MMR considers two critical factors:
    Relevance: Measures how closely the document matches the user's query.
    
    Diversity: Ensures the retrieved documents are distinct from each other to avoid repetitive results.

Key Parameters:
    search_type="mmr": Activates the MMR retrieval strategy.
    
    k: The number of documents returned after applying diversity filtering(default: 4).
    
    fetch_k: Number of documents initially retrieved before applying diversity filtering (default: 20).
    
    lambda_mult: Diversity control factor (0 = max diversity , 1 = max relevance , default: 0.5).

# MMR Retriever Configuration (Balancing Relevance and Diversity)
retriever = db.as_retriever(
    search_type="mmr", 
    search_kwargs={
        "k": 3,                
        "fetch_k": 10,           
        "lambda_mult": 0.6  # Balancing Similarity and Diversity (0.6: Slight Emphasis on Diversity)
    }
)

query = "What is an embedding?"
docs = retriever.invoke(query)

#  Display the search results
print(f"\n🔎 [Query]: {query}\n")
for idx, doc in enumerate(docs):
    print(f"📄 [Document {idx + 1}]")
    print("📖 Document Content:", doc.page_content)
    print("🗂️ Metadata:", doc.metadata)
    print("=" * 60)


##Similarity Score Threshold Search
Similarity Score Threshold Search is a retrieval method where only documents exceeding 
a predefined similarity score are returned. This approach helps filter out low-relevance results, 
ensuring that the returned documents are highly relevant to the query.

Key Features:
    Relevance Filtering: Returns only documents with a similarity score above the specified threshold.
    Configurable Precision: The threshold is adjustable using the score_threshold parameter.
    Search Type Activation: Enabled by setting search_type="similarity_score_threshold" .

This search method is ideal for tasks requiring highly precise results, 
such as fact-checking or answering technical queries.

# Retriever Configuration (Similarity Score Threshold Search)
retriever = db.as_retriever(
    search_type="similarity_score_threshold",  
    search_kwargs={
        "score_threshold": 0.6,  
        "k": 5                
    }
)
# Execute the query
query = "What is Word2Vec?"
docs = retriever.invoke(query)

# Display the search results 
print(f"\n🔎 [Query]: {query}\n")
if docs:
    for idx, doc in enumerate(docs):
        print(f"📄 [Document {idx + 1}]")
        print("📖 Document Content:", doc.page_content)
        print("🗂️ Metadata:", doc.metadata)
        print("=" * 60)
else:
    print("⚠️ No relevant documents found. Try lowering the similarity score threshold.")


##Configuring top_k (Adjusting the Number of Returned Documents)

    The parameter k specifies the number of documents returned during a vector search. 
    It determines how many of the top-ranked documents (based on similarity score) will be retrieved 
    from the vector database.

    The number of documents retrieved can be adjusted by setting the k value within the search_kwargs.

    For example, setting k=1 will return only the top 1 most relevant document based on similarity.

# Retriever Configuration (Return Only the Top 1 Document)
retriever = db.as_retriever(
    search_kwargs={
        "k": 1  # Return only the top 1 most relevant document
    }
)

query = "What is an embedding?"
docs = retriever.invoke(query)

#  Display the search results 
print(f"\n🔎 [Query]: {query}\n")
if docs:
    for idx, doc in enumerate(docs):
        print(f"📄 [Document {idx + 1}]")
        print("📖 Document Content:", doc.page_content)
        print("🗂️ Metadata:", doc.metadata)
        print("=" * 60)
else:
    print("⚠️ No relevant documents found. Try increasing the `k` value.")


##Dynamic Configuration (Using ConfigurableField )
The ConfigurableField feature in LangChain allows for dynamic adjustment of search configurations, 
providing flexibility during query execution.

Key Features:
    Runtime Search Configuration: Adjust search settings without modifying the core retriever setup.
    
    Enhanced Traceability: Assign unique identifiers, names, and descriptions to each parameter 
    for improved readability and debugging.
    
    Flexible Control with config: Search configurations can be passed dynamically using the 
    config parameter as a dictionary.

Use Cases:
    Switching Search Strategies: Dynamically adjust the search type (e.g., "similarity", "mmr" ).
    
    Real-Time Parameter Adjustments: Modify search parameters like k , score_threshold , 
    and fetch_k during query execution.
    
    Experimentation: Easily test different search strategies and parameter combinations 
    without rewriting code.

from langchain_core.runnables import ConfigurableField 

# Retriever Configuration Using ConfigurableField
retriever = db.as_retriever(search_kwargs={"k": 1}).configurable_fields(
    search_type=ConfigurableField(
        id="search_type", 
        name="Search Type",  # Name for the search strategy
        description="The search type to use",  # Description of the search strategy
    ),
    search_kwargs=ConfigurableField(
        id="search_kwargs",  
        name="Search Kwargs",  # Name for the search parameters
        description="The search kwargs to use",  # Description of the search parameters
    ),
)

The following examples demonstrate how to apply dynamic search settings using ConfigurableField in LangChain.

#Search Configuration 1: Basic Search (Top 3 Documents)

config_1 = {"configurable": {"search_kwargs": {"k": 3}}}

# Execute the query
docs = retriever.invoke("What is an embedding?", config=config_1)

# Display the search results
print("\n🔎 [Search Results - Basic Configuration (Top 3 Documents)]")
for idx, doc in enumerate(docs):
    print(f"📄 [Document {idx + 1}]")
    print(doc.page_content)
    print("=" * 60)


# Search Configuration 2: Similarity Score Threshold (≥ 0.8)

config_2 = {
    "configurable": {
        "search_type": "similarity_score_threshold",
        "search_kwargs": {
            "score_threshold": 0.8,  # Only return documents with a similarity score of 0.8 or higher
        },
    }
}

# Execute the query
docs = retriever.invoke("What is Word2Vec?", config=config_2)

# Display the search results
print("\n🔎 [Search Results - Similarity Score Threshold ≥ 0.8]")
for idx, doc in enumerate(docs):
    print(f"📄 [Document {idx + 1}]")
    print(doc.page_content)
    print("=" * 60)


# Search Configuration 3: MMR Search (Diversity and Relevance Balanced)

config_3 = {
    "configurable": {
        "search_type": "mmr",
        "search_kwargs": {
            "k": 2,            # Return the top 2 most diverse and relevant documents
            "fetch_k": 10,     # Initially fetch the top 10 documents before filtering for diversity
            "lambda_mult": 0.6 # Balance factor: 0.6 (0 = maximum diversity, 1 = maximum relevance)
        },
    }
}
# Execute the query using MMR search
docs = retriever.invoke("What is Word2Vec?", config=config_3)

#  Display the search results
print("\n🔎 [Search Results - MMR (Diversity and Relevance Balanced)]")
for idx, doc in enumerate(docs):
    print(f"📄 [Document {idx + 1}]")
    print(doc.page_content)
    print("=" * 60)



##Using Separate Query & Passage Embedding Models
By default, a retriever uses the same embedding model for both queries and documents. However, certain 
scenarios can benefit from using different models tailored to the specific needs of queries and documents.

Why Use Separate Embedding Models?
Using different models for queries and documents can improve retrieval accuracy 
and search relevance by optimizing each model for its intended purpose:

    Query Embedding Model: Fine-tuned for understanding short and concise search queries.
    
    Document (Passage) Embedding Model: Optimized for longer text spans with richer context.

For instance, Upstage Embeddings provides the capability to use distinct models for:
    Query Embeddings (solar-embedding-1-large-query)
    
    Document (Passage) Embeddings (solar-embedding-1-large-passage)

In such cases, the query is embedded using the query embedding model, 
while the documents are embedded using the document embedding model.

##How to Issue an Upstage API Key

    Sign Up & Log In:
        Visit Upstage and log in (sign up if you don't have an account).

    Open API Key Page:
        Go to the menu bar, select "Dashboards", then navigate to "API Keys".

    Generate API Key:
        Click "Create new key" -> Enter name your key (e.g., LangChain-Tutorial)

    Copy & Store Safely:
        Copy the generated key and keep it secure.

Description

from langchain_community.vectorstores import FAISS
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from langchain_upstage import UpstageEmbeddings

# 1. Data Loading and Document Splitting
loader = TextLoader("./data/01-vectorstore-retriever-appendix-keywords.txt", encoding="utf-8")
documents = loader.load()

# Split the loaded documents into text chunks 
text_splitter = CharacterTextSplitter(chunk_size=300, chunk_overlap=0)
split_docs = text_splitter.split_documents(documents)

#  2. Document Embedding
doc_embedder = UpstageEmbeddings(model="solar-embedding-1-large-passage")

#  3. Create a Vector Database
db = FAISS.from_documents(split_docs, doc_embedder)


#  3. Query Embedding and Vector Search
query_embedder = UpstageEmbeddings(model="solar-embedding-1-large-query")

# Convert the query into a vector using the query embedding model
query_vector = query_embedder.embed_query("What is an embedding?")

#  4. Vector Similarity Search (Return Top 2 Documents)
results = db.similarity_search_by_vector(query_vector, k=2)

#  5. Display the Search Results
print(f"\n🔎 [Query]: What is an embedding?\n")
for idx, doc in enumerate(results):
    print(f"📄 [Document {idx + 1}]")
    print("📖 Document Content:", doc.page_content)
    print("🗂️ Metadata:", doc.metadata)
    print("=" * 60)

##Understanding other Vector store 
Why Vector Store Is Essential

    Fast and Efficient Search
        By properly storing and indexing embedding vectors, vector stores allow 
        for the rapid retrieval of relevant information, even when dealing with massive datasets.

    Scalability for Growing Data
        As data continues to expand, vector stores must scale efficiently. 
        A well-structured vector store ensures the system can handle large-scale data 
        without performance issues, supporting seamless growth.

    Facilitating Semantic Search
        Unlike traditional keyword-based search, semantic search retrieves content based on meaning. 
        Vector stores enable this by finding paragraphs or sections that closely align 
        with a user’s query in context. This is a key advantage over databases that store raw text, 
        which are limited to exact keyword matches.
        
Interface
    LangChain provides a unified interface for interacting with vector stores, 
    allowing users to seamlessly switch between various implementations.

    This interface includes core methods for writing, deleting, and searching documents 
    within the vector store.

    The main methods are as follows:
        add_documents : Adds a list of texts to the vector store.
        upsert_documents : Adds new documents to the vector store or updates existing ones 
            if they already exist.
            the upsert_documents_parallel method, which enables efficient bulk processing of data when applicable.
        delete_documents : Deletes a list of documents from the vector store.
        similarity_search : Searches for documents similar to a given query.

Understanding Search Methods
    Keyword-Based Search
    This method relies on matching exact words or phrases in the query with those in the document. 
    It’s simple but lacks the ability to capture semantic relationships between terms.

    Similarity-Based Search
    Uses vector representations to evaluate how semantically similar the query is to the documents. 
    It provides more accurate results, especially for natural language queries.

    Score-Based Similarity Search
    Assigns a similarity score to each document based on the query. 
    Higher scores indicate stronger relevance. Commonly uses metrics like cosine similarity 
    or distance-based scoring.

How Similarity Search Works
    Concept of Embeddings and Vectors
    Embeddings are numerical representations of words or documents in a high-dimensional space. 
    They capture semantic meaning, enabling better comparison between query and documents.

    Similarity Measurement Methods
        Cosine Similarity: Measures the cosine of the angle between two vectors. 
        Values closer to 1 indicate higher similarity.
        Euclidean Distance: Calculates the straight-line distance between two points in vector space. 
        Smaller distances imply higher similarity.

    Scoring and Ranking Search Results
    After calculating similarity, documents are assigned scores. 
    Results are ranked in descending order of relevance based on these scores.

    Brief Overview of Search Algorithms
        TF-IDF: Weights terms based on their frequency in a document relative 
        to their occurrence across all documents.
        
        BM25: A refined version of TF-IDF, optimized for relevance in information retrieval.
        
        Neural Search: Leverages deep learning to generate context-aware embeddings for more accurate results.

Types of Searches in Vector Stores
    Similarity Search : Finds documents with embeddings most similar to the query. 
    Ideal for semantic search applications.

    Maximal Marginal Relevance (MMR) Search : Balances relevance and diversity in search results 
    by prioritizing diverse yet relevant documents.

    Sparse Retriever : Uses traditional keyword-based methods like TF-IDF or BM25 
    to retrieve documents. Effective for datasets with limited context.

    Dense Retriever : Relies on dense vector embeddings to capture semantic meaning. 
    Common in modern search systems using deep learning.

    Hybrid Search : Combines sparse and dense retrieval methods. Balances the precision 
    of dense methods with the broad coverage of sparse methods for optimal results.
    
    
Integration
    Here is a brief overview of the vector stores covered in this tutorial:
        Chroma : An open-source vector database designed for AI applications, 
        enabling efficient storage and retrieval of embeddings.
        
        FAISS : Developed by Facebook AI, FAISS (Facebook AI Similarity Search) 
        is a library for efficient similarity search and clustering of dense vectors. ￼
        
        Pinecone : A managed vector database service that provides high-performance vector 
        similarity search, enabling developers to build scalable AI applications.
        
        Qdrant : Qdrant (read: quadrant ) is a vector similarity search engine. It provides a production-
        ready service with a convenient API to store, search, and manage vectors with additional payload and 
        extended filtering support. It makes it useful for all sorts of neural network or semantic-based 
        matching, faceted search, and other applications.
        
        Elasticsearch : A distributed, RESTful search and analytics engine that supports vector search, 
        allowing for efficient similarity searches within large datasets.
        
        MongoDB : MongoDB Atlas Vector Search enables efficient storage, indexing, and querying of vector 
        embeddings alongside your operational data, facilitating seamless implementation of AI-driven 
        applications.
       
       pgvector (PostgreSQL) : An extension for PostgreSQL that adds vector similarity search capabilities, 
       allowing for efficient storage and querying of vector data within a relational database.
        
        Neo4j : A graph database that stores nodes and relationships, with native support for vector search, 
        facilitating complex queries involving both graph and vector data. ￼
        
        Weaviate : An open-source vector database that allows for storing data objects and vector 
        embeddings, supporting various data types and offering semantic search capabilities.
        
        Milvus : A database that stores, indexes, and manages massive embedding vectors generated by machine learning models, designed for high-performance vector similarity search. ￼

pip install angchain-chroma chromadb  langchain-huggingface

Requires HUGGINGFACEHUB_API_TOKEN

Chroma is the open-source vector database designed for AI application.

It specializes in storing high-dimensional vectors and performing fast similariy search, 
making it ideal for tasks like semantic search , recommendation systems and multimodal search .

The biggest feature of Chroma is that it internally Indexing (HNSW) 
and Embedding (all-MiniLM-L6-v2) are used when storing data.

from langchain_huggingface import HuggingFaceEmbeddings

model_name = "Alibaba-NLP/gte-base-en-v1.5"

embeddings = HuggingFaceEmbeddings(
    model_name=model_name, model_kwargs={"trust_remote_code": True}
)

pip install langchain-chroma

from langchain_chroma import Chroma

db = Chroma.from_documents(documents, OpenAIEmbeddings())

Key init args — indexing params:
    collection_name: str
        Name of the collection.
    embedding_function: Embeddings
        Embedding function to use.

Key init args — client params:
    client: Optional[Client]
        Chroma client to use.
    client_settings: Optional[chromadb.config.Settings]
        Chroma client settings.
    persist_directory: Optional[str]
        Directory to persist the collection.


        

Add Documents:

    from langchain_core.documents import Document

    document_1 = Document(page_content="foo", metadata={"baz": "bar"})
    document_2 = Document(page_content="thud", metadata={"bar": "baz"})
    document_3 = Document(page_content="i will be deleted :(")

    documents = [document_1, document_2, document_3]
    ids = ["1", "2", "3"]
    vector_store.add_documents(documents=documents, ids=ids)

Update Documents:

    updated_document = Document(
        page_content="qux",
        metadata={"bar": "baz"}
    )

    vector_store.update_documents(ids=["1"],documents=[updated_document])

Delete Documents:

    vector_store.delete(ids=["3"])

Search:

    results = vector_store.similarity_search(query="thud",k=1)
    for doc in results:
        print(f"* {doc.page_content} [{doc.metadata}]")

* thud [{'baz': 'bar'}]

Search with filter:

    results = vector_store.similarity_search(query="thud",k=1,filter={"baz": "bar"})
    for doc in results:
        print(f"* {doc.page_content} [{doc.metadata}]")

* foo [{'baz': 'bar'}]

Search with score:

    results = vector_store.similarity_search_with_score(query="qux",k=1)
    for doc, score in results:
        print(f"* [SIM={score:3f}] {doc.page_content} [{doc.metadata}]")

* [SIM=0.000000] qux [{'bar': 'baz', 'baz': 'bar'}]

Async:

    # add documents
    # await vector_store.aadd_documents(documents=documents, ids=ids)

    # delete documents
    # await vector_store.adelete(ids=["3"])

    # search
    # results = vector_store.asimilarity_search(query="thud",k=1)

    # search with score
    results = await vector_store.asimilarity_search_with_score(query="qux",k=1)
    for doc,score in results:
        print(f"* [SIM={score:3f}] {doc.page_content} [{doc.metadata}]")

* [SIM=0.335463] foo [{'baz': 'bar'}]

Use as Retriever:

    retriever = vector_store.as_retriever(
        search_type="mmr",
        search_kwargs={"k": 1, "fetch_k": 2, "lambda_mult": 0.5},
    )
    retriever.invoke("thud")

[Document(metadata={'baz': 'bar'}, page_content='thud')]



##Chroma as SelfQueryRetriever 
class langchain.retrievers.self_query.base.SelfQueryRetriever
    Bases: BaseRetriever
    Retriever that uses a vector store and an LLM to generate the vector store queries.

Note: The self-query retriever requires you to have lark installed (pip install lark). 
We also need the langchain-chroma package.

%pip install --upgrade --quiet  lark

%pip install --upgrade --quiet  langchain-chroma

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()

docs = [
    Document(
        page_content="A bunch of scientists bring back dinosaurs and mayhem breaks loose",
        metadata={"year": 1993, "rating": 7.7, "genre": "science fiction"},
    ),
    Document(
        page_content="Leo DiCaprio gets lost in a dream within a dream within a dream within a ...",
        metadata={"year": 2010, "director": "Christopher Nolan", "rating": 8.2},
    ),
    Document(
        page_content="A psychologist / detective gets lost in a series of dreams within dreams within dreams and Inception reused the idea",
        metadata={"year": 2006, "director": "Satoshi Kon", "rating": 8.6},
    ),
    Document(
        page_content="A bunch of normal-sized women are supremely wholesome and some men pine after them",
        metadata={"year": 2019, "director": "Greta Gerwig", "rating": 8.3},
    ),
    Document(
        page_content="Toys come alive and have a blast doing so",
        metadata={"year": 1995, "genre": "animated"},
    ),
    Document(
        page_content="Three men walk into the Zone, three men walk out of the Zone",
        metadata={
            "year": 1979,
            "director": "Andrei Tarkovsky",
            "genre": "science fiction",
            "rating": 9.9,
        },
    ),
]
vectorstore = Chroma.from_documents(docs, embeddings)

#Creating our self-querying retriever
Now we can instantiate our retriever. 
To do this we'll need to provide some information upfront about the metadata fields 
that our documents support and a short description of the document contents.

from langchain.chains.query_constructor.schema import AttributeInfo
from langchain.retrievers.self_query.base import SelfQueryRetriever
from langchain_openai import OpenAI

metadata_field_info = [
    AttributeInfo(
        name="genre",
        description="The genre of the movie",
        type="string or list[string]",
    ),
    AttributeInfo(
        name="year",
        description="The year the movie was released",
        type="integer",
    ),
    AttributeInfo(
        name="director",
        description="The name of the movie director",
        type="string",
    ),
    AttributeInfo(
        name="rating", description="A 1-10 rating for the movie", type="float"
    ),
]
document_content_description = "Brief summary of a movie"
llm = OpenAI(temperature=0)
retriever = SelfQueryRetriever.from_llm(
    llm, vectorstore, document_content_description, metadata_field_info, verbose=True
)

# This example only specifies a relevant query
retriever.invoke("What are some movies about dinosaurs")

# This example only specifies a filter
retriever.invoke("I want to watch a movie rated higher than 8.5")

query=' ' filter=Comparison(comparator=<Comparator.GT: 'gt'>, attribute='rating', value=8.5)

# This example specifies a query and a filter
retriever.invoke("Has Greta Gerwig directed any movies about women")
query='women' filter=Comparison(comparator=<Comparator.EQ: 'eq'>, attribute='director', value='Greta Gerwig')

# This example specifies a composite filter
retriever.invoke("What's a highly rated (above 8.5) science fiction film?")

query=' ' filter=Operation(operator=<Operator.AND: 'and'>, arguments=[Comparison(comparator=<Comparator.EQ: 'eq'>, attribute='genre', value='science fiction'), Comparison(comparator=<Comparator.GT: 'gt'>, attribute='rating', value=8.5)])

# This example specifies a query and composite filter
retriever.invoke(
    "What's a movie after 1990 but before 2005 that's all about toys, and preferably is animated"
)

query='toys' filter=Operation(operator=<Operator.AND: 'and'>, arguments=[Comparison(comparator=<Comparator.GT: 'gt'>, attribute='year', value=1990), Comparison(comparator=<Comparator.LT: 'lt'>, attribute='year', value=2005), Comparison(comparator=<Comparator.EQ: 'eq'>, attribute='genre', value='animated')])


We can also use the self query retriever to specify k: the number of documents to fetch.

We can do this by passing enable_limit=True to the constructor.

retriever = SelfQueryRetriever.from_llm(
    llm,
    vectorstore,
    document_content_description,
    metadata_field_info,
    enable_limit=True,
    verbose=True,
)

# This example only specifies a relevant query
retriever.invoke("what are two movies about dinosaurs")

query='dinosaur' filter=None

##How to use the LangChain indexing API
The indexing API lets you load and keep in sync documents from any source into a vector store. 
Specifically, it helps:
    Avoid writing duplicated content into the vector store
    Avoid re-writing unchanged content
    Avoid re-computing embeddings over unchanged content

LangChain indexing makes use of a record manager (RecordManager) 
that keeps track of document writes into the vector store.

When indexing content, hashes are computed for each document, 
and the following information is stored in the record manager:
    the document hash (hash of both page content and metadata)
    write time
    the source id -- each document should include information in its metadata 
    to allow us to determine the ultimate source of this document

#Deletion modes
When indexing documents into a vector store, it's possible that some existing documents 
in the vector store should be deleted. In certain situations you may want to remove any existing documents 
that are derived from the same sources as the new documents being indexed. In others you may want to delete 
all existing documents wholesale. The indexing API deletion modes let you pick the behavior you want:

None does not do any automatic clean up, allowing the user to manually do clean up of old content.

incremental, full and scoped_full offer the following automated clean up:
    If the content of the source document or derived documents has changed, 
    all 3 modes will clean up (delete) previous versions of the content.
    
    If the source document has been deleted (meaning it is not included in the documents currently being 
    indexed), the full cleanup mode will delete it from the vector store correctly, 
    but the incremental and scoped_full mode will not.

When content is mutated (e.g., the source PDF file was revised) there will be a period of time during 
indexing when both the new and old versions may be returned to the user. 
This happens after the new content was written, but before the old version was deleted.
    incremental indexing minimizes this period of time as it is able to do clean up continuously, as it writes.
    full and scoped_full mode does the clean up after all batches have been written.

Requirements
    Do not use with a store that has been pre-populated with content independently of the indexing API, 
    as the record manager will not know that records have been inserted previously.
    
    Only works with LangChain vectorstore's that support:
        document addition by id (add_documents method with ids argument)
        delete by id (delete method with ids argument)

Compatible Vectorstores: Aerospike, AnalyticDB, AstraDB, AwaDB, AzureCosmosDBNoSqlVectorSearch, 
AzureCosmosDBVectorSearch, AzureSearch, Bagel, Cassandra, Chroma, CouchbaseVectorStore, DashVector, 
DatabricksVectorSearch, DeepLake, Dingo, ElasticVectorSearch, ElasticsearchStore, FAISS, HanaDB, Milvus, 
MongoDBAtlasVectorSearch, MyScale, OpenSearchVectorSearch, PGVector, Pinecone, Qdrant, Redis, Rockset, ScaNN, 
SingleStoreDB, SupabaseVectorStore, SurrealDBStore, TimescaleVector, Vald, VDMS, Vearch, VespaStore, Weaviate, 
Yellowbrick, ZepVectorStore, TencentVectorDB, OpenSearchVectorSearch.


from langchain.indexes import SQLRecordManager, index
from langchain_core.documents import Document
from langchain_elasticsearch import ElasticsearchStore
from langchain_openai import OpenAIEmbeddings


Initialize a vector store and set up the embeddings:

collection_name = "test_index"
embedding = OpenAIEmbeddings()

from langchain_chroma import Chroma

vector_store = Chroma(
    collection_name=collection_name,
    embedding_function=embeddings,
    persist_directory="./chroma_langchain_db",  # Where to save data locally, remove if not necessary
)


Initialize a record manager with an appropriate namespace.
Suggestion: Use a namespace that takes into account both the vector store and the collection name 
in the vector store; e.g., 'redis/my_docs', 'chromadb/my_docs' or 'postgres/my_docs'.

namespace = f"chromadb/{collection_name}"
record_manager = SQLRecordManager(
    namespace, db_url="sqlite:///record_manager_cache.sql"
)

Create a schema before using the record manager.

record_manager.create_schema()

Let's index some test documents:

doc1 = Document(page_content="kitty", metadata={"source": "kitty.txt"})
doc2 = Document(page_content="doggy", metadata={"source": "doggy.txt"})

Indexing into an empty vector store:

def _clear():
    """Hacky helper method to clear content. See the `full` mode section to to understand why it works."""
    index([], record_manager, vectorstore, cleanup="full", source_id_key="source")

##None deletion mode
This mode does not do automatic clean up of old versions of content; 
however, it still takes care of content de-duplication.

_clear()
index(
    [doc1, doc1, doc1, doc1, doc1],
    record_manager,
    vectorstore,
    cleanup=None,
    source_id_key="source",
)
#{'num_added': 1, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 0}

_clear()
index([doc1, doc2], record_manager, vectorstore, cleanup=None, source_id_key="source")
#{'num_added': 2, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 0}

Second time around all content will be skipped:

index([doc1, doc2], record_manager, vectorstore, cleanup=None, source_id_key="source")
#{'num_added': 0, 'num_updated': 0, 'num_skipped': 2, 'num_deleted': 0}

##"incremental" deletion mode
_clear()

index(
    [doc1, doc2],
    record_manager,
    vectorstore,
    cleanup="incremental",
    source_id_key="source",
)

{'num_added': 2, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 0}

Indexing again should result in both documents getting skipped -- also skipping the embedding operation!

index(
    [doc1, doc2],
    record_manager,
    vectorstore,
    cleanup="incremental",
    source_id_key="source",
)

#{'num_added': 0, 'num_updated': 0, 'num_skipped': 2, 'num_deleted': 0}

If we provide no documents with incremental indexing mode, nothing will change.

index([], record_manager, vectorstore, cleanup="incremental", source_id_key="source")
#{'num_added': 0, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 0}

If we mutate a document, the new version will be written and all old versions sharing 
the same source will be deleted.

changed_doc_2 = Document(page_content="puppy", metadata={"source": "doggy.txt"})
index(
    [changed_doc_2],
    record_manager,
    vectorstore,
    cleanup="incremental",
    source_id_key="source",
)
#{'num_added': 1, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 1}

##"full" deletion mode
In full mode the user should pass the full universe of content that should be indexed into the indexing function.

Any documents that are not passed into the indexing function 
and are present in the vectorstore will be deleted!

This behavior is useful to handle deletions of source documents.

_clear()

all_docs = [doc1, doc2]
index(all_docs, record_manager, vectorstore, cleanup="full", source_id_key="source")
#{'num_added': 2, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 0}

Say someone deleted the first doc:

del all_docs[0]

all_docs
#[Document(page_content='doggy', metadata={'source': 'doggy.txt'})]

Using full mode will clean up the deleted content as well.
index(all_docs, record_manager, vectorstore, cleanup="full", source_id_key="source")
#{'num_added': 0, 'num_updated': 0, 'num_skipped': 1, 'num_deleted': 1}

##Source
The metadata attribute contains a field called source. 
This source should be pointing at the ultimate provenance associated with the given document.

For example, if these documents are representing chunks of some parent document, 
the source for both documents should be the same and reference the parent document.

In general, source should always be specified. Only use a None, 
if you never intend to use incremental mode, and for some reason can't specify the source field correctly.

from langchain_text_splitters import CharacterTextSplitter

doc1 = Document(
    page_content="kitty kitty kitty kitty kitty", metadata={"source": "kitty.txt"}
)
doc2 = Document(page_content="doggy doggy the doggy", metadata={"source": "doggy.txt"})

new_docs = CharacterTextSplitter(
    separator="t", keep_separator=True, chunk_size=12, chunk_overlap=2
).split_documents([doc1, doc2])
new_docs

[Document(page_content='kitty kit', metadata={'source': 'kitty.txt'}),
 Document(page_content='tty kitty ki', metadata={'source': 'kitty.txt'}),
 Document(page_content='tty kitty', metadata={'source': 'kitty.txt'}),
 Document(page_content='doggy doggy', metadata={'source': 'doggy.txt'}),
 Document(page_content='the doggy', metadata={'source': 'doggy.txt'})]

_clear()

index(
    new_docs,
    record_manager,
    vectorstore,
    cleanup="incremental",
    source_id_key="source",
)

{'num_added': 5, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 0}

changed_doggy_docs = [
    Document(page_content="woof woof", metadata={"source": "doggy.txt"}),
    Document(page_content="woof woof woof", metadata={"source": "doggy.txt"}),
]

This should delete the old versions of documents associated with doggy.txt source 
and replace them with the new versions.

index(
    changed_doggy_docs,
    record_manager,
    vectorstore,
    cleanup="incremental",
    source_id_key="source",
)

{'num_added': 2, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 2}

vectorstore.similarity_search("dog", k=30)

[Document(page_content='woof woof', metadata={'source': 'doggy.txt'}),
 Document(page_content='woof woof woof', metadata={'source': 'doggy.txt'}),
 Document(page_content='tty kitty', metadata={'source': 'kitty.txt'}),
 Document(page_content='tty kitty ki', metadata={'source': 'kitty.txt'}),
 Document(page_content='kitty kit', metadata={'source': 'kitty.txt'})]

##Using with loaders
Indexing can accept either an iterable of documents or else any loader.

from langchain_core.document_loaders import BaseLoader


class MyCustomLoader(BaseLoader):
    def lazy_load(self):
        text_splitter = CharacterTextSplitter(
            separator="t", keep_separator=True, chunk_size=12, chunk_overlap=2
        )
        docs = [
            Document(page_content="woof woof", metadata={"source": "doggy.txt"}),
            Document(page_content="woof woof woof", metadata={"source": "doggy.txt"}),
        ]
        yield from text_splitter.split_documents(docs)

    def load(self):
        return list(self.lazy_load())


_clear()

loader = MyCustomLoader()

loader.load()

[Document(page_content='woof woof', metadata={'source': 'doggy.txt'}),
 Document(page_content='woof woof woof', metadata={'source': 'doggy.txt'})]

index(loader, record_manager, vectorstore, cleanup="full", source_id_key="source")

{'num_added': 2, 'num_updated': 0, 'num_skipped': 0, 'num_deleted': 0}

vectorstore.similarity_search("dog", k=30)

[Document(page_content='woof woof', metadata={'source': 'doggy.txt'}),
 Document(page_content='woof woof woof', metadata={'source': 
###ADVANCED : Understanding the basic structure of RAG
https://github.com/LangChain-OpenTutorial/LangChain-OpenTutorial/blob/main/12-RAG/01-RAG-Basic-PDF.ipynb

1. Pre-processing - Steps 1 to 4
https://raw.githubusercontent.com/LangChain-OpenTutorial/LangChain-OpenTutorial/a148ed0be7412532ba9c1f1cb81cf8d8f9c9f79f/12-RAG/assets/12-rag-rag-basic-pdf-rag-process-01.png

The pre-processing stage involves four steps to load, split, embed, and store documents i
nto a Vector DB (database).
    Step 1: Document Load : Load the document content.
    Step 2: Text Split : Split the document into chunks based on specific criteria.
    Step 3: Embedding : Generate embeddings for the chunks and prepare them for storage.
    Step 4: Vector DB Storage : Store the embedded chunks in the database.

2. RAG Execution (RunTime) - Steps 5 to 8
https://raw.githubusercontent.com/LangChain-OpenTutorial/LangChain-OpenTutorial/a148ed0be7412532ba9c1f1cb81cf8d8f9c9f79f/12-RAG/assets/12-rag-rag-basic-pdf-rag-process-02.png

    Step 5: Retriever : Define a retriever to fetch results from the database based on the input query. 
    
    Retrievers use search algorithms and are categorized as dense or sparse:
        Dense : Similarity-based search.
        Sparse : Keyword-based search.

    Step 6: Prompt : Create a prompt for executing RAG. 
    The context in the prompt includes content retrieved from the document. Through prompt engineering, 
    you can specify the format of the answer.

    Step 7: LLM : Define the language model (e.g., GPT-3.5, GPT-4, Claude).

    Step 8: Chain : Create a chain that connects the prompt, LLM, and output.



from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

# Step 1: Load Documents
loader = PyMuPDFLoader("./data/A European Approach to Artificial Intelligence - A Policy Perspective.pdf")
docs = loader.load()
print(f"Number of pages in the document: {len(docs)}")
print(docs[10].page_content)

#Check the metadata.
docs[10].__dict__

{'id': None,
 'metadata': {'source': './data/A European Approach to Artificial Intelligence - A Policy Perspective.pdf',
  'file_path': './data/A European Approach to Artificial Intelligence - A Policy Perspective.pdf',
  'page': 10,
 
 'type': 'Document'}

# Step 2: Split Documents
The RecursiveCharacterTextSplitter works by taking a list of characters and attempting to split 
the text into smaller pieces based on that list. It continues splitting until the pieces 
are sufficiently small.

By default, the character list is ['\n\n', '\n', ' ", "'], which means it recursively splits 
in the following order: paragraph -> sentence -> word. This prioritizes keeping paragraphs, 
then sentences, then words together as much as possible, as these are considered 
the most semantically related units.

Here's a summary of how it works:
    Splitting is done by a list of characters ([‘\n\n’, ‘\n’, ‘ “, ”’]).
    Chunk size is measured by the number of characters.

Now, create a RecursiveCharacterTextSplitter with the following parameters:
    chunk_size = 250 (limits each chunk to 250 characters)
    chunk_overlap = 50 (allows 50 characters of overlap between chunks)
    length_function = len() (specifies that built-in len() function for length calculation)
    is_separator_regex = False (disables regular expression separators).


    
text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
split_documents = text_splitter.split_documents(docs)
print(f"Number of split chunks: {len(split_documents)}")


# Step 3: Generate Embeddings
embeddings = OpenAIEmbeddings()

# Step 4: Create and Save the Database
# Create a vector store.
vectorstore = FAISS.from_documents(documents=split_documents, embedding=embeddings)

for doc in vectorstore.similarity_search("URBAN MOBILITY"):
    print(doc.page_content)



# Step 5: Create Retriever
# Search and retrieve information contained in the documents.
retriever = vectorstore.as_retriever()

Send a query to the retriever and check the resulting chunks.

retriever.invoke("What is the phased implementation timeline for the EU AI Act?")

# Step 6: Create Prompt
prompt = PromptTemplate.from_template(
    """You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, just say that you don't know. 

#Context: 
{context}

#Question:
{question}

#Answer:"""
)

# Step 7: Setup LLM
llm = ChatOpenAI(model_name="gpt-4o", temperature=0)

# Step 8: Create Chain
chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

Input a query (question) into the created chain and execute it.

# Run Chain
# Input a query about the document and print the response.
question = "Where has the application of AI in healthcare been confined to so far?"
response = chain.invoke(question)
print(response)



###ADVANCED: Another RAG -Web News Based QA(Question-Answering) Chatbot

This guide builds a RAG pipeline using OpenAI Chat models, Embedding, and FAISS vector store, 
utilizing Forbes News pages and Naver News pages which is the most popular news website in Korea.


import bs4
from langchain import hub
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import WebBaseLoader
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

We implement a process that loads web page content, splits text into chunks for indexing, 
and then searches for relevant text snippets to generate new content.

WebBaseLoader uses bs4.SoupStrainer to parse only the necessary parts from the specified web page.

#legacy 
import bs4
from urllib.request import urlopen as request
from bs4 import BeautifulSoup as soup

url = 'https://www.newegg.com/p/pl?d=graphics+cards'

# opening connection, grabbing the HTML from the page
client = request(url)
page_html = client.read()
client.close()

page_soup = soup(page_html, 'html.parser')
cells = page_soup.find_all("div", attrs={"class": "item-cell"})

#With souptrainer 
import bs4
from urllib.request import urlopen as request
from bs4 import BeautifulSoup as soup
from bs4 import SoupStrainer as strainer

url = 'https://www.newegg.com/p/pl?d=graphics+cards'

# opening connection, grabbing the HTML from the page
client = request(url)
page_html = client.read()
client.close()

only_item_cells = strainer("div", attrs={"class": "item-cell"})
page_soup = soup(page_html, 'html.parser', parse_only=only_item_cells)
page_soup_list = list(page_soup)




# Load news article content, split into chunks, and index them.

url = "https://www.forbes.com/sites/rashishrivastava/2024/05/21/the-prompt-scarlett-johansson-vs-openai/"
loader = WebBaseLoader(
    web_paths=(url,),  #many Urls can be given 
    bs_kwargs=dict(
        parse_only=bs4.SoupStrainer(
            "div",
            attrs={"class": ["article-body fs-article fs-premium fs-responsive-text current-article font-body color-body bg-base font-accent article-subtype__masthead",
                             "header-content-container masthead-header__container"]},
        )
    ),
)
docs = loader.load()

docs = loader.load()
print(f"Number of documents: {len(docs)}")
docs

Number of documents: 1



RecursiveCharacterTextSplitter splits documents into chunks of specified size.


text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)

splits = text_splitter.split_documents(docs)
len(splits)

12

Vector stores like FAISS or Chroma generate vector representations of documents based on these chunks.

# Create a vector store.
vectorstore = FAISS.from_documents(documents=splits, embedding=OpenAIEmbeddings())

# Search for and generate information contained in the news.
retriever = vectorstore.as_retriever()

The retriever created through vectorstore.as_retriever() generates new content 
using the prompt fetched with hub.pull and the ChatOpenAI model.

Finally, StrOutputParser parses the generated results into a string.

from langchain_core.prompts import PromptTemplate

prompt = PromptTemplate.from_template(
    """You are a friendly AI assistant performing Question-Answering. 
Your mission is to answer the given question based on the provided context.
Please answer the question using the following retrieved context. 
If you cannot find the answer in the given context or if you don't know the answer, please respond with 'The information related to the question cannot be found in the provided information'.
Please answer in English. 
However, keep technical terms and names in their original form without translation.

#Question: 
{question} 

#Context: 
{context} 

#Answer:"""
)



# English rag prompt

prompt = hub.pull("rlm/rag-prompt")

llm = ChatOpenAI(model_name="gpt-4o", temperature=0)


# Create a chain.
rag_chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

To use streaming output, use stream_response.

stream_response = rag_chain.stream_response(
    {"question": "What is the latest news about AI?"}
)

for chunk in stream_response:
    print(chunk)

answer = rag_chain.invoke("What is the latest news about AI?")
print(answer)

answer = rag_chain.invoke("What is the main idea of latest news about?")
print(answer)

answer = rag_chain.invoke("Why did OpenAI and Scarlett Johansson have a conflict?")
print(answer)

###ADVANCED : Agentic Ai  - Legacy implementation without Langgraph 
https://python.langchain.com/docs/how_to/agent_executor/

By themselves, language models can't take actions - they just output text. 
A big use case for LangChain is creating agents.

Agents are systems that use an LLM as a reasoning engine to determine which actions to take 
and what the inputs to those actions should be. The results of those actions can then be fed back 
into the agent and it determines whether more actions are needed, or whether it is okay to finish

Concepts we will cover are:
    Using language models, in particular their tool calling ability
    
    Creating a Retriever to expose specific information to our agent
    
    Using a Search Tool to look up things online
    
    Chat History, which allows a chatbot to "remember" past interactions 
    and take them into account when responding to follow-up questions.
    
    Debugging and tracing your application using LangSmith

##Tavily
We have a built-in tool in LangChain to easily use Tavily search engine as tool. 
Note that this requires an API key - they have a free tier, 
but if you don't have one or don't want to create one, you can always ignore this step.

Once you create your API key, you will need to export that as:

export TAVILY_API_KEY="..."

from langchain_community.tools.tavily_search import TavilySearchResults

search = TavilySearchResults(max_results=2)

search.invoke("what is the weather in SF")

[{'url': 'https://www.weatherapi.com/',
}}

##Retriever
We will also create a retriever over some data of our own. 


from langchain_community.document_loaders import WebBaseLoader
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

loader = WebBaseLoader("https://docs.smith.langchain.com/overview")
docs = loader.load()
documents = RecursiveCharacterTextSplitter(
    chunk_size=1000, chunk_overlap=200
).split_documents(docs)
vector = FAISS.from_documents(documents, OpenAIEmbeddings())
retriever = vector.as_retriever()

retriever.invoke("how to upload a dataset")[0]

Now that we have populated our index that we will do doing retrieval over, 
we can easily turn it into a tool (the format needed for an agent to properly use it)

from langchain.tools.retriever import create_retriever_tool

langchain_core.tools.retriever.create_retriever_tool(retriever: BaseRetriever, 
    name: str, 
    description: str, *, document_prompt: BasePromptTemplate | None = None, 
    document_separator: str = '\n\n', response_format: Literal['content', 
    'content_and_artifact'] = 'content') → Tool


retriever_tool = create_retriever_tool(
    retriever,
    "langsmith_search",
    "Search for information about LangSmith. For any questions about LangSmith, you must use this tool!",
)

##Tools
Now that we have created both, we can create a list of tools that we will use downstream.

tools = [search, retriever_tool]

##Using Language Models

from langchain.chat_models import init_chat_model

model = init_chat_model("gpt-4", model_provider="openai")

You can call the language model by passing in a list of messages. 
By default, the response is a content string.

from langchain_core.messages import HumanMessage

response = model.invoke([HumanMessage(content="hi!")])
response.content
#'Hello! How can I assist you today?'


model_with_tools = model.bind_tools(tools)

We can now call the model. Let's first call it with a normal message, and see how it responds. 
We can look at both the content field as well as the tool_calls field.
Empty tool_calls means tools are not used 

response = model_with_tools.invoke([HumanMessage(content="Hi!")])

print(f"ContentString: {response.content}")
print(f"ToolCalls: {response.tool_calls}")

ContentString: Hello! How can I assist you today?
ToolCalls: []

Now, let's try calling it with some input that would expect a tool to be called.

response = model_with_tools.invoke([HumanMessage(content="What's the weather in SF?")])

print(f"ContentString: {response.content}")
print(f"ToolCalls: {response.tool_calls}")
#output 
ContentString: 
ToolCalls: [{'name': 'tavily_search_results_json', 'args': {'query': 'current weather in San Francisco'}, 'id': 'call_4HteVahXkRAkWjp6dGXryKZX'}]

We can see that there's now no content, but there is a tool call! It wants us to call the Tavily Search tool.

This isn't calling that tool yet - it's just telling us to. 
In order to actually calll it, we'll want to create our agent.

##Create the agent
Now that we have defined the tools and the LLM, we can create the agent. 

We will be using a tool calling agent 


class langchain.agents.agent.AgentExecutor(Chain):
    """Runnable. Agent that is using tools."""

    agent: Union[BaseSingleActionAgent, BaseMultiActionAgent, Runnable]
    """The agent to run for creating a plan and determining actions
    to take at each step of the execution loop."""
    
    tools: Sequence[BaseTool]
    """The valid tools the agent can call."""
    
    return_intermediate_steps: bool = False
    """Whether to return the agent's trajectory of intermediate steps
    at the end in addition to the final output."""
    
    max_iterations: Optional[int] = 15
    """The maximum number of steps to take before ending the execution
    loop.
    Setting to 'None' could lead to an infinite loop."""
    
    max_execution_time: Optional[float] = None
    """The maximum amount of wall clock time to spend in the execution
    loop.
    """
    
    early_stopping_method: str = "force"
    """The method to use for early stopping if the agent never
    returns `AgentFinish`. Either 'force' or 'generate'.

    `"force"` returns a string saying that it stopped because it met a
        time or iteration limit.

    `"generate"` calls the agent's LLM Chain one final time to generate
        a final answer based on the previous steps.
    """
    handle_parsing_errors: Union[bool, str, Callable[[OutputParserException], str]] = (
        False
    )
    """How to handle errors raised by the agent's output parser.
    Defaults to `False`, which raises the error.
    If `true`, the error will be sent back to the LLM as an observation.
    If a string, the string itself will be sent to the LLM as an observation.
    If a callable function, the function will be called with the exception
     as an argument, and the result of that function will be passed to the agent
      as an observation.
    """
    trim_intermediate_steps: Union[
        int, Callable[[List[Tuple[AgentAction, str]]], List[Tuple[AgentAction, str]]]
    ] = -1
    """How to trim the intermediate steps before returning them.
    Defaults to -1, which means no trimming.
    """


langchain.agents.tool_calling_agent.base.create_tool_calling_agent(
    llm: ~langchain_core.language_models.base.BaseLanguageModel, 
    tools: ~typing.Sequence[~langchain_core.tools.base.BaseTool], 
    prompt: ~langchain_core.prompts.chat.ChatPromptTemplate, 
    *, message_formatter: ~typing.Callable[[~typing.Sequence[~typing.Tuple[~langchain_core.agents.AgentAction, str]]], ~typing.List[~langchain_core.messages.base.BaseMessage]] 
    = <function format_to_tool_messages>) → Runnable
    
    #Example 
    from langchain.agents import AgentExecutor, create_tool_calling_agent, tool
    from langchain_anthropic import ChatAnthropic
    from langchain_core.prompts import ChatPromptTemplate

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "You are a helpful assistant"),
            ("placeholder", "{chat_history}"),
            ("human", "{input}"),
            ("placeholder", "{agent_scratchpad}"),
        ]
    )
    model = ChatAnthropic(model="claude-3-opus-20240229")

    @tool
    def magic_function(input: int) -> int:
        """Applies a magic function to an input."""
        return input + 2

    tools = [magic_function]

    agent = create_tool_calling_agent(model, tools, prompt)
    
    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

    agent_executor.invoke({"input": "what is the value of magic_function(3)?"})

    # Using with chat history
    from langchain_core.messages import AIMessage, HumanMessage
    agent_executor.invoke(
        {
            "input": "what's my name?",
            "chat_history": [
                HumanMessage(content="hi! my name is bob"),
                AIMessage(content="Hello Bob! How can I assist you today?"),
            ],
        }
    )


We can first choose the prompt we want to use to guide the agent.

If you want to see the contents of this prompt and have access to LangSmith, you can go to:
https://smith.langchain.com/hub/hwchase17/openai-functions-agent

from langchain import hub

# set the LANGSMITH_API_KEY environment variable (create key in settings)
# Get the prompt to use - you can modify this!
prompt = hub.pull("hwchase17/openai-functions-agent")
prompt.messages
#Output - contains ChatPromptTemplate with four message 
[SystemMessagePromptTemplate(prompt=PromptTemplate(input_variables=[], template='You are a helpful assistant')),
 MessagesPlaceholder(variable_name='chat_history', optional=True),
 HumanMessagePromptTemplate(prompt=PromptTemplate(input_variables=['input'], template='{input}')),
 MessagesPlaceholder(variable_name='agent_scratchpad')]

Now, we can initialize the agent with the LLM, the prompt, and the tools. 
The agent is responsible for taking in input and deciding what actions to take. 

Crucially, the Agent does not execute those actions - that is done by the AgentExecutor (next step). 

Note that we are passing in the model, not model_with_tools. 
That is because create_tool_calling_agent will call .bind_tools for us under the hood.

from langchain.agents import create_tool_calling_agent

agent = create_tool_calling_agent(model, tools, prompt)

Finally, we combine the agent (the brains) with the tools inside the AgentExecutor 
(which will repeatedly call the agent and execute tools).

from langchain.agents import AgentExecutor

agent_executor = AgentExecutor(agent=agent, tools=tools)

##Run the agent
We can now run the agent on a few queries! 
Note that for now, these are all stateless queries (it won't remember previous interactions).

First up, let's how it responds when there's no need to call a tool:

agent_executor.invoke({"input": "hi!"})

{'input': 'hi!', 'output': 'Hello! How can I assist you today?'}

In order to see exactly what is happening under the hood (and to make sure it's not calling a tool) 
we can take a look at the LangSmith trace

Let's now try it out on an example where it should be invoking the retriever

agent_executor.invoke({"input": "how can langsmith help with testing?"})

Let's take a look at the LangSmith trace to make sure it's actually calling that.

Now let's try one where it needs to call the search tool:

agent_executor.invoke({"input": "whats the weather in sf?"})

{'input': 'whats the weather in sf?',
 'output': 'The current weather in San Francisco is partly cloudy with a temperature of 16.1°C (61.0°F). The wind is coming from the WNW at a speed of 10.5 mph. The humidity is at 67%. [source](https://www.weatherapi.com/)'}

We can check out the LangSmith trace to make sure it's calling the search tool effectively.


##Adding in memory
As mentioned earlier, this agent is stateless. This means it does not remember previous interactions. 
To give it memory we need to pass in previous chat_history. Note: it needs to be called chat_history 
because of the prompt we are using. If we use a different prompt, we could change the variable name

# Here we pass in an empty list of messages for chat_history because it is the first message in the chat
agent_executor.invoke({"input": "hi! my name is bob", "chat_history": []})

{'input': 'hi! my name is bob',
 'chat_history': [],
 'output': 'Hello Bob! How can I assist you today?'}

from langchain_core.messages import AIMessage, HumanMessage

agent_executor.invoke(
    {
        "chat_history": [
            HumanMessage(content="hi! my name is bob"),
            AIMessage(content="Hello Bob! How can I assist you today?"),
        ],
        "input": "what's my name?",
    }
)

{'chat_history': [HumanMessage(content='hi! my name is bob'),
  AIMessage(content='Hello Bob! How can I assist you today?')],
 'input': "what's my name?",
 'output': 'Your name is Bob. How can I assist you further?'}

If we want to keep track of these messages automatically, 
we can wrap this in a RunnableWithMessageHistory. 

from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

store = {}

#mandatory 
def get_session_history(session_id: str) -> BaseChatMessageHistory:
    if session_id not in store:
        store[session_id] = ChatMessageHistory()
    return store[session_id]


Because we have multiple inputs, we need to specify two things:
    input_messages_key: The input key to use to add to the conversation history.
    history_messages_key: The key to add the loaded messages into.

agent_with_chat_history = RunnableWithMessageHistory(
    agent_executor,
    get_session_history,
    input_messages_key="input",  # query has input key 
    history_messages_key="chat_history", 
)

agent_with_chat_history.invoke(
    {"input": "hi! I'm bob"},
    config={"configurable": {"session_id": "<foo>"}},
)

{'input': "hi! I'm bob",
 'chat_history': [],
 'output': 'Hello Bob! How can I assist you today?'}

agent_with_chat_history.invoke(
    {"input": "what's my name?"},
    config={"configurable": {"session_id": "<foo>"}},
)

{'input': "what's my name?",
 'chat_history': [HumanMessage(content="hi! I'm bob"),
  AIMessage(content='Hello Bob! How can I assist you today?')],
 'output': 'Your name is Bob.'}

Example LangSmith trace: https://smith.langchain.com/public/98c8d162-60ae-4493-aa9f-992d87bd0429/r


###ADVANCED: ReAct-style agent-  legacy LangChain agents and  LangGraph agents 
In LangGraph, the graph replaces LangChain's agent executor. It manages the agent's cycles
and tracks the scratchpad as messages within its state. 
 
The LangChain "agent" corresponds to the prompt and LLM you've provided.
##Legacy using AgentExecutor
For basic creation and usage of a tool-calling ReAct(Reasoning and Action)-style agent, 
the functionality is the same. 

First, let's define a model and tool(s), then we'll use those to create an agent.

from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

model = ChatOpenAI(model="gpt-4o")


@tool
def magic_function(input: int) -> int:
    """Applies a magic function to an input."""
    return input + 2


tools = [magic_function]

query = "what is the value of magic_function(3)?"

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant"),
        ("human", "{input}"),
        # Placeholders fill up a **list** of messages
        ("placeholder", "{agent_scratchpad}"),
    ]
)


agent = create_tool_calling_agent(model, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools)

agent_executor.invoke({"input": query})

{'input': 'what is the value of magic_function(3)?',
 'output': 'The value of `magic_function(3)` is 5.'}

##Langraph 
LangGraph's react agent executor manages a state that is defined by a list of messages. 
It will continue to process the list until there are no tool calls in the agent's output. 

To kick it off, we input a list of messages. 
The output will contain the entire state of the graph-- in this case, the conversation history.

from langgraph.prebuilt import create_react_agent

langgraph_agent_executor = create_react_agent(model, tools)


messages = langgraph_agent_executor.invoke({"messages": [("human", query)]})
{
    "input": query,
    "output": messages["messages"][-1].content,
}
#output 

{'input': 'what is the value of magic_function(3)?',
 'output': 'The value of `magic_function(3)` is 5.'}

message_history = messages["messages"]

new_query = "Pardon?"

messages = langgraph_agent_executor.invoke(
    {"messages": message_history + [("human", new_query)]}
)
{
    "input": new_query,
    "output": messages["messages"][-1].content,
}
#output 
{'input': 'Pardon?',
 'output': 'The result of applying `magic_function` to the input value 3 is 5.'}

##Prompt Templates
With legacy LangChain agents you have to pass in a prompt template. 
You can use this to control the agent.

With LangGraph react agent executor, by default there is no prompt. 

You can achieve similar control over the agent in a few ways:
    Pass in a system message as input
    Initialize the agent with a system message
    
    Initialize the agent with a function to transform messages in the graph state 
    before passing to the model.
    
    Initialize the agent with a Runnable to transform messages in the graph state before passing 
    to the model. This includes passing prompt templates as well.

LangGraph's prebuilt create_react_agent does not take a prompt template directly as a parameter, 
but instead takes a prompt parameter. 

This modifies the graph state before the llm is called, and can be one of four values:
    A SystemMessage, which is added to the beginning of the list of messages.
    
    A string, which is converted to a SystemMessage and added to the beginning of the list of messages.
    
    A Callable, which should take in full graph state. 
    The output is then passed to the language model.
    
    Or a Runnable, which should take in full graph state. 
    The output is then passed to the language model.


from langchain_core.messages import SystemMessage
from langgraph.prebuilt import create_react_agent

system_message = "You are a helpful assistant. Respond only in Spanish."
# This could also be a SystemMessage object
# system_message = SystemMessage(content="You are a helpful assistant. Respond only in Spanish.")

langgraph_agent_executor = create_react_agent(model, tools, prompt=system_message)


messages = langgraph_agent_executor.invoke({"messages": [("user", query)]})

We can also pass in an arbitrary function or a runnable. This function/runnable should take in a the graph 
state and output a list of messages. We can do all types of arbitrary formatting of messages here. In this 
case, let's add a SystemMessage to the start of the list of messages and append another user 
message at the end.

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.prebuilt import create_react_agent
from langgraph.prebuilt.chat_agent_executor import AgentState

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant. Respond only in Spanish."),
        ("placeholder", "{messages}"),
        ("user", "Also say 'Pandamonium!' after the answer."),
    ]
)

# alternatively, this can be passed as a function, e.g.
# def prompt(state: AgentState):
#     return (
#         [SystemMessage(content="You are a helpful assistant. Respond only in Spanish.")] +
#         state["messages"] +
#         [HumanMessage(content="Also say 'Pandamonium!' after the answer.")]
#     )

#ChatPromptTemplate is callable, which invokes .invoke()
langgraph_agent_executor = create_react_agent(model, tools, prompt=prompt)


messages = langgraph_agent_executor.invoke({"messages": [("human", query)]})
print(
    {
        "input": query,
        "output": messages["messages"][-1].content,
    }
)


{'input': 'what is the value of magic_function(3)?', 'output': 'El valor de magic_function(3) es 5. ¡Pandamonium!'}

##Memory In LangChain

With LangChain's AgentExecutor, you could add chat Memory so it can engage in a multi-turn conversation.

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

model = ChatOpenAI(model="gpt-4o")
memory = InMemoryChatMessageHistory(session_id="test-session")
prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant."),
        # First put the history
        ("placeholder", "{chat_history}"),
        # Then the new input
        ("human", "{input}"),
        # Finally the scratchpad
        ("placeholder", "{agent_scratchpad}"),
    ]
)


@tool
def magic_function(input: int) -> int:
    """Applies a magic function to an input."""
    return input + 2


tools = [magic_function]


agent = create_tool_calling_agent(model, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools)

agent_with_chat_history = RunnableWithMessageHistory(
    agent_executor,
    # This is needed because in most real world scenarios, a session id is needed
    # It isn't really used here because we are using a simple in memory ChatMessageHistory
    lambda session_id: memory,
    input_messages_key="input",
    history_messages_key="chat_history",
)

config = {"configurable": {"session_id": "test-session"}}
print(
    agent_with_chat_history.invoke(
        {"input": "Hi, I'm polly! What's the output of magic_function of 3?"}, config
    )["output"]
)
print("---")
print(agent_with_chat_history.invoke({"input": "Remember my name?"}, config)["output"])
print("---")
print(
    agent_with_chat_history.invoke({"input": "what was that output again?"}, config)[
        "output"
    ]
)

##Memory in In LangGraph
Memory is just persistence, aka checkpointing.

Add a checkpointer to the agent and you get chat memory for free.

from langgraph.checkpoint.memory import MemorySaver  # an in-memory checkpointer
from langgraph.prebuilt import create_react_agent

system_message = "You are a helpful assistant."
# This could also be a SystemMessage object
# system_message = SystemMessage(content="You are a helpful assistant. Respond only in Spanish.")

memory = MemorySaver()
langgraph_agent_executor = create_react_agent(
    model, tools, prompt=system_message, checkpointer=memory
)

config = {"configurable": {"thread_id": "test-thread"}}
print(
    langgraph_agent_executor.invoke(
        {
            "messages": [
                ("user", "Hi, I'm polly! What's the output of magic_function of 3?")
            ]
        },
        config,
    )["messages"][-1].content
)
print("---")
print(
    langgraph_agent_executor.invoke(
        {"messages": [("user", "Remember my name?")]}, config
    )["messages"][-1].content
)
print("---")
print(
    langgraph_agent_executor.invoke(
        {"messages": [("user", "what was that output again?")]}, config
    )["messages"][-1].content
)


##Iterating through steps - In LangChain
With LangChain's AgentExecutor, you could iterate over the steps using the stream 
(or async astream) methods or the iter method. LangGraph supports stepwise iteration using stream

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

model = ChatOpenAI(model="gpt-4o")


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant."),
        ("human", "{input}"),
        # Placeholders fill up a **list** of messages
        ("placeholder", "{agent_scratchpad}"),
    ]
)


@tool
def magic_function(input: int) -> int:
    """Applies a magic function to an input."""
    return input + 2


tools = [magic_function]

agent = create_tool_calling_agent(model, tools, prompt=prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools)

for step in agent_executor.stream({"input": query}):
    print(step)



##Iterating through steps - In LangGraph

In LangGraph, things are handled natively using stream or the asynchronous astream method.

from langgraph.prebuilt import create_react_agent
from langgraph.prebuilt.chat_agent_executor import AgentState

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant."),
        ("placeholder", "{messages}"),
    ]
)

langgraph_agent_executor = create_react_agent(model, tools, prompt=prompt)

for step in langgraph_agent_executor.stream(
    {"messages": [("human", query)]}, stream_mode="updates"
):
    print(step)


## return_intermediate_steps - In LangChain
Setting this parameter on AgentExecutor allows users to access intermediate_steps, 
which pairs agent actions (e.g., tool invocations) with their outcomes.

agent_executor = AgentExecutor(agent=agent, tools=tools, return_intermediate_steps=True)
result = agent_executor.invoke({"input": query})
print(result["intermediate_steps"])


## return_intermediate_steps - In LangGraph
By default the react agent executor in LangGraph appends all messages to the central state. 
Therefore, it is easy to see any intermediate steps by just looking at the full state.

from langgraph.prebuilt import create_react_agent

langgraph_agent_executor = create_react_agent(model, tools=tools)

messages = langgraph_agent_executor.invoke({"messages": [("human", query)]})

messages


{'messages': [HumanMessage(content='what is the value of magic_function(3)?', additional_kwargs={}, response_metadata={}, id='1abb52c2-4bc2-4d82-bd32-5a24c3976b0f'),
  AIMessage(content='', additional_kwargs={'tool_calls': [{'id': 'call_XfQD6C7rAalcmicQubkhJVFq', 'function': {'arguments': '{"input":3}', 'name': 'magic_function'}, 'type': 'function'}], 'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 14, 'prompt_tokens': 55, 'total_tokens': 69, 'completion_tokens_details': {'audio_tokens': None, 'reasoning_tokens': 0}, 'prompt_tokens_details': {'audio_tokens': None, 'cached_tokens': 0}}, 'model_name': 'gpt-4o-2024-08-06', 'system_fingerprint': 'fp_a20a4ee344', 'finish_reason': 'tool_calls', 'logprobs': None}, id='run-34f02786-5b5c-4bb1-bd9e-406c81944a24-0', tool_calls=[{'name': 'magic_function', 'args': {'input': 3}, 'id': 'call_XfQD6C7rAalcmicQubkhJVFq', 'type': 'tool_call'}], usage_metadata={'input_tokens': 55, 'output_tokens': 14, 'total_tokens': 69, 'input_token_details': {'cache_read': 0}, 'output_token_details': {'reasoning': 0}}),
  ToolMessage(content='5', name='magic_function', id='cbc9fadf-1962-4ed7-b476-348c774652be', tool_call_id='call_XfQD6C7rAalcmicQubkhJVFq'),
  AIMessage(content='The value of `magic_function(3)` is 5.', additional_kwargs={'refusal': None}, response_metadata={'token_usage': {'completion_tokens': 14, 'prompt_tokens': 78, 'total_tokens': 92, 'completion_tokens_details': {'audio_tokens': None, 'reasoning_tokens': 0}, 'prompt_tokens_details': {'audio_tokens': None, 'cached_tokens': 0}}, 'model_name': 'gpt-4o-2024-08-06', 'system_fingerprint': 'fp_a7d06e42a7', 'finish_reason': 'stop', 'logprobs': None}, id='run-547e03d2-872d-4008-a38d-b7f739a77df5-0', usage_metadata={'input_tokens': 78, 'output_tokens': 14, 'total_tokens': 92, 'input_token_details': {'cache_read': 0}, 'output_token_details': {'reasoning': 0}})]}

## max_iterations - In LangChain
AgentExecutor implements a max_iterations parameter, 
allowing users to abort a run that exceeds a specified number of iterations.

@tool
def magic_function(input: str) -> str:
    """Applies a magic function to an input."""
    return "Sorry, there was an error. Please try again."


tools = [magic_function]

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant. Respond only in Spanish."),
        ("human", "{input}"),
        # Placeholders fill up a **list** of messages
        ("placeholder", "{agent_scratchpad}"),
    ]
)

agent = create_tool_calling_agent(model, tools, prompt)
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    max_iterations=3,
)

agent_executor.invoke({"input": query})


## max_iterations - In LangGraph
In LangGraph this is controlled via recursion_limit configuration parameter.

Note that in AgentExecutor, an "iteration" includes a full turn of tool invocation and execution. 
In LangGraph, each step contributes to the recursion limit, 
so we will need to multiply by two (and add one) to get equivalent results.

If the recursion limit is reached, LangGraph raises a specific exception type, 
that we can catch and manage similarly to AgentExecutor.

from langgraph.errors import GraphRecursionError
from langgraph.prebuilt import create_react_agent

RECURSION_LIMIT = 2 * 3 + 1

langgraph_agent_executor = create_react_agent(model, tools=tools)

try:
    for chunk in langgraph_agent_executor.stream(
        {"messages": [("human", query)]},
        {"recursion_limit": RECURSION_LIMIT},
        stream_mode="values",
    ):
        print(chunk["messages"][-1])
except GraphRecursionError:
    print({"input": query, "output": "Agent stopped due to max iterations."})

##max_execution_time - In LangChain
AgentExecutor implements a max_execution_time parameter, 
allowing users to abort a run that exceeds a total time limit.

import time


@tool
def magic_function(input: str) -> str:
    """Applies a magic function to an input."""
    time.sleep(2.5)
    return "Sorry, there was an error. Please try again."


tools = [magic_function]

agent = create_tool_calling_agent(model, tools, prompt)
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    max_execution_time=2,
    verbose=True,
)

agent_executor.invoke({"input": query})


##max_execution_time -  In LangGraph

With LangGraph's react agent, you can control timeouts on two levels.

You can set a step_timeout to bound each step:

from langgraph.prebuilt import create_react_agent

langgraph_agent_executor = create_react_agent(model, tools=tools)
# Set the max timeout for each step here
langgraph_agent_executor.step_timeout = 2

try:
    for chunk in langgraph_agent_executor.stream({"messages": [("human", query)]}):
        print(chunk)
        print("------")
except TimeoutError:
    print({"input": query, "output": "Agent stopped due to a step timeout."})


The other way to set a single max timeout for an entire run is to directly 
use the python stdlib asyncio library.

import asyncio

from langgraph.prebuilt import create_react_agent

langgraph_agent_executor = create_react_agent(model, tools=tools)


async def stream(langgraph_agent_executor, inputs):
    async for chunk in langgraph_agent_executor.astream(
        {"messages": [("human", query)]}
    ):
        print(chunk)
        print("------")


try:
    task = asyncio.create_task(
        stream(langgraph_agent_executor, {"messages": [("human", query)]})
    )
    await asyncio.wait_for(task, timeout=3)
except asyncio.TimeoutError:
    print("Task Cancelled.")


##early_stopping_method - In LangChain
With LangChain's AgentExecutor, you could configure an early_stopping_method to either
return a string saying "Agent stopped due to iteration limit or time limit." ("force") 
or prompt the LLM a final time to respond ("generate").

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

model = ChatOpenAI(model="gpt-4o")


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant."),
        ("human", "{input}"),
        # Placeholders fill up a **list** of messages
        ("placeholder", "{agent_scratchpad}"),
    ]
)


@tool
def magic_function(input: int) -> int:
    """Applies a magic function to an input."""
    return "Sorry there was an error, please try again."


tools = [magic_function]

agent = create_tool_calling_agent(model, tools, prompt=prompt)
agent_executor = AgentExecutor(
    agent=agent, tools=tools, early_stopping_method="force", max_iterations=1
)

result = agent_executor.invoke({"input": query})
print("Output with early_stopping_method='force':")
print(result["output"])
#output 
Output with early_stopping_method='force':
Agent stopped due to max iterations.

##early_stopping_method -In LangGraph
In LangGraph, you can explicitly handle the response behavior outside the agent, 
since the full state can be accessed.

from langgraph.errors import GraphRecursionError
from langgraph.prebuilt import create_react_agent

RECURSION_LIMIT = 2 * 1 + 1

langgraph_agent_executor = create_react_agent(model, tools=tools)

try:
    for chunk in langgraph_agent_executor.stream(
        {"messages": [("human", query)]},
        {"recursion_limit": RECURSION_LIMIT},
        stream_mode="values",
    ):
        print(chunk["messages"][-1])
except GraphRecursionError:
    print({"input": query, "output": "Agent stopped due to max iterations."})

##trim_intermediate_steps - In LangChain
With LangChain's AgentExecutor, you could trim the intermediate steps of long-running agents 
using trim_intermediate_steps, which is either an integer (indicating the agent should keep the 
last N steps) or a custom function.

For instance, we could trim the value so the agent only sees the most recent intermediate step.

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

model = ChatOpenAI(model="gpt-4o")


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant."),
        ("human", "{input}"),
        # Placeholders fill up a **list** of messages
        ("placeholder", "{agent_scratchpad}"),
    ]
)


magic_step_num = 1


@tool
def magic_function(input: int) -> int:
    """Applies a magic function to an input."""
    global magic_step_num
    print(f"Call number: {magic_step_num}")
    magic_step_num += 1
    return input + magic_step_num


tools = [magic_function]

agent = create_tool_calling_agent(model, tools, prompt=prompt)


def trim_steps(steps: list):
    # Let's give the agent amnesia
    return []


agent_executor = AgentExecutor(
    agent=agent, tools=tools, trim_intermediate_steps=trim_steps
)


query = "Call the magic function 4 times in sequence with the value 3. You cannot call it multiple times at once."

for step in agent_executor.stream({"input": query}):
    pass


##trim_intermediate_steps - In LangGraph

We can use the prompt just as before when passing in prompt templates.

from langgraph.errors import GraphRecursionError
from langgraph.prebuilt import create_react_agent
from langgraph.prebuilt.chat_agent_executor import AgentState

magic_step_num = 1


@tool
def magic_function(input: int) -> int:
    """Applies a magic function to an input."""
    global magic_step_num
    print(f"Call number: {magic_step_num}")
    magic_step_num += 1
    return input + magic_step_num


tools = [magic_function]


def _modify_state_messages(state: AgentState):
    # Give the agent amnesia, only keeping the original user query
    return [("system", "You are a helpful assistant"), state["messages"][0]]


langgraph_agent_executor = create_react_agent(
    model, tools, prompt=_modify_state_messages
)

try:
    for step in langgraph_agent_executor.stream(
        {"messages": [("human", query)]}, stream_mode="updates"
    ):
        pass
except GraphRecursionError as e:
    print("Stopping agent prematurely due to triggering stop condition")



###ADVANCED : Agentic Ai  and Agentic RAG
Agentic RAG extends traditional RAG (Retrieval-Augmented Generation) systems by incorporating 
an agent-based approach for more sophisticated information retrieval and response generation. 
This system goes beyond simple document retrieval and response generation by enabling agents to utilize 
various tools for more intelligent information processing. 

These tools include Tavily Search for accessing up-to-date information, Python code execution capabilities, 
and custom function implementations, all integrated within the LangChain framework to provide a 
comprehensive solution for information processing and generation tasks.

pip install langchain_community langchain_openai langchain_core faiss-cpu pypdf


To use Tavily Search, you'll need to obtain an API key.

set  TAVILY_API_KEY=

#code 

from langchain_community.tools.tavily_search import TavilySearchResults

# Create a search tool instance that returns up to 6 results
search = TavilySearchResults(k=6)

# Example usage
result = search.invoke("When was the movie A.I. released and who is the director?")
print(result)

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain.document_loaders import PyPDFLoader
from langchain.tools.retriever import create_retriever_tool

# Load and process the PDF
loader = PyPDFLoader("data/What_Is_AI.pdf")

# Create text splitter
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)

# Split the document
split_docs = loader.load_and_split(text_splitter)

# Create vector store
vector = FAISS.from_documents(split_docs, OpenAIEmbeddings())

# Create retriever
retriever = vector.as_retriever()

# Create retriever tool
retriever_tool = create_retriever_tool(
    retriever,
    name="pdf_search",
    description="use this tool to search information from the PDF document",
)

retriever.invoke("What are the main limitations of AI discussed in the text?")


tools = [search, retriever_tool]

#Building the Agent
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.agents import create_tool_calling_agent, AgentExecutor

# Initialize LLM
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Define prompt template- must be in this sequence 
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful assistant. "
            "Make sure to use the `pdf_search` tool for searching information from the PDF document. "
            "If you can't find the information from the PDF document, use the `search` tool for searching information from the web.",
        ),
        ("placeholder", "{chat_history}"),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ]
)

# Create agent
agent = create_tool_calling_agent(llm, tools, prompt)

# Create agent executor
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=False)

#Implementing Chat History
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

# Create a store for session histories
store = {}


def get_session_history(session_ids):
    if session_ids not in store:
        store[session_ids] = ChatMessageHistory()
    return store[session_ids]


# Create agent with chat history
agent_with_chat_history = RunnableWithMessageHistory(
    agent_executor,
    get_session_history,
    input_messages_key="input",  # query must have this key 
    history_messages_key="chat_history", # chat history loades into this 
)

#Running Examples

def process_response(response):
    """
    Process and display streaming response from the agent.

    Args:
        response: Agent's streaming response iterator
    """
    for chunk in response:
        if chunk.get("output"):
            print(chunk["output"])
        elif chunk.get("actions"):
            for action in chunk["actions"]:
                print(f"\nTool Used: {action.tool}")
                print(f"Tool Input: {action.tool_input}")
                if action.log:
                    print(f"Tool Log: {action.log}")

# Example 1: Searching in PDF
response = agent_with_chat_history.stream(
    {
        "input": "What information can you find about Samsung's AI model in the document?"
    },
    config={"configurable": {"session_id": "tutorial_session_1"}},
)
process_response(response)
#output 
Tool Used: pdf_search
Tool Input: {'query': 'Samsung AI model'}
Tool Log: 
Invoking: `pdf_search` with `{'query': 'Samsung AI model'}`

The document does not contain specific information about Samsung's AI model. 
If you need information about Samsung's AI model, I can search the web for you. Would you like me to do that?

# Example 2: Following up with web search (same session)
response = agent_with_chat_history.stream(
    {
        "input": "Yes, please search the web for information about Samsung's latest AI model"
    },
    config={"configurable": {"session_id": "tutorial_session_1"}},
)
process_response(response)
#output 
Tool Used: tavily_search_results_json
Tool Input: {'query': 'Samsung latest AI model 2023'}
Tool Log: 
Invoking: `tavily_search_results_json` with `{'query': 'Samsung latest AI model 2023'}`


# Example 3: New session with different topic (Session 2)
response = agent_with_chat_history.stream(
    {"input": "What can you tell me about Strong and Weak AI from the PDF document?"},
    config={"configurable": {"session_id": "tutorial_session_2"}},
)
process_response(response)
#output 
Tool Used: pdf_search
Tool Input: {'query': 'Strong and Weak AI'}
Tool Log: 
Invoking: `pdf_search` with `{'query': 'Strong and Weak AI'}`


# Example 4: Request to summarize previous response in a table (Session 2)
response = agent_with_chat_history.stream(
    {"input": "Can you organize your previous response into a table format?"},
    config={"configurable": {"session_id": "tutorial_session_2"}},
)
process_response(response)


###ADVANCED : Agentic Ai  and React Agent
ReAct Agent stands for Reasoning + Action, meaning that the LLM explicitly goes through a reasoning phase, 
utilizes tools (or actions), and then generates the final answer based on the obtained results.

Throughout this tutorial, we will implement a ReAct Agent by covering the following:
    Tool Setup: Utilizing various tools such as web search, file management, 
    document search based on VectorStore, etc.
    Agent Creation: Practice how to use the ReAct Agent in LangChain.
    Graph Execution: Execute the agent to observe the answers to queries.

pip install langsmith langchain langchain_core langchain_community langchain_openai langgraph faiss-cpu pymupdf


set TAVILY_API_KEY = 

#Serach result tool 

from langchain_community.tools.tavily_search import TavilySearchResults

# Create an instance of TavilySearchResults with k=5 for retrieving up to 5 search results
web_search = TavilySearchResults(k=5)
     

# Test the web search tool.
result = web_search.invoke(
    "Please find information related to the major AI-related from CES 2025"
)
result
     
##File Management
https://python.langchain.com/api_reference/community/agent_toolkits/langchain_community.agent_toolkits.file_management.toolkit.FileManagementToolkit.html
Using FileManagementToolkit, you can create, delete, and modify files.
Check Other tool kit 
https://python.langchain.com/api_reference/community/agent_toolkits.html


from langchain_community.agent_toolkits import FileManagementToolkit

# Set 'tmp' as the working directory.
working_directory = "tmp"
file_management_tools = FileManagementToolkit(
    root_dir=str(working_directory)
).get_tools()
#file_management_tools
     
##Retriever Tool
To search for information within documents such as PDFs, we create a Retriever. 
First, we load the PDF, split the text, then embed it into a VectorStore.


from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_community.document_loaders import PyMuPDFLoader

# Example PDF file path (adjust according to your environment)
pdf_file_path = "data/shsconf_icdeba2023_02022.pdf"

# Load the PDF using PyMuPDFLoader
loader = PyMuPDFLoader(pdf_file_path)

# Split text into smaller chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
split_docs = loader.load_and_split(text_splitter)

# Create FAISS VectorStore
vector = FAISS.from_documents(split_docs, OpenAIEmbeddings())

# Create a retriever from the VectorStore
pdf_retriever = vector.as_retriever()
     

from langchain_core.tools.retriever import create_retriever_tool
from langchain_core.prompts import PromptTemplate

# Create a tool for PDF-based search
retriever_tool = create_retriever_tool(
    retriever=pdf_retriever,
    name="pdf_retriever",
    description="use this tool to search for information in Tesla PDF file",
    document_prompt=PromptTemplate.from_template(
        "{page_content}"
    ),
)
     

##Combine these tools into a single list.

tools = [web_search, *file_management_tools, retriever_tool]
tools
     
     
     
## Create and Visualize the Agent
We will now create a ReAct Agent and visualize the agent graph. 
In LangChain, a ReAct agent generates answers through step-by-step reasoning and tool usage.


from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import create_react_agent

# Memory and model configuration
memory = MemorySaver()
model = ChatOpenAI(model_name="gpt-4o-mini")

# Create ReAct Agent
agent = create_react_agent(model, tools=tools, checkpointer=memory)
     

The code below visualizes the agent's graph structure.

from IPython.display import Image, display

display(
    Image(agent.get_graph().draw_mermaid_png(output_file_path="11-React-Agent.png"))
)
     

def print_stream(stream):
    for s in stream:
        message = s["messages"][-1]
        if isinstance(message, tuple):
            print(message)
        else:
            message.pretty_print()
     
##Execute Agent
Let's execute the created ReAct Agent. 
We can track the step-by-step process of generating an answer to a query.

The example code below uses stream_graph to stream the agent's execution process. 
We place the user's query in the messages key, and the agent's reasoning will be displayed.

config = {"configurable": {"thread_id": "1"}}
inputs = {"messages": [("human", "Hello, my name is Teddy.")]}

print_stream(agent.stream(inputs, config=config, stream_mode="values"))
     

# Another example - maintaining chat flow
config = {"configurable": {"thread_id": "1"}}
inputs = {"messages": [("human", "What was my name again?")]}

print_stream(agent.stream(inputs, config=config, stream_mode="values"))
     

config = {"configurable": {"thread_id": "1"}}
inputs = {
    "messages": [("human", "Please summarize Tesla from shsconf_icdeba2023_02022.pdf.")]
}

print_stream(agent.stream(inputs, config=config, stream_mode="values"))
     

# Example of using web search + file management
config = {"configurable": {"thread_id": "1"}}
inputs = {
    "messages": [
        (
            "human",
            "Search for news about American writer John Smith's Pulitzer Prize and draft a brief report based on it.",
        )
    ]
}

print_stream(agent.stream(inputs, config=config, stream_mode="values"))
     

# A more concrete scenario example
instruction = """
Your task is to write a 'press release.'
----
Please process the following steps in order:
1. Search for news about American writer John Smith's Pulitzer Prize.
2. Based on the Pulitzer Prize news, write a press release/report.
3. Actively use markdown table format to summarize key points.
4. Save the output to a file named `agent_press_release.md`.
"""

config = {"configurable": {"thread_id": "1"}}
inputs = {"messages": [("human", instruction)]}
print_stream(agent.stream(inputs, config=config, stream_mode="values"))
     
     
    
###ADVANCED: Example of structured ouput - Classify Text into Labels and OpenAI metadata tagger
from langchain.chat_models import init_chat_model

llm = init_chat_model("gpt-4o-mini", model_provider="openai")

Let's specify a Pydantic model with a few properties and their expected type in our schema.

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field

tagging_prompt = ChatPromptTemplate.from_template(
    """
Extract the desired information from the following passage.

Only extract the properties mentioned in the 'Classification' function.

Passage:
{input}
"""
)


class Classification(BaseModel):
    sentiment: str = Field(description="The sentiment of the text")
    aggressiveness: int = Field(
        description="How aggressive the text is on a scale from 1 to 10"
    )
    language: str = Field(description="The language the text is written in")


# LLM
llm = ChatOpenAI(temperature=0, model="gpt-4o-mini").with_structured_output(
    Classification
)
inp = "Estoy increiblemente contento de haberte conocido! Creo que seremos muy buenos amigos!"
prompt = tagging_prompt.invoke({"input": inp})
response = llm.invoke(prompt)

response
#Classification(sentiment='positive', aggressiveness=1, language='Spanish')

If we want dictionary output, we can just call .model_dump()

inp = "Estoy muy enojado con vos! Te voy a dar tu merecido!"
prompt = tagging_prompt.invoke({"input": inp})
response = llm.invoke(prompt)

response.model_dump()


Let's redeclare our Pydantic model to control for each of the previously mentioned aspects using enums:

class Classification(BaseModel):
    sentiment: str = Field(..., enum=["happy", "neutral", "sad"])
    aggressiveness: int = Field(
        ...,
        description="describes how aggressive the statement is, the higher the number the more aggressive",
        enum=[1, 2, 3, 4, 5],
    )
    language: str = Field(
        ..., enum=["spanish", "english", "french", "german", "italian"]
    )
    
tagging_prompt = ChatPromptTemplate.from_template(
    """
Extract the desired information from the following passage.

Only extract the properties mentioned in the 'Classification' function.

Passage:
{input}
"""
)

llm = ChatOpenAI(temperature=0, model="gpt-4o-mini").with_structured_output(
    Classification
)

Now the answers will be restricted in a way we expect!

inp = "Estoy increiblemente contento de haberte conocido! Creo que seremos muy buenos amigos!"
prompt = tagging_prompt.invoke({"input": inp})
llm.invoke(prompt)

Classification(sentiment='positive', aggressiveness=1, language='Spanish')

inp = "Estoy muy enojado con vos! Te voy a dar tu merecido!"
prompt = tagging_prompt.invoke({"input": inp})
llm.invoke(prompt)

Classification(sentiment='enojado', aggressiveness=8, language='es')

inp = "Weather is ok here, I can go outside without much more than a coat"
prompt = tagging_prompt.invoke({"input": inp})
llm.invoke(prompt)

Classification(sentiment='neutral', aggressiveness=1, language='English')

##OpenAI metadata tagger
It can often be useful to tag ingested documents with structured metadata, such as the title, tone, 
or length of a document, to allow for a more targeted similarity search later. H
owever, for large numbers of documents, performing this labelling process manually can be tedious.

The OpenAIMetadataTagger document transformer automates this process by extracting metadata from each 
provided document according to a provided schema. It uses a configurable OpenAI Functions-powered chain under the hood, so if you pass a custom LLM instance, it must be an OpenAI model 
with functions support.

from langchain_community.document_transformers.openai_functions import (
    create_metadata_tagger,
)
from langchain_core.documents import Document
from langchain_openai import ChatOpenAI

schema = {
    "properties": {
        "movie_title": {"type": "string"},
        "critic": {"type": "string"},
        "tone": {"type": "string", "enum": ["positive", "negative"]},
        "rating": {
            "type": "integer",
            "description": "The number of stars the critic rated the movie",
        },
    },
    "required": ["movie_title", "critic", "tone"],
}

# Must be an OpenAI model that supports functions
llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613")

document_transformer = create_metadata_tagger(metadata_schema=schema, llm=llm)

You can then simply pass the document transformer a list of documents, 
and it will extract metadata from the contents:

original_documents = [
    Document(
        page_content="Review of The Bee Movie\nBy Roger Ebert\n\nThis is the greatest movie ever made. 4 out of 5 stars."
    ),
    Document(
        page_content="Review of The Godfather\nBy Anonymous\n\nThis movie was super boring. 1 out of 5 stars.",
        metadata={"reliable": False},
    ),
]

enhanced_documents = document_transformer.transform_documents(original_documents)

import json

print(
    *[d.page_content + "\n\n" + json.dumps(d.metadata) for d in enhanced_documents],
    sep="\n\n---------------\n\n",
)
The new documents can then be further processed by a text splitter before being loaded 
into a vector store. Extracted fields will not overwrite existing metadata.

You can also initialize the document transformer with a Pydantic schema:

from typing import Literal

from pydantic import BaseModel, Field


class Properties(BaseModel):
    movie_title: str
    critic: str
    tone: Literal["positive", "negative"]
    rating: int = Field(description="Rating out of 5 stars")


document_transformer = create_metadata_tagger(Properties, llm)
enhanced_documents = document_transformer.transform_documents(original_documents)

print(
    *[d.page_content + "\n\n" + json.dumps(d.metadata) for d in enhanced_documents],
    sep="\n\n---------------\n\n",
)

#Customization
You can pass the underlying tagging chain the standard LLMChain arguments in the document transformer 
constructor. For example, if you wanted to ask the LLM to focus specific details in the input documents, 
or extract metadata in a certain style, you could pass in a custom prompt:

from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_template(
    """Extract relevant information from the following text.
Anonymous critics are actually Roger Ebert.

{input}
"""
)

document_transformer = create_metadata_tagger(schema, llm, prompt=prompt)
enhanced_documents = document_transformer.transform_documents(original_documents)

print(
    *[d.page_content + "\n\n" + json.dumps(d.metadata) for d in enhanced_documents],
    sep="\n\n---------------\n\n",
)


###ADVANCED: LangGraph Quickstart
In this tutorial, we will build a support chatbot in LangGraph that can:

✅ Answer common questions by searching the web
✅ Maintain conversation state across calls
✅ Route complex queries to a human for review
✅ Use custom state to control its behavior
✅ Rewind and explore alternative conversation paths

%pip install -U langgraph langsmith langchain_anthropic

##Part 1: Build a Basic Chatbot
Start by creating a StateGraph. A StateGraph object defines the structure of our chatbot 
as a "state machine". We'll add nodes to represent the llm and functions our chatbot can call 
and edges to specify how the bot should transition between these functions.

from typing import Annotated

from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages


class State(TypedDict):
    # Messages have the type "list". The `add_messages` function
    # in the annotation defines how this state key should be updated
    # (in this case, it appends messages to the list, rather than overwriting them)
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)

Our graph can now handle two key tasks:
    Each node can receive the current State as input and output an update to the state.
    
    Updates to messages will be appended to the existing list rather than overwriting it, 
    thanks to the prebuilt add_messages function used with the Annotated syntax.

When defining a graph, the first step is to define its State. The State includes the graph's schema 
and reducer functions that handle state updates. In our example, State is a TypedDict with one key:
messages. The add_messages reducer function is used to append new messages to the list 
instead of overwriting it. Keys without a reducer annotation will overwrite previous values. 
Learn more about state, reducers, and related concepts in this guide.
https://langchain-ai.github.io/langgraph/concepts/low_level/#reducers
https://langchain-ai.github.io/langgraph/reference/graphs/#langgraph.graph.message.add_messages


Next, add a "chatbot" node. Nodes represent units of work. They are typically regular python functions.

from langchain_anthropic import ChatAnthropic

llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")


def chatbot(state: State):
    return {"messages": [llm.invoke(state["messages"])]}


# The first argument is the unique node name
# The second argument is the function or object that will be called whenever
# the node is used.
graph_builder.add_node("chatbot", chatbot)


Notice how the chatbot node function takes the current State as input 
and returns a dictionary containing an updated messages list under the key "messages". 
This is the basic pattern for all LangGraph node functions.

The add_messages function in our State will append the llm's response messages 
to whatever messages are already in the state.

Next, add an entry point. This tells our graph where to start its work each time we run it.

graph_builder.add_edge(START, "chatbot")

Similarly, set a finish point. This instructs the graph "any time this node is run, you can exit."

graph_builder.add_edge("chatbot", END)

Finally, we'll want to be able to run our graph. To do so, call "compile()" on the graph builder. 
This creates a "CompiledGraph" we can use invoke on our state.

graph = graph_builder.compile()

You can visualize the graph using the get_graph method and one of the "draw" methods, 
like draw_ascii or draw_png. The draw methods each require additional dependencies.

from IPython.display import Image, display

try:
    display(Image(graph.get_graph().draw_mermaid_png()))
except Exception:
    # This requires some extra dependencies and is optional
    pass

Now let's run the chatbot!

Tip: You can exit the chat loop at any time by typing "quit", "exit", or "q".

def stream_graph_updates(user_input: str):
    for event in graph.stream({"messages": [{"role": "user", "content": user_input}]}):
        for value in event.values():
            print("Assistant:", value["messages"][-1].content)


while True:
    try:
        user_input = input("User: ")
        if user_input.lower() in ["quit", "exit", "q"]:
            print("Goodbye!")
            break

        stream_graph_updates(user_input)
    except:
        # fallback if input() is not available
        user_input = "What do you know about LangGraph?"
        print("User: " + user_input)
        stream_graph_updates(user_input)
        break

##Full Code


from typing import Annotated

from langchain_anthropic import ChatAnthropic
from typing_extensions import TypedDict

from langgraph.graph import StateGraph
from langgraph.graph.message import add_messages


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")


def chatbot(state: State):
    return {"messages": [llm.invoke(state["messages"])]}


# The first argument is the unique node name
# The second argument is the function or object that will be called whenever
# the node is used.
graph_builder.add_node("chatbot", chatbot)
graph_builder.set_entry_point("chatbot")
graph_builder.set_finish_point("chatbot")
graph = graph_builder.compile()


##Part 2: 🛠️ Enhancing the Chatbot with Tools¶
To handle queries our chatbot can't answer "from memory", we'll integrate a web search tool. 
Our bot can use this tool to find relevant information and provide better responses.

%%capture --no-stderr
%pip install -U tavily-python langchain_community

_set_env("TAVILY_API_KEY")

TAVILY_API_KEY:  ········

Next, define the tool:

from langchain_community.tools.tavily_search import TavilySearchResults

tool = TavilySearchResults(max_results=2)
tools = [tool]
tool.invoke("What's a 'node' in LangGraph?")


The results are page summaries our chat bot can use to answer questions.

Next, we'll start defining our graph. The following is all the same as in Part 1, 
except we have added bind_tools on our LLM. 
This lets the LLM know the correct JSON format to use if it wants to use our search engine.

from typing import Annotated

from langchain_anthropic import ChatAnthropic
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
# Modification: tell the LLM which tools it can call
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    return {"messages": [llm_with_tools.invoke(state["messages"])]}


graph_builder.add_node("chatbot", chatbot)

Next we need to create a function to actually run the tools if they are called. 
We'll do this by adding the tools to a new node.

Below, we implement a BasicToolNode that checks the most recent message in the state 
and calls tools if the message contains tool_calls. It relies on the LLM's tool_calling support, 
which is available in Anthropic, OpenAI, Google Gemini, and a number of other LLM providers.

We will later replace this with LangGraph's prebuilt ToolNode to speed things up, 
but building it ourselves first is instructive.

import json

from langchain_core.messages import ToolMessage


class BasicToolNode:
    """A node that runs the tools requested in the last AIMessage."""

    def __init__(self, tools: list) -> None:
        self.tools_by_name = {tool.name: tool for tool in tools}

    def __call__(self, inputs: dict):
        if messages := inputs.get("messages", []):
            message = messages[-1]
        else:
            raise ValueError("No message found in input")
        outputs = []
        for tool_call in message.tool_calls:
            tool_result = self.tools_by_name[tool_call["name"]].invoke(
                tool_call["args"]
            )
            outputs.append(
                ToolMessage(
                    content=json.dumps(tool_result),
                    name=tool_call["name"],
                    tool_call_id=tool_call["id"],
                )
            )
        return {"messages": outputs}


tool_node = BasicToolNode(tools=[tool])
graph_builder.add_node("tools", tool_node)

With the tool node added, we can define the conditional_edges.

Recall that edges route the control flow from one node to the next. 
Conditional edges usually contain "if" statements to route to different nodes depending 
on the current graph state. These functions receive the current graph state 
and return a string or list of strings indicating which node(s) to call next.

Below, call define a router function called route_tools, that checks for tool_calls in the chatbot's 
output. Provide this function to the graph by calling add_conditional_edges, which tells the graph that 
whenever the chatbot node completes to check this function to see where to go next.

The condition will route to tools if tool calls are present and END if not.

Later, we will replace this with the prebuilt tools_condition to be more concise, but implementing it ourselves first makes things more clear.

def route_tools(
    state: State,
):
    """
    Use in the conditional_edge to route to the ToolNode if the last message
    has tool calls. Otherwise, route to the end.
    """
    if isinstance(state, list):
        ai_message = state[-1]
    elif messages := state.get("messages", []):
        ai_message = messages[-1]
    else:
        raise ValueError(f"No messages found in input state to tool_edge: {state}")
    if hasattr(ai_message, "tool_calls") and len(ai_message.tool_calls) > 0:
        return "tools"  # next node tools
    return END  #next node END # these two are configured in next call 


# The `tools_condition` function returns "tools" if the chatbot asks to use a tool, and "END" if
# it is fine directly responding. This conditional routing defines the main agent loop.
graph_builder.add_conditional_edges(
    "chatbot",
    route_tools,
    # The following dictionary lets you tell the graph to interpret the condition's outputs as a specific node
    # It defaults to the identity function, but if you
    # want to use a node named something else apart from "tools",
    # You can update the value of the dictionary to something else
    # e.g., "tools": "my_tools"
    {"tools": "tools", END: END}, #if "tools" is returned, go to "tools" node 
)
# Any time a tool is called, we return to the chatbot to decide the next step
graph_builder.add_edge("tools", "chatbot") 

graph_builder.add_edge(START, "chatbot")
graph = graph_builder.compile()

Notice that conditional edges start from a single node. 
This tells the graph "any time the 'chatbot' node runs, either go to 'tools' if it calls a tool, 
or end the loop if it responds directly.

Like the prebuilt tools_condition, our function returns the END string if no tool calls are made. 
When the graph transitions to END, it has no more tasks to complete and ceases execution. 
Because the condition can return END, we don't need to explicitly set a finish_point this time. 
Our graph already has a way to finish!

Let's visualize the graph we've built. 
The following function has some additional dependencies to run that are unimportant for this tutorial.

from IPython.display import Image, display

try:
    display(Image(graph.get_graph().draw_mermaid_png()))
except Exception:
    # This requires some extra dependencies and is optional
    pass

Now we can ask the bot questions outside its training data.

while True:
    try:
        user_input = input("User: ")
        if user_input.lower() in ["quit", "exit", "q"]:
            print("Goodbye!")
            break

        stream_graph_updates(user_input)
    except:
        # fallback if input() is not available
        user_input = "What do you know about LangGraph?"
        print("User: " + user_input)
        stream_graph_updates(user_input)
        break


Our chatbot still can't remember past interactions on its own, limiting its ability 
to have coherent, multi-turn conversations. In the next part, we'll add memory to address this.

The full code for the graph we've created in this section is reproduced below, 
replacing our BasicToolNode for the prebuilt ToolNode, 
and our route_tools condition with the prebuilt tools_condition

##Full Code


from typing import Annotated

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict

from langgraph.graph import StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


tool = TavilySearchResults(max_results=2)
tools = [tool]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    return {"messages": [llm_with_tools.invoke(state["messages"])]}


graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=[tool])
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
# Any time a tool is called, we return to the chatbot to decide the next step
graph_builder.add_edge("tools", "chatbot")
graph_builder.set_entry_point("chatbot")
graph = graph_builder.compile()



##Part 3: Adding Memory to the Chatbot
Our chatbot can now use tools to answer user questions, but it doesn't remember the context 
of previous interactions. This limits its ability to have coherent, multi-turn conversations.

LangGraph solves this problem through persistent checkpointing. 
If you provide a checkpointer when compiling the graph and a thread_id when calling your graph, 
LangGraph automatically saves the state after each step. When you invoke the graph again 
using the same thread_id, the graph loads its saved state, allowing the chatbot to pick up where it left off.

We will see later that checkpointing is much more powerful than simple chat memory - it lets you save and 
resume complex state at any time for error recovery, human-in-the-loop workflows, time travel interactions, 
and more. 

from langgraph.checkpoint.memory import MemorySaver

memory = MemorySaver()

Notice we're using an in-memory checkpointer. In a production application, you would likely change this 
to use SqliteSaver or PostgresSaver and connect to your own DB.
Example 
>>> import sqlite3
>>> from langgraph.checkpoint.sqlite import SqliteSaver
>>> from langgraph.graph import StateGraph
>>>
>>> builder = StateGraph(int)
>>> builder.add_node("add_one", lambda x: x + 1)
>>> builder.set_entry_point("add_one")
>>> builder.set_finish_point("add_one")
>>> conn = sqlite3.connect("checkpoints.sqlite")
>>> memory = SqliteSaver(conn)
>>> graph = builder.compile(checkpointer=memory)
>>> config = {"configurable": {"thread_id": "1"}}
>>> graph.get_state(config)
>>> result = graph.invoke(3, config)
>>> graph.get_state(config)
StateSnapshot(values=4, next=(), config={'configurable': {'thread_id': '1', 'checkpoint_ns': '', 'checkpoint_id': '0c62ca34-ac19-445d-bbb0-5b4984975b2a'}}, parent_config=None)

Next define the graph.

from typing import Annotated

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


tool = TavilySearchResults(max_results=2)
tools = [tool]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    return {"messages": [llm_with_tools.invoke(state["messages"])]}


graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=[tool])
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
# Any time a tool is called, we return to the chatbot to decide the next step
graph_builder.add_edge("tools", "chatbot")
graph_builder.add_edge(START, "chatbot")

Finally, compile the graph with the provided checkpointer.

graph = graph_builder.compile(checkpointer=memory)

Notice the connectivity of the graph hasn't changed since Part 2. 
All we are doing is checkpointing the State as the graph works through each node.

from IPython.display import Image, display

try:
    display(Image(graph.get_graph().draw_mermaid_png()))
except Exception:
    # This requires some extra dependencies and is optional
    pass

Now you can interact with your bot! First, pick a thread to use as the key for this conversation.

config = {"configurable": {"thread_id": "1"}}

Next, call your chat bot.

user_input = "Hi there! My name is Will."

# The config is the **second positional argument** to stream() or invoke()!
events = graph.stream(
    {"messages": [{"role": "user", "content": user_input}]},
    config,
    stream_mode="values",
)
for event in events:
    event["messages"][-1].pretty_print()


Note: The config was provided as the second positional argument when calling our graph. 
It importantly is not nested within the graph inputs ({'messages': []}).

Let's ask a followup: see if it remembers your name.

user_input = "Remember my name?"

# The config is the **second positional argument** to stream() or invoke()!
events = graph.stream(
    {"messages": [{"role": "user", "content": user_input}]},
    config,
    stream_mode="values",
)
for event in events:
    event["messages"][-1].pretty_print()


Notice that we aren't using an external list for memory: it's all handled by the checkpointer! 
You can inspect the full execution in this LangSmith trace to see what's going on.

Don't believe me? Try this using a different config.

# The only difference is we change the `thread_id` here to "2" instead of "1"
events = graph.stream(
    {"messages": [{"role": "user", "content": user_input}]},
    {"configurable": {"thread_id": "2"}},
    stream_mode="values",
)
for event in events:
    event["messages"][-1].pretty_print()


Notice that the only change we've made is to modify the thread_id in the config. 
See this call's LangSmith trace for comparison.

By now, we have made a few checkpoints across two different threads. But what goes into a checkpoint? 
To inspect a graph's state for a given config at any time, call get_state(config).

snapshot = graph.get_state(config)
snapshot
StateSnapshot(values={'messages': [HumanMessage(content='Hi there! My name is Will.', additional_kwargs={}, response_metadata={}, id='8c1ca919-c553-4ebf-95d4-b59a2d61e078'), AIMessage(content="Hello Will! It's nice to meet you. How can I assist you today? Is there anything specific you'd like to know or discuss?", additional_kwargs={}, response_metadata={'id': 'msg_01WTQebPhNwmMrmmWojJ9KXJ', 'model': 'claude-3-5-sonnet-20240620', 'stop_reason': 'end_turn', 'stop_sequence': None, 'usage': {'input_tokens': 405, 'output_tokens': 32}}, id='run-58587b77-8c82-41e6-8a90-d62c444a261d-0', usage_metadata={'input_tokens': 405, 'output_tokens': 32, 'total_tokens': 437}), HumanMessage(content='Remember my name?', additional_kwargs={}, response_metadata={}, id='daba7df6-ad75-4d6b-8057-745881cea1ca'), AIMessage(content="Of course, I remember your name, Will. I always try to pay attention to important details that users share with me. Is there anything else you'd like to talk about or any questions you have? I'm here to help with a wide range of topics or tasks.", additional_kwargs={}, response_metadata={'id': 'msg_01E41KitY74HpENRgXx94vag', 'model': 'claude-3-5-sonnet-20240620', 'stop_reason': 'end_turn', 'stop_sequence': None, 'usage': {'input_tokens': 444, 'output_tokens': 58}}, id='run-ffeaae5c-4d2d-4ddb-bd59-5d5cbf2a5af8-0', usage_metadata={'input_tokens': 444, 'output_tokens': 58, 'total_tokens': 502})]}, next=(), config={'configurable': {'thread_id': '1', 'checkpoint_ns': '', 'checkpoint_id': '1ef7d06e-93e0-6acc-8004-f2ac846575d2'}}, metadata={'source': 'loop', 'writes': {'chatbot': {'messages': [AIMessage(content="Of course, I remember your name, Will. I always try to pay attention to important details that users share with me. Is there anything else you'd like to talk about or any questions you have? I'm here to help with a wide range of topics or tasks.", additional_kwargs={}, response_metadata={'id': 'msg_01E41KitY74HpENRgXx94vag', 'model': 'claude-3-5-sonnet-20240620', 'stop_reason': 'end_turn', 'stop_sequence': None, 'usage': {'input_tokens': 444, 'output_tokens': 58}}, id='run-ffeaae5c-4d2d-4ddb-bd59-5d5cbf2a5af8-0', usage_metadata={'input_tokens': 444, 'output_tokens': 58, 'total_tokens': 502})]}}, 'step': 4, 'parents': {}}, created_at='2024-09-27T19:30:10.820758+00:00', parent_config={'configurable': {'thread_id': '1', 'checkpoint_ns': '', 'checkpoint_id': '1ef7d06e-859f-6206-8003-e1bd3c264b8f'}}, tasks=())

snapshot.next  # (since the graph ended this turn, `next` is empty. If you fetch a state from within a graph invocation, next tells which node will execute next)

()

The snapshot above contains the current state values, corresponding config, and the next node to process. 
In our case, the graph has reached an END state, so next is empty.


##Full Code


from typing import Annotated

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


tool = TavilySearchResults(max_results=2)
tools = [tool]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    return {"messages": [llm_with_tools.invoke(state["messages"])]}


graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=[tool])
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
graph_builder.add_edge("tools", "chatbot")
graph_builder.set_entry_point("chatbot")
memory = MemorySaver()
graph = graph_builder.compile(checkpointer=memory)




##Part 4: Human-in-the-loop
Agents can be unreliable and may need human input to successfully accomplish tasks. Similarly, for some 
actions, you may want to require human approval before running to ensure that everything is running 
as intended.

LangGraph's persistence layer supports human-in-the-loop workflows, allowing execution to pause and resume 
based on user feedback. The primary interface to this functionality is the interrupt function. Calling 
interrupt inside a node will pause execution. Execution can be resumed, together with new input 
from a human, by passing in a Command. interrupt is ergonomically similar 
to Python's built-in input(), with some caveats. 

We will make one change, which is to add a simple human_assistance tool accessible to the chatbot. 
This tool uses interrupt to receive information from a human.

from typing import Annotated

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.tools import tool
from typing_extensions import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

from langgraph.types import Command, interrupt


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


@tool
def human_assistance(query: str) -> str:
    """Request assistance from a human."""
    human_response = interrupt({"query": query})
    return human_response["data"]


tool = TavilySearchResults(max_results=2)
tools = [tool, human_assistance]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    message = llm_with_tools.invoke(state["messages"])
    # Because we will be interrupting during tool execution,
    # we disable parallel tool calling to avoid repeating any
    # tool invocations when we resume.
    assert len(message.tool_calls) <= 1
    return {"messages": [message]}


graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=tools)
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
graph_builder.add_edge("tools", "chatbot")
graph_builder.add_edge(START, "chatbot")


Check out the Human-in-the-loop section of the How-to Guides for more examples of Human-in-the-loop workflows, including how to review and edit tool calls before they are executed.
https://langchain-ai.github.io/langgraph/how-tos/#human-in-the-loop
https://langchain-ai.github.io/langgraph/how-tos/human_in_the_loop/review-tool-calls/


We compile the graph with a checkpointer, as before:

memory = MemorySaver()

graph = graph_builder.compile(checkpointer=memory)


from IPython.display import Image, display

try:
    display(Image(graph.get_graph().draw_mermaid_png()))
except Exception:
    # This requires some extra dependencies and is optional
    pass

Let's now prompt the chatbot with a question that will engage the new human_assistance tool:

user_input = "I need some expert guidance for building an AI agent. Could you request assistance for me?"
config = {"configurable": {"thread_id": "1"}}

events = graph.stream(
    {"messages": [{"role": "user", "content": user_input}]},
    config,
    stream_mode="values",
)
for event in events:
    if "messages" in event:
        event["messages"][-1].pretty_print()

================================[1m Human Message [0m=================================

I need some expert guidance for building an AI agent. Could you request assistance for me?
==================================[1m Ai Message [0m==================================

[{'text': "Certainly! I'd be happy to request expert assistance for you regarding building an AI agent. To do this, I'll use the human_assistance function to relay your request. Let me do that for you now.", 'type': 'text'}, {'id': 'toolu_01ABUqneqnuHNuo1vhfDFQCW', 'input': {'query': 'A user is requesting expert guidance for building an AI agent. Could you please provide some expert advice or resources on this topic?'}, 'name': 'human_assistance', 'type': 'tool_use'}]
Tool Calls:
  human_assistance (toolu_01ABUqneqnuHNuo1vhfDFQCW)
 Call ID: toolu_01ABUqneqnuHNuo1vhfDFQCW
  Args:
    query: A user is requesting expert guidance for building an AI agent. Could you please provide some expert advice or resources on this topic?

    
    
    
The chatbot generated a tool call, but then execution has been interrupted! 
Note that if we inspect the graph state, we see that it stopped at the tools node:

snapshot = graph.get_state(config)
snapshot.next
('tools',)

Let's take a closer look at the human_assistance tool:

@tool
def human_assistance(query: str) -> str:
    """Request assistance from a human."""
    human_response = interrupt({"query": query})
    return human_response["data"]

Similar to Python's built-in input() function, calling interrupt inside the tool will pause execution. 
Progress is persisted based on our choice of checkpointer-- so if we are persisting with Postgres, we can 
resume at any time as long as the database is alive. Here we are persisting with the in-memory checkpointer, 
so we can resume any time as long as our Python kernel is running.

To resume execution, we pass a Command object containing data expected by the tool. 
The format of this data can be customized based on our needs. 

Here, we just need a dict with a key "data":

human_response = (
    "We, the experts are here to help! We'd recommend you check out LangGraph to build your agent."
    " It's much more reliable and extensible than simple autonomous agents."
)

human_command = Command(resume={"data": human_response})

events = graph.stream(human_command, config, stream_mode="values")
for event in events:
    if "messages" in event:
        event["messages"][-1].pretty_print()

==================================[1m Ai Message [0m==================================

[{'text': "Certainly! I'd be happy to request expert assistance for you regarding building an AI agent. To do this, I'll use the human_assistance function to relay your request. Let me do that for you now.", 'type': 'text'}, {'id': 'toolu_01ABUqneqnuHNuo1vhfDFQCW', 'input': {'query': 'A user is requesting expert guidance for building an AI agent. Could you please provide some expert advice or resources on this topic?'}, 'name': 'human_assistance', 'type': 'tool_use'}]
Tool Calls:
  human_assistance (toolu_01ABUqneqnuHNuo1vhfDFQCW)
 Call ID: toolu_01ABUqneqnuHNuo1vhfDFQCW
  Args:
    query: A user is requesting expert guidance for building an AI agent. Could you please provide some expert advice or resources on this topic?
=================================[1m Tool Message [0m=================================
Name: human_assistance

We, the experts are here to help! We'd recommend you check out LangGraph to build your agent. It's much more reliable and extensible than simple autonomous agents.
==================================[1m Ai Message [0m==================================






Our input has been received and processed as a tool message. Review this call's LangSmith trace to see the 
exact work that was done in the above call. Notice that the state is loaded in the first step so that our 
chatbot can continue where it left off.

Human-in-the-loop workflows enable a variety of new workflows and user experiences. Check out this section 
of the How-to Guides for more examples of Human-in-the-loop workflows, including how to review and edit tool 
calls before they are executed.
https://langchain-ai.github.io/langgraph/how-tos/#human-in-the-loop
https://langchain-ai.github.io/langgraph/how-tos/human_in_the_loop/review-tool-calls/


##Full Code


from typing import Annotated

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.tools import tool
from typing_extensions import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.types import Command, interrupt


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


@tool
def human_assistance(query: str) -> str:
    """Request assistance from a human."""
    human_response = interrupt({"query": query})
    return human_response["data"]


tool = TavilySearchResults(max_results=2)
tools = [tool, human_assistance]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    message = llm_with_tools.invoke(state["messages"])
    assert(len(message.tool_calls) <= 1)
    return {"messages": [message]}


graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=tools)
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
graph_builder.add_edge("tools", "chatbot")
graph_builder.add_edge(START, "chatbot")

memory = MemorySaver()
graph = graph_builder.compile(checkpointer=memory)



##Part 5: Customizing State
So far, we've relied on a simple state with one entry-- a list of messages. 
You can go far with this simple state, but if you want to define complex behavior without relying 
on the message list, you can add additional fields to the state. Here we will demonstrate a new scenario, 
in which the chatbot is using its search tool to find specific information, 
and forwarding them to a human for review. 

Let's have the chatbot research the birthday of an entity. 
We will add name and birthday keys to the state:

from typing import Annotated

from typing_extensions import TypedDict

from langgraph.graph.message import add_messages


class State(TypedDict):
    messages: Annotated[list, add_messages]
    name: str
    birthday: str


Adding this information to the state makes it easily accessible by other graph nodes (e.g., a downstream 
node that stores or processes the information), as well as the graph's persistence layer.

Here, we will populate the state keys inside of our human_assistance tool. This allows a human to review the 
information before it is stored in the state. We will again use Command, this time to issue a state update 
from inside our tool. Read more about use cases for Command here.

from langchain_core.messages import ToolMessage
from langchain_core.tools import InjectedToolCallId, tool

from langgraph.types import Command, interrupt


@tool
# Note that because we are generating a ToolMessage for a state update, we
# generally require the ID of the corresponding tool call. We can use
# LangChain's InjectedToolCallId to signal that this argument should not
# be revealed to the model in the tool's schema.
def human_assistance(
    name: str, birthday: str, tool_call_id: Annotated[str, InjectedToolCallId]
) -> str:
    """Request assistance from a human."""
    human_response = interrupt(
        {
            "question": "Is this correct?",
            "name": name,
            "birthday": birthday,
        },
    )
    # If the information is correct, update the state as-is.
    if human_response.get("correct", "").lower().startswith("y"):
        verified_name = name
        verified_birthday = birthday
        response = "Correct"
    # Otherwise, receive information from the human reviewer.
    else:
        verified_name = human_response.get("name", name)
        verified_birthday = human_response.get("birthday", birthday)
        response = f"Made a correction: {human_response}"

    # This time we explicitly update the state with a ToolMessage inside
    # the tool.
    state_update = {
        "name": verified_name,
        "birthday": verified_birthday,
        "messages": [ToolMessage(response, tool_call_id=tool_call_id)],
    }
    # We return a Command object in the tool to update our state.
    return Command(update=state_update)


Otherwise, the rest of our graph is the same:

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode, tools_condition


tool = TavilySearchResults(max_results=2)
tools = [tool, human_assistance]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    message = llm_with_tools.invoke(state["messages"])
    assert len(message.tool_calls) <= 1
    return {"messages": [message]}


graph_builder = StateGraph(State)
graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=tools)
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
graph_builder.add_edge("tools", "chatbot")
graph_builder.add_edge(START, "chatbot")

memory = MemorySaver()
graph = graph_builder.compile(checkpointer=memory)


Let's prompt our application to look up the "birthday" of the LangGraph library. 
We will direct the chatbot to reach out to the human_assistance tool once it has the required information. 
Note that setting name and birthday in the arguments for the tool, we force the chatbot to generate proposals for these fields.

user_input = (
    "Can you look up when LangGraph was released? "
    "When you have the answer, use the human_assistance tool for review."
)
config = {"configurable": {"thread_id": "1"}}

events = graph.stream(
    {"messages": [{"role": "user", "content": user_input}]},
    config,
    stream_mode="values",
)
for event in events:
    if "messages" in event:
        event["messages"][-1].pretty_print()

================================[1m Human Message [0m=================================

Can you look up when LangGraph was released? When you have the answer, use the human_assistance tool for review.
==================================[1m Ai Message [0m==================================

[{'text': "Certainly! I'll start by searching for information about LangGraph's release date using the Tavily search function. Then, I'll use the human_assistance tool for review.", 'type': 'text'}, {'id': 'toolu_01JoXQPgTVJXiuma8xMVwqAi', 'input': {'query': 'LangGraph release date'}, 'name': 'tavily_search_results_json', 'type': 'tool_use'}]
Tool Calls:
  tavily_search_results_json (toolu_01JoXQPgTVJXiuma8xMVwqAi)
 Call ID: toolu_01JoXQPgTVJXiuma8xMVwqAi
  Args:
    query: LangGraph release date
=================================[1m Tool Message [0m=================================
Name: tavily_search_results_json
Tool Calls:
  human_assistance (toolu_01JDQAV7nPqMkHHhNs3j3XoN)
 Call ID: toolu_01JDQAV7nPqMkHHhNs3j3XoN
  Args:
    name: Assistant
    birthday: 2023-01-01

We've hit the interrupt in the human_assistance tool again. 
In this case, the chatbot failed to identify the correct date, so we can supply it:

human_command = Command(
    resume={
        "name": "LangGraph",
        "birthday": "Jan 17, 2024",
    },
)

events = graph.stream(human_command, config, stream_mode="values")
for event in events:
    if "messages" in event:
        event["messages"][-1].pretty_print()

==================================[1m Ai Message [0m==================================

[{'text': "Based on the search results, it appears that LangGraph was already in existence before June 27, 2024, when LangGraph Cloud was announced. However, the search results don't provide a specific release date for the original LangGraph. \n\nGiven this information, I'll use the human_assistance tool to review and potentially provide more accurate information about LangGraph's initial release date.", 'type': 'text'}, {'id': 'toolu_01JDQAV7nPqMkHHhNs3j3XoN', 'input': {'name': 'Assistant', 'birthday': '2023-01-01'}, 'name': 'human_assistance', 'type': 'tool_use'}]
Tool Calls:
  human_assistance (toolu_01JDQAV7nPqMkHHhNs3j3XoN)
 Call ID: toolu_01JDQAV7nPqMkHHhNs3j3XoN
  Args:
    name: Assistant
    birthday: 2023-01-01
=================================[1m Tool Message [0m=================================
Name: human_assistance

Made a correction: {'name': 'LangGraph', 'birthday': 'Jan 17, 2024'}
==================================[1m Ai Message [0m==================================

Thank you for the human assistance. I can now provide you with the correct information about LangGraph's release date.

LangGraph was initially released on January 17, 2024. This information comes from the human assistance correction, which is more accurate than the search results I initially found.

To summarize:
1. LangGraph's original release date: January 17, 2024
2. LangGraph Cloud announcement: June 27, 2024

It's worth noting that LangGraph had been in development and use for some time before the LangGraph Cloud announcement, but the official initial release of LangGraph itself was on January 17, 2024.












Note that these fields are now reflected in the state:

snapshot = graph.get_state(config)

{k: v for k, v in snapshot.values.items() if k in ("name", "birthday")}
#{'name': 'LangGraph', 'birthday': 'Jan 17, 2024'}

This makes them easily accessible to downstream nodes (e.g., a node that further processes or stores the information).

##Manually updating state
LangGraph gives a high degree of control over the application state. 
For instance, at any point (including when interrupted), we can manually override a key using graph.update_state:

graph.update_state(config, {"name": "LangGraph (library)"})

{'configurable': {'thread_id': '1',
  'checkpoint_ns': '',
  'checkpoint_id': '1efd4ec5-cf69-6352-8006-9278f1730162'}}

If we call graph.get_state, we can see the new value is reflected:

snapshot = graph.get_state(config)

{k: v for k, v in snapshot.values.items() if k in ("name", "birthday")}

{'name': 'LangGraph (library)', 'birthday': 'Jan 17, 2024'}

Manual state updates will even generate a trace in LangSmith. If desired, they can also be used to control 
human-in-the-loop workflows, as described in this guide. Use of the interrupt function is generally 
recommended instead, as it allows data to be transmitted in a human-in-the-loop interaction independently of 
state updates.



##full code 
from typing import Annotated

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import ToolMessage
from langchain_core.tools import InjectedToolCallId, tool
from typing_extensions import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.types import Command, interrupt



class State(TypedDict):
    messages: Annotated[list, add_messages]
    name: str
    birthday: str


@tool
def human_assistance(
    name: str, birthday: str, tool_call_id: Annotated[str, InjectedToolCallId]
) -> str:
    """Request assistance from a human."""
    human_response = interrupt(
        {
            "question": "Is this correct?",
            "name": name,
            "birthday": birthday,
        },
    )
    if human_response.get("correct", "").lower().startswith("y"):
        verified_name = name
        verified_birthday = birthday
        response = "Correct"
    else:
        verified_name = human_response.get("name", name)
        verified_birthday = human_response.get("birthday", birthday)
        response = f"Made a correction: {human_response}"

    state_update = {
        "name": verified_name,
        "birthday": verified_birthday,
        "messages": [ToolMessage(response, tool_call_id=tool_call_id)],
    }
    return Command(update=state_update)


tool = TavilySearchResults(max_results=2)
tools = [tool, human_assistance]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    message = llm_with_tools.invoke(state["messages"])
    assert(len(message.tool_calls) <= 1)
    return {"messages": [message]}


graph_builder = StateGraph(State)
graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=tools)
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
graph_builder.add_edge("tools", "chatbot")
graph_builder.add_edge(START, "chatbot")

memory = MemorySaver()
graph = graph_builder.compile(checkpointer=memory)



##Part 6: Time Travel
In a typical chat bot workflow, the user interacts with the bot 1 or more times to accomplish a task. 
In the previous sections, we saw how to add memory and a human-in-the-loop to be able to checkpoint 
our graph state and control future responses.

But what if you want to let your user start from a previous response and "branch off" to explore 
a separate outcome? Or what if you want users to be able to "rewind" your assistant's work 
to fix some mistakes or try a different strategy (common in applications like autonomous software engineers)?

You can create both of these experiences and more using LangGraph's built-in "time travel" functionality.

In this section, you will "rewind" your graph by fetching a checkpoint using the graph's 
get_state_history method. You can then resume execution at this previous point in time.

For this, let's use the simple chatbot with tools from Part 3:

from typing import Annotated

from langchain_anthropic import ChatAnthropic
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition


class State(TypedDict):
    messages: Annotated[list, add_messages]


graph_builder = StateGraph(State)


tool = TavilySearchResults(max_results=2)
tools = [tool]
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
llm_with_tools = llm.bind_tools(tools)


def chatbot(state: State):
    return {"messages": [llm_with_tools.invoke(state["messages"])]}


graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools=[tool])
graph_builder.add_node("tools", tool_node)

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
graph_builder.add_edge("tools", "chatbot")
graph_builder.add_edge(START, "chatbot")

memory = MemorySaver()
graph = graph_builder.compile(checkpointer=memory)


Let's have our graph take a couple steps. Every step will be checkpointed in its state history:

config = {"configurable": {"thread_id": "1"}}
events = graph.stream(
    {
        "messages": [
            {
                "role": "user",
                "content": (
                    "I'm learning LangGraph. "
                    "Could you do some research on it for me?"
                ),
            },
        ],
    },
    config,
    stream_mode="values",
)
for event in events:
    if "messages" in event:
        event["messages"][-1].pretty_print()


events = graph.stream(
    {
        "messages": [
            {
                "role": "user",
                "content": (
                    "Ya that's helpful. Maybe I'll "
                    "build an autonomous agent with it!"
                ),
            },
        ],
    },
    config,
    stream_mode="values",
)
for event in events:
    if "messages" in event:
        event["messages"][-1].pretty_print()


Now that we've had the agent take a couple steps, we can replay the full state history 
to see everything that occurred.

to_replay = None
for state in graph.get_state_history(config):
    print("Num Messages: ", len(state.values["messages"]), "Next: ", state.next)
    print("-" * 80)
    if len(state.values["messages"]) == 6:
        # We are somewhat arbitrarily selecting a specific state based on the number of chat messages in the state.
        to_replay = state

Num Messages:  8 Next:  ()
--------------------------------------------------------------------------------
Num Messages:  7 Next:  ('chatbot',)
--------------------------------------------------------------------------------
Num Messages:  6 Next:  ('tools',)
--------------------------------------------------------------------------------
Num Messages:  5 Next:  ('chatbot',)
--------------------------------------------------------------------------------
Num Messages:  4 Next:  ('__start__',)
--------------------------------------------------------------------------------
Num Messages:  4 Next:  ()
--------------------------------------------------------------------------------
Num Messages:  3 Next:  ('chatbot',)
--------------------------------------------------------------------------------
Num Messages:  2 Next:  ('tools',)
--------------------------------------------------------------------------------
Num Messages:  1 Next:  ('chatbot',)
--------------------------------------------------------------------------------
Num Messages:  0 Next:  ('__start__',)
--------------------------------------------------------------------------------

Notice that checkpoints are saved for every step of the graph. This spans invocations so you can rewind 
across a full thread's history. We've picked out to_replay as a state to resume from. This is the state 
after the chatbot node in the second graph invocation above.

Resuming from this point should call the action node next.

print(to_replay.next)
print(to_replay.config)

('tools',)
{'configurable': {'thread_id': '1', 'checkpoint_ns': '', 'checkpoint_id': '1efd43e3-0c1f-6c4e-8006-891877d65740'}}

Notice that the checkpoint's config (to_replay.config) contains a checkpoint_id timestamp. 
Providing this checkpoint_id value tells LangGraph's checkpointer to load the state 
from that moment in time. Let's try it below:

# The `checkpoint_id` in the `to_replay.config` corresponds to a state we've persisted to our checkpointer.
for event in graph.stream(None, to_replay.config, stream_mode="values"):
    if "messages" in event:
        event["messages"][-1].pretty_print()

        
##Further reference 
Server Quickstart
    LangGraph Server Quickstart: Launch a LangGraph server locally and interact with it using the REST API and LangGraph Studio Web UI.

LangGraph Cloud
    LangGraph Cloud QuickStart: Deploy your LangGraph app using LangGraph Cloud.

LangGraph Framework
    LangGraph Concepts: Learn the foundational concepts of LangGraph.
    LangGraph How-to Guides: Guides for common tasks with LangGraph.

LangGraph Platform

Expand your knowledge with these resources:
    LangGraph Platform Concepts: Understand the foundational concepts of the LangGraph Platform.
    LangGraph Platform How-to Guides: Guides for common tasks with LangGraph Platform.

https://langchain-ai.github.io/langgraph/tutorials/introduction/#next-steps
https://langchain-ai.github.io/langgraph/tutorials/introduction/#server-quickstart
https://langchain-ai.github.io/langgraph/tutorials/langgraph-platform/local-server
https://langchain-ai.github.io/langgraph/tutorials/introduction/#langgraph-cloud
https://langchain-ai.github.io/langgraph/cloud/quick_start
https://langchain-ai.github.io/langgraph/tutorials/introduction/#langgraph-framework
https://langchain-ai.github.io/langgraph/concepts
https://langchain-ai.github.io/langgraph/how-tos
https://langchain-ai.github.io/langgraph/tutorials/introduction/#langgraph-platform
https://langchain-ai.github.io/langgraph/concepts#langgraph-platform
https://langchain-ai.github.io/langgraph/how-tos#langgraph-platform


def add(x,y):
    """adding two numbers
    and returning"""
    z = x+y 
    return z


print(f"""
{add(1,2)=}  <- positional way 
{add(y=2, x=1)=}  <- keyword based calling 
{add(1, y=1)=}  <- positional comes first 
""")

#y default , defaults come last 
def add1(x,y=20):
    """adding two numbers
    and returning"""
    z = x+y 
    return z


print(f"""
{add1(1)=}  <- y takes default
{add1(1,2)=}  <- y explicit
{add1(1, y=1)=}  <- positional comes first 
""")

# def (x,y) : return x+y 
#body can have single expr, which returned 
print(f""" lambda or no named function

{ (lambda x,y: x+y)(1,2) } <- lambda 
{ (lambda x,y=20: x+y)(1) } <- lambda 

""")
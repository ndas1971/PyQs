#Given input, create output 
input = '[1,2,3,4]'
#output = [1,2,3,4]

output = []
for ch in input.strip('[]').split(','):
    output.append(int(ch))
    
print(output)
#Map pattern - comprehension 
output = [int(ch) for ch in input.strip('[]').split(',')]
print(output)

#Given list, transform each element - Map pattern 
#STEP-1: Use right bracket, if you want output as list 
#use [], for set, {}, for dict {:}
#STEP-2:write transform at first and then for loop 

lst = list(range(100))  #0, ..., 100
#square each element 
o = []
for e in lst:
    o.append(e*e)
#equiv 
o = [e*e for e in lst]
#square only even elemnt 
o = []
for e in lst:
    if e % 2 == 0:
        o.append(e*e)

#equiv 
o = [e*e for e in lst if e % 2 == 0]
#example create a tuple of even and odd 
o = [(e1,e2) for e1 in lst if e1 % 2 == 0 
    for e2 in lst if e2 % 2 == 1]
#equiv 
o = []
for e1 in lst:
    if e1 % 2 == 0:
        for e2 in lst:
            if e2 % 2 == 1:
                o.append( (e1, e2) )
                
#Handson 
#how many Pythogorus numbers  below 100
#ie (x,y,z) which satisfy z*z == x*x +y*y 
#
#hint - three for loops and comprehension with above conditions 

o = [(x,y,z)
        for x in range(1,100)
            for y in range(x,100)
                for z in range(y,100)
                    if z*z == x*x + y*y ]
print(len(o))

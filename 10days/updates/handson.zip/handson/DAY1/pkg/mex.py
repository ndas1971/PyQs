#first string in module is module doc 
"""
package - directory contains 
    all modules 
    __init__.py - could be empty
Module - file .py extension
Usage 
    we used for import 
    contains fns, class

while importing package 
import package_name.module_name 
Python  searches package_name dir in sys.path 

"""
def square(x):
    #first string - doc string 
    """Square fn"""
    z = x*x 
    return z 
    
    
#mean = average, sum/leng

def mean(lst):
    return sum(lst)/len(lst)
    
    
    
    
    
    
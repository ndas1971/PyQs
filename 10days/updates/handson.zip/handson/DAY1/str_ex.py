s = "Hello World and Earth"

#how many upper case, lowercase and space in that string 
#Use .islower... kind of methods 

#forloop check each chracter and incement some counter 
clower, cupper, cspace = 0,0,0
for ch in s:
    if ch.islower():
        clower += 1
    elif ch.isupper():
        cupper += 1
    elif ch == ' ':
        cspace += 1
print(f"{clower=},{cupper=},{cspace=}")
"""
script - file with .py extension
Usage 
    execute 
    python file.name 

"""
import pkg
#import pkg.__init__
lst = [1,2,3,4]
print(f"""
square of 10 = {pkg.square(10)}
mean of {lst} = {pkg.mean(lst)}
""")
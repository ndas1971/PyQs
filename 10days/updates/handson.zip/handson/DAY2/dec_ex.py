#Given a directory, find out the file Name 
#having max size recursively
"""
decorator DP - enhancing original functionality 
"""

import glob             #ls  or dir 
import os.path          # get size, to know is file or dir 
import time
import sys 

DEBUG = bool(sys.argv[1]) if len(sys.argv) > 1 else False 
def d_print(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)
        
        

def profile(fun):  #fun = original get_max_filename
    d_print("profile called", fun)
    def _inner(*args, **kwargs):  #args = (path, ) kwargs = {}
        d_print("profile::_inner called", f"{args=},{kwargs=}")
        st = time.time()
        res = fun(*args, **kwargs) #original get_max_filename(path) #1 wud call 2
        print("Time taken", time.time()-st, "secs")  #when 2 returns 
        d_print("profile::_inner returned")
        return res 
    d_print("profile returned",_inner )
    return _inner 

#get_max_filename = profile(get_max_filename) = _inner     
@profile                    
def get_max_filename(path):
    def get_files(path, ed = {}):  #2
        files = glob.glob(os.path.join(path, "*"))
        for f in files:
            if os.path.isfile(f):
                ed[f] = os.path.getsize(f)
            elif os.path.isdir(f):
                get_files(f, ed)
        return ed  
    allfiles = get_files(path)
    std = sorted(allfiles, key=lambda k: allfiles[k])
    return std[-1] if std else ''
    
if __name__ == '__main__':
    path = r"."
    print(get_max_filename(path)) #_inner(path)

# TASK1: Write 5 times "hello world" to  "demo.txt" file 
# TASK2: Read "demo.txt" and prepend line number to each line 
# and write that to "demo.bak.txt"

# readlines -> list 
# list -> writelines 

out = ["Hello World\n"] * 5 
path = "demo.txt"
with open(path, "wt") as f:
    f.writelines(out)

#TASK2:
#read 
with open(path, "rt") as f:
    lines = f.readlines()
    
#prepend 
out = []
no = 1
for line in lines:
    out.append(f"{no} {line}")
    no += 1
#enumerate(lst) -> [(i1, e1),(i2, e2)]
#prepend 
out = []
for no,line in enumerate(lines):
    out.append(f"{no+1} {line}")
#equiv 
out = [f"{no+1} {line}" for no,line in enumerate(lines)]

#write 
path = "demo.bak.txt"
with open(path, "wt") as f:
    f.writelines(out)
    
##Extremely large - must not do completing reading 
path, path2 = "demo.txt", "demo.bak.txt"
with open(path, "rt") as f, open(path2, "wt") as f2:
    for no, line in enumerate(f):
        f2.write(f"{no+1} {line}")
        
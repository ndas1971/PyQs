path = r"D:\handson\DAY2\data\iris.csv"
with open(path, "rt") as f:
    lines = f.readlines()

rows = lines[1:]
rowsd = []
for e in rows:
    a,b,c,d,n = e.strip().split(",")
    rowsd.append([float(a),float(b),float(c),float(d),n])
    
rowsd = [ [float(e.strip().split(",")[0]),
           float(e.strip().split(",")[1]),
           float(e.strip().split(",")[2]),
           float(e.strip().split(",")[3]), 
           e.strip().split(",")[-1]]  for e in rows]  

#how many subspecies are in that file
es = set()
for _,_,_,_,n in rowsd:
    es.add(n)

es = { n for _,_,_,_,n in rowsd}


#find min of SepalLength of each name
#select min(SepalLength), max(SepalLength), min(SepalWidth) from ... groupby Name
o = {}
for n in es:
    lst_sl, lst_sw = [], []
    for a,b,_,_,n1 in rowsd:
        if n == n1:
            lst_sl.append(a)
            lst_sw.append(b)
    #o[n]={'SepalLength': {'min': min(lst_sl), 'max': max(lst_sl)}, 'SepalWidth': {'min': min(lst_sw)}}
    o[n]={'SepalLength': [min(lst_sl), max(lst_sl)], 'SepalWidth': {'min': min(lst_sw)}}



o = { n: {'SepalLength': min([ a for a,b,_,_,n1 in rowsd if n1 == n])}
        for n in es}

print(o)
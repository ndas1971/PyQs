"""
User input - always in string 
input function 
    Uses stdin file internally 
    sys.stdin.readline()
    Use it sensitive information 
    Use getpass 
Use env variable 
    set MYPW=ok
    >>> import os
    >>> os.environ['MYPW']
    'ok'
Via config files 
    Use open API of text file 
    json/xml/yaml - use std lib to proces 
Using command line ( argparse, ...)
    When we execute 
    > python filename.py  arg1 arg2 arg3
    it comes to sys.argv = ['filename.py',  'arg1', 'arg2', 'arg3']
PROB1: User not providing 
sol - use default strategy 
PROB2: Provides but wrong data 
sol - handle exception , use strategy how to resolve exception 
again default 

"""
import sys 
default_age = 40 

name = input("Give Name:")
#X if Y else Z -> if Y true, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError as ex:
    print("Wrong data given, using default age")
    age = default_age
    
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")
    

# Create a file mex.py and write below functions in it 
# 
# Use builtin sum 
# https://docs.python.org/3/library/functions.html
# Use math module 
# 
# Mean(lst) = Sum of lst/length of lst 
# 
# sd(lst) = sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
# 
# groupby(lst,key_fn)
# key_fn takes each item of list and returns key 
# group should collate those keys with list of corresponding items 
# lst = [0,1,2,3,4]
# o = { True: [0,2,4], False:[1,3]}
# lst = ['aa', 'b', 'cc']
# o = { 1:['b'], 2:['aa', 'cc']}
# lst = [[1,...,n], [2,...n]]
# o = {n1:[1,...,n], [2,...n]], n2:[1,...,n2], [2,...n2]]}
"""
Misc functions
"""
import math 

def mean(lst):
    return sum(lst)/len(lst)
    
def sd(lst):
    m = mean(lst)
    o = [(x-m)*(x-m) for x in lst]
    return math.sqrt(sum(o)/len(o))
    
def group_by(lst, k_fn):
    #doc string 
    """
    Given list of items and key_fn 
    it creates dict of keys and corresponding items 
    Note, key_fn must arg of function 
    designed to take item from lst and returns key     
    """
    o = {}
    for e in lst:
        k = k_fn(e)
        if k not in o:
            o[k] = [e]
        else:
            o[k].append(e)
    return o 
    
def group_by_adv(lst, k_fn, pick_fn, aggr_fn):
    o = {}
    o2 = {}
    o3 = {}
    #first part
    for e in lst:
        k = k_fn(e)
        if k not in o:
            o[k] = [e]
        else:
            o[k].append(e)
    #2nd part 
    for k,v in o.items():
        o2[k] = [pick_fn(e)  for e in v]  #v is list of list incase of iris.csv 
    #3rd part 
    for k,v in o2.items():
        o3[k] = aggr_fn(v)
    return o3 
    
"""
in script, __name__ is always '__main__'
in module, __name__ become file name

""" 
if __name__ == '__main__':  #below is script code 
    def k(e):
        return e % 2 == 0  

    lst = [1,2,3,4,5,6]

    print(f"""{mean(lst)=},{sd(lst)=},
     {group_by(lst,k)=},  
     {group_by(lst,lambda e: e % 2 == 0  )=},
     {group_by_adv(lst,lambda e: e % 2 == 0, lambda e:e, lambda v: sum(v)  )=}
     """)

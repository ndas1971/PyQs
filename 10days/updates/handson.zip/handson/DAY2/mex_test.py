import mex 

def k(e):
    return e % 2 == 0  

lst = [1,2,3,4,5,6]

print(f"""{mex.mean(lst)=},{mex.sd(lst)=},
 {mex.group_by(lst,k)=},  
 {mex.group_by(lst,lambda e: e % 2 == 0  )=},
 {mex.group_by_adv(lst,lambda e: e % 2 == 0, lambda e:e, lambda v: sum(v)  )=}
 """)
 
##ways to import 
import mex   #RECO 
mex.mean(lst)

import mex as m  #2nd reco
m.mean(lst)

#BELOW dont use till you know what you are doing 
from mex import mean 
mean(lst)
from mex import mean as mm 
mm(lst)
from mex import mean as mm , sd, group_by as gb 
mm(lst)
gb(lst, lambda e: e)
from mex import * 
mean(lst)

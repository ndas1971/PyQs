# Bank User has name and account. There are two types of Users
# Normal and privileged user . There are two types of privileged
# users, Gold and Silver. Gold has cashback of 5% and Silver has 
# cashback of 3% of expenditure when they spend any cash 

"""
composition 
    has/have/contains - clue 
    implement through __init__
inheritance 
    is/are/... - clue 
    inheritance structure 

"""

#https://docs.python.org/3/reference/datamodel.html
#https://docs.python.org/3/library/exceptions.html
#https://www.oreilly.com/library/view/design-patterns-elements/0201633612/

class NotEnoughBalance(Exception):
    pass

class BankAccount:
    def __init__(self, init_amount):
        self.balance = init_amount
    def __str__(self):
        return f"BankAccount({self.balance})"
    def transact(self, amount):
        if self.balance + amount < 0:
            raise NotEnoughBalance("not possible")
        self.balance += amount 
        
        
class BankUser:
    def __init__(self, name, init_amount):
        self.name = name 
        self.account = BankAccount(init_amount)
    def __str__(self):
        return f"BankUser({self.name}, {self.abalance})"
    @property 
    def abalance(self):
        return self.account.balance
    def transact(self, amount):
        #templating - algo in bankuser, tweak in derived class 
        # DP 
        #delegate to components 
        try:
            self.account.transact(amount)
            if amount < 0:
                cashback = self.get_cashback_percentage() * abs(amount)
                self.account.transact(cashback)
        except NotEnoughBalance as ex:
                print(ex, "Name:", self.name, "amount:", amount)
    def get_cashback_percentage(self):
        return 0 
                
            
#Gold has cashback of 5% and Silver has  cashback of 3% of expenditure when they spend any cash 
class NormalUser(BankUser):
    pass 
    
class GoldUser(BankUser):
    def get_cashback_percentage(self):
        return 0.05
       
class SilverUser(BankUser):
    def get_cashback_percentage(self):
        return 0.03
       
if __name__ == '__main__':      # pragma: no cover 
    users = [GoldUser("gold",100),
             SilverUser("silver",100),
             NormalUser("normal",100)]
    amounts = [100, -200, 300, -400, 500]
    for u in users:
        for am in amounts:
            u.transact(am)
        print(u.name, u.abalance)


#    ba = BankUser("ABC", 100)   # BankUser.__init__( ba, "ABC", 100)
#    ba.transact(-200)           # BankUser.transact( ba, 100)
#    print(ba)                   #BankUser.__str__(ba)
import oop

"""
file name - should have test prefix 
testcase = fn with test prefix 
test suite - class with Test prefix 
    collection similar testcase

"""


def test_normal_user():
    u = oop.NormalUser("normal",100)
    amounts = [100, -200, 300, -400, 500]
    for am in amounts:
        u.transact(am)
    assert u.abalance == 800
    
def test_gold_user():
    u = oop.GoldUser("normal",100)
    amounts = [100, -200, 300, 400, -300]
    for am in amounts:
        u.transact(am)
    assert u.abalance == 425
    
def test_ba_string():
    u = oop.BankAccount(100)    
    assert str(u) == "BankAccount(100)"
    
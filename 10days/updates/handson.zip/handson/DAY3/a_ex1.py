import asyncio
import time 


async def worker(delay, what): # coroutine 1
    await asyncio.sleep(delay)  # time consuming use await 
    print(what)
    return what 
    
async def main():                       # coroutine 2
    res1 = await worker(5, "Hello")
    res2 = await worker(5, "World")
    return res1 + res2 

async def mainp():                      # coroutine 3
    res = await asyncio.gather(
        worker(5, "Hello"),     #*coroutines
        worker(5, "World"),
        )
    return res              #list of all results 
    
if __name__ == '__main__':
    print("Sequentially")
    st = time.time()
    res = asyncio.run(main())
    print("Time taken", time.time()-st, "secs")
    print(res)
    print("Parallely")
    st = time.time()
    res = asyncio.run(mainp())
    print("Time taken", time.time()-st, "secs")
    print(res)

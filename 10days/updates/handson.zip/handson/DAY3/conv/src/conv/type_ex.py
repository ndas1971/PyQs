"""
degtoF = lambda deg :  32 + 9/5 * deg 
FtoC   = lambda f : (f-32)*5/9

"""

from enum import Enum 

Unit = Enum("Unit", ['F', 'C'])                         #C1

def convert(value: int|float, /, unit:Unit) -> float :   #C2
    cd = {Unit.C : lambda deg :  32 + 9/5 * deg ,        #C3
          Unit.F : lambda f : (f-32)*5/9}
    match unit:                                          #6
        case Unit():
            return cd[unit](value)
        case _:
            raise Exception("unit not known")
          
if __name__ == '__main__':
    values: list[int|float] = [0, 32]
    units = [Unit.C] * len(values) + [Unit.F] * len(values)
    for v,u in zip([*values, *values], units):              #C4
        print(f"{v=} {u=} conv={convert(v,u)}")             #C5
    
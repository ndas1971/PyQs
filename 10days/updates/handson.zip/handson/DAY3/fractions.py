class Fraction:
    def __init__(self, n,d):
        self.n = n 
        self.d = d 
    def __add__(self, other):  #a,b 
        n = self.n * other.d + self.d * other.n 
        d = self.d * other.d 
        return Fraction(n,d)
    def __str__(self):
        return f"Fraction({self.n},{self.d})"



if __name__ == '__main__':
    a = Fraction(1,2) #Fraction.__init__(a, 1,2)  # __init__(self, n,v)
    b = Fraction(1,3) #Fraction.__init__(b, 1,3)  #...
    c = a + b + a + b + a        # c = Fraction.__add__(a,b) #__add__(self, other)
    print(c)                    #Fraction.__str__(c)        #__str__(self)
    #Fraction(5,6)

# directory size , given a directory 
"""
master thread = sum it ->Reduce 
N worker thread - gives size of one directory - Map
https://docs.python.org/3/library/concurrent.futures.html

max_workers = 2 cores , 1.5-2. x no of cores 

"""
import threading
import concurrent.futures
import os.path , time, os 

def  profile(fun):
    def _inner(*args, **kargs):
        import time
        now = time.time()
        print_ = kargs['print_'] if 'print_' in kargs else True
        res = fun(*args,**kargs)
        if print_:
            print(fun.__name__, "(", threading.current_thread().name, 
                "): ", round(time.time() - now, 2), " secs")
        return res
    return _inner

class FileUtil:
    def __init__(self, path):
        self.path = path 
    def get_size_files(self, rootpath, files):
        s = 0
        for f in files:
            p = os.path.join(rootpath, f)
            try:
                size = os.path.getsize(p)
            except:
                size = 0 
            s += size 
        return s 
    @profile    
    def get_one_dir_size(self, **kwargs):
        s = 0
        for rootpath, dirs, files in os.walk(self.path):
            s += self.get_size_files(rootpath, files)
        return s 
    @profile   
    def get_dir_size_threaded(self, max_w=4):
        s = 0
        rootpath, dirs, files = next(os.walk(self.path))
        s += self.get_size_files(rootpath, files)
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=max_w)
        #https://docs.python.org/3/library/concurrent.futures.html
        #for process, use ProcessPoolExecutor 
        res = ex.map(lambda p: FileUtil(p).get_one_dir_size(print_=True),
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        ex.shutdown()
        return s 
    @profile   
    def get_dir_size_sequentially(self, max_w=4):
        s = 0
        rootpath, dirs, files = next(os.walk(self.path))
        s += self.get_size_files(rootpath, files)
        #ex = concurrent.futures.ThreadPoolExecutor(max_workers=max_w)
        res = map(lambda p: FileUtil(p).get_one_dir_size(print_=False),
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        #ex.shutdown()
        return s 



if __name__ == '__main__':
    path = r"c:\Windows\system32"
    #path = "."
    size = FileUtil(path).get_dir_size_sequentially()
    print(size)
    size = FileUtil(path).get_dir_size_threaded()
    print(size)
import  multiprocessing 
import time 

def worker(sleeptime):
    print(multiprocessing.current_process().name, "Entering")
    time.sleep(sleeptime)
    print(multiprocessing.current_process().name, "Exiting")


if __name__ == '__main__':
    print("Sequentially")
    worker(5)  #MainProcess MainThread
    print("Parallel")
    ths = []
    st = time.time()
    for _ in range(10):
        th = multiprocessing.Process(target=worker, args=(5,))
        ths.append(th)
    #but start it 
    [th.start() for th in ths]
    #Wait for ending - join
    [th.join() for th in ths]
    print("Time taken", time.time()-st, "secs")
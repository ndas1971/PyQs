lst = [1,"OK", True, [1,2,3], 2, "NOK"]

def p(e):
    if type(e) is bool:
        return 0 
    elif type(e) is int:
        return 1  
    elif type(e) is float:
        return 2    
    elif type(e) is str:
        return 3    
    elif type(e) is list:
        return 4       
    else:
        return 5 

sorted(lst, key=p)

#match statement 
def p(e):
    match e:
        case bool() : return 0
        case int()  : return 1
        case float(): return 2
        case str()  : return 3 
        case list() : return 4 
        case _      : return 5 

sorted(lst, key=p)

#lookuptable - best 
sd = {bool: 1, int: 2, float: 3, str: 4, list: 5}
sorted(lst, key = lambda e: sd.get(type(e),6))



#--- internal working  
#tmp_list = []
#for e in lst:
#    tmp_list.append(p(e))
#                          lst = [a, b,c, d, ...]
#internal_sort(tmp_list) ->      [k1, k2, k3,. .]
#
#[a,b,c,d,...]
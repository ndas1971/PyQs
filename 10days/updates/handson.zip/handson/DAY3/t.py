"""
Current way 
    single host, single process, single thread
Ways of concurrency 
    0. single host, single process, single thread
        cooperative concurrency(coroutines)
            asyncio or asynchronous/callback programming 
    1. single host, one process, multiple threads 
        threading 
    2. Single host, multiple process 
        multiprocessing
    3. Multiple host 
        Dedicated frameworks 
            pyspark 

Ways to do 1 and 2 
    low level libs 
        threading
        multiprocessing
    MapReduce/fork-join 
        Executor and futures 
 
One process may contain multiple threads 

Heavywt 
    process 
    to handle process level constraint     
    for CPU bound uses process 
    One extra process is created for IPC 
        Manager process 
            used for sharing data accross processes 
    
lightwt 
    thread 
    IO bound code removes GIL
    Sharing of global is easy 
    
    
Constraint - GIL 
    one thread can access to GIL 
    to run python code 
    (3.13 removes the GIL)
    
Commands 
tasklist /FI "IMAGENAME eq python.exe"
taskkill /F /IM python.exe 

Daemon 
    threads - means main thread is master 
    master ends, all daemon thread ends 
    else OS will wait for all threads to end 
    
Synchronization
https://docs.python.org/3/library/threading.html
    Lock/RLock Objects
        mutex - one thread at a time 
        updated shared variable 
            HIGH level API - futures/forkjoin/MapReduce 
            uses Executor 
    Event Objects
        some event happens, N threads notified 
    Condition Objects
        Event with Lock 
        producer , consumer kind of problem 
        Queue
        https://docs.python.org/3/library/queue.html
    Semaphore Objects 
        N=2 or 3  thread at a time 
    Timer Objects
        execute code in future time 
    Barrier Objects
        N threads synced at N points 
Deadlock 
    when we use many sync objects 
"""
#update this code , to use Semaphore 
#2 threads at time sleeping 
import  threading 
import time 

global_var = 2
def worker(sleeptime, lock):
    global global_var    
    with lock:
        print(threading.current_thread().name, "acquired")
        time.sleep(sleeptime)
        #print("before updating", global_var)   # 3
        #global_var = global_var + 1    #4
        # another threads updates make it 5
        #print("after updating", global_var)    # ???
        print(threading.current_thread().name, "released")


if __name__ == '__main__':
    #print("Sequentially")
    #worker(5)  #MainProcess MainThread
    print("Parallel")
    ths = []
    st = time.time()
    #lock = threading.RLock()
    lock = threading.Semaphore(2)
    for _ in range(10):
        th = threading.Thread(target=worker, args=(5,lock))
        ths.append(th)
    #but start it 
    [th.start() for th in ths]
    #Wait for ending - join
    [th.join() for th in ths]
    print("Time taken", time.time()-st, "secs")


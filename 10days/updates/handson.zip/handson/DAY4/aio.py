import asyncio 
import random, time 
"""
async for def 
in async , await 
https://docs.python.org/3/library/asyncio.html
"""
async def child(name, *, delay=None):
    print(f"-->{name}")
    de = random.uniform(0.5, 2.0)
    if delay:
        de = delay
    await asyncio.sleep(de)
    print(f"<--{name}")
    return 42 * de
    
async def main():
    print("Main started")
    res = await child("C1")
    print("C1 returned", res)
    print("Main ended")
    
    #OPTION-1
    st = time.time()
    tasks = [asyncio.create_task(child(f"C{i}", delay=5)) for i in range(10)]
    await asyncio.sleep(5)
    res = [(await t) for t in tasks]
    print("Time taken:", time.time()-st, "sec")
    #OR OPTION-2
    st = time.time()
    tasks = [asyncio.create_task(child(f"C{i}", delay=5)) for i in range(10)]
    res = await asyncio.gather(*tasks)
    print(res)
    print("Time taken:", time.time()-st, "sec")
    
    
if __name__ == '__main__':
    asyncio.run(main())

"""
SQlalchemy connection 
https://docs.sqlalchemy.org/en/20/core/engines.html
SQLMODEL based on sqlalchemy, but simplified 

Using DATABASE URL 
    DB API(sql based) or ORM (class based)
    Oracle, mysql,...
    For each engine, we have modules 

"""
from sqlalchemy import create_engine, text , inspect 
import json 

path = r"D:\handson\DAY2\data\example.json"

with open(path, "rt") as f:
    obj = json.load(f)
    
data = [ {'id': e['empId'], 
          'fn': e['details']['firstName'] + " " + e['details']['lastName'], 
          'state':e['details']['address']['state']
            }    for e in obj]
            
#{'id': 1, 'fn': 'John Smith', 'state': 'NY'}
engine = create_engine("sqlite:///foo.db")
#https://docs.sqlalchemy.org/en/20/core/reflection.html
ip = inspect(engine)

c_s = "create table if not exists employee(id int, fn varchar(50),state varchar(5))"
i_s = "insert into employee values(:id, :fn, :state)"
s_s = "select * from employee"
g_s = "select count(*) from employee group by state"

with engine.connect() as con:
    con.execute(text(c_s))
    for d in data:
        con.execute(text(i_s), d)
    con.commit() 
    
with engine.connect() as con:
    cur = con.execute(text(s_s))
    print(cur.fetchall())
    cur = con.execute(text(g_s))
    print(cur.fetchall())
    
print(ip.get_table_names())
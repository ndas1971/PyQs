# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 
"""
STEP1:
    initialization paramaters 
    each might be instance variable - prefix self.
STEP2: initializer method  __init__
    taking initialization parameter 
STEP3: 
    write all other methods 
    which uses instance variable 

self 
    not a keyword 
    must be first arg where py puts instance 
Special methods 
    https://docs.python.org/3/reference/datamodel.html
    

Python OOP - Learning Python by Mark Lutz 
    no access control 
    instance method and variable 
        prefix self or first arg self 
    class method or variable 
        variable 
            define in the body 
            and access like className.variable 
        method 
            with @classmethod , 
            to access class variable 
    Static method 
        where there is no first arg 
    property 
        Access like a variable
        it calls a function 
    Metaclass 
        class is an instance of Metaclass
    No abstract/interface 
        abc module contains Abstract
        implements using metaclass 
    Slots 
        Restricting creating variable from outside 
    Patterns 
        Iterator 
        Decorator 
        Singleton 
    Reflection 
        .__class__ 
    
"""
class NotEnoughBalance(Exception):  # inheritance 
    pass 

class BankAccount:
    count = 0               #class variable 
    def __init__(self, init_amount:float) -> None: #self=ba, init_amount=100
        self.amount = init_amount    #ba.amount = 100
        BankAccount.count += 1
    @classmethod 
    def get_count(cls):  #cls = BankAccount, call as BankAccount.get_count()
        return cls.count 
    @staticmethod
    def version():          #BankAccount.version()
        return '0.0.1'
    @property 
    def balance(self):      #instance.balance <- Note there is no ()
        print("Accessing amount")
        return self.amount 
    def transact(self, amount:float) -> None:      #self = ba, amount =100
        if self.amount + amount < 0:
            raise NotEnoughBalance("not possible")
        self.amount += amount        #ba.amount = 200
    def __str__(self):
        return f"BankAccount:amount:{self.amount}"
        
class SpecialBankAccount(BankAccount):   
    def transact(self, amount:float) -> None:
            try:
                super().transact(amount)
                if amount < 0:
                    cb = self.get_cashback_percentage() * abs(amount)
                    super().transact(cb)
            except NotEnoughBalance:
                print("Not possible", "Amount:",amount)    
    def get_cashback_percentage(self)->float:
        return 0.05
        
if __name__ == '__main__':  # pragma: no cover
    #creating instance 
    #ba = BankAccount(100) #BankAccount.__init__(ba, 100)
    #try:
    #    ba.transact(-200)      #BankAccount.transact(ba, 100)
    #except NotEnoughBalance as ex:
    #    print(ex)
    #print(ba)             #BankAccount.__str__(ba)
    
    accs:list[BankAccount] = [BankAccount(100), 
        SpecialBankAccount(100)]
    amounts:list[float] = [100, -200, 500, -300, 400]
    for ac in accs:
       for am in amounts:           
            try:
                ac.transact(am)
            except NotEnoughBalance as ex:
                print(ex)
       print(ac.balance)
       
    print(f"""
    How many={BankAccount.get_count()}
    version = {BankAccount.version()}
    """)
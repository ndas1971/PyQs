from oop import *

"""
Execute by 
pytest -v test_classes.py 

Module must have "test" prefix 
Testcase is a function having test prefix 
    Must use assert condition 
    if condition fails, testcase fails 
Test Suite
    collection of similar testcase 
    is a class with Test prefix 
    
Coverage Reports
pytest --cov=classes --cov-report term-missing -v test_classes.py

Under package (must have - poetry add --group dev pytest-cov)
pytest --cov=oop --cov-report term-missing 

Filtering :
Marker 
k expression 

My testcase names are 
test_ba 
test_sp_ba

 -k EXPRESSION         Only run tests which match the given substring
                        expression. An expression is a Python evaluable
                        expression where all names are substring-matched against
                        test names and their parent classes. Example: -k
                        'test_method or test_other' matches all test functions
                        and classes whose name contains 'test_method' or
                        'test_other', while -k 'not test_method' matches those
                        that don't contain 'test_method' in their names. -k 'not
                        test_method and not test_other' will eliminate the
                        matches. Additionally keywords are matched to classes
                        and functions containing extra names in their
                        'extra_keyword_matches' set, as well as functions which
                        have names assigned directly to them. The matching is
                        case-insensitive.

#only execute test_sp_ba
pytest -k test_sp_ba -v 
pytest -k "test_sp_ba or test_ba" -v 

"""

def test_ba():
    ba = BankAccount(100)
    ba.transact(100)
    assert ba.amount == 200

def test_sp_ba():
    ba = SpecialBankAccount(100)
    ba.transact(100)
    ba.transact(-100)
    assert ba.amount == 105
import multiprocessing 
import time 

def worker(dt):
    print("-->", multiprocessing.current_process().name)
    time.sleep(dt)
    print("<--", multiprocessing.current_process().name)
    
if __name__== '__main__':
    print("sequential")
    worker(5)
    print("concurrently")
    ths = []
    st = time.time()
    for _ in range(10):
        th = multiprocessing.Process(target=worker, 
            args=(5,))
        ths.append(th)
    #start explictly 
    [th.start() for th in ths] 
    #wait for end 
    [th.join() for th in ths] 
    print(f"Time taken: {time.time()-st} secs")
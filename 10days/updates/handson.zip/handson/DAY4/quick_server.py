from flask import Flask 

"""
class flask.Flask(import_name, 
static_url_path=None, static_folder='static', template_folder='templates',

static_host=None, host_matching=False, subdomain_matching=False, 
instance_path=None, instance_relative_config=False, 
root_path=None)

static 
    favicon.ico
    
templates 
    jinjs templates 
    
Integrating favicon.ico 
Browser asks from GET /favicon.ico 
We are serving from /static/favicon.ico
    Option-1 
        mention in html 
        <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    Option-2 
        redirect
    Option-3:
        Handle /favicon.ico  and serve from /static/favicon.ico


"""

app = Flask(__name__)


#GET, / , Content-Type, payload 
@app.route("/")    #http://localhost:5000/
def hello():
    return """
    <html>
    <head><title>My Webserver</title>
    <style>
    .some{
        color: red;
    }
    </style>
    <body>
    <h1 id="some" class="some">Hello there</h1>
    <h1 id="some2" class="some">Hello again</h1>
    </body>
    </html>
    """
    
@app.route("/favicon.ico")
def favicon():
    return app.send_static_file("favicon.ico")
    
#Display env var, user can give which env var to be shown 
import os 
from flask import request , render_template

@app.route("/env", methods=['GET', 'POST'])
def env():
    if request.method == 'POST':
        color = request.form.get("color", "black").lower()
        envp = request.form.get("envp", "ALL").upper()  # request.form is a dict .get(key, default)
        env_dict = os.environ 
        # if os.environ.get(envp.upper(), "NotFound") != "NotFound":
        #     env_dict = {envp: os.environ[envp.upper()]}
        match envp:
            case "ALL" | '':
                pass
            case s:
                env_dict = {k:os.environ.get(k.upper()) 
                                for k in s.split(";") 
                                    if os.environ.get(k.upper(), None) }
            
        return render_template("env.html",envs=env_dict, color=color)
    else: #GET 
        #display form 
        return """
    <html>
    <head><title>Give Env</title>    
    <body>
    <form action="/env" method="post">
        Give Env var:<input type="text" name="envp" value="ALL" />
        <br/>
        Give color:<input type="text" name="color" value="black" />
        <br/>
        <input type="submit" value="Submit" />
    </form>
    </body>
    </html>        
        """

"""
GET params 
    1. URL params 
        http://localhost:5000/helloj?name=das&format=json 
        request.args = {'name': 'das', 'format': 'json'}
    2. Path Params 
        http://localhost:5000/helloj/das/json 
        Flask gives in function arguments 
        
Post/body params 
    Content-Type= application/json 
    in body 
    {"name": "das", "format": "json" }

"""
@app.route("/helloj", methods=['GET', 'POST']) #http://localhost:5000/helloj?name=das&format=json 
@app.route("/helloj/<string:name>/",  methods=['GET'])  #http://localhost:5000/helloj/das/
@app.route("/helloj/<string:name>/<string:format>",  methods=['GET']) #http://localhost:5000/helloj/das/json
def helloj(name="ABC", format="json"):
    args = request.args 
    json_data = None 
    if 'Content-Type' in request.headers and \
        request.headers['Content-Type'] in ["application/json"]:
            json_data = request.json 
    return dict(args=args, json=json_data)
    
"""
import requests
#GET
url1 = "http://localhost:5000/helloj?name=das&format=json"
url2 = "http://localhost:5000/helloj/das/json"
url3 = "http://localhost:5000/helloj/das"

#Post
url4 = "http://localhost:5000/helloj"

for url in [url1, url2, url3]:
    resp = requests.get(url)
    print(resp.json())


#Post 
resp = requests.post(url4, json={'name':'das'})
print(resp.json())

"""
    
if __name__ == '__main__':
    #http://localhost:5000
    #run(host=None, port=None, debug=None, load_dotenv=True, **options)
    app.run()

    
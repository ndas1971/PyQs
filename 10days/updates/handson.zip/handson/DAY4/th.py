"""
Concurrent Programming 

One thread 
    asyncio 
        IO bound 
        co-op multitasking 
Multithread, one process 
    threading 
Multi process, single host 
    multiprocessing 
Multihost, cluster compute 
    spark

Thread 
    process may create them - light wt 
    GIL- IO bound activity 
Process
    heavy wt
    CPU bound     
By default, we cork in MainProcess MainThread

Synchronization 
    join 
    Lock/RLock
        mutex - one thread at a time 
    Condition objects
        prod/consumer
    Semaphore objects
        N thread at a time 
    Event objects
        pub/sub application 
    Timer objects
        executing in future 
    Barrier objects
        intermediate sync for N threads at N points 
Deadlock 
    Usage multi sync objects 
Two Highlevel API 
    prod/consumer 
        Queue 
    MapReduce/fork-join 
        1 master - N worker 
        Master spwan Workers, workers work/map/fork  
        send the result back to master 
        master does reduce/collate/join 
        Use executor 
        https://docs.python.org/3/library/concurrent.futures.html
"""
import threading 
import time 

def worker(dt,lck):
    if lck:
        with lck:
            print("-->", threading.current_thread().name)
            time.sleep(dt)
            print("<--", threading.current_thread().name)
    
if __name__== '__main__':
    print("sequential")
    worker(5, None)
    print("concurrently")
    lck = threading.Semaphore(2)  #Lock()
    ths = []
    st = time.time()
    for _ in range(10):
        th = threading.Thread(target=worker, 
            args=(5,lck))
        ths.append(th)
    #start explictly 
    [th.start() for th in ths] 
    #wait for end 
    [th.join() for th in ths] 
    print(f"Time taken: {time.time()-st} secs")
from flask import Flask

"""
Flask(import_name, 
static_url_path=None, static_folder='static', template_folder='templates'

static_host=None, 
host_matching=False, subdomain_matching=False, 
, instance_path=None, instance_relative_config=False, 
root_path=None)

Server
    static 
        html, css, js, ico   
        browser puts in Cache
    Dynamic /template 
        SSS - jinja2 templates     
client 
    static 
        html, css 
    dynamic 
        js 
        
Now below works 
http://localhost:5000/static/favicon.ico 
Browser asks from http://localhost:5000/favicon.ico 
Solutions 
    change in html using meta 
    handle /favicon.ico 

"""


app = Flask(__name__)

from .quick_server import * 
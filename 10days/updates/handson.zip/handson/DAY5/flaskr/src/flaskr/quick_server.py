from flask import Flask , session, redirect, url_for
import os 
from flask import request , render_template

"""
class flask.Flask(import_name, 
static_url_path=None, static_folder='static', template_folder='templates',

static_host=None, host_matching=False, subdomain_matching=False, 
instance_path=None, instance_relative_config=False, 
root_path=None)

static 
    favicon.ico
    
templates 
    jinjs templates 
    
Integrating favicon.ico 
Browser asks from GET /favicon.ico 
We are serving from /static/favicon.ico
    Option-1 
        mention in html 
        <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    Option-2 
        redirect
    Option-3:
        Handle /favicon.ico  and serve from /static/favicon.ico


"""
from flaskr import app 

#app = Flask(__name__)
app.secret_key = "Put some random key which is used to sign the session cookies"
#session is dict , store, read like dict 

#decorator is also called middleware 
def auth_required(f):
    def _inner(*args, **kwargs):
        if 'username' not in session:
            #no login 
            return redirect(url_for("login"))  #instead of hardcoding, use url_for(func_name)
        else:
            return f(*args, **kwargs)            
    return _inner 
    
def check_password(username, password):
    if username == 'ganesh' and password == 'hero':
        return True 
    return False 

    
@app.route("/logout", methods=['GET', 'POST']) 
def logout():
    if 'username' in session:
        del session['username']
        return "Logged out"
    else:
        return "Nothing to logout" 

@app.route("/login", methods=['GET', 'POST']) 
def login():
    if request.method == 'POST':
        username = request.form.get("username", None)
        password = request.form.get("password", None)
        if username and password:
            res = check_password(username, password)
            if res:
                session['username'] = username
                return "Login success"
            else:
                return redirect(url_for("login"))             
        return redirect(url_for("login"))
    else: #GET 
        #display form 
        return """
    <html>
    <head><title>Give Env</title>    
    <body>
    <form action="/login" method="post">
        Give UserName:<input type="text" name="username"   required/>
        <br/>
        Give Password:<input type="text" name="password"  required/>
        <br/>
        <input type="submit" value="Submit" />
    </form>
    </body>
    </html>        
        """

#GET, / , Content-Type, payload 
@app.route("/")    #http://localhost:5000/
@auth_required    # inner decorator 
def hello():
    return """
    <html>
    <head><title>My Webserver</title>
    <style>
    .some{
        color: red;
    }
    </style>
    <body>
    <h1 id="some" class="some">Hello there</h1>
    <h1 id="some2" class="some">Hello again</h1>
    </body>
    </html>
    """
    
    
@app.route("/favicon.ico")
def favicon():
    return app.send_static_file("favicon.ico")
    
#Display env var, user can give which env var to be shown 


@app.route("/env", methods=['GET', 'POST'])
def env():
    if request.method == 'POST':
        color = request.form.get("color", "black").lower()
        envp = request.form.get("envp", "ALL").upper()  # request.form is a dict .get(key, default)
        env_dict = os.environ 
        # if os.environ.get(envp.upper(), "NotFound") != "NotFound":
        #     env_dict = {envp: os.environ[envp.upper()]}
        match envp:
            case "ALL" | '':
                pass
            case s:
                env_dict = {k:os.environ.get(k.upper()) 
                                for k in s.split(";") 
                                    if os.environ.get(k.upper(), None) }
            
        return render_template("env.html",envs=env_dict, color=color)
    else: #GET 
        #display form 
        return """
    <html>
    <head><title>Give Env</title>    
    <body>
    <form action="/env" method="post">
        Give Env var:<input type="text" name="envp" value="ALL" />
        <br/>
        Give color:<input type="text" name="color" value="black" />
        <br/>
        <input type="submit" value="Submit" />
    </form>
    </body>
    </html>        
        """

"""
GET params 
    1. URL params 
        http://localhost:5000/helloj?name=das&format=json 
        request.args = {'name': 'das', 'format': 'json'}
    2. Path Params 
        http://localhost:5000/helloj/das/json 
        Flask gives in function arguments 
        
Post/body params 
    Content-Type= application/json 
    in body 
    {"name": "das", "format": "json" }

"""
import os 
from flask import Response, jsonify, g 
DATABASE = os.path.join(app.root_path, "people.db")
from sqlalchemy import create_engine, text 
import xml.etree.ElementTree as ET

def get_db():
    db = getattr(g, '_database', None)
    if not db:
        db = g._database = create_engine("sqlite:///"+DATABASE, echo=False)
        print( "sqlite:///"+DATABASE, os.path.exists("sqlite:///"+DATABASE))
    return db 
    
def get_age(name):
    db = get_db()
    sql = "select age from people where name = :name"
    with db.connect() as con:
        q = con.execute(text(sql), dict(name=name))
        res = q.fetchone()
        if res :
            return res[0]
        else:
            return None 
    



@app.route("/helloj", methods=['GET', 'POST']) #http://localhost:5000/helloj?name=das&format=json 
@app.route("/helloj/<string:name>/",  methods=['GET'])  #http://localhost:5000/helloj/das/
@app.route("/helloj/<string:name>/<string:format>",  methods=['GET']) #http://localhost:5000/helloj/das/json
def helloj(name="ABC", format="json"):
    fname = name 
    fformat = format 
    if request.method == 'GET':
        fname = request.args.get('name', name)
        fformat = request.args.get('format', format)
    else:
        if 'Content-Type' in request.headers:
            if request.headers['Content-Type'] in ['application/json']:
                fname = request.json.get('name', name)
                fformat = request.json.get('format', format)
            elif request.headers['Content-Type'] in ['application/xml']:
                root = ET.fromstring(request.data)
                el = root.findall("./name")
                if el:
                    fname = el[0].text
                else:
                    fname = name 
                fformat = "xml"
            else:
                return "Content type no recognized" 
    age = get_age(fname.lower())
    if fformat == 'json':
       if age is not None:
           success = dict(name=fname, age=age)
           resp = jsonify(success)
           resp.status_code = 200 
       else:
           error = dict(name=fname, details="Not found")
           resp = jsonify(error)
           resp.status_code = 500 
       return resp  
    elif fformat == 'xml':
       response = f"""<?xml version="1.0"?>
                     <data><name>{fname}</name>
                     <age>{age}</age>
                     </data>"""
       resp = Response(response=response, status=200, mimetype="application/xml")
       return resp        
    else:
       return "Format not recognized"
        
    
    
"""
import requests
#GET
url1 = "http://localhost:5000/helloj?name=das&format=json"
url2 = "http://localhost:5000/helloj/das/json"
url3 = "http://localhost:5000/helloj/das"

#Post
url4 = "http://localhost:5000/helloj"

for url in [url1, url2, url3]:
    resp = requests.get(url)
    print(resp.json())


#Post 
resp = requests.post(url4, json={'name':'das'})
print(resp.json())

#xml 
import xml.etree.ElementTree as ET
resp = requests.post(url4, data="<data><name>das</name></data>", 
    headers={'Content-Type': 'application/xml'})
root = ET.fromstring(resp.text)
ET.dump(root)

"""
    
if __name__ == '__main__':
    #http://localhost:5000
    #run(host=None, port=None, debug=None, load_dotenv=True, **options)
    app.run()

    
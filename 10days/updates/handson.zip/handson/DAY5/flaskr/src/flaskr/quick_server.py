from flaskr import app 


#URL enpoint a function 
#http://localhost:5000/
@app.route("/", methods=['GET'])
def home():
    return """
    <html>
    <body>
    <h1>Hello There!!</h1>
    </body>
    </html>"""
    
    
"""
How to invalidate the cache
    firefox 
        CRTL+SHIFT+R 
    chrome
        access http://localhost:5000/favicon.ico 

"""
@app.route("/favicon.ico", methods=['GET'])
def favicon():
    return app.send_static_file('favicon.ico')
    
    
"""
Form Submission 
    jinja temple for Server side scripting 
REST server 
request
    to check HTTP request 
"""
from flask import request, render_template 
import os
#http://localhost:5000/env 
@app.route("/env", methods=['POST', 'GET'])
def env():
    if request.method == 'POST':     
        #name="envp"
        #all form data is part of request.form dict 
        #print(f"{request.form=}")
        envp = request.form.get("envp", "ALL").strip().upper()
        #print(f"{envp=}")
        if envp == '' or envp == "ALL":
            env_dict = os.environ
        else:
            env_dict = {}
            for k in envp.split(","):
                env_var = k.strip()
                if env_var in os.environ:
                    env_dict[env_var] = os.environ[env_var]
        #print(f"{env_dict=}")
        return render_template("env.html", envs=env_dict)
    else:
        return """
        <html>
        <head><title>Dump envVar</title></head>
        <body>
        <form method="post" action="/env" >
        Give env Var : <input type="text" name="envp" value="ALL" />
        <br /><br />
        <input type="submit" value="Submit" />
        </form>
        </body>
        </html>
        """
        
#REST -  URL params, path paras
#body params 
"""
URL params 
    GET URL params 
        http://localhost:5000/helloj?name=das&format=json
    PATH params 
        http://localhost:5000/helloj/das/json
BODY params - POST
    Content-Type == application/json 
    bod contains josn string '{"name": "das", "format": "json"}'
"""
from flask import jsonify
@app.route("/helloj", methods = ['GET', 'POST']) #GET URL PARAMS, POST PARAMS 
@app.route("/helloj/<name>/<format>", methods=['GET']) #PATH params 
def helloj(name="abc", format="json"): #PATH params 
    #DB 
    emp = [dict(name="das", age=50), dict(name="abc", age=40)]
    #get user input 
    #GET URL 
    fname, fformat = name, format            #PATH 
    if request.method == 'GET':
        fname = request.args.get('name', name) #GET URL 
        fformat = request.args.get('name', format)
    else:
        #POST or BODY params 
        if 'Content-Type' in request.headers \
                    and 'application/json' in request.headers['Content-Type']:
            fname = request.json.get('name', name)
            fformat = request.json.get('name', format)
    #find age 
    age = None 
    for e in emp:
        if fname.lower() == e['name'].lower():
            age = e['age']
    #return json paylod 
    if age:
        success = dict(name=fname, age=age)
        resp = jsonify(success)
        resp.status_code = 200
    else:
        #error
        error = dict(name=fname, details="not found")
        resp = jsonify(error)
        resp.status_code = 500
    return resp 
    
"""
import requests 

url1 = "http://localhost:5000/helloj?name=das&format=json"
url2 = "http://localhost:5000/helloj/das/json"
url3 = "http://localhost:5000/helloj/nobody/json"
urls = [url1, url2, url3]
for url in urls :
    resp = requests.get(url)
    print(resp.json())
    
#post 
url4 = "http://localhost:5000/helloj"
obj = dict(name="das", format="json")
headers = {'Content-Type': 'application/json'}
resp = requests.post(url4, json=obj, headers=headers)
print(resp.json())


"""
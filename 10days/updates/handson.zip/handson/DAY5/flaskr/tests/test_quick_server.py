from flaskr import app 
import pytest 
import requests 
from bs4 import BeautifulSoup 

"""
unit testing 
    FlaskTestClient 
        https://flask.palletsprojects.com/en/stable/api/#flask.testing.FlaskClient
e2e or system testing
    using requests 
"""
@pytest.mark.unit 
def test_root_path():
    client = app.test_client()
    res = client.get("/")
    assert res.status_code == 200 
    assert "Hello" in res.text

#must start the server 
#so disable by default running 
@pytest.mark.e2e                  
def test_root_path_e2e():
    res = requests.get("http://localhost:5000/")
    assert res.status_code == 200 
    assert "Hello" in res.text
    
@pytest.mark.e2e                  
def test_env_e2e():
    #params = URL params, data = post params , json = json body 
    res = requests.post("http://localhost:5000/env", data={'envp': 'ALL'})
    assert res.status_code == 200 
    #Parse 
    soup = BeautifulSoup(res.text, 'html.parser')
    #how many trs , must be more than 1 
    res = soup.select("tr")  #arg is CSS select https://www.w3schools.com/cssref/css_selectors.php
    assert len(res) > 1 

    
@pytest.mark.e2e                  
def test_env2_e2e():
    res = requests.post("http://localhost:5000/env", data={'envp': 'PATH,FLASK_APP'})
    assert res.status_code == 200 
    #Parse 
    soup = BeautifulSoup(res.text, 'html.parser')
    #how many trs , must be more than 1 
    res = soup.select("tr")  #arg is CSS select https://www.w3schools.com/cssref/css_selectors.php
    assert len(res) == 3
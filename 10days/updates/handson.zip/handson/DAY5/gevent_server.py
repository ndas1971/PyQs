from gevent.pywsgi import WSGIServer
from flaskr import app

http_server = WSGIServer(('192.168.65.60', 443), app, keyfile='key.pem', certfile='cert.pem')
#http_server = WSGIServer(('192.168.65.60', 8080), app)
http_server.serve_forever()

"""
http://192.168.65.60:8080/env 

"""
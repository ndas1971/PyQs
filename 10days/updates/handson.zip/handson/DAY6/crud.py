from fastapi import FastAPI, Request, HTTPException
from typing import Any, Annotated 
from pydantic import BaseModel
import threading 

app = FastAPI()


class Item(BaseModel):
    name: str 
    description: str |None = None 
    price : float 
    tax: float|None = None 
    
class LockedDict:
    items: dict[int, Item] = {}
    lock = threading.RLock()
    @classmethod 
    def delete(cls, item_id=None):
        with cls.lock:
            try:
                if item_id :
                    del cls.items[item_id]
                else:
                    cls.items.clear()
            except:
                pass 
    @classmethod 
    def create(cls, item:Item):
        with cls.lock:
            next_key = (max(cls.items.keys()) + 1) if cls.items else 1
            cls.items[next_key] = item.model_copy()
    @classmethod         
    def update(cls, item_id:int, item:Item):
        with cls.lock:
            if item_id in cls.items:
                cls.items[item_id] = item.model_copy()        
    @classmethod         
    def get(cls, item_id = None):
        lst = []
        with cls.lock:
            if item_id in cls.items:
                return cls.items[item_id]
            else:
                for k, v in cls.items.items():
                    lst.append(v.model_copy())
        return lst 
    
@app.delete("/delete/{item_id}")
@app.delete("/delete")
def delete(item_id : int|None = None):
    LockedDict.delete(item_id)
    return dict(details="deleted")
    
@app.post("/create")
def create(item:Item):
    LockedDict.create(item)
    return dict(details="created")
    
@app.get("/list/{item_id}")
@app.get("/list")
def get_list(item_id : int|None = None):
    return LockedDict.get(item_id)

@app.put("/update/{item_id}")
def update(item_id : int, item:Item):
    LockedDict.update(item_id, item)
    return dict(details="updated")
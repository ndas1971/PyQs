#Test data - fixture - scopes 
#scope means when to create test data and when to destroy
#function - testcase, module, package, session 
import pytest
import pytest_asyncio
import aiohttp

#dont use pytest fixture, which is for synchronous case 
#use pytest_asyncio fixture without session scope
@pytest_asyncio.fixture
async def aio_session():
    #any other setup
    print("setup phase")
    async with aiohttp.ClientSession() as session:
        yield session                 #yield as return with memory 
    #any other teardown commands 
    print("tear-down phase")

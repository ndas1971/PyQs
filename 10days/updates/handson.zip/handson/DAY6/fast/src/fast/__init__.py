from fastapi import FastAPI

app = FastAPI()

from .main import *
from .model import *
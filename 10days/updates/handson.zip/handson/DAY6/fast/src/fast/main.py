from fast import app 
from pydantic import BaseModel, Field

@app.get("/")
async def index():
    return dict(message="Hello World")
    
    
"""
GET URL params 
    any argument which is not body or path params 
Path param 
    special syntax 
Body params 
    any argument with BaseModel
"""
#http://localhost:8000/url_params?q=name&limit=20
#http://localhost:8000/url_params
#http://localhost:8000/url_params?limit=20
#http://localhost:8000/url_params?limit=ab
@app.get("/url_params")
def url_params(q: str|None = None, limit: int = 0):  #params will be converted and validated
    return dict(q=q,limit=limit)
    
"""
Experiment with http://localhost:8000/docs
"""
#Path params 
@app.get("/path_params/{item_id}")
def path_params(item_id: int):
        return dict(item_id=item_id)
        
#Body params 
class Image(BaseModel):
    url: str                #<- required as there is no default value 
    title: str|None = None   #<- optional, might not contain
    
class Item(BaseModel):
    name: str 
    description: str|None = None 
    price : float 
    tags: list[str] = []
    image: Image |None = None 
    
#item_id <- path, limit <- get params, item:body params 
@app.post("/items/{item_id}")
def all_params(item_id: int, item:Item, limit: int|None = None):
    print(item.name, item.image.title)
    return dict(item_id=item_id, limit=limit, **item.dict())
#can you write requests based e2e test case

##Depends as dependency injection 
from fastapi import Depends
from typing import Annotated
#Using that, u can seperate the common code into individual function 

def common_params(q:str, limit:int):
    return dict(q=q, limit=limit)   
    
def db_connection():
    print("preprocessing")
    yield dict(connection="TODO")
    print("postprocessing")
    
@app.get("/p1")
def p1(input: Annotated[dict, Depends(common_params)], 
          db: Annotated[dict, Depends(db_connection)]):
    return dict(name="p1", **input, **db)
    
    
@app.get("/p2")
def p2(input: Annotated[dict, Depends(common_params)]):
    return dict(name="p2", **input)
from fast import app 
from typing import Annotated

from fastapi import  Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm #poetry add python-multipart
from sqlmodel import SQLModel, Field, create_engine, Session, select #poetry add sqlmodel
from jose import jwt, JWTError    #poetry add "python-jose[cryptography]"
from datetime import timedelta, datetime

#import below 
from sqlmodel.ext.asyncio.session import AsyncSession #poetry add aiosqlite
from sqlalchemy.ext.asyncio import create_async_engine 


class Book(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key= True)
    title: str 
    author: str 
    price: float 
    
engine = create_engine("sqlite:///db.sqlite")
#engine_a = create_async_engine("sqlite+aiosqlite:///db_a.sqlite")


    
def get_session():
    with Session(engine) as session:
        yield session 


#Implement tokenUrl with form 
#must return json with token 
#user must use this token in header called authorization 
#sever parse the token , see the validity 


SECRET_KEY = "SUPER_SECRET"
ALGO = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/login")

class User(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key= True)
    username: str 
    password: str 
    
@app.post("/login")
def login(session: Annotated[Session, Depends(get_session)], 
        form: OAuth2PasswordRequestForm = Depends()):
    #form.username and form.password 
    user = session.exec(select(User).where(User.username == form.username)).first()
    if not user:
        raise HTTPException(status_code=401, details="Unauthorized")
    payload = dict(sub=user.username)
    token = create_token(payload)
    return {'access_token': token, 'token_type': 'bearer'}
    
    
def create_token(payload):
    data = payload.copy()
    data['exp'] = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    token = jwt.encode(data, SECRET_KEY, algorithm=ALGO)
    return token 
    
def get_current_user(token: Annotated[str, Depends(oauth2_scheme)],  
            session: Annotated[Session, Depends(get_session)]):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGO])
        username = payload.get('sub', None)
        if not username:
            raise HTTPException(status_code=401, details="Wrong token")
        user = session.exec(select(User).where(User.username == username)).first()
        if not user:
            raise HTTPException(status_code=401, details="No user found")
        return user 
    except JWTError as ex:
        raise HTTPException(status_code=401, details="JWTError:{ex}")
    
    
    
@app.on_event('startup')
def create_db():
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        session.add(User(username="self", password="selfpass"))
        session.commit()


#CRUD - ORM - table -> class 
       
async def get_session_a():
    async with AsyncSession(engine_a) as session:
        yield session 
        
#Create
@app.post("/book", response_model=Book)
def create_book(book:Book, session: Annotated[Session, Depends(get_session)],
            user:Annotated[User, Depends(get_current_user)]):
    session.add(book)
    session.commit()
    session.refresh(book)
    return book
    
#READ
@app.get("/books", response_model=list[Book])
def list_book(session: Annotated[Session, Depends(get_session)]):
    #stmt = select(Book.price, Book.title)
    #stmt = select(Book.price, Book.title).where(Bool.author == "Abhiram")
    stmt = select(Book)
    result = session.exec(stmt)  #await in async 
    return result.all()
    
#Update 
@app.put("/book/{book_id}", response_model=Book)
def update_book(book_id: int, new_book:Book, session: Annotated[Session, 
        Depends(get_session)],
            user:Annotated[User, Depends(get_current_user)]):
    book = session.get(Book, book_id) #await in async 
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    book.title = new_book.title 
    book.author = new_book.author 
    book.price = new_book.price 
    session.commit()            #await in async 
    session.refresh(book)       #await in async 
    return book

#Delete 
@app.delete("/book/{book_id}")
def delete_book(book_id: int, session: Annotated[Session, Depends(get_session)],
            user:Annotated[User, Depends(get_current_user)]):
    book = session.get(Book, book_id)  #await in async 
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    session.delete(book)  #await in async 
    session.commit()      #await in async 
    return {"deleted" : True}
    
    
# @app.post("/abook", response_model=Book)
# async def create_book_a(book:Book, session: Annotated[Session, Depends(get_session_a)]):
#     session.add(book)
#     await session.commit()
#     await session.refresh(book)
#     return book
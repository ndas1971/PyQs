import pytest 
import requests
import aiohttp

@pytest.mark.skip
def test_root_path():
    with requests.Session() as session:
        resp = session.get("http://localhost:8000/")
        assert resp.status_code == 200
        assert resp.json() == {'message': 'Hello World'}

  
@pytest.mark.skip  
@pytest.mark.asyncio     #<- testing async def test cases
async def test_root_path_a2():
    async with aiohttp.ClientSession() as session:     #<- asynchronous Context management protocol 
        async with session.get("http://localhost:8000/") as resp:
            assert resp.status == 200   
            data = await resp.json()    
            assert data == {'message': 'Hello World'}
            
            
@pytest.mark.skip
@pytest.mark.asyncio
async def test_root_path_a(aio_session): #aio_session coming from conftest
    async with aio_session.get("http://localhost:8000/") as resp:
        assert resp.status == 200    #note no await here , comes from API
        data = await resp.json()     #note await here 
        assert data == {'message': 'Hello World'}
        
@pytest.mark.skip
@pytest.mark.asyncio
async def test_all_params(aio_session):
    data = {
          "name": "abc",
          "description": "dfg",
          "price": 12.3,
          "tags": ["loc"],
          "image": {
            "url": "http://image.com",
            "title": "demo"
          }
        }
    headers = {'Content-Type': 'application/json'}
    params = {'limit': 200 }
    url = "http://localhost:8000/items/2"
    async with aio_session.post(url, params=params, json=data, headers=headers) as resp:
        assert resp.status == 200    
        data = await resp.json()    
        assert data['limit'] == 200
        assert data['price'] == 12.3
        assert data['image']['title'] == "demo"
        
@pytest.mark.skip
def test_all_params_s():
    data = {
          "name": "abc",
          "description": "dfg",
          "price": 12.3,
          "tags": ["loc"],
          "image": {
            "url": "http://image.com",
            "title": "demo"
          }
        }
    headers = {'Content-Type': 'application/json'}
    params = {'limit': 200 }
    url = "http://localhost:8000/items/2"
    resp = requests.post(url, params=params, json=data, headers=headers) 
    assert resp.status_code == 200    
    data = resp.json()    
    assert data['limit'] == 200
    assert data['price'] == 12.3
    assert data['image']['title'] == "demo"
    
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzZWxmIiwiZXhwIjoxNzY4MzkxNDUwfQ.rAYEa-LFF8WJuyTxsq24t0Z3Bmo5QFQJveZCLutRpMM"
#Test create 
@pytest.mark.skip
@pytest.mark.asyncio 
async def test_book_create(aio_session):
    book = {
      "title": "Understanding Asyncio",
      "author": "Abhiram",
      "price": 3000.0
    }
    headers = {'Content-Type': 'application/json',
            "Authorization": f"Bearer {TOKEN}"
        }
    async with aio_session.post("http://localhost:8000/book", json=book,headers=headers)  as resp:
        data = await resp.json()
        assert data['price'] == 3000.0
        
@pytest.mark.skip
@pytest.mark.asyncio 
async def test_list_books(aio_session):
    url = "http://localhost:8000/books"
    headers = {
            "Authorization": f"Bearer {TOKEN}"
        }
    async with aio_session.get(url, headers=headers) as resp:
        data = await resp.json()
        #print(data)
        assert type(data) is list  
     



     
@pytest.mark.skip 
@pytest.mark.asyncio 
async def test_book_create_a(aio_session):
    book = {
      "title": "Understanding Asyncio",
      "author": "Abhiram",
      "price": 3000.0
    }
    headers = {'Content-Type': 'application/json'}
    async with aio_session.post("http://localhost:8000/abook", json=book,headers=headers)  as resp:
        data = await resp.json()
        assert data['price'] == 3000.0
        
        
#Automated test 
BASE_URL = "http://127.0.0.1:8000"

@pytest.mark.asyncio
async def test_jwt_crud():
    async with aiohttp.ClientSession(base_url=BASE_URL) as client:

        # Login user -> get token
        async with client.post(
            "/login",
            data={"username": "self", "password": "selfpass"}
        ) as resp:
            assert resp.status == 200
            login_data = await resp.json()
            token = login_data["access_token"]

        headers = {
            "Authorization": f"Bearer {token}"
        }

        # Create item
        async with client.post(
            "/book/",
            json={"title": "Test", "author": "Me", "price": 9.99},
            headers=headers
        ) as resp:
            assert resp.status == 200
            book = await resp.json()
            book_id = book["id"]

        # Read all
        async with client.get(
            "/books/",
            headers=headers
        ) as resp:
            assert resp.status == 200
            books = await resp.json()
            assert len(books) >= 1

        # Update
        async with client.put(
            f"/book/{book_id}",
            json={"title": "Updated", "author": "Me", "price": 11},
            headers=headers
        ) as resp:
            assert resp.status == 200
            updated = await resp.json()
            assert updated["title"] == "Updated"

        # Delete
        async with client.delete(
            f"/book/{book_id}",
            headers=headers
        ) as resp:
            assert resp.status == 200
            deleted = await resp.json()
            assert deleted["deleted"] is True
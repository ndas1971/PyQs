from tpot import TPOTRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import *  
import pandas  as pd 

if __name__=="__main__":  #for Dask , required 
    df = pd.read_csv('./data/boston.csv')
    dataset = df.values
    X = dataset[:, 0:13]
    y = dataset[:, 13]

    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                        train_size=0.75, 
                                                        test_size=0.25)  


    '''
    for genetic programming configuration, Main parameters are 
        generations: int, optional (default=100)
            Number of iterations to the run pipeline optimization process. 
            Must be a positive number.
            Generally, TPOT will work better when you give it more generations 
            (and therefore time) to optimize the pipeline.
            TPOT will evaluate population_size + generations × offspring_size pipelines 
            in total. 
        population_size: int, optional (default=100)
            Number of individuals to retain in the genetic programming population 
            every generation. Must be a positive number.
            Generally, TPOT will work better when you give it more individuals 
            with which to optimize the pipeline. 

    '''
    #increase generations, and population_size, default both =50 
    #but would take 5hrs
    #TPOT also provides a warm_start parameter that lets you restart a TPOT run from where it left off.

    print("""\n\n\nAtleast make generations=10 and population size=100
    currently it is too low""")
    tpot = TPOTRegressor(
        #search_space='linear-light', #for new version 
        generations=2, population_size=10,  
        n_jobs=4, early_stop=5)
    tpot.fit(X_train, y_train)
    print("Generate best pipeline", tpot.fitted_pipeline_)
    predictions = tpot.predict(X_test)
    print("Training score(R^2)", r2_score(y_train, tpot.predict(X_train)))
    print("Test score(R^2)", r2_score(y_test, predictions))
from flask import Flask 
import base64 
from io import BytesIO
import matplotlib.pyplot as plt
import numpy as np

app = Flask(__name__)



@app.route("/")
def hello():
    buf = BytesIO()
    fig, ax = plt.subplots(figsize=(3,3), layout='constrained')  # constrained is new layout algo, use this always
    x = np.linspace(0, 2, 100)
    ax.plot(x, x, label='linear')
    ax.plot(x, x*x, label='quardatic')  # label is for display 
    ax.plot(x, x*x*x, label='cubic')
    ax.set_xlabel('x label')
    ax.set_ylabel('y label')
    ax.set_title('first plot')
    ax.legend() #show data labels 
    fig.savefig(buf, format='png')
    data = base64.b64encode(buf.getbuffer()).decode('ascii')
    return f'<img src="data:image/png;base64,{data}" />'
    
    
if __name__ == '__main__':
    app.run()

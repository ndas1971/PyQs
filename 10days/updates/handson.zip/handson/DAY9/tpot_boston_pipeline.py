import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.model_selection import train_test_split

import pandas  as pd 

df = pd.read_csv('code/data/boston.csv')
dataset = df.values
X = dataset[:, 0:13]
y = dataset[:, 13]

X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    train_size=0.75, 
                                                    test_size=0.25)  
                                                    

# Average CV score on the training set was: -14.141499180547267
exported_pipeline = ExtraTreesRegressor(bootstrap=True, 
    max_features=0.95, min_samples_leaf=3, 
    min_samples_split=7, 
    n_estimators=100)

exported_pipeline.fit(X_train, y_train)
print(
exported_pipeline.score(X_train, y_train),
exported_pipeline.score(X_test, y_test))

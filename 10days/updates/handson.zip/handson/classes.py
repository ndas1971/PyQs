# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 
"""
STEP1:
    initialization paramaters 
    each might be instance variable - prefix self.
STEP2: initializer method  __init__
    taking initialization parameter 
STEP3: 
    write all other methods 
    which uses instance variable 

self 
    not a keyword 
    must be first arg where py puts instance 
Special methods 
    https://docs.python.org/3/reference/datamodel.html
    

Python OOP 
    no access control 
"""
class NotEnoughBalance(Exception):  # inheritance 
    pass 

class BankAccount:
    def __init__(self, init_amount): #self=ba, init_amount=100
        self.amount = init_amount    #ba.amount = 100
    def transact(self, amount):      #self = ba, amount =100
        if self.amount + amount < 0:
            raise NotEnoughBalance("not possible")
        self.amount += amount        #ba.amount = 200
    def __str__(self):
        return f"BankAccount:amount:{self.amount}"
        
if __name__ == '__main__':  # pragma: no cover
    #creating instance 
    ba = BankAccount(100) #BankAccount.__init__(ba, 100)
    try:
        ba.transact(-200)      #BankAccount.transact(ba, 100)
    except NotEnoughBalance as ex:
        print(ex)
    print(ba)             #BankAccount.__str__(ba)
    
    accs = [BankAccount(100), 
       BankAccount(100)]
    amounts = [100, -300, 200, -300, 400]
    for ac in accs:
       for am in amounts:           
            try:
                ac.transact(am)
            except NotEnoughBalance as ex:
                print(ex)
       print(ac)
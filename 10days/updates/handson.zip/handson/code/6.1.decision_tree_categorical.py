import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import *
from sklearn import datasets
from sklearn_pandas import DataFrameMapper
from sklearn.model_selection import * 
from sklearn.ensemble import *  
from sklearn.tree import *

print("""
Features with Categorical (example - surveys.csv)
Note sklearn can not handle categorical string directly (y or feature)
Use LabelEncoder to get numeric categorical 
For Feature, it should be one-hot encoded as well 
(OneHotEncoder after LabelEncoder     or LabelBinarizer)

Note: Only using LabelEncoder - converts to integers 
which the DecisionTreeClassifier() will treat as numeric. 
If your categorical data is not ordinal, this is not good 
- you'll end up with splits that do not make sense. 
Using a OneHotEncoder is the only current valid way, but is computationally expensive.

note Ordinal Data- data having natural order 
eg 
Like 	Like Somewhat 	Neutral 	Dislike Somewhat 	Dislike
1 	    2 	            3 	        4 	                5 
""")


#Option-0


#OPTION-1 , 
df1 = pd.read_csv('data/surveys.csv')
df1.rename(columns={'Order Quantity':'Order_Quantity', 
    'Improvement Area' :'Improvement_Area',
    'Customer type' : 'Customer_Type',
    'Overall Satisfaction': 'Overall_Satisfaction'}, inplace=True)
    
#in place of LabelEncoder 
#df1['Region'] = df1['Region'].map( {'EAST': 1, 'WEST': 2, 'NORTH': 3, 'SOUTH':4} ).astype(int)
#df1['Customer_Type'] = df1['Customer_Type'].map({'Prime': 1, 'NonPrime': 0}).astype(int)
#df1['Improvement_Area'] = df1['Improvement_Area'].map({'Website UI':1, 'Packing & Shipping':2, 'Product Quality':3,}).astype(int)
#df1['Overall_Satisfaction'] = df1['Overall_Satisfaction'].map( {'Dissatisfied': 0, 'Satisfied': 1} ).astype(int)

#now OneHotEncoder , can take strings as well 
xs = ['Region','Customer_Type','Improvement_Area']
enc = OneHotEncoder() #drop='first' in later version 
X = enc.fit_transform(df1[xs])
feature_names = enc.get_feature_names()
y = df1['Overall_Satisfaction'].values 
pipe = DecisionTreeClassifier()    
        
#OPTION-2 
df2 = pd.read_csv('data/surveys.csv')
df2.rename(columns={'Order Quantity':'Order_Quantity', 
    'Improvement Area' :'Improvement_Area',
    'Customer type' : 'Customer_Type',
    'Overall Satisfaction': 'Overall_Satisfaction'}, inplace=True)

    
#'drop_first = True' could help to avoid multicolinearity problems.
#first one is deleted 
one_hot_data = pd.get_dummies(df2[['Region','Customer_Type','Improvement_Area', 'Overall_Satisfaction']],drop_first=True)
feature_names = one_hot_data.columns[:-1]
df2 = pd.concat([df2.copy(), one_hot_data],axis=1) #columnwise 
X = one_hot_data[feature_names]
y = one_hot_data[one_hot_data.columns[-1]]
pipe = DecisionTreeClassifier()        

#Option-3
#Using pipeline 
from sklearn_pandas import * 
df = pd.read_csv('data/surveys.csv')
#Overall_Satisfaction ~ Order_Quantity,Total_Purchased,Months_Customer,Customer_Type,Improvement_Area,Region
df.rename(columns={'Order Quantity':'Order_Quantity', 
    'Improvement Area' :'Improvement_Area',
    'Customer type' : 'Customer_Type',
    'Overall Satisfaction': 'Overall_Satisfaction',
    'Total Purchased': 'Total_Purchased',
    'Months Customer':'Months_Customer'}, inplace=True)
    
y = LabelEncoder().fit_transform(df['Overall_Satisfaction'])
#Dissatisfied- 0, Satisfied-1
X = df[['Order_Quantity','Total_Purchased','Months_Customer','Customer_Type','Improvement_Area','Region']]
 
from sklearn_pandas import *  
cat_features = gen_features(
        columns=['Region','Customer_Type','Improvement_Area'],
        classes=[LabelBinarizer]  
    )    
no_trans = gen_features(
        columns=['Order_Quantity','Total_Purchased','Months_Customer'],
        classes=[None]  
    )   

pipe = Pipeline([('enc', DataFrameMapper(cat_features+no_trans)), ('clf', DecisionTreeClassifier())])            
model = pipe.fit(X,y)


feature_names= pipe.named_steps['enc'].transformed_names_
print("Total features after conversion")
print(model.named_steps['clf'].n_features_ )#12 = 3 + 4(region) + 2(customertype) + 3(improvement_area)

print("Score", model.score(X,y))
print("Feature importance")
print(pipe.named_steps['clf'].feature_importances_)
#array([0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0.])
print("Feature names")
print(feature_names)
#['Region_EAST', 'Region_NORTH', 'Region_SOUTH', 'Region_WEST', 'Customer_Type','Improvement_Area_Packing & Shipping', 'Improvement_Area_Product Quality', 'Improvement_Area_Website UI', 'Order_Quantity', 'Total_Purchased', 'Months_Customer']
 
#ie 
d = dict(zip(feature_names,  pipe.named_steps['clf'].feature_importances_))
print("ie")
print(dict([(k,v)  for k,v in d.items() if v !=0]))
#{'Customer_Type': 1.0}
print("{'Prime': 1, 'NonPrime': 0}")
#plot
import graphviz 
dot_data = export_graphviz(pipe.named_steps['clf'], out_file=None, 
                         feature_names=feature_names, 
                         class_names=['Satisfied', 'Dissatisfied'],   #use enc.classes_
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("created visulization file")
graph.render('customer_survey') #'.pdf'      
print("Decision- If customer type is Prime, then he is satishfied !!!")
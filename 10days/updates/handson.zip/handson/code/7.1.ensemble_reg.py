import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)
warnings.simplefilter(action='ignore', category=DeprecationWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *

PAUSE='Y'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()

print("----------------- Various ensemble methods on Boston regression ----------------")

import time 
data = datasets.load_boston()
print(data.DESCR.encode('ascii', 'ignore').decode())
#input()

X, y = data.data, data.target 

CV= KFold(n_splits=5,shuffle=True)

st = time.time()
#min_samples_leaf=5, max_depth=5, min_samples_split=5
clf1 = DecisionTreeRegressor()
scores = cross_val_score(clf1, X, y, cv=CV) 
print("DecisionTreeRegressor\nR^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", clf1)

st = time.time()
clf2 = BaggingRegressor(clf1, max_samples=0.5, max_features=0.9)
scores = cross_val_score(clf2, X, y, cv=CV) 
print("BaggingRegressor with DT\nR^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", clf2)

pause_d()


st = time.time()
#If None, then max_features=n_features.
clf = RandomForestRegressor(n_estimators=10, max_features = None, max_depth=None)
scores = cross_val_score(clf, X, y, cv=CV) 
print("RandomForestRegressor\nR^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", clf)

st = time.time()
clf = ExtraTreesRegressor(n_estimators=10,max_features = None, max_depth=None)
scores = cross_val_score(clf, X, y, cv=CV) 
print("ExtraTreesRegressor\nR^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", clf)
pause_d()


st = time.time()
clf =  AdaBoostRegressor(n_estimators=100)
scores = cross_val_score(clf, X, y, cv=CV) 
print("AdaBoostRegressor\nR^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", clf)


st = time.time()
clf =  GradientBoostingRegressor(n_estimators=100, learning_rate=1.0, max_depth=None, random_state=0)
scores = cross_val_score(clf, X, y, cv=CV) 
print("GradientBoostingRegressor\nR^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", clf)
pause_d()

st = time.time()
clf =  GradientBoostingRegressor(n_estimators=100, learning_rate=0.1,subsample=0.5, max_features = 0.5, max_depth=None, random_state=0)
scores = cross_val_score(clf, X, y, cv=CV) 
print("StocasticGradientBoostingRegressor(bias-inc, variance-dec)\nR^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", clf)
pause_d()

print("----Ofcourse , you can Gridsearch GBM-----")
#do we scale 
scale = StandardScaler()
X = scale.fit(X).transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
clf =  GradientBoostingRegressor()
params = dict(max_features = np.arange(0.3,1.0,0.1), 
    n_estimators= np.arange(10,100,10), 
    learning_rate= np.arange(0.01, 0.5, 0.02) , 
    subsample=np.arange(0.1,1.0,0.2))
    
search = RandomizedSearchCV(clf, params)
st = time.time()
search.fit(X_train, y_train)
print("Best param for GradientBoostingRegressor", search.best_params_ )#{'n_estimators': 80}
print("score= train:%f test:%f and time=%d sec" % (search.score(X_train, y_train),
        search.score(X_test, y_test), (time.time()-st)))
best = search.best_estimator_
st = time.time()
scores = cross_val_score(best, X, y, cv=CV) 
print("R^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", best)
       
       


print("Now Gridsearch RF")
clf = RandomForestRegressor()
params = dict(max_features = np.arange(0.3,1.0,0.1), 
    n_estimators= np.arange(10,100,10), 
    min_samples_leaf= np.arange(2,10,1) , 
    max_depth=np.arange(1,10,1), 
    min_samples_split=np.arange(2,10,1))
search = RandomizedSearchCV(clf, params)
st = time.time()
search.fit(X_train, y_train)
print("Best param for RandomForestRegressor", search.best_params_ )#{'n_estimators': 80}
print("score= train:%f test:%f and time=%d sec" % (search.score(X_train, y_train),
        search.score(X_test, y_test), (time.time()-st)))
best = search.best_estimator_
st = time.time()
scores = cross_val_score(best, X, y, cv=CV) 
print("R^2: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
print("with model\n", best)


print("These methods can also ranks feature...")
pause_d()
#Higher the more important 
forest = search.best_estimator_

importances = forest.feature_importances_
#find out stddev of each tree's feature importance
std = np.std([tree.feature_importances_ for tree in forest.estimators_],axis=0) #columnwise
#Returns the indices that would sort an array.
'''
>>> x = np.array([3, 1, 2]) #
>>> np.argsort(x)
array([1, 2, 0]) #sorted array x[1], x[2], x[0]
'''
indices = np.argsort(importances)[::-1] #then reverser it, so highest is first 

# Print the feature ranking
print("Feature ranking from RandomForestRegressor:")

sorted_features = []
for f in np.arange(X.shape[1]):  #1 means feature's ie 54 
    print("%d. feature %d(%s): %3.2f%%" % (f + 1, indices[f],data.feature_names[indices[f]], importances[indices[f]]*100))
    sorted_features.append(data.feature_names[indices[f]])
    
# Plot the feature importances of the forest
plt.figure()
plt.title("Feature importances")
#yerr = is line for variation of that bar 
plt.bar(np.arange(X.shape[1]), importances[indices],color="r", yerr=std[indices], align="center")
plt.xticks(np.arange(X.shape[1]), sorted_features, rotation='vertical')
plt.xlim([-1, X.shape[1]])
plt.show()     


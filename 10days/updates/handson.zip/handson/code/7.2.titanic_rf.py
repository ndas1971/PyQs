"""
Let's go through an example from Kaggle, the Titanic dataset. 
The task here is to predict who will survive on Titanic, 
based on a subset of whole dataset.

0. Note survived is 'y', rest all are 'X' 
1. Replace nan values of embarked, fare by mode of embarked, fare 
2. Create a transformer with following transformation 
   String categorical - embarked, pclass, sex, Title
                        FamilyID
   Take as it is - fare, parch , sibsp , FamiliySize, AgeOriginallyNaN
                   AgeFilledMedianByTitle   
   Create following columns as 
        Title - get Title portion from name
        LastName  - get last name ftom name 
        FamilySize - total of sibsp and parch + 1 
        FamilyID  - String of "LastName:FamiliySize"
                    If FamiliySize <=2 , then "Small_Family"
        AgeOriginallyNaN - new column where 0 = age is NaN, 1 = age is not NaN 
            Hint: Use .isnull() and convert to int 
        AgeFilledMedianByTitle , median age for that Title 
            Find median age for each title(groupby)
            then merge that with original DF on Title 
            

"""
print(__doc__)

import numpy as np
import pandas as pd 

from sklearn.preprocessing import *  

from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV

from sklearn.ensemble import RandomForestClassifier
from sklearn_pandas import *
from sklearn.pipeline import * 


df_train = pd.read_csv('data/titanic_train.csv', header = 0, index_col = 'ticket')
df_test = pd.read_csv('data/titanic_test.csv', header = 0, index_col = 'ticket')

#axis=0 , means vertical(row) stacking , axis=1, columnwise append 
df = pd.concat([df_train, df_test], keys=["train", "test"])

'''
df.index.get_level_values(0)  #train, test 
df.index.get_level_values(1)  #ticket
df.index.names # [None, 'ticket']
df.index.names = ['type', 'ticket']
df.index.get_level_values('type')
df.index.get_level_values('ticket')
df.columns 

>>> df['sex'].reset_index()
       type              ticket     sex
0     train           A/5 21171    male
1     train            PC 17599  female

#get back 
df.loc['train', :]
df.loc['test', :]
df.loc[:, 'name' : 'sibsp']  #for all index 
df.loc[('train', '113803') , :] #one row 
df.iloc[3:4, :]  #DF 
'''

#df.mode() gives DF of most frequent , take first col 
#replace NaN of 'fare' by mode of that 
#Use fillna to replace np.nan
df.fillna({'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] }, inplace=True)

'''
#or 
df.loc[df['fare'].isnull(), 'fare'] = df['fare'].mode()[0]
#or could use replace 
df.replace({'fare':np.nan, 'embarked': np.nan}, {'fare': df['fare'].mode()[0], 'embarked': df['embarked'].mode()[0] })
'''
#drop cabin 
df.drop(columns='cabin', inplace=True)

#check any more null 
df[df.isnull().any(axis=1)]  #axis=1 is row 
df[df.isnull().any(axis=1)].loc['train',:]


#Setting up 
#Series.apply can take py fn or ufun, py fn- operates on eah element 
#df.apply has to be ufunc , if python func, vectorise with np.vectorize 
df['Title'] = df['name'].apply(lambda c: c[c.index(',') + 2 : c.index('.')])
df['LastName'] = df['name'].apply(lambda n: n[0:n.index(',')])

df['FamilySize'] = df['sibsp'] + df['parch'] + 1

df['FamilyID'] = df['LastName'] + ':' + df['FamilySize'].apply(str) #python fn, so operates on each element 
#if family size is <=2 
df.loc[df['FamilySize'] <= 2, 'FamilyID'] = 'Small_Family'

#convert age to 0 or 1 based on age is NaN or present 
df['AgeOriginallyNaN'] = df['age'].isnull().astype(int)

#for each title, get median age , and rename that column as AgeFilledMedianByTitle
medians_by_title = pd.DataFrame(df.groupby('Title')['age'].median()) \
  .rename(columns = {'age': 'AgeFilledMedianByTitle'}) #index is Title 
  
#Then for each row, fill AgeFilledMedianByTitle column 
#ie merge with df.Title with medians_by_title.index
#that merge would hamper original [train, test] sort order , hence sort_index 
df = df.merge(medians_by_title, left_on = 'Title', right_index = True) \
  .sort_index(level = 0).sort_index(level = 1) #by level 0 and the level=1 
  
#after processing , split 
df_train = df.ix['train']
X = df_train[df_train.columns.drop('survived')]
y = df_train['survived']
df_test  = df.ix['test'].drop(columns=['survived'])

#Note Categoricals are embarked, pclass, sex , title, FamilyIDD 


#to create dummy variables out of categorical ones. 
#In Scikit ,algorithms accept only float variables.
#LabelBinarizer can accept string or INT whereas oneHotEncoder can only accept numeric INT

transformations = [
                      ('embarked', LabelBinarizer()),
                      ('fare', None),
                      ('parch', None),
                      ('pclass', LabelBinarizer()),
                      ('sex', LabelBinarizer()),
                      ('sibsp', None),                                       
                      ('Title', LabelBinarizer()),
                      ('FamilySize', None),
                      ('FamilyID', LabelBinarizer()),
                      ('AgeOriginallyNaN', None),
                      ('AgeFilledMedianByTitle', None)]

mapper = DataFrameMapper(transformations,   df_out=True)

#transformed_array = mapper.fit_transform(X)
#Create pipeline 
pipeline = Pipeline([('featurize', mapper), 
    ('forest', RandomForestClassifier())])


model = pipeline.fit(X,y)
print("Training score", model.score(X, y))
#prediction
prediction = model.predict(df_test)  #their is no truth value 
np.where(prediction == 1, ["yes"], ["No"]) #change 1 to Yes
#or with dftest 
df_test['survived'] = np.where(prediction == 1, ["yes"], ["No"])
df_test.[['name', 'survived']]
df_test.loc[df_test.survived == 'yes', 'name']
df_test.groupby('survived').agg({'name': 'count'})
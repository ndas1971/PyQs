from __future__ import print_function

print('''Trains a simple deep NN on the MNIST dataset.
Gets to 99.25% test accuracy after 12 epochs
(there is still a lot of margin for parameter tuning).
16 seconds per epoch on a GRID K520 GPU.

MNIST database of handwritten digits
    Dataset of 60,000 28x28 grayscale images of the 10 digits, 
    along with a test set of 10,000 images.
    Returns:
        2 tuples:
            x_train, x_test: uint8 array of grayscale image data with shape (num_samples, 28, 28).
            y_train, y_test: uint8 array of digit labels (integers in range 0-9) with shape (num_samples,).
    Arguments:
        path: if you do not have the index file locally (at '~/.keras/datasets/' + path), it will be downloaded to this location.
    #Usage:
    from keras.datasets import mnist
    (x_train, y_train), (x_test, y_test) = mnist.load_data()

''')


import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import RMSprop

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt


batch_size = 128
num_classes = 10
epochs = 20

# the data, split between train and test sets

(x_train, y_train), (x_test, y_test) = mnist.load_data()
y_test_original = np.copy(y_test)

x_train = x_train.reshape(60000, 784)
x_test = x_test.reshape(10000, 784)
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

#Feature is scaled already(check..)
from sklearn.preprocessing import *
scaler1 = MinMaxScaler(feature_range=(-1,1))
x_train = scaler1.fit(x_train).transform(x_train)
scaler2 = MinMaxScaler(feature_range=(-1,1))
x_test = scaler2.fit(x_test).transform(x_test)

# convert numerical class to one hot encoded 
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

model = Sequential()
model.add(Dense(512, activation='relu', input_shape=(784,)))
model.add(Dropout(0.2))  #for regularize
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(num_classes, activation='softmax'))

print(model.summary())

model.compile(loss='categorical_crossentropy',
              optimizer=RMSprop(),
              metrics=['accuracy'])
#Early stopping   
filepath='best_model_2.h5'
from keras.callbacks import * 
callbacks = [EarlyStopping(monitor='val_loss', patience=2),
             ModelCheckpoint(filepath=filepath, monitor='val_loss', save_best_only=True)]


history = model.fit(x_train, y_train,
                    batch_size=batch_size,
                    epochs=epochs,
                    verbose=1,
                    callbacks=callbacks, 
                    validation_data=(x_test, y_test))
                    
#Load the best model from best_model.h5 which is compiled as well 
from keras.models import load_model
model2 = load_model(filepath)                   
score = model2.evaluate(x_train, y_train, verbose=0)
print('Train loss:', score[0])
print('Train accuracy:', score[1])
score = model2.evaluate(x_test, y_test, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])

predictions = model2.predict(x_test)
print("Predictions: note one hot encoded is not collapsed")
print(np.round(predictions))
# array([[0., 0., 0., ..., 1., 0., 0.],
       # [0., 0., 1., ..., 0., 0., 0.],
       # [0., 1., 0., ..., 0., 0., 0.],
       # ...,
       # [0., 0., 0., ..., 0., 0., 0.],
       # [0., 0., 0., ..., 0., 0., 0.],
       # [0., 0., 0., ..., 0., 0., 0.]], dtype=float32)

print("digit predictions", np.argmax(predictions, axis=1))#rowwise 
#array([7, 2, 1, ..., 4, 5, 6], dtype=int64)

from sklearn.metrics import *  
print("confusion_matrix",confusion_matrix(y_test_original, np.argmax(predictions, axis=1) ))
# array([[ 976,    1,    0,    0,    0,    1,    1,    1,    0,    0],
       # [   0, 1125,    2,    0,    0,    1,    2,    2,    3,    0],
       # [   4,    0, 1019,    2,    0,    0,    0,    4,    3,    0],
       # [   0,    0,    8,  991,    0,    1,    0,    3,    1,    6],
       # [   1,    1,    7,    0,  958,    0,    1,    3,    1,   10],
       # [   2,    1,    0,    7,    1,  877,    2,    0,    2,    0],
       # [   5,    2,    0,    1,    2,   10,  938,    0,    0,    0],
       # [   2,    1,    8,    0,    0,    0,    0, 1010,    4,    3],
       # [   5,    1,    2,    4,    1,    4,    0,    2,  950,    5],
       # [   1,    2,    0,    4,    7,    3,    0,    4,    1,  987]],
      # dtype=int64)

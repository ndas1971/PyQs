from classes import *

"""
Execute by 
pytest -v test_classes.py 

Module must have "test" prefix 
Testcase is a function having test prefix 
    Must use assert condition 
    if condition fails, testcase fails 
Test Suite
    collection of similar testcase 
    is a class with Test prefix 
    
Coverage Reports
pytest --cov=classes --cov-report term-missing -v test_classes.py 

"""

def test_ba():
    ba = BankAccount(100)
    assert ba.amount == 100


from flask import Flask, request, jsonify, render_template, make_response 
import json , os 
import logging

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

@app.route("/env", methods=['GET','POST'])#http://localhost:5000/env or http://localhost:5000/env?render=reactjsx
def env():
    render_style = request.args.get("render", "basic")
    if request.method == 'POST':
        envp = request.form.get('envp', 'all').upper()
        app.logger.info(str(request.form))
        env_dict = os.environ
        if os.environ.get(envp, "notfound") != "notfound":
            env_dict = { envp : os.environ.get(envp,"notfound") }            
        #get it from URL params         
        render_dict = dict(basic='env.html', angjs='env_angjs.html',
                           react='env_react_without_jsx.html', reactjsx='env_react_jsx.html')
        return render_template(render_dict[render_style], envs=env_dict)
    else:
        return f"""
            <html><body>
            <form action="/env?render={render_style}" method="post">
              Put Variable name :<br>
              <input type="text" name="envp" value="ALL"><br>
              <label for="chk1">Only Count</label>
              <input type="checkbox" id="chk1" name="only_count" value="count" checked><br>
              <label for="ra1">Table</label>
              <input type="radio" id="ra1" name="output_type" value="table" checked>
              <label for="ra2">Text</label>
              <input type="radio" id="ra2" name="output_type" value="text">
              <br><br>
              <input type="submit" value="Submit">
            </form> 
            </body></html>
        """
        

if __name__ == '__main__':
    app.run()    
#Update master_covid_data by today_data

master_covid_data = { 'usa' : {'+ive': 20, 'test': 200 },
                    'india': {'+ive': 15, 'test': 100 }}

today_data = {'usa' : {'+ive': 1, 'test': 1.5 },
         'india': {'+ive': 0.75, 'test': 1 },
         'af' : {'+ive': 0, 'test': 0 }} 
         
         
for country, data in today_data.items():
    if country in master_covid_data:
        old_data = master_covid_data[country]
        master_covid_data[country] = \
            {'+ive': old_data['+ive'] + data['+ive'],
            'test': old_data['test'] + data['test']}
    else:
        master_covid_data[country] = data.copy()
        
print(master_covid_data)
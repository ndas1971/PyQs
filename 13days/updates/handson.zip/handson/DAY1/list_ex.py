lst = ["OK", "NOK", "hello", "hi"]
#Q1.How many even length string #
#Q2. how many odd length string #
#Q3.What is the total length of all strings 
lst = ["OK","NOK","hello","hi"]
even, odd, total = 0,0,0
for item in lst:
    if len(item) % 2 == 0:
        even += 1
    else:
        odd += 1
    total += len(item)
print(even, odd, total)
#Other 
#----MAP, depends on that element----
#o = []
#for e in lst:
#    if len(e) % 2 == 0:
#        o.append(e)
#comprehension
#o = [e  for e in lst if len(e) % 2 == 0]  
#----REDUCE, depends on other element-----
#print(len([e  for e in lst if len(e) % 2 == 0]  ))
#
#----MAP, depends on that element----
#o = []
#for e in lst:
#    if len(e) % 2 == 1:
#        o.append(e)
#o = [e  for e in lst if len(e) % 2 == 1]   
#----REDUCE, depends on other element-----
#print(len([e  for e in lst if len(e) % 2 == 1] ))
#
#----MAP, depends on that element----
#o = []
#for e in lst:
#    o.append(len(e))
#
#----REDUCE, depends on other element-----
#print(sum([len(e)  for e in lst ]))

print(len([e  for e in lst if len(e) % 2 == 0] ))
print(len([e  for e in lst if len(e) % 2 == 1] ))
print(sum([len(e)  for e in lst ]))

#[ or { or {key:

lst = [1,2,3,4]
#sq 
[ e*e for e in lst]
[ e*e for e in lst if e % 2 == 0]
{ e*e for e in lst if e % 2 == 0}
[(e1,e2) for e1 in lst if e1 % 2 == 0 for e2 in lst if e2 % 2 == 1]
#how to write in normal way 
o = []
for e1 in lst :
    if e1 % 2 == 0:
        for e2 in lst:
            if e2 % 2 == 1:
                o.append( (e1,e2) )

#Set 
o = set()
for e1 in lst :
    if e1 % 2 == 0:
        for e2 in lst:
            if e2 % 2 == 1:
                o.add( (e1,e2) )
#dict 
o = {}
for e1 in lst :
    if e1 % 2 == 0:
        for e2 in lst:
            if e2 % 2 == 1:
                o[(e1,e2) ] = (e1,e2)
#Dict comprehension
{e: e*e for e in lst}

#find the no of Pythagoras triplet below 100
print(len([(e1,e2,e3) for e1 in range(1,100) 
    for e2 in range(e1+1,100) 
        for e3 in range(e2+1,100) 
            if (e3*e3) == (e1*e1)+(e2*e2)]))
















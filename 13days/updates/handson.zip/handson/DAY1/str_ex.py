s = "Hello World and Hello Earth"

# print frequencies of upper cased alphabets 
# H - 3
# e - ??

for ch1 in s:
    count = 1
    for ch2 in s:
        if ch1.upper() == ch2.upper():
            count += 1
    print(ch1, count)

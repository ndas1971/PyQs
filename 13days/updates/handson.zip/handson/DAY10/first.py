#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


# ### Data Engineering Workshop
# 

# In[2]:


get_ipython().run_line_magic('lsmagic', '')


# In[3]:


get_ipython().run_line_magic('quickref', '')


# ### execute shell commands by prefixing !
# 

# In[4]:


get_ipython().system('dir')


# In[5]:


# more Help 
# https://ipython.readthedocs.io/en/stable/interactive/magics.html


# In[6]:


x = np.array([1,2,3,4])                 #1, (4, )
y = np.linspace(2.0, 3.0, num=100)      #1, (100,)
z = np.arange(12)                       #1, (12,)
ru = np.random.random( (2,6) )  # 2x6   #2, (2,6)
rn = np.random.normal(0.0, 1, (6,2))    #2, (6,2)


# In[10]:


print(ru, ru.ndim, ru.shape, sep="\n")


# ### Reshape, squeeze, ravel, adding axis, np.newaxis  etc

# In[17]:


# z.reshape(3,4)            #(12,)  =>  (3,4), (2,6), (12,1), (1,12)
z1 = z.reshape(1,1,1,1, 3, 1, -1)      #ndim = 7, shape = (1,1,1,1,3,1,4)
z1.shape


# In[19]:


z1.squeeze().shape  #removing axises which contains shape 1


# In[21]:


z1.ravel().shape  #flattening to get vector 


# In[23]:


#adding new axiss, : means slice, : means all elements in row,
z[:, None].shape   #To increase dimension by adding shape 1, 
                   #use respae of this shortcut of putting None or np.newaxis


# In[24]:


z[None, :].shape


# In[25]:


#or 
z[:, np.newaxis].ravel() == z[np.newaxis, :].ravel()


# In[42]:


# accessing by [i,j,k,...]  access, can contain slice ,
# any operation like == happens elementwise 

#Accesing 
z[0]
ru[0, 0]
ru[:, 0]
ru[:, 1:2:2]  #can contain slice 
ru[ ru > 0.5]  #condition
ru[ (ru > 0.1) & (ru < 0.7) ] 
ru [0, 0] = 10
ru


# In[43]:


#elementwise ops
ru + ru  # is dimension changing?- dimension should match or see below


# In[62]:


#Broadcasting
ru + 2   #dimension is not same, but 2 can be brocasted into (2,6) diemsnion by repeating
z[:, None] + z[None, :]  # (12,1) + (1,12) => (12,12)



# In[48]:


z[None, :].shape


# In[61]:


#matrix ops
np.mat(ru) * np.mat(rn)  # 2,6  x 6,2 => 2, 2
np.mat(ru).T             # 2,6 => 6,2
np.mat(ru) * np.mat(ru).I            # 2,6 x 6,2 = I


# In[80]:


#sum , mean, std,....etc method
np.sum(ru)   #ravel and sum
ru.sum(axis=0)  # row varying - columnwise - (6,)
ru.sum(axis=1) #col varying,  rowsise - (2,)

y1= y.reshape(2,2,5,5) #(2, 2, 5, 5)
#axis =0, to 3
y1.sum(axis=0).shape  #(2,5,5)
y1.sum(axis=3).shape   #(2,2,5)  res[0,0,0] = SUM of y1[0,0,0,:]


# In[ ]:





# In[64]:


#Other methods - elementwise 
len(dir(np))
np.sqrt(ru)


# In[89]:


#hstack and vstack
x = np.array([[1,2],[3,4]])
y = np.array([5,6])
y1 = np.array([5,6,7,8])

#vstack (M,N) - below should be (1,N) , 2nd dimension is fixed and depends on first arg
np.vstack( (x, y[None, :]) )
np.vstack( (x, y1.reshape(-1, 2) ) )
#hstack - (M,N) - side wise should be (M,1) - 1st diemnsion is fixed, depends on first arg
np.hstack( (x, y[:, None]) )
np.hstack( (x, y1.reshape(2,-1) ) )


# In[82]:


x.shape, y.shape


# # Matplotlib

# In[90]:


# FigureCanvas - lowest level, Renderer knows how to use FC
# Highlevel, Artist uses Renderer
#e use Artist 
#Two interface - oo or procedural

#Display window (0,0) x(width, height) -> Figure (0,0) x(1,1) -> may contain SubFigure 
#-> Axes (0,0) x (1,1) -> our DATA, (0,0) x (data-xmax, data-ymax)

#procedural - below


# In[91]:


t = np.arange(0, 5, 0.2)


# In[92]:


plt.plot(t,t, 'r-', t,t**2, 'b-', t, t**3, 'g*')
#plt.show()  #in script, it will pause and display


# In[93]:


get_ipython().run_line_magic('run', 'code\\0.2.plt_options.py')


# ## subplots

# In[102]:


#2 x 2 , first two args, so destructure 
fig, ((ax1,ax2),(ax3,ax4)) = plt.subplots(2,2, figsize=(5,2.7), #in inch
                                         layout='tight') #check doc for how many layout
t = np.linspace(0,2,100)
#fig, axes = plt.subplots(2,2,....)
# ax1 = axes[0,0] , ax2=axes[0,1], ax3=axes[1,0],....
ax1.plot(t,t, 'c.', label='linear')
ax2.plot(t, t**2, 'm-', label='quadratic')
ax3.plot(t, np.sin(2*np.pi*t), label='sin')
ax4.plot(t, np.sin(2*np.pi*t) * np.cos(2*np.pi*t), label='sin(t)*cos(t)')
ax1.set_xlabel('himakar')
ax2.set_ylabel('break')
ax3.set_title('lunch')
ax1.legend()


# In[105]:


#Other plots 
get_ipython().run_line_magic('run', 'code\\0.2.plt_other_plot.py')


# In[107]:


#


# In[103]:


# You can draw 3D figure as well
get_ipython().run_line_magic('run', 'code\\0.2.plt_3dr_plot.py')


# # Pandas

# In[108]:


path = r"code\data\iris.csv"
iris = pd.read_csv(path)


# In[110]:


#Check metadata
iris.head()  # by default 5 or specify with arg
iris.columns
iris.index  # row_id is called index 
iris.dtypes  # each col datatype


# In[111]:


iris.head() 


# In[113]:


len(iris)  #how many rows 


# In[114]:


#DataFrame - list of Columns/Series 
type(iris), type(iris.SepalLength)


# In[115]:


len(dir(pd)), len(dir(iris)), len(dir(iris.SepalLength))


# In[118]:


#Access
#.loc[row_id, column_name] and iloc[row index, column index]
#if contains slice,  row_id - slice- end is included, in row_index, it is not 
iris.loc[0:2, ['SepalLength', 'SepalWidth']], iris.iloc[0:3, [0,1]]
#Access like dict or class attributes- only for column 
iris[['SepalLength', 'SepalWidth']]  #Single column - Series, multiple columns-DataFrame
iris.SepalLength                   #<- one col


# In[ ]:





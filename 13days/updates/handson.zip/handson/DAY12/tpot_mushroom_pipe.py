import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import train_test_split

df = pd.read_csv(r"code\data\mushroom.csv")

data = df.values
X_raw = data[:, 1:]
y_raw = data[:, 0]
oh = OneHotEncoder()
X = oh.fit_transform(X_raw)   #create sparse array 
X = np.asarray(X.todense())
enc = LabelEncoder()
y = enc.fit_transform(y_raw)
X_train, X_test, y_train, y_test = train_test_split(X, y)


# Average CV score on the training set was: 0.709620930774505
exported_pipeline = ExtraTreesClassifier(bootstrap=False, criterion="entropy", max_features=0.9500000000000001, min_samples_leaf=4, min_samples_split=4, n_estimators=100)

exported_pipeline.fit(X_train, y_train)
yHat = exported_pipeline.predict(X_test)

print(exported_pipeline.score(X_train, y_train), exported_pipeline.score(X_test, y_test))

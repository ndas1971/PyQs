#Q1. Write 5 times "hello world" to  "demo.txt" file 
#Q2.Read "demo.txt" and prepend "#" to each line and write that to "demo.bak.txt"
#Q3.Read "demo.txt" and prepend line number to each line and write that to "demo.bak2.txt"
#Q1 - Geetha, Bharath J , Rahul
out = ["Hello World\n"] * 5
path = r"demo.txt"
with open(path, "wt") as f:
    f.writelines(out)
    
#Q-2
with open(path, "rt") as f:
    lines = f.readlines()
    
lines_o1 = [ f"#{line}" for line in lines]
lines_o2 = [ f"{index+1}{line}" for index,line in enumerate(lines)]
 
with open("demo.bak.txt", "wt") as f:
    f.writelines(lines_o1)

with open("demo.bak2.txt", "wt") as f:
    f.writelines(lines_o2)
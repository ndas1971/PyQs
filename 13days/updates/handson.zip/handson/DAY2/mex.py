"""
module is a file with .py extension
"""
import math 

def square(x):
    """returns square of 
    number"""
    z = x * x 
    return z 
    
    
def mean(lst):
    """Sum of lst/length of lst"""
    return sum(lst)/len(lst)
    
def sd(lst):
    """sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )"""
    m = mean(lst)
    o = []
    for e in lst:
        o.append( square(e-m))
    return math.sqrt(sum(o)/len(o))
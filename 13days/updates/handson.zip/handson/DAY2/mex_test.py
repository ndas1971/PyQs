"""
script we execute

"""

import mex 

print(f"""
square of 10 = {mex.square(10)}
""")

lst = [1,2,3,4,]

print(f"""
mean = {mex.mean(lst)}
sd = {mex.sd(lst)}
"""
)
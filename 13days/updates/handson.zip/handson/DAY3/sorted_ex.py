covid_data = { 'India': { 'cont': 'asia', 'data':{ '+ive': 20, 'tested': 200}},
 'China': { 'cont': 'asia', 'data':{ '+ive': 25, 'tested': 250}},
 'USA': { 'cont': 'America', 'data':{ '+ive': 30, 'tested': 300}},}
 
##Which country has most +ive
sorted(covid_data, key = lambda c: covid_data[c]['data']['+ive'])

## which continent has most +ive 
##group by 
#dict continent is key , value = list/dict 
ed = {}
for cn, data in covid_data.items():
    if data['cont'] not in ed:
        ed[data['cont']] = {cn: data}
    else:
        #old_dict = ed[data['cont']]
        #old_dict.update( {cn: data})
        ed[data['cont']] = {cn: data, **ed[data['cont']] }
        
print(ed)
{'asia': {'India': {'cont': 'asia', 'data': {'+ive': 20, 'tested': 200}}, 'China': {'cont': 'asia', 'data': {'+ive': 25, 'tested': 250}}}, 'America': {'USA': {'cont': 'America', 'data': {'+ive': 30, 'tested': 300}}}}
ans = sorted(ed, key=lambda cont: sum(
    [data['data']['+ive']for cn, data in ed[cont].items()]))
print(ans)


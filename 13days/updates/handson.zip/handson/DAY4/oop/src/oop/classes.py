# Bank User has name and account. There are two types of Users
# Normal and privileged user . There are two types of privileged
# users, Gold and Silver. Gold has cashback of 5% and Silver has 
# cashback of 3% of expenditure when they spend any cash 

# I am going to school
#     - cohesion
# 
# class 
#     ~ Noun
#         contains many attributes - a CLASS
#     contains instance methods
#         ~ verbs 
#     data
#         instance variables
# 
# object 
#     memory to hold data 
#     
#Special method 
#    has function signature is fixed 
#    When Python calls- is fixed 
#    https://docs.python.org/3/reference/datamodel.html#special-method-names
# self
#    NOt a key word
#    a convention
#    has to be first element, where python puts instance 
#instance variable 
#   self.hfkjashjk = , u initialize in __init__ method 
#   N number 
#Instance method 
#   first arg has to be self 
#   simple py function - no restriction 
#   few are special methods given in that doc 
# class variable 
#     defined class body 
#     used for global variable , only those class instances 
#     Classname.var_name 
# class method 
#     Create using @classmethod 
#     Can only access class variables 
#     Classname.method(...)
#     
# static method 
#     does not have any first arg 
#     Nowhere 
# Abstract method 
#     Use metaclass 
#     Refer abc 
#     Derived class must implement 
#     from abc import ABCMeta, abstractmethod 
#     Use @abstractmethod over abstract method 
#     Use metaclass= ABCMeta in class inheritance 
# Property
#     Lazy method  
#     Access like a variable, internally, it calls method 
# __slots___
#     WHat instance var be created 
# Reflections method 

#Error 
#   Exception 
#   https://docs.python.org/3/library/exceptions.html
class NotEnoughBalance(Exception):
    pass
    
class BankAccount:
    def __init__(self, init_amount): #instance method - self
        self.amount = init_amount   #instance var - self - DATA
    def __str__(self):
        return f"BankAccount({self.amount})"
    def transact(self, amount):
        if self.amount + amount < 0:
            raise NotEnoughBalance("not possible")
        self.amount += amount
        
        
# Two kinds of relation 
#         composition - has or have 
#             __init__ method 
#             delegation
#         inheritance -  is or are 
#             syntax 
#             How method is searched
            
class BankUser:
    how_many_users = {'total_users': 0}  #class variable, BankUser.how_many_users
    
    @classmethod
    def how_many(cls):                  #BankUser.how_many()
        return cls.how_many_users
      
    @staticmethod      
    def version():
        return "0.1"
        
    def __init__(self, name, init_amount):
        self.name = name 
        self.account = BankAccount(init_amount)
        self.update_dumps()
    def get_user_type(self):
        raise NotImplementedError("no type")
    def update_dumps(self):
        BankUser.how_many_users['total_users'] += 1
        t = self.get_user_type()
        if t not in BankUser.how_many_users:
            BankUser.how_many_users[t] = 1
        else:
            BankUser.how_many_users[t] += 1
            
    def __str__(self):
        return f"BankUser({self.name},{self.account})"
    def transact(self, amount):
        try:
            self.account.transact(amount)
            if amount < 0:
                cashback = self.get_cashback_per() * abs(amount)
                self.account.transact(cashback)
        except NotEnoughBalance as ex:
            print("Name", self.name, "Amount", amount, str(ex))
    def get_cashback_per(self):
        return 0
    @property 
    def balance(self):
        return self.account.amount
            
#Design Pattern - solution of all  conflicting 
#template - implement in base, tweak in derived        
        
class NormalUser(BankUser):
    def get_cashback_per(self):
        return super().get_cashback_per()
    def get_user_type(self):
        return "NormalUser"
        
class GoldUser(BankUser):
    def get_cashback_per(self):
        return 0.05   
    def get_user_type(self):
        return "GoldUser"
        
class SilverUser(BankUser):
    def get_cashback_per(self):
        return 0.03
    def get_user_type(self):
        return "SilverUser"
# when module, below code not execution 
#when script, below code execution
if __name__ == '__main__':              # pragma: no cover 
    users = [ NormalUser("Normal", 100),
              GoldUser("Gold", 100),
              SilverUser("silver", 100)
              ]
    amounts = [100, -200, 300, -400, 500]
    for u in users:
        for am in amounts:
            u.transact(am)
        print(u.balance)
    print(BankUser.how_many())
    print(BankUser.version())

    #ba = BankUser("ABC",100)  #BankUser.__init__( ba, 100) #ba = instance
    #ba.transact(-200)         #BankUser.transact( ba,100)
    #print(ba)                 #BankUser.__str__(ba)
    
    
    
    
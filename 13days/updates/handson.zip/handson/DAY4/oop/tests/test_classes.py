from oop import *
#pytest -v 
#pytest -v --cov=oop --cov-report term-missing 

# Module - prefix test 
# testcase - fn with prefix test 
#     must one or more assert 
# test suite - class with prefix Test 

#Update with Silver user and gold user testcase 
class TestUser:
    def test_normal_user(self):
        u = NormalUser("Normal", 100)
        amounts = [100, -200, 300, -400, 500]
        for am in amounts:
            u.transact(am)
        assert u.balance == 800
    def test_gold_user(self):
        u = GoldUser("Normal", 100)
        amounts = [100, -200, 300, -400, 500]
        for am in amounts:
            u.transact(am)
        assert u.balance == 810        
    def test_silver_user(self):
        u = SilverUser("Normal", 100)
        amounts = [100, -200, 300, -400, 500]
        for am in amounts:
            u.transact(am)
        assert u.balance == 806
        
def test_str_ba():
    ba = BankAccount(100)
    assert str(ba) == "BankAccount(100)"
    
#pytest -v 
#pytest -v -k "TestUser"
#pytest -v -k "normal or gold"

#Check Pytest reference doc, has many features 
#like skip, exception testing...
#link is part of all_links.md
"""
tests/test_classes.py::TestUser::test_normal_user PASSED                              [ 25%]
tests/test_classes.py::TestUser::test_gold_user PASSED                                [ 50%]
tests/test_classes.py::TestUser::test_silver_user PASSED                              [ 75%]
tests/test_classes.py::test_str_ba PASSED                                             [100%]


  -k EXPRESSION         Only run tests which match the given substring expression. An
                        expression is a Python evaluable expression where all names are
                        substring-matched against test names and their parent classes.
                        Example: -k 'test_method or test_other' matches all test functions
                        and classes whose name contains 'test_method' or 'test_other', while
                        -k 'not test_method' matches those that don't contain 'test_method'
                        in their names. -k 'not test_method and not test_other' will
                        eliminate the matches. Additionally keywords are matched to classes
                        and functions containing extra names in their 'extra_keyword_matches'
                        set, as well as functions which have names assigned directly to them.
                        The matching is case-insensitive.

"""










#given a directory, find file having max size 
import glob 
import os.path 
import time 
import sys 
DEBUG = bool(sys.argv[1]) if len(sys.argv) > 1 else False

def print_d(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)
        
#DECORATOR 
#    enhancing existing functionality with min code 
#    Function taking, FUnction and return function 
    
def profile(func):  #func = get_max_file
    print_d("profile called", func) #profile called <function get_max_file at 0x000001958E824540>
    def _inner(*args, **kwargs):
        print_d("profile::_inner called", f"{args=},{kwargs=}")
        st = time.time()
        res = func(*args, **kwargs)
        print("Time taken:", time.time() -st, "secs")
        print_d("profile::_inner returned")
        return res 
    print_d("profile returned", _inner) #profile returned <function profile.<locals>._inner at 0x000001958E8245E0>
    return _inner
    

@profile                #get_max_file = profile(get_max_file) = _inner
def get_max_file(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for f in files:
            if os.path.isfile(f):
                ed[f] = os.path.getsize(f)
            elif os.path.isdir(f):
                get_files(f, ed)
        return ed     
    allfiles = get_files(path)
    #print_d(allfiles)
    std = sorted(allfiles, key=lambda k: allfiles[k])    
    return std[-1] if std else ''

if __name__ == '__main__':
    path = r"."
    print(get_max_file(path))

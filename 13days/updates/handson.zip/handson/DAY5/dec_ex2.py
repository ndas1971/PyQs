#given a directory, find file having max size 
import glob 
import os.path 
import time 

        
#DECORATOR - Refer Learning Python 
#    enhancing existing functionality with min code 
#    Function taking, FUnction and return function 
#    can take arguments 
#    stack many decorators , inner post processing happens first 
#   class based decorator 
#   apply on function or class 
    
def profile1(prec):  #3
    def _first1(func ):  #_second2
        def _second1(*args, **kwargs):
            st = time.time()
            res = func(*args, **kwargs) #calls _second2
            print("1 Time taken:", round(time.time() -st, prec), "secs")
            return res 
        return _second1
    return _first1
    
def profile2(prec):     #2
    def _first2(func ): #get_max_file
        def _second2(*args, **kwargs):
            st = time.time()
            res = func(*args, **kwargs)     #calls original get_max_file
            print("2 Time taken:", round(time.time() -st, prec), "secs")
            return res 
        return _second2
    return _first2
    
#2 Time taken: 0.0 secs      #get_max_file = profile1(3)(profile2(2)(get_max_file)) = _second1
#1 Time taken: 0.0 secs      #OR 
@profile1(3)                 #get_max_file = profile1(3)(_second2) = _second1
@profile2(2)                 #profile2(2)(get_max_file) = _second2
def get_max_file(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for f in files:
            if os.path.isfile(f):
                ed[f] = os.path.getsize(f)
            elif os.path.isdir(f):
                get_files(f, ed)
        return ed     
    allfiles = get_files(path)
    std = sorted(allfiles, key=lambda k: allfiles[k])    
    return std[-1] if std else ''

if __name__ == '__main__':
    path = r"."
    print(get_max_file(path))

#Suitable for program where N similar task can be found 
#each task one THread , then master thread collates the result
# Dir - N subdirs 
#     One thread calculates one sub dir size - Map/fork
# Master thread - sum it up - Reduce /join

import threading , time 
import concurrent.futures
import os, os.path 


def  profile(fun):
    def _inner(*args, **kargs):
        import time
        now = time.time()
        dont_print = 'dont_print' in kargs
        res = fun(*args,**kargs)
        if not dont_print:
            print(fun.__name__, "(", threading.current_thread().name, 
                "): ", round(time.time() - now, 2), " secs")
        return res
    return _inner
    
    

class FileUtil:    
    def __init__(self, path):
        self.path = path
    def get_size(self, rootpath,files):
        ed = {}
        for file in files:
            try:
                ed[file] = os.path.getsize(os.path.join(rootpath,file))
            except Exception as ex:
                pass
        return ed
    @profile
    def getDirSize(self, **kwargs):
        s = 0                                               
        for rootpath, dirs, files in os.walk(self.path):    
            el = self.get_size(rootpath, files)             
            #print(el, files,rootpath)
            s += sum(el.values())                           
        return s 
    @profile   
    def getDirSizeThreaded(self, ws=4):
        s = 0 
        #1.5 tp 2 times of no of cores 
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=ws)
        rootpath, dirs, files =  next(os.walk(self.path))
        #root files size 
        el = self.get_size(rootpath, files) 
        s += sum(el.values()) 
        #Each dir, create a thread 
        #thread managed by ThreadPoolExecutor
        res = ex.map(lambda p: FileUtil(p).getDirSize(dont_print=True),
                [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        ex.shutdown()
        return s 
        
if __name__ == '__main__':
    path = r"C:\windows\system32"
    fiu = FileUtil(path)
    #first time more for cache operations, so do after one time     
    print("sequential")
    r = fiu.getDirSize()    

    print("Now parallel")
    rs = fiu.getDirSizeThreaded()
    
    print(r, rs)
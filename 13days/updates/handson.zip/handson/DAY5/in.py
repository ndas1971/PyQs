"""
4 ways - string , comversion int()/float()
    input()
        for password, input OK, else dont USe 
    Take it from env var 
        import os
        os.environ.get('X', "NOTFOUND")
    Configuration file 
        yaml, ini 
        Use open(filename, "rt")
    Commandline
        python filename.py   hello world 
        goes to 
        sys.argv = ['filename.py','hello','world' ]
        
        Many modules
            argparse
            click
    
"""    
    
    
import sys 
print(sys.argv)

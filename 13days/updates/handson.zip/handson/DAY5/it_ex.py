#given a directory, print all files 
import glob 
import os.path 
import time 
import sys 

def get_files(path, ed=None):
    if ed is None:
        ed = []
    files = glob.glob(os.path.join(path, "*"))
    for f in files:
        if os.path.isfile(f):
            ed.append(f)
        elif os.path.isdir(f):
            get_files(f, ed)
    return ed    

    
def get_files_it(path):
    files = glob.glob(os.path.join(path, "*"))
    for f in files:
        if os.path.isfile(f):
            yield f 
        elif os.path.isdir(f):
            yield from get_files_it(f)

class Files:
    def __init__(self, path):
        self.path = path 
    def __iter__(self):
        files = glob.glob(os.path.join(self.path, "*"))
        for f in files:
            if os.path.isfile(f):
                yield f 
            elif os.path.isdir(f):
                yield from Files(f)
                
                
if __name__ == '__main__':
    path = r"C:\Windows"
    for f in Files(path):
        print(f)
        
# Files.__init__(tmpInsance, path)     
# i =  iter(Files.__iter__(tmpInsance))
# f = next(i) = filename1 
# print filename1 as f var 
# f = next(i) = dir1/filename2
# print dir1/filename2 as f var 
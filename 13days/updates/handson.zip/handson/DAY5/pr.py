"""
Commands 
tasklist /FI "IMAGENAME eq python.exe"
taskkill /F /IM python.exe 

Extra process is for Process management 
    called Manager 
"""


import multiprocessing 
import time 

def worker(delay):
    print(multiprocessing.current_process().name, "Entering")
    time.sleep(delay)
    print(multiprocessing.current_process().name, "Exiting")



if __name__ == '__main__':
    print("Seq")
    worker(5) # MainProcess MainThread
    print("Para")
    st = time.time()
    ths = []
    for _ in range(10):
        th = multiprocessing.Process(target=worker, args=(5,))
        ths.append(th)
    #Now start it 
    [th.start() for th in ths]
    #wait for end 
    [th.join() for th in ths]
    print("Time taken", time.time()-st, "secs")
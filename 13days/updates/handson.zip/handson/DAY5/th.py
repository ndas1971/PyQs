"""
4 ways concurrent programming
https://wiki.python.org/moin/ParallelProcessing
    single host, single process, multithread
        IO bound - input/output
        Because of GIL - only one thread 
        can be executed at a time 
        >python13.0 GIT is getting removed
        https://docs.python.org/3/library/threading.html
        
    single host, multiprocess 
        we go beyond process constraint 
        CPU bound - encrypt 
        API is similar
        https://docs.python.org/3/library/multiprocessing.html
        
    multihost 
        requires framework
        eg pyspark
        
    
    single host single process, single thread 
        asynchronous programming

Host 
    machine 
    
process 
    spawned by os 
    heavy wt 
    contains many threads
    Global memory 
        use IPC 
        Manager does that 
        Use 
        https://docs.python.org/3/library/multiprocessing.html#managers
        

thread 
    spawned by process 
    light wt 
    all threads share process resource
        unit of scheduling for OS
    All threads share same space of a process 
        global memory can be shared 

Synchronize 
    Lock / RLock 
        Mutex    
        update global variable 
        High level 
            Map-Reduce /fork-join or executor 
            Python - futures 
    Condition Objects
        producer/consumer 
            Queue
                1 Producer N consumers 
    Semaphore Objects
        N threads at a time
        database pool
    Event Objects
        pub/sub  application
    Timer Objects
        future executing some code 
    Barrier Objects
        N threads synced at M points 
        
When we use more than one sync objects 
    Deadlock 
    A -> B and B <- A 
        
    
"""
import threading 
import time 


def worker(delay, lock):
    print(threading.current_thread().name, "Entering")
    if lock:
        with lock:
            print(threading.current_thread().name, "acquired")
            time.sleep(delay)
    print(threading.current_thread().name, "Exiting")



if __name__ == '__main__':
    print("Seq")
    worker(5, None) #MainProcess MainThread
    print("Para")
    lock = threading.RLock()
    lock = threading.Semaphore(2)
    st = time.time()
    ths = []
    for _ in range(10):
        th = threading.Thread(target=worker, args=(5,lock))
        ths.append(th)
    #Now start it 
    [th.start() for th in ths]
    #wait for end 
    [th.join() for th in ths]
    print("Time taken", time.time()-st, "secs")
        
        
    






    
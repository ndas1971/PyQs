#single host single process, single thread 
#    Usecase 
#        lot of blocking(takes time) codes - IO bound (takes time in IO)
#    Creates a event loop - list of events/coroutines
#        for each_event in loop:
#            does each_event wait for some IO 
#            if yes 
#                continue 
#            else 
#                process that event/coroutine 
#     When blocking ends, wake the the event and let it process 
#            Callback programming or asynchronous 
#  
"""   
def - async def 
any blocking code written in asyncio way - call await to get result 
for - async for 
with - async with 



run it with asyncio.run(coroutine)
"""
"""
Coroutine 
    async def 
    Only async def can call, async for, async with or await 
    normal def can not 
How do we wait and get result from coro
    await coro(arg1,...)
How do run coro in parallel - create task 
    task1 = asyncio.create_task(coro(arg1,...))
    Then for getting result 
    await task1 
How to run many coro and get all results 
    list_of_result = await ayncio.gather(coro1(..), coro2(...))
    OR 
    async for e in asyncio.as_completed([coro1(...), coro1(..),...])
        res = await e 
    OR 
    (done, pending) = await asyncio.wait([coro1(...), coro1(..),...])
How do we run blocking code in asyncio 
    search of asyncio enable modules 
    or put it in 
    await asyncio.to_thread(fn_name, args..)
    OR 
    Create ThreadPoolExecutor or ProcessPoolExecutor 
        asyncio.run_in_executor(..._)
"""     


import asyncio 
import time  #time.sleep is called non asynio aware code. Never call in asyncio code
import logging 
logging.basicConfig(level=logging.DEBUG)

def normal_method(delay):
    time.sleep(delay)
    return "slept happily"


async def worker(delay, what):
    await asyncio.sleep(delay)  # ayncio aware sleep #doing IO here 
    #print(what)
    return what 

async def mainS():
    res1 = await worker(5,"Hello")
    res2 = await worker(5,"World")
    return res1+res2
    
#mainP or mainP1 or mainP2 
async def mainP():
    res = await asyncio.gather(
            worker(5,"Hello"),
            worker(5,"World"))
    return res
    
   
async def mainP1():
    task1 = asyncio.create_task(worker(5,"Hello"))
    task2 = asyncio.create_task(worker(5,"Hello"))
    #do other activities 
    res1 = await task1
    res2 = await task2
    return res1+res2
    
    
async def mainP2():
    import random
    o = [random.randint(1,5) for _ in range(10)]
    tasks = [ asyncio.create_task(worker(i, f"Hello-{i}")) for i in o]
    out = []
    for e in asyncio.as_completed(tasks): # Py3.13 - async for 
        res = await e
        out.append( res)
    return out 
    
async def call_normal(delay):
    res =  await asyncio.to_thread(normal_method, delay)
    return res 

#__name__ is variable, python creates internally 
#in module __name__  = module name 
#in script , __name__ becomes __main__ 
if __name__ == '__main__':
    #OPT-1
    res = asyncio.run(worker(5,"Hello"), debug=True) #starts Eventloop 
    print(res)
    
    #OPT-2 - running many top level coro
    with asyncio.Runner() as r:
        st = time.time()
        res = r.run(mainS())
        print(res)
        print("Time taken", time.time() - st, "secs")  #10 secs 
        st = time.time()
        res = r.run(mainP())
        print(res)        
        print("Time taken", time.time() - st, "secs")  #5 secs 
        
        st = time.time()
        res = r.run(mainP1())
        print(res)
        print("Time taken", time.time() - st, "secs")  #5 secs   
        st = time.time()
        res = r.run(mainP2())
        print(res)
        print("Time taken", time.time() - st, "secs")  #5 secs 
        
        st = time.time()
        res = r.run(call_normal(5))
        print(res)
        print("Time taken", time.time() - st, "secs")  #5 secs 
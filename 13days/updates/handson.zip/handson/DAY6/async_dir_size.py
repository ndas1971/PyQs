# can not use glob/os.path/open - Anyio 
#     https://anyio.readthedocs.io/en/stable/fileio.html
#    anyio Path follows python pathlib API 
#    https://docs.python.org/3/library/pathlib.html
#    check github for any reference doc 
#    https://github.com/agronholm/anyio/blob/master/src/anyio/_core/_fileio.py

#Given directory find total size , include all the directories and subdirectories

#or directory - asyncdef fn1 
#anyio.Glob 
#USe glob to get all files and directory 
#if file 
#    get size 
#if directory 
#    recursive 
#    
#Get root label Path.walk 
#get size of all root labels files 
#for each directory 
#    call asyncdef1 <- mainP or mainP2 
#    
import asyncio 
from anyio import Path 
import sys 

DEBUG = bool(sys.argv[1]) if len(sys.argv) > 1 else False 
def print_d(*a,**b):
    if DEBUG:
        print(*a, **b)

#TODO - Handle exception
async def get_size(root,fs):
    res = sum([ (await Path(root, f).stat()).st_size for f in fs])
    return res 

async def get_size_one_dir(root, dir):
    s = 0
    async for rp, sds, fs in Path(root,dir).walk():
        print_d(f"{rp=},{sds=},{fs=}")
        s += await get_size(rp,fs)
        for sd in sds:
            s += await get_size_one_dir(rp,sd)
    return s 
    
async def dir_size(path):
    s = 0
    #Take root levels files and dirs 
    #async for rp, sds, fs in Path(path).walk(): 
    #    break    
    rp, sds, fs = await Path(path).walk().__anext__()
    print_d(f"{rp=},{sds=},{fs=}")
    s += await get_size(rp,fs)
    #for each subdir, now spawn one coroutine 
    res = await asyncio.gather(*[
            get_size_one_dir(rp,sd) for sd in sds
            ])
    s += sum(res)
    return s 
    
if __name__ == '__main__':
    path="."
    res = asyncio.run(dir_size(path)) 
    print(res)
            
        
    
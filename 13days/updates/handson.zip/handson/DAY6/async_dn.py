# https://github.com/timofurrer/awesome-asyncio
# Normal libs can not be used 
# Can not use requests - aiohttp 
#     https://github.com/aio-libs/aiohttp
# can not use glob/os.path/open - Anyio 
#     https://anyio.readthedocs.io/en/stable/fileio.html
#    anyio Path follows python pathlib API 
#    https://docs.python.org/3/library/pathlib.html
#    check github for any reference doc 
#    https://github.com/agronholm/anyio/blob/master/src/anyio/_core/_fileio.py

import asyncio 
import time, sys
import aiohttp
#setup
if sys.platform == 'win32':
	asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
#setip end 
    
    
async def download(url):
    async with aiohttp.ClientSession() as sess:
        async with sess.get(url) as resp:
            return await resp.text()
    
async def download_10_p(urls):
    tasks = [ download(i)  for i in urls ]
    return await asyncio.gather(*tasks)
    
async def download_10_f(urls):    
    tasks = []
    for i in urls :
        task = asyncio.create_task(download(i))
        tasks.append(task)
    #other work 
    res = []
    for t in tasks:
        res.append( await t)
    return res 
    
async def download_10_y(urls):  
    res = []
    async with aiohttp.ClientSession() as sess:
        for url in urls:
            async with sess.get(url) as resp:
                res.append( await resp.text())
    return res 
    
async def download_10_b(urls):
    tasks = [ asyncio.create_task(download(url)) for url in urls]
    out = []
    for e in asyncio.as_completed(tasks): 
        res = await e
        out.append( res)
    return out 
    
    

if __name__ == '__main__':
    url = "http://httpbin.org/get"
    urls = [url] * 10
    print("One download")
    st = time.time()
    res = asyncio.run(download(url))
    print(len(res))
    print("Time taken", time.time() - st, "secs")
    #handson 
    print("10 download")
    codes = [download_10_p, download_10_f, download_10_y, download_10_b]
    for code in codes :
        st = time.time()
        res = asyncio.run(code(urls))
        print(sum([len(r) for r in res ]))
        print("Time taken", time.time() - st, "secs")
    
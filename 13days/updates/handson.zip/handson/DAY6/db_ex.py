# DB API or ORM (Object Relation Mapper)
# SQL or    table -> class , use SQL via that class 
# DB engines - MySQL, ORacle, SQL server, sqlite3
# Libs of each DB engine 
# High - sqlalchemy 
from sqlalchemy import create_engine, text 
path = "iris.csv"
with open(path, "rt") as f:
    lines = f.readlines()

#Check data 
print(type(lines))  # list of str ie line 
print(type(lines[0]))  #
print(lines[:10])
#'SepalLength,SepalWidth,PetalLength,PetalWidth,Name\n'
#'5.1,3.5,1.4,0.2,Iris-setosa\n'
#csv - 2D - rows x cols - [[col1,col2,],[col1,col2],[]]
header = lines[0]
rows = lines[1:]
rowsd = []
for row in rows:
    a,b,c,d,n = row.strip().split(",")
    rowsd.append([float(a), float(b), float(c), float(d), n])
print(rowsd[:5])

#How many subspecies of Iris in that data file?
#set 
es = set()
for _,_,_,_,n in rowsd:
    es.add(n)
    
print(es)
sql_m = "select distinct Name from iris"
sql_d = "drop table if exists iris"
sql_c = """create table if not exists iris(
    SepalLength double,
    SepalWidth  double ,
    PetalLength double ,
    PetalWidth  double,
    Name string)
    """
sql_i = """insert into iris values(
        :sl, :sw, :pl, :pw, :n )"""
sql_g = "select max(SepalLength), min(SepalWidth) from iris group by Name"
sql_s = "select * from iris where Name = :n"
        
#Handson 
#find min of sepalLength and max of sepalWidth for each species 
#how many data is present when Name is iris-setosa 

#Create engine 
eng = create_engine("sqlite:///iris.db")

h = ('sl','sw','pl','pw','n')
with eng.connect() as con:
    con.execute(text(sql_d))
    con.execute(text(sql_c))    
    for r in rowsd:
        con.execute(text(sql_i), dict(zip(h,r)))
    con.commit()
    
with eng.connect() as con:
    res = con.execute(text(sql_m)).fetchall()
    print(res)
    res = con.execute(text(sql_g)).fetchall()
    print(res)
    res = con.execute(text(sql_s), dict(n='Iris-setosa')).fetchall()
    print(len(res))

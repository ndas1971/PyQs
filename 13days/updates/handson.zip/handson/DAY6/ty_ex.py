"""
Python dynamic typed 
    No type checking 
To check type without executing - called static checking 
    mypy file_name.py 
"""
from enum import Enum 
Unit = Enum('Unit', ['F', 'C'])                          #C1

def convert(value: int|float, /, unit:Unit) -> float:    #C2
    conv = {Unit.C : lambda d: (d * 9/5) + 32,
                Unit.F:  lambda f: (f-32)* 5/9 }
    match unit:                                          #C3
        case Unit():
            return round(conv[unit](value), 2)
        case _:
            return NotImplementedError("pass Unit")
            
            
if __name__ == '__main__':
    values:list[int|float] = [0, 32]                #C2
    units = [Unit.F] * len(values) + [Unit.C] * len(values) 
    for v,u in zip(values * 2, units):
        print(f"{v=},{u=},{convert(v,u)}, {Unit.C if u == Unit.F else Unit.F}")
                

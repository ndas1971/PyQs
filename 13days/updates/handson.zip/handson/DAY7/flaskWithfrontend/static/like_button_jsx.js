'use strict';

class BeautifulButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = { liked: false };
  }

  render() {
    if (this.state.liked) {      
      window.alert(this.props.k+"="+this.props.v)
      this.setState({ liked: false })
    }

    //synthetic events - https://reactjs.org/docs/events.html
    return <button onClick={() => this.setState({ liked: true })}>
            {this.props.k}
           </button>
  }
}

// Find all DOM containers, and render Like buttons into them.
document.querySelectorAll('.show_box')
  .forEach(domContainer => {
    // Read the k,v from a data-* attribute.
    const k_value = domContainer.dataset.k;
    const v_value = domContainer.dataset.v;
    ReactDOM.render(
      <BeautifulButton k={k_value} v={v_value} />,
      domContainer
    );
  });
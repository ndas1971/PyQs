'use strict';

//React.createElement(type,[props],[...children])
const e = React.createElement;

class BeautifulButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = { liked: false };
  }

  render() {
    if (this.state.liked) {      
      window.alert(this.props.k+"="+this.props.v)
      this.setState({ liked: false })
    }

    return e(
      'button',
      //synthetic events - https://reactjs.org/docs/events.html
      { onClick: () => this.setState({ liked: true }) },
      this.props.k
    );
  }
}

// Find all DOM containers, and render Like buttons into them.
document.querySelectorAll('.show_box')
  .forEach(domContainer => {
    // Read the k,v from a data-* attribute.
    const k_value = domContainer.dataset.k;
    const v_value = domContainer.dataset.v;
    ReactDOM.render(
      e(BeautifulButton, { k: k_value, v: v_value }),
      domContainer
    );
  });
  
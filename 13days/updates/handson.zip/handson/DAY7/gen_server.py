from flask import Flask
from flask import render_template, request 
import random 

app = Flask(__name__)

@app.route("/generate", methods=['GET', "POST"]) #http://localhost:5000/generate
def generate():
    def get_type(input):
        valid_types = ["table", "plain"]
        type_ = input.get("type", "plain").lower()
        if type_ not in valid_types:
            type_ = "plain"
        return type_         
    def get_min_max_count(input):
        def parse(v, fn=int, default=0):
            try:
                res = fn(v)
            except:
                res = default 
            return res 
        min_ = parse(input.get("min", 0), default=0)
        max_ = parse(input.get("max", 100), default=100)
        count = parse(input.get("count", 100), default=100)
        #TODO if min is > max , then do take something 
        if min_ > max_:
            min_, max_ = max_, min_
        min_ = max([0, min_])
        max_ = max([100, max_])
        return min_, max_, count 
    if request.method == 'POST':
        min_, max_, count = get_min_max_count(request.form)
        type_ = get_type(request.form)   
        data = [ random.randint(min_,max_) for _ in range(count)]
        print(request.form, min_, max_, count, type_, data)
        return render_template("gen.html", type_=type_, data=data)
    else:
        return """
    <html><head>
    <title>Give Env</title>
    </head>
    <body>
        <form action="/generate" method="post">
        Min:<input type="number" name="min" value="0" />
        Max:<input type="number" name="max" value="100" />
        Count:<input type="number" name="count" value="2" />
        <br/>
        <input type="radio" name="type" value="table" />table 
        <input type="radio" name="type" value="plain" />plain 
        <input type="submit" value="Submit" />
        </form>
    </body>
    </html> 
        """


if __name__ == '__main__':
    #http://localhost:5000
    app.run()
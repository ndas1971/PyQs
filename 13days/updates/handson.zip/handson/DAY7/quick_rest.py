Create two API endpoint 
items = [item python obj, ..]

1. Create item 
/create
Post with body 
item = '{"title": "some title", "price": 200, "country": "india"}'

Update items with this item 

2. List items 
/all
display that in list 

All in json data 



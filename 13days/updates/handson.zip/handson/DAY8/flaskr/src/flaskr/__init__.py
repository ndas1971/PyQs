from flask import Flask

app = Flask(__name__)

from .quick_server import * 
from .quick_rest import * 

"""
CRUD - Using rest server 
db = people.db 
table = people

C  - POST /create  {"name": ..., "age": ...}
U - PUT /update/name  { "age": ...}
            If exists update, else ignores
D - DELETE /delete/name 
    if exists, delete, else ignores 
R - GET /all 
    list of dict of name and age 
    
"""
from flask import Flask, jsonify, g , request, session #a dict 
import os
from sqlalchemy import create_engine, text 
from functools import wraps

#app = Flask(__name__)
from flaskr import app 

SCHEMA = ["name", "age"]
app.secret_key = b"gjdagdkgkdgkagdkh"  
#for using session, above is required, this should be long and super secret 
#it is used for signing session(by cookies)

#g in flask is a global object 
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        #create 
        DATABASE = os.path.join(app.root_path, "people.db")
        db = create_engine("sqlite:///" + DATABASE)
        g._database = db 
    return db 
    
def get_all():
    eng = get_db()
    with eng.connect() as conn:
        res = conn.execute(text("select name, age from people")).fetchall()
    return [dict(zip(SCHEMA,row)) for row in res]
    
def get_one(name):
    eng = get_db()
    with eng.connect() as conn:
        res = conn.execute(text("select age from people where name=:name"),
            dict(name=name)).fetchone()
    return res
  
def delete_one(name):
    eng = get_db()
    with eng.connect() as conn:
        conn.execute(text("delete from people where name=:name"),
                dict(name=name))
        conn.commit()
                
def update_one(name, age):
    eng = get_db()
    with eng.connect() as conn:
        conn.execute(text("Update people SET age=:age where name=:name"),
                dict(name=name, age=age))
        conn.commit()

def insert_one(name, age):
    eng = get_db()
    if get_one(name):
        return 
    with eng.connect() as conn:
        conn.execute(text("insert into people values(:name, :age)"),
                dict(name=name, age=age))
        conn.commit()
        
def auth_root(func):
    @wraps(func)
    def _inner(*args, **kwargs):
        if 'username' not in session:
            obj = dict(details="not logged in, Please log in at first")
            resp = jsonify(obj)
            resp.status_code = 401
            return resp 
        return func(*args, **kwargs)
    return _inner
#API 
#C  - POST /create  {"name": ..., "age": ...}
#U - PUT /update/name  { "age": ...}, If exists update, else ignores
#D - DELETE /delete/name ,     if exists, delete, else ignores 
#R - GET /all ,     list of dict of name and age 
@app.route("/all", methods=['GET'])
def get():
    obj = get_all()
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    
@app.route("/update/<string:name>", methods=['PUT'])
@auth_root      #must be inner most 
def update(name):
    age = None
    if 'Content-Type' in request.headers and \
            request.headers['Content-Type'] in ["application/json"]:
        age = request.json.get("age", None) 
    if age is None:
        obj = dict(name=name, details="no age in body, unable to update")
        status_code = 500
    else:
        print(name, age)
        update_one(name, age)
        obj=dict(name=name, details="updated")
        status_code = 200
    resp = jsonify(obj)
    resp.status_code = status_code
    return resp 
    
@app.route("/create", methods=['POST'])
@auth_root      #must be inner most 
def create():
    name, age = None, None
    if 'Content-Type' in request.headers and \
            request.headers['Content-Type'] in ["application/json"]:
        age = request.json.get("age", None) 
        name = request.json.get("name", None) 
    if age is None or name is None:
        obj = dict(details="no name/age in body, unable to update")
        status_code = 500
    else:
        insert_one(name, age)
        obj=dict(name=name, age=age, details="updated")
        status_code = 200
    resp = jsonify(obj)
    resp.status_code = status_code
    return resp 
    
@app.route("/delete/<string:name>", methods=['DELETE'])
@auth_root      #must be inner most 
def delete(name):
    delete_one(name)
    obj=dict(name=name, details="deleted")
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    

def check_pass(username, password):
    return username == 'admin' and password == 'verystrong'
    
@app.route("/login", methods=['POST'])
def login():
    username, password = None, None
    if 'Content-Type' in request.headers and \
            request.headers['Content-Type'] in ["application/json"]:
        username = request.json.get("username", None) 
        password = request.json.get("password", None) 
    if password is None or username is None or not check_pass(username, password):
        obj = dict(details="username or password is wrong")
        resp = jsonify(obj)
        resp.status_code = 401
        return resp 
    #signed in 
    session['username'] = username
    obj = dict(details="successfully logged in")
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    
@app.route("/logout", methods=['GET'])
def logout():
    if 'username' in session:
        del session['username'] 
    obj = dict(details="successfully logged out")
    resp = jsonify(obj)
    resp.status_code = 200
    return resp 
    
    
if __name__ == '__main__':
    #http://localhost:5000
    app.run()
    
"""
import requests 
create = ("http://localhost:5000/create", 
            requests.post,
            dict(json = dict(name='das', age=5)))
update =  ("http://localhost:5000/update/das", 
            requests.put,
            dict(json = dict(age=15)))
get =   ("http://localhost:5000/all", 
            requests.get,
            {})          
delete = ("http://localhost:5000/delete/das", 
            requests.delete,
            {}) 
all = [create, update, get, delete]
for url, method, data in all:
    r = method(url, **data)
    print(r.json())
    
#With session 
sess = requests.Session()
#Try create, must fail 
url, method, data = create 
r = method(url, **data)
print(r.json())

#Now log in 
login = ("http://localhost:5000/login", 
            sess.post,
            dict(json = dict(username='admin', password="verystrong")))
            
create1 = ("http://localhost:5000/create", 
            sess.post,
            dict(json = dict(name='das', age=5)))
update1 =  ("http://localhost:5000/update/das", 
            sess.put,
            dict(json = dict(age=15)))
get1 =   ("http://localhost:5000/all", 
            sess.get,
            {})          
delete1 = ("http://localhost:5000/delete/das", 
            sess.delete,
            {})  
            
all = [login, create1, update1, get1, delete1]
for url, method, data in all:
    r = method(url, **data)
    print(r.json())
    
    
#Anybody can do all 
get2 =   ("http://localhost:5000/all", 
            sess.get,
            {}) 
            
url, method, data = get2 
r = method(url, **data)
print(r.json())


#Now logout 
logout = ("http://localhost:5000/logout", 
            sess.get,
            {})  
url, method, data = logout 
r = method(url, **data)
print(r.json())      
            
sess.close()
"""
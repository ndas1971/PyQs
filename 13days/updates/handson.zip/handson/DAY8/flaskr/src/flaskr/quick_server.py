from flask import Flask, jsonify, g 
from flask import render_template, request 
import os
from sqlalchemy import create_engine, text 

#app = Flask(__name__)
from flaskr import app 

"""
https://flask.palletsprojects.com/en/stable/api/
class flask.Flask(import_name, 
static_url_path=None, static_folder='static', template_folder='templates',

static_host=None, host_matching=False, subdomain_matching=False,  instance_path=None, 
instance_relative_config=False, root_path=None)

Client side 
    static 
        css, html,...    
    dynamic 
        js 

Server side 
    static 
        goes to static_folder, access by /static/ URL PREFIX 
                by default  static_url_path is None or specify prefix here 
        these are put in browser cache
        html, css, js,..    
    dynamic/templates 
        server side scripting 
        jinja2 templates 
    
Update favicon.ico 
Browser wants from /favicon.ico, but we serve from /static with URL /static/favicon.ico
    OPT-1:
    in html file in head as ref ico 
        <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    OPT-2:
        asks from /favicon.ico, we redirect to /static/favicon.ico
    OPT-3
        asks from /favicon.ico, we also serve from /favicon.ico
        Update the cache 
            manually update cache by giving below URL 
            http://localhost:5000/favicon.ico
"""


#all methods are enabled 
@app.route("/")         #http://localhost:5000/
def index():
    return """
    <html><head>
    <title>My webserver</title>
    <style>
    .some {
        color: red;
    }
    </style></head>
    <body>
        <h1 id="some" class="some">Hello!!!</h1>
        <h1 id="some1" class="some">Hello Again!!!</h1>
    </body>
    </html>
    """

@app.route("/favicon.ico")  #http://localhost:5000/favicon.ico
def favicon():
    return app.send_static_file("favicon.ico")
    
#Handle POST , understand Templates 
#Given a env variable , display the value 
#or display all env var s

@app.route("/env", methods=['GET', "POST"]) #http://localhost:5000/env
def env():
    if request.method == 'POST':
        #all names from form comes in request.form , which is dict 
        envp = request.form.get("envp", "ALL").upper()
        env_dict = os.environ 
        if env_dict.get(envp, "NotFound") != "NotFound":
            env_dict = { envp: env_dict.get(envp)}
        return render_template("env.html", envs=env_dict)
        #/templates/env.html, can access  envs variable
    else:
        return """
    <html><head>
    <title>Give Env</title>
    </head>
    <body>
        <form action="/env" method="post">
        Given Env var:
        <input type="text" name="envp" value="ALL"  />
        <br/>
        <input type="submit" value="Submit" />
        </form>
    </body>
    </html> 
        """
#user inputs 
"""
GET params 
    URL params 
        http://localhost:5000/helloj?name=das&format=json 
    PATH params
        http://localhost:5000/helloj/das/json
POST params 
    Content-Type: application/json 
    BODY contains '{"name":"das", "format":"json"}'
"""
from flask import g 
from sqlalchemy import create_engine, text 

DATABASE = os.path.join(app.root_path, "people.db")
#g in flask is a global object 
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        #create 
        db = create_engine("sqlite:///" + DATABASE)
        g._database = db 
    return db 
    
class NotFound(Exception):
    pass
    
def get_age(name):
    eng = get_db()
    with eng.connect() as conn:
        #list of tuples/rows - fetchall 
        #tuple/one row - fetchone
        res = conn.execute(text("select age from people where name = :name"),
                dict(name=name)).fetchone()
        if res:
            return res[0]
        else:
            raise NotFound("NotFound")
    

@app.route("/helloj", methods=['GET', "POST"])         #GET URL params 
@app.route("/helloj/<string:name>/<string:format>", methods=['GET']) #PATH params
def helloj(name="abc", format="json"):      #flask puts path params in function arguments 
    fformat, fname = format, name 
    if request.method == 'GET':
        fname = request.args.get("name", name)
        fformat = request.args.get("format", format)
    else:
        #POST body 
        if 'Content-Type' in request.headers and \
            request.headers['Content-Type'] in ["application/json"]:
            fname = request.json.get("name", name) #contains post body 
            fformat = request.args.get("format", format)
    #TODO - update with XML - NOT NOW
    #TODO - given name find age from DB table
    age = None
    try:
        age = get_age(fname)
        obj = dict(name=fname, age=age)
    except NotFound:
        obj = dict(name=fname, details="Not found")
    resp = jsonify(obj)  
    if age is not None:
        resp.status_code = 200
    else:
        resp.status_code = 500
    return resp 
"""
import requests 
url1 = "http://localhost:5000/helloj?name=das&format=json"
url2 = "http://localhost:5000/helloj/das/json"
url3 = "http://localhost:5000/helloj"
obj3 = dict(name="das", format="json")

r = requests.get(url1)
r.json()

r = requests.get(url2)
r.json()

#post 
r = requests.post(url3, json=obj3)
r.json()

"""
        
        
    
if __name__ == '__main__':
    #http://localhost:5000
    app.run()

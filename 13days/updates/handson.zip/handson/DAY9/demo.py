from flask import Flask, jsonify

app = Flask(__name__)

from flask import render_template, request 
import os
@app.route("/env", methods=['GET', "POST"]) #http://localhost:5000/env
def env():
    if request.method == 'POST':
        #all names from form comes in request.form , which is dict 
        envpN = request.form.get("envp", None)
        envpL = request.form.getlist("envp", None)
        chL = request.form.getlist("ch", None)
        chN = request.form.get("ch", None)
        raL = request.form.getlist("ra", None)
        raN = request.form.get("ra", None)
        return dict(envpN=envpN, envpL=envpL, chL=chL, chN=chN, raL=raL, raN=raN, 
            form=dict(request.form))
        #{"chL":["A","B","C"],"chN":"A",
        #"envpL":["AB"],"envpN":"AB",
        #"form":{"ch":"A","envp":"AB","ra":"C"},
        #"raL":["C"],"raN":"C"}
    else:
        return """
    <html><head>
    <title>Give Env</title>
    </head>
    <body>
        <form action="/env" method="post">
        Given Env var:
        <input type="text" name="envp" value="ALL"  /><br/>
        <input type="checkbox" name="ch" value="A"  />OK<br/>
        <input type="checkbox" name="ch" value="B"  />NOK<br/>
        <input type="checkbox" name="ch" value="C"  />Yes<br/>
        <input type="checkbox" name="ch" value="D"  />NO<br/>
        <input type="radio" name="ra" value="A"  />OK<br/>
        <input type="radio" name="ra" value="B"  />NOK<br/>
        <input type="radio" name="ra" value="C"  />Yes<br/>
        <input type="radio" name="ra" value="D"  />NO<br/>
        <br/>
        <input type="submit" value="Submit" />
        </form>
    </body>
    </html> 
        """

        
    
if __name__ == '__main__':
    #http://localhost:5000
    app.run()

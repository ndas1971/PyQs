import os.path 

dir = os.path.dirname(__file__)
print(dir)
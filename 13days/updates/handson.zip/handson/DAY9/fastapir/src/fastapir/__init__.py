from fastapi import FastAPI 
app = FastAPI()
from .quick_rest import * 
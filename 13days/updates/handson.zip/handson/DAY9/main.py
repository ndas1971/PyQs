from fastapi import FastAPI , Request
from pydantic import BaseModel

app = FastAPI()

@app.get("/")       #http://localhost:8000/
async def root():
    return {"hello":"world"}
    
class Item(BaseModel):
    id : int 
    price: float 
    category:str = "book"
    
#Access URL param and path params 
@app.post("/items/{item_id}")       
async def get_items(item_id: int, request:Request, item:Item, name:str, limit:int=0):
    item_dict = item.dict()
    return dict(item_id=item_id, name=name, 
            limit=limit, method=request.method, 
            path=request.url.path,
            **item_dict)

"""
item is post/body param , send it with Content-Type: application/json
item_id is path, mandatory
name, limit = query params 
Request - injected 
http://localhost:8000/items/2?name=das 
http://localhost:8000/items/2?name=das&limit=100
"""


##HANDSON 
#dump environ variable 
#user may provide some env var or might provide ALL or can keep empty 
#return json data =dict of  key=env_var, value= value 
import os 

class Env(BaseModel):
    var: str = None

@app.post("/env/{envp}")
@app.post("/env")
async def env(env: Env|None = None, envp:str=None, envvar:str=None):
    envp_var = envp if envp else (envvar if envvar else  ( env.var if env.var else "ALL"))
    env_dict = {k:v for k,v in os.environ.items()}
    if env_dict.get(envp_var, "NotFound") != "NotFound":
        env_dict = { envp_var: env_dict.get(envp_var)}
    return env_dict


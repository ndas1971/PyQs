from fastapi import FastAPI , Request, HTTPException, Response
from pydantic import BaseModel
from starlette.middleware.sessions import SessionMiddleware

app = FastAPI()
#raise HTTPException(status_code=401, detail="login at first")

@app.middleware('http')
async def check_auth(request:Request, call_next):
    path = request.url.path 
    if 'username' in request.session or path in ["/env", "/login"]:
        resp = await call_next(request)
        return resp
    else:
        return Response(content='{"details" : "Login at first"}', media_type="application/json", status_code=401)

@app.get("/")       #http://localhost:8000/
async def root1():
    return {"hello":"world"}
    
@app.get("/env")       #http://localhost:8000/env
async def root2():
    return {"hello":"env"}
    
    
@app.get("/login")       #http://localhost:8000/login
async def root3(request:Request):
    request.session['username'] = 'das'
    return dict(details="loggedin")
    
    
    
#Must be last line 
app.add_middleware(SessionMiddleware, secret_key="some-random-string")


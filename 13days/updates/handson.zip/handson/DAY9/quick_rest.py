"""
CRUD - Using rest server 
db = people.db 
table = people

C  - POST /create  {"name": ..., "age": ...}
U - PUT /update/name  { "age": ...}
            If exists update, else ignores
D - DELETE /delete/name 
    if exists, delete, else ignores 
R - GET /all 
    list of dict of name and age 
    
"""
from fastapi import FastAPI , Request, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, text 
import os 


app = FastAPI()

SCHEMA = ["name", "age"]

#g in flask is a global object 
def get_db():
    DATABASE = os.path.join(".", "people.db")
    db = create_engine("sqlite:///" + DATABASE)
    return db 
    
def get_all():
    eng = get_db()
    with eng.connect() as conn:
        res = conn.execute(text("select name, age from people")).fetchall()
    return [dict(zip(SCHEMA,row)) for row in res]
    
def get_one(name):
    eng = get_db()
    with eng.connect() as conn:
        res = conn.execute(text("select age from people where name=:name"),
            dict(name=name)).fetchone()
    return res
  
def delete_one(name):
    eng = get_db()
    with eng.connect() as conn:
        conn.execute(text("delete from people where name=:name"),
                dict(name=name))
        conn.commit()
                
def update_one(name, age):
    eng = get_db()
    with eng.connect() as conn:
        conn.execute(text("Update people SET age=:age where name=:name"),
                dict(name=name, age=age))
        conn.commit()

def insert_one(name, age):
    eng = get_db()
    if get_one(name):
        return 
    with eng.connect() as conn:
        conn.execute(text("insert into people values(:name, :age)"),
                dict(name=name, age=age))
        conn.commit()
        
#API 
#C  - POST /create  {"name": ..., "age": ...}
#U - PUT /update/name  { "age": ...}, If exists update, else ignores

from pydantic import BaseModel


class UdpateData(BaseModel):
    age: float 
    
class CreateData(BaseModel):
    name: str 
    age: float 
    
@app.post("/create")
def api_create(data:CreateData):
    if get_one(data.name):
        raise HTTPException(status_code=402, detail="name exists")
    insert_one(data.name, data.age)

@app.put("/update/{name}")
def api_update(name:str, data:UdpateData):
    update_one(name, data.age)
    
#D - DELETE /delete/name ,     if exists, delete, else ignores 
#R - GET /all ,     list of dict of name and age 
@app.delete("/update/{name}")
def api_delete(name:str):
    delete_one(name)
    
@app.get("/all")
def api_getall():
    return get_all()

    
"""
import requests 
create = ("http://localhost:8000/create", 
            requests.post,
            dict(json = dict(name='das', age=5)))
update =  ("http://localhost:8000/update/das", 
            requests.put,
            dict(json = dict(age=15)))
get =   ("http://localhost:8000/all", 
            requests.get,
            {})          
delete = ("http://localhost:8000/delete/das", 
            requests.delete,
            {}) 
all = [create, update, get, delete]
for url, method, data in all:
    r = method(url, **data)
    print(r.json())

#With session 
sess = requests.Session()
#Try create, must fail 
url, method, data = create 
r = method(url, **data)
print(r.json())

#Now log in 
login = ("http://localhost:8000/login", 
            sess.post,
            dict(json = dict(username='admin', password="verystrong")))
            
create1 = ("http://localhost:8000/create", 
            sess.post,
            dict(json = dict(name='das', age=5)))
update1 =  ("http://localhost:8000/update/das", 
            sess.put,
            dict(json = dict(age=15)))
get1 =   ("http://localhost:8000/all", 
            sess.get,
            {})          
delete1 = ("http://localhost:8000/delete/das", 
            sess.delete,
            {})  
            
all = [login, create1, update1, get1, delete1]
for url, method, data in all:
    r = method(url, **data)
    print(r.json())
    
    
#Anybody can do all 
get2 =   ("http://localhost:8000/all", 
            sess.get,
            {}) 
            
url, method, data = get2 
r = method(url, **data)
print(r.json())


#Now logout 
logout = ("http://localhost:8000/logout", 
            sess.get,
            {})  
url, method, data = logout 
r = method(url, **data)
print(r.json())      
            
sess.close()
"""
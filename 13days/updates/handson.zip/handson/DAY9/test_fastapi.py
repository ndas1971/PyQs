import requests , sys
import aiohttp, asyncio

#setup
if sys.platform == 'win32':
	asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
#setip end 

def sync(url, **kwargs):
    return requests.get(url,  **kwargs)
    
def sync_post(url, obj):
    return requests.post(url,  json=obj)
    
async def download(url, obj):
    async with aiohttp.ClientSession() as sess:
        async with sess.post(url, json=obj) as resp:
            return await resp.json()
            
async def download_get(url):
    async with aiohttp.ClientSession() as sess:
        async with sess.get(url) as resp:
            return await resp.json()
    
async def downloads(urls, obj):
    res = await asyncio.gather(
        *[download(url, obj) for url in urls]
        )
    return res 
            
if __name__ == '__main__':
    # url = "http://localhost:8000/"
    # resp = sync(url)
    # print(resp.json())
    # obj = dict(id =2, price=200.0)
    # 
    # res = asyncio.run(download_get(url))
    # print(res)
    # urls = ["http://localhost:8000/items/2?name=das",
    #     "http://localhost:8000/items/2?name=das&limit=100",
    #     "http://localhost:8000/items/OK?name=das&limit=100",
    #     ]
    # res = asyncio.run(downloads(urls, obj))
    # print(res)
    # 
    # url = "http://localhost:8000/items/2?name=das"
    # resp = sync_post(url, obj)
    # print(resp.json())
    
    urls =[ "http://localhost:8000/env/APPDATA",
            "http://localhost:8000/env?envvar=USERNAME",
            "http://localhost:8000/env",
            "http://localhost:8000/env/APPDATA?envvar=USERNAME"]
    obj = dict(var="PATH")
    for url in urls:
        resp = sync_post(url, obj)
        print(resp.json())
    
    

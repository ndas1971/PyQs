#update master_data by today's data 
master_data = { 'usa' : {'+ive': 20, 'test': 200 },
                    'india': {'+ive': 15, 'test': 100 },
                    'zim': {'+ive': 10, 'test': 1 }}


today_data = {'usa' : {'+ive': 1, 'test': 1.5 },
         'india': {'+ive': 0.75, 'test': 1 },
         'af' : {'+ive': 0, 'test': 0 }}
         
for cname, data in  today_data.items():
    if cname in master_data:
        #update 
        master_data[cname]['+ive'] += data['+ive']
        master_data[cname]['test'] += data['test']
    else:
        master_data[cname] = data.copy()
         
print(master_data)      
#Answer
# master_data = { 'usa' : {'+ive': 21, 'test': 201.5 },
                    # 'india': {'+ive': 15.75, 'test': 101 },
                    # 'af': {'+ive': 0, 'test': 0 },
                    # 'zim': {'+ive': 10, 'test': 1 }}
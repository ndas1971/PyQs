#Transform some_data to  master_data
some_data = {'+ive': {'usa': 20, 'india': 15, 'zim': 10},
            'test': {'usa': 200, 'india': 100, 'zim': 1}}

#master_data = { 'usa' : {'+ive': 20, 'test': 200 },
#                    'india': {'+ive': 15, 'test': 100 },
#                    'zim': {'+ive': 10, 'test': 1 }}

master_data = {}
for metric, data in some_data.items():
    for cname, value in data.items():
        if cname not in master_data:
            master_data[cname] = {}
        master_data[cname][metric] = value 
        
print(master_data)

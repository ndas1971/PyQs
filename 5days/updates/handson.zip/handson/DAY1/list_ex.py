input = "[1,2,3,4]"
#parse and make it like below 
output = [1,2,3,4]

#hint - remove "[]", and then split by ","
#iterate, convert each str into number 
output = []
for ch in input.strip('[]').split(","):
    output.append(int(ch))
   
#
print(output)
#Map pattern - comprehension
output = [ int(ch) for ch in input.strip('[]').split(",")]
#Using map fn - not now 

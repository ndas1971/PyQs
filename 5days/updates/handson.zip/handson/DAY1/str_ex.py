s = "Hello World and Hello Earth"

#Count uppercase, lowercase and space in above string 
#Hint: Use suitable instance methods and for loop 
cupper, clower, cpace = 0, 0, 0
for ch in s:
    if ch.isupper():
        cupper += 1
    elif ch.islower():
        clower += 1        
    if ch.isspace():
        cpace += 1
print(f"{cupper=}, {clower=}, {cpace=}")
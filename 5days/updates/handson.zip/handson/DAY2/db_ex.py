"""
DB API(sql) or ORM (each table => class)
Many engines 
Each engine has many libs 

Use sqlalchemy 
https://docs.sqlalchemy.org/en/14/core/engines.html

"""
#create a table people (name, age)
#put two rows 
#max age 
create_s = """create table if not exists 
people(name string, age int)"""
insert_s = "insert into people values(:n, :a)" #:n, :a are placeholders
select_s = "select max(age) from people"
from sqlalchemy import create_engine, text 
engine = create_engine("sqlite:///people.db") #DB_URL - change based on engine 

db = [("abc", 20), ("xyz", 30)]
with engine.connect() as con:
    con.execute(text(create_s))
    for n,a in db:
        con.execute(text(insert_s), dict(n=n,a=a))
    con.commit()   # .rollback()
    
with engine.connect() as con:
    cur = con.execute(text(select_s))
    print(cur.fetchone())  #.fetchall()
    
    



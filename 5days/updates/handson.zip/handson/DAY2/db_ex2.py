#Use iris.csv and dump into sqlite3 table iris 
#find how many subspecies in iris

from sqlalchemy import create_engine, text 
engine = create_engine("sqlite:///iris.db") #DB_URL - change based on engine 
select_s = "select distinct Name from iris"
create_s = """create table if not exists iris(
SepalLength float,SepalWidth float,PetalLength float,
PetalWidth float,Name string)"""
insert_s = """insert into iris values(
:SepalLength,:SepalWidth,:PetalLength,:PetalWidth,:Name)"""

#table iris contains five columns 
#SepalLength,SepalWidth,PetalLength,PetalWidth,Name
#first four are float and last one is string 

#read iris.csv and parse accordingly and then insert into iris table 
    
path = r"D:\handson\DAY4\code\data\iris.csv"
with open(path, "rt") as f:
    lines = f.readlines()
    
header = lines[0].strip().split(",")
rows = lines[1:]  
rowsd = []
for e in rows:
    #5.1,3.5,1.4,0.2,Iris-setosa      
    tmp = e.strip().split(",")
    res = [*[float(v) for v in tmp[:-1]], tmp[-1]]
    rowsd.append( dict(zip(header,res)))
    
#print(rowsd)

with engine.connect() as con:
    con.execute(text(create_s))
    for dv in rowsd:
        con.execute(text(insert_s), dv)
    con.commit()   # .rollback()
    
with engine.connect() as con:
    cur = con.execute(text(select_s))
    print(cur.fetchall())  

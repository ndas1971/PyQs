#How many species are there in iris?
#
#STEP1 - opening the file, filemode -rt 
#=> list of lines 
#Remove header - slicing 
#STEP2:
#set  because we distinct 
#STEP3:
#    extract Name column and put in set 
#    strip and split by , 
#      -- map pattern 
#STEP4: use len

path = r"D:\handson\DAY4\code\data\iris.csv"
with open(path, "rt") as f:
    lines = f.readlines()
    
header = lines[0]
rows = lines[1:]  # in memory 
s = set()
for e in rows:
    #5.1,3.5,1.4,0.2,Iris-setosa
    s.add( e.strip().split(",")[-1])
    
print(f"species count={len(s)}")
# "select distinct Name from iris"
#HOMEWORK - find min and max of SepalLength for each species 


import os 
import os.path  #OOP pathlib

def square(x):
    #doc string - first string 
    #after def 
    """squaring number
    and returning"""
    z = x * x 
    return z 


def get_dir_size(path):
    """
    Use os.walk
    and os.path.join and os.path.getsize    
    check documnentation 
    """
    #TODO - if size is not possible, what to do 
    def get_size(dirpath, filenames):
        #sizes = []
        #for file in filenames:
        #    sizes.append(os.path.getsize(os.path.join(dirpath,file)))
        sizes = [os.path.getsize(os.path.join(dirpath,file)) 
            for file in filenames]
        return sum(sizes)          
    #TODO - if path is not directory, what to return 
    #Assume path is directory 
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(path):
        #Get size of filenames 
        total_size += get_size(dirpath, filenames)
    return total_size
        
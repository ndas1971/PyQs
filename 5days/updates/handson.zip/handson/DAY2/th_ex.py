"""
Reference 
https://docs.python.org/3/library/multiprocessing.html
https://docs.python.org/3/library/threading.html
https://docs.python.org/3/library/concurrent.futures.html
https://docs.python.org/3/library/asyncio.html
https://wiki.python.org/moin/ParallelProcessing

Single host, single process, single Thread 
    - till now 
    concurrent - asyncio 
        async def ....
Single host, single process, multi Thread
    threading 
Single host, Multi process
    multiprocessing
Multihost (cores)
    pyspark 
    
Thread 
    light wt 
    Process or Thread can create other threads
    choice - Thread 
    Because of GIL (getting removed in py3.13) - LOCK 
    suitable IO bound - consists of disk/ip...
Process
    heavy 
    One process/thread can create other processes
    suitable for CPU bound  
        consists of only memory operation     

Synchronization 
    Lock /RLock objects
        mutex - one thread at a time 
    Condition objects
        producer-consumer 
        high level - Queue
    Semaphore objects
        N thread at a time 
    Event objects
        pub-sub 
    Timer objects
        working in future 
    Barrier objects
        sync at few intermidiate points 
Many sync primitives 
    Deadlock 
        
fork-join/mapreduce/
    moving from Thread to Process is very simple 
    https://docs.python.org/3/library/concurrent.futures.html
    
    N workers are working on some chunk of data - map /fork 
    master thread is reducing(summing..) the worker's function return - Reduce-join 
    
    ThreadPoolExecutor 
    
"""
import threading 
import multiprocessing 
import time 

def worker(sleeptime, lock=None):
    print("Entering..", threading.current_thread().name)
    if lock:
        with lock:
            time.sleep(sleeptime)
    print("Exiting..", threading.current_thread().name)
    
    
#def workerP(sleeptime):
#    print("Entering..", multiprocessing.current_process().name)
#    time.sleep(sleeptime)
#    print("Exiting..", multiprocessing.current_process().name)
#  
    
    
if __name__ == '__main__':
    print("Sequentially")
    worker(5)       #MainProcess MainThread
    print("Parallely")
    st = time.time()
    ths = []
    lock = threading.RLock()
    #lock = threading.Semaphore(2)
    for _ in range(10):
        th = threading.Thread(target=worker, args=(5,lock))
        #th = multiprocessing.Process(target=workerP, args=(5,))
        #commands to check number of processes in OS 
        #tasklist /FI "IMAGENAME eq python.exe"
        ths.append(th)
    #start explicitly 
    [th.start() for th in ths]
    #wait for their end 
    [th.join() for th in ths]
    print("Time taken:", time.time()-st, "secs")
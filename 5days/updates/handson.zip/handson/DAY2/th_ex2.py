import os
import os.path 
import threading, time 
import concurrent.futures

def get_dir_size_threaded(path, max_workers=4):
    def get_size(dirpath, filenames):
        sizes = [os.path.getsize(os.path.join(dirpath,file)) 
            for file in filenames]
        return sum(sizes) 
    def get_dir_size(path):
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(path):
            total_size += get_size(dirpath, filenames)
        return total_size
    if max_workers > 1:
        total_size = 0    
        #for base directory 
        rootpath, dirs, files = next(os.walk(path))
        total_size += get_size(rootpath, files)
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
            res = ex.map(get_dir_size, [os.path.join(rootpath,d) for d in dirs])
            total_size += sum(res)
        return total_size 
    else:
        return get_dir_size(path)
    
if __name__ == '__main__':
    path = r"D:\handson"
    print(get_dir_size_threaded(path), get_dir_size_threaded(path, 1))
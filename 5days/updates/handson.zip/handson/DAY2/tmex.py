import mex 

print(f"""
square of 10 = {mex.square(10)}
""")

path = r"D:\handson"
size = mex.get_dir_size(path)
print(size)
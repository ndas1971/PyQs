from flaskr import app 

"""
client side 
    static 
        html 
    dynamic 
        js - angular/jquery/react/vue
Server side 
    static , must go in static folder 
        html, js - angular/jquery/react/vue
    cached, so need to clear cache ,
    in Firefox, 
    http://localhost:5000/favicon.ico
    dynamic/templates - templates folder 
        jinja2

"""


@app.route("/")  #http://localhost:5000/
def home():
    return """
    <html>
    <head><title>My Webserver</title>
    <style>
    .some {
        color: red;
    }
    </style></head>
    <body>
    <h1 class="some" id="some1">Hello There!!</h1>
    </body>
    </html>
    """


@app.route("/favicon.ico")
def favicon():
    return app.send_static_file('favicon.ico')
    
from flask import request , render_template
import os 
@app.route("/env", methods=['GET','POST'])#http://127.0.0.1:5000/env
def env():
    if request.method == 'POST':
        envp = request.form.get('envp', 'all').upper()
        env_dict = os.environ
        if os.environ.get(envp, "notfound") != "notfound":
            env_dict = { envp : os.environ.get(envp,"notfound") }
        return render_template("env.html", envs=env_dict)
    else:
        return """
            <html><body>
            <form action="/env" method="post">
              Put Variable name :<br>
              <input type="text" name="envp" value="ALL">
              <br><br>
              <input type="submit" value="Submit">
            </form> 
            </body></html>
        """
        
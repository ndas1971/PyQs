from gevent.pywsgi import WSGIServer
from flaskr import app

# http_server = WSGIServer(('localhost', 443), app, keyfile='key.pem', certfile='cert.pem')
http_server = WSGIServer(('192.168.108.11', 80), app)
http_server.serve_forever()

"""
http://192.168.108.11/env
http://192.168.108.11:8080/env

"""


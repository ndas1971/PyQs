# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 
r"""
class 
    ~ Nouns 
    collection of methods ~ verbs 
    which operates on instance variables

object/instance 
    has memory location 
    and use methods from class 
    
STEP1:
    find all initialization params
    with which we create instance 
STEP2:
    write initialization method , __init__(self,...)
    creates instance variables 
        self.some_name 
STEP3:
    Write others methods 
    which works with instance variables 
    
Relations 
    is/are - inheritance 
    has/have - composition

packaging 
python -m poetry new oop
cd oop 
python -m poetry add --group dev pytest pytest-cov 
#enable shell
python -m poetry env activate 
#above gives what you should execute 
#execute that 

#copy this file into src\oop

#Add below in pyproject.toml 
[tool.pytest.ini_options]
pythonpath = [
  "src"
]
#Update src\oop\__init__.py 
from .account import * 
from .fractions import * 
#testing 
echo > tests\test_account.py 
python -m pytest -v 
python -m pytest -v --cov=oop --cov-report term-missing 

#Then build 
python -m poetry build -v 

#*.whl file will be created under dist , can be installed 
#in any env like virtualenv 
#decativate the current one 
deactivate 
cd ..
#create new one 
python -v venv .\.venv 
#Activate 
.\.venv\Scripts\Activate 
#install 
pip install oop\dist\whlfilename
#test in python prompt 
python 
>>> from oop import Fraction 
>>> Fraction(1,2) + Fraction(2,3)



Exception 
https://docs.python.org/3/library/exceptions.html#exception-hierarchy

No access control 
self 
    not a keyword, but must be at first arg to any instance methods  
    python puts instance there 
Special method 
    signature fixed
    Python uses for operator conversion
    https://docs.python.org/3/reference/datamodel.html
    example 
    __init__ 
    __str__
Metaclass 
    class which creates other class 
    default metaclass is type
    metaprogramming - inheriting from type 
No interface or abstract keyword 
    module abc contains ABCMeta using metaclass
instance method
    first arg is instance 
class method 
    first arg is class 
class variable 
    define inside body of class 
static method 
    there is no first arg 
property 
slots 
....
"""
class NotEnoughBalance(Exception): #inherit from Exception 
    pass
    
class BankAccount:
    def __init__(self, init_balance): #<-  #tmp_sba, 100
        self.balance = init_balance  #tmp_sba.balance = 100
    def transact(self, amount):  #<-
        if self.balance + amount < 0:
            #return error 
            raise NotEnoughBalance("not possible")
        self.balance += amount   #ba.balance += 100
    def __str__(self):
        return f"BankAccount(balance={self.balance})"
        
        
class SpecialBankAccount(BankAccount):  #inheritance , multiple inheritance 
    def transact(self, amount, cbp=0.05): #tmp_sba, 100  , tmp_sba.balance = 100
        try:
            super().transact(amount)    #calling base class methods
            if amount < 0:
                cashback = cbp * abs(amount)
                super().transact(cashback)
        except NotEnoughBalance as ex:  
            print(ex, "Amount:", amount)
#MRO = (SpecialBankAccount, BankAccount, object)
if __name__ == "__main__":  # pragma: no cover
    bas = [BankAccount(100),         #BankAccount.__init__(tmp_ba,100)
           SpecialBankAccount(100)]  #SpecialBankAccount.__init__(tmp_sba, 100)
    amounts = [100, -200, 200, -300, 400]
    for ba in bas :
        for am in amounts:
            try:
                ba.transact(am)      #SpecialBankAccount.transact(tmp_sba, 100)
            except NotEnoughBalance as ex:    
                print(ex)
        print(ba)
    
    
    
    
    # ba = BankAccount(100)  #BankAccount.__init__(ba, 100)
    # try:
    #     ba.transact(-200)       #BankAccount.transact(ba, 100)
    # except NotEnoughBalance as ex:
    #     print(ex)
    # print(ba)      # 200
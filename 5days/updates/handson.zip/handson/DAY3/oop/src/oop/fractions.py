class Fraction:
    def __init__(self, n, d):
        self.n = n 
        self.d = d 
    def __str__(self):
        return f"Fraction({self.n},{self.d})"
    def __add__(self, other):
        n = self.n * other.d + other.n * self.d 
        d = self.d * other.d 
        return Fraction(n, d)




if __name__ == '__main__':
    a = Fraction(1, 2)
    b = Fraction(2, 3)
    c = a + b     # 1/2 + 2/3 = 7/6
    print(c)      #Fraction(7, 6)  

"""
test module - file with prefix test 
testcase - function prefix with test 
    contains assert 
    if assert is failed, testcase failed 
test suite - class with prefix Test
        collection similar test case 


"""
import oop 

def test_bank_account():
    ba = oop.BankAccount(100)
    amounts = [100, -200, 200, -300, 400]
    for am in amounts:
        try:
            ba.transact(am)      
        except oop.NotEnoughBalance as ex: 
            pass
    assert ba.balance == 600
    
def test_special_bank_account():
    ba = oop.SpecialBankAccount(100)
    amounts = [100, -200, 200, -300, 400]
    for am in amounts:
        ba.transact(am)      
    assert ba.balance == 610
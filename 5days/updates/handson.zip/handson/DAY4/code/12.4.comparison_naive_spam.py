from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import nltk
import string
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import *
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.linear_model import SGDClassifier
from sklearn.preprocessing import *

PAUSE='N'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()

print("-------------------- Naive Bayes for spam -------------")
print("""
GaussianNB 
    implements the Gaussian Naive Bayes algorithm for classification. 
    The likelihood of the features is assumed to be Gaussian
    Gaussian Naive Bayes is used in cases when all our features are continuous
MultinomialNB 
    implements the naive Bayes algorithm for multinomially distributed data
    Its is used when we have discrete data
    Classic algorithm for classification of text data with TfidfTransformer
ComplementNB 
    implements the complement naive Bayes (CNB) algorithm. 
    CNB is an adaptation of the standard multinomial naive Bayes (MNB) algorithm 
    that is particularly suited for imbalanced data sets.
    CNB uses statistics from the complement of each class to compute the model's weights. 
    The inventors of CNB show empirically that the parameter estimates for CNB 
    are more stable than those for MNB. 
    Further, CNB regularly outperforms MNB (often by a considerable margin) 
    on text classification tasks.
BernoulliNB 
    implements the naive Bayes training and classification algorithms for data 
    that is distributed according to multivariate Bernoulli distributions; 
    i.e., there may be multiple features but each one is assumed to be a binary-valued 
    (Bernoulli, boolean) variable. 
    Therefore, this class requires samples to be represented as binary-valued feature 
    vectors; if handed any other kind of data, 
    a BernoulliNB instance may binarize its input (depending on the binarize parameter).
    In the case of text classification, word occurrence vectors 
    (rather than word count vectors) may be used to train and use this classifier. 
    BernoulliNB might perform better on some datasets, 
    especially those with shorter documents.     
SGDClassifier  
    This estimator implements regularized linear models with stochastic gradient descent 
    (SGD) learning: the gradient of the loss is estimated each sample at a time 
    and the model is updated  along the way with a decreasing strength schedule (aka learning rate). 
    For best results using the default learning rate schedule, 
    the data should have zero mean and unit variance.    
    Can be used with very high number of samples 
""")





#since the dataset comes with additional unnamed, column, drop them first

messages = pd.read_csv('data/spam.csv', encoding='latin-1')
#specify list of columns 
messages.drop(['Unnamed: 2','Unnamed: 3','Unnamed: 4'],axis=1,inplace=True)
messages = messages.rename(columns={'v1': 'class','v2': 'text'})

print(messages.head())
print(messages.groupby('class').describe())
'''
       text
      count unique
class
ham    4825   4516
spam    747    653


from above information, we know that:

    only about 15% of the text messages is classified as a spam
    there are some duplicate messages, since the number of unique values lower than the count values of the text

in the next part, lext check the length of each text messages to see whether it is correlated with the text classified as a spam or not.
'''


def process_text(text, lower_case = True, stem = True, stop_words = True):    
    message = [char for char in text if char not in string.punctuation]
    message = ''.join(message)     
    if lower_case:
        message = message.lower()
    words = word_tokenize(message)
    words = [w for w in words if len(w) > 2]
    if stop_words:
        sw = stopwords.words('english')
        words = [word for word in words if word not in sw]
    if stem:
        stemmer = PorterStemmer()
        words = [stemmer.stem(word) for word in words]       
    return words

    
print("Fitting pipeline....")
msg_train, msg_test, class_train, class_test = train_test_split(messages['text'],messages['class'],test_size=0.2)



def process(pipeline, t_X=msg_train, t_y=class_train, te_X=msg_test, te_y=class_test):    
    pipeline.fit(t_X, t_y)
    predictions = pipeline.predict(te_X)
    print("Number of mislabeled points out of a total %d points : %d"
            % (msg_test.shape[0],(te_y != predictions).sum()))
    print("classification reports")
    print(classification_report(te_y,predictions))

    #              precision    recall  f1-score   support#how many True class for that row
    #
    #         ham       0.96      1.00      0.98       968
    #        spam       1.00      0.75      0.86       147
    #
    #   micro avg       0.97      0.97      0.97      1115
    #   macro avg       0.98      0.87      0.92      1115
    #weighted avg       0.97      0.97      0.96      1115

classes = [
     
    ('Gaussian Naive Bayes', 1,
                 Pipeline([
                     ('bow',CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), 
                     ('tfidf',TfidfTransformer()), 
                     ('dense', FunctionTransformer(lambda x: x.toarray(), validate=True, accept_sparse=True, check_inverse=False)),# requires dense matrix
                     ('classifier',GaussianNB()) ])),
    ('Multinomial Naive Bayes', 0, Pipeline([
                    ('bow',CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), 
                    ('tfidf',TfidfTransformer()), 
                    ('classifier',MultinomialNB()) ])),
    ('Complement Naive Bayes', 0, Pipeline([
                    ('bow',CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), 
                    ('tfidf',TfidfTransformer()), 
                    ('classifier',ComplementNB()) ])),
    ('Bernoulli Naive Bayes', 0, Pipeline([
                    ('bow',CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), 
                    ('tfidf',TfidfTransformer()), 
                    ('std', MaxAbsScaler()),  #[-1, 1] such that binarize=0.0 works (BernoulliNB works with only binary features)
                    ('classifier',BernoulliNB(binarize=0.0)) ])),
    ('Stochastic Gradient Descent (SGD) ', 0, Pipeline([
                    ('bow',CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), 
                    ('tfidf',TfidfTransformer()), 
                    ('std', StandardScaler(with_mean=False)), #not to break sparsity 
                    ('classifier',SGDClassifier(tol=1e-3)) ])),
]   
    
    
    
    

print('''
precision
    what % of predicted positive are actually positves?
Recall, Sensitivity 
    what % of actual positives are predicted positives?
f1 score
    The F1 score is a weighted harmonic mean of precision and recall 
    such that the best score is 1.0 and the worst is 0.0. 
support
    Support is the number of actual occurrences of the class in the specified dataset. 
    Imbalanced support in the training data may indicate structural weaknesses 
    in the reported scores of the classifier 
    and could indicate the need for stratified sampling or rebalancing. 
    Support doesn't change between models but instead diagnoses the evaluation process.
    
F1 score methods 
"macro" 
    simply calculates the mean of the binary metrics, giving equal weight to each class. 
"micro" 
    gives each sample-class pair an equal contribution to the overall metric 
    Rather than summing the metric per class, 
    this sums the dividends and divisors that make up the per-class metrics 
    to calculate an overall quotient. 
    Micro-averaging may be preferred in multilabel settings, 
    including multiclass classification   
''')

for name, dense, pipeline in classes:
    print("---------------------------%s------------------------" % (name, ))
    process(pipeline)
    #else:
    #    process(pipeline, msg_train.values, class_train, msg_test.values, class_test)

from flaskr2 import app 

"""
REST - payload json (python dict) or xml

User input 
GET params 
    URL params  - http://localhost:5000/helloj?name=das&format=json 
        read it from request.args , a dict 
    PATH params -  http://localhost:5000/helloj/das/json 
    
POST params - Content-Type : 'application/json' 
body contains json string - '{"name": "das", "format": "json"}'

Then returns json string with Content-Type = "application/json"
"""
from flask import request, jsonify

@app.route("/helloj", methods=['GET', 'POST']) #GET URL params and post params 
@app.route("/helloj/<string:name>", methods=["GET"]) #PATH params
def helloj(name="abc"):  #flask puts PATH params in function arguments
    db = [dict(name="das", age=20), dict(name="abc", age=30)]
    #Get user input 
    fname = name 
    if request.method == 'GET':
        fname = request.args.get("name", fname) # GET URL params 
    else: #POST
        if 'Content-Type' in request.headers and \
            request.headers['Content-Type'].lower() in ["application/json"]:
            fname = request.json.get("name", fname) #request.json is a dict 
    #find the age 
    age = None   
    for emp in db:
        if emp['name'].lower() == fname.lower():
            age = emp['age']
    #Return result in json 
    if age:
        obj = dict(name=fname, age=age)
        resp = jsonify(obj)  #flask tool to convert python dict into json string
        resp.status_code = 200 
        return resp         
    else: #error 
        obj = dict(name=fname, details="not found")
        resp = jsonify(obj)
        resp.status_code = 500 
        return resp      


"""Client -code => run in new python prompt or in script 
import requests 

url1 = "http://localhost:5000/helloj?name=das"
url2 = "http://localhost:5000/helloj/das"
url3 = "http://localhost:5000/helloj"

resp = requests.get(url1)
resp.status_code 
resp.json()  # in python dict 
resp = requests.get(url2)
resp.status_code 
resp.json()  # in python dict 

headers = {'Content-Type': 'application/json'}
obj = dict(name="das")
resp = requests.post(url3, json=obj, headers=headers)
resp.status_code 
resp.json() 


"""
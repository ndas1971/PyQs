##Pandas
#2D - rows x cols
#2D - DataFrame - collection of columns - each COl - Series
#2D - DB, xlsx, CSV.. - IO
#Read any IO 
iris = pd.read_csv("data/iris.csv")
#Metadata
iris.head()
iris.columns  #['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth', 'Name']
iris.index  # row_id 
iris.dtypes
len(iris)  # no of rows 
#Access 
iris.SepalLength   # Series 
iris['SepalLength']  # Series
iris[['SepalLength', 'PetalLength']]  #DF 
#iloc - based on index [row_index, col_index]
#loc - [row_id, col_names] 
#can contain slice, in iloc, end is not included, loc, end is included 
#    SepalLength  SepalWidth
# 0          5.1         3.5
# 1          4.9         3.0
# 2          4.7         3.2
iris.iloc[0:3, [0,1]]
iris.loc[ 0:2, ['SepalLength',  'SepalWidth']]  #DF 
#loc - can boolean query 
iris.loc[ iris.SepalLength > 5.5, :]
#and - &, or - |, not ~
iris.loc[ (iris.SepalLength > 5.0) & (iris.SepalLength < 5.9), :]
#Create column 
iris['dummy'] = iris.SepalLength - 2* iris.PetalLength + 2
iris.dummy 
#Apply some functions
iris.SepalLength.mean()  # mean of one colume 
iris.iloc[:,0:4].mean()  #applied on cloumnise 
iris.iloc[:,0:4].mean(axis=1)  #default axis=0, axis=1 , rowise
#Aggregation 
gr = iris.groupby('Name')
gr.mean()  # mean of each column for each distinct Name 
gr.agg({'SepalLength': ['min', 'max']})
gr.agg({'SepalLength': ['min', 'max']}).to_excel('p.xlsx')
#plot
iris.iloc[:, 0:4].plot(kind='line')
plt.show()
#individual
fig, (ax1, ax2) = plt.subplots(2,1, layout="constrained")
iris.SepalLength.plot(kind='line', ax=ax1)
iris.SepalWidth.plot(kind='line', ax=ax2)
plt.show()

###########handson 
###Handson 
Prove that sum of two Gaussian distributions is normal 
Prove Central limit theorem 

Hint- CLT
if you take sufficiently large samples from any population, 
the distribution of the sample means will be approximately a normal (bell-shaped) distribution, 
regardless of the original population's distribution
Create 
Use pandas dataframe of four columns 
A,B,C,D with normal mu=0,sigma=1, normal mu=3,sigma=2,
uniform ,binomial with n=1000, p=0.4
Then draw accordingly

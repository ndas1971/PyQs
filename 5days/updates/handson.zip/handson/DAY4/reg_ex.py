"""
Preprocessing - Most Important 
    LabelEncoding
    OneHotEncoder
    StdScalar
Train Test Split
    Train 
    Validation - Test 
CrossValidation
y = F(X)
Target y - discreet - classification
Target y - continuous - Regressing 
Given X,y - find F, we call Model finding 
ML - given X, predict y 
GenAI - Given y, predict X 
X - 2D , y- 1D 
F - relational parameter
    configuration parameters 
    - hyperparameter- Tune - GridSearch
Metrics - Regression - R^2 , 0 -1
          classication - Accuracy 
          AUC - 0, 1, F1beta , 0-1
"""
df = pd.read_csv('data/boston.csv')
data = df.iloc[:, 0:13]
target = df.ilcoc[:, 13]
scaler = StandardScaler()
data_s = scaler.fit_transform(data)  # 2D
#Spliting
X_train, X_test, y_train, y_test = train_test_split(data_s, target, random_state=0)
#Train, then score, predict and see test score
model = LinearRegression().fit(X_train, y_train)
#By default R^
model.score(X_train, y_train)
y_pred = model.predict(X_test)
model.score(X_test, y_test)

##classification 
iris = pd.read_csv(r"data\iris.csv")
data = iris[['SepalLength' , 'SepalWidth',  'PetalLength',  'PetalWidth']]
target = iris.Name
enc = LabelEncoder()
y = enc.fit_transform(target)
X = data
sc = StandardScaler()
lr = LogisticRegression()
pipeline = Pipeline([('sc', sc),('lr', lr)])
search_grid = dict(lr__C=[0.1, 1,10])
X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=0)
m = GridSearchCV(pipeline, search_grid,cv=5)  # KFold is 5
m.fit(X_train,y_train)
final_model = m.best_estimator_
final_model.score(X_test,y_test)
y_pred = final_model.predict(X_test)
confusion_matrix(y_test,y_pred)
m.best_params_

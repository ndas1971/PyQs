#1. Find checksum 
input="ABCDEF1234567890"
#http://bit.ly/3TNN4hp

#Take two two character(one byte) from above (which are in hex digit )
#Convert to int  (Hint: use int function with base)
#Sum all and then find mod with 255, that is your checksum 

#map 
el = []
for c1, c2 in list(zip(input[::2], input[1::2])):
    el.append( int(c1+c2, base=16))
print(el)
#reduce 
checksum = sum(el) % 255
print(f"checksum={checksum}")
#alternate
print( sum([int(c1+c2, base=16) for c1, c2 in zip(input[::2], input[1::2]) ]) % 255)

"""
>>> a = 1
>>> type(a)
<class 'int'>

class - instance methods


object - instance 
    call those instance methods 
    has memory location , instance methods use that memory 

OOD
    nouns - class , verbs - instance methods 
    
Special method 
    __xyz__ , signature is given in datamodel 
    
Relations 
    has - containment 
    is - inheritance
    
abstract method 
    which derived classes must implement 
    (line interface in java)
    
OOP
    no access control 
    no interface 
        abcMeta 
    instance variables and methods 
        prefix self 
    class method and class variables 
        (like java static)
    static method 
    properties 
    slots 
    ....

"""
# Bank User has name and account. There are two types of Users
# Normal and privileged user . There are two types of privileged
# users, Gold and Silver. Gold has cashback of 5% and Silver has 
# cashback of 3% of expenditure when they spend any cash 

class NotEnoughBalance(Exception):  #inheritance 
    pass

class BankAccount:
    def __init__(self, initAmount):
        self.amount = initAmount
    def transact(self, amount):
        if self.amount + amount < 0:
            raise NotEnoughBalance("Not enough balance")
        self.amount = self.amount + amount 
    def __str__(self):
        return f"BankAccount({self.amount})"
        
from abc import ABCMeta, abstractmethod
class BankUser(metaclass=ABCMeta):   #changing metaclass
    how_many_users = 0               #class variables, access BankUser.how_many_users
    #class methods - only can access class variable 
    @classmethod                    #decorator applied 
    def count_of_users(cls):
        return cls.how_many_users          #class method - first argument is class 
    def __init__(self, name, initAmount):  #instance method - first argument is instance 
        self.name = name                    #instance variable 
        self.account = BankAccount(initAmount)
        BankUser.how_many_users += 1
    def __str__(self):
        return f"BankUser({self.name}, {self.account})"
    def transact(self, amount):    # templating - algorithm in base, tweaking in derived
        try:
            self.account.transact(amount)
            if amount < 0:
                cashback = self.getCashbackPercentage() * abs(amount)
                self.account.transact(cashback)
        except NotEnoughBalance as ex:
            print(self.name, " has problem-", ex)
    @abstractmethod    #applying a deorator
    def getCashbackPercentage(self):
        return 0 
    @staticmethod 
    def version():  #no first argument
        return "1.0.0"
    @property               #property is method, which you call like variable 
    def balance(self):
        return self.account.amount 

class GoldUser(BankUser):
    def getCashbackPercentage(self):
        return 0.05
    
class SilverUser(BankUser):
    def getCashbackPercentage(self):
        return 0.03
        
class NormalUser(BankUser):
    def getCashbackPercentage(self):
        return super().getCashbackPercentage()
    
        
if __name__ == '__main__':  # pragma: no cover 
    #BankUser("ABC", 100)
    users = [GoldUser("Gold", 100), 
             SilverUser("Silver", 100), 
             NormalUser("Normal", 100), ]
    amounts = [100, -200, 300, -400, 400]
    for u in users:
        for am in amounts:
            u.transact(am)
        print(u.name, u.balance)  #using prop
    print(BankUser.how_many_users)
    print(BankUser.version())



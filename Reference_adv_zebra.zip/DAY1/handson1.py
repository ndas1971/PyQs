
class Fraction:
    def __init__(self, num, den):
        self.n = num 
        self.d = den 
    def __add__(self, other):
        d = self.d * other.d 
        n = self.d * other.n + self.n * other.d 
        return  Fraction(n,d)
    def __str__(self):
        return f"Fraction({self.n}, {self.d})" 


#Usage 
if __name__ == '__main__':
    a = Fraction(1,2)
    b = Fraction(1,2)
    c = a+b 
    print(f"a={a}, b={b}, c={c}") #Fraction(4,4)
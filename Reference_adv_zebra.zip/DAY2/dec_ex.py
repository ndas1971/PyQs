# Given directory, find file name with maximum size 
import glob   # dir/ls 
import os.path  # file path handling 
import time 

DEBUG = False 

def print_debug(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)
        
#fn taking fn returning fn 
#profile taking fun function and returning _inner function 
def profile(fun):  #fun = getMaxFilename
    print_debug("profile called, fun=", fun)
    def _inner(*args, **kwargs):
        print_debug("profile::_inner called, args=", args, "kwargs=", kwargs)
        st = time.time()
        res = fun(*args, **kwargs)  #getMaxFilename(*args, **kwargs)
        print("Time taken:", time.time()-st)
        print_debug("profile::_inner returned")
        return res 
    print_debug("profile returned, _inner=", _inner)
    return _inner 
        

@profile                        #getMaxFilename = profile(getMaxFilename) = _inner #profile called,returned 
def getMaxFilename(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for f in files:
            if os.path.isfile(f):
                ed[f] = os.path.getsize(f)
            else:
                get_files(f, ed)    
        return ed 
    #create dict with filename as key and value with size 
    allfiles = get_files(path)
    #print_debug(allfiles)
    #sort based on values 
    sted = sorted(allfiles, key=lambda k: allfiles[k])
    #return last     
    return sted[-1] if sted else ''



if __name__ == '__main__':
    path = r"D:\handson"
    #print(getMaxFilename(path)) #_inner(path)


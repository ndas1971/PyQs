#Given path, print all files 
import glob   # dir/ls 
import os.path  # file path handling 
import time 
import itertools 
chunk = 20 

def get_files(path, ed):
    files = glob.glob(os.path.join(path, "*"))
    for f in files:
        if os.path.isfile(f):
            ed.append( f)
        else:
            get_files(f, ed)    
    return ed 
    
#iterator - syntax is like function, but has yield 
#only for loop can handle iterator 
def get_files_it(path):
    files = glob.glob(os.path.join(path, "*"))
    for f in files:
        if os.path.isfile(f):
            yield f
        else:
            #for file in get_files_it(f):
            #    yield file 
            #or 
            yield from get_files_it(f)
    
if __name__ == '__main__':
    path = r"C:\Windows"
    it = iter( get_files_it(path))  # to conver a function pure Iterator 
    chunks = list(itertools.islice(it, chunk))
    while chunks:
        print(chunks)
        chunks = list(itertools.islice(it, chunk))
    #for f in get_files_it(path):
    #    print(f)
import threading
import time

from dec_ex import profile 

#@profile 
def worker(sleeptime, lock):
    print(f"-> {threading.current_thread().getName()}")
    with lock:
        time.sleep(sleeptime)
    print(f"<- {threading.current_thread().getName()}")
    
@profile 
def thread_worker(n, target, *args):
    ths = []
    for i in range(n):
        th = threading.Thread(target=target, args=args)
        ths.append( th )
    [th.start() for th in ths]
    #waiting for end 
    [th.join() for th in ths] 

    
if __name__ == '__main__':
    print("sequentially")
    #worker(5)   #MainThread
    #
    print("parallely")
    #syn = threading.Lock()
    syn = threading.Semaphore(2) 
    thread_worker(10, worker, 5, syn)

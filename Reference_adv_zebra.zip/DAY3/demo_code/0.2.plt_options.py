import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("""
character      description 
'-'             solid line style 
'--'            dashed line style 
'-.'            dash-dot line style 
':'             dotted line style 
'.'             point marker 
','             pixel marker 
'o'             circle marker 
'v'             triangle_down marker 
'^'             triangle_up marker 
'<'             triangle_left marker 
'>'             triangle_right marker 
'1'             tri_down marker 
'2'             tri_up marker 
'3'             tri_left marker 
'4'             tri_right marker 
's'             square marker 
'p'             pentagon marker 
'*'             star marker 
'h'             hexagon1 marker 
'H'             hexagon2 marker 
'+'             plus marker 
'x'             x marker 
'D'             diamond marker 
'd'             thin_diamond marker 
'|'             vline marker 
'_'             hline marker 

character   color 
'b'         blue 
'g'         green 
'r'         red 
'c'         cyan 
'm'         magenta 
'y'         yellow 
'k'         black 
'w'         white



few Line2D properties that can be passsed to  plt.plot or ax.plot 
or other plot functions as keyword arg passing 

To get a list of settable line properties, 
call the setp() function with a line or lines as argument
""")

lines = plt.plot([1, 2, 3])
plt.setp(lines) 


print("""

Main Kewords:
----------------
color or c              
    any matplotlib color 
label                   
    string or anything printable with '%s' conversion. 
linestyle or ls         
    ['solid' | 'dashed', 'dashdot', 'dotted' | (offset, on-off-dash-seq) | '-' | '--' | '-.' | ':' | 'None' | ' ' | ''] 
linewidth or lw         
    float value in points 

    
Setting of options 
---------------------------
#Option-1 Use keyword args:
plt.plot(t, t, linewidth=2.0)

#Option-2: Use the setter methods of Line2D
line1, line2 = plt.plot(t, t**2, t, t**3 ) #x1,y1,x2,y2
line1.set_antialiased(False)  # turn off antialising

#Option-3: Use the setp() command
lines = plt.plot(t, t**2, t, t**3 )
# use keyword args
plt.setp(lines, color='r', linewidth=2.0)
# or MATLAB style string value pairs
plt.setp(lines, 'color', 'r', 'linewidth', 2.0)

""")


"""
#Main keyword 
color or c              any matplotlib color 
label                   string or anything printable with '%s' conversion. 
linestyle or ls         ['solid' | 'dashed', 'dashdot', 'dotted' | (offset, on-off-dash-seq) | '-' | '--' | '-.' | ':' | 'None' | ' ' | ''] 
linewidth or lw         float value in points 
#Other Keyword
alpha                   float (0.0 transparent through 1.0 opaque) 
animated                [True | False] 
antialiased or aa       [True | False] 
clip_box                a matplotlib.transforms.Bbox instance 
clip_on                 [True | False] 
dash_capstyle           ['butt' | 'round' | 'projecting'] 
dash_joinstyle          ['miter' | 'round' | 'bevel'] 
drawstyle               ['default' | 'steps' | 'steps-pre' | 'steps-mid' | 'steps-post'] 
fillstyle               ['full' | 'left' | 'right' | 'bottom' | 'top' | 'none'] 
marker                  A valid marker style 
markeredgecolor or mec  any matplotlib color 
markeredgewidth or mew  float value in points 
markerfacecolor or mfc  any matplotlib color 
markersize or ms        float 
solid_capstyle          ['butt' | 'round' | 'projecting'] 
solid_joinstyle         ['miter' | 'round' | 'bevel'] 
visible                 [True | False] 
zorder                  any number 
"""

print("""
##Specifying matplotlib.colors
#Only For the below basic colors, use a single letter
b: blue,g: green,r: red,c: cyan,m: magenta,y: yellow,k: black w: white

#All examples of colors 
#https://matplotlib.org/examples/color/named_colors.html

#Gray shades can be given as a string encoding a float in the 0-1 range, e.g.:
color = '0.75'

#can specify the color using an html hex string(RGB or RGBA), as in:
color = '#eeefff' or '#0F0F0F0F'

#or you can pass an R , G , B tuple, or RGBA 
#where each of R , G , B are in the range [0,1].
color = (0.5,0.5,0.5) or (0.1, 0.2, 0.5, 0.3));

#Or use legal html names for colors, like 'red, 'burlywood and 'chartreuse'
#https://www.w3schools.com/tags/ref_colornames.asp
color = 'burlywood'
""")
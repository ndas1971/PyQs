import warnings
warnings.simplefilter(action='ignore', category=RuntimeWarning)

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

df = pd.DataFrame(np.random.randn(6,4),index=list('abcdef'),columns=list('ABCD'))

print("""
##DataFrame Accessing 

Main Accessing 
>>> df= pd.DataFrame([[4, 7, 10],[5, 8, 11],[6 , 9, 12 ]],index=[1, 2, 3],columns=['a', 'b', 'c'])
#one column 
>>> df['a']
1    4
2    5
3    6
Name: a, dtype: int64

>>> df[['a','c']]
   a   c
1  4  10
2  5  11
3  6  12

>>> df.iloc[0,0]
4

>>> df.iloc[0:2,0:2]
   a  b
1  4  7
2  5  8

>>> df.iloc[[0,2],[0,2]]
   a   c
1  4  10
3  6  12

#Note df['a'] > 10 generates True/False for each row,
>>> df['a'] > 10
1    False
2    False
3    False
Name: a, dtype: bool

#based on condition: 
#Only true row is selected and  all columns 
>>> df[df['a']< 10]
   a  b   c
1  4  7  10
2  5  8  11
3  6  9  12

#.loc is must 
>>> df.loc[df['a']< 10, ['a','c']]
   a   c
1  4  10
2  5  11
3  6  12

#column condition based selection 
>>> df.columns
Index(['a', 'b', 'c'], dtype='object')

#this workes only when row and column dimension match 
>>> df.columns[df['a'] > 5]   #Only true result is selected 
Index(['c'], dtype='object')

#only below form 
>>> df[df.columns[df['a'] > 5]]
    c
1  10
2  11
3  12





df.column_name
    when column_name is string
    Only for accessing or update 
    Not for creation of new column, use df['column_name'] style 
    For index column, access always like df.index 
    
#Example    
df.head()
df.tail()
df.index 
df.columns 
df.dtypes 
df.size #30
df.shape #6,5
df.A 
#for update , in place 
df['A-1'] = df.A + df.C   
#new copy  
df.assign(AA= df.A + df.C, BB= lambda df: df.A + df.C    )

#all arithmatic operations possible  
df['A-1'] = df.A ** 2 
df['A-1'] = np.sqrt(df.A) 
 
#also at DF level , elementwise 
df + 1 
df + df 
1/df 
np.log(df)  #with Nan 
np.log(df).fillna(0) #all fill 
#or 
np.log(df).fillna({'A': np.mean(df.A)}) #only A column fill 

#fill all columns by A mean where df.A is null (might not be intended)
df11 = np.log(df)
df11[df11.A.isnull()] =  np.mean(df.A)

#but below OK , fill only those points in A by A mean 
df11 = np.log(df)
df11['A'][df11.A.isnull()]=  np.mean(df.A)

 
df[column]
    column can be 
        Single column label eg 'City'
        Array of column lables eg ['City', 'City']
        A boolean eg df[df.City == 'Chicago']
        A callable, fn(df):returns_any_from_above eg. df[lambda d: d.City == 'Chicago']
    Can be used for update dfi['C'] = dfi['A']
    
#Example 
#df[column]
df['A']  #Series 
df[['A']]  # DF 
df[['A', 'B']] 
df[ df['A'] >= 1.0] #DF  #all rows where df['A'] is >= 1.0 , True , rows includes all Column
df[lambda df: df['A'] >= 1.0]

df.query('A > B')
# same result as the previous expression  
df[df.A > df.B] 
#Replace values by 0 (all columns) where the condition is False.
df.where(df.A > df.B, 0) 
#Replace values by NaN(all columns) where the condition is False.
df.where(df.A > df.B) 
    

df[row_slice]
    row_slice can be 
        start:stop:step, stop exclusive 
        where start,stop are row index 
    But for DatetimeIndex, it's possible to access based on datetime index 
#Example 
df[1:3]
df[1:3]['A']  #only A 
df['a':'c']   #based on index label , but index should be sorted one 
df.sort_index(level=0)
    
    
df.loc[row,column] 
    label based(both row and column)
    row,column takes 
        A single label, e.g. 5 or 'a', 
        A list or array of labels ['a', 'b', 'c']
        A slice object with labels 'a':'f' (end inclusive)
        A boolean array eg df.A > 0 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
        For DatetimeIndex, row can be as given in above example 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']
df.loc[row]
    equivalent to df.loc[row,:]
#Example  
df.loc['a' , :]  #Series of all COlumns 
df.loc['a']      #same as above 
df.loc[['a'] , :] #now DF of single row 
df.loc[: , 'A']   #Series of all rows of column A 
df.loc[: , ['A']]   #now DF of single column
df.loc['a', 'A']   #single cell 
df.loc[['a','b'], ['A','B']] 
df.loc[['a','b']] 
df.loc['a': 'c', 'A': 'C']  #inclusive index must be sorted
df.loc[df.A >=1.0, 'C']   #Series 
df.loc[df.A >=1.0, ['C']]  #now DF 
df.loc[lambda df: df.A >=1.0, 'C']
#update , LHS can have any of the above, RHS dimension must match 
df.loc[:,'C'] = df.loc[:,'A']


df.iloc[row,column] 
    index based(both row, column)
    row,column takes 
        An integer e.g. 5
        A list or array of integers [4, 3, 0]
        A slice object with ints 1:7:1 , end exclusive 
        A boolean array *** NOT IMPLEMENTED *** 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']    
df.iloc[row]
    equivalent to df.iloc[row,:]
#Same with integer index  now  
#Example  
df.iloc[0 , :]  #Series of all COlumns 
df.iloc[0]      #same as above 
df.iloc[[0] , :] #now DF of single row 
df.iloc[: , 0]   #Series of all rows of column A 
df.iloc[: , [0]]   #now DF of single column
df.iloc[0, 0]   #single cell 
df.iloc[[0,1], [0,1]] 
df.iloc[[0,1]] 
df.iloc[0: 3, 0: 3]  #inclusize
#below three not available 
#df.iloc[df.A >=1.0, 2]   #Series 
#df.iloc[df.A >=1.0, [2]]  #now DF 
#df.iloc[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.iloc[:,2] = df.iloc[:,0]

   
df.ix[row,column] 
    For each of row,column ,at first tries label based like df.loc[] 
    if Fails, then tries index based like df.iloc[]
    If the index or column does not have label,then behaves like df.iloc[] always 
    For DatetimeIndex, row can be as given in above example 
df.ix[row]
    equivalent to df.ix[row,:]
    For DatetimeIndex, row can be as given in above example
#Firt label, then index 
#all .loc and iloc can be used exactly like above 
#but now can be mixed     
#Example 
df.ix['a' , :]  #Series of all COlumns 
df.ix['a']      #same as above 
df.ix[[0] , :] #now DF of single row 
df.ix[: , 'A']   #Series of all rows of column A 
df.ix[: , [0]]   #now DF of single column
df.ix['a', 0]   #single cell 
df.ix[[0,1], ['A','B']] 
df.ix[[0,1]] 
df.ix['a': 'c', 0: 2]  #label inclusive, integer exclusive , index must be sorted
df.ix[df.A >=1.0, 2]   #Series 
df.ix[df.A >=1.0, ['C']]  #now DF 
df.ix[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.ix[:,'C'] = df.ix[:,0]



df.iat[row_index,column_index]
df.at[row_label, column_label] 
    for accessing a cell 
#Example 
df.at['a', 'A']
df.iat[0,0]  
    
    
    
df.xs(key, axis=0, level=None, drop_level=True)
    key : label or tuple of label
    Mainly for  for multiindex 
#Example 
df.xs('a')  #rowwise , but a Series 
df.xs('A', axis=1) #cloumnwise, but a series 
""")
df.head()
df.tail()
df.index 
df.columns 
df.dtypes 
df.size #30
df.shape #6,5
df.A 
#for update , in place 
df['A-1'] = df.A + df.C   
#new copy  
df.assign(AA= df.A + df.C, BB= lambda df: df.A + df.C    )

#all arithmatic operations possible  
df['A-1'] = df.A ** 2 
df['A-1'] = np.sqrt(df.A) 
 
#also at DF level , elementwise 
df + 1 
df + df 
1/df 
np.log(df)  #with Nan 
np.log(df).fillna(0) #all fill 
#or 
np.log(df).fillna({'A': np.mean(df.A)}) #only A column fill 

#fill all columns by A mean where df.A is null (might not be intended)
df11 = np.log(df)
df11[df11.A.isnull()] =  np.mean(df.A)

#but below OK , fill only those points in A by A mean 
df11 = np.log(df)
df11['A'][df11.A.isnull()]=  np.mean(df.A)

'''
df[column]
    column can be 
        Single column label eg 'City'
        Array of column lables eg ['City', 'City']
        A boolean eg df[df.City == 'Chicago']
        A callable, fn(df):returns_any_from_above eg. df[lambda d: d.City == 'Chicago']
    Can be used for update dfi['C'] = dfi['A']
'''
 
#df[column]
df['A']  #Series 
df[['A']]  # DF 
df[['A', 'B']] 
df[ df['A'] >= 1.0] #DF  #all rows where df['A'] is >= 1.0 , True , rows includes all Column
df[lambda df: df['A'] >= 1.0]

df.query('A > B')
# same result as the previous expression  
df[df.A > df.B] 

#Replace values by 0 (all columns) where the condition is False.
df.where(df.A > df.B, 0) 
#Replace values by NaN(all columns) where the condition is False.
df.where(df.A > df.B)   
    
'''
df[row_slice]
    row_slice can be 
        start:stop:step, stop exclusive 
        where start,stop are row index 
    But for DatetimeIndex, it's possible to access based on datetime index 
'''    
df[1:3]
df[1:3]['A']  #only A 
df['a':'c']   #based on index label , but index should be sorted one 
df.sort_index(level=0)
    
''' 
df.loc[row,column] 
    label based(both row and column)
    row,column takes 
        A single label, e.g. 5 or 'a', 
        A list or array of labels ['a', 'b', 'c']
        A slice object with labels 'a':'f' (end inclusive)
        A boolean array eg df.A > 0 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
        For DatetimeIndex, row can be as given in above example 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']
    
df.loc[row]
    equivalent to df.loc[row,:]
'''
#label based    
df.loc['a' , :]  #Series of all COlumns 
df.loc['a']      #same as above 
df.loc[['a'] , :] #now DF of single row 
df.loc[: , 'A']   #Series of all rows of column A 
df.loc[: , ['A']]   #now DF of single column
df.loc['a', 'A']   #single cell 
df.loc[['a','b'], ['A','B']] 
df.loc[['a','b']] 
df.loc['a': 'c', 'A': 'C']  #inclusive index must be sorted
df.loc[df.A >=1.0, 'C']   #Series 
df.loc[df.A >=1.0, ['C']]  #now DF 
df.loc[lambda df: df.A >=1.0, 'C']
#update , LHS can have any of the above, RHS dimension must match 
df.loc[:,'C'] = df.loc[:,'A']

'''
df.iloc[row,column] 
    index based(both row, column)
    row,column takes 
        An integer e.g. 5
        A list or array of integers [4, 3, 0]
        A slice object with ints 1:7:1 , end exclusive 
        A boolean array *** NOT IMPLEMENTED *** 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']    
df.iloc[row]
    equivalent to df.iloc[row,:]
'''
#Same with integer index  now   
df.iloc[0 , :]  #Series of all COlumns 
df.iloc[0]      #same as above 
df.iloc[[0] , :] #now DF of single row 
df.iloc[: , 0]   #Series of all rows of column A 
df.iloc[: , [0]]   #now DF of single column
df.iloc[0, 0]   #single cell 
df.iloc[[0,1], [0,1]] 
df.iloc[[0,1]] 
df.iloc[0: 3, 0: 3]  #inclusize
#below three not available 
#df.iloc[df.A >=1.0, 2]   #Series 
#df.iloc[df.A >=1.0, [2]]  #now DF 
#df.iloc[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.iloc[:,2] = df.iloc[:,0]

'''
df.ix[row,column] 
    For each of row,column ,at first tries label based like df.loc[] 
    if Fails, then tries index based like df.iloc[]
    If the index or column does not have label,then behaves like df.iloc[] always 
    For DatetimeIndex, row can be as given in above example 
df.ix[row]
    equivalent to df.ix[row,:]
    For DatetimeIndex, row can be as given in above example
'''
#Firt label, then index 
#all .loc and iloc can be used exactly like above 
#but now can be mixed     
df.ix['a' , :]  #Series of all COlumns 
df.ix['a']      #same as above 
df.ix[[0] , :] #now DF of single row 
df.ix[: , 'A']   #Series of all rows of column A 
df.ix[: , [0]]   #now DF of single column
df.ix['a', 0]   #single cell 
df.ix[[0,1], ['A','B']] 
df.ix[[0,1]] 
df.ix['a': 'c', 0: 2]  #label inclusive, integer exclusive , index must be sorted
df.ix[df.A >=1.0, 2]   #Series 
df.ix[df.A >=1.0, ['C']]  #now DF 
df.ix[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.ix[:,'C'] = df.ix[:,0]

'''
df.iat[row_index,column_index]
df.at[row_label, column_label] 
    for accessing a cell 
'''
df.at['a', 'A']
df.iat[0,0]  

'''
df.xs(key, axis=0, level=None, drop_level=True)
    key : label or tuple of label
    Mainly for  for multiindex 
'''
df.xs('a')  #rowwise , but a Series 
df.xs('A', axis=1) #cloumnwise, but a series 


print("""
Dropping Rows And Columns In pandas Dataframe

import pandas as pd

data = {'name': ['Jason', 'Molly', 'Tina', 'Jake', 'Amy'], 
        'year': [2012, 2012, 2013, 2014, 2014], 
        'reports': [4, 24, 31, 2, 3]}
df = pd.DataFrame(data, index = ['Cochice', 'Pima', 'Santa Cruz', 'Maricopa', 'Yuma'])

>>>df
             name  reports  year
Cochice     Jason        4  2012
Pima        Molly       24  2012
Santa Cruz   Tina       31  2013
Maricopa     Jake        2  2014
Yuma          Amy        3  2014

#default is axis=0 ie row 
>>> df.drop(['Cochice', 'Pima'])
            name  reports  year
Santa Cruz  Tina       31  2013
Maricopa    Jake        2  2014
Yuma         Amy        3  2014

#from column 
>>> df.drop('reports', axis=1)
             name  year
Cochice     Jason  2012
Pima        Molly  2012
Santa Cruz   Tina  2013
Maricopa     Jake  2014
Yuma          Amy  2014


#Drop a row if it contains a certain value (in this case, 'Tina')

>>> df[df.name != 'Tina']
           name  reports  year
Cochice   Jason        4  2012
Pima      Molly       24  2012
Maricopa   Jake        2  2014
Yuma        Amy        3  2014


#Drop a row by row number (in this case, row 3)
df.drop(df.index[2])

#dropping a range
df.drop(df.index[[2,3]])

#dropping relative to the end of the DF.
df.drop(df.index[-2])

df[:3] #keep top 3
df[:-3] #drop bottom 3 
""")

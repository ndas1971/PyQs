import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("", """
DataFrame.unstack(level=-1, fill_value=None)
DataFrame.stack(level=-1, dropna=True)
    level : int, string, or list of these, default -1 (last level)
        Level(s) of index to unstack, can pass level name
    fill_value : replace NaN with this value if the unstack produces missing values
    dropna : boolean, default True
        Whether to drop rows in the resulting Frame/Series with no valid values

#Meanings 
stack(column->row): Move last level(default) or 'level' of MultiIndex column labels 
       into last level of row labels
unstack(row->column): Move last level(default) or 'level' of MultiIndex row labels 
       into last level of column labels

#The stack function moves out a level in the DataFrame's columns 
#to produce either:
    *A Series, in the case of a simple column Index
    *A DataFrame, in the case of a MultiIndex in the columns
""")

#Example 
tuples = list(zip(*[['bar', 'bar', 'baz', 'baz',
                    'foo', 'foo', 'qux', 'qux'],
                   ['one', 'two', 'one', 'two',
                    'one', 'two', 'one', 'two']]))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 2), index=index, columns=['A', 'B'])
df2 = df[:4]
print("Given DF=",df2, sep="\n")
#                      A         B
# first second                    
# bar   one     0.721555 -0.706771
#       two    -1.039575  0.271860
# baz   one    -0.424972  0.567020
#       two     0.276232 -1.087401
      
stacked = df2.stack() #(column->row)
print("", """
stacked = df2.stack() #(column->row)
>>> stacked
""",
stacked,
sep="\n")

#first  second   
#bar    one     A    0.721555
#               B   -0.706771
#       two     A   -1.039575
#               B    0.271860
#baz    one     A   -0.424972
#               B    0.567020
#       two     A    0.276232
#               B   -1.087401
#dtype: float64

print("", """
>>> stacked.unstack() #(row->column)
""",
stacked.unstack(),
sep="\n")
#                     A         B
#first second                    
#bar   one     0.721555 -0.706771
#      two    -1.039575  0.271860
#baz   one    -0.424972  0.567020
#      two     0.276232 -1.087401

print("", """
>>> stacked.unstack(1) #(row->column), level=1 (0-based) moved to column 
""",
stacked.unstack(1),
sep="\n")

#second        one       two
#first                      
#bar   A  0.721555 -1.039575
#      B -0.706771  0.271860
#baz   A -0.424972  0.276232
#      B  0.567020 -1.087401

print("", """
>>> stacked.unstack(0) #(row->column), level=0 (0-based)
""",
stacked.unstack(0),
sep="\n")
#first          bar       baz
#second                      
#one    A  0.721555 -0.424972
#       B -0.706771  0.567020
#two    A -1.039575  0.276232
#       B  0.271860 -1.087401

print("", """
#If the indexes have names
>>> stacked.unstack('second')#(row->column), level=1 (0-based)
""",
stacked.unstack('second'),
sep="\n")
#second        one       two
#first                      
#bar   A  0.721555 -1.039575
#      B -0.706771  0.271860
#baz   A -0.424972  0.276232
#      B  0.567020 -1.087401
#
      
      
      
      
      
##Combining stack/unstack with stats and GroupBy
columns = pd.MultiIndex.from_tuples([('A', 'cat'), ('B', 'dog'),
                                     ('B', 'cat'), ('A', 'dog')],
                                    names=['exp', 'animal'])
index = pd.MultiIndex.from_product([('bar', 'baz', 'foo', 'qux'),
                                    ('one', 'two')],
                                   names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 4), index=index, columns=columns)

print("Combining stack/unstack with stats and GroupBy", 
"Given DF=",
df,
sep="\n")
#>>> df
#exp                  A                  B                 
#animal             cat       dog       cat       dog
#first second                                        
#bar   one     0.895717  0.805244 -1.206412  2.565646
#      two     1.431256  1.340309 -1.170299 -0.226169
#baz   one     0.410835  0.813850  0.132003 -0.827317
#      two    -0.076467 -1.187678  1.130127 -1.436737
#foo   one    -1.413681  1.607920  1.024180  0.569605
#      two     0.875906 -2.211372  0.974466 -2.006747
#qux   one    -0.410001 -0.078638  0.545952 -1.219217
#      two    -1.226825  0.769804 -1.281247 -0.727707
      
      
print("", """
#(column->row), then mean rowwise 
#here axis=0 means columnwise , =1 mean rowwise
>>> df.stack().mean(axis=1).unstack() 
""",
df.stack().mean(axis=1).unstack(),
sep="\n")
# animal             cat       dog
# first second                    
# bar   one    -0.155347  1.685445
#       two     0.130479  0.557070
# baz   one     0.271419 -0.006733
#       two     0.526830 -1.312207
# foo   one    -0.194750  1.088763
#       two     0.925186 -2.109060
# qux   one     0.067976 -0.648927
#       two    -1.254036  0.021048

      
print("", """
# same result, another way
#In Group By: axis : int, default 0, axis=0 split rows , =1 split column
#level : int, level name, or sequence of such, default None
#If the axis is a MultiIndex (hierarchical), group by a particular level or levels
>>> df.groupby(level=1, axis=1).mean() 
#ie on 'animal', keeping same index ie agg on 'A','B' of same cat
""",
df.groupby(level=1, axis=1).mean(),
sep="\n")
 
# animal             cat       dog
# first second                    
# bar   one    -0.155347  1.685445
#       two     0.130479  0.557070
# baz   one     0.271419 -0.006733
#       two     0.526830 -1.312207
# foo   one    -0.194750  1.088763
#       two     0.925186 -2.109060
# qux   one     0.067976 -0.648927
#       two    -1.254036  0.021048
      
print("", """
#(column->row),
>>> df.stack().groupby(level=1).mean() #axis=0 , split row ie on 'second' 
""",
df.stack().groupby(level=1).mean(),
sep="\n")
#exp            A         B
#second                    
#one     0.071448  0.455513
#two    -0.424186 -0.204486

print("", """
#(row->column)
>>> df.mean()
""",
df.mean(),
sep="\n")
#exp  animal
#A    cat      -0.024948
#B    dog       0.458365
#     cat      -0.322612
#A    dog      -0.024222

print("", """
>>> df.mean().unstack(0)  #mean axis=0, column wise  , then move 0 row to column 
""",
df.mean().unstack(0),
sep="\n")
#exp            A         B
#animal                    
#cat     0.060843  0.018596
#dog    -0.413580  0.232430
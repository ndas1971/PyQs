from stanfordcorenlp import StanfordCoreNLP

print(" Using StanfordCoreNLP analyzer")
print("https://stanfordnlp.github.io/CoreNLP/download.html")
#print("requires 64 bit Java, set PATH=C:\Program Files\Java\jdk1.8.0_65\jre\bin;%PATH%")
def getValue(text):
    nlp = StanfordCoreNLP(r'C:\nltk_data\stanford-corenlp-full-2018-02-27')
    output = nlp.annotate(text, properties={
            #https://stanfordnlp.github.io/CoreNLP/annotators.html
            "annotators": "tokenize,ssplit,parse,sentiment",
            "outputFormat": "json",
            # Only split the sentence at End Of Line. We assume that this method only takes in one single sentence.
            "ssplit.eolonly": "true",
            # Setting enforceRequirements to skip some annotators and make the process faster
            "enforceRequirements": "false",
            'pipelineLanguage':'en'
        })
    # Only care about the result of the first sentence because 
    #we assume ,we only annotate a single sentence in this method.
    import json 
    obj  = json.loads(output)
    nlp.close()
    return int(obj['sentences'][0]['sentimentValue'])

texts = ['I like the service.', 
    'I absolutly love this service', 
    'I hate this service', 'I disgust this service']
    
print("higher the positive sentiments")
for t in texts:
    print(t, getValue(t))
    
    
print("\n\nUsing vader analyzer - another tool")
print("""
VADER (Valence Aware Dictionary and sEntiment Reasoner) is a lexicon 
and rule-based sentiment analysis tool that is specifically attuned 
to sentiments expressed in social media. 

VADER uses a combination of A sentiment lexicon is a list of lexical features 
(e.g., words) which are generally labelled according 
to their semantic orientation as either positive or negative.
""")

from nltk.sentiment.vader import SentimentIntensityAnalyzer

texts = ['I like the service.', 
    'I absolutly love this service', 
    'I hate this service', 'I disgust this service']

print("""
understanding OUTPUT
    Return a float for sentiment strength based on the input text. 
    The Positive, Negative and Neutral scores represent the proportion of text 
    that falls in these categories. 
    eg a sentence is rated as 67% Positive, 33% Neutral and 0% Negative. 
    Hence all these should add up to 1.
    The Compound score is a metric that calculates the sum of all the lexicon ratings 
    which have been normalized between -1(most extreme negative) 
    and +1 (most extreme positive).
""")
    
sid = SentimentIntensityAnalyzer() #Give a sentiment intensity score to sentences
for sentence in texts:
    print(sentence)
    ss = sid.polarity_scores(sentence) 
    for k in sorted(ss):
        print('{0}: {1}, '.format(k, ss[k]), end='')
    print()

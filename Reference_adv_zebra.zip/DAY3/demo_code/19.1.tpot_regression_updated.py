from tpot import TPOTClassifier

# Load data
#train, test, y_train, y_test   
from tpot import TPOTRegressor
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.metrics import *  

housing = load_boston()
#data_url = "http://lib.stat.cmu.edu/datasets/boston"
#data_url = "data/boston.txt"
#raw_df = pd.read_csv(data_url, sep="\s+", skiprows=22, header=None)
#data = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, :2]]) #spans into twor row 
#target = raw_df.values[1::2, 2]
        
X_train, X_test, y_train, y_test = train_test_split(housing.data, housing.target,
                                                    train_size=0.75, test_size=0.25)  


'''
class tpot.TPOTRegressor(generations=100, population_size=100,
                         offspring_size=None, mutation_rate=0.9,
                         crossover_rate=0.1,
                         scoring='neg_mean_squared_error', cv=5,
                         subsample=1.0, n_jobs=1,
                         max_time_mins=None, max_eval_time_mins=5,
                         random_state=None, config_dict=None,
                         template="RandomTree",
                         warm_start=False,
                         memory=None,
                         use_dask=False,
                         periodic_checkpoint_folder=None,
                         early_stop=None,
                         verbosity=0,
                         disable_update_check=False)
                          
Automated machine learning for supervised classification tasks.
The TPOT performs an intelligent search over machine learning pipelines 
that can contain supervised classification models, preprocessors, 
feature selection techniques, and any other estimator or transformer 
that follows the scikit-learn API. 

The TPOT will also search over the hyperparameters of all objects in the pipeline.
By default, TPOT will search over a broad range of supervised ML algorithms, 
transformers, and their parameters. 

Uses genetic programming, 
Genetic algorithms are commonly used to generate high-quality solutions 
to optimization and search problems by relying on bio-inspired operators 
such as mutation, crossover and selection(https://en.wikipedia.org/wiki/Genetic_algorithm)

check https://epistasislab.github.io/tpot/api/
for genetic programming configuration, Main parameters are 
    generations: int, optional (default=100)
        Number of iterations to the run pipeline optimization process. 
        Must be a positive number.
        Generally, TPOT will work better when you give it more generations 
        (and therefore time) to optimize the pipeline.
        TPOT will evaluate population_size + generations × offspring_size pipelines 
        in total. 
    population_size: int, optional (default=100)
        Number of individuals to retain in the genetic programming population 
        every generation. Must be a positive number.
        Generally, TPOT will work better when you give it more individuals 
        with which to optimize the pipeline. 

'''
#increase generations, and population_size, default both =100 
#but would take 5hrs
#TPOT also provides a warm_start parameter that lets you restart a TPOT run from where it left off.
print("""\n\n\nAtleast make generations=2 and population size=100
""")
tpot = TPOTRegressor(generations=2, population_size=100, verbosity=2)
tpot.fit(X_train, y_train)
print("Training score(neg MSE)", tpot.score(X_train, y_train))
print("Test score(neg MSE)", tpot.score(X_test, y_test))
print("Generate the code ...", 'tpot_boston_pipeline.py')
tpot.export('tpot_boston_pipeline.py')  #get the pipeline code 
predictions = tpot.predict(X_test)
print("Training score(R^2)", r2_score(y_train, tpot.predict(X_train)))
print("Test score(R^2)", r2_score(y_test, predictions))
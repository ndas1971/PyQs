print("""
More understanding - Clasification metrics 
Total case = N = a+b+c+d

        Actual True                             False 
Predicted 
True        a                                   b (false positive) - Type 1 error,alpha

False       c(false negative/alarm)(type-ii)    d

Accuracy = (a+d)/N 
precision = a/(a+b)
recall,sensitivity, probability of detection = a/(a+c)
specificity= d/(b+d)

Recall, Sensitivity 
    Percentage of positives that are successfully classified as positive
Specificity 
    Percentage of negatives that are successfully classified as negatives 

Since Classification model predicts probabilities of each class, 
there is some threashold required for calculating True and False. 
Hence for one threshold, we get one pair of Sensitivity and Specificity

Ideally we want to maximize both Sensitivity & Specificity. 
But this is not possible. 

Sometimes we want to be 100% sure on Predicted negatives, 
Specificity(eg Testing a medicine is good or poisonous ) ie false positive is zero,
(predicted positive is zero for condition negative)

sometimes we want to be 100% sure on Predicted positives, 
Sensitivity(eg Predicting a customers good or bad before issuing the loan ) 
ie false negative is zero (predicted negative is zero for condition positive)

The threshold is set based on business problem

Sensitivity and Specificity are inversely proportional to each other. 
So when we increase Sensitivity, Specificity decreases 
When we decrease the threshold, we get more positive values 
thus it increases the sensitivity and decreasing the specificity.

As FPR is 1 - specificity. So when we increase TPR(sensitivity), 
FPR also increases and vice versa
(FPR - Flase positive rate, TPR-true positive rate)

ROC Curve
Consider all the possible threshold values 
and the corresponding specificity and sensitivity rate
ROC(Receiver operating characteristic) curve is drawn by taking 
(1- specificity) on X-axis and sensitivity on Y- axis.
    

ROC and AUC
We want that curve to be far away from the straight line. 
Ideally, we want the area under the curve as high as possible. 
ie AUC. Area Under the Curve needs to be 1

ROC Curve Gives us an idea on the performance of the model 
under all possible values of threshold.

AUC=1.0, It is perfectly able to distinguish between positive class and negative class.

AUC=0.7, it means there is 70% chance that model will be able 
to distinguish between positive class and negative class.

AUC=0.5, model has no discrimination capacity to distinguish 
between positive class and negative class.

AUC=0.0, model is actually reciprocating the classes. 
It means, model is predicting negative class as a positive class and vice versa

""")

from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer

#Poisonous mushroom model 
#Display for each class, precision, recall and f1 



from yellowbrick.classifier import ConfusionMatrix, ROCAUC
from sklearn_pandas import gen_features

def draw_auc_confusion_matrix(X, y, model, features, labels):     
    # Create a new figure to draw the classification report on
    fig, (ax1,ax2) = plt.subplots(1,2)
    # Instantiate the classification model and visualizer
    visualizer = ConfusionMatrix( model, ax=ax1, classes=labels )
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.finalize()
    visualizer = ROCAUC(model, ax=ax2, classes=labels)
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.finalize()
    visualizer.show()

dataset = pd.read_csv('data/mushroom.csv')
names = [
    'class',
    'cap-shape',
    'cap-surface',
    'cap-color'
]
dataset.columns = names
features = ['cap-shape', 'cap-surface', 'cap-color']
target   = 'class'

X = dataset[features]
y = dataset[target]  
lenc = LabelEncoder().fit(y)
y = lenc.transform(y)

estimator = RandomForestClassifier()
#old code when ColumnTransformer was not present in sklearn 
##transformer for each column 
#feature_def = gen_features(
#    columns=features,
#    classes=[LabelEncoder]  #scikit_pandas can not handle OneHotEncoder after LabelEncoder as LabelEncoder expects 1D, oneHotEncoder expects 2D 
#)                           #Can use LabelBinarizer which is same as LabelEncoder, then OneHotEncoder
#X_mapper = DataFrameMapper(feature_def)
##Note features categorical, so, convert them to OneHotEncoding 
#model = Pipeline([
#    ('mapper', X_mapper),
#    ('hotencoder', OneHotEncoder()), #OneHotEncoder requires numerical categorical 
#    ('estimator', estimator)
#])
col_tran = ColumnTransformer(
    [
        ("one_hot",
            OneHotEncoder(),                
            features), #OneHotEncoder currently can take both numerical and categorical 
                
    ],
    remainder="drop",
)
model = Pipeline([('trx', col_tran),('estimator', estimator)])

draw_auc_confusion_matrix(X,y, model, features, lenc.classes_)

#Sklearn metrics 
model.fit(X,y)
y_pred = model.predict(X)
    
cr = classification_report(y,y_pred, 
    output_dict=True, target_names=lenc.classes_)
df = pd.DataFrame(cr)
df['micro'] = precision_recall_fscore_support(y, y_pred, average='micro')
df.fillna(len(y_pred), inplace=True)
print("Classification report\n",df.astype(np.float64).round(2))

df2 = pd.DataFrame(confusion_matrix(y, y_pred), 
    columns=["p-"+n for n in lenc.classes_],
    index=["a-"+n for n in lenc.classes_])
print("""
Confusion Matrix- summary
Note in practice, TP and FP for each class is computed and then averaged (macro/wt/micro)
Below is only possible for binary case 

""", df2)
print("""\nonly for binary cases
         predicted
         T       F 
         ----------
       T| tp    fn 
actual  |
       F| fp    tn
""")
tp,fn,fp,tn  = df2.iat[0,0],df2.iat[0,1], df2.iat[1,0],df2.iat[1,1]
print(f"""accuracy= (tp+tn)/all = {round((tp+tn)/(tp+fn+fp+tn), 2)}
precision= tp/(tp+fp) = {round(tp/(tp+fp), 2)}, precision of positive class
sensitivity= tp/(tp+fn) = {round(tp/(tp+fn), 2)}, recall of positive class
specificity= tn/(tn+fp) = {round(tn/(tn+fp), 2)}, recall of negative class
""")

print("""--------------------Details--------------------
Confusion metrics is made for each class's actual True and False 
Vs  Predicted True and Predicted False 

         predicted
         T       F 
         ----------
       T| tp    fn 
actual  |
       F| fp    tn


"macro" 
    calculates the mean of the binary metrics, giving equal weight to each class. 
    For example, for precision PrA=TpA/(TpA+FpA) for class A, ... for other classes 
    macro = (PrA+PrB+...)/No_of_classes, where PrA means Precision of class A
    
    In problems where infrequent classes are nonetheless important,     
    macro-averaging may be a means of highlighting their performance. 
    On the other hand, the assumption that all classes are equally important is often untrue, 
    such that macro-averaging will over-emphasize the typically low performance 
    on an infrequent class.

"weighted" 
    accounts for class imbalance by computing the average of binary metrics 
    in which each class's score is weighted by its presence in the true data sample.
    (recommended to use this)
    wt = (SupportA*PrA + .....)/Total_Support

"micro" 
    gives each sample-class pair an equal contribution to the overall metric 
    (except as a result of sample-weight).
    micro = (TpA + TpB + ....)/(TpA + FpA + TpB + FpB + ......)
    
    Rather than summing the metric per class, this sums the dividends and divisors 
    that make up the per-class metrics to calculate an overall quotient. 
    Micro-averaging may be preferred in multilabel settings, 
    including multiclass classification where a majority class is to be ignored.

""")

modules = [
'numpy','scipy',
'matplotlib',
'pandas',
'streamlit',
'plotly',
'sklearn',
'flask',
'keras',
'yellowbrick', 'tpot', 'xgboost', 'lightgbm', 'catboost', 'graphviz',
'torch', 'torchvision', 'torchaudio', 'jupyter', 'tornado', 
]

for m in modules:
    try:
        exec(f'import {m}')
    except Exception as ex:
        print(f"{m} - Exception: ", ex)
        continue
    try:
        exec(f'print("{m}", {m}.__version__)')
    except:
        #mostly __version__ is not found 
        pass 
    
    
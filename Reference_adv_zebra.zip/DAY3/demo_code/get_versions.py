modules = [
'numpy',
'matplotlib',
'pandas',
'streamlit',
'plotly',
'sklearn',
'flask',
'keras',
'yellowbrick', 'tpot', 'xgboost', 'lightgbm', 'catboost', 'graphviz',
'torch', 'torchvision', 'torchaudio', 'jupyter', 'tornado', 
]

for m in modules:
    exec(f'import {m}')
    exec(f'print("{m}", {m}.__version__)')
    
    
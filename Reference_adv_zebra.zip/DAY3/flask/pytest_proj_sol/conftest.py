import pytest 
import share_server as ss
import os.path 
import os, time
import subprocess as S 
import threading 

def get_app_filename():
    return os.path.join(ss.app.config['UPLOAD_FOLDER'], ss._filename )

def get_existing_text():
    fileexists = False 
    text = None 
    filename = get_app_filename()
    if os.path.exists(filename):
        fileexists = True
        with open(filename, "rt") as f:
            text = f.read()
    return (fileexists, text)
    
def save_existing_text(fileexists, text):
    filename = get_app_filename()
    if fileexists:
        with open(filename, "wt") as f:
            f.write(text)
    else:
        try:
            os.remove(filename)
        except:
            pass
            
def notepadfile_with_hello_it(new_text):
    #setup
    fileexists, text = get_existing_text()
    #replace with Hello 
    filename = get_app_filename()
    with open(filename, "wt") as f:
        f.write(new_text)
    yield new_text
    #teardown 
    save_existing_text(fileexists, text)         
            
            
def no_notepad_file_it():
    #setup
    filename = get_app_filename()
    fileexists, text = get_existing_text()
    #remove 
    if fileexists:
        os.remove(filename)
    yield ''
    #teardown 
    save_existing_text(fileexists, text)

@pytest.fixture(scope='function')
def notepadfile_with_hello(new_text="Hello"):
    yield from notepadfile_with_hello_it(new_text)

        
@pytest.fixture(scope='function')
def no_notepad_file():
    yield from no_notepad_file_it()
            
            
#creates multiple fixture with each value  and run dependent testcase that many times
@pytest.fixture(scope='function', params=["Hello", ''], ids=['hello', 'nofile'])
def notepadfile(request):
    if request.param :   #file case 
        yield from notepadfile_with_hello_it(request.param)
    else:       #no file case 
        yield from no_notepad_file_it()
        

#Write text fixture 
@pytest.fixture(scope='function')
def prepare_write_notepad():
    #setup
    fileexists, text = get_existing_text()
    yield "Done"
    #teardown 
    save_existing_text(fileexists, text)  
    
#Write text fixture 
@pytest.fixture(scope='module')
def prepare_server():    
    th = threading.Thread(target=lambda : ss.app.run(), daemon=True)
    th.start()
    time.sleep(1)
    yield "Done"
    #th.join()
    
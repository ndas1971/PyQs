from flask import Flask, request, jsonify, render_template, make_response, g, redirect, url_for
import json , os , re
import logging

app = Flask(__name__)
app.logger.setLevel(logging.INFO)
UPLOAD_FOLDER = os.path.join(app.root_path,'static')
# create the folder next to static 
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
_filename = "notepad.txt"

def get_text():
    try:
        with open(os.path.join(app.config['UPLOAD_FOLDER'], _filename ), "rt") as f:
            text = f.read()
    except:
        text = ''
    return text.replace("\r\n","\n").strip() 
    
def write_text(text=''):
    text = text.strip().replace("\r\n","\n")
    with open(os.path.join(app.config['UPLOAD_FOLDER'], _filename ), "wt") as f:
        f.write(text)

@app.route("/updatefortoday", methods=['GET','POST'])
def update():
    if request.method == 'POST':
        text = request.form.get('notepad', '')
        #app.logger.info(f"Text=<{text.__repr__()}><{text}>")
        write_text(text)
    else:
        text = get_text()
    return render_template("submit.html", text=text)

@app.route("/share", methods=['GET'])#
def share():
    text = get_text()
    return render_template("share.html", text=text)    
    
if __name__ == '__main__':  # pragma: no cover
    print("""
    Open one browser tab - this is for updating 
        http://localhost:5000/updatefortoday
    Open another browser tab - this is for sharing 
        http://localhost:5000/share
    """)
    app.run()    
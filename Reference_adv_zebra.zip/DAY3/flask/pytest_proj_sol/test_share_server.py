#pytest -s -v -m "not addl" test_share_server.py
#pytest --cov=share_server --cov-report term-missing test_share_server.py

import share_server as ss
import pytest
import requests 
from bs4 import BeautifulSoup

@pytest.mark.addl 
def test_get_text_hello(notepadfile_with_hello):
    text = ss.get_text()
    print(f"test_get_text_nofile=<{text}>")
    assert text == notepadfile_with_hello
    
@pytest.mark.addl 
def test_get_text_nofile(no_notepad_file):
    text = ss.get_text()
    print(f"test_get_text_nofile=<{text}>")
    assert text == no_notepad_file
    
def test_get_text(notepadfile):
    text = ss.get_text()
    print(f"test_get_text_nofile=<{text}>")
    assert text == notepadfile
    
#in parametrize, if you have multiple argument, you pass tuple in each element of list 
#for one, pass single element 
#indirect=True , means notepadfile argument is a fixture 
#and that  fixture is called with request.param with "hello" and '' 
#https://docs.pytest.org/en/7.1.x/reference/reference.html#request
@pytest.mark.parametrize("notepadfile",["hello", '' ],ids=["hello", "nofile"], indirect=True)
def testMany(notepadfile):
    text = ss.get_text()
    assert text == notepadfile
    
#prepare_write_notepad fixture would get request.param from 1st arg of tuple 
@pytest.mark.parametrize("prepare_write_notepad,new_text",[('',"hello"), ('','') ],ids=["hello", "empty"], indirect=['prepare_write_notepad'])
def test_write_text(prepare_write_notepad, new_text):
    ss.write_text("Hello")
    text = ss.get_text()
    assert text == "Hello"
    
    
def test_get_update_data(prepare_server, notepadfile_with_hello):
    url_get = "http://localhost:5000/updatefortoday"
    expected_text = notepadfile_with_hello
    with requests.Session() as s:       
        r = s.get(url_get)
        sp = BeautifulSoup(r.text, 'html.parser')
        for t in sp.select("#notepad"):
            assert t.text == expected_text
    
def test_post_data(prepare_server, no_notepad_file):
    url_post = "http://localhost:5000/updatefortoday"
    url_get = "http://localhost:5000/share"
    expected_text = "Hello Hello"
    with requests.Session() as s:
        data = {'notepad' :  expected_text}
        r = s.post(url_post, data)
        assert r.status_code == 200
        r = s.get(url_get)
        sp = BeautifulSoup(r.text, 'html.parser')
        for t in sp.select("#checkdata"):
            assert t.text == expected_text
        
    
    
#/usr/bin/sh
#usage ./backup.sh F:/backUp/

#cp -r -v -f  C:/scala/lib  ${1}/scala-lib
cp -r -v -f  D:/Desktop  ${1}
cp -r -v -f  D:/Moni  ${1}
#cp -r -v -f  D:/software  ${1}




#cp -r -v -f  C:/Users/Das/.conscript  ${1}/user-das
#cp -r -v -f  C:/Users/Das/.gem  ${1}/user-das
#cp -r -v -f  C:/Users/Das/bin  ${1}/user-das
#cp -r -v -f  C:/Users/Das/pip  ${1}/user-das
#cp -r -v -f  C:/Users/Das/.gfclient  ${1}/user-das

#cp -r -v -f  C:/Users/Das/.ivy2  ${1}/user-das
#cp -r -v -f  C:/Users/Das/.m2  ${1}/user-das
#cp -r -v -f  C:/Users/Das/.sbt  ${1}/user-das

#cp -r -v -f  C:/Training  ${1}
#cp -r -v -f  C:/cygwin64  ${1}


from flask import Flask 
#pip install flask --upgrade 


app = Flask(__name__)  

@app.route("/")    #http://localhost:5000/
def home():
    #Content-Type : text/html
    return """
    <html>
    <head>
        <title>My Webserver</title>
        <style>
        #some1 {
            color: red;
        }
        </style>
    </head>
    <body>
    <h1 class="some" id="some1">Hello there!!!</h1>
    <h1 class="some" id="some2">Hello there!!!</h1>
    </body>
    </html>
    """
#Content-Type, status_code, URLEndpoint,payload
from flask import request, render_template 
import os 

@app.route("/env", methods=['GET', 'POST'])  #http://localhost:5000/env
def env():
    if request.method == "POST":    #request is flask object , represents HTTP request
        envp = request.form.get("envp", "all").upper()  #request.form is dict 
        env_dict = os.environ 
        if os.environ.get(envp, "notfound") != "notfound":
            env_dict = {envp: os.environ[envp]}
        return render_template("env.html", envs = env_dict) 
        # renders templates/env.html with variable envs 
    else:
        #name attrs of input, which would be key in request.form 
        return """
    <html>
    <head>
        <title>Env Var</title>
    </head>
    <body>
    <form method="post" action="/env">
    Give env var:<input  type="text" name="envp" value="ALL" />
    <input value="Submit" type="submit"  />
    </form>
    </body>
    </html>        
        """


@app.route("/favicon.ico")  #http://localhost:5000/favicon.ico
def favicon():
    return app.send_static_file('favicon.ico')  #serves from /static folder 

if __name__ == '__main__':
    #http://localhost:5000
    app.run()

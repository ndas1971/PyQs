###Introduction to Object-Oriented Programming  
import functools
@functools.total_ordering
class MyInt:
    def __init__(self, v):
        self.value = v 
    def __add__(self,other):
        z = self.value + other.value 
        return MyInt(z) 
    def __str__(self):
        return "MyInt(%d)" % (self.value,)
    def __eq__(self,other):
        return self.value == other.value 
    def __gt__(self,other):
        return self.value > other.value 
    def __call__(self,p):
        return self.value + p
        
if __name__ == '__main__:
    a = MyInt(2)
    b = MyInt(3)
    c = a + b 
    print(c)
    
##HandsOn - usage 
from pkg.MyInt import Fraction
a = Fraction(1,2)
b = Fraction(1,2)
c = a+b 
print(c) #Fraction(4,4)
##Solution 
class Fraction:
    def __init__(self, n,d):
        self.n = n 
        self.d = d
    def __add__(self,other):
        n = self.n * other.d + other.n * self.d 
        d = self.d * other.d 
        return Fraction(n,d) 
    def __str__(self):
        return "Fraction(%d,%d)" % (self.n,self.d)
 
###Deep Dive into Object-Oriented Programming
#  Class Example: User, PreUser, BankAcount
Bank User has name and account. There are two types of Users
Normal and privileged user . There are two types of privileged
users, Gold and Silver. Gold has cashback of 5% and Silver has 
cashback of 3% of expenditure when they spend any cash 

#Workshop-code 

class NotEnoughBalance(Exception):
    pass

class BankAccount:
    def __init__(self, initAmount):
        self.amount = initAmount
    def transact(self, amount):
        if self.amount +amount < 0 :
            raise NotEnoughBalance("Not possible")
        self.amount = self.amount + amount
    def __str__(self):
        return "BankAccount("+str(self.amount)+")"
        
from abc import ABCMeta, abstractmethod
class BankUser(metaclass=ABCMeta):
    how_many_users = {'TotalUsers': 0}     #BankUser.how_many_users
    def __init__(self, name, initAmount):
        self.name = name 
        self.account = BankAccount(initAmount)
        self.update_user_types()
    @property  # get
    def balance(self):
        return self.account.amount        
    @balance.setter  #setting
    def balance(self, amount):
        #self.account.amount = amount
        raise NotImplementedError("can not set via property, use transact method")
    def update_user_types(self):
        t = self.getUserType()
        if t in BankUser.how_many_users:
            BankUser.how_many_users[t] += 1
        else:
            BankUser.how_many_users[t] = 1
        BankUser.how_many_users['TotalUsers'] += 1        
    def __str__(self):
        return "%s(%s,%s)" % (self.getUserType(), self.name, str(self.balance))
    @abstractmethod
    def getCashbackPercentage(self):
        return 0
    @abstractmethod
    def getUserType(self):
        pass
    @classmethod 
    def howMany(cls):
        return cls.how_many_users    
    def transact(self, amount):
        try:
            self.account.transact(amount)
            if amount < 0:
                cashback = self.getCashbackPercentage() * abs(amount)
                self.account.transact(cashback)
        except NotEnoughBalance as ex:
            print(str(ex), "Name:", self.name, "amount:", amount)

class NormalUser(BankUser):
    def getCashbackPercentage(self):
        return super().getCashbackPercentage()
    def getUserType(self):
        return "NormalUser"

class GoldUser(BankUser):
    def getCashbackPercentage(self):
        return 0.05     
    def getUserType(self):
        return "GoldUser"

class SilverUser(BankUser):
    def getCashbackPercentage(self):
        return 0.03    
    def getUserType(self):
        return "SilverUser"        

if __name__ == '__main__':   # pragma: no cover
    users = [GoldUser("Gold", 100),
             SilverUser("Silver", 100),
             NormalUser("Normal",100)]
    amounts = [100, -200, 300, -400, 400]
    for u in users:
        for am in amounts:
            u.transact(am)
        #u.balance = 500
        print(u, u.balance)
    print(BankUser.howMany())
    
    

###Using PyTest 
#Any unexpected error, remove .cache file 
$ pip install pytest-cov -i JPMC_INTERNAL_SERVER

$ pytest -v classTest 

$ pytest --cov=userh test_userh.py   
(note --cov=pkgDir  ie cov can take package dir 
also last arg can be dir eg check from pytest --help)

$ pytest --cov=pkgDir testdir

#check coverage of 'class/pkg' by running all tests under class/
Check https://pytest-cov.readthedocs.io/en/latest/reporting.html

--cov-report=html for html report 
eg to get line nos which are missed
--cov-report term-missing
#anotated source code check userh/classes.py,cover 
#where ! means missed line 
--cov-report annotate 
It uses internally coverage.py, check the meaning 
https://coverage.readthedocs.io/en/latest/cmd.html#text-annotation-coverage-annotate

Skipping 
https://coverage.readthedocs.io/en/latest/excluding.html
eg use # pragma: no cover to remove some code 
if __name__ == '__main__':  # pragma: no cover

$ pytest --cov=userh --cov-report term-missing test_user.py

        
'''
Lots of options 
$ pytest --help 

$ pytest -v test_userh.py
#check default markers
pytest --markers  
#check default fixtures 
pytest --fixtures


To check scope 
https://docs.pytest.org/en/stable/fixture.html#fixture-scopes

#to output of  stdout
$ pytest -v -s test_userh.py

#to check builtin fixture 
 
         
#For running marker
pytest -v -m addl
pytest -v -m "not addl"

#request is optional and it contains few requestng functions 
https://docs.pytest.org/en/stable/fixture.html#fixtures-can-introspect-the-requesting-test-context
'''
#pytest.ini 
[pytest]
markers = 
    addl: Addl testcases 
    
#conftest.py 
from userh import * 
import pytest 

@pytest.fixture(scope='module')
def silver(request):  # request is optional, 
    a = SilverUser("Gold",  BankAccount(100))
    yield a   # use return, then no teardown code 
    print("shutdown code")
  
@pytest.fixture(scope='module')
def amounts(request):
    a = [ 100, -200, 300, -400, 400]
    yield a

@pytest.fixture(scope='module')
def normal(request):
    a = NormalUser("Gold",  BankAccount(100))
    yield a
    
    
#test_user.py 
from userh import *
import pytest

class TestUser:
    def test_gold(self, amounts):
        u = GoldUser("Gold",  BankAccount(100))
        for am in amounts:
            u.transact(am)
        assert u.balance == 710

@pytest.mark.addl     
def test_normal(normal, amounts):   
    for am in amounts:
            normal.transact(am)
    assert normal.balance == 700

@pytest.mark.addl     
def test_silver(silver, amounts):   
    for am in amounts:
            silver.transact(am)
    assert silver.balance == 704
    
##Advanced 
If you put print inside test, it would not print as it captures 
pytest -s            # disable all capturing


pytest -k stringexpr # only run tests with names that match the
                     # "stringExpression", e.g. "MyClass and not method"
                     # will select TestMyClass.test_something
                     # but not TestMyClass.test_method_simple
pytest test_mod.py::test_func # only run tests that match the "node ID",
                              # e.g. "test_mod.py::test_func" will select
                              # only test_func in test_mod.py
pytest test_mod.py::TestClass::test_method # run a single method in
                                             # a single class
                                             
#string expr could be
"stringexpr"
"not stringexpr"
"stringexpr1 and stringexpr2"
"stringexpr1 and not stringexpr2"
"stringexpr1 or stringexpr2"
                               
#Selecting test based on id 
#pytest -v -k "silver" test_userh.py 
#pytest -v -k "not silver" test_userh.py 
#pytest -v -k "silver or another" test_userh.py 
#pytest --collect-only  test_userh.py 
#pytest -v test_userh.py::testMany

@pytest.mark.parametrize("user,transactions,result",[
    (SilverUser("Silver", 100) , [100, -200, 300, -400, 400] , 706),
    pytest.param(SilverUser("Silver", 100) , [100, -200, 300, -400, 400] , 706, marks=pytest.mark.addl),
    ],
    ids=["silver", "another"]
)
def testMany(user,transactions,result):
    for am in transactions:
        user.transact(am)
    assert user.balance == result
    
#Monkey patching  
import userh
def test_monkey(request, monkeypatch):
    class DummyUser:
        def __init__(self, name, initAmount):
            self.name = name 
            self.amount = initAmount
        def transact(self, amount):
            self.amount += amount 
    monkeypatch.setattr(userh, "SilverUser", DummyUser)
    sv = userh.SilverUser("ABC", 100)
    sv.transact(100)
    assert  sv.account.amount == 200   
    
#Can be put in conftest. But remember monkeypatch is function scoped 
#conftest.py
class DummyUser:
    def __init__(self, name, initAmount):
        self.name = name 
        self.amount = initAmount
    def transact(self, amount):
        self.amount += amount 
            
import userh         
@pytest.fixture(scope='function')
def puserh(monkeypatch):
    #comment out this to see original 
    monkeypatch.setattr(userh, "SilverUser", DummyUser)
    return userh
         
#test 
def test_monkey(puserh):
    sv = puserh.SilverUser("ABC", 100)
    sv.transact(100)
    assert  sv.account.amount == 200       
         
###Pytest reference -- ADVANCED 
monkeypatch
    The returned ``monkeypatch`` fixture provides these
    helper methods to modify objects, dictionaries or os.environ::

    monkeypatch.setattr(obj, name, value, raising=True)
    monkeypatch.delattr(obj, name, raising=True)
    monkeypatch.setitem(mapping, name, value)
    monkeypatch.delitem(obj, name, raising=True)
    monkeypatch.setenv(name, value, prepend=False)
    monkeypatch.delenv(name, value, raising=True)
    monkeypatch.syspath_prepend(path)
    monkeypatch.chdir(path)

    All modifications will be undone after the requesting
    test function or fixture has finished. The ``raising``
    parameter determines if a KeyError or AttributeError
    will be raised if the set/deletion operation has no target.


#to pretend that os.expanduser returns a certain directory, 
#use monkeypatch(a builtin fixture).setattr()

# content of test_module.py
import os.path
def getssh(): # pseudo application code
    return os.path.join(os.path.expanduser("~admin"), '.ssh')

def test_mytest(monkeypatch):
    def mockreturn(path):
        return '/abc'
    monkeypatch.setattr(os.path, 'expanduser', mockreturn) #module_name, method_name, new_method_name 
    x = getssh()
    assert x == '/abc/.ssh'
      
      
#Example - preventing "requests" library  from remote operations
#delete the method request.session.Session.request 
#so that any attempts within tests to create http requests will fail

# content of conftest.py
import pytest
@pytest.fixture(autouse=True)  #automatically activate 
def no_requests(monkeypatch):
    monkeypatch.delattr("requests.sessions.Session.request")        


##Fixture details 
#(return a) decorator to mark a fixture factory function.
pytest.fixture(scope='function', params=None, autouse=False, ids=None, name=None)
    scope – the scope for which this fixture is shared, 
        one of 'function' (default), 'class', 'module' 'package' or 'session'.
    params – an optional list of parameters which will cause multiple invocations of the fixture function 
        and all of the tests using it. 
        each of params are accessed by request.param inside fixture function
    autouse – if True, the fixture func is activated for all tests that can see it. 
        If False (the default) then an explicit reference is needed to activate the fixture.
    ids – list of string ids each corresponding to the params 
        so that they are part of the test id           
    name – the name of the fixture. 
       This defaults to the name of the decorated function.
       
##Fixture function can accept the 'request' object (instance of FixtureRequest)
#to introspect the test function, class or module context  

#default fixture 
#cache, capsys,capfd,doctest_namespace,pytestconfig,record_xml_property,monkeypatch,recwarn,tmpdir_factory,tmpdir
$ pytest --fixtures


#Example - to read an optional server URL from the test module 

# content of conftest.py
import pytest
import smtplib

@pytest.fixture(scope="module")
def smtp(request):
    server = getattr(request.module, "smtpserver", "smtp.gmail.com") #get 'smtpserver' of module 
    smtp = smtplib.SMTP(server)
    yield smtp
    print ("finalizing %s (%s)" % (smtp, server))
    smtp.close()


# content of test_anothersmtp.py
smtpserver = "mail.python.org"              # will be read by smtp fixture
def test_showhelo(smtp):
    assert 0, smtp.helo()

#Running it:
$ pytest -qq --tb=short test_anothersmtp.py     


##API 
class FixtureRequest
https://docs.pytest.org/en/stable/reference.html#pytest.FixtureRequest

Configuration 
https://docs.pytest.org/en/stable/customize.html


##Skipping test functions
@pytest.mark.skip(reason="no way of currently testing this")
def test_the_unknown():
    pass

#OR 
def test_function():
    if not valid_config():
        pytest.skip("unsupported configuration")

#skip the whole module 
import sys
import pytest

if not sys.platform.startswith("win"):
    pytest.skip("skipping windows-only tests", allow_module_level=True)



#skipif - based on condition , True means skips 
If multiple skipif decorators are applied to a test function, 
it will be skipped if any of the skip conditions is true.
#Example 
import sys

@pytest.mark.skipif(sys.version_info < (3, 7), reason="requires python3.7 or higher")
def test_function():
    ...

#share skipif markers between modules

# content of test_mymodule.py
import mymodule

minversion = pytest.mark.skipif(
    mymodule.__versioninfo__ < (1, 1), reason="at least mymodule-1.1 required"
)


@minversion
def test_function():
    ...


# test_myothermodule.py
from test_mymodule import minversion


@minversion
def test_anotherfunction():
    ...

#use the skipif marker (as any other marker) on classes:

@pytest.mark.skipif(sys.platform == "win32", reason="does not run on windows")
class TestPosixCalls:
    def test_function(self):
        "will not be setup or run under 'win32' platform"


#to skip all test functions of a module, use the pytestmark global:

# test_module.py
pytestmark = pytest.mark.skipif(...)



#Skipping on a missing import dependency
#using pytest.importorskip at module level, within a test, or test setup function.

docutils = pytest.importorskip("docutils")

#If docutils cannot be imported here, this will lead to a skip outcome of the test. 
#You can also skip based on the version number of a library(uses __version__):

docutils = pytest.importorskip("docutils", minversion="0.3")

##XFail: mark test functions as expected to fail

@pytest.mark.xfail
def test_function():
    ...

#OR 
def test_function():
    if not valid_config():
        pytest.xfail("failing configuration (but should work)")

def test_function2():
    import slow_module

    if slow_module.slow_function():
        pytest.xfail("slow_module taking too long")

#If a test is only expected to fail under a certain condition, 
#you can pass that condition as the first parameter (also as string), True means fails 

@pytest.mark.xfail(sys.platform == "win32", reason="bug in a 3rd party library")
def test_function():
    ...

#You can specify the motive of an expected failure with the reason parameter:

@pytest.mark.xfail(reason="known parser issue")
def test_function():
    ...

#raises parameter
If you want to be more specific as to why the test is failing, you can specify a single exception, 
or a tuple of exceptions, in the raises argument.
Then the test will be reported as a regular failure if it fails with an exception not mentioned in raises.

@pytest.mark.xfail(raises=RuntimeError)
def test_function():
    ...

#run parameter
If a test should be marked as xfail and reported as such 
but should not be even executed, use the run parameter as False:

@pytest.mark.xfail(run=False)
def test_function():
    ...
    
#Testing exception - pytest.raises(ExpectedException, func, *args, **kwargs)

import pytest


def test_zero_division():
    with pytest.raises(ZeroDivisionError):
        1 / 0

#To access actual exception info 
def test_recursion_depth():
    with pytest.raises(RuntimeError) as excinfo: #ExceptionInfo instance having .type, .value and .traceback

        def f():
            f()

        f()
    assert "maximum recursion" in str(excinfo.value)

#or using regexp
import pytest


def myfunc():
    raise ValueError("Exception 123 raised")


def test_match():
    with pytest.raises(ValueError, match=r".* 123 .*"):
        myfunc()


#Skip/xfail with parametrize

import pytest


@pytest.mark.parametrize(
    ("n", "expected"),
    [
        (1, 2),
        pytest.param(1, 0, marks=pytest.mark.xfail),
        pytest.param(1, 3, marks=pytest.mark.xfail(reason="some bug")),
        (2, 3),
        (3, 4),
        (4, 5),
        pytest.param(
            10, 11, marks=pytest.mark.skipif(sys.version_info >= (3, 0), reason="py2k")
        ),
    ],
)
def test_increment(n, expected):
    assert n + 1 == expected

##Customizing test collection
You can easily instruct pytest to discover tests from every Python file:

# content of pytest.ini
[pytest]
python_files = *.py

However, many projects will have a setup.py which they don’t want to be imported. 
Moreover, there may files only importable by a specific python version. 

# content of conftest.py
import sys

collect_ignore = ["setup.py"]
if sys.version_info[0] > 2:
    collect_ignore.append("pkg/module_py2.py")


Its also possible to ignore files based on Unix shell-style wildcards 
by adding patterns to collect_ignore_glob.

The following example conftest.py ignores the file setup.py 
and in addition all files that end with *_py2.py when executed with a Python 3 interpreter:

# content of conftest.py
import sys

collect_ignore = ["setup.py"]
if sys.version_info[0] > 2:
    collect_ignore_glob = ["*_py2.py"]

Since Pytest 2.6, users can prevent pytest from discovering classes that start with Test 
by setting a boolean __test__ attribute to False.

# Will not be discovered as a test
class TestClass:
    __test__ = False

    
###OOP - Design Pattern and other concepts - ADANCED 
##Unerstanding __new__ 
# __new__ gets called when instantiation with 'cls' , 
#must call object.__new__ to get a instance, and should return it, Then 
#__new__ calls __init__ automatically 

class Singletone:
    class __Impl:
        def __init__(self):
            self.val = None
        def __str__(self):
            return str(self.val)
    __instance = None               #__ means names are mangled 
    def __new__(cls): 				#it's a class method , without any @classmethod 
        if not cls.__instance:
            cls.__instance = cls.__Impl()
        return cls.__instance  #calls __init__
        #here it calls Singleton.__init__(cls.__instance)
    def __getattr__(self, name):     #for unknown attribute 
        return getattr(self.__instance, name)
    def __setattr__(self, name):    #for all 
        return setattr(self.__instance, name)

if __name__ == '__main__': 
    x = Singletone()
    x.val = 'sausage'
    print(x)
    y = Singletone()
    y.val = 'eggs'
    print(y)
    z = Singletone()
    z.val = 'spam'
    print(z)  #spam 
    print(x)  #spam 
    print(y)  #spam 

##Name namgling - Inside can access as __name , but outside class name prefixed 
class Student:
    def __init__(self, name):
        self.__name = name
    def displayName(self):
        print(self.__name)

s1 = Student("ABC")
s1.displayName()
  
# Raises an error
print(s1.__name) 
dir(s1) #the __name is actually made as _Student__name 

##Understanding getattr 
#name is string , value is of actual type 
def __getattr__(self, name): 		# On undefined attribute fetch [obj.name], for old and new style
def __getattribute__(self, name): 	# On all attribute fetch [obj.name], new style
def __setattr__(self, name, value): # On all attribute assignment [obj.name=value]
def __delattr__(self, name): 		# On all attribute deletion [del obj.name]

##builtins method to access above 
getattr(object, name[, default]) -> value  # object.name 
setattr(object, name, value)               # object.name = value
delattr(object, name)					   # del object.name

##Class -Attribute fetching - WARNING 

class Example 
    def __getattr__(self, attrname): 	
            if attrname == 'age':
                return 40
            else:
                raise AttributeError(attrname)

    def __setattr__(self, attr, value):  			# for all setting
            if attr == 'age':
                self.__dict__[attr] = value + 10 	# does not include __slot__
            else:
                raise AttributeError(attr + ' not allowed')

    def __getattribute__(self, name):
            x = object.__getattribute__(self, name)   # Must use object. else infine loop


#Note following would loops infinitely in __setattr__
self.age = value + 10 			# Loops
setattr(self, attr, value + 10) # Loops (attr is 'age')

#use below in __setattr__
self.__dict__[attr] = value + 10 			# OK: doesn't loop
object.__setattr__(self, attr, value + 10) 	# OK: doesn't loop (new-style only)
		
#To be inclusive of slot and properties, use always object.__setattr__

##Slots 
In Python every class can have instance attributes. 
By default Python uses a dict to store an object’s instance attributes
However, for small classes with known attributes it might be a bottleneck. 
The dict wastes a lot of RAM. 
Use  __slots__ to tell Python not to use a dict, 
and only allocate space for a fixed set of attributes.

class GFG(object):
    __slots__=['a', 'b']
    def __init__(self, *args, **kwargs):
        self.a = 1
        self.b = 2
  
instance = GFG()
print(instance.__dict__) # error 
print(instance.a) # 1 



###Introduction to MetaProgramming -- ADVANCED 
when Class is defined, 
Python calls Meta Class's(default is type) __new__(meta as first arg)  for allocation 
(default implemention) type's __new__ calls Meta Class's __init__(class as first arg) 
to init the class


When a class instance is created, Py calls metaclass's(default is type) __call__
(default implemention)type's __call__ calls class's __new__(class as first arg)
(default implemention)class's __new__ calls object's __new__(class as first arg)
(default implemention)object's __new__ calls class's __init__(instance as first arg)


#m is metaclass as inherited from type 
class m(type):
	def __new__(meta, c, s, cd):  #meta, classname, supers, classdict #at class definition
		print("meta.__new__")
		print(meta, c, s, cd)
		return type.__new__(meta,c,s,cd)  #calls meta.__init__
	def __call__(*args, **kargs):    #calls at instance creation
		print("meta.__call__")
		return type.__call__(*args, **kargs)
	def __init__ (c, cn, s, cd):   #class, classname, supers, classdict #class definition
		print("meta.__init__")
		print(c,cn,s,cd)
		return type.__init__(c,cn,s,cd)
	
	
class A(metaclass=m):   #object py2.x
	#__metaclass__ = m  #py2.x
	def __new__(cls):           #called at instance creation
		print("A's new")
		return object.__new__(cls)  #calls self.__init__
	def __init__(self):
		print("A's init")
	def __call__(self, *args, **kargs):
		print("A's call")


#above instantly prints below
#meta.__new__
#<class '__main__.m'> A () {'__module__': '__main__', '__qualname__': 'A'} #meta, classname, supers, classdict
#meta.__init__
#<class '__main__.A'> A () {'__module__': '__main__', '__qualname__': 'A'} #class, classname, supers, classdict 

a = A()
#prints below
#meta.__call__
#A's new
#A's init

a()
#prints below
#A's call

##Example - Meta programming Usage
#Introducing a new function for all classes 

def func4(self): return self.value * 4


class Extender(type):
	def __new__(meta, classname, supers, classdict):
		classdict['func4'] = func4					#adding func4 method
		return type.__new__(meta, classname, supers, classdict)



class A(metaclass=Extender):
	def __init__(self, value): self.value = value
	def func2(self): return self.value * 2

	
a = A(1)
a.func4()


##Example Usage- Tracing, Usage - Adding tracing to all functions
def trace(f):
	def inner(*args, **kargs):
		print("-->" + f.__name__)
		res = f(*args, **kargs)
		print("<--" + f.__name__)
		return res
	return inner

import types

class Tracing(type):
	def __new__(meta, classname, supers, classdict):
		classdict = {k:(trace(v) if type(v) is types.FunctionType and v.__name__.startswith("fun") else v ) for k,v in classdict.items()}
		return type.__new__(meta, classname, supers, classdict)



class B(metaclass=Tracing):
	def __init__(self, value): self.value = value
	def func(self): return self.value * 2


>>> b = B(2)
>>> b.func()
-->func
<--func

###XML 
import xml.etree.ElementTree as ET
tr = ET.parse(r"data\example.xml")
#Or directly from a string:
root = ET.fromstring(country_data_as_string)

root = tr.getroot()
root.tag
root.attrib
root.text
nn = root.findall("./country/rank")
[n.text  for n in nn]

res = []
for n in nn:
    res.append(n.text)

[int(n.text)  for n in nn]

nn = root.findall("./country")
[n.attrib['name']  for n in nn]

res = []
for n in nn:
    res.append(n.attrib['name'])
    
#other 
#Give me all country names along with it's neighbors
{ c.attrib["name"] : [
    n.attrib["name"] for n in c.findall(".//neighbor")]
  for c in root_element.findall(".//country")}


# Top-level elements
root.findall(".")
root.findall("./country/neighbor")
# Nodes with name='Singapore' that have a 'year' child
root.findall(".//year/..[@name='Singapore']")
# 'year' nodes that are children of nodes with name='Singapore'
root.findall(".//*[@name='Singapore']/year")
# All 'neighbor' nodes that are the second child of their parent
root.findall(".//neighbor[2]")

#Modifying an XML File
#to update attribute,  use Element.set()
#to update text, just assign to text 
import xml.etree.ElementTree as ET
tree = ET.parse('example.xml')
root = tree.getroot()

for rank in root.iter('rank'):
    new_rank = int(rank.text) + 1
    rank.text = str(new_rank)
    rank.set('updated', 'yes')

tree.write('output.xml')

#Creation
#Element(tag, attrib={})
#SubElement(parent, tag, attrib={})
import xml.etree.ElementTree as ET
a = ET.Element('a')
b = ET.SubElement(a, 'b', attrib=dict(count="1")) #attrib must be string 
b.text = "hello"
ET.dump(a)

>>> #with NS
>>> tr1 = ET.parse(r"data\example1.xml")
>>> root1 = tr1.getroot()
>>> root1.tag
'{http://people.example.com}actors'
>>> ns = dict(ns="http://people.example.com")
>>> ns1 = dict(ns1="http://characters.example.com")
>>> nn = root1.findall(".//ns1:character", ns1)
>>> nn
>>> [n.text for n in nn]
['Lancelot', 'Archie Leach', 'Sir Robin', 'Gunther', 'Commander Clement']
>>> #Give actor name and his/her characters
>>> { actor.findall(".//ns:name", ns)[0].text : [
...    char.text for char in actor.findall(".//ns1:character", ns1)]
...  for actor in root1.findall(".//ns:actor", ns)}
{'John Cleese': ['Lancelot', 'Archie Leach'], 'Eric Idle': ['Sir Robin', 'Gunt
her', 'Commander Clement']}


#for example rest API 
url = "http://weatherapi1971.pythonanywhere.com/query.yahooapis.com/v1/public/yql"
p = {'q': "select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='mumbai') and u='c'",
         "format" : "xml"}
import requests 
r = requests.get(url, params=p)

#Now parse
import xml.etree.ElementTree as ET
obj = ET.fromstring(r.text)
#prettyprint 
rough_string = ET.tostring(obj, 'utf-8')
import xml.dom.minidom as dom
xp = dom.parseString(rough_string)
print(xp.toprettyxml(indent="\t"))


ns = dict(ns1="http://xml.weather.yahoo.com/ns/rss/1.0")
{e.attrib['date']: e.attrib['low']  for e in obj.findall('.//ns1:forecast', ns) }


###Json 
import json
with open(r"data/example.json", "rt") as f:
    obj = json.load(f)

[emp['empId']   for emp in obj]

res = []
for emp in obj:
    res.append(emp['empId'])

[emp['details']['firstName'] + emp['details']['lastName']   for emp in obj]

for emp in obj:
    res.append(emp['details']['firstName'] + emp['details']['lastName'])

#other 
#Give me all office phone nos
[ ph["number"] for emp in obj
     for ph in emp['details']['phoneNumbers']
       if ph['type'] == 'office']

{ ph["number"] for emp in obj
     for ph in emp['details']['phoneNumbers']
       if ph['type'] == 'office'}

#OR
o = set()
for emp in obj:
    for ph in emp['details']['phoneNumbers']:
            if ph['type'] == 'office':
                    o.add(ph["number"])


>>> with open(r"data\weather.json", "rt") as f:
...     obj = json.load(f)
...
>>> type(obj)
<class 'dict'>
>>> obj.keys()
dict_keys(['query'])
>>> type(obj['query'])
<class 'dict'>
>>> obj['query'].keys()
dict_keys(['count', 'created', 'lang', 'results'])
>>> type(obj['query']['results'])
<class 'dict'>
>>> obj['query']['results'].keys()
dict_keys(['channel'])
>>> type(obj['query']['results']['channel'])
<class 'dict'>
>>> obj['query']['results']['channel'].keys()
dict_keys(['units', 'title', 'link', 'description', 'language', 'lastBuildDate
', 'ttl', 'location', 'wind', 'atmosphere', 'astronomy', 'image', 'item'])
>>> obj['query']['results']['channel']['item'].keys()
dict_keys(['title', 'lat', 'long', 'link', 'pubDate', 'condition', 'forecast',
 'description', 'guid'])
>>> type(obj['query']['results']['channel']['item']['forecast'])
<class 'list'>
>>> e = obj['query']['results']['channel']['item']['forecast'][0]
>>> e
{'code': '23', 'date': '19 Aug 2020', 'day': 'Wed', 'high': '27', 'low': '17',
 'text': 'Breezy'}
>>> e['date']
'19 Aug 2020'
>>> e['low']
'17'
>>> {e['date'] : e['low'] for e in obj['query']['results']['channel']['item'][
'forecast'] }

#for example rest API 
url = "http://weatherapi1971.pythonanywhere.com/query.yahooapis.com/v1/public/yql"
p = {'q': "select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='mumbai') and u='c'",
         "format" : "json"}
import requests 
r = requests.get(url, params=p)
obj = r.json()
{e['date']: e['low']  for e in 
  obj['query']['results']['channel']['item']['forecast'] }
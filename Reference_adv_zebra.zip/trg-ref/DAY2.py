###Decorator

#without wraps, trace prints _inner 
from functools import wraps
def  mea(fun):
    @wraps(fun)
    def _inner(*args, **kargs):
        import time
        now = time.time()
        res = fun(*args,**kargs)
        print(time.time() - now, " secs")
        return res
    return _inner

  
def trace(f):
    def _inner(*args, **kargs):
        print(f"entering {f.__name__}")
        res = f(*args,**kargs)
        print(f"exiting {f.__name__}")
        return res
    return _inner

import glob, os.path  
    
#opposite is OK 
@trace 
@mea
def getMaxFilename(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for file in files:
            if os.path.isfile(file):
                ed[file] =  os.path.getsize(file)
        for file in files:
            if not os.path.isfile(file):
                get_files(file, ed)
        return ed
    allfiles = get_files(path)
    sted = sorted(allfiles, key=lambda k: allfiles[k])
    return sted[-1]


#Suppose we, want to round to certain digits  of mea output 
from functools import wraps
def mea(howmany=2):
    def  _inner1(fun):
        @wraps(fun)
        def _inner2(*args, **kargs):
            import time
            now = time.time()
            res = fun(*args,**kargs)
            print(round(time.time() - now, howmany), " secs")
            return res
        return _inner2
    return _inner1

#default would work this way 
@trace 
@mea()
def getMaxFilename(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for file in files:
            if os.path.isfile(file):
                ed[file] =  os.path.getsize(file)
        for file in files:
            if not os.path.isfile(file):
                get_files(file, ed)
        return ed
    allfiles = get_files(path)
    sted = sorted(allfiles, key=lambda k: allfiles[k])
    return sted[-1]

    
##Using wraps 
#the name of the example function would have been 'wrapper', 
#and the docstring of the original example() would have been lost.
   
    
from functools import wraps
def my_decorator(f):
    @wraps(f)
    def wrapper(*args, **kwds):
        print 'Calling decorated function'
        return f(*args, **kwds)
    return wrapper

@my_decorator
def example():
    """Docstring"""
    print 'Called example function'

>>> example()
Calling decorated function
Called example function
>>> example.__name__
'example'
>>> example.__doc__
'Docstring'

###Iterator
import glob , os.path 

def get_files(path, res):
    files = glob.glob(os.path.join(glob.escape(path), "*"))
    for file in files:
        if os.path.isfile(file):
            res.append(file) 
    for file in files:
        if os.path.isdir(file):
            get_files(file, res)
    return res
            
#Iterator 
def get_files_recursive(path):
    files = glob.glob(os.path.join(glob.escape(path), "*"))
    #print(os.path.join(glob.escape(path), "*"), files)
    for file in files:
        if os.path.isfile(file):
            yield file 
    for file in files:
        if os.path.isdir(file):
            #print("dir", file)
            yield from get_files_recursive(file)
              
###General HandsON 
MaxFile class 
from pkg.file import File 
fs = File(".")
fs.getMaxSizeFile(2) # gives two max file names 
fs.getLatestFiles(datetime.date(2018,2,1))
#Returns list of files after 1st Feb 2018 


#implementation 
import datetime, glob, os.path 
class File:
    def __init__(self, dir, dynamic=False):
        self.dir = dir 
        self.file_dict = None 
        self.dynamic = dynamic 
    def getAllFiles(self):
        def recurse(root, acc={} ):
            import os.path, glob
            lst = [os.path.normpath(f) for f in glob.glob(os.path.join(root, "*"))]
            acc.update( { f:{'size':os.path.getsize(f), 
                             'mtime': datetime.date.fromtimestamp(os.path.getmtime(f)),
                             'ctime': datetime.date.fromtimestamp(os.path.getctime(f))}   
                             for f in lst if os.path.isfile(f) } )
            [recurse(f, acc) for f in lst if os.path.isdir(f)]	
            return acc
        if not self.file_dict or self.dynamic:
            self.file_dict = recurse(self.dir)
    def getMaxSizeFile(self, howmany=1):
        self.getAllFiles()
        maxnames = sorted(self.file_dict.keys(), 
            key = lambda n: self.file_dict[n]['size'], reverse=True )
        return [(maxnames[i],self.file_dict[maxnames[i]]['size'])  
            for i in range(howmany)] 
    def getLatestFiles(self, after=datetime.date.today()-datetime.timedelta(days=7)):
        """ after : datetime.date(year, month, day)"""
        self.getAllFiles()
        return [ f  for f in  self.file_dict 
            if ( self.file_dict[f]['mtime'] >= after 
            or self.file_dict[f]['ctime'] >= after )]


### Multithreading
#daemon - process waits for non daemon thread/process while exiting 
#but process does not wait for daemon thread/process and exists(and in process cleanup-they are cleaned)
#daemon should be set before start()

import time
import random
import threading 

def w(sleeptime):
	time.sleep(sleeptime)
	print(threading.current_thread().getName()," Thread finished")

t = threading.Thread(target=w, args=(10,))
t.start(); print("Main thread")


t = threading.Thread(target=w)
t.start(); t.join(); print("Main thread")

##Another example 
import time
import random
import threading

def worker(sleeptime):
    print(threading.current_thread().getName(), "Entering")
    time.sleep(sleeptime)
    print(threading.current_thread().getName(), "exiting")
    
if __name__ == '__main__':
    print("sequentially")
    worker(1)
    print("Parallely")
    ths = []
    st = time.time()
    for i in range(10):
        th = threading.Thread(target=worker, args=(5,))
        ths.append(th)
    [th.start() for th in ths]
    [th.join() for th in ths]  # wait for ending
    print("Time taken:", round(time.time()-st, 3), " secs")

#With process 
import time
import random
import multiprocessing

def worker(sleeptime):
    print(multiprocessing.current_process().name, "Entering")
    time.sleep(sleeptime)
    print(multiprocessing.current_process().name, "exiting")
    
if __name__ == '__main__':
    print("sequentially")
    worker(1)
    print("Parallely")
    ths = []
    st = time.time()
    for i in range(10):
        th = multiprocessing.Process(target=worker, args=(5,))
        ths.append(th)
    [th.start() for th in ths]
    [th.join() for th in ths]  # wait for ending
    print("Time taken:", round(time.time()-st, 3), " secs")
    
#Note Signal Handling in Process in trickey
#SIGINT(CRTL+C) handling is inherited by child process if not ignored 
#So handle it in child process (KeyboardInterrupt is not child of Exception)
import time
import time
import random
import multiprocessing

def worker(sleeptime):
    try:
        print(multiprocessing.current_process().name, "Entering")
        time.sleep(sleeptime)
        print(multiprocessing.current_process().name, "exiting")
    except KeyboardInterrupt as ex:
        print(multiprocessing.current_process().name, 'KeyboardInterrupt - cleaning')
    
if __name__ == '__main__':
    ths = []
    for i in range(10):
        th = multiprocessing.Process(target=worker, args=(10,))
        ths.append(th)
    [th.start() for th in ths]
    while all( [not th.is_alive() for th in ths]):
        time.sleep(0.5)
    try:
        [th.join() for th in ths]  
    except KeyboardInterrupt as ex:
        print('KeyboardInterrupt')    
    
    
##RLock- threading 

#golbal variable are shared 
import threading , time 
shared= []
def proc(lck):
    global shared    
    print("before", threading.current_thread().getName())
    with lck:   #lck.accquire()
        print("Acquired", threading.current_thread().getName())
        time.sleep(2)
        shared.append(threading.current_thread().getName())
    #lck.release()
    time.sleep(2)    

ids = []
lock = threading.RLock() #one at time 
lock = threading.Semaphore(2) #two at time 
#A Semaphore can be released more times than it's acquired, 
#and that will raise its counter above the starting value. 
#A BoundedSemaphore can't be released more than no of acquire 
for i in range(10):
    t = threading.Thread(target=proc, args=(lock,))
    ids.append(t)
[t.start() for t in ids]
[t.join() for t in ids]



#With process , global variable are not shared , Use Array, Value or Manager.list/.dict 
# list(sequence)/list()/dict(mapping)/dict() for initial value 
# can contained nested Manager list/dict etc 

import  time 
import multiprocessing 


def proc(lck,shared):
    print("before", multiprocessing.current_process().name)
    with lck:   #lck.accquire()
        print("Acquired", multiprocessing.current_process().name)
        time.sleep(2)
        shared.append(multiprocessing.current_process().name)
    #lck.release()
    time.sleep(2)    


if __name__ == '__main__':
    ids = []
    manager = multiprocessing.Manager()
    shared = manager.list()
    lock = multiprocessing.RLock() #one at time 
    #lock = multiprocessing.Semaphore(2) #two at time 
    #A Semaphore can be released more times than it's acquired, 
    #and that will raise its counter above the starting value. 
    #A BoundedSemaphore can't be raised above the starting value
    for i in range(10):
        t = multiprocessing.Process(target=proc, args=(lock,shared))
        ids.append(t)
    [t.start() for t in ids]
    [t.join() for t in ids]
    print(shared)
    

##Queue
import queue
import threading
import time

def worker(q):
	while True:
		item = q.get()
		print(threading.current_thread().getName(), item)
		time.sleep(2)
		q.task_done()

		
que = queue.Queue()
for i in range(2):
	t = threading.Thread(target=worker, args=(que,))
	t.start()

for item in range(10):  #Only one thread get one item 
	que.put(item)

que.join()       # block until all tasks are done

#OR with Event 
import queue
import threading
import time, random

#Display buffer 
output = []  #list of tuples 


def display(lock, event, exit_event):
    displayindex = 0
    while True:
        if exit_event.is_set():
            break 
        event_is_set = event.wait() # waits for flag to true 
        print('Display ' , threading.current_thread().getName(), end=" ")
        #is there anything to display 
        while displayindex < len(output):
            with lock:
                print( output[displayindex] )
            displayindex += 1
        #reset the event 
        event.clear()  #flag is false 


def download(que,lock,event):
    while True:
        item = que.get() # blocks 
        print(threading.current_thread().getName(), "got", item)
        time.sleep(random.randint(1,5))		
        #Update output 
        with lock:
            output.append( (item, "OK") )
        que.task_done()
        event.set() #make flag true 
        
		
que = queue.Queue()
event = threading.Event()
lock = threading.RLock()
exit_event = threading.Event()
#Start download , make it daemon such that main thread exits 
for i in range(2):
    t = threading.Thread(target=download, args=(que,lock,event), daemon = True)
    t.start()
#Start download 
display_t = threading.Thread(target=display, args=(lock,event, exit_event))
display_t.start()

#Main Thread
for item in range(10):  #Only one thread get one item 
	que.put(item)

que.join() #Blocks until all items in the queue have been gotten and processed
exit_event.set()
display_t.join() #wait for display to end 


##process Queue 
#example 
from __future__ import print_function
from multiprocessing import Process, Queue, Pipe, RLock



class A(object):
    def __init__(self, v):
        self.value = v 
    def __repr__(self):
        return "A(%d)" % (self.value,)

def queuef(q, obj):
    q.put([42, None, 'hello', {'from': 'queue'}, obj])
    
def pipef(conn, obj):
    conn.send([42, None, 'hello', {'from': 'pipe'}, obj])
    conn.close()
    
if __name__ == '__main__':
    #lck
    lck = RLock()
    #A
    a = A(20)
    #Queue
    q = Queue()
    p = Process(target=queuef, args=(q, a))
    p.start()
    with lck:
        print(q.get())    # prints "[42, None, 'hello']"
    p.join()
    #Pipe
    parent_conn, child_conn = Pipe()
    p = Process(target=pipef, args=(child_conn, a))
    p.start()
    with lck:
        print(parent_conn.recv())   # prints "[42, None, 'hello']"
    p.join()
    
Joining processes that use queues
    Bear in mind that a process that has put items in a queue will wait 
    before terminating until all the buffered items are consumed 
    OR call the Queue.cancel_join_thread method of the queue to avoid this behaviour.
    #deadlock
    #A fix here would be to swap the last two lines (or simply remove the p.join() line).

    from multiprocessing import Process, Queue

    def f(q):
        q.put('X' * 1000000)

    if __name__ == '__main__':
        queue = Queue()
        p = Process(target=f, args=(queue,))
        p.start()
        p.join()                    # this deadlocks
        obj = queue.get()
    

##futures 

import threading , time 
import concurrent.futures
import os, os.path 

from functools import wraps 

def  profile(fun):
    def _inner(*args, **kargs):
        import time
        now = time.time()
        dont_print = 'dont_print' in kargs
        res = fun(*args,**kargs)
        if not dont_print:
            print(fun.__name__, "(", threading.current_thread().getName(), 
                "): ", round(time.time() - now, 2), " secs")
        return res
    return _inner
    
def  aprofile(afun):
    async def _inner(*args, **kargs):
        import time
        now = time.time()
        dont_print = 'dont_print' in kargs
        res = await afun(*args,**kargs)
        if not dont_print:
            print(afun.__name__, "(", threading.current_thread().getName(), 
                "): ", round(time.time() - now, 2), " secs")
        return res
    return _inner
    
#note local lambda can not be prickled , so 
#it is written as top level function which is pickable 
# note run time might be higher than sequential because of process creation
def get_dir_size(p):
    return FileUtil(p).getDirSize(dont_print=True)

class FileUtil:    
    def __init__(self, path):
        self.path = path
    def get_size(self, rootpath,files):
        ed = {}
        for file in files:
            try:
                ed[file] = os.path.getsize(os.path.join(rootpath,file))
            except Exception as ex:
                pass
        return ed
    @profile
    def getDirSize(self, **kwargs):
        s = 0
        for rootpath, dirs, files in os.walk(self.path):
            el = self.get_size(rootpath, files)
            #print(el, files,rootpath)
            s += sum(el.values())
        return s 
    @profile
    def getDirSizeThreaded(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        res = ex.map(lambda p : FileUtil(p).getDirSize(dont_print=True), 
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        ex.shutdown()
        return s 
    @profile
    def getDirSizeThreadedSubmit(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        fs = [ ex.submit( lambda p : FileUtil(p).getDirSize(dont_print=True), 
                    os.path.join(rootpath,d))
              for d in dirs]
        for res in concurrent.futures.as_completed(fs):
            s += res.result()
        ex.shutdown()
        return s 
    @profile
    def getDirSizeThreadedP(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ProcessPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        res = ex.map(get_dir_size, 
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        ex.shutdown()
        return s 
    @profile
    def getDirSizeThreadedSubmitP(self, ws=4):
        import os, os.path 
        s = 0
        ex = concurrent.futures.ProcessPoolExecutor(max_workers=ws)
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        fs = [ ex.submit( get_dir_size, 
                    os.path.join(rootpath,d))
              for d in dirs]
        for res in concurrent.futures.as_completed(fs):
            s += res.result()
        ex.shutdown()
        return s 
    @profile
    def getDirSizePoolP(self, ws=4):
        import os, os.path 
        s = 0
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        with multiprocessing.Pool(processes=ws) as pool: 
            res = pool.map(get_dir_size, 
                [os.path.join(rootpath,d) for d in dirs])
        
        s += sum(res)
        return s 
        
    @profile
    def getDirSizeThreadedEE(self, executor):
        s = 0
        rootpath, dirs, files = next(os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #for other dirs 
        res = executor.map(lambda p : FileUtil(p).getDirSize(dont_print=True), 
            [os.path.join(rootpath,d) for d in dirs])
        s += sum(res)
        return s 
    @aprofile 
    async def getDirSizeAsync(self, executor=None):
        s = 0
        rootpath, dirs, files = next( os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #awaitable loop.run_in_executor(executor, func, *args)
        #awaitable asyncio.gather(*aws, loop=None, return_exceptions=False)
        loop = asyncio.get_running_loop()
        async_jobs = [loop.run_in_executor(executor,
                                     lambda p: FileUtil(p).getDirSize(dont_print=True), 
                                     os.path.join(rootpath,d)) for d in dirs]
        res = await asyncio.gather(*async_jobs)
        s += sum(res)
        return s 
        
    @aprofile 
    async def getDirSizeAsync_v2(self,  executor=None):
        s = 0
        rootpath, dirs, files = next( os.walk(self.path))
        el = self.get_size(rootpath, files)
        s += sum(el.values())
        #awaitable loop.run_in_executor(executor, func, *args)
        #awaitable asyncio.gather(*aws, loop=None, return_exceptions=False)
        loop = asyncio.get_running_loop()
        async_jobs = {loop.run_in_executor(executor,
                                     lambda p: FileUtil(p).getDirSize(dont_print=True), 
                                     os.path.join(rootpath,d)) for d in dirs}                                     
        for coro in asyncio.as_completed(async_jobs):
            size = await coro
            s += size            
        return s 
        
if __name__ == '__main__':
    path = r"C:\windows\system32"
    fiu = FileUtil(path)
    #first time more for cache operations, so do after one time     
    print("sequential")
    r = fiu.getDirSize()    

    print("Now parallel")
    rs = fiu.getDirSizeThreaded()
    
    print("Now parallel")
    rs = fiu.getDirSizeThreaded(8)
    
    print("Now parallel")
    rs = fiu.getDirSizeThreadedSubmit()  

    print("Now parallel")
    rs = fiu.getDirSizeThreadedP()
    
    print("Now parallel with 8")
    rs = fiu.getDirSizeThreadedP(8)
    
    print("Now parallel with submit ")
    rs = fiu.getDirSizeThreadedSubmitP()  
    
    print("Now parallel with Pool ")
    rs = fiu.getDirSizePool()  
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=ws)  as executor:
        r = fiu.getDirSizeThreadedEE(executor) 
        print(r)
        r = asyncio.run(fiu.getDirSizeAsync(executor))
        print(r)
        r = asyncio.run(fiu.getDirSizeAsync_v2(executor))
        print(r)
        import timeit 
        print(timeit.timeit(stmt="asyncio.run(fiu.getDirSizeAsync_v2(executor))", number=10, globals=globals()))


###Linear algebra using numpy, 
import numpy as np

a = np.array([1, 2, 3])  # Create a rank 1 array
print(type(a))            # Prints "<type 'numpy.ndarray'>"
print(a.shape)            # Prints "(3,)"
print(a.ndim) 			 # 1
print(a[0], a[1], a[2])   # Prints "1 2 3"
a[0] = 5                 # Change an element of the array
print(a)                  # Prints "[5, 2, 3]"

b = np.array([[1,2,3],[4,5,6]])   # Create a rank 2 array
print(b.shape)                     # Prints "(2, 3)"
print(b[0, 0], b[0, 1], b[1, 0])   # Prints "1 2 4"
b[0,]	#or b[0,:]   			  # array([1, 2, 3])  
b[:,0]                            #array([1, 4])



#Note the difference of below, one is vector and another is 1x3
>>> x = np.array([[1,2,3]])        
>>> x.shape                         #rank 2 as two dimension 
(1, 3)

>>> x = np.array([1,2,3])           # rank 1, generally called vector 
>>> x.shape
(3,)

##Creation of array - these methods take (m,n,...) dimensions 
# similar methods (zeros/ones/full)_like(another_array) which creates based on another_array.shape
import numpy as np

a = np.zeros((2,2))  # Create an array of all zeros 

    
b = np.ones((1,2))   # Create an array of all ones

c = np.full((2,2), 7) # Create a constant array
print(c)               # Prints "[[ 7.  7.]
                      #          [ 7.  7.]]"

d = np.eye(2)        # Create a 2x2 identity matrix

#numpy.linspace(start, stop, num=50, endpoint=True, retstep=False, dtype=None)
>>> np.linspace(2.0, 3.0, num=5)
array([ 2.  ,  2.25,  2.5 ,  2.75,  3.  ])

#numpy.arange([start, ]stop, [step, ]dtype=None)
>>> np.arange(3.0)
array([ 0.,  1.,  2.])

>>> np.arange(10).reshape(2,5)
array([[0, 1, 2, 3, 4],
       [5, 6, 7, 8, 9]])
       
#Example , one shape arg could be -1 , then that is calculated 
b = np.array([[0, 1], [2, 3], [4,5]])
b.resize(2, 3) # or tuple (2,3) #mutable 
#or 
b = b.reshape((2,3)) #or varargs 2,3 
b = b.reshape(2,-1)  #-1 would be autocalculated 
>>> b
array([[0, 1, 2],
       [3, 0, 0]])
       
#Note 
reshape(a, newshape, order='C')
    (default)C language order, C_CONTIGUOUS - row major ie read row wise (for each row, read cols)
    F order/Fortran order,F_CONTIGUOUS - column major ie read column wise (for each col, read rows)
    
a = np.array([[1,2,3,4], [5,6,7,8]])
>>> a.shape
(2, 4)
>>> a.shape = 4,2
>>> a
array([[1, 2],
       [3, 4],
       [5, 6],
       [7, 8]])
>>> a.flags 
 C_CONTIGUOUS : True
 F_CONTIGUOUS : False
 OWNDATA : True
 WRITEABLE : True
 ALIGNED : True
 WRITEBACKIFCOPY : False
 UPDATEIFCOPY : False
 
#If you change the shape, the order of data do not change.
#to get column major
>>> b = a.ravel()
array([1, 2, 3, 4, 5, 6, 7, 8])
>>> c = b.reshape(2,4,order='F')
>>> c
array([[1, 3, 5, 7],
       [2, 4, 6, 8]])


#numpy.logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)
#base ** start is the starting value of the sequence.
>>> np.logspace(2.0, 3.0, num=4)
array([  100.        ,   215.443469  ,   464.15888336,  1000.        ])

##Broadcasting 
x = np.linspace(1.0, 5.0, num=5)
y = np.linspace(10.0, 50.0, num=5)
>>> x
array([1., 2., 3., 4., 5.])
>>> y
array([10., 20., 30., 40., 50.])
>>> x.shape
(5,)
>>> y.shape
(5,)
>>> y1 = y[:, None]
>>> y1
array([[10.],
       [20.],
       [30.],
       [40.],
       [50.]])
>>> y2 = y[:, np.newaxis]
>>> y2
array([[10.],
       [20.],
       [30.],
       [40.],
       [50.]])
>>> y3 = y[None, :]
>>> y3
array([[10., 20., 30., 40., 50.]])
#means removes any dim if it is of  1 
>>> np.squeeze(y1)
array([10., 20., 30., 40., 50.])

## Rules of Broadcasting 
1. Shape manipulation 
   Convert lower rank array's shape to higher rank shape 
   'by prepending 1'(always prepend)
   For example vector with shape (3,) 
   is converted to rank 2 array as (1,3) or rank 3 as (1,1,3)
   array with (2,3) is converted to rank 3 by (1,2,3)
						
2. Compatibility of arrays 
   Compatible if they have the same size in a dimension, 
   or if one of the arrays has size 1 in that dimension.
   For example , shape (2,3) is compatible with other array 
   with shape (2,3) or (1,3) or (2,1) or (1,1) or (1,) 
   then Broadcasting is possible for other array  

3. Boradcasting  
   If a dimesion is 1 , other dimesions are copied along that dimension 
   when doing operations between arrays 
   eg (1,3) is row stacked 2 times to get (2,3) ie np.tile(x13,(2,1))
   (2,1) is col stacked three times to get (2,3) ie np.repeat(x21, 3, axis=1) or np.tile(x21, (1,3))
   (1,1) or (1,) can be tiled ie np.tile(x11, (2,3))
   #Example:
   If a.shape is (5,1), b.shape is (1,6), c.shape is (6,) 
   and d.shape is () (ie d scalar), 
   then a, b, c, and d are all broadcastable to dimension (5,6); 
    •a acts like a (5,6) array where a[:,0] is broadcast to the other columns,
    •b acts like a (5,6) array where b[0,:] is broadcast to the other rows,
    •c acts like a (1,6) array and therefore like a (5,6) array where c[:] is broadcast to every row
    •d acts like a (5,6) array where the single value is repeated.

#broadcasting 
>>> x + y1  #== x[None,:] + y1 
#X(5,) becomes (1, 5), then x becomes (5,5) with repeatation of  first row 
#Y1(5,1) becomes (5,5) with repeatation of  first column 
array([[11., 12., 13., 14., 15.],
       [21., 22., 23., 24., 25.],
       [31., 32., 33., 34., 35.],
       [41., 42., 43., 44., 45.],
       [51., 52., 53., 54., 55.]])
#ie 
>>> np.tile(x, (5,1))   #row five times, column 1 times 
array([[1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.]])
>>> np.tile(y1, (1,5))          #row 1 times , column 5 times , final dim =(5*1, 1*5)
array([[10., 10., 10., 10., 10.],
       [20., 20., 20., 20., 20.],
       [30., 30., 30., 30., 30.],
       [40., 40., 40., 40., 40.],
       [50., 50., 50., 50., 50.]])
#OR 
>>> x
array([1., 2., 3., 4., 5.])
>>> XX,YY = np.meshgrid(x,y)
>>> XX
array([[1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.],
       [1., 2., 3., 4., 5.]])
>>> YY
array([[10., 10., 10., 10., 10.],
       [20., 20., 20., 20., 20.],
       [30., 30., 30., 30., 30.],
       [40., 40., 40., 40., 40.],
       [50., 50., 50., 50., 50.]])
#mgrid  are helper classes which use index notation 
#without having to use 'linspace'. 
#Note The order in which the output are generated is reversed.
YY1, XX1 = np.mgrid[10:40:10, 1:4]
XX1
array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
YY1
array([[10, 10, 10],
       [20, 20, 20],
       [30, 30, 30]])
#ravel means flatten 
>>> XX.ravel()
array([1., 2., 3., 4., 5., 1., 2., 3., 4., 5., 1., 2., 3., 4., 5., 1., 2., 3., 4., 5., 1., 2., 3., 4., 5.])
>>> YY.ravel()
array([10., 10., 10., 10., 10., 20., 20., 20., 20., 20., 30., 30., 30.,30., 30., 40., 40., 40., 40., 40., 50., 50., 50., 50., 50.])
>>> (x+y1).ravel()
array([11., 12., 13., 14., 15., 21., 22., 23., 24., 25., 31., 32., 33., 34., 35., 41., 42., 43., 44., 45., 51., 52., 53., 54., 55.])
>>> XX.ravel() + YY.ravel()
array([11., 12., 13., 14., 15., 21., 22., 23., 24., 25., 31., 32., 33.,34., 35., 41., 42., 43., 44., 45., 51., 52., 53., 54., 55.])

       
       
##random 
#https://docs.scipy.org/doc/numpy-1.14.1/reference/routines.random.html
#Seed
RandomState([seed]) 	
    Container for the Mersenne Twister pseudo-random number generator.
    RandomState has similar methods like np.random.  where these seed would be valid 
seed([seed]) 	
    Seed the generator, used for np.random methods 

##many methods(few are similar) are there eg  
rand(d0, d1, …, dn) 	
    Random values in a given shape.
randn(d0, d1, …, dn) 	
    Return a sample (or samples) from the "standard normal" distribution.
#Note size is either single N or (d1, d2,..) for multidimesion      
randint(low[, high, size, dtype]) 	
    Return random integers from low (inclusive) to high (exclusive).
random_integers(low[, high, size]) 	
    Random integers of type np.int between low and high, inclusive.
random_sample([size]) 	
ranf([size]) 	
sample([size]) 	
random([size]) 	
    All these methods Return random floats in the half-open interval [0.0, 1.0).


#Example     
np.random.random((2,2))  #tuple
np.random.rand(3,2)       #vargs 
2.5 * np.random.randn(2, 4) + 3


#Many distributions, 
#for example 
#Note size is either single N or (d1, d2,..) for multidimesion      
lognormal([mean, sigma, size]) 	
    Draw samples from a log-normal distribution.
multinomial(n, pvals[, size]) 	
    Draw samples from a multinomial distribution.
normal([loc, scale, size]) 	    
    Draw random samples from a normal (Gaussian) distribution.
#Example      
mu, sigma = 0, 0.1 # mean and standard deviation
s = np.random.normal(mu, sigma, 1000)    
s.shape  #(1000,)
s = np.random.normal(mu, sigma, (6,4))     
s.shape     #(1000,)
       
       
        





##Array indexing - Slice Indexing (can be mutated)
#index can be single number, or start:stop:step (stop exclusive)
#or :(means all elements of that dimension) or array of indexes
#or boolean array(where True indexes are selected)
import numpy as np

# Create the following rank 2 array with shape (3, 4)
a = np.array([[1,2, 3, 4], 
              [5,6, 7, 8], 
              [9,10,11,12]])


b = a[:2, 1:3]
print(a[0, 1])   # Prints "2"
b[0, 0] = 77    # b[0, 0] is the same piece of data as a[0, 1]
print(a[0, 1])   # Prints "77"

row_r1 = a[1, :]    # Rank 1 view of the second row of a  
row_r2 = a[1:2, :]  # Rank 2 view of the second row of a
col_r1 = a[:, 1]
col_r2 = a[:, 1:2]

##Boolean array indexing - a[bool], bool and a are of same dimension 

import numpy as np

a = np.array([[1,2], [3, 4], [5, 6]])

bool_idx = (a > 2)  
            
print(bool_idx)      # Prints "[[False False]
                    #          [ True  True]
                    #          [ True  True]]"

print(a[bool_idx])  # Prints "[3 4 5 6]", 

# We can do all of the above in a single concise statement:
print(a[a > 2])     # Prints "[3 4 5 6]"

>>> a[ (a > 2) & (a<5)]    #Use &, | and ~ for boolean operation , ==, !=, > >= etc for comparison
array([3, 4])
>>> a[ (a > 2) | (a<5)]
array([1, 2, 3, 4, 5, 6])
>>> a[ ~(a > 2) ]
array([1, 2])

>>> a[ a == 2]
array([2])
>>> a[ a != 2]
array([1, 3, 4, 5, 6])


##Numpy - Array indexing - using ... (means all remaining dimensions)
>>> from numpy import arange
>>> a = arange(16).reshape(2,2,2,2)

#you have a 4-dimensional matrix of order 2x2x2x2. 
#To select all first elements in the 4th dimension, you can use the ellipsis notation
>>> a[..., 0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])

#which is equivalent to
>>> a[:,:,:,0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])

## Default iteration
a = np.arange(6).reshape(3,2)
>>> a
array([[0, 1],
       [2, 3],
       [4, 5]])
       
for val in a:
    print('item:', val)
#output 
item: [0 1]
item: [2 3]
item: [4 5]


##Array math 
#ndarray.methods or np.methods(ndarray) - operates elementwise on array 
#check by 
#https://docs.scipy.org/doc/numpy-1.13.0/reference/ufuncs.html
dir(np)

import numpy as np

x = np.array([[1,2],[3,4]], dtype=np.float64)
y = np.array([[5,6],[7,8]], dtype=np.float64)

# Elementwise sum; both produce the array
# [[ 6.0  8.0]
#  [10.0 12.0]]
print(x + y)
print(np.add(x, y))
# Elementwise
print(x - y)    #print np.subtract(x, y)
print(x * y)    #print np.multiply(x, y)
print(x / y)    #print np.divide(x, y)

##Use .dot  for inner product of vector or matrix multiplication 
v = np.array([9,10])
w = np.array([11, 12])

# Inner product of vectors; both produce 219
print(v.dot(w))
print(np.dot(v, w))
# Matrix / vector product; both produce the rank 1 array [29 67]
print(x.dot(v)
print(np.dot(x, v))
# Matrix / matrix product; both produce the rank 2 array
# [[19 22]
#  [43 50]]
print(x.dot(y))
print(np.dot(x, y))
#Many mathemaical functions 
np.log(x) 
print(np.sqrt(x))  #other math methods eg np.sin(), np.log() ....

#applying function 
arr = np.array([[1, 2], [3, 4], [5,6]])
#gets each row as it is rowmajor by default, so for loop also gets each row 
>>> list(map(print, arr))
[1 2]
[3 4]
[5 6]
#here broadcasting is happening for + 
list(map(lambda e: e+10, arr))
#[array([11, 12]), array([13, 14]), array([15, 16])]
np.array(list(map(lambda e: e+10, arr)))

#numpy func operates on Vector -called ufunc
#frompyfunc-Takes an arbitrary Python function and returns a NumPy ufunc(including broadcasting)
oct_array = np.frompyfunc(oct, 1, 1)  #1,1 = nin, nout = no of input to pyfn and no of output from pyfn

oct_array(np.array((10, 30, 100)))
#array(['0o12', '0o36', '0o144'], dtype=object)

np.array((oct(10), oct(30), oct(100))) # for comparison
#array(['0o12', '0o36', '0o144'], dtype='<U5')

#Similarly - np.vectorize which also understand broadcasting 
def myfunc(a, b):
    "Return a-b if a>b, otherwise return a+b"
    if a > b:
        return a - b
    else:
        return a + b

vfunc = np.vectorize(myfunc)

vfunc([1, 2, 3, 4], 2)
#array([3, 4, 1, 2])

#or output dtypes can be specfied 
vfunc = np.vectorize(myfunc, otypes=[float])
out = vfunc([1, 2, 3, 4], 2)
type(out[0])
#<class 'numpy.float64'>



##Sum -  for performing computations on arrays 
# For , np.sum(axis=n),  then dimension n is collapsed and deleted, 
#For example, if b has shape (5,6,7,8), and c = b.sum(axis=2), 
#then axis 2 (dimension with size 7) is collapsed, and the result has shape (5,6,8). 
#c[x,y,z] is equal to the sum of all elements c[x,y,:,z].


#Other similar methods are 
ndarray.cumsum([axis, dtype, out]) 					Return the cumulative sum of the elements along the given axis. 
ndarray.mean([axis, dtype, out, keepdims]) 			Returns the average of the array elements along given axis. 
ndarray.var([axis, dtype, out, ddof, keepdims]) 	Returns the variance of the array elements, along given axis. 
ndarray.std([axis, dtype, out, ddof, keepdims]) 	Returns the standard deviation of the array elements along given axis. 
ndarray.prod([axis, dtype, out, keepdims]) 			Return the product of the array elements over the given axis 
ndarray.cumprod([axis, dtype, out]) 				Return the cumulative product of the elements along the given axis. 

#for 2D , axis=0, means column sum and axis=1, means row sum 

import numpy as np

x = np.array([[1,2],[3,4]])

print(np.sum(x))  # Compute sum of all elements; prints "10"
print(np.sum(x, axis=0))  # Compute sum of each column; prints "[4 6]"
print(np.sum(x, axis=1))  # Compute sum of each row; prints "[3 7]"

>>> np.cumsum(x, axis=0)
array([[1, 2],
       [4, 6]], dtype=int32)

>>> np.cumsum(x, axis=1)
array([[1, 3],
       [3, 7]], dtype=int32)
       
       
       
##Transposing  an array 
import numpy as np

x = np.array([[1,2], [3,4]])
print(x)    # Prints "[[1 2]
           #          [3 4]]"
print(x.T)  # Prints "[[1 3]
           #          [2 4]]"

# Note that taking the transpose of a rank 1 array does nothing:
v = np.array([1,2,3])
print(v)    # Prints "[1 2 3]"
print(v.T)  # Prints "[1 2 3]"


##Conversion
x = np.array([1, 2, 2.5])
>>> x
array([ 1. ,  2. ,  2.5])

>>> x.astype(int)
array([1, 2, 2])
>>> x.astype(str)
array(['1.0', '2.0', '2.5'],
      dtype='|S32')
      
##Repeat and Tile 
x = np.array([[1,2],[3,4]])
>>> np.repeat(x, 2)   #default is flattened, and each element 2 times 
array([1, 1, 2, 2, 3, 3, 4, 4])
>>> np.repeat(x, 3, axis=1)     #axis=1 means column , each column 3 times 
array([[1, 1, 1, 2, 2, 2],
       [3, 3, 3, 4, 4, 4]])
>>> np.repeat(x, [1, 2], axis=0) #axis=0 means row, row1 one time, row2 two times 
array([[1, 2],
       [3, 4],
       [3, 4]])

#numpy.tile(A, reps) - either promote A or reps if one's dimesion is less 
#Construct an array by repeating A  given by reps(The number of repetitions of A along each axis.)
#If reps has length d, the result will have dimension of max(d, A.ndim).
#If A.ndim < d, A is promoted to be d-dimensional by prepending new axes(broadcasting)
#So a shape (3,) array is promoted to (1, 3) for 2-D replication, or shape (1, 1, 3) for 3-D replication. 
#If this is not the desired behavior, promote A to d-dimensions manually before calling this function.
#If A.ndim > d, reps is promoted to A.ndim by pre-pending 1’s to it. 
#Thus for an A of shape (2, 3, 4, 5), a reps of (2, 2) is treated as (1, 1, 2, 2).
a = np.array([0, 1, 2])
>>> np.tile(a, 2)
array([0, 1, 2, 0, 1, 2])

>>> np.tile(a, (2, 2))   #promote a to (1,3), then to (1*reps, 3*reps)
array([[0, 1, 2, 0, 1, 2],
       [0, 1, 2, 0, 1, 2]])
>>> np.tile(a, (2, 1, 2))  #promote a to (1,1,3), then to (1*2, 1*1, 3*2)
array([[[0, 1, 2, 0, 1, 2]],
       [[0, 1, 2, 0, 1, 2]]])

b = np.array([[1, 2], [3, 4]])
>>> np.tile(b, 2)       #promote reps to (1,2) ie b dim = (2*1, 2*2), each row one times, each column two times 
array([[1, 2, 1, 2],
       [3, 4, 3, 4]])
>>> np.tile(b, (2, 1))   #b dim =(2*2, 2*1)
array([[1, 2],
       [3, 4],
       [1, 2],
       [3, 4]])

>>> c = np.array([1,2,3,4])
>>> np.tile(c,(4,1))    #c is promoted to (1,4), then dim= (1*4,4*1)
array([[1, 2, 3, 4],
       [1, 2, 3, 4],
       [1, 2, 3, 4],
       [1, 2, 3, 4]])


       
      
##r_ , c_ , stack etc 
#In general use concatenate for row(vertical) stacking or column(horizontal) stacking
#Many other functions do the same activity, 
#Use .r_[] or .c_[] if you want to use integer slice 

#one example ie all features collected in 1D  then vstack= feature matrix
#adding rows to form a new 2D 
a = np.array([1, 2, 3])
b = np.array([2, 3, 4])
>>> np.vstack((a,b)) 
array([[1, 2, 3],
       [2, 3, 4]])
#OR 
np.stack((a, b), axis=0)
       
#one feature collected at many points in 1D and then [:,None] then hstack= feature matrix
#adding columns to form a new 2D
a1 = np.array([[1],[2],[3]])  #a[:,None]
b1 = np.array([[2],[3],[4]])  #b[:,None]     
>>> np.hstack((a1,b1))  
array([[1, 2],
       [2, 3],
       [3, 4]])
#OR 
np.stack((a, b), axis=1)

#existing feature matrix, add one example or row , axis=0
#Adding one row to an existing 2D 
a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6]])
>>> np.concatenate((a, b), axis=0)
array([[1, 2],
       [3, 4],
       [5, 6]])

#existing feature matrix, add one feature (collected at many points) or column= axis=1
#Adding one col(must be nx1) to an existing 2D 
>>> b.T
array([[5],
       [6]]) 
>>> np.concatenate((a, b.T), axis=1)  #col concatenated
array([[1, 2, 5],
       [3, 4, 6]])   
       

##concatenate     
#a,b are 2D , axis=0, rowwise, axis=1, columnwise 
#feature matrix, then new example -all features collected in 1D,then [None,:], 
#then concatenate, axis=0 - row stack or vstack = feature matrix
a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6]])
>>> np.concatenate((a, b), axis=0) #row stack or vstack
array([[1, 2],
       [3, 4],
       [5, 6]])
       
#feature matrix, then one feature collected at many points in 1D,then [:, None], 
#then concatenate, axis=1 - col concatenated= feature matrix
>>> b.T
array([[5],
       [6]]) 
>>> np.concatenate((a, b.T), axis=1)  #col concatenated
array([[1, 2, 5],
       [3, 4, 6]])       
       
>>> np.concatenate((a, b), axis=None)
array([1, 2, 3, 4, 5, 6])



##When a,b are 1D 
np.r_  
    By default: create a array(1D) from comma seperated many slices start:stop:step (stop exclusive)
    or comman seperated numbers (along the first axis ie row)
    it has many other functonalities - check Reference 

np.c_ 
    create a array(2D) from comma seperated many 1D arrays or start:stop:step (stop exclusive)
    but  along the second axis(ie column) -> Column stack 


#note used with []   not ()

#column stacking 
a = np.array([1, 2, 3])
b = np.array([4,5,6])

>>> np.c_[a,b]    #each feature collected at many points, _c = feature matrix
array([[1, 4],
       [2, 5],
       [3, 6]])
       

>>> x = np.r_[-2:3, 0,0, 3:9]
>>> x
array([-2, -1,  0,  1,  2,  0,  0,  3,  4,  5,  6,  7,  8]

##vstack vs hstack  
#vstack-args 1D, output 2D ,rowstack 
a = np.array([1, 2, 3])
b = np.array([2, 3, 4])
>>> np.vstack((a,b)) #one example ie all features collected in 1D  then vstack= feature matrix
array([[1, 2, 3],
       [2, 3, 4]])
       
>>> np.hstack((a,b))
array([1, 2, 3, 2, 3, 4])

#when a,b re 2D
#hstack-args1D, [:,None], result 2D, colstack
a1 = np.array([[1],[2],[3]])  #a[:,None]
b1 = np.array([[2],[3],[4]])       
>>> np.vstack((a1,b1))
array([[1],
       [2],
       [3],
       [2],
       [3],
       [4]])
       
>>> np.hstack((a1,b1))  
#one feature collected at many points in 1D and then [:,None] then hstack= feature matrix
array([[1, 2],
       [2, 3],
       [3, 4]])

#columnwise append 
a = np.array((1,2,3))
b = np.array((2,3,4))
>>> np.column_stack((a,b))
array([[1, 2],
       [2, 3],
       [3, 4]])
       
   
#Powerful -stack(arrays, axis=0, out=None, *, dtype=None, casting='same_kind')[source]

#General stack , axis=0, rowwise, axis=1, columnwise 
a = np.array([1, 2, 3])
b = np.array([2, 3, 4])
>>> np.stack((a, b))    #one example ie all features collected in 1D  then vstack= feature matrix
array([[1, 2, 3],
       [2, 3, 4]])

#each feature collected at many points in 1D  then hstack = feature matrix
>>> np.stack((a, b), axis=-1) #stack as column, -1 means last dimension 
array([[1, 2],
       [2, 3],
       [3, 4]])

#Join a sequence of arrays along a new axis.
arrays = [np.random.randn(3, 4) for _ in range(10)]

[a.shape for a in arrays]
#[(3, 4), (3, 4), (3, 4), (3, 4), (3, 4), (3, 4), (3, 4), (3, 4), (3, 4), (3, 4)]

np.stack(arrays, axis=0).shape
#(10, 3, 4)
np.stack(arrays, axis=1).shape
#(3, 10, 4)
np.stack(arrays, axis=2).shape
#(3, 4, 10)
       
##histogram(a, bins=10, range=None, density=None, weights=None)
All but the last (righthand-most) bin is half-open. 
In other words, if bins is:

[1, 2, 3, 4]

then the first bin is [1, 2) (including 1, but excluding 2) 
and the second [2, 3). The last bin, however, is [3, 4], which includes 4.
#Example 
np.histogram([1, 2, 1], bins=[0, 1, 2, 3])
#(array([0, 2, 1]), array([0, 1, 2, 3]))

np.histogram(np.arange(4), bins=np.arange(5), density=True)
#(array([0.25, 0.25, 0.25, 0.25]), array([0, 1, 2, 3, 4]))

np.histogram([[1, 2, 1], [1, 0, 1]], bins=[0,1,2,3])
#(array([1, 4, 1]), array([0, 1, 2, 3]))

#Example 
a = np.arange(5)
hist, bin_edges = np.histogram(a, density=True)
#bin_edges=Return the bin edges (length(hist)+1)

hist
#array([0.5, 0. , 0.5, 0. , 0. , 0.5, 0. , 0.5, 0. , 0.5])

hist.sum()
#2.4999999999999996

np.sum(hist * np.diff(bin_edges))
#1.0

#Example  
import matplotlib.pyplot as plt
rng = np.random.RandomState(10)  # deterministic random data
a = np.hstack((rng.normal(size=1000),
               rng.normal(loc=5, scale=2, size=1000)))

_ = plt.hist(a, bins='auto')  # arguments are passed to np.histogram

plt.title("Histogram with 'auto' bins")
Text(0.5, 1.0, "Histogram with 'auto' bins")

plt.show()

       
##numpy Matrix 
x = np.array([[1, 2], [3, 4]])
m = np.asmatrix(x)
x[0,0] = 5
>>> m
matrix([[5, 2],
        [3, 4]])
#matrix multiplication 
print(m * m) 

#3. Matrices have special attributes which make calculations easier. 
matrix.T 
    Returns the transpose of the matrix. 
matrix.H 
    Returns the (complex) conjugate transpose of self. 
matrix.I 
    Returns the (multiplicative) inverse of invertible self. 
matrix.A 
    Return self as an ndarray object. 
# Matrix creation from a string
>> a=np.mat('1 2 3; 4 5 3')
>>> print (a*a.T).I
[[ 0.2924 -0.1345]
 [-0.1345  0.0819]]


# Matrix creation from nested sequence
>>> np.mat([[1,5,10],[1.0,3,4j]])
matrix([[  1.+0.j,   5.+0.j,  10.+0.j],
        [  1.+0.j,   3.+0.j,   0.+4.j]])


#Matrix creation from an array
>>> np.mat(random.rand(3,3)).T
matrix([[ 0.7699,  0.7922,  0.3294],
        [ 0.2792,  0.0101,  0.9219],
        [ 0.3398,  0.7571,  0.8197]])

##More ndarray methods  
ndarray.sort([axis, kind, order]) 				
    Sort an array, in-place. 
#Example 
a = np.array([[1,4],[3,1]])
>>> np.sort(a)                # sort along the last axis, ie axis=1 for 2D, rowwise 
array([[1, 4],
       [1, 3]])
       
>>> np.sort(a, axis=None)     # sort the flattened array
array([1, 1, 3, 4])

>>> np.sort(a, axis=0)        # sort along the first axis/ columnwise ie [1,3] and [4,1] cols
array([[1, 1],
       [3, 4]])   
>>> np.sort(a, axis=1)      # sort along the rowwise ie [1,4] and [3,1] rows
array([[1, 4],
       [1, 3]])
    
ndarray.argsort([axis, kind, order]) 			
    Returns the indices that would sort this array. 
#Example 
x = np.array([3, 1, 2])
>>> np.argsort(x)
array([1, 2, 0])  #ie sorted array is x[1], x[2], x[0]

x = np.array([[0, 3], [2, 2]])
>>> x
array([[0, 3],
       [2, 2]])
       
>>> np.argsort(x, axis=0)  # sorts along first axis (down), columnwise 
array([[0, 1],
       [1, 0]])

>>> np.argsort(x, axis=1)  # sorts along last axis (across), rowwise 
array([[0, 1],
       [0, 1]])


#Other methods     
ndarray.argmax([axis, out]) 						
    Return indices of the maximum values along the given axis. 
ndarray.argmin([axis, out]) 						
    Return indices of the minimum values along the given axis of a. 
#Example 
a = np.arange(6).reshape(2,3)
>>> a
array([[0, 1, 2],
       [3, 4, 5]])
>>> np.argmax(a)
5
>>> np.argmax(a, axis=0) #columnwise 
array([1, 1, 1])
>>> np.argmax(a, axis=1) #rowwise 
array([2, 2])


ndarray.max(axis=None, out=None, keepdims=False)
ndarray.min(axis=None, out=None, keepdims=False)
    Return the maximum/minimum along a given axis.
    equivalent to numpy.amax, numpy.amin 
numpy.amax, amin(a, axis=None, out=None, keepdims=<class 'numpy._globals._NoValue'>)
    Return the maximum/minimum of an array or maximum along an axis.

#Example 
a = np.arange(4).reshape((2,2))
>>> a
array([[0, 1],
       [2, 3]])
       
>>> np.amin(a)           # Minimum of the flattened array
0

>>> np.amin(a, axis=0)   # Minima along the first axis(columnwise)
array([0, 1])

>>> np.amin(a, axis=1)   # Minima along the second axis(rowwise)
array([0, 2])  
    
       
  

##Splitting arrays
hsplit(ary, indices_or_sections) 	
    Split an array into multiple sub-arrays horizontally (column-wise).
#Example 
x = np.arange(16.0).reshape(4, 4)
>>> x
array([[  0.,   1.,   2.,   3.],
       [  4.,   5.,   6.,   7.],
       [  8.,   9.,  10.,  11.],
       [ 12.,  13.,  14.,  15.]])
>>> np.hsplit(x, 2)
[array([[  0.,   1.],
       [  4.,   5.],
       [  8.,   9.],
       [ 12.,  13.]]),
 array([[  2.,   3.],
       [  6.,   7.],
       [ 10.,  11.],
       [ 14.,  15.]])]



 
vsplit(ary, indices_or_sections) 	
    Split an array into multiple sub-arrays vertically (row-wise).

#Example 
x = np.arange(16.0).reshape(4, 4)
>>> x
array([[  0.,   1.,   2.,   3.],
       [  4.,   5.,   6.,   7.],
       [  8.,   9.,  10.,  11.],
       [ 12.,  13.,  14.,  15.]])
>>> np.vsplit(x, 2)
[array([[ 0.,  1.,  2.,  3.],
       [ 4.,  5.,  6.,  7.]]),
 array([[  8.,   9.,  10.,  11.],
       [ 12.,  13.,  14.,  15.]])]
 
 

##Adding and removing elements
delete(arr, obj[, axis]) 	
    Return a new array with sub-arrays along an axis deleted.
#Exmaple 
arr = np.array([[1,2,3,4], [5,6,7,8], [9,10,11,12]])
>>> arr
array([[ 1,  2,  3,  4],
       [ 5,  6,  7,  8],
       [ 9, 10, 11, 12]])
>>> np.delete(arr, 1, axis=0)#axis =0, row delete, 1=means which subarray to delete 
array([[ 1,  2,  3,  4],
       [ 9, 10, 11, 12]])
       
    
insert(arr, obj, values[, axis]) 	
    Insert values along the given axis before the given indices.
#Example 
a = np.array([[1, 1], [2, 2], [3, 3]])
>>> a
array([[1, 1],
       [2, 2],
       [3, 3]])
>>> np.insert(a, 1, 5, axis=1) #axis=1, insert column, before 1, value 5 
array([[1, 5, 1],
       [2, 5, 2],
       [3, 5, 3]])   
    
    
append(arr, values[, axis]) 	
    Append values to the end of an array.
#Example 
arr = np.array([1, 2, 3])
values = [[4, 5, 6], [7, 8, 9]]
>>> np.append(arr, values)
array([1, 2, 3, 4, 5, 6, 7, 8, 9])
>>> np.append([[1, 2, 3], [4, 5, 6]], [[7, 8, 9]], axis=0) #axis=0 , row append 
array([[1, 2, 3],
       [4, 5, 6],
       [7, 8, 9]])    
    
unique(ar[, return_index, return_inverse, ...]) 	
    Find the unique elements of an array.
#Example 
>>> np.unique([1, 1, 2, 2, 3, 3])
array([1, 2, 3])
>>> a = np.array([[1, 1], [2, 3]])
>>> np.unique(a)
array([1, 2, 3])
a = np.array([[1, 0, 0], [1, 0, 0], [2, 3, 4]])
>>> np.unique(a, axis=0)  #axis=0, rowwise 
array([[1, 0, 0], [2, 3, 4]])

##Numpy - Record Array(numpy.recarray) vs Structured array(numpy.ndarray with complex dtype)
#Arrays may have a data-types containing fields
#An example is [(x, int), (y, float)], where each entry in the array is a pair of (int, float). 
#Normally, access is eg  arr['x'] and arr['y']. 
#Record arrays allows access using arr.x and arr.y

#Structured Array 
x = np.array([(1.0, 2), (3.0, 4)], dtype=[('x', float), ('y', int)])
>>> x
array([(1.0, 2), (3.0, 4)],
      dtype=[('x', '<f8'), ('y', '<i4')])

>>> x['x']  #all 'x'
array([ 1.,  3.])

#Convert to  record array:
>>> x = x.view(np.recarray)
>>> x.x  #all 'x'
array([ 1.,  3.])

>>> x.y
array([2, 4])

#Create a new, empty two elements record array
#1st arg  , shape tuple(could be xD)
#=> , how many elements where each element is having dtype structure 
#does not initialize array 

# 1D array of two elements, each element having x,y,z
>>> r = np.recarray((2,), dtype=[('x', int), ('y', float), ('z', int)]) 
>>> r.x   #all x 
array([3, 1])
>>> r
rec.array([(3, 2.1219957915e-314, 3), (1, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
>>> r.x = np.array([0,0]) #assign to all x 
>>> r
rec.array([(0, 2.1219957915e-314, 3), (0, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
>>> r.y[0] = 500  #first y 
>>> r
rec.array([(0, 500.0, 3), (0, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
>>> r.z = [2,2]
>>> r
rec.array([(0, 500.0, 2), (0, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
          
>>> r['x']
array([0, 0])

#The recommended way to store and load data:
>>> np.save(fname, r)
>>> np.load(fname + '.npy')
rec.array([(0, 500.0, 2), (0, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
          
#loadtxt 
from io import StringIO   # StringIO behaves like a file object
c = StringIO("0 1\n2 3")
>>> np.loadtxt(c)
array([[ 0.,  1.],
       [ 2.,  3.]])

#fromstring- only one dimension 
>>> np.fromstring('1 2', dtype=int, sep=' ')
array([1, 2])

##numpy.select(condlist, choicelist, default=0)
#if x > 3, then 0, if x>=0 , then x+2 else default =0 
>>> np.select([x > 3, x >= 0], [0, x+2])
array([0, 0, 2, 3, 4, 2, 2, 5, 0, 0, 0, 0, 0])

##numpy.where(condition[, x, y])
#condition : array_like, bool, When True, yield x, otherwise yield y.
#x, y : array_like, optional
#out : ndarray or tuple of ndarrays
#If both x and y are specified, the output array contains elements of x 
#where condition is True, and elements from y elsewhere.
#If only condition is given, return the tuple of indices where condition is True.
 
>>> x = np.arange(9.).reshape(3, 3)
>>> x
array([[ 0.,  1.,  2.],
       [ 3.,  4.,  5.],
       [ 6.,  7.,  8.]])
>>> np.where( x > 5 )
(array([2, 2, 2]), array([0, 1, 2]))     # indices [2,0], [2,1], [2,2] are true
>>> x[np.where( x > 3.0 )]               # Note: result is 1D.
array([ 4.,  5.,  6.,  7.,  8.])
>>> np.where(x < 5, x, -1)               # Note: broadcasting.
array([[ 0.,  1.,  2.],
       [ 3.,  4., -1.],
       [-1., -1., -1.]])

##Datetimes and Timedeltas - subclass of numpy.ndarray 
#Starting in NumPy 1.7, there are core array data types which natively support datetime functionality. 
#The data type is called 'datetime64'

#A simple ISO date: YYY-MM-DD
>>> np.datetime64('2005-02-25')
numpy.datetime64('2005-02-25')


#Using months for the unit:
>>> np.datetime64('2005-02')
numpy.datetime64('2005-02')


#Specifying just the month, but forcing a 'days unit:
>>> np.datetime64('2005-02', 'D')
numpy.datetime64('2005-02-01')


#From a date and time:
>>> np.datetime64('2005-02-25T03:30')
numpy.datetime64('2005-02-25T03:30')


>>> np.array(['2007-07-13', '2006-01-13', '2010-08-13'], dtype='datetime64')
array(['2007-07-13', '2006-01-13', '2010-08-13'], dtype='datetime64[D]')

>>> np.array(['2001-01-01T12:00', '2002-02-03T13:56:03.172'], dtype='datetime64')
array(['2001-01-01T12:00:00.000-0600', '2002-02-03T13:56:03.172-0600'], dtype='datetime64[ms]')


#Using arange - All the dates for one month:
>>> np.arange('2005-02', '2005-03', dtype='datetime64[D]')
array(['2005-02-01', '2005-02-02', '2005-02-03', '2005-02-04',
       '2005-02-05', '2005-02-06', '2005-02-07', '2005-02-08',
       '2005-02-09', '2005-02-10', '2005-02-11', '2005-02-12',
       '2005-02-13', '2005-02-14', '2005-02-15', '2005-02-16',
       '2005-02-17', '2005-02-18', '2005-02-19', '2005-02-20',
       '2005-02-21', '2005-02-22', '2005-02-23', '2005-02-24',
       '2005-02-25', '2005-02-26', '2005-02-27', '2005-02-28'],
       dtype='datetime64[D]')
#Code 
Y       year       
M       month        
W       week       
D       day        
h       hour       
m       minute     
s       second     
ms      millisecond
us      microsecond
ns      nanosecond 
ps      picosecond 
fs      femtosecond
as      attosecond 
    
#The datetime object represents a single moment in time, 
#if two datetimes have different units,
>>> np.datetime64('2005') == np.datetime64('2005-01-01')
True
>>> np.datetime64('2010-03-14T15Z') == np.datetime64('2010-03-14T15:00:00.00Z')
True


##Datetime and Timedelta Arithmetic
#NumPy allows the subtraction of two Datetime values, 
#an operation which produces a number with a time unit. 

>>> np.datetime64('2009-01-01') - np.datetime64('2008-01-01')
numpy.timedelta64(366,'D')

>>> np.datetime64('2009') + np.timedelta64(20, 'D')
numpy.datetime64('2009-01-21')



>>> np.datetime64('2011-06-15T00:00') + np.timedelta64(12, 'h')
numpy.datetime64('2011-06-15T12:00-0500')

>>> np.timedelta64(1,'W') / np.timedelta64(1,'D')
7.0


#There are two Timedelta units ('Y', years and 'M,' months) 
#which are treated specially,
#While a timedelta day unit is equivalent to 24 hours, there is no way to convert a month unit into days, 
#because different months have different numbers of days
>>> a = np.timedelta64(1, 'Y')

#converts to Month 
>>> np.timedelta64(a, 'M')
numpy.timedelta64(12,'M')
#but can not be converted to Days 
>>> np.timedelta64(a, 'D')
Traceback (most recent call last):  
File "<stdin>", line 1, in <module>
TypeError: Cannot cast NumPy timedelta64 scalar from metadata [Y] to [D] according to the rule 'same_kind'

#conversion is done as belows - use .astype()
>>> x = np.timedelta64(2069211000000000, 'ns')
>>> days = x.astype('timedelta64[D]')
>>> days / np.timedelta64(1, 'D')
23
#from python datetime 
>>> from datetime import datetime
>>> import numpy as np
>>> dt = datetime.utcnow()
>>> dt
datetime.datetime(2012, 12, 4, 19, 51, 25, 362455)
>>> dt64 = np.datetime64(dt)
>>> ts = (dt64 - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
>>> ts
1354650685.3624549
>>> datetime.utcfromtimestamp(ts)
datetime.datetime(2012, 12, 4, 19, 51, 25, 362455)

>>> np.datetime64('2002-06-28T01:00:00.000000000+0100').astype(datetime)
1025222400000000000L        
        
 
##Some Example of numpy applications 
#Solve the system of equations 3 * x0 + x1 = 9 and x0 + 2 * x1 = 8:

a = np.array([[3,1], [1,2]])
b = np.array([9,8])
x = np.linalg.solve(a, b)
>>> x
array([ 2.,  3.])
#Check that the solution is correct:
>>> np.allclose(np.dot(a, x), b)
True

from numpy.linalg import inv
a = np.array([[1., 2.], [3., 4.]])
ainv = inv(a)
>>> np.allclose(np.dot(a, ainv), np.eye(2))
True
>>> np.allclose(np.dot(ainv, a), np.eye(2))
True
 

##*numpy.polyfit(x, y, deg, rcond=None, full=False, w=None, cov=False)
#Least squares polynomial fit.
#Fit a polynomial p(x) = p[0] * x**deg + ... + p[deg] of degree deg to points (x, y). 
#Returns a vector of coefficients p that minimises the squared error.


x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])
z = np.polyfit(x, y, 3)  #Polynomial coefficients, highest power first,0th index 
>>> z
array([ 0.08703704, -0.81349206,  1.69312169, -0.03968254])
>>> p = np.poly1d(z) #highest power first,0th index 
>>> print(p)
         3          2
0.08704 x - 0.8135 x + 1.693 x - 0.03968
>>> p(0.5)   #evaluate 
0.6143849206349179
>>> p.r #roots
array([6.24151464, 3.08128307, 0.02370685])
#+,-,*,**,/ are overloaded , np.methods() can be called 
>> p**2
poly1d([ 7.57544582e-03, -1.41607878e-01,  9.56497928e-01, -2.76158982e+00,
       2.93122393e+00, -1.34374738e-01,  1.57470396e-03])
>> np.sin(p)
array([ 0.08692719, -0.72669053,  0.99252758, -0.03967213])


#High-order polynomials may oscillate wildly:
p30 = np.poly1d(np.polyfit(x, y, 30))
>>> p30(4)
-0.80000000000000204

#plot 
import matplotlib.pyplot as plt
xp = np.linspace(-2, 6, 100)
_ = plt.plot(x, y, '.', xp, p(xp), '-', xp, p30(xp), '--')
plt.ylim(-2,2)
plt.show()

 
###Numpy few Other Operations  -- ADVANCED 
#Execute - 0.1.numpy_operations.py


###Numpy with Matplotlib - Minimizing a mathematical function -- ADVANCED 

import numpy as np
import scipy as sp
import scipy.optimize as opt
import matplotlib.pyplot as plt
%matplotlib inline

#Simple function 
def f(x):
    return 1 - np.sin(x) / x

#Plot (with 1000 samples):
x = np.linspace(-20., 20., 1000)
y = f(x)

fig, ax = plt.subplots(1, 1, figsize=(5, 5))
ax.plot(x, y)

#The scipy.optimize module comes with many function minimization routines
x0 = 3
xmin = opt.minimize(f, x0).x

#Draw them 
fig, ax = plt.subplots(1, 1, figsize=(5, 5))
ax.plot(x, y)
ax.scatter(x0, f(x0), marker='o', s=300) 
ax.scatter(xmin, f(xmin), marker='v', s=300,  zorder=20) #s for size, zorder higher more front 
ax.set_xlim(-20, 20)

#if we start from an initial point that is further away from the actual global minimum
# the algorithm converges towards a local minimum only:
x0 = 10
xmin = opt.minimize(f, x0).x

#Draw
fig, ax = plt.subplots(1, 1, figsize=(5, 5))
ax.plot(x, y)
ax.scatter(x0, f(x0), marker='o', s=300)
ax.scatter(xmin, f(xmin), marker='v', s=300,zorder=20)
ax.set_xlim(-20, 20)


#the BFGS algorithm is efficient at finding local minima
# but not necessarily global minima, especially on complicated  or noisy objective functions. 
# A general strategy to overcome this problem is to combine such algorithms 
# with an exploratory grid search on the initial points. 
# Another option is to use a different class of algorithms based on heuristics 
# and stochastic methods. An example is the basin-hopping algorithm:

# We use 1000 iterations.
xmin = opt.basinhopping(f, x0, 1000).x

#draw
fig, ax = plt.subplots(1, 1, figsize=(5, 5))
ax.plot(x, y)
ax.scatter(x0, f(x0), marker='o', s=300)
ax.scatter(xmin, f(xmin), marker='v', s=300,  zorder=20)
ax.set_xlim(-20, 20)

#reference 
The scipy.optimize reference documentation available at http://docs.scipy.org/doc/scipy/reference/optimize.html
Documentation of the basin-hopping algorithm available at http://scipy.github.io/devdocs/generated/scipy.optimize.basinhopping.html
A lecture on mathematical optimization with SciPy available at http://scipy-lectures.github.io/advanced/mathematical_optimization/
Definition of the gradient on Wikipedia, available at https://en.wikipedia.org/wiki/Gradient
Newton's method on Wikipedia, available at https://en.wikipedia.org/wiki/Newton%27s_method_in_optimization
Quasi-Newton methods on Wikipedia, available at https://en.wikipedia.org/wiki/Quasi-Newton_method
Metaheuristics for function minimization on Wikipedia, available at https://en.wikipedia.org/wiki/Metaheuristic
The CMA-ES algorithm described at https://en.wikipedia.org/wiki/CMA-ES
A Python implementation of CMA-ES available at http://www.lri.fr/~hansen/cmaes_inmatlab.html#python

 
###Plotting using matplotlib 
#There are three layers to the matplotlib API. 
1.The matplotlib.backend_bases.FigureCanvas 
    is the area  onto which the figure is drawn, 
2.The matplotlib.backend_bases.Renderer 
    is the object  which knows how to draw on the FigureCanvas, 
    The FigureCanvas and Renderer handle all the details of talking 
    to user interface toolkits like wxPython or drawing languages like PostScript®
3.The matplotlib.artist.Artist 
    is the object that knows how to use a renderer to paint onto the canvas. 
    The Artist handles all the high level constructs 
    like representing and laying out the figure, text, and lines. 
    The typical user will spend 95% of their time working with the Artists.  
    There are two types of Artists: primitives and containers. 
    #check class hierarchy https://matplotlib.org/stable/api/artist_api.html
    The primitives represent the standard graphical objects 
    eg  Line2D, Rectangle, Text, AxesImage, etc.(subclass of Artist)
    and the containers are places to put primitives (Axis, Axes and Figure)(subclass of Artist) 
Good Tutorials 
https://matplotlib.org/stable/tutorials/introductory/lifecycle.html

#Example
import matplotlib.pyplot as plt
#x,y , red and line 
plt.plot([1,2,3,4], [1,2,3,4],'r-', lw=2)                #y values , x is taken as 0,1,2,3
plt.xlabel('x axis label', fontsize=14, color='red')
plt.ylabel('y axis label')
plt.title('My first plot ')
plt.legend(['Straight Line'], loc='best')
plt.grid(True)
plt.yscale('linear') #log, symlog, logit
plt.xscale('linear')
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.axis.html
plt.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
#or 
plt.ylim(0, 4)
plt.xlim(0, 10)

#x,y this is in data coordinates, which gets dynamically adjusted when we add data 
#default is 0 to 1 
plt.xlim()#(0.0, 1.0)
 plt.ylim()#(0.0, 1.0)
plt.text(2, 2, r'$\mu=100,\ \sigma=15$')  #Any text  or  '$any LaTex code$'

#for axis coords (0,0 is lower-left and 1,1 is upper-right)
#which is constant irrespective of adding data , use ax.transAxes
#for figure, similarly fig.transFigure which (0,0 is lower-left and 1,1 is upper-right)
plt.text(0.5, 0.5, 'matplotlib', horizontalalignment='center',
            verticalalignment='center', transform=ax.transAxes)

#put a rectangular box around the text - data cordinate system 
text(4,4, "Another text", bbox=dict(facecolor='red', alpha=0.5))

#https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.annotate.html
#text with arrow - cordinates is determined by xycoords, default data 
plt.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
plt.show()

#plt.show()
#above is blocking,
#non blocking 
#plt.draw()
#plt.pause(0.01)
#plt.close()



##With multiple x, y pairs in same plot
import numpy as np
import matplotlib.pyplot as plt

# evenly sampled time at 200ms intervals
t = np.arange(0., 5., 0.2)

# red solid, blue dashed and green triangles
plt.plot(t, t, 'r-', t, t**2, 'b--', t, t**3, 'g^')
plt.show()

#character      description 
'-'             solid line style 
'--'            dashed line style 
'-.'            dash-dot line style 
':'             dotted line style 
'.'             point marker 
','             pixel marker 
'o'             circle marker 
'v'             triangle_down marker 
'^'             triangle_up marker 
'<'             triangle_left marker 
'>'             triangle_right marker 
'1'             tri_down marker 
'2'             tri_up marker 
'3'             tri_left marker 
'4'             tri_right marker 
's'             square marker 
'p'             pentagon marker 
'*'             star marker 
'h'             hexagon1 marker 
'H'             hexagon2 marker 
'+'             plus marker 
'x'             x marker 
'D'             diamond marker 
'd'             thin_diamond marker 
'|'             vline marker 
'_'             hline marker 

#character   color 
'b'         blue 
'g'         green 
'r'         red 
'c'         cyan 
'm'         magenta 
'y'         yellow 
'k'         black 
'w'         white

#few Line2D properties that can be passsed to  plt.plot or ax.plot or other plot functions 
#as keyword arg passing 
#To get a list of settable line properties, call the setp() function with a line or lines as argument
lines = plt.plot([1, 2, 3])
plt.setp(lines) 
#Option-1 Use keyword args:
plt.plot(t, t, linewidth=2.0)

#Option-2: Use the setter methods of Line2D
line1, line2 = plt.plot(t, t**2, t, t**3 ) #x1,y1,x2,y2
line1.set_antialiased(False) # turn off antialising

#Option-3: Use the setp() command
lines = plt.plot(t, t**2, t, t**3 )
# use keyword args
plt.setp(lines, color='r', linewidth=2.0)
# or MATLAB style string value pairs
plt.setp(lines, 'color', 'r', 'linewidth', 2.0)

#Main keyword 
color or c              any matplotlib color 
label                   string or anything printable with '%s' conversion. 
linestyle or ls         ['solid' | 'dashed', 'dashdot', 'dotted' | (offset, on-off-dash-seq) | '-' | '--' | '-.' | ':' | 'None' | ' ' | ''] 
linewidth or lw         float value in points 
#Other Keyword
alpha                   float (0.0 transparent through 1.0 opaque) 
animated                [True | False] 
antialiased or aa       [True | False] 
clip_box                a matplotlib.transforms.Bbox instance 
clip_on                 [True | False] 
dash_capstyle           ['butt' | 'round' | 'projecting'] 
dash_joinstyle          ['miter' | 'round' | 'bevel'] 
drawstyle               ['default' | 'steps' | 'steps-pre' | 'steps-mid' | 'steps-post'] 
fillstyle               ['full' | 'left' | 'right' | 'bottom' | 'top' | 'none'] 
marker                  A valid marker style 
markeredgecolor or mec  any matplotlib color 
markeredgewidth or mew  float value in points 
markerfacecolor or mfc  any matplotlib color 
markersize or ms        float 
solid_capstyle          ['butt' | 'round' | 'projecting'] 
solid_joinstyle         ['miter' | 'round' | 'bevel'] 
visible                 [True | False] 
zorder                  any number 


##Specifying matplotlib.colors
#Only For the below basic colors, use a single letter
b: blue,g: green,r: red,c: cyan,m: magenta,y: yellow,k: black w: white

#All examples of colors 
#https://matplotlib.org/2.0.2/examples/color/named_colors.html

#Gray shades can be given as a string encoding a float in the 0-1 range, e.g.:
color = '0.75'

#can specify the color using an html hex string(RGB or RGBA), as in:
color = '#eeefff' or '#0F0F0F0F'

#or you can pass an R , G , B tuple, or RGBA 
#where each of R , G , B are in the range [0,1].
color = (0.5,0.5,0.5) or (0.1, 0.2, 0.5, 0.3));

#Or use legal html names for colors, like 'red, 'burlywood and 'chartreuse'
#https://www.w3schools.com/tags/ref_colornames.asp
color = 'burlywood'

##Matplotlib - The matplotlibrc configuration file
#matplotlib uses matplotlibrc(dir= . , 
then $HOME/.matplotlib, then $PYTHON_INSTALL/matplotlib/mpl-data)

>>> import matplotlib
>>> matplotlib.matplotlib_fname()
'/home/foo/.config/matplotlib/matplotlibrc'
#all kinds of properties, which we call rc settings or rc parameters 
#https://matplotlib.org/stable/tutorials/introductory/customizing.html

#Dynamic rc settings
All of the rc settings are stored in a dictionary-like variable called 
matplotlib.rcParams, which is global to the matplotlib package. 

#rcParams can be modified directly, for example:
import matplotlib as mpl
mpl.rcParams['lines.linewidth'] = 2
mpl.rcParams['lines.color'] = 'r'

#Or using rc()
import matplotlib as mpl
mpl.rc('lines', linewidth=2, color='r')
# matplotlib.rcdefaults() command will restore the standard matplotlib default settings.

##Using style sheets
#There are a number of pre-defined styles provided by matplotlib
import matplotlib.pyplot as plt
plt.style.use('ggplot')

#To list all available styles, use:
print(plt.style.available)
#Can create own, check https://matplotlib.org/users/customizing.html

##Figure size in inches (default)
import matplotlib.pyplot as plt
text_kwargs = dict(ha='center', va='center', fontsize=28, color='C1')

plt.subplots(figsize=(6, 2)) #in inches
# x, y in data coordinate, which is 0 to 1 in both x and axis 
#gets dynamically updated when we add new data 
plt.text(0.5, 0.5, '6 inches x 2 inches', **text_kwargs)
plt.show()

#Figure size in centimeter
cm = 1/2.54  # centimeters in inches
plt.subplots(figsize=(15*cm, 5*cm))
plt.text(0.5, 0.5, '15cm x 5cm', **text_kwargs)
plt.show()

#Figure size in pixel - default rcParams['figure.dpi'] = 100,
#this does not work well for the matplotlib inline backend
px = 1/plt.rcParams['figure.dpi']  # pixel in inches
plt.subplots(figsize=(600*px, 200*px))
plt.text(0.5, 0.5, '600px x 200px', **text_kwargs)
plt.show()



##Colormap - list of colors with common themes
Generally used for 3d plots eg contour plots with different shades
(shade relations could be Sequential, Diverging, Cyclic, misc called Qualitative)
Matplotlib has a number of built-in colormaps accessible via matplotlib.colormaps
https://matplotlib.org/stable/gallery/color/colormap_reference.html
https://matplotlib.org/stable/tutorials/colors/colormaps.html

#Use 
from matplotlib import cm 
select by cmap=plt.get_cmap(string_name) 
or cmap=cm.Dark2




## Working with multiple figures and axes
Plots may contain many Figure, 
each figure is one display window
each Figure may contain many Axes (partition of window)
Figure contains set/get of figure related attributes 
eg get_figheight(),get_figwidth()
Axes contains plot() and set/get of xlabel, ylabel etc

Figure also may contain subfigure (subfigure is new in v3.4,)
class matplotlib.figure.SubFigure(parent, subplotspec, *, facecolor=None, edgecolor=None, 
linewidth=0.0, frameon=None, **kwargs)
    Added by  
    Figure.add_subfigure 
    or SubFigure.add_subfigure, 
    or SubFigure.subfigures(nrows=1, ncols=1, squeeze=True, wspace=None, hspace=None, 
    width_ratios=None, height_ratios=None

#For example the following puts two subfigures side-by-side:
fig = plt.figure()
sfigs = fig.subfigures(1, 2)
axsL = sfigs[0].subplots(1, 2)
axsR = sfigs[1].subplots(2, 1)



#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplots.html 
##Option-1 
#note subplots(..) returns (figure,axes)
#where axes is numpy.ndarray, hence access like axes[0,0], axes[0,1],... for complex subplots 
#for simple , can destructure immediately
t = np.arange(0., 5., 0.2)

#sharex=True, means only one X ticks value printing , similarly for sharey
#figsize : (float, float), optional, default: None
#width, height in inches. 
#If not provided, defaults to rcParams["figure.figsize"] = [6.4, 4.8].

figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, sharex=False, sharey=True, figsize=(15,15))
ax1.plot(t, t, 'r-')  
ax1.set_title('Sharing Y axis')
ax2.scatter(t, t**2, color='b')
#then show 
plt.show()


##Option-2 
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.figure.html#matplotlib.pyplot.figure 
fig = plt.figure(figsize=(10,10), edgecolor='b', tight_layout=True)        #create a figure 

ax1 = fig.add_subplot(211)               # nrows, ncols, which_Axes_tomake_current ie 1  
x = np.linspace(0, 2*np.pi, 400)
y = np.sin(x**2)
ax1.plot(x,y,'r-')  
ax2 = fig.add_subplot(212)
ax2.plot(x,y**2,'b--') 
ax2.plot(x,y**3,'go') 
#then show 
plt.show()


##Option-3 
#All plotting commands apply to the current axes.
#figure means one window 
x = np.linspace(0, 2*np.pi, 400)
y = np.sin(x**2)

plt.figure(1)           # the first figure
plt.subplot(211)        # nrows,ncols, which_Axes_tomake_current ie 1                             
plt.plot(x,y,'r-')      # all plot/scatter/box/hist etc goes subplot 1 
plt.subplot(212)        # nrows,ncols, which_Axes_tomake_current ie 2
plt.plot(x,y**2,'b--')  # all plot/scatter/box/hist etc goes subplot 2

plt.figure(2)           # a second figure, sets to this figure, all plot commands go here
plt.plot(x,y**3,'go')   # creates a subplot(111) by default

plt.figure(1)                # figure 1 current; subplot(212) still current
plt.subplot(211)             # make subplot(211) in figure1 current
plt.title('Easy as 1, 2, 3') # subplot 211 title
#then show 
plt.show()



#The function gca() returns the current axes (a matplotlib.axes.Axes instance ),
#and gcf() returns the current figure (matplotlib.figure.Figure instance ).
#clear the current figure with clf() and the current axes with cla()
ax = plt.gca()  #Get the current Axes instance on the current figure 
fig = plt.gcf()  #Get a reference to the current figure.
ax.cla() #clear 
fig.clf() # clear 


##Option-4, advanced 
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplot2grid.html


#3x3 grid , 
fig1= plt.figure(1)
ax1 = plt.subplot2grid((3,3), (0,0), colspan=3) #for (0,0), 3 columns 
ax2 = plt.subplot2grid((3,3), (1,0), colspan=2) #for (1,0), 2 columns 
ax3 = plt.subplot2grid((3,3), (1, 2), rowspan=2) #for (1,2), 2 rows 
ax4 = plt.subplot2grid((3,3), (2, 0))  #one row and col
ax5 = plt.subplot2grid((3,3), (2, 1))   #one row and col 
#Now use ax1.plot() to direct commands to ax1, etc
x = np.linspace(-5,5,20)
y = np.sin(x)
ax1.plot(x,y,"r-")
ax2.plot(x,y,"b-")
ax3.plot(x,y,"r-")
ax4.plot(x,y,"b-")
plt.tight_layout() #tight_layout automatically adjusts subplot params so that the subplot(s) fits in to the figure area
plt.show()

##Few methods of subplots 
subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
    Adjust the subplot layout parameters.
    initial values are given by rcParams["figure.subplot.[name]"].
    Parameters:
        left, right, bottom, top, float
            The position of the left, bottom, right, top, edge of the subplots, 
            as a fraction of the figure width or  figure height
        wspace hspace, float
            The width of the padding between subplots, as a fraction of the average Axes width.
            OR The height of the padding between subplots, 
            as a fraction of the average Axes height.
    #Example with colormaps 
    import numpy as np
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from colorspacious import cspace_converter

    cmaps = {}

    gradient = np.linspace(0, 1, 256)
    gradient = np.vstack((gradient, gradient))


    def plot_color_gradients(category, cmap_list):
        # Create figure and adjust figure height to number of colormaps
        nrows = len(cmap_list)
        figh = 0.35 + 0.15 + (nrows + (nrows - 1) * 0.1) * 0.22
        fig, axs = plt.subplots(nrows=nrows + 1, figsize=(6.4, figh))
        fig.subplots_adjust(top=1 - 0.35 / figh, bottom=0.15 / figh,
                            left=0.2, right=0.99)
        axs[0].set_title(f'{category} colormaps', fontsize=14)

        for ax, name in zip(axs, cmap_list):
            ax.imshow(gradient, aspect='auto', cmap=mpl.colormaps[name])
            ax.text(-0.01, 0.5, name, va='center', ha='right', fontsize=10,
                    transform=ax.transAxes)

        # Turn off *all* ticks & spines, not just the ones with colormaps.
        for ax in axs:
            ax.set_axis_off()

        # Save colormap list for later.
        cmaps[category] = cmap_list

    #Usage 
    plot_color_gradients('Perceptually Uniform Sequential',
                         ['viridis', 'plasma', 'inferno', 'magma', 'cividis'])
suptitle(t, **kwargs)
    Add a centered suptitle to the figure.
supxlabel(t, **kwargs)
    Add a centered supxlabel to the figure.
supylabel(t, **kwargs)
    Add a centered supylabel to the figure.
text(x, y, s, fontdict=None, **kwargs)
    x,y in figure cordinates 
tight_layout(*, pad=1.08, h_pad=None, w_pad=None, rect=None) **Important method
    Adjust the padding between and around subplots.
    To exclude an artist on the Axes from the bounding box calculation 
    that determines the subplot parameters (i.e. legend, or annotation), 
    set a.set_in_layout(False) for that artist.
    
    Note that matplotlib.pyplot.tight_layout() will only adjust the subplot params 
    when it is called. In order to perform this adjustment each time the figure is redrawn, 
    you can call fig.set_tight_layout(True)
    or, equivalently, set rcParams["figure.autolayout"] (default: False) to True
    
    When you have multiple subplots, often you see labels of different axes overlapping each other.
    Use tight_layout 
    #Example 
    import matplotlib.pyplot as plt
    import numpy as np

    plt.rcParams['savefig.facecolor'] = "0.8"
    def example_plot(ax, fontsize=12):
        ax.plot([1, 2])
        ax.locator_params(nbins=3)
        ax.set_xlabel('x-label', fontsize=fontsize)
        ax.set_ylabel('y-label', fontsize=fontsize)
        ax.set_title('Title', fontsize=fontsize)

    plt.close('all')
    fig, ax = plt.subplots()
    example_plot(ax, fontsize=24)

    #To prevent this, the location of axes needs to be adjusted. 
    fig, ax = plt.subplots()
    example_plot(ax, fontsize=24)
    plt.tight_layout()



##Styling with cycler
from cycler import cycler
import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 2 * np.pi, 50)
offsets = np.linspace(0, 2 * np.pi, 4, endpoint=False)
yy = np.transpose([np.sin(x + phi) for phi in offsets])

print(yy.shape)#(50, 4)

#So yy[:, i] will give  the i-th offset sine curve

default_cycler = (cycler(color=['r', 'g', 'b', 'y']) +
                  cycler(linestyle=['-', '--', ':', '-.']))

plt.rc('lines', linewidth=4)
plt.rc('axes', prop_cycle=default_cycler)

custom_cycler = (cycler(color=['c', 'm', 'y', 'k']) +
                 cycler(lw=[1, 2, 3, 4]))

fig, (ax0, ax1) = plt.subplots(nrows=2)
ax0.plot(yy)
ax0.set_title('Set default color cycle to rgby') #default from above setting of rc params
ax1.set_prop_cycle(custom_cycler)
ax1.plot(yy)
ax1.set_title('Set axes color cycle to cmyk')

# Add a bit more space between the two plots.
fig.subplots_adjust(hspace=0.3)
plt.show()



##Constrained Layout Guide
#https://matplotlib.org/stable/tutorials/intermediate/constrainedlayout_guide.html

constrained_layout automatically adjusts subplots and decorations like legends 
and colorbars so that they fit in the figure window while still preserving,
 as best they can, the logical layout requested by the user.

constrained_layout is similar to tight_layout, 
but uses a constraint solver to determine the size of axes that allows them to fit.

constrained_layout typically needs to be activated before any axes are added to a figure. 
    using the respective argument to subplots() or figure(), e.g.:
    plt.subplots(layout="constrained")
    
    activate it via rcParams, like:
    plt.rcParams['figure.constrained_layout.use'] = True


##Few Axes methods  , many are available on plt. as well 
#Note below relevant methods withour arg or get_*() gives current value 
#eg xlim() gives current xlimit , get_xlabel() gives current xlabel 

ax.set_xlabel('x axis label')
ax.set_ylabel('y axis label')
ax.set_title('Simple plot')
ax.legend(['Sine', 'Cosine'])

ax.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
ax.set_axis_off() #Turn off the axis. 
ax.set_axis_on()  # Turn on the axis. 

ax.text(60, .025, r'$\mu=100,\ \sigma=15$')  #Any text 
ax.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
ax.arrow(x, y, dx, dy, **kwargs)    #Add an arrow to the axes.
ax.grid(b=True|False, color='r', linestyle='-', linewidth=2)
ax.set_label(s)       #Set the label to s for auto legend.
 
ax.set_ylim(-2,2)
ax.set_xlim(-2,2)
ax.set_yscale('linear') #log, symlog, logit
ax.set_xscale('linear')
ax.set_visible(b)     #Set the artist's visibility.
ax.set_zorder(level)  #Set the zorder for the artist. Artists with lower zorder values are drawn first.

ax.set_xticks(ticks, minor=False)     #Set the x ticks with list of ticks
ax.set_xticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the x-tick labels with list of string labels.
ax.set_yticks(ticks, minor=False)#Set the y ticks with list of ticks
ax.set_yticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the y-tick labels with list of strings labels.

ax.xaxis_date(tz=None)  #Sets up x-axis ticks and labels that treat the x data as dates.
ax.yaxis_date(tz=None)  #Sets up y-axis ticks and labels that treat the y data as dates.
ax.minorticks_off()     #Remove minor ticks from the axes.
ax.minorticks_on()      #Remove minor ticks from the axes.
new_ax = ax.twinx()     #Create a twin Axes sharing the xaxis
new_ax = ax.twiny()     #Create a twin Axes sharing the yaxis



##Saving to a file
#output format is deduced from the extension of the filename
matplotlib.pyplot.savefig(file_name)


##To display image 
https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.imshow.html#matplotlib.axes.Axes.imshow
matplotlib.pyplot.imread(fname, format=None)
    default png file 
    Uses PIL.Image.open(fp, mode='r', formats=None)
        fp - A filename (string), pathlib.Path object or a file object.
        eg 
        from PIL import Image
        with Image.open("hopper.jpg") as im:
            im.rotate(45).show()
Axes.imshow(X, cmap=None, norm=None, *, aspect=None,...)   
    X  array-like or PIL image
    Supported (M, N): an image with scalar data. 
    The values are mapped to colors using normalization and a colormap. 
    (M, N, 3): an image with RGB values (0-1 float or 0-255 int).
    (M, N, 4): an image with RGBA values (0-1 float or 0-255 int), i.e. including transparency.

#eg-Clipping images with patches
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.cbook as cbook


with cbook.get_sample_data('grace_hopper.jpg') as image_file:
    image = plt.imread(image_file)

fig, ax = plt.subplots()
im = ax.imshow(image)
patch = patches.Circle((260, 200), radius=200, transform=ax.transData)
im.set_clip_path(patch)

ax.axis('off')
plt.show()


##Autoscaling
Use manually - eg  ax.set_xlim(xmin, xmax)) 
or Matplotlib can set them automatically based on the data already on the axes. 

#Example 
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

x = np.linspace(-2 * np.pi, 2 * np.pi, 100)
y = np.sinc(x)

fig, ax = plt.subplots()
ax.plot(x, y)

#default margins 
print(ax.margins())
#(0.05, 0.05)

#magins can be inrage of (-0.5, Inf)
#where negative margins clips data. Using a single number for margins affects both axes
#eg increase 
ax.margins(0.2, 0.2)

#By default, the limits are recalculated every time you add a new curve to the plot:
fig, ax = plt.subplots(ncols=2, figsize=(12, 8))
ax[0].plot(x, y)
ax[0].set_title("Single curve")
ax[1].plot(x, y)
ax[1].plot(x * 2.0, y)
ax[1].set_title("Two curves")

#To disable autoscaling is to manually set the axis limit
#eg To see only a part of the data in greater detail. 
#Setting the xlim persists even if we add more curves to the data. 
#To recalculate the new limits calling Axes.autoscale will toggle the functionality manually.

fig, ax = plt.subplots(ncols=2, figsize=(12, 8))
ax[0].plot(x, y)
ax[0].set_xlim(left=-1, right=1)
ax[0].plot(x + np.pi * 0.5, y)
ax[0].set_title("set_xlim(left=-1, right=1)\n")
ax[1].plot(x, y)
ax[1].set_xlim(left=-1, right=1)
ax[1].plot(x + np.pi * 0.5, y)
ax[1].autoscale()
ax[1].set_title("set_xlim(left=-1, right=1)\nautoscale()")

print(ax[0].get_autoscale_on())  # False means disabled
print(ax[1].get_autoscale_on())  # True means enabled -> recalculated

#Arguments of the autoscale function give us precise control over the process of autoscaling. 
#A combination of arguments enable, and axis sets the autoscaling feature 
#for the selected axis (or both). 
#The argument tight sets the margin of the selected axis to zero. 
#To preserve settings of either enable or tight you can set the opposite one to None, 
#that way it should not be modified. 
#However, setting enable to None and tight to True affects both axes regardless of the axis argument.

fig, ax = plt.subplots()
ax.plot(x, y)
ax.margins(0.2, 0.2)
ax.autoscale(enable=None, axis="x", tight=True)

print(ax.margins())
#(0, 0)

#Autoscale works out of the box for all lines, patches, and images added to the axes. 
#One of the artists that it won't work with is a Collection. 
#After adding a collection to the axes, one has to manually trigger the autoscale_view() 
#to recalculate axes limits.

fig, ax = plt.subplots()
collection = mpl.collections.StarPolygonCollection(
    5, rotation=0, sizes=(250,),  # five point star, zero angle, size 250px
    offsets=np.column_stack([x, y]),  # Set the positions
    offset_transform=ax.transData,  # Propagate transformations of the Axes
)
ax.add_collection(collection)
ax.autoscale_view()


#Sticky edges
There are plot elements (Artists) that are usually used without margins. 
e.g. created with Axes.imshow) are not considered 
in the margins calculation.

#example 
xx, yy = np.meshgrid(x, x)
zz = np.sinc(np.sqrt((xx - 1)**2 + (yy - 1)**2))

fig, ax = plt.subplots(ncols=2, figsize=(12, 8))
ax[0].imshow(zz)
ax[0].set_title("default margins") ##no change 
ax[1].imshow(zz)
ax[1].margins(0.2)
ax[1].set_title("margins(0.2)")  #no change 

#This override of margins is determined by "sticky edges", 
#setting use_sticky_edges to False renders the image with requested margins.
ax[1].imshow(zz)
ax[1].use_sticky_edges = False
ax[1].set_title("use_sticky_edges=False\nmargins(0.2)")
ax[2].imshow(zz)
ax[2].margins(-0.2)
ax[2].set_title("default use_sticky_edges\nmargins(-0.2)")

##Cordinate systems and Transforms 
Use inputs in data cordinate system and matplot transforms 
to figure, subfigure, Axes and then display 

To easily move between coordinate systems, the userland data coordinate system, 
the axes coordinate system, the figure coordinate system, and the display coordinate system

data coordinate system
	The coordinate system of the data in the Axes.
	use transform=ax.transData in suitable methods 
axes coordinate system
	The coordinate system of the Axes; (0, 0) is bottom left of the axes, 
    and (1, 1) is top right of the axes.
	use transform=ax.transAxes
subfigure coordinate system
	The coordinate system of the SubFigure; 
    (0, 0) is bottom left of the subfigure, and (1, 1) is top right of the subfigure. 
    If a figure has no subfigures, this is the same as transFigure.
	Use, transform=subfigure.transSubfigure
figure coordinate system
	The coordinate system of the Figure; (0, 0) is bottom left of the figure, 
    and (1, 1) is top right of the figure.
	Use, transform=fig.transFigure

"figure-inches"
	The coordinate system of the Figure in inches; 
    (0, 0) is bottom left of the figure, and (width, height) is the top right of the figure in inches.
	Use, transform=fig.dpi_scale_trans
"xaxis", "yaxis"
	Blended coordinate systems, using data coordinates on one direction 
    and axes coordinates on the other.
	Use ax.get_xaxis_transform(), ax.get_yaxis_transform()
display coordinate system
	The native coordinate system of the output 
    (0, 0) is the bottom left of the window, and 
    (width, height) is top right of the output in "display units".
    The exact interpretation of the units depends on the back end. 
    For example it is pixels for Agg and points for svg/pdf.
	Use transform=None, or IdentityTransform()
    
#Data Cordinate- most commonly used 
Whenever you add data to the axes, Matplotlib updates the datalimits, 
eg by  set_xlim() and set_ylim() methods. 
For example, in the figure below, the data limits stretch from 0 to 10 on the x-axis, 
and -1 to 1 on the y-axis.
#Example 
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

x = np.arange(0, 10, 0.005)
y = np.exp(-x/2.) * np.sin(2*np.pi*x)

fig, ax = plt.subplots()
ax.plot(x, y)
ax.set_xlim(0, 10)
ax.set_ylim(-1, 1)

plt.show()

Use the ax.transData instance to transform from your data 
to your display coordinate system,

type(ax.transData)
#<class 'matplotlib.transforms.CompositeGenericTransform'>

ax.transData.transform((5, 0))
#array([ 335.175,  247.   ])

ax.transData.transform([(5, 0), (1, 2)])
#
array([[ 335.175,  247.   ],
       [ 132.435,  642.2  ]])

OR use inverted() method from display to data coordinates:

inv = ax.transData.inverted()

inv.transform((335.175,  247.))
#Out[43]: array([ 5.,  0.])

#For example 
x = np.arange(0, 10, 0.005)
y = np.exp(-x/2.) * np.sin(2*np.pi*x)

fig, ax = plt.subplots()
ax.plot(x, y)
ax.set_xlim(0, 10)
ax.set_ylim(-1, 1)

xdata, ydata = 5, 0
# This computing the transform now, if anything
# (figure size, dpi, axes placement, data limits, scales..)
# changes re-calling transform will get a different value.
xdisplay, ydisplay = ax.transData.transform((xdata, ydata))

bbox = dict(boxstyle="round", fc="0.8")
arrowprops = dict(
    arrowstyle="->",
    connectionstyle="angle,angleA=0,angleB=90,rad=10")

offset = 72
ax.annotate('data = (%.1f, %.1f)' % (xdata, ydata),
            (xdata, ydata), xytext=(-2*offset, offset), textcoords='offset points',
            bbox=bbox, arrowprops=arrowprops) #xycoords= data by default 

disp = ax.annotate('display = (%.1f, %.1f)' % (xdisplay, ydisplay),
                   (xdisplay, ydisplay), xytext=(0.5*offset, -offset),
                   xycoords='figure pixels',
                   textcoords='offset points',
                   bbox=bbox, arrowprops=arrowprops)

plt.show()

#Axes coordinates - next most useful cordinates 

fig = plt.figure()
for i, label in enumerate(('A', 'B', 'C', 'D')):
    ax = fig.add_subplot(2, 2, i+1)
    ax.text(0.05, 0.95, label, transform=ax.transAxes,
            fontsize=16, fontweight='bold', va='top')

plt.show()

#You can also make lines or patches in the axes coordinate system, 
fig, ax = plt.subplots()
x, y = 10*np.random.rand(2, 1000)
ax.plot(x, y, 'go', alpha=0.2)  # plot some data in data coordinates

circ = mpatches.Circle((0.5, 0.5), 0.25, transform=ax.transAxes,
                       facecolor='blue', alpha=0.75)
ax.add_patch(circ)
plt.show()

#Blended transformations
The blended transformations where x is in data coords and y in axes coordinates is so useful 
that matplotlib has helper methods to return the versions Matplotlib uses internally 

trans = ax.get_xaxis_transform() # get_yaxis_transform()

In fact these blended lines and spans are so useful, there is builtin function 
(see axhline(), axvline(), axhspan(), axvspan()) 

for example to create a horizontal span which highlights some region of the y-data 
but spans across the x-axis regardless of the data limits, pan or zoom level, etc. 

#eg  horizontal span 
import matplotlib.transforms as transforms

fig, ax = plt.subplots()
x = np.random.randn(1000)

ax.hist(x, 30)
ax.set_title(r'$\sigma=1 \/ \dots \/ \sigma=2$', fontsize=16)

# the x coords of this transformation are data, and the y coord are axes
trans = transforms.blended_transform_factory(
    ax.transData, ax.transAxes)
# highlight the 1..2 stddev region with a span.
# We want x to be in data coordinates and y to span from 0..1 in axes coords.
rect = mpatches.Rectangle((1, 0), width=1, height=1, transform=trans,
                          color='yellow', alpha=0.5)
ax.add_patch(rect)

plt.show()

$\sigma=1 \/ \dots \/ \sigma=2$

Note


#Plotting in physical coordinates
#To draw the same circle as above, but in physical coordinates. 

fig, ax = plt.subplots(figsize=(5, 4))
x, y = 10*np.random.rand(2, 1000)
ax.plot(x, y*10., 'go', alpha=0.2)  # plot some data in data coordinates
# add a circle in fixed-coordinates
circ = mpatches.Circle((2.5, 2), 1.0, transform=fig.dpi_scale_trans,
                       facecolor='blue', alpha=0.75)
ax.add_patch(circ)
plt.show()

#If we change the figure size, the circle does not change its absolute position and is cropped.
fig, ax = plt.subplots(figsize=(7, 2))
x, y = 10*np.random.rand(2, 1000)
ax.plot(x, y*10., 'go', alpha=0.2)  # plot some data in data coordinates
# add a circle in fixed-coordinates
circ = mpatches.Circle((2.5, 2), 1.0, transform=fig.dpi_scale_trans,
                       facecolor='blue', alpha=0.75)
ax.add_patch(circ)
plt.show()

##Defining paths in your Matplotlib visualization. - manual drawing 
https://matplotlib.org/stable/tutorials/advanced/path_tutorial.html

import matplotlib.pyplot as plt
from matplotlib.path import Path
import matplotlib.patches as patches

verts = [
   (0., 0.),  # left, bottom
   (0., 1.),  # left, top
   (1., 1.),  # right, top
   (1., 0.),  # right, bottom
   (0., 0.),  # ignored
]

codes = [
    Path.MOVETO,
    Path.LINETO,
    Path.LINETO,
    Path.LINETO,
    Path.CLOSEPOLY,
]

path = Path(verts, codes)

fig, ax = plt.subplots()
patch = patches.PathPatch(path, facecolor='orange', lw=2)
ax.add_patch(patch)
ax.set_xlim(-2, 2)
ax.set_ylim(-2, 2)
plt.show()


##Animations using Matplotlib
FuncAnimation
    Generate data for first frame and then modify this data for each frame 
    to create an animated plot.

ArtistAnimation
    Generate a list (iterable) of artists that will draw in each frame in the animation.

FuncAnimation object takes a Figure that we want to animate 
and a function func that modifies the data plotted on the figure. 

It uses the frames parameter to determine the length of the animation. 
The interval parameter is used to determine time in milliseconds between drawing of two frames. 

Steps are 
    Plot the initial figure, including all the required artists. 
    Save all the artists in variables so that they can be updated later on during the animation.

    Create an animation function that updates the data in each artist 
    to generate the new frame at each function call.

    Create a FuncAnimation object with the Figure and the animation function, 
    along with the keyword arguments that determine the animation properties.

    Use animation.Animation.save or pyplot.show to save or show the animation.

The update function uses the set_* function for different artists to modify the data. 

#for example 
#Plotting method     Artist                          Set method
Axes.plot           lines.Line2D                    set_data
Axes.scatter        collections.PathCollection      set_offsets
Axes.imshow         image.AxesImage                 AxesImage.set_data
Axes.annotate       text.Annotation                 update_positions
Axes.barh           patches.Rectangle               set_angle, set_bounds, set_height, set_width, set_x, set_y, set_xy
Axes.fill           patches.Polygon                 set_xy
Axes.add_patch(patches.Ellipse) patches.Ellipse     set_angle, set_center, set_height, set_width

#For example 
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np

fig, ax = plt.subplots()
t = np.linspace(0, 3, 40)
g = -9.81
v0 = 12
z = g * t**2 / 2 + v0 * t

v02 = 5
z2 = g * t**2 / 2 + v02 * t

scat = ax.scatter(t[0], z[0], c="b", s=5, label=f'v0 = {v0} m/s')
line2 = ax.plot(t[0], z2[0], label=f'v0 = {v02} m/s')[0]
ax.set(xlim=[0, 3], ylim=[-4, 10], xlabel='Time [s]', ylabel='Z [m]')
ax.legend()


def update(frame):
    # for each frame, update the data stored on each artist.
    x = t[:frame]
    y = z[:frame]
    # update the scatter plot:
    data = np.stack([x, y]).T
    scat.set_offsets(data)
    # update the line plot:
    line2.set_xdata(t[:frame])
    line2.set_ydata(z2[:frame])
    return (scat, line2)


ani = animation.FuncAnimation(fig=fig, func=update, frames=40, interval=30)
plt.show()

#ArtistAnimation
ArtistAnimation can be used to generate animations if there is data stored 
on various different artists. 
This list of artists is then converted frame by frame into an animation. 

For example, when we use Axes.barh to plot a bar-chart, 
it creates a number of artists for each of the bar and error bars. 

To update the plot, one would need to update each of the bars from the container individually 
and redraw them. 
Instead, animation.ArtistAnimation can be used to plot each frame individually 
and then stitched together to form an animation. 

#Example 

fig, ax = plt.subplots()
rng = np.random.default_rng(19680801)
data = np.array([20, 20, 20, 20])
x = np.array([1, 2, 3, 4])

artists = []
colors = ['tab:blue', 'tab:red', 'tab:green', 'tab:purple']
for i in range(20):
    data += rng.integers(low=0, high=10, size=data.shape)
    container = ax.barh(x, data, color=colors)
    artists.append(container)


ani = animation.ArtistAnimation(fig=fig, artists=artists, interval=400)
plt.show()

#Animation Writers
Animation objects can be saved to disk using various multimedia writers 
(ex: Pillow, ffpmeg, imagemagick). 
    PillowWriter - Uses the Pillow library to create the animation.
    HTMLWriter - Used to create JavaScript-based animations.
    Pipe-based writers - FFMpegWriter and ImageMagickWriter are pipe based writers.
        These writers pipe each frame to the utility (ffmpeg / imagemagick) 
        which then stitches all of them together to create the animation.
    File-based writers - FFMpegFileWriter and ImageMagickFileWriter are examples of file-based writers. 
        These writers are slower than their pipe-based alternatives 
        but are more useful for debugging as they save each frame in a file 
        before stitching them together into an animation.

#Writer                 Supported Formats
PillowWriter            .gif, .apng, .webp
HTMLWriter              .htm, .html, .png
FFMpegWriter
FFMpegFileWriter        All formats supported by ffmpeg: ffmpeg -formats
ImageMagickWriter
ImageMagickFileWriter   All formats supported by imagemagick: magick -list format

#Pillow writers:
ani.save(filename="/tmp/pillow_example.gif", writer="pillow")
ani.save(filename="/tmp/pillow_example.apng", writer="pillow")

#HTML writers:
ani.save(filename="/tmp/html_example.html", writer="html")
ani.save(filename="/tmp/html_example.htm", writer="html")
ani.save(filename="/tmp/html_example.png", writer="html")

#FFMpegWriter:
ani.save(filename="/tmp/ffmpeg_example.mkv", writer="ffmpeg")
ani.save(filename="/tmp/ffmpeg_example.mp4", writer="ffmpeg")
ani.save(filename="/tmp/ffmpeg_example.mjpeg", writer="ffmpeg")

#Imagemagick writers:
ani.save(filename="/tmp/imagemagick_example.gif", writer="imagemagick")
ani.save(filename="/tmp/imagemagick_example.webp", writer="imagemagick")
ani.save(filename="apng:/tmp/imagemagick_example.apng",
         writer="imagemagick", extra_args=["-quality", "100"])

(the extra_args for apng are needed to reduce filesize by ~10x)

##Plotting commands summary 
#http://matplotlib.org/api/pyplot_summary.html

#All these functions take any Line2D properties eg  ls='solid', ...
#http://matplotlib.org/api/lines_api.html#matplotlib.lines.Line2D

#use with prefix matplotlib.pyplot. or axes.

acorr(x)                    
    Plot the autocorrelation of  x.
xcorr(x,y)                  
    Plot the cross correlation between x and y.

bar(left, height)           
    Make a bar plot with x=left array and y=height array
barbs(...)                  
    Plot a 2-D field of barbs.
barh(bottom, width)         
    Make a horizontal bar plot with bottom and width array
boxplot(x)                  
    Make a box plot

cohere(x,y)                 
    Plot the coherence between x and  y
contour(x,y,z,N)            
    Plot contours, with egde
contourf(x,y,z,N)           
    Plot contours without edges

stem(x, y, linefmt, markerfmt, basefmt=)        
    plots vertical lines (using linefmt) at each x location from the baseline to y, and places a marker there using markerfmt. A horizontal line at 0 is is plotted using basefmt
errorbar(x, y, yerr, xerr, fmt)                 
    Plot an errorbar grap h.
eventplot(positions, orientation='horizontal')  
    Plot identical parallel lines at specific positio ns

fill(x,y,fmt)               
    Plot filled polygons

hexbin(x,y,C)               
    Make a hexagonal binning plot,  C specifies values at the coordinate (x[i],y[i] ).
hist(x, bins=10)            
    Plot a histogra m.
hist2d(x, y, bins=10)       
    Make a 2D histogram plo t.
hlines(y, xmin, xmax)       
    Plot horizontal lines at each y from xmin to xma x.
vlines(x, ymin,ymax)        
    Plot vertical lines at each x from ymin to ym ax

loglog(x,y)                 
    Make a plot with log scaling on both the x and y axi s.
semilogx(x,y)               
    Make a plot with log scaling on x
semilogy(x,y)               
    Make a plot with log scaling on  y

pcolor(x2d,y2d,Color1D)     
    Create a pseudocolor plot of a 2-D arra y.
pcolormesh(x2d,y2d,Color1D) 
    Plot a quadrilateral mesh of 2D array

magnitude_spectrum(x,Fs=2, Fc=0)  
    Plot the magnitude spectrum. Fs= sampling frequency, Fc=center frequency
angle_spectrum(x,Fs=2, Fc=0)      
    Plot the angle spectrum.
phase_spectrum(x,Fs=2, Fc=0)      
    Plot the phase spectrum.
psd(x,Fs=2, Fc=0)                 
    Plot the power spectral densit y.
specgram(x, NFFT=256, Fs=2, Fc=0) 
    Plot a spectrogr m.
csd(x,y)                          
    Plot the cross-spectral density.

pie(x)                          
    Plot a pie char t.
plot(x,y,fmt)                   
    Plot lines and/or markers to the Axe s.
plot_date(x,y,fmt)              
    Plot with data with dates in either x,y or bo th
spy(Z)                          
    Plot the sparsity pattern on a 2-D array,Z.
polar(theta, r)                 
    Make a polar plo t.
quiver(x,y,C)                   
    Plot a 2-D field of arrow s.

step(x,y)                       
    Make a step plo t.
streamplot(x,y,u,v)             
    Draws streamlines of a vector flow. x,y=1d array u, v : 2d arrays = x and y-velocities. Number of rows should match length of y, and the number of columns should match x.
stackplot(x,y)                  
    Draws a stacked area plot. x : 1d array of dimension N y : 2d array of dimension MxN
scatter(x,y)                    
    Make a scatter plot of x vs y, where x and y are sequence like objects of the same lengt hs

violinplot(dataset)             
    Make a violin plot for each column of datas  
    
##Example 
names = ['group_a', 'group_b', 'group_c']
values = [1, 10, 100]

plt.figure(figsize=(9, 3))

plt.subplot(131)
plt.bar(names, values)
plt.subplot(132)
plt.scatter(names, values)
plt.subplot(133)
plt.plot(names, values)
plt.suptitle('Categorical Plotting')
plt.show()

##3D plots 
#3D plots require x,y (create from meshgrid) and Z 
#Z points are mapped to color  from ColorMap 
#Colourmap - Setting a range of colors for various items 
#select by cmap=plt.get_cmap(string_name) or cmap=cm.Dark2
#https://matplotlib.org/gallery/color/colormap_reference.html


from matplotlib import cm 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np

X = np.arange(-5, 5, 0.25)
Y = np.arange(-5, 5, 0.25)
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)



fig = plt.figure(figsize=(10,6))
ax1 = fig.add_subplot(141, projection='3d')  #requires Axes3D
#rstride 	Array row stride (step size)
#cstride 	Array column stride (step size)
surf = ax1.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, linewidth=0, antialiased=False)
ax1.set_zlim(-1.01, 1.01)
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=10)

##Mesh graph 
ax2 = fig.add_subplot(142) 
surf2 = ax2.pcolormesh(X, Y, Z, cmap=cm.ocean, alpha=0.2)


##Contour graph 
#contourf() differs from the MATLAB version in that it does not draw the polygon edges. 
#To draw edges, add line contours with calls to contour().


#If an int n, use n data intervals; i.e. draw n+1 contour lines. 
#The level heights are automatically chosen.
ax3 = fig.add_subplot(143) 
surf3 = ax3.contourf(X, Y, Z, levels=[-.25,0,.25], cmap=cm.Dark2, alpha=0.2)
ax3.set_ylim(-5,5)
ax3.set_xlim(-5,5)

ax4 = fig.add_subplot(144) 
surf3 = ax4.contour(X, Y, Z, levels=[-.25,0,.25], cmap=cm.Dark2, alpha=0.2)

plt.show()

##Polar plot 
r = np.arange(0, 2, 0.01)
theta = 2 * np.pi * r

ax = plt.subplot(111, projection='polar')
ax.plot(theta, r)
ax.set_rmax(2)
ax.set_rticks([0.5, 1, 1.5, 2])  # less radial ticks
ax.set_rlabel_position(-22.5)  # get radial labels away from plotted line
ax.grid(True)

ax.set_title("A line plot on a polar axis", va='bottom')
plt.show()

#Other 3D plots 
#https://matplotlib.org/mpl_toolkits/mplot3d/api.html
#https://matplotlib.org/mpl_toolkits/mplot3d/tutorial.html#wireframe-plots

#Example wireframe plot 
def get_test_data(delta=0.05):
    from matplotlib.mlab import  bivariate_normal
    x = y = np.arange(-3.0, 3.0, delta)
    X, Y = np.meshgrid(x, y)
    Z1 = bivariate_normal(X, Y, 1.0, 1.0, 0.0, 0.0)
    Z2 = bivariate_normal(X, Y, 1.5, 0.5, 1, 1)
    Z = Z2 - Z1
    X = X * 10
    Y = Y * 10
    Z = Z * 500
    return X, Y, Z

from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
x, y, z = get_test_data(0.05)
ax.plot_wireframe(x,y,z, rstride=2, cstride=2)
plt.show()




##HandsON - understanding polyfit 
x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])

z = np.polyfit(x, y, 3)  #Polynomial coefficients, highest power first,0th index 
>>> z
array([ 0.08703704, -0.81349206,  1.69312169, -0.03968254])

>>> p = np.poly1d(z) #highest power first,0th index 
>>> print(p)
         3          2
0.08704 x - 0.8135 x + 1.693 x - 0.03968

>>> p(0.5)   #evaluate 
0.6143849206349179

>>> p.r #roots
array([6.24151464, 3.08128307, 0.02370685])
#+,-,*,**,/ are overloaded , np.methods() can be called 

>> p**2
poly1d([ 7.57544582e-03, -1.41607878e-01,  9.56497928e-01, -2.76158982e+00,
       2.93122393e+00, -1.34374738e-01,  1.57470396e-03])
>> np.sin(p)
array([ 0.08692719, -0.72669053,  0.99252758, -0.03967213])


#High-order polynomials may oscillate wildly:
p30 = np.poly1d(np.polyfit(x, y, 30))
>>> p30(4)
-0.80000000000000204

##HandsON - Create equal spaced 100 points between -2 and 6 and 
#then plot above p and p30 graphs for those x points 

#plot 
import matplotlib.pyplot as plt
xp = np.linspace(-2, 6, 100)
_ = plt.plot(x, y, '.', xp, p(xp), '-', xp, p30(xp), '--')
plt.ylim(-2,2)
plt.show()






###Matplotlib- Few other plotting command than plot  -- ADVANCED 
#Execute - 0.2.plt_other_plot.py

###Using matplotlib styles -- ADVANCED 

#matplotlib comes with a set of high-quality predefined styles along with a styling system 


import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
%matplotlib inline

#list of all available styles:

sorted(mpl.style.available)

#create a plot:

def doplot():
    fig, ax = plt.subplots(1, 1, figsize=(5, 5))
    t = np.linspace(-2 * np.pi, 2 * np.pi, 1000)
    x = np.linspace(0, 14, 100)
    for i in range(1, 7):
        ax.plot(x, np.sin(x + i * .5) * (7 - i))
    return ax

#set a style ,All subsequent plots will use this style:
mpl.style.use('fivethirtyeight')
doplot()


#temporarily change the style for a given plot using the with context manager syntax:

# Set the default style.
mpl.style.use('default')
# Temporarily switch to the ggplot style.
with mpl.style.context('ggplot'):
    ax = doplot()
    ax.set_title('ggplot style')
# Back to the default style.
ax = doplot()
ax.set_title('default style')


#customize the ggplot style by creating a new custom style to be applied in addition to ggplot. 
cfgdir = matplotlib.get_configdir()
cfgdir
#'/home/cyrille/.config/matplotlib'

#get the path to the file using the pathlib module:
from pathlib import Path
p = Path(cfgdir)
stylelib = (p / 'stylelib')
stylelib.mkdir(exist_ok=True)
path = stylelib / 'mycustomstyle.mplstyle'

#specify the option of a few parameters:
path.write_text('''
axes.facecolor : f0f0f0
font.family : serif
lines.linewidth : 5
xtick.labelsize : 24
ytick.labelsize : 24
''')

#reload the library after we add or change a style:
mpl.style.reload_library()

#first apply the ggplot style, then we customize it by applying the options of our new style
with mpl.style.context(['ggplot', 'mycustomstyle']):
    doplot()


#references:
Customizing matplotlib, at http://matplotlib.org/users/customizing.html
Matplotlib style gallery https://tonysyu.github.io/raw_content/matplotlib-style-gallery/gallery.html
Matplotlib: beautiful plots with style, at http://www.futurile.net/2016/02/27/matplotlib-beautiful-plots-with-style/


###Numpy and Matplotlib - HANDS-ON 
#define a new function, in two dimensions this time, called the Lévi function:
$$f(x,y) = sin^2(3\pi x)+(x−1)^2(1+sin^2(3\pi y))+(y−1)^2(1+sin^2(2\pi y))$$

#The Lévi function is one of the many test functions for optimization 
#that researchers have developed to study and benchmark optimization algorithms (https://en.wikipedia.org/wiki/Test_functions_for_optimization):
def g(X):
    # X is a 2*N matrix,
    x, y = X  #x=1st row, y=2nd row 
    return (np.sin(3*np.pi*x)**2 +
            (x-1)**2 * (1 + np.sin(3*np.pi*y)**2) +
            (y-1)**2 * (1 + np.sin(2*np.pi*y)**2))

#Let's display this function with imshow(), on the square [−10,10]
n = 500
k = 10
X, Y = np.mgrid[-k:k:n * 1j, -k:k:n * 1j]
#vstack( (a,b) ) makes first row=a, second row=b 
Z = g(np.vstack( (X.ravel(), Y.ravel()) )).reshape(n, n)

fig, ax = plt.subplots(1, 1, figsize=(3, 3))
# We use a logarithmic scale for the color here.
#extent= bounding box , (left, right, bottom, top) 
#origin = upper = topleft=0,0, bottomright=N,N 
#origin = lower = bottomleft=0,0, topright=N,N 
ax.imshow(np.log(Z), cmap=plt.cm.hot_r, extent=(-k, k, -k, k), origin="lower")
ax.set_axis_off()

#The minimize() function also works in multiple dimensions:
# We use the Powell method.
x0, y0 = opt.minimize(g, (8, 3),  method='Powell').x
x0, y0

#Draw
fig, ax = plt.subplots(1, 1, figsize=(3, 3))
ax.imshow(np.log(Z), cmap=plt.cm.hot_r, extent=(-k, k, -k, k), origin="lower")
ax.scatter(x0, y0, s=100)
ax.set_axis_off()

###3D plots  -- ADVANCED 
#Execute - this would display and for pause() empty line in jupyter 
%run demo_code/0.2.plt_3dr_plot.py   


###Pandas- Dataframe manipulation using pandas 
DF is composed of list of Series with one column is designated by Index 
Dataframe can be created from 
Along with the below data, pass 'index' (row labels) and 'columns' (column labels) arguments
By default row, column labels are integer, 0 to n ,For time series, index is datetime based 
   1.Dict , where key is column name and value is column data  of 1D ndarrays, lists, Series
    OR list of dicts, where each element of list is one row, and dict's key is column name, value is cell value 
   2.2D numpy.ndarray
   3.Structured or record ndarray
   4.A Series
   5.Another DataFrame
   5.Any pandas IO read_* methods 
   
For conversion use, pd.to_numeric(arg), 
pd.to_datetime(arg, ,format='%Y %m %d'), pd.to_timedelta(arg, unit='ns')
where arg could be single or list or Series of values 
For generating daterange, use pd.date_range(start, end, periods, freq)

##Freq 
check http://pandas.pydata.org/pandas-docs/stable/timeseries.html#offset-aliases for offset aliases, 
note for multiple, you can give '5H' ie every 5th hour 
check https://github.com/pandas-dev/pandas/blob/master/doc/source/timeseries.rst#id11        
eg '2Q'  denotes two quarterly, '30min' means 30 min

Weekly can take day to denote which day of week eg 'W-MON' means Monday of week
Q can take Month eg 'Q-Feb' means every 2nd month of Q

B,D,H,Min,S,MS,U,N can be combined eg '30min20s' means 30 min 20 second
eg '2H20min30s' , '2D12H20Min30s'

#Example 
import numpy as np
import pandas as pd

df1 = pd.DataFrame(np.random.randn(6,4),index=list('abcdef'),columns=list('ABCD'))

#datetime based freq= 'M', 'D'(default), 'Y','YS','Q','W','H','T'(min),'S'(sec),'ms','us', or n muliples eg "nH" or combination "xD yH zT"
#start is generally "yyymmdd" or "yyyDELIMmmDELIMdd" where DELIM is some deliminator 
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],index=pd.date_range('20130101',periods=100000,freq='T')) 

ts = pd.Series(np.random.randn(100000), index=pd.date_range('20130101',periods=100000,freq='T'))
>>> dft.head()
                            A
2013-01-01 00:00:00  2.375359
2013-01-01 00:01:00  0.663875
2013-01-01 00:02:00 -0.534566
2013-01-01 00:03:00  0.172524
2013-01-01 00:04:00  0.502204

##DataFrame Accessing 
df[column]
    column can be 
        Single column label eg 'City'
        Array of column lables eg ['City', 'City']
        A boolean eg df[df.City == 'Chicago']
        A callable, fn(df):returns_any_from_above eg. df[lambda d: d.City == 'Chicago']
    Can be used for update dfi['C'] = dfi['A']
df.column_name
    when column_name is string
    Only for accessing or update 
    Not for creation of new column, use df['column_name'] style 
    For index column, access always like df.index 
df[row_slice]
    row_slice can be 
        start:stop:step, stop exclusive 
        where start,stop are row index 
    there is no way to get row based on index label
    But for DatetimeIndex, it's possible to access based on datetime index 
df.loc[row,column] 
    label based(both row and column)
    row,column takes 
        A single label, e.g. 5 or 'a', 
        A list or array of labels ['a', 'b', 'c']
        A slice object with labels 'a':'f' (end inclusive)
        A boolean array eg df.A > 0 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
        For DatetimeIndex, row can be as given in above example 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']
df.loc[row]
    equivalent to df.loc[row,:]
df.iloc[row,column] 
    index based(both row, column)
    row,column takes 
        An integer e.g. 5
        A list or array of integers [4, 3, 0]
        A slice object with ints 1:7:1 , end exclusive 
        A boolean array *** NOT IMPLEMENTED *** 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']    
df.iloc[row]
    equivalent to df.iloc[row,:]
df.ix[row,column] 
    For each of row,column ,at first tries label based like df.loc[] 
    if Fails, then tries index based like df.iloc[]
    If the index or column does not have label,then behaves like df.iloc[] always 
    For DatetimeIndex, row can be as given in above example 
df.ix[row]
    equivalent to df.ix[row,:]
    For DatetimeIndex, row can be as given in above example
df.iat[row_index,column_index]
df.at[row_label, column_label] 
    for accessing a cell 
    
#Example 
df = pd.DataFrame(np.random.randn(6,4),index=list('abcdef'),columns=list('ABCD'))


##DataFrame Accessing 
df.column_name
    when column_name is string
    Only for accessing or update 
    Not for creation of new column, use df['column_name'] style 
    For index column, access always like df.index 
    
df.head()
df.tail()
df.index 
df.columns 
df.dtypes 
df.size #30
df.shpe #6,5
df.A 
#for update , in place 
df['A-1'] = df.A + df.C   
#new copy  
df.assign(AA= df.A + df.C, BB= lambda df: df.A + df.C    )

#all arithmatic operations possible  
df['A-1'] = df.A ** 2 
df['A-1'] = np.sqrt(df.A) 
 
#also at DF level , elementwise 
df + 1 
df + df 
1/df 
np.log(df)  #with Nan 
np.log(df).fillna(0) #all fill 
#or 
np.log(df).fillna({'A': np.mean(df.A)}) #only A column fill 

#fill all columns by A mean where df.A is null (might not be intended)
df11 = np.log(df)
df11[df11.A.isnull()] =  np.mean(df.A)

#but below OK , fill only those points in A by A mean 
df11 = np.log(df)
df11['A'][df11.A.isnull()]=  np.mean(df.A)

 
df[column]
    column can be 
        Single column label eg 'City'
        Array of column lables eg ['City', 'City']
        A boolean eg df[df.City == 'Chicago']
        A callable, fn(df):returns_any_from_above eg. df[lambda d: d.City == 'Chicago']
    Can be used for update dfi['C'] = dfi['A']
    
#df[column]
df['A']  #Series 
df[['A']  # DF 
df[['A', 'B']] 
df[ df['A'] >= 1.0] #DF  #all rows where df['A'] is >= 1.0 , True , rows includes all Column
df[lambda df: df['A'] >= 1.0]

df.query('A > B')
# same result as the previous expression  
df[df.A > df.B] 

df.where(df.A > df.B, 0) #Replace values by 0 (all columns) where the condition is False.
df.where(df.A > df.B) #Replace values by NaN(all columns) where the condition is False.
    

df[row_slice]
    row_slice can be 
        start:stop:step, stop exclusive 
        where start,stop are row index 
    But for DatetimeIndex, it's possible to access based on datetime index 
    
df[1:3]
df[1:3]['A']  #only A 
df['a':'c']   #based on index label , but index should be sorted one 
df.sort_index(level=0)
    
    
df.loc[row,column] 
    label based(both row and column)
    row,column takes 
        A single label, e.g. 5 or 'a', 
        A list or array of labels ['a', 'b', 'c']
        A slice object with labels 'a':'f' (end inclusive)
        A boolean array eg df.A > 0 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
        For DatetimeIndex, row can be as given in above example 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']
df.loc[row]
    equivalent to df.loc[row,:]
#label based    
df.loc['a' , :]  #Series of all COlumns 
df.loc['a']      #same as above 
df.loc[['a'] , :] #now DF of single row 
df.loc[: , 'A']   #Series of all rows of column A 
df.loc[: , ['A']]   #now DF of single column
df.loc['a', 'A']   #single cell 
df.loc[['a','b'], ['A','B']] 
df.loc[['a','b']] 
df.loc['a': 'c', 'A': 'C']  #inclusive index must be sorted
df.loc[df.A >=1.0, 'C']   #Series 
df.loc[df.A >=1.0, ['C']]  #now DF 
df.loc[lambda df: df.A >=1.0, 'C']
#update , LHS can have any of the above, RHS dimension must match 
df.loc[:,'C'] = df.loc[:,'A']


df.iloc[row,column] 
    index based(both row, column)
    row,column takes 
        An integer e.g. 5
        A list or array of integers [4, 3, 0]
        A slice object with ints 1:7:1 , end exclusive 
        A boolean array *** NOT IMPLEMENTED *** 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']    
df.iloc[row]
    equivalent to df.iloc[row,:]
#Same with integer index  now   
df.iloc[0 , :]  #Series of all COlumns 
df.iloc[0]      #same as above 
df.iloc[[0] , :] #now DF of single row 
df.iloc[: , 0]   #Series of all rows of column A 
df.iloc[: , [0]]   #now DF of single column
df.iloc[0, 0]   #single cell 
df.iloc[[0,1], [0,1]] 
df.iloc[[0,1]] 
df.iloc[0: 3, 0: 3]  #inclusize
#below three not available 
#df.iloc[df.A >=1.0, 2]   #Series 
#df.iloc[df.A >=1.0, [2]]  #now DF 
#df.iloc[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.iloc[:,2] = df.iloc[:,0]

   
df.ix[row,column] 
    For each of row,column ,at first tries label based like df.loc[] 
    if Fails, then tries index based like df.iloc[]
    If the index or column does not have label,then behaves like df.iloc[] always 
    For DatetimeIndex, row can be as given in above example 
df.ix[row]
    equivalent to df.ix[row,:]
    For DatetimeIndex, row can be as given in above example
#Firt label, then index 
#all .loc and iloc can be used exactly like above 
#but now can be mixed     
df.ix['a' , :]  #Series of all COlumns 
df.ix['a']      #same as above 
df.ix[[0] , :] #now DF of single row 
df.ix[: , 'A']   #Series of all rows of column A 
df.ix[: , [0]]   #now DF of single column
df.ix['a', 0]   #single cell 
df.ix[[0,1], ['A','B']] 
df.ix[[0,1]] 
df.ix['a': 'c', 0: 2]  #label inclusive, integer exclusive , index must be sorted
df.ix[df.A >=1.0, 2]   #Series 
df.ix[df.A >=1.0, ['C']]  #now DF 
df.ix[lambda df: df.A >=1.0, 2]
#update , LHS can have any of the above, RHS dimension must match 
df.ix[:,'C'] = df.ix[:,0]

df.iat[row_index,column_index]
df.at[row_label, column_label] 
    for accessing a cell 
df.at['a', 'A']
df.iat[0,0]  
    
df.xs(key, axis=0, level=None, drop_level=True)
    key : label or tuple of label
    Mainly for  for multiindex 
    
df.xs('a')  #rowwise , but a Series 
df.xs('A', axis=1) #cloumnwise, but a series  
   
#Multiindex 
d = {'num_legs': [4, 4, 2, 2],
     'num_wings': [0, 0, 2, 2],
     'class': ['mammal', 'mammal', 'mammal', 'bird'],
     'animal': ['cat', 'dog', 'bat', 'penguin'],
     'locomotion': ['walks', 'walks', 'flies', 'walks']}     
df = pd.DataFrame(data=d)
#set level-0 class, level-1, animal, level-3 locomotion 
#Note length of each must be same 
df = df.set_index(['class', 'animal', 'locomotion'])
>>> df
                           num_legs  num_wings
class  animal  locomotion
mammal cat     walks              4          0
       dog     walks              4          0
       bat     flies              2          2
bird   penguin walks              2          2

#Get values at (level0, level1, level2), and that lavel is gone 
df.xs('mammal')
df.xs(('mammal', 'dog'))
#or give explicit via level=n or [n_or_label, ..]
df.xs('cat', level=1)
df.xs(('bird', 'walks'), level=[0, 'locomotion'])

#Get values at specified column and axis
df.xs('num_wings', axis=1)

#Only loc, and ix , not iloc, Note multiindex has to be based on label
df.loc[('mammal', 'cat', 'walks'), 'num_legs']
df.loc[('mammal', 'cat', 'walks')]
df.loc[('mammal', 'cat'), 'num_legs']
df.loc[('mammal', slice(None), 'walks'), 'num_legs'] #any animal 
df.loc[('mammal', 'cat', 'walks'):('mammal', 'bat', 'walks'), 'num_legs']

df.ix[('mammal', slice(None), 'walks'), [0,1]]
df.ix[('mammal', slice(None), 'walks'), 0]

#for slicing, index should be sorted one 
df.index.lexsort_depth #0 
df.sort_index(level=0)  #level-0 sorted , now depth should be 1 
df.sort_index(level=[0,1,2], inplace=True) #all levels are sorted now 
df.loc['bird':'mammal']
df.loc['bird':('mammal', 'bat', 'flies'), ['num_legs']]


##DF  - Concat 
pd.concat(objs, axis=0, join='outer', join_axes=None, ignore_index=False,       
        keys=None, levels=None, names=None, verify_integrity=False)
    Concatenate pandas objects along a particular axis 
    with optional set logic along the other axes.
        •objs: a sequence or mapping of Series, DataFrame, or Panel objects.    
        •axis: {0, 1}, default 0(index). 
            =0 means vertical(row) stacking, =1 means horizontal(column) stacking 
        •join: {'inner', 'outer'}, default 'outer'. 
            Outer for union and inner for intersection.
        keys: new columns name 
        ignore_index : boolean, default False
            If True, do not use the index values along the concatenation axis. 
            The resulting axis will be labeled 0, ..., n - 1.
            
            
#Note numpy axis means the same as pandas 
#vertically(row) stacking array - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5,6]]  ), axis=0) #, arg = list of 2D matrix 
array([[1, 2],
       [3, 4],
       [5, 6]])
#2nd array appended columnwise - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5],[6]]  ), axis=1)
array([[1, 2, 5],
       [3, 4, 6]])
#Example 
df1 = pd.DataFrame({'A': ['A0', 'A1', 'A2', 'A3'],  #keys are columns                    
    'B': ['B0', 'B1', 'B2', 'B3'],                    
    'C': ['C0', 'C1', 'C2', 'C3'],                    
    'D': ['D0', 'D1', 'D2', 'D3']},                    
    index=[0, 1, 2, 3])
df2 = pd.DataFrame({'A': ['A4', 'A5', 'A6', 'A7'],                   
    'B': ['B4', 'B5', 'B6', 'B7'],                   
    'C': ['C4', 'C5', 'C6', 'C7'],                    
    'D': ['D4', 'D5', 'D6', 'D7']},                    
    index=[4, 5, 6, 7])
df3 = pd.DataFrame({'A': ['A8', 'A9', 'A10', 'A11'],                    
    'B': ['B8', 'B9', 'B10', 'B11'],                     
    'C': ['C8', 'C9', 'C10', 'C11'],                        
    'D': ['D8', 'D9', 'D10', 'D11']},                    
    index=[8, 9, 10, 11])

#Note same index values in multiple DFs would be duplicated in result DF 
#To ignore index in input DF, use ignore_index=True 
frames = [df1, df2, df3]
result = pd.concat(frames)    #Using concat, default axis=0, vertically(row) append 
>>> result
      A    B    C    D
0    A0   B0   C0   D0
1    A1   B1   C1   D1
2    A2   B2   C2   D2
3    A3   B3   C3   D3
4    A4   B4   C4   D4
5    A5   B5   C5   D5
6    A6   B6   C6   D6
7    A7   B7   C7   D7
8    A8   B8   C8   D8
9    A9   B9   C9   D9
10  A10  B10  C10  D10
11  A11  B11  C11  D11
>>> result = pd.concat(frames, axis=1) #horizontal(column) stacking 
>>> result
      A    B    C    D    A    B    C    D    A    B    C    D
0    A0   B0   C0   D0  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
1    A1   B1   C1   D1  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
2    A2   B2   C2   D2  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
3    A3   B3   C3   D3  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
4   NaN  NaN  NaN  NaN   A4   B4   C4   D4  NaN  NaN  NaN  NaN
5   NaN  NaN  NaN  NaN   A5   B5   C5   D5  NaN  NaN  NaN  NaN
6   NaN  NaN  NaN  NaN   A6   B6   C6   D6  NaN  NaN  NaN  NaN
7   NaN  NaN  NaN  NaN   A7   B7   C7   D7  NaN  NaN  NaN  NaN
8   NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN   A8   B8   C8   D8
9   NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN   A9   B9   C9   D9
10  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN  A10  B10  C10  D10
11  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN  A11  B11  C11  D11

#Note append  is similar to axis=0 
result = df1.append(df2)
>>> result
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
4  A4  B4  C4  D4
5  A5  B5  C5  D5
6  A6  B6  C6  D6
7  A7  B7  C7  D7

#the indexes must be disjoint or use ignore_index=True 
>>> df1.append(df1)
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
>>> df1.append(df1).reset_index()
   index   A   B   C   D
0      0  A0  B0  C0  D0
1      1  A1  B1  C1  D1
2      2  A2  B2  C2  D2
3      3  A3  B3  C3  D3
4      0  A0  B0  C0  D0
5      1  A1  B1  C1  D1
6      2  A2  B2  C2  D2
7      3  A3  B3  C3  D3
>>> df1.append(df1, ignore_index=True)
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
4  A0  B0  C0  D0
5  A1  B1  C1  D1
6  A2  B2  C2  D2
7  A3  B3  C3  D3

#To concatenate a mix of Series and DataFrames.
s1 = pd.Series(['X0', 'X1', 'X2', 'X3'], name='X')
result = pd.concat([df1, s1], axis=1) #horzontal stacking 
>>> result
    A   B   C   D   X
0  A0  B0  C0  D0  X0
1  A1  B1  C1  D1  X1
2  A2  B2  C2  D2  X2
3  A3  B3  C3  D3  X3



##DF - Database-style DataFrame merging
DataFrame.join(other, on=None, how='left', lsuffix='', rsuffix='', sort=False)
    Join : this DF's index or column(if 'on' given) with 'other' index 
    'other' index values sud be similar to 'this' DF's index or column
    Efficiently Join multiple DataFrame objects by index at once by passing a list.
    Use merge which is superset of join 
        on : column name, tuple/list of column names, or array-like
            Column(s) in the caller to join on the index in other, 
            otherwise joins index-on-index. 
            If multiples columns given, the passed DataFrame must have a MultiIndex. 
            Can pass an array as the join key if not already contained in the calling DataFrame. Like an Excel VLOOKUP operation
pandas.merge(left, right, how='inner', on=None, left_on=None, right_on=None,      
        left_index=False, right_index=False, sort=True,      
        suffixes=('_x', '_y'), copy=True, indicator=False)
DataFrame.merge(right, how='inner', on=None, left_on=None, right_on=None, 
        left_index=False, right_index=False, sort=False, suffixes=('_x', '_y'), copy=True, indicator=False, validate=None)
    If joining columns on columns, ie 'on' or (left_on,right_on), 
    the DataFrame indexes will be ignored. 
    Otherwise if joining indexes on indexes ie left_index,right_index 
    or indexes on a column(ie on*, *_index combination, 
    Note, one's index values must match with other's column's value) 
    the index will be passed on.    
    left, right : DataFrame
    how : {'left', 'right', 'outer', 'inner'}, default 'inner'
        •left: use only keys from left frame, similar to a SQL left outer join; preserve key order
        •right: use only keys from right frame, similar to a SQL right outer join; preserve key order
        •outer: use union of keys from both frames, similar to a SQL full outer join; sort keys lexicographically
        •inner: use intersection of keys from both frames, similar to a SQL inner join; preserve the order of the left keys
    on: Columns (names) to join on. 
        Must be found in both the left and right DataFrame objects. 
        If not passed and left_index and right_index are False, 
        the intersection of the columns in the DataFrames will be inferred to be the join keys
    •left_on: Columns from the left DataFrame to use as keys. 
        Can either be column names or arrays with length equal to the length of the DataFrame
    •right_on: Columns from the right DataFrame to use as keys. 
        Can either be column names or arrays with length equal to the length of the DataFrame
    •left_index: If True, use the index (row labels) from the left DataFrame as its join key(s). 
        In the case of a DataFrame with a MultiIndex (hierarchical), 
        the number of levels must match the number of join keys from the right DataFrame
    right_index: Same usage as left_index for the right DataFrame
    sort : boolean, default False
        Sort the join keys lexicographically in the result DataFrame. 
    suffixes : 2-length sequence (tuple, list, ...)
        Suffix to apply to overlapping column names in the left and right side, 
    copy : boolean, default True
        If False, do not copy data unnecessarily
    indicator : boolean or string, default False
        If True, adds a column to output DataFrame called '_merge' with information 
        on the source of each row.eg 'left_only', 'right_only','both' 
    validate : string, default None
        If specified, checks if merge is of specified type.
        •'one_to_one' or '1:1': check if merge keys are unique in both left and right datasets.
        •'one_to_many' or '1:m': check if merge keys are unique in left dataset.
        •'many_to_one' or 'm:1': check if merge keys are unique in right dataset.
        •'many_to_many' or 'm:m': allowed, but does not result in checks.

#Type of joins
•one-to-one joins: for example when joining two DataFrame objects 
 on their indexes (which must contain unique values)
•many-to-one joins: for example when joining an index (unique) to one or more                    
 columns in a DataFrame
•many-to-many joins: joining columns on columns.

>>> A              >>> B
    lkey value        rkey value
0   foo  1            foo  5
1   bar  2            bar  6
2   baz  3            qux  7
3   foo  4            bar  8
#read above and split 
df = pd.read_clipboard() #lkey  value rkey  value.1
A = df.iloc[:,[0,1]]
B = df.iloc[:, [2,3]]
B.columns= [ B.columns[0], 'value'] #rename 
>>> A
  lkey  value
0  foo      1
1  bar      2
2  baz      3
3  foo      4
>>> B
  rkey  value
0  foo      5
1  bar      6
2  qux      7
3  bar      8
#note for below index-column joining, one can use 'join' as well 
>>> pd.merge(A, B,  left_on='value',right_index = True) #left column 'value' == right index
   value lkey  value_x rkey  value_y
0      1  foo        1  bar        6
1      2  bar        2  qux        7
2      3  baz        3  bar        8


>>> A.merge(B, left_index=True, right_index=True) #index joining 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_index=True, right_index=True, how='outer')#does not matter 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='outer') #column joining 
   lkey  value_x  rkey  value_y
0  foo   1        foo   5
1  foo   4        foo   5
2  bar   2        bar   6
3  bar   2        bar   8
4  baz   3        NaN   NaN
5  NaN   NaN      qux   7
>>> A.merge(B, left_on='lkey', right_on='rkey', how='inner')
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  foo        4  foo        5
2  bar        2  bar        6
3  bar        2  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='left')
  lkey  value_x rkey  value_y
0  foo        1  foo      5.0
1  bar        2  bar      6.0
2  bar        2  bar      8.0
3  baz        3  NaN      NaN
4  foo        4  foo      5.0
>>> A.merge(B, left_on='lkey', right_on='rkey', how='right')
  lkey  value_x rkey  value_y
0  foo      1.0  foo        5
1  foo      4.0  foo        5
2  bar      2.0  bar        6
3  bar      2.0  bar        8
4  NaN      NaN  qux        7


###Many Other Pandas Operations -- ADVANCED 

#Example 
left = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
right = pd.DataFrame({'key1': ['K0', 'K1', 'K1', 'K2'],                      
        'key2': ['K0', 'K0', 'K0', 'K0'],                        
        'C': ['C0', 'C1', 'C2', 'C3'],                         
        'D': ['D0', 'D1', 'D2', 'D3']}) 
#multiple keys 
result = pd.merge(left, right, on=['key1', 'key2'])
>>> result
    A   B key1 key2   C   D
0  A0  B0   K0   K0  C0  D0
1  A2  B2   K1   K0  C1  D1
2  A2  B2   K1   K0  C2  D2

# With The merge indicator
pd.merge(left, right, on=['key1', 'key2'], indicator=True)


Series.map(arg, na_action=None)
    Map values of Series using input correspondence (a dict, Series, or function).
    arg : function, dict, or Series
#Example 
x = pd.Series([1,2,3], index=['one', 'two', 'three'])
>>> x
one      1
two      2
three    3
dtype: int64

y = pd.Series(['foo', 'bar', 'baz'], index=[1,2,3])
>>> y
1    foo
2    bar
3    baz
>>> x.map(y)
one   foo
two   bar
three baz

#For data frame 
df = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
>>> df.key1.map(lambda e: e[-1])
0    0
1    0
2    1
3    2
Name: key1, dtype: object
df['key11'] = df.key1.map(lambda e: e[-1])
>>> df
    A   B key1 key2 key11
0  A0  B0   K0   K0     0
1  A1  B1   K0   K1     0
2  A2  B2   K1   K0     1
3  A3  B3   K2   K1     2
    
    
DataFrame.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) one by one 
        Accepted Combinations are:
            •string function name
            •function
            •list of functions
            •dict of column names -> functions (or list of functions)

#Examples
df = pd.DataFrame(np.random.randn(10, 3), columns=['A', 'B', 'C'],
            index=pd.date_range('1/1/2000', periods=10))
df.iloc[3:7] = np.nan

>>> df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 
                   A         B         C
2000-01-01  0.579457  1.236184  0.123424
2000-01-02  0.370357 -0.605875 -1.231325
2000-01-03  1.455756 -0.277446  0.288967
2000-01-04       NaN       NaN       NaN
2000-01-05       NaN       NaN       NaN
2000-01-06       NaN       NaN       NaN
2000-01-07       NaN       NaN       NaN
2000-01-08 -0.498658  1.274522  1.642524
2000-01-09 -0.540524 -1.012676 -0.828968
2000-01-10 -1.366388 -0.614710  0.005378

DataFrame.assign(**kwargs)
    Assign new columns to a DataFrame, returning a new object (a copy) 
    with the new columns added to the original ones. 
    Existing columns that are re-assigned will be overwritten.


df = pd.DataFrame({'A': range(1, 11), 'B': np.random.randn(10)})
>>> df.assign(ln_A = lambda df: np.log(df.A)) #takes df 
    A         B      ln_A
0   1  0.426905  0.000000
1   2 -0.780949  0.693147
2   3 -0.418711  1.098612
3   4 -0.269708  1.386294
4   5 -0.274002  1.609438
5   6 -0.500792  1.791759
6   7  1.649697  1.945910
7   8 -1.495604  2.079442
8   9  0.549296  2.197225
9  10 -0.758542  2.302585



DataFrame.apply(func, axis=0, broadcast=None, raw=False, reduce=None, result_type=None, args=(), **kwds)
    Apply a function along an axis of the DataFrame.
    axis : {0 or ‘index’, 1 or ‘columns’}, default 0
        Axis along which the function is applied:
        •0 or ‘index’: apply function to each column.
        •1 or ‘columns’: apply function to each row.
 
#Example 
>>> df = pd.DataFrame([[4, 9],] * 3, columns=['A', 'B'])
>>> df
   A  B
0  4  9
1  4  9
2  4  9
>>> df.apply(np.sqrt)
     A    B
0  2.0  3.0
1  2.0  3.0
2  2.0  3.0

>>> df.apply(np.sum, axis=0)
A    12
B    27
dtype: int64



DataFrame.applymap(func)
    Apply a function to a Dataframe elementwise.

#Example 
>>> df = pd.DataFrame([[1, 2.12], [3.356, 4.567]])
>>> df
       0      1
0  1.000  2.120
1  3.356  4.567

>>> df.applymap(lambda x: len(str(x)))
   0  1
0  3  4
1  5  5

>>> df.applymap(lambda x: x**2)
           0          1
0   1.000000   4.494400
1  11.262736  20.857489
#But it’s better to avoid applymap in that case.
>>> df ** 2
           0          1
0   1.000000   4.494400
1  11.262736  20.857489

##GroupBy    
DataFrame.groupby(by=None, axis=0, level=None, as_index=True, sort=True, group_keys=True, squeeze=False, **kwargs)
    Returns DataFrameGroupBy or SeriesGroupBy
    When aggregation function is applied on returned type,
    final return would be DataFrame or Series respectively 
    Parameters:
    by can be 
        •A Python function, to be called on the axis labels(axis=0, with Index, axis=1, with Columns)
        •A list or NumPy array of the same length as the selected axis
        •A dict or Series, providing a label -> group name mapping
        •For DataFrame objects, a string indicating a column to be used to group. 
         df.groupby('A') is just syntactic sugar for df.groupby(df['A']), 
        •For DataFrame objects, a string indicating an index level to be used to group.
        •A list of any of the above things
        •A Grouper object 
    axis : int, default 0(index, columnwise)
    level : int, level name, or sequence of such, default None
        If the axis is a MultiIndex (hierarchical), group by a particular level or levels
    as_index : boolean, default True
        For aggregated output, return object with group labels as the index. 
        Only relevant for DataFrame input. as_index=False is effectively "SQL-style' grouped output
    sort : boolean, default True
        Sort group keys. Get better performance by turning this off. 
    group_keys : boolean, default True
        When calling apply, add group keys to index to identify pieces
    squeeze : boolean, default False
        reduce the dimensionality of the return type if possible, 
        otherwise return a consistent type
        
# default is axis=0,columnwise
>>> grouped = obj.groupby(key)
>>> grouped = obj.groupby(key, axis=1)
>>> grouped = obj.groupby([key1, key2])

#Example 
#DataFrame results
>>> data.groupby(func, axis=0).mean()
>>> data.groupby(['col1', 'col2'])['col3'].mean() #


#Example 
df = pd.read_excel("./data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225
>>> g =df.groupby('order')
>>> g.groups  #[row lables for group]
{10001: Int64Index([0, 1, 2], dtype='int64'), 10005: Int64Index([3,4,5,6,7], dtype='int64'), 10006: Int64Index([8, 9, 10, 11], dtype='int64

>>> g.indices
{10001: array([0, 1, 2], dtype=int64), 10005: array([3, 4, 5, 6]...), 10006: array([ 8,  9, 10, 11], dtype=int64)}

>>> g.ngroup()  #row_index vs group_index 
0     0
1     0
2     0
3     1
4     1
5     1
6     1
7     1
8     2
9     2
10    2
11    2
dtype: int64
>>> g.size() #group size
order
10001    3
10005    5
10006    4
dtype: int64



#Q= "What percentage of the order total does each sku represent?"
#First Approach - Merging(joining like SQL JOIN)
#Series with index =order 
>>> df.groupby('order')["ext price"].sum().rename("Order_Total")
order
10001     576.12
10005    8185.49
10006    3724.49
Name: Order_Total, dtype: float64

>>> df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
   order  Order_Total
0  10001       576.12
1  10005      8185.49
2  10006      3724.49

#how to combine this data back with the original dataframe. 
order_total = df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
df_1 = df.merge(order_total, on='order')
>>> df_1.head(3)
   account      name  order       sku  quantity  unit price  ext price  \
0   383080  Will LLC  10001  B1-20000         7       33.69     235.83
1   383080  Will LLC  10001  S1-27722        11       21.12     232.32
2   383080  Will LLC  10001  B1-86481         3       35.99     107.97

   Order_Total
0       576.12
1       576.12
2       576.12
df_1["Percent_of_Order"] = df_1["ext price"] / df_1["Order_Total"]


#Second Approach - Using Transform
>>> df.groupby('order')["ext price"]
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]



DataFrameGroupBy.agg(arg, *args, **kwargs)
    Aggregate using callable, string, dict, or list of string/callables
    Check further description from DataFrame.aggregate
    Parameters:
    func : callable, string, dictionary, or list of string/callables
        Accepted Combinations are:
        •string function name
        •function
        •list of functions
        •dict of column names -> functions (or list of functions)
 
#Examples
df = pd.DataFrame({'A': [1, 1, 2, 2],
                    'B': [1, 2, 3, 4],
                    'C': np.random.randn(4)})
>>> df
   A  B         C
0  1  1  0.362838
1  1  2  0.227877
2  2  3  1.267767
3  2  4 -0.562860

#The aggregation is for each column.
>>> df.groupby('A').agg('min')
   B         C
A
1  1  0.227877
2  3 -0.562860
#Multiple aggregations
>>> df.groupby('A').agg(['min', 'max'])
    B             C
  min max       min       max
A
1   1   2  0.227877  0.362838
2   3   4 -0.562860  1.267767

#Select a column for aggregation
>>> df.groupby('A').B.agg(['min', 'max'])
   min  max
A
1    1    2
2    3    4

#Different aggregations per column
>>> df.groupby('A').agg({'B': ['min', 'max'], 'C': 'sum'})
    B             C
  min max       sum
A
1   1   2  0.590716
2   3   4  0.704907




GroupBy.apply(func, *args, **kwargs)
    Apply function func group-wise and combine the results together.
    The function passed to apply must take a dataframe as its first argument 
    and return a dataframe, a series or a scalar. 
    Parameters:
        func : function
            A callable that takes a dataframe as its first argument, 
            and returns a dataframe, a series or a scalar. 
            In addition the callable may take positional and keyword arguments
            Note dataframe is each group with remaining columns 
        args, kwargs : tuple and dict
            Optional positional and keyword arguments to pass to func
 

#In the current implementation apply calls func twice on the first group to decide 
#whether it can take a fast or slow code path. 
#Examples
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})
g = df.groupby('A')

#Example 1: below the function passed to apply takes a dataframe as its argument 
#and returns a dataframe. Dataframe is each group with remaining columns 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x / x.sum())
          B    C
0  0.333333  0.4
1  0.666667  0.6
2  1.000000  1.0

#Example 2: The function passed to apply takes a dataframe as its argument 
#and returns a series. 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x.max() - x.min())
   B  C
A
a  1  2
b  0  0

#Example 3: The function passed to apply takes a dataframe as its argument 
#and returns a scalar. 
#apply combines the result for each group together into a series, 
#including setting the index as appropriate:
>>> g.apply(lambda x: x.C.max() - x.B.min())
A
a    5
b    2
dtype: int64


GroupBy.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) of each group one by one 
        Accepted Combinations are:
            •string function name
            •function
            •list of functions
            •dict of column names -> functions (or list of functions)
    * apply implicitly passes all the columns for each group as a DataFrame to the custom function,
      while transform passes each column for each group as a Series to the custom function
    * The custom function passed to apply can return a scalar, or a Series or DataFrame (or numpy array or even list). 
      The custom function passed to transform must return a sequence (a one dimensional Series, array or list) 
      the same length as the group.
    
#Example 
df = pd.read_clipboard()
    A      B         C         D
0  foo    one  0.162003  0.087469
1  bar    one -1.156319 -1.526272
2  foo    two  0.833892 -1.666304
3  bar  three -2.026673 -0.322057
4  foo    two  0.411452 -0.954371
5  bar    two  0.765878 -0.095968
6  foo    one -0.654890  0.678091
7  foo  three -1.789842 -1.130922


#OK as X is each group as DF and see bothe C and D 
> df.groupby('A').apply(lambda x: (x['C'] - x['D']))
> df.groupby('A').apply(lambda x: (x['C'] - x['D']).mean())


#But below is not OK , 
> df.groupby('A').transform(lambda x: (x['C'] - x['D']))
ValueError: could not broadcast input array from shape (5) into shape (5,3)

> df.groupby('A').transform(lambda x: (x['C'] - x['D']).mean())
 TypeError: cannot concatenate a non-NDFrame object
 
#Actual usage of Transform ,  
zscore = lambda x: (x - x.mean()) / x.std() # Note that it does not reference anything outside of 'x' and for transform 'x' is one column.
>>> df.groupby('A').transform(zscore) #for each column of each group 

       C      D
0  0.989  0.128
1 -0.478  0.489
2  0.889 -0.589
3 -0.671 -1.150
4  0.034 -0.285
5  1.149  0.662
6 -1.404 -0.907
7 -0.509  1.653
#But 
>>> df.groupby('A').apply(zscore) 
ValueError: operands could not be broadcast together with shapes (6,) (2,)

#Which is exactly the same 
>>> df.groupby('A')['C'].transform(zscore)
#or 
>>> (df.groupby('A')['C'].apply(zscore))
0    0.989
1   -0.478
2    0.889
3   -0.671
4    0.034
5    1.149
6   -1.404
7   -0.509

#Another Usecase:- trying to assign results of reduction function back to original dataframe.
df['sum_C'] = df.groupby('A')['C'].transform(sum)
df.sort('A') # to clearly see the scalar ('sum') applies to the whole column of the group
#Output 
     A      B      C      D  sum_C
1  bar    one  1.998  0.593  3.973
3  bar  three  1.287 -0.639  3.973
5  bar    two  0.687 -1.027  3.973
4  foo    two  0.205  1.274  4.373
2  foo    two  0.128  0.924  4.373
6  foo    one  2.113 -0.516  4.373
7  foo  three  0.657 -1.179  4.373
0  foo    one  1.270  0.201  4.373

#Trying the same with .apply would give NaNs in sum_C. 
#Because .apply would return a reduced Series, which it does not know how to broadcast back:
df.groupby('A')['C'].apply(sum)
#Output 
A
bar    3.973
foo    4.373

#There are also cases when .transform is used to filter the data:
df[df.groupby(['B'])['D'].transform(sum) < -1]

     A      B      C      D
3  bar  three  1.287 -0.639
7  foo  three  0.657 -1.179







GroupBy.pipe(func, *args, **kwargs)
    Apply a function with arguments to this GroupBy object,
    Parameters:
    func : callable or tuple of (callable, string)
        Function to apply to this GroupBy object or, 
        alternatively, a (callable, data_keyword) tuple 
        where data_keyword is a string indicating the keyword of callable that expects the GroupBy object.
        Note function gets full groupedBy dataframe with it's groupby column as index 
    args : iterable, optional
        positional arguments passed into func.
    kwargs : dict, optional
        a dictionary of keyword arguments passed into func.
 
#Use .pipe when chaining together functions that expect Series, DataFrames or GroupBy objects. 
#Instead of writing
>>> f(g(h(df.groupby('group')), arg1=a), arg2=b, arg3=c)
#You can write
>>> (df
        .groupby('group')
        .pipe(f, arg1)
        .pipe(g, arg2)
        .pipe(h, arg3))
        

df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})
>>> df
   A  B
0  a  1
1  b  2
2  a  3
3  b  4


#To get the difference between each groups maximum and minimum value in one pass, you can do
>>> df.groupby('A').pipe(lambda g: g.max() - g.min()) #g is groupedFataframe 
   B
A
a  2
b  2


##Difference between pipe and apply 
#Pipe function takes entire Groupby result DataFrame including groupby columns as index 
#Apply function takes only DF of each group's remaining columns (excluding groupby columns)

df = pd.DataFrame(dict(
    A=list('XXXXYYYYYY'),
    B=range(10)
))

   A  B
0  X  0
1  X  1
2  X  2
3  X  3
4  Y  4
5  Y  5
6  Y  6
7  Y  7
8  Y  8
9  Y  9

#Example 1
#Make the entire 'B' column sum to 1 while each sub-group sums to the same amount. 
#This requires that the calculation be aware of how many groups exist. 
#This is something we can't do with apply because apply wouldn't know how many groups exist.
s = df.groupby('A').B.pipe(lambda g: df.B / g.transform('sum') / g.ngroups)
s

0    0.000000
1    0.083333
2    0.166667
3    0.250000
4    0.051282
5    0.064103
6    0.076923
7    0.089744
8    0.102564
9    0.115385
Name: B, dtype: float64

#Note:
s.sum()

0.99999999999999989

#And:
s.groupby(df.A).sum()

A
X    0.5
Y    0.5
Name: B, dtype: float64


#Example 2 -  Subtract the mean of one group from the values of another. 
#Again, this can't be done with apply because apply doesn't know about other groups.
df.groupby('A').B.pipe(
    lambda g: (
        g.get_group('X') - g.get_group('Y').mean()
    ).append(
        g.get_group('Y') - g.get_group('X').mean()
    )
)

0   -6.5
1   -5.5
2   -4.5
3   -3.5
4    2.5
5    3.5
6    4.5
7    5.5
8    6.5
9    7.5
Name: B, dtype: float64



DataFrameGroupBy.filter(func, dropna=True, *args, **kwargs)
    Return a copy of a DataFrame excluding elements from groups 
    that do not satisfy the boolean criterion specified by func.
    Parameters:
        f : function
            Function to apply to each subframe. Should return True or False.
            f takes full DF 
        dropna : Drop groups that do not pass the filter. True by default;
            if False, groups that evaluate False are filled with NaNs.
    Returns:
    filtered : DataFrame 


#Example 
import pandas as pd
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})
grouped = df.groupby('A')
>>> grouped.filter(lambda x: x['B'].mean() > 3.)
     A  B    C
1  bar  2  5.0
3  bar  4  1.0
5  bar  6  9.0



##DF-Melt Example 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data, columns=['weekday',
        'Person 1', 'Person 2', 'Person 3'])
#output 
     weekday  Person 1  Person 2  Person 3
0     Monday        12        10         8
1    Tuesday         6         6         5
2  Wednesday         5        11         7

#How can you do group by on person 
#this is not normalized table 
#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
#output 
     weekday    Person  Score
0     Monday  Person 1     12
1    Tuesday  Person 1      6
2  Wednesday  Person 1      5

#umpivot 
#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
#output 
Person    Person 1  Person 2  Person 3
weekday
Friday          11         8         7
Monday          12        10         8
#reset_index()
pm2 = pm.reset_index()



##excel style pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

#or to get to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])
##Compute a simple cross-tabulation of two (or more) factors
pandas.crosstab(index, columns, values=None, rownames=None, colnames=None, 
        aggfunc=None, margins=False, margins_name='All', 
        dropna=True, normalize=False)
    index : array-like, Series, or list of arrays/Series
        Values to group by in the rows
    columns : array-like, Series, or list of arrays/Series
        Values to group by in the columns
    values : array-like, optional
        Array of values to aggregate according to the factors. 
        Requires aggfunc be specified.
    aggfunc : function, optional
        If specified, requires values be specified as well
    rownames : sequence, default None
        If passed, must match number of row arrays passed
    colnames : sequence, default None
        If passed, must match number of column arrays passed
    margins : boolean, default False
        Add row/column margins (subtotals)
    margins_name : string, default 'All'
        Name of the row / column that will contain the totals when margins is True.
    dropna : boolean, default True
        Do not include columns whose entries are all NaN
    normalize : boolean, {'all', 'index', 'columns'}, or {0,1}, default False
        Normalize by dividing all values by the sum of values.
        •If passed 'all' or True, will normalize over all values.
        •If passed 'index' will normalize over each row.
        •If passed 'columns' will normalize over each column.
        •If margins is True, will also normalize margin values.

#Example 
df = pd.DataFrame({'A': [1, 2, 2, 2, 2], 'B': [3, 3, 4, 4, 4],
                   'C': [1, 1, np.nan, 1, 1]})
>>> df
   A  B    C
0  1  3  1.0
1  2  3  1.0
2  2  4  NaN
3  2  4  1.0
4  2  4  1.0
>>> pd.crosstab(df.A, df.B)
B  3  4
A      
1  1  0
2  1  3
>>> pd.crosstab(df.A, df.B, values=df.C, aggfunc=np.sum, normalize=True,margins=True)
B       3    4   All
A                   
1    0.25  0.0  0.25
2    0.25  0.5  0.75
All  0.50  0.5  1.00

foo = pd.Categorical(['a', 'b'], categories=['a', 'b', 'c'])
bar = pd.Categorical(['d', 'e'], categories=['d', 'e', 'f'])
>>> pd.crosstab(foo, bar)
col_0  d  e  f
row_0         
a      1  0  0
b      0  1  0
c      0  0  0
##Datetime based indexing 
#Freq 
#check http://pandas.pydata.org/pandas-docs/stable/timeseries.html#offset-aliases for offset aliases, 
#note for multiple, you can give '5H' ie every 5th hour 
#check https://github.com/pandas-dev/pandas/blob/master/doc/source/timeseries.rst#id11        
#eg '2Q'  denotes two quarterly, '30min' means 30 min

#Weekly can take day to denote which day of week eg 'W-MON' means Monday of week
#Q can take Month eg 'Q-Feb' means every 2nd month of Q

#B,D,H,Min,S,MS,U,N can be combined eg '30min20s' means 30 min 20 second
#eg '2H20min30s' , '2D12H20Min30s'


#datetime based freq= 'M', 'D'(default), 'Y','YS','Q','W','H',
#'T'(min),'S'(sec),'ms','us', or n muliples eg "nH" or combination "xD yH zT"
#start is generally "yyymmdd" or "yyyDELIMmmDELIMdd" where DELIM is some deliminator 
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],index=pd.date_range('20130101',periods=100000,freq='T')) 
ts = pd.Series(np.random.randn(100000), index=pd.date_range('20130101',periods=100000,freq='T'))

>>> dft.head()
                            A
2013-01-01 00:00:00  0.602450
2013-01-01 00:01:00 -2.708178
2013-01-01 00:02:00 -0.087823
2013-01-01 00:03:00  0.351917
2013-01-01 00:04:00 -0.231122

#Accessing 
dft.iloc[0:3]
dft.iloc[0:3, 0]
dft.iloc[0:3, [0]]

#for index based indexing 
from datetime import datetime
#For specific exact index for Only DF , use .loc[] 
dft['2013-01-01 00:00:00'] #ERROR 
dft[datetime(2013, 1, 1)] #equivalent to exact  #ERROR 

#use below 
dft.loc['2013-01-01 00:00:00']
dft.loc[datetime(2013, 1, 1)] 

#note for Series, below works 
ts['2013-01-01 00:00:00']
ts[datetime(2013, 1, 1)]
ts.loc[datetime(2013, 1, 1)]

#for both DF and Series- any partial date string or slice of exact index works 
dft['2013-01-01 00:00:00':'2013-01-01 00:04:00']
dft['2013-1-1']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime(2013, 1, 1):datetime(2013,2,28)] #exact start and stop time 
dft[datetime(2013, 1, 1, 10, 12, 0):datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 

dft.loc['2013', 'A']  
dft.loc['2013', ['A']]  

#Note 
ts[0] #first item , scalar 
#but 
dft[0] #error as for DF, [] includes column label 
dft['A'] #OK 
#but for slicing , works as it is row slicing 
ts[0:5]
dft[0:5]


###Pandas- String, Datetime and categorical columns -- ADVANCED 

##If a DF's Column or Series or Index is of strings , check string methods 
df = pd.DataFrame({'A': ['cat', 'dog', 'bat']})
dir(df.A.str)
df.A.str.lower() #elementwise 
#other methods- similar to 'str' class 
#concatenation 
df['B'] = df.A 
df.A.str.cat(df.B, sep=':') #A and B values concatenated and returns a series 
df.A.str.cat(['1' for i in range(len(df.A))], sep='-')
df.A.str.cat(sep='-') #'cat-dog-bat'

#contains , match 
df.A.str.contains('c') #boolean series 
df.A.str.contains(r'c.{2}')
df.loc[df.A.str.contains(r'c.{2}'), 'B']
df.loc[df.A.str.match(r'cat|dog'), 'B']

#Extract - named group's name become column name 
df.A.str.extract(r'(?P<first>.)(?P<rest>.+)') #DF with two columns first, rest 

#get(index)
df.A.str.get(0)  #first char 

#findall 
df.A.str.findall(r'cat|dog')  #Series of result, note, result is list like str 
>>> df.A.str.findall(r'cat|dog')
0    [cat]
1    [dog]
2       []
Name: A, dtype: object
>>> df.A.str.findall(r'cat|dog').str.get(0)
0    cat
1    dog
2    NaN
#split, join 
>>> df.A.str.split("a")
0    [c, t]
1     [dog]
2    [b, t]
Name: A, dtype: object
>>> df.A.str.split("a").str.join(":")
0    c:t
1    dog
2    b:t
Name: A, dtype: object
#replace ,slice
df.A.str.replace(r'(\w+)', r'\1s')
df.A.str.slice(0,None,2) #0::2

#other 
str.capitalize() 	
str.center(width[, fillchar])
str.count(pat[, flags]) 	
str.decode(encoding[, errors]) 	
str.encode(encoding[, errors]) 	
str.endswith(pat[, na]) 	
str.find(sub[, start, end]) 	
str.get(i) 	
str.index(sub[, start, end]) 	
str.join(sep) 	
str.len() 	
str.ljust(width[, fillchar]) 	
str.lower() 	
str.lstrip([to_strip]) 	
str.normalize(form) 	
str.pad(width[, side, fillchar]) 	
str.repeat(repeats) 	
str.rfind(sub[, start, end]) 	
str.rindex(sub[, start, end]) 	
str.rjust(width[, fillchar]) 	
str.rstrip([to_strip]) 	
str.rsplit([pat, n, expand]) 	
str.startswith(pat[, na]) 	
str.strip([to_strip])
str.swapcase()
str.title()
str.upper()
str.isalnum()
str.isalpha()
str.isdigit()
str.isspace()
str.islower()
str.isupper()
str.istitle()
str.isnumeric()
Series.str.isdecimal()

##if a DF's Column or Series or Index is of datetime , check datetime methods 
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],
    index=pd.date_range('20130101',periods=100000,freq='T')) 
dft = dft.reset_index() #old index would become a column 'index'
#note df.index and df['index'] are different 
dft.rename(columns={'index':'B'}, inplace=True)
dft.columns  #B,A

dir(dft.B.dt)

# .date, .time, .timetz, .year, .month, .day, .hour, .minute, .second, 
# .microsecond, .nanosecond, .week, .weekofyear, .dayofweek, .weekday, 
# .dayofyear, .quarter, .is_month_start, .is_month_end, .is_quarter_start, 
# .is_quarter_end, .is_year_start, .is_year_end, 
# .is_leap_year, .daysinmonth, .days_in_month, 
# .tz, .freq 	
dft.B.dt.hour #elementwise 
dft.B.dt.normalize()  #Convert times to midnight
dft.B.dt.strftime('%B %d, %Y, %r') #format 
#.floor(freq), .ceil(freq)
dft.B.dt.round('H') #Perform round operation on the data to the specified freq.



##if a DF's Column or Series or Index is of type categorical, check category method 
df = pd.DataFrame({'A': pd.Series(["a","b","c","a"], dtype="category"),
                'B': ['cat','cat','bat','bat']})
                
df['B']=df.B.astype('category')

dir(df.A.cat)
df.A.cat.categories   #Index(['a', 'b', 'c'], dtype='object')
df.A.cat.codes  #Seris of 0,1,2,0

df.A.cat.rename_categories([1,2,3]) #'a' by 1, so on , value gets changes 
df.A.cat.set_categories(['a','b'],ordered=True) #c would be Nan , Categories (2, object): [a < b]

df.A.cat.add_categories(['d']) #Categories (4, object): [a, b, c, d]
df.A.cat.add_categories(['d']).cat.remove_categories(['d']) #Categories (3, object): [a, b, c]
df.A.cat.add_categories(['d']).cat.remove_unused_categories()#Categories (3, object): [a, b, c]

df.A.cat.as_ordered()  #Categories (3, object): [a < b < c]
#now can be compared 
df.A.cat.as_ordered() > 'b' #False,False, True,False
df.A.cat.as_unordered() #Categories (3, object): [a, b, c]
df.A.cat.ordered  #False 
df.A.cat.reorder_categories(['b','c','a'], ordered=True)#Categories (3, object): [b < c < a]













###Deep Dive into Pandas -- ADVANCED 
#Various Creation
pd.DataFrame([{'A':1, 'B':1},{'A':2, 'B':2}])
pd.DataFrame( np.array([[1,2],[3,4]]), columns=['A', 'B'])
pd.DataFrame([[1,2],[3,4]], columns=['a','b'])
df = pd.DataFrame({'A': [1,2,3], 'B':[1,2,3]})
df.head()

#For conversion use, pd.to_numeric(arg), pd.to_datetime(arg, ,format='%Y %m %d'), 
#pd.to_timedelta(arg, unit='ns')
df1 = pd.DataFrame({'A': ['1', '2'], 'B':['20181231', '20180304'],
                     'C': [10000, 10000]})

                     #new column creation and accessing 
df1['AA'] = pd.to_numeric(df1.A)
df1['BB'] = pd.to_datetime(df1.B ,format='%Y%m%d')
df1['CC'] = pd.to_timedelta(df1.C, unit='ns')

#drop a column 
df1.drop('C', inplace=True, axis=1) #axis=0, for row, axis=0 for column 
df1.drop(0,  axis=0)  #0th row 

#rename 
df1.rename(columns={'CC': 'C'}, inplace=True)
#rename index 
df1.index 
df1.index  = [10,20]
#or
df1.index = [0,1]
df1r = df1.rename({0:20, 1:30}, axis='index')

#creation of new row and column, if existing in earlier, get value from earlier 
#else, put Nan or fill_value 
>>> df1
   A         B  AA               C         BB
0  1  20181231   1 00:00:00.000010 2018-12-31
1  2  20180304   2 00:00:00.000010 2018-03-04
#creation of two new row, 10,20 and one column 'a'
df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'])
df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'], fill_value=0)


#rename all columns name s
cols = df1.columns.tolist()
n_cols = {c: c + "1" for c in cols}
df11 = df1.rename(columns=n_cols)

#copy and append 
df2 = df1.copy()
df3 = pd.concat([df1,df2], axis=0) #rowwise stack 
df3 = pd.concat([df1,df2], axis=0).reset_index() #reseting index 
df3 = pd.concat([df1,df2], axis=0, ignore_index=True) #reseting index 
#or 
df2.append(df1)    #index copied 
df2.append(df1, ignore_index=True) #equivlent to reset_index

df4 = pd.concat([df1,df11], axis=1)  #columnwise stack for same index
df5 = pd.concat([df1,df1r], axis=1) #creates Nan
df5.columns =list( "ABCDEFGHIJ") #change column names(earlier has dumplicates

#dropna, fillna , inplace=False 
df5.dropna(axis=0, how='all') #row wise, if row consists of 'all' or 'any' Nan
df5.dropna(axis=0, how='any')
df5.dropna(axis=1, how='any')  #columnwise 

df5.fillna(0)   #nan by 0 
df5.fillna({'A': 0})   #only A



#replace 
df1.replace('1', 20)  #one valye by one value 
df1.replace({'A':'1'}, 20) #only for A 
df1.replace({'A':{'1':20}})  #Only for A, '1'
df1.replace({'A':'1'}, {'A':20}) #Another way 
df1.replace(['1','2'], 20) #multiple values 
df1.replace(['1','2'], [20,30])

#map(only for series, convert one value to other)
df1.A.map({'1': 'cat', '2':'dog'}) #missing  = Nan 
#or takes a fun (each element)
df1.A.map(lambda e: 'cat', na_action='ignore') #NaN values would not be passed to fn 

#apply for Series(fn takes each element) 
df1.A.apply(lambda e: len(e))
#or fn takes an ufunc 
df1.AA.apply(np.log)

#with conversion 
df1.AA.apply(str)
#or
df1.AA.astype('str')
df1.A.astype(np.float64) #conversion 
df1[['A', 'A']].astype(np.float64) #works with DF as well 

#applymap:DF (fn takes each element)
df1[['A','B']].applymap(lambda e: len(e))

#apply: DF(fn = ufunc takes full Series/columns)
df1[['A','B']]
df1[['A','B']].apply(lambda col : len(col)) #column wise , ie get each column value
df1[['A','B']].apply(lambda col : len(col), axis=1) #rowwise, ie get each row value 

df1[['AA', 'AA']].apply(np.sum)  #columnwise 
df1[['AA', 'AA']].apply(np.sum, axis=1) #rowwise  

#threeways - replace 
df5 = pd.DataFrame({'A':[0, np.nan, 0, np.nan], 'B':[np.nan, 0, np.nan, 0]})
df5.fillna({'A': 0})
df5.replace({'A':{np.nan:0}})
df5.loc[df5.A.isnull(), 'A'] = 0



###Pandas and CSV  
import pandas as pd 
import matplotlib.pyplot as plt
path = r"data\iris.csv"
iris = pd.read_csv(path)
iris.head()
iris.columns
len(iris.columns)
len(iris.index)
iris.dtypes
iris['SepalRatio'] = iris.SepalLength/iris['SepalWidth']
iris['PetalRatio'] = iris.PetalLength/iris.PetalWidth
iris['dummy'] = iris.SepalRatio * 2 + iris.PetalRatio
iris[['SepalLength', 'PetalLength']]

iris.SepalRatio.mean()
iris.loc[iris.SepalRatio > iris.SepalRatio.mean(), :]

iris.iloc[100:150, ['SepalLength', 'PetalLength']]

#Return new DF 
>>> (iris.assign(sepal_ratio = iris['SepalWidth'] / iris['SepalLength']).head())
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200


#Or use function of one argument which is the  DF
>>> iris.assign(sepal_ratio = lambda df: (df['SepalWidth'] /df['SepalLength'])).head()
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200



#Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:

(iris.query('SepalLength > 5').assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength,            
                     PetalRatio = lambda df: df.PetalWidth / df.PetalLength)   
                .plot(kind='scatter', x='SepalRatio', y='PetalRatio'))
plt.show()

#Clearly two clusters 
iris_m = iris.assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength, PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')

##Quick K-Means - Find those two clusters 
from sklearn.cluster import KMeans
numpy_features = iris_m[ ['SepalRatio','PetalRatio' ]].values
kmeans = KMeans(n_clusters=2, random_state=0).fit(numpy_features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
       
#unique Name 
iris.Name.unique()
#many str methods 
iris.Name.str.lower()
iris.Name.str.split("-") #gives a column with list of strings 
df = iris.Name.str.split("-", expand=True) #each list element becomes one column 
df.columns = ['part1', 'par2']
#merge 
pd.concat([iris, df], axis=1)  #columnwise stack 

>>> np.unique(iris.Name.apply(lambda x: un.tolist().index(x)))
array([0, 1, 2], dtype=int64)
#apply for Series, fn takes each element, 
#for DF, fn takes each col if axis=0 else takes each row if axis=1
iris["target"] = iris.Name.apply(lambda x: un.tolist().index(x))

#Get the first five rows of a column by name
iris['SepalLength'][:5]                     #Series
iris[ [ 'SepalLength', 'SepalWidth'] ][:5]  #DF 


#Create categorical ranges for numerical data. 14 is number of bins
sl_bin = pd.cut(iris['SepalLength'], 14)
sl_bin[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(sl_bin)
sl_bin.value_counts()

#Access through .cat 
iris["category"] = sl_bin
iris.category.cat.categories
#to get index of each bin 
iris.category.cat.rename_categories(range(14))

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
iris.ix[0,0:6]

#Order the data by specified column
iris['SepalLength'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = iris.sort_values(by=['SepalLength', 'PetalLength'])  #DF
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
iris['PetalLength'].value_counts()

#to obtain the datatype 
iris.dtypes

#Get the unique values for a column by name.
iris['Name'].unique()

#Get a count of the unique values of a column
len(iris['Name'].unique())

#Index into a column and get the first four rows
iris.ix[0:3,'Name']

#Obtain True/False  values which could be used inside iloc, loc etc 
iris.ix[:,'Name'] == 'Iris-setosa'
#Can get any columns , use  | , &, ~ for boolean conjunction, disjunction and inverse 
iris.loc[iris['Name'] == 'Iris-setosa', 'SepalLength']  #Series
iris.ix[iris['Name'] == 'Iris-setosa', 0] #note .iloc with boolean not available 
iris.loc[iris['Name'] == 'Iris-setosa', ['SepalLength','PetalLength']] #DF

#Query the data
qry1 = iris.query('Name == "Iris-setosa"')  #returns DF of original only where cond is valid 
qry1.head(10)

#Check a boolean condition
(iris.ix[:,'SepalLength'] > 4.3).any()


#Return descriptive statistics of the dataset- mean, std etc is calculated for each colu mn
>>> iris.describe()
       SepalLength
count   150.000000
mean      5.843333
std       0.828066
min       4.300000
25%       5.100000
50%       5.800000
75%       6.400000
max       7.900000
>>> iris.Name.describe()
count                 150
unique                  3
top       Iris-versicolor
freq                   50
Name: Name, dtype: object

#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(iris['category'],iris['target']) #DF, multiindex 

#Which same as merge 
#merge(right, how='inner', on=None, left_on=None, right_on=None, left_index=False, right_index=False)
iris.merge(df, right_index=True, left_index=True)

#value counts : value vs count  
iris['PetalLength'].value_counts()
#mean 
iris.mean() #columnwise 
iris.mean(axis=1) #rowwise 
#aggregation 
gr1 = iris.groupby('Name')
gr1.mean()  #DF of each column mean for each Name 
gr1.agg({'SepalLength':
    ['mean', 'max']}).to_csv("processed.csv")
#open data/processed.csv 

#Using UDF 
#drop
df2 = iris.drop(columns='Name')
df2.head()
iris.replace({'Name':{np.nan:0}})

#Conditionally update 
iris['dummy'] = 2
iris.loc[iris['Name'] == 'Iris-setosa', 'dummy'] = 0
#if true, then x else y , where(condition, x, y)
df['dummy'] = np.where(iris['Name'] == 'Iris-setosa', 0, df['dummy'])


#apply with index based access - check reference for axis meaning
iris.iloc[:, 0:4].apply(np.sum)  #columnwise #end exclusive, s-> each column ie pd.Series
iris.iloc[:, 0:4].apply(np.sum, axis=1) #rowwise 

#similar to transform when single series is operated upon 
df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 

#In groupby, there is some difference 
There are two major differences between the transform and apply groupby methods.
Input:
    apply implicitly passes all the columns for each group as a DataFrame 
        to the custom function.
        so below works as x is full DF 
        > df.groupby('A').apply(lambda x: (x['C'] - x['D']))
        > df.groupby('A').apply(lambda x: (x['C'] - x['D']).mean())
    transform passes each column for each group individually as a Series 
        to the custom function.
        so below can not work as x is individual Series 
        > df.groupby('A').transform(lambda x: (x['C'] - x['D']))
        > df.groupby('A').transform(lambda x: (x['C'] - x['D']).mean())
            TypeError: cannot concatenate a non-NDFrame object
Output:
    The custom function passed to apply can return a scalar, 
        or a Series or DataFrame (or numpy array or even list).
    The custom function passed to transform must return a sequence 
        (a one dimensional Series, array or list) the same length(no of rows) as the group.

So, transform works on just one Series at a time 
and apply works on the entire DataFrame at once

#plot
iris.Name.value_counts().plot(kind='bar')
plt.show()

#How Many Factors - 3 
iris['index'] = iris.index
iris.plot(x='index', y='SepalLength', kind='scatter')
plt.show()

iris.plot(x='SepalWidth', y='SepalLength', kind='scatter')
plt.show()
iris.iloc[:,0:4].plot(kind='line')
#dont dow below as many plots 
plt.show()
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#or 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.savefig('plot.png')
#or in one plot 
#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label, title='SepalLength')

plt.tight_layout()
plt.legend()
plt.show()

##Using To sql 
from sqlalchemy import create_engine
engine = create_engine('sqlite:///iris.db', echo=False)

iris.to_sql('iris', con=engine,if_exists='replace') 
#{'fail', 'replace', 'append'}, default 'fail'
#index : bool, default True

engine.execute("select * from iris").fetchall()

engine.execute("SELECT max(SepalLength) , count(*) FROM iris group by Name").fetchall()

pd.read_sql('iris', con=engine) 
pd.read_sql('select * from iris', con=engine) 



##More Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, pip install seaborn

iris.Name.value_counts().plot(kind='bar')
plt.show()
#with x and y 
iris.plot(x=None, y='SepalWidth', kind='line')
plt.show()
#full DF 
iris.plot( kind='line')
plt.show()
#for sub DF 
iris.iloc[:,0:4].plot(kind='line')
plt.show()
#with groupby 
iris.groupby('Name').plot(kind='line')
plt.show()
#as subplots 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#for partial DF 
iris.iloc[:,0:5].groupby('Name')['SepalLength'].plot(kind='line', subplots=True)
plt.show()

#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label)
plt.legend()
plt.show()

#all 
#https://matplotlib.org/users/colormaps.html
cm =['Blues', 'Greens', 'Reds']
fig, ax = plt.subplots(figsize=(8,6))
x_label = []
for i,(label, df) in enumerate(iris.groupby('Name')):
    x_label.append(label)
    df.plot(kind='line', ax=ax, colormap=cm[i])

plt.xlabel(x_label)
plt.legend()
plt.show()

#note 
iris.plot(kind='line') 
#is equivalent to 
iris.plot.line()
#and similarly for others 

#with subplots 
#multiple in one plot 
iris.plot(kind='line', y=['SepalLength','PetalLength'] )
#with subplots 
iris.plot(kind='line', y=['SepalLength','PetalLength'], subplots=True )

#Bar plot of median values
iris.groupby('Name')['SepalLength'].agg(np.mean).plot(kind = 'bar')
plt.show()

#Scatter_matrix or sns.pairplot
#hue is categorical data and for each hue, scatter_matrix is done
sns.pairplot(iris.iloc[:,0:5], hue='Name', size=2.5)
plt.show()

from pandas.plotting import scatter_matrix
scatter_matrix(iris.iloc[:,0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#for only one Name 
scatter_matrix(iris.ix[iris.Name=='Iris-virginica',0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#only density plot 
iris.SepalLength.plot.kde()
plt.show()
#or 
sns.kdeplot(iris.SepalLength)
sns.kdeplot(iris.SepalWidth)
plt.show()
#or
sns.distplot(iris.SepalLength)
plt.show()
#for bivariate kernel density estimate
sns.kdeplot(iris.iloc[:,0:4]) #bivariate kernel density estimate
plt.show()
#joint distribution of x,y and the marginal distributions (joit distribution with one const)
#For this plot, we'll set the style to a white background
#pearsonr = correlation coefficient  , -1 to 1, 0= not correlated, H0:not correlated 
#kind : { “scatter” | “reg” | “resid” | “kde” | “hex” }, optional
with sns.axes_style('white'):
    sns.jointplot(x="SepalLength", y="PetalLength", data=iris.iloc[:,0:4], kind='kde');

plt.show()

#Box plot - x= x axis categorical data, y= box plot variable  , hue=categorical data, for each, x vs y box plot is done 
#box plot - box-25%,median, 75%(third quartiles), min-max data - some convension of min and max - https://en.wikipedia.org/wiki/Box_plot, outliers
#seaborn.factorplot(x=None, y=None, hue=None, data=None, row=None, col=None, col_wrap=None, estimator=<function mean>, ci=95, n_boot=1000, units=None, order=None, hue_order=None, row_order=None, col_order=None, kind='point', size=4, aspect=1, orient=None, color=None, palette=None, legend=True, legend_out=True, sharex=True, sharey=True, margin_titles=False, facet_kws=None, **kwargs)
#kind : {point, bar, count, box, violin, strip}
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Barplot 
g = sns.factorplot(x="Name", data=iris.iloc[:,0:5], aspect=2,  kind="count", color='steelblue')


###Excel-pandas 
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parse_dates=True, index_col=0, header=0)
# date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
#from pandas.tseries.offsets import *
#dft.index.freq = Day() #set freq as D 
##if above does not work 
#dft.index.freq = pd.tseries.frequencies.to_offset(Day())
#
dft = dft.asfreq('D')


dft['Open'] #OK 
dft[0:5]

import datetime
#For specific exact index for DF , use .loc 
#dft['2000-06-01'] #ERROR 
#dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
dft.loc['2000-06-01']
dft.loc['2000-06-01', 'Open']

dft.iloc[0]
dft.loc[datetime.date(2000, 6, 1)] 
#for both DF and Series- any partial date string or slice of exact index works 
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day

dft.Close.plot(kind='line')
plt.show()

#which year , stock market crashed 
dft_s = dft.resample('Y')  #'M' , for version <19.2, it is 'A'
dir(dft_s)
#month value would be mean()
dft_s['Open'].mean()   #
sr = dft_s[['Open', 'Close']].first() 
#shift one and drop na 
sr['Close'] = sr.Close.shift(-1)
sr.dropna(how='any', axis=0, inplace=True)
import numpy as np 
sr['diff'] = np.abs(sr.Close - sr.Open)
sr['diff'].idxmax()
sr.loc[[sr['diff'].idxmax()]].index.year.tolist() #DF required 

##other
dft_s = dft.resample('M')
dft_s.mean() #DF 
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})
sr = dft_s['Open'].first().to_frame() #series to DF 
sr.loc[sr['diff'].idxmax()]
sr['Year'] = sr.index.year  #date.astype(np.datetime64)


#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')



###More Excel - Example -- ADVANCED 
df = pd.read_excel("data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225


#Q= "What percentage of the order total does each order represent?"
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]

#Or using openpyxl 
from openpyxl import load_workbook

wb = load_workbook(filename =r"data\Nifty-17_Years_Data-V1.xlsx", 
    data_only=True) #default false, so only read formula 
wb.get_sheet_names()

sheet = wb['Sheet1'] #or wb.worksheets[0]
sheet['A18'].value #datetime 
[(c1.value, c2.value) for c1, c2 in sheet['A1': 'B6']]
data  = []
#Iterating by rows, ie row by row 
#index from 1
for row in sheet.iter_rows(min_row=2):  #sheet.max_row, sheet.max_column
    r = []
    for cell in row:
        r.append(cell.value)
    data.append(r)

rows = sheet.rows #generator, can not remove header 

###Example Pandas - More Data processing -- ADAVNCED

#Step-1
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline

#enable high-resolution matplotlib on retina display 
from IPython.display import set_matplotlib_formats 
set_matplotlib_formats('retina')

#Step-2  :daily attendance of bike tracks
url = "https://raw.githubusercontent.com/ndas1971/Misc/master/bikes.csv"

df = pd.read_csv(url, index_col='Date', parse_dates=True, dayfirst=True)

#Step-3 : Check 
df.head(2)

#Step-4: summary statistics 

df.describe()

#Step-5: plot the daily attendance of two tracks
df[['Berri1', 'PierDup']].plot(figsize=(10, 6),
                               style=['-', '--'],
                               lw=2)


#Step-6: Check index 
df.index.weekday_name

#Step-7: To get the attendance as a function of the weekday
df_week = df.groupby(df.index.weekday).sum()
df_week

#Step-8: Display this in figure 
fig, ax = plt.subplots(1, 1, figsize=(10, 8))
df_week.plot(style='-o', lw=3, ax=ax)
ax.set_xlabel('Weekday')
# We replace the labels 0, 1, 2... by the weekday  names.
ax.set_xticklabels( 'Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday').split(','))
ax.set_ylim(0)  # Set the bottom axis to 0.

#Step-9: interactive capabilities of the Notebook. 
#plot a smoothed version of the track attendance as a function of time (rolling mean)

from ipywidgets import interact,interact_manual

@interact(n=(1, 30))
def plot(n=5):
    fig, ax = plt.subplots(1, 1, figsize=(10, 8))
    df['Berri1'].rolling(window=n).mean().plot(ax=ax)
    ax.set_ylim(0, 7000)
    plt.show()
  
#@interact_manual decorator  provides a button to call the function manually
@interact_manual(n=(1, 30))
def plot(n=5):
    fig, ax = plt.subplots(1, 1, figsize=(10, 8))
    df['Berri1'].rolling(window=n).mean().plot(ax=ax)
    ax.set_ylim(0, 7000)
    plt.show()

    
    
###More pandas and matplotlib -- ADAVNCED
#Use dataset containing all ATP matches played by the Swiss tennis player Roger Federer until 2012.

from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline

#Use 
player = 'Roger Federer'
df = pd.read_csv("https://raw.githubusercontent.com/ndas1971/Misc/master/federer.csv",
                 parse_dates=['start date'],
                 dayfirst=True)

df.head(3)

#select some 
df['win'] = df['winner'] == player
df['win'].tail()

#Calculate some 
won = 100 * df['win'].mean()
print(f"{player} has won {won:.0f}% of his matches.")

#Check some time dependent data 
date = df['start date']

#eg  proportion of double faults in each match 
df['dblfaults'] = (df['player1 double faults'] /
                   df['player1 total points total'])

#check 
df['dblfaults'].tail()

#stats 
df['dblfaults'].describe()

#Win per surface 
df.groupby('surface')['win'].mean()


#display the proportion of double faults as a function of the tournament date
gb = df.groupby('year')

#use the matplotlib plot_date() function because the x-axis contains dates:

fig, ax = plt.subplots(1, 1)
ax.plot_date(date.astype(datetime), df['dblfaults'], alpha=.25, lw=0)
ax.plot_date(gb['start date'].max().astype(datetime),  gb['dblfaults'].mean(), '-', lw=3)
ax.set_xlabel('Year')
ax.set_ylabel('Double faults per match')
ax.set_ylim(0)

#Reference 
pandas website at https://pandas.pydata.org/
pandas tutorial at http://pandas.pydata.org/pandas-docs/stable/10min.html
Python for Data Analysis, 2nd Edition, Wes McKinney, O'Reilly Media, at http://shop.oreilly.com/product/0636920050896.do


###Streamlit Introductions 
Installed in anaconda3 
#streamlit latest requires plotly >5.0.0 
pip install plotly --upgrade 
pip install streamlit

Many examples 
https://github.com/streamlit/streamlit/tree/develop/examples

#Share the  app
Put the  app in a public GitHub repo (and make sure it has a requirements.txt!)
Sign into share.streamlit.io
Click 'Deploy an app' and then paste in your GitHub URL

#Example 
$ streamlit run first_app.py 

#Code 
import streamlit as st
import pandas as pd
import numpy as np

st.title('Uber pickups in NYC')

DATE_COLUMN = 'date/time'
DATA_URL = ('https://s3-us-west-2.amazonaws.com/'
            'streamlit-demo-data/uber-raw-data-sep14.csv.gz')

@st.cache_data
def load_data(nrows):
    data = pd.read_csv(DATA_URL, nrows=nrows)
    lowercase = lambda x: str(x).lower()
    data.rename(lowercase, axis='columns', inplace=True)
    data[DATE_COLUMN] = pd.to_datetime(data[DATE_COLUMN])
    return data

data_load_state = st.text('Loading data...')
data = load_data(10000)
data_load_state.text("Done! (using st.cache_data)")

if st.checkbox('Show raw data'):
    st.subheader('Raw data')
    st.write(data)

st.subheader('Number of pickups by hour')
hist_values = np.histogram(data[DATE_COLUMN].dt.hour, bins=24, range=(0,24))[0]
st.bar_chart(hist_values)

# Some number in the range 0-23
hour_to_filter = st.slider('hour', 0, 23, 17)
filtered_data = data[data[DATE_COLUMN].dt.hour == hour_to_filter]

#requires token from https://mapbox.com 
#st.subheader('Map of all pickups at %s:00' % hour_to_filter)
#st.map(filtered_data)
st.subheader('DataFrame of all pickups at %s:00' % hour_to_filter)
st.dataframe(filtered_data)



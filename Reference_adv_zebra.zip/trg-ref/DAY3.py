###Example ML-  Pipeline, GridSearch 

##Iris - Transformation and Feature Selection 
iris = pd.read_csv('data/iris.csv')
X_raw = iris.iloc[:, 0:4].astype(np.float64)
y_raw = iris.iloc[:, 4]
lenc = LabelEncoder()
std =  MinMaxScaler()   #StandardScaler() #SelectKBest requires + input , check with X[X<0]
X = std.fit_transform(X_raw)
y = lenc.fit_transform(y_raw)


# This dataset is way too high-dimensional. Better do PCA:
X_new = PCA(n_components=1).fit_transform(X,y)  #X_new.shape #(150, 1)

# Maybe some original features where good, too?
X_new_2 = SelectKBest(chi2, k=1).fit_transform(X,y)  #X_new.shape#(150, 1)

#OR Build estimator from PCA and Univariate selection:
pca = PCA(n_components=1)
selection = SelectKBest(chi2, k=1)
combined_features = FeatureUnion([("pca", pca),  ("univ", selection)])

#Apply some regression 
lr = LogisticRegression()
pipeline = Pipeline([("features", combined_features), ("lr", lr)])

pipeline.steps[0]
pipeline.named_steps['lr']
pipeline.get_params()
pipeline.set_params(lr__C=10) 
#Even Replace 
pipeline.set_params(features__pca = KernelPCA(n_components=1,kernel='rbf'))

#OR Grid Search 
pipeline.set_params(features__pca = pca)
param_grid = dict(features__pca__n_components=[1, 2, 3],
                  features__univ__k=[1, 2], lr__C=[0.1, 1, 10])

gs = RandomizedSearchCV(pipeline, param_grid, cv=5)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
gs.fit(X_train, y_train)
final_model = gs.best_estimator_
print(gs.best_params_ )
print(final_model)
y_pred = final_model.predict(X_test)
final_model.score(X_train, y_train)
accuracy_score(y_test, y_pred) #y_true, y_pred

#Save Model 
import pickle 
pickle.dump(gs.best_estimator_, open("final.sklearnModel","wb"))
clf = pickle.load(open("final.sklearnModel", "rb"))
clf.score(X_test, y_test)

###Understanding Matrics with Simple OLS and in scikit-learn only 
boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
Y = boston["target"]
X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)
m = LinearRegression().fit(X_train,y_train)
m.score(X_train,y_train)  #R^2 
m.score(X_test, y_test)
mean_squared_error(y_test, m.predict(X_test))

#coefficients
df = pd.DataFrame(m.coef_, columns=['Coeff'], index=boston["feature_names"])    
df
       
       
#scatter_matrix
from pandas.plotting import scatter_matrix
scatter_matrix(pd.DataFrame(X, columns=boston.feature_names), 
    diagonal='kde')
plt.show()

###Various Other Plots -- ADVANCED 
##Residuals Plot
#Residuals are the difference between  target variable (y) and the predicted value (y), 
#to analyze the variance of the error of the regressor. 
#If the points are randomly dispersed around the horizontal axis, 
#a linear regression model is usually appropriate for the data; 
#otherwise(eg funnel data), a non-linear model(eg GLM, use statsmodels, SVC(nonlinear kernel), Boosting) is more appropriate. 

from yellowbrick.regressor import *

# Instantiate the linear model and visualizer

visualizer = ResidualsPlot(m)

visualizer.fit(X_train, y_train)  # Fit the training data to the model
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
visualizer.poof()                 # Draw/show/poof the data
#visualizer.poof(outpath="pcoords.png") #sve to file, ext determines file type 

#Note that if the histogram is not desired, it can be turned off with the hist=False flag
visualizer = ResidualsPlot(ridge, hist=False)



##Prediction Error Plot
#A prediction error plot shows the actual targets from the dataset against the predicted values 

#Data scientists can diagnose regression models using this plot by comparing against the 45 degree line, 
#where the prediction exactly matches the model.


visualizer = PredictionError(m)

visualizer.fit(X_train, y_train)  # Fit the training data to the visualizer
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
g = visualizer.poof()             # Draw/show/poof the data


##Alpha Selection in Regularization

# Create a list of alphas to cross-validate against
alphas = np.logspace(-10, 1, 400) #logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)

visualizer = AlphaSelection(m)

visualizer.fit(X, Y)
g = visualizer.poof()


##A Q-Q plot is a scatterplot created by plotting two sets of quantiles against one another. 
#If both sets of quantiles came from the same distribution, we should see the points forming a line that's roughly straight. 

#In case of regression, error should come from normal (maches with 45 deg line 
#If there is exponential part in the plot, do a log transform of y 
#Example - qqplot
import statsmodels.api as sm

res = y_train - m.predict(X_train)
fig = sm.qqplot(res)
plt.show()

#log transforms 
#log1p(x) Calculates log(1 + x).
#expm1 exp(x) - 1, the inverse of log1p.


y_train_1 = np.log1p(y_train)
model = model.fit(X_train, y_train_1)
res = y_train_1 - model.predict(X_train)
fig = sm.qqplot(res)
plt.show()
#model 
model.score(X_train, y_train_1)
model.score(X_test, np.log1p(y_test))
y_pred = np.expm1(model.predict(X_test))
mean_squared_error(y_test, y_pred) 

###Various Regressors - ADVANCED  
import time 
data = load_boston()
X, y = data.data, data.target 
CV= KFold(n_splits=5,shuffle=True)
X_train, X_test, y_train, y_test = train_test_split(X,y) #random splitting 

clf1 = DecisionTreeRegressor()
clf2 = RandomForestRegressor(n_estimators=100)
clf3 = ExtraTreesRegressor(n_estimators=100)
clf4 =  AdaBoostRegressor(n_estimators=100)
clf5 =  GradientBoostingRegressor(n_estimators=100)
clf6 = SVR(kernel='rbf')
clf7 = StackingRegressor( estimators=[
                ('lr', RidgeCV()),
                ('svr', LinearSVR(random_state=42))],
                final_estimator=RandomForestRegressor(n_estimators=10))
names = [ 'DT', 'RF', 'ER', 'Ada', 'GBM', 'SVR', "Stack"]
pipe = Pipeline([('reg', clf1)])

grid = dict(
 reg=[clf1,clf2, clf3, clf4, clf5, clf6, clf7], 
)
search = GridSearchCV(pipe, param_grid=grid)
search.fit(X_train,y_train)
search.best_estimator_
search.best_params_
search.score(X_test, y_test)#.87 
#Additional 
search.cv_results_['params'] = names 
search.cv_results_['param_clf'] = names 
search.cv_results_['param_reg'] = names 
df = pd.DataFrame(search.cv_results_)
df
#FImport 
clf5 #the best model or best_estimator_.named_steps['reg']
clf5.feature_importances_
df2 = pd.DataFrame(  
    clf5.feature_importances_,
    index=data.feature_names, columns=['FI'])
df2 = df2.reset_index().sort_values(by=['FI'],ascending=False)   
df2.index = df2['index']
df2.drop('index', axis=1, inplace=True)
df2['FI'] = df2.FI.apply(lambda e: "%d%%" %(e*100,))







### Automatic ML - Tpot -- ADVANCED 
https://towardsdatascience.com/tpot-automated-machine-learning-in-python-4c063b3e5de9
#Execute - 19.1.tpot_regression.py

###Understadning Matrics with Logistic Regression 
#Check 
#https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html

#Note l2 penalty 
#good for overfitting (Ridge) and highly correlated data(as coef shrinkage)
#l1 penalty
#many coef is zero, so feature selection , good for large no of features 

X, y = load_iris(return_X_y=True)
scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

clf = LogisticRegression(random_state=0, solver='lbfgs', multi_class='multinomial').fit(X_train, y_train)

clf.predict(X_test)
clf.predict_proba(X_test)  #predicted prob in each class 
clf.score(X_train, y_train)
clf.score(X_test, y_test)

#check meaning of average 
#https://scikit-learn.org/stable/modules/model_evaluation.html#from-binary-to-multiclass-and-multilabel 
#use weighted 

y_pred = clf.predict(X_test)
accuracy_score(y_test, y_pred)
confusion_matrix(y_test, y_pred)
precision_recall_fscore_support(y_test, y_pred, average='weighted')
precision_score(y_test, y_pred, average='weighted') 	
recall_score(y_test, y_pred, average='weighted') 	
f1_score(y_test, y_pred, average='weighted')
#It is possible to compute per-label precisions, recalls, F1-scores and supports 
#instead of averaging:
precision_recall_fscore_support(y_test, y_pred, average=None)

##Confusion_matric plot 
import seaborn as sns
sns.heatmap(confusion_matrix(y_test,y_pred),annot=True)


##Clasification metrics 
Total case = N = a+b+c+d

        Actual True                             False 
Predicted 
True        a                                   b (false positive) - Type 1 error,alpha

False       c(false negative/alarm)(type-ii)    d

Accuracy = (a+d)/N 
precision = a/(a+b)
recall,sensitivity, probability of detection = a/(a+c)
specificity= d/(b+d)

Recall, Sensitivity : Percentage of positives that are successfully classified as positive
Specificity : Percentage of negatives that are successfully classified as negatives 

Since Classification model predicts probabilities of each class, 
there is some threashold required for calculating True and False. 
Hence for one threshold, we get one pair of Sensitivity and Specificity

Ideally we want to maximize both Sensitivity & Specificity. 
But this is not possible. There is always a trade-off.

Sometimes we want to be 100% sure on Predicted negatives, 
Specificity(eg Testing a medicine is good or poisonous ) ie false positive is zero,
(predicted positive is zero for condition negative)

sometimes we want to be 100% sure on Predicted positives, 
Sensitivity(eg Predicting a customers good or bad before issuing the loan ) 
ie false negative is zero (predicted negative is zero for condition positive)

The threshold is set based on business problem

Sensitivity and Specificity are inversely proportional to each other. 
So when we increase Sensitivity, Specificity decreases When we decrease the threshold, 
we get more positive values thus it increases the sensitivity and decreasing 
the specificity.

As FPR is 1 - specificity. So when we increase TPR(sensitivity), 
FPR also increases and vice versa.

###More Classification matrix -- ADVANCED 
ROC Curve
Consider all the possible threshold values and the corresponding specificity and sensitivity rate
ROC(Receiver operating characteristic) curve is drawn by taking (1- specificity) on X-axis and sensitivity on Y- axis.
    

ROC and AUC
We want that curve to be far away from the straight line. Ideally, we want the area under the curve as high as possible. ie AUC. Area Under the Curve needs to be 1

ROC Curve Gives us an idea on the performance of the model under all possible values of threshold.

AUC=1.0, It is perfectly able to distinguish between positive class and negative class.
AUC=0.7, it means there is 70% chance that model will be able to distinguish between positive class and negative class.
AUC=0.5, model has no discrimination capacity to distinguish between positive class and negative class.
AUC=0.0, model is actually reciprocating the classes. It means, model is predicting negative class as a positive class and vice versa





###NLP Example -- ADVANCED 
#spam/Ham
sp = pd.read_csv("data/spam.csv", encoding='latin-1')[['v1','v2']].dropna() #how='any'
sp.head()
X_raw = sp.iloc[:, 1]
y_raw = sp.iloc[:, 0]

lenc = LabelEncoder()
y = lenc.fit_transform(y_raw)

tf = TfidfVectorizer()
X = tf.fit_transform(X_raw )

X_train, X_test, y_train, y_test = train_test_split( X,y, random_state=0) 
param_grid = dict(C= [0.001, 0.1, 1, 10, 100])
clf = LogisticRegression()
gs = GridSearchCV(clf, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)


#with ngrams 1,2 , y is already LabelEncoded 
tf = TfidfVectorizer(ngram_range=(1,2))
X = tf.fit_transform(X_raw ) #very high now 

svd = TruncatedSVD(n_components=1000)
lr = LogisticRegression()

X_train, X_test, y_train, y_test = train_test_split(X_raw,y, random_state=0) 
pipeline = Pipeline([
    ("tf", tf), 
    ('pca', svd),  
    ("lr", lr)])

param_grid = dict(lr__C=[100,500])
gs = GridSearchCV(pipeline, param_grid) 
gs.fit(X_train, y_train)
print(gs.best_params_) 
gs.score(X_train, y_train)
gs.score(X_test, y_test)



###Example - KNN -- ADVANCED 
#Learning to recognize handwritten digits with a K-nearest neighbors classifier

%matplotlib inline

#load the digits dataset, part of the datasets module of scikit-learn. 
#This dataset contains handwritten digits that have been manually labeled:

digits = load_digits()
X = digits.data
y = digits.target
print((X.min(), X.max()))
print(X.shape)
#(0.0, 16.0)
#(1797, 64)

#In the matrix X, each row contains 8*8=64 pixels (in grayscale, values between 0 and 16). 
#The row-major ordering is used.

#display some of the images along with their labels:

nrows, ncols = 2, 5
fig, axes = plt.subplots(nrows, ncols, figsize=(6, 3))
for i in range(nrows):
    for j in range(ncols):
        # Image index
        k = j + i * ncols
        ax = axes[i, j]
        ax.matshow(digits.images[k, ...],  cmap=plt.cm.gray)
        ax.set_axis_off()
        ax.set_title(digits.target[k])


#fit a K-nearest neighbors classifier on the data:
(X_train, X_test, y_train, y_test) =  train_test_split(X, y, test_size=.25)
knc = KNeighborsClassifier()
knc.fit(X_train, y_train)

#evaluate the score of the trained classifier on the test dataset:
knc.score(X_test, y_test)
#0.987

#now predict 
# Let's draw a 1.
one = np.zeros((8, 8))
one[1:-1, 4] = 16  # The image values are in [0, 16].
one[2, 3] = 16

fig, ax = plt.subplots(1, 1, figsize=(2, 2))
ax.imshow(one, interpolation='none',  cmap=plt.cm.gray)
ax.grid(False)
ax.set_axis_off()
ax.set_title("One")

# We need to pass a (1, D) array.
knc.predict(one.reshape((1, -1)))
#array([1])


#references:
The K-NN algorithm in scikit-learn's documentation, available at http://scikit-learn.org/stable/modules/neighbors.html
The K-NN algorithm on Wikipedia, available at https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm
Blog post about how to choose the K hyperparameter, available at http://datasciencelab.wordpress.com/2013/12/27/finding-the-k-in-k-means-clustering/
Instance-based learning on Wikipedia, available at https://en.wikipedia.org/wiki/Instance-based_learning

###Example Decision Trees  -- ADVANCED 
#download graphviz and update , where dot.exe 
#set PATH=C:\Program Files (x86)\Graphviz2.38\bin;%PATH%

#Code 
iris = datasets.load_iris()
clf = DecisionTreeClassifier(criterion='entropy')

vals = cross_val_score(clf, iris.data, iris.target, cv=10)
print("cross validated score %3.2f +/- %3.2f" % (vals.mean(),vals.std()) )


X_train, X_test, y_train, y_test = train_test_split(iris.data, iris.target, random_state=0)
clf = clf.fit(X_train, y_train)
predicted = clf.predict(X_test)
print("Training Accuracy",accuracy_score(y_train, clf.predict(X_train)))
print("Test data Accuracy",accuracy_score(y_test, predicted))

print("the probability of each class can be predicted(test data)")
print(clf.predict_proba(X_test)[:5])

print("We can get feature importance from DT algorithm")
[print(i,":", j) for i,j in zip(iris.feature_names,clf.feature_importances_) ]

import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=iris.feature_names,  
                         class_names=iris.target_names,  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
#graph.render('iris_entropy') #'iris.pdf'
graph  #Jupyter handles them directly 
print(""" 
Each node 
    Condition on One feature 
    entropy/gini = value at this node 
    samples = How many samples(or subsamples) is used for this condition
    value = ndarray([[class_1_count, class_2_count, ....]])
    whereas class_X_count = no of samples for that class 
    with that condition ie samples = SUM of value
    class = class from Majority 

Left Node = True of node condition 
    Another feature condition and it's data 
Right node = False of node condition 
    Another feature condition and it's data

Objective is to go down the tree by decreasing entropy/gini 
(entropy/gini is highest if all class_X_count = equal)
such that only one class is seen at leaf node 
""")

###Flask 
jinja2 core filter 
    https://jinja.palletsprojects.com/en/2.10.x/templates/#list-of-builtin-filters
Jinja2 Test 
    https://jinja.palletsprojects.com/en/2.10.x/templates/#builtin-tests

#First code 
from flask import Flask

# Flask(import_name, static_url_path=None, static_folder='static', 
# static_host=None, host_matching=False, subdomain_matching=False, 
# template_folder='templates', instance_path=None, 
# instance_relative_config=False, root_path=None)
app = Flask(__name__)

@app.route("/")#http://127.0.0.1:5000/
def home():
    return """
        <html><body>
        <h1>Hello there!!</h1>
        </body></html>
    """
    
if __name__ == '__main__':
    app.run()    
    #run(host=None, port=None, debug=None, load_dotenv=True, **options)
    #localhost, port=5000
    #host='0.0.0.0' means all IP interface in this machine 
    #URI = scheme:[//authority]path[?query][#fragment]
    #http://localhost:5000/PATH?URL_PARAMS
    
#updated 
@app.route("/")  # http://localhost:5000/
def home():
    return """
    <html>
    <head>
    <title>My webserver </title>
    <style>
    .some {
        color: red;
    }
    </style> </head>
    <body>
    <h1 id="some" class="some">Hello there !!! </h1>
    <h1 id="some2" class="some">Welcome </h1>
    </body></html>
    """
    
#OR  
# from flask import Response
# r = Response(response="<a>ok</a>", status=200, mimetype="application/xml")
# r.headers["Content-Type"] = "text/xml; charset=utf-8"
# return r  

#To handle favicon file - download 
#and store it to /static/favicon.ico 
@app.route("/favicon.ico")
def favicon():
    return app.send_static_file('favicon.ico')
    

    
#Other configuration 
Note static files are handled automatically. for example, if 
URL is /static/a.css and file is under static/a.css folder 

OR configure as below 

app = Flask(__name__,
            static_url_path='', 
            static_folder='web/static',
            template_folder='web/templates')

static_url_path='' 
    removes any preceding path from the URL (i.e. the default /static).
static_folder='web/static' 
    to serve any files found in the folder web/static as static files.
template_folder='web/templates' 
    similarly, this changes the templates folder.

<link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
would go now web/static/css/bootstrap.min.css

Eg 
from flask import Flask, send_from_directory

# set the project root directory as the static folder
app = Flask(__name__, static_url_path='')

@app.route('/js/<path:path>')
def send_js(path):
    return send_from_directory('js', path) #from project root_folder/js 

 
    
    
#Debug mode 
Flask will suppress any server error with a generic error page unless 
it is in debug mode. 
As such to enable just the interactive debugger without the code reloading, 
you have to invoke run() with debug=True and use_reloader=False
app.run(host=None, port=None, debug=None, load_dotenv=True, **options)

Note FLASK_ENV='production' is default, but can be 'development'
where just in load would happen 

host – the hostname to listen on. Set this to '0.0.0.0' 
to have the server available externally as well. 
Defaults to '127.0.0.1' or the host in the SERVER_NAME config variable if present.

port – the port of the webserver. Defaults to 5000 or the port defined 
in the SERVER_NAME config variable if present.


#BeautifulSoup 
from bs4 import BeautifulSoup
import requests

r  = requests.get("http://127.0.0.1:5000/")
data = r.text
soup = BeautifulSoup(data, 'html.parser')
soup.html.body.h1.name  #only first
soup.html.body.h1.attrs  #only first 
soup.html.body.h1.text  #only first
soup.find_all('h1') 
for e in soup.find_all('h1') :
    print(e.attrs['id'])  #e.text, e['id']

soup.select("html body h1")  
soup.select("h1#some")
soup.select("h1.some")

###BeautifulSoup -- ADVANCED 
from bs4 import BeautifulSoup
import requests

r  = requests.get("http://www.yahoo.com")
data = r.text

soup = BeautifulSoup(data, 'html.parser')
for link in soup.find_all('a'):  # tag <a href=".."
		print(link.get('href'))	 # Attribute href

##	Pretty-printing
print(soup.prettify())

##Non-pretty printing
print(str(soup))       

#extracting all the text from a page:
print(soup.get_text())

#
soup.html
soup.html.body.p        # all p 
soup.html.body.text     #or .string
soup.html.body.attrs    #{'class': ['title']}
soup.html.body.name     #tag 
soup.html.body.p['class']
list(soup.html.body.children)

#other 
#find all the <TITLE> and all the <P> tags. 
soup.findAll(['title', 'p']) 
# with attribs 'align' and it's value 'center'
soup.findAll(align="center")
soup.find("b", attrs={ "class" : "lime" })
#or 
soup.find("b", "lime")
#or 
soup.find_all("b", class_="lime")
soup.findAll(attrs={'id' : re.compile("para$")})
soup.findAll(text="one")
#css select 
soup.select("title")
#Find tags beneath other tags:
soup.select("body a")
#Find tags directly beneath other tags:
soup.select("head > title") 
soup.select("#link1")
soup.select(".sister")

###More flask code 
from flask import Flask, request, jsonify, render_template, make_response 
import json , os 

app = Flask(__name__)

'''
#to xml or json based on template 
template = render_template('somefile.xml', values=values)
r = make_response(template)
r.headers['Content-Type'] = 'application/xml'
r.status_code = 200 
return r 
'''
@app.route("/env", methods=['GET','POST'])#http://127.0.0.1:5000/env
def env():
    if request.method == 'POST':
        envp = request.form.get('envp', 'all').upper()
        env_dict = os.environ
        if os.environ.get(envp, "notfound") != "notfound":
            env_dict = { envp : os.environ.get(envp,"notfound") }
        return render_template("env.html", 
            envs=env_dict)
    else:
        return """
            <html><body>
            <form action="/env" method="post">
              Put Variable name :<br>
              <input type="text" name="envp" value="ALL">
              <br><br>
              <input type="submit" value="Submit">
            </form> 
            </body></html>
        """
        

#templates/env.html 
<html>
<body>
<table border="1">
<tr style="color: red"><th>Key</th><th>Value</th></tr>
{% if envs.items() %}  {# can put jinja test eg var is defined #}
{% for k,v in envs.items() %}
<tr>
<td>{{ k }}</td>
<td>{{ v }}</td>
</tr>
{% endfor %}
{% endif %}
</table>
</body>
</html>

##Adding bootstrap and React -- ADVANCED 
##With Bootstrap 
#base.html 
<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>{% block title %}{% endblock %}</title>
</head>
<body>
    {% block content %}
    {% endblock %}
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>

#index.html 
{% extends "base.html" %}
{% block title %}Give Env{% endblock %}
{% block content %}
<form action="/env" method="post">
    Put env var <br/>
    <input type="text" name="envp" value="ALL" />
    <br />
    <br />
    <input type="submit" value="Submit" />
</form>
{% endblock %}

#env.html 
{% extends "base.html" %}
{% block title %}Give Env{% endblock %}
{% block content %}
<table border="1">
<tr class="some"><th>Key</th><th>Value</th></tr>
{% for k,v in envs.items() %}
<tr><td>{{k}}</td><td>{{v}}</td></tr>
{% endfor %}
</table>
{% endblock %}

#Then env method change 
    else:
        return render_template("index.html")
        
#Then Beautify- index.html 
{% extends "base.html" %}
{% block title %}Give Env{% endblock %}
{% block content %}
<form action="/env" method="post">
  <div class="form-group row">
    <label for="var" class="col-2 col-form-label">Put env var</label>
     <div class="col-10">
    <input type="text" id="var" class="form-control" name="envp" value="ALL">
     </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-8">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>
{% endblock %}


#Then beautify-table - env.html 
{% extends "base.html" %}
{% block title %}Result{% endblock %}
{% block content %}
<table class="table table-dark table-striped">
<tr><th>Key</th><th>Value</th></tr>
{% for k,v in envs.items() %}
<tr><td>{{k}}</td><td>{{v}}</td></tr>
{% endfor %}
</table>
{% endblock %}

##Add ReactJs 
#base.html 
<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>{% block title %}{% endblock %}</title>
</head>
<body>
    {% block content %}
    {% endblock %}
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <!-- Note: when deploying, replace "development.js" with "production.min.js". -->
    <script src="https://unpkg.com/react@17/umd/react.production.min.js" crossorigin></script>
    <script src="https://unpkg.com/react-dom@17/umd/react-dom.production.min.js" crossorigin></script>
    <!-- Load our React component. -->
    <script src="/static/like_button_adv.js"></script>
</body>
</html>

#env.html 
{% extends "base.html" %}
{% block title %}Give Env{% endblock %}
{% block content %}


<table class="table table-dark table-striped">
<tr><th>Key</th><th>Value</th></tr>
{% for k,v in envs.items() %}
<tr><td><div class="show_box" data-k="{{k}}" data-v="{{v}}"></div> </td><td>{{v}}</td></tr>
{% endfor %}
</table>
{% endblock %}


#Note any change in script might not be reflected as browser caches this 
#So change the name 
#https://support.mozilla.org/en-US/kb/how-clear-firefox-cache
#To know whether, firefox is using cache js, show page show source and click js link 
#static/like_button_adv.js
'use strict';

const e = React.createElement;

class BeautifulButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = { liked: false };
  }

  render() {
    if (this.state.liked) {      
      window.alert(this.props.k+"="+this.props.v)
      this.setState({ liked: false })
    }

    return e(
      'button',
      { onClick: () => this.setState({ liked: true }) },
      this.props.k
    );
  }
}

// Find all DOM containers, and render Like buttons into them.
document.querySelectorAll('.show_box')
  .forEach(domContainer => {
    // Read the k,v from a data-* attribute.
    const k_value = domContainer.dataset.k;
    const v_value = domContainer.dataset.v;
    ReactDOM.render(
      e(BeautifulButton, { k: k_value, v: v_value }),
      domContainer
    );
  });
  
#Note to add Angularjs , use raw because both jinja and Angjs uses {{ for substiture 
{% raw %}
<button type="submit" class="btn btn-primary" ng-disabled="loading">{{ submitButtonText }}</button>
{% endraw %}




###More Flask - REST  

from flask import jsonify, Response
@app.route("/helloj") #http://localhost:5000/helloj?name=das&format=json 
@app.route("/helloj/<string:name>/")  #http://localhost:5000/helloj/das/
@app.route("/helloadv", methods=['POST'])
@app.route("/helloj/<string:name>/<string:format>") #http://localhost:5000/helloj/das/json
def helloj(name="ABC", format="json"):
    db = [{"name": "ABC", "age": 30},
           {"name": "das", "age": 40}]
    if request.method == 'GET':
        fname = request.args.get("name", name)
        fformat = request.args.get("format", format)
    elif request.method == 'POST' :
        if 'Content-Type' in request.headers:
          if request.headers['Content-Type'].lower() in ['text/json',  'application/json']:
            fname = request.json.get("name", "ABC")
            fformat = "json"
          elif request.headers['Content-Type'].lower() in ['text/xml',  'application/xml']:
            import xml.etree.ElementTree as ET            
            root = ET.fromstring(request.data.decode('utf-8'))
            #root itself is name
            #nn = root.findall(".//name")
            print(request.data, root.text)
            fname = root.text
            fformat = "xml"            
    age = None 
    for emp in db:
        if fname == emp['name']:
            age = emp['age']
    if fformat == "json":
        if age is not None:
            success = {"name" : fname, "age" : age}
            resp = jsonify(success)
            resp.status_code = 200
        else:
            error = {"details" : "Name is not found"}
            resp = jsonify(error)
            resp.status_code = 500
    elif fformat == "xml":
        data = f"""<?xml version="1.0"?>
               <data><name>{fname}</name>
               <age>{age}</age></data>"""
        resp = Response(response=data, status=200, mimetype="application/xml")
        resp.headers['Content-Type'] = "text/xml; charset=utf-8"
    else:
        resp = "Not Supported"
    return resp   
    
'''
import requests as r 
res = r.get("http://localhost:5000/helloj")
res.json() 

#for xml 
import xml.etree.ElementTree as ET
res = r.get("http://localhost:5000/helloj?name=das&format=xml")
root = ET.fromstring(res.text)
root.tag
root.attrib
root.text
nn = root.findall(".//name")
[n.text  for n in nn]

headers = {'Content-Type': 'application/json'}
import json
obj = {'name' : 'das'}
res = r.post("http://localhost:5000/helloadv", data=json.dumps(obj),headers=headers)
res.json()

headers = {'Content-Type': 'application/xml'}
data = "<name>das</name>"
res = r.post("http://localhost:5000/helloadv", data=data,headers=headers)
res.text 

'''   

#Note 
request.data Contains the incoming request data as string in case it came with a mimetype Flask does not handle.
request.args: the key/value pairs in the URL query string
request.form: the key/value pairs in the body, from a HTML post form, or JavaScript request that isn't JSON encoded
request.files: the files in the body, which Flask keeps separate from form. HTML forms must use enctype=multipart/form-data or files will not be uploaded.
request.values: combined args and form, preferring args if keys overlap
request.json: parsed JSON data. The request must have the application/json content type, or use request.get_json(force=True) to ignore the content type.

All of these are MultiDict instances (except for json). You can access values using:
request.form['name']: use indexing if you know the key exists
request.form.get('name'): use get if the key might not exist
request.form.getlist('name'): use getlist if the key is sent multiple times and you want a list of values. get only returns the first value.



###Using Example DB -- ADVANCED 
from sqlalchemy import * 
from flask import jsonify, g
DATABASE = "people.db"
def get_db():
    db = getattr(g, '_database', None)  #do import g, g is global object in FLASK
    if db is None:
        db = g._database = create_engine("sqlite:///"+DATABASE)
    return db     
    
#for sqlalchemy, not required 
@app.teardown_appcontext
def close_connection(exception):
    db = g.pop('_database', None)
    if db is not None:
        db.close()
        
        
def getage(name):
    eg = get_db()
    q = eg.execute("select age from people where name = ?" ,name)
    return q.fetchone()[0]

@app.route("/json", methods=['POST'])   # http://localhost:5000/json with jsondata
def js():
    user = dict(username='nobody', age="nonefound")
    if 'Content-Type' in request.headers and request.headers['Content-Type'].lower() == 'application/json':
        user['username'] = request.json.get("username", "nobody")
    try:
        user['age'] = getage(user['username'])
    except:
        pass
    resp = jsonify(user)
    resp.status_code = 200
    return resp  
    
'''
headers = {'Content-Type': 'application/json'}
import json
import requests as r 
obj = {'username' : 'das'}
res = r.post("http://localhost:5000/json", data=json.dumps(obj),headers=headers)
res.json() 
''' 

#Some data creation 
from sqlalchemy import * 
DATABASE = "people.db"
db = create_engine("sqlite:///"+DATABASE)
db.execute("""create table if not exists people (name string, age int)""")
db.execute("""insert into people values(?,?)""", ["das", 20])

q = db.execute("select age from people where name=?", "das")
q.fetchone()

#OR 
with db.connect() as connection:
    result = connection.execute("select age from people where name=?", "das")
    for row in result:
        print("name:", row['name'])
        
#By default Autocommit 
conn = engine.connect()
conn.execute("INSERT INTO users VALUES (1, 'john')")  # autocommits

#OR explicitly
from sqlalchemy import text
with engine.connect().execution_options(autocommit=True) as conn:
    conn.execute(text("SELECT my_mutating_procedure()"))

##Understanding Application Globals - flask.g
#To share data that is valid for one request only from one function to another, 
#a global variable is not good enough because it would break in threaded environments. 
#Use flask.g , it is only valid for the active request 
#and that will return different values for each request. 

#methods 
'key' in g
iter(g)
g.get(name, default=None)
g.pop(name, default=<object object>)
g.setdefault(name, default=None)

###More Example of Flask - Login - using session -- ADVANCED 
from flask import session, redirect, url_for #NEW
app.secret_key = b"jhdkjhdkhshd"  #NEW

from functools import wraps
def auth_required(f):
    @wraps(f)
    def _inner(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))  #login is method name 
        return f(*args, **kwargs)
    return _inner

    
@app.route("/")
@auth_required  #NEW, should be inner 
def home():   # http://localhost:5000/
    return """
            <html><body>
                <h1 id="some" class="cl2">Hello there!!! </h1>
                <h1 id="some2" class="cl2">Welcome</h1>
            </body></html>
        """

def check_auth(user, password):
    return user == 'admin' and password == 'secret'
   
@app.route("/login", methods=['GET', 'POST'])  # http://localhost:5000/login
def login():  
    if request.method == 'POST':
        name = request.form.get('name', 'all')
        password = request.form.get('pass', 'all')
        if check_auth(name, password):
            session['username'] = name
            return redirect(url_for('home'))  #home is method name 
        else:
            return "<h1>Error</h1>"
    else:
        return """
                <html><body>
                <form action="/login" method="post">
                 Name: <br/>
                 <input type="text" name="name" value="" />
                 Password: <br/>
                 <input type="password" name="pass" value="" />
                 <br/><br/>
                 <input type="submit" value="Submit" />
                </form>
                </body></html>
            """
        
'''
s = r.Session()
cred = {'name': 'admin', 'pass': 'secret'}
r1 = s.post("http://127.0.0.1:5000/login", cred)
r2 = s.get("http://127.0.0.1:5000/")
r2.text   
'''        
        
###More Example - upload , download -- ADVANCED 
import os
from flask import Flask, flash, request, redirect, url_for
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = os.path.join(app.root_path,'uploads')
# create the folder next to static 
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/upload', methods=['GET', 'POST']) #http://127.0.0.1:5000/upload
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file.filename:
            filename = secure_filename(file.filename) #normalizes the file path 
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('download',filename=filename))
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''
    
from flask import send_from_directory
#mimetype: str

#as_attachment: bool, attachment_filename:str, mimetype: str
@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)    
    
  
#with file upload and download 
files = {'file': open('copy.txt','rb')} #'file' same as form's name for type=file 
other_form_data = {'DB': 'photcat', 'OUT': 'csv', 'SHORT': 'short'}
r = requests.post("http://127.0.0.1:5000/upload", files=files, data=other_form_data)
r.request.url #'http://127.0.0.1:5000/download/copy.txt' , the redirected one 
r.status_code
r.headers.get('content-disposition') #'attachment; filename=copy.txt'
local_filename = r.headers.get('content-disposition').split("=")[-1]
with open(local_filename+".bak", 'wb') as f:
    f.write(r.content)

            
#for big file 
import shutil
with requests.get('http://127.0.0.1:5000/download/copy.txt', stream=True) as r:
    with open(local_filename+".bak2", 'wb') as f:
        shutil.copyfileobj(r.raw, f)           
            
            
##Sending file 
flask.send_file(filename_or_fp, mimetype=None, as_attachment=False, 
        attachment_filename=None, add_etags=True, 
        cache_timeout=None, conditional=False, 
        last_modified=None)
    Sends the contents of a file to the client
        filename_or_fp – the filename of the file to send. 
            This is relative to the root_path if a relative path is specified. 
            Alternatively a file object might be provided in which case X-Sendfile might not work 
            and fall back to the traditional method. 
            Make sure that the file pointer is positioned at the start of data to send 
            before calling send_file().
        mimetype – the mimetype of the file if provided. 
            If a file path is given, auto detection happens as fallback, otherwise an error will be raised.
        as_attachment – set to True if you want to send this file 
            with a Content-Disposition: attachment header.
        attachment_filename – the filename for the attachment 
            if it differs from the file’s filename.
        add_etags – set to False to disable attaching of etags.
        conditional – set to True to enable conditional responses.
        cache_timeout – the timeout in seconds for the headers. When None (default), this value is set by get_send_file_max_age() of current_app.
        last_modified – set the Last-Modified header to this value, a datetime or timestamp. If a file was passed, this overrides its mtime.
flask.send_from_directory(directory, filename, **options)
    Send a file from a given directory with send_file(). 
    This is a secure way to quickly expose static files 
    from an upload folder or something similar.
    #Example 
    @app.route('/uploads/<path:filename>')
    def download_file(filename):
        return send_from_directory(app.config['UPLOAD_FOLDER'],
                                   filename, as_attachment=True)





###Understandin flask Configuration -- ADVANCED 
app.config 
    Works exactly like a dict 
    but provides ways to fill it from files or special dictionaries.

#yourconfig.cfg
#only uppercase keys are added to the config.
DEBUG = True
SECRET_KEY = 'development key'

#Then 
app.config.from_pyfile('yourconfig.cfg')
#or 
export YOURAPPLICATION_SETTINGS='/path/to/config/yourconfig.cfg'
app.config.from_envvar('YOURAPPLICATION_SETTINGS')
#ie  
app.config.from_pyfile(os.environ['YOURAPPLICATION_SETTINGS'])

#or 
app.config.from_object('configmodule.DevelopmentConfig')
#or 
from configmodule import DevelopmentConfig
app.config.from_object(default_config)
#Objects are usually either modules or classes. 
#loads only the uppercase attributes of the module/class. 
#configmodule.py 
class DevelopmentConfig(Config):
    """
    Development configurations
    """
    DEBUG = True
    SQLALCHEMY_ECHO = True
    ASSETS_DEBUG = True
    DATABASE = 'teamprojet_db'
    print('THIS APP IS IN DEBUG MODE. YOU SHOULD NOT SEE THIS IN PRODUCTION.')


class ProductionConfig(Config):
    """
    Production configurations
    """
    DEBUG = False
    DATABASE = 'teamprojet_prod_db'
    
#OR above sets below 
import os
if os.environ['ENV'] == 'prod':
    app.config.from_object('configmodule.ProductionConfig')
else:
    app.config.from_object('configmodule.DevelopmentConfig')
    
#or store directly 
app.config['IMAGE_STORE_TYPE'] = 'fs'
app.config['IMAGE_STORE_PATH'] = '/var/app/images'
app.config['IMAGE_STORE_BASE_URL'] = 'http://img.website.com'
image_store_config = app.config.get_namespace('IMAGE_STORE_')
#The resulting dictionary image_store_config would look like:
{
    'type': 'fs',
    'path': '/var/app/images',
    'base_url': 'http://img.website.com'
}
#or 
app.config.from_mapping(
        SECRET_KEY='dev',
        DATABASE=os.path.join(app.instance_path, 'flaskr.sqlite'),
    )


###Flask Logging -- ADVANCED 
#a logger is preconfigured  to use.
app.logger.debug('A value for debugging')
app.logger.warning('A warning occurred (%d apples)', 42)
app.logger.error('An error occurred')


###Understanding Deployement
#https://flask.palletsprojects.com/en/1.1.x/deploying/wsgi-standalone/

# For example to deploy via  Gevent 
pip install gevent 
#Gevent is a coroutine-based Python networking library 
#that uses greenlet to provide a high-level synchronous API on top of libev event loop:


#gevent_server.py
from gevent.pywsgi import WSGIServer
from flaskr import app

# http_server = WSGIServer(('localhost', 5000), app, keyfile='key.pem', certfile='cert.pem')
http_server = WSGIServer(('127.0.0.1', 5000), app)
http_server.serve_forever()

#With tornado 
$ pip install tornado

#code 
from tornado.wsgi import WSGIContainer
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from flaskr import app

http_server = HTTPServer(WSGIContainer(app))
http_server.listen(5000)
IOLoop.instance().start()


###Deployment - SSL -- ADVANCED 
#to use adhoc certificates 
$ pip install pyopenssl
#then 
app.run(ssl_context='adhoc')
#or 
$ flask run --cert=adhoc

#to use Self-Signed Certificates
#http://slproweb.com/products/Win32OpenSSL.html
C:\cygwin64\bin\openssl.exe req -x509 -newkey rsa:4096 -nodes -out cert.pem -keyout key.pem -days 365

#then 
app.run(ssl_context=('cert.pem', 'key.pem'))
#OR 
$ flask run --cert=cert.pem --key=key.pem

#To redirect http to https, use Flask-SSLify 
#that configures your Flask application to redirect all incoming requests to HTTPS.

#Using real certificates 
#https://blog.miguelgrinberg.com/post/running-your-flask-application-over-https
#eg one free CA , https://letsencrypt.org/getting-started/
#with nignx 
#https://www.digitalocean.com/community/tutorials/how-to-serve-flask-applications-with-uswgi-and-nginx-on-ubuntu-18-04


#To handle in requests with self signed cert , verify=False
#Note dont send http request now when https is active, it would give big faliure in gevent 
'''
headers = {'Content-Type': 'application/json'}
import json
import requests as r 
obj = {'username' : 'das'}
res = r.post("https://localhost:5000/json", data=json.dumps(obj),headers=headers, verify=False)
res.json() 
''' 

#if you want hhtp to https , Redirects only occur when app.debug is False.
#pip install Flask-SSLify
from flask import Flask
from flask_sslify import SSLify

app = Flask(__name__)
sslify = SSLify(app)




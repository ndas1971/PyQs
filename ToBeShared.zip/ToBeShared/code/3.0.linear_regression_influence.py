import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

from sklearn.pipeline import * 
from sklearn.linear_model import *  
from sklearn.preprocessing import *  
from sklearn.datasets import *  
from sklearn.model_selection import *  
from sklearn.metrics import *  



#Statsmodel require pandas DF 

boston = load_boston()
       
bostonDF = pd.DataFrame(boston.data, columns=boston.feature_names)
bostonDF['MEDV'] = boston.target


import statsmodels.api as sm
import statsmodels.formula.api as smf

# Fit regression model (using the natural log of one of the regressors)
# + means add , - means remove the term 
#(does not exist in statsmodel). means all remaining ie CRIM + ZN ...
#can mention individually, each can be transformed eg np.log(CRIM)
# 1 + means include intercept (default) + -1  means exclude 
#* for including interaction, eg CRIM*ZN = CRIM + ZN + CRIM:ZN 
#: for only interaction CRIM:ZN 
#for categorical use C() eg C(chas)
#for including any operator use I(x), eg I(x1 + x2) inside a formula to represent the sum of x1 and x2  
#to quote variable Q(name) eg Q("weight.in.kg")  

results = smf.ols('MEDV ~ CRIM + ZN', data=bostonDF).fit()
# Inspect the results
print("Using statsmodels regression summary for 'MEDV ~ CRIM + ZN'")
print("""Contains many goodies eg 
Coef 
    the estimates of  mean values of the coefficients  
    
coefficientStandardErrors            
    = estimate of  standard deviation of parameter estimate 
    
[....]              
    95% CI        
   =  mean +/- 2* std err ie sd  
   = coef  +/-  2* coefficientStandardErrors     
  
Df Total            
    These are the degrees of freedom associated with the sources of variance
    ie no of observation 
    
Df Model            
    No of independent variables (excluding intercept)
    
residualDegreeOfFreedom, Df Residuals        
    Df total - Df Model 

R-squared           
     How model fits the data? Towards 1 is better 
     
Adj. R-squared      
    adjusts for the number of terms in a model. 
    If you add more and more useless variables to a model, 
    adjusted r-squared will decrease. 
    If you add more useful variables, adjusted r-squared will increase
                    
Prob (F-statistic)  
    <0.05, model is significant 
    
AIC, BIC            
    Akaike's 'An Information Criterion'(AIC) for the fitted model
    lower the better. Used for comparing two models 
    Note  one model needs to be a subset of the other
    
Log-Likelihood   
    Value where model iteration is stopped, This is maximized
   
t   , tValues                
    These are the t-statistics used in testing 
    Dividing the coefficient by its standard error calculates a t-value
    
P>|t|   , pValues             
    < 0.05, coefficient is significant , H0= coefficient is zero 
    
Jarque-Bera     
    a goodness-of-fit test with normal distribution (normality test of data)
    HO: sample data have the skewness and kurtosis matching a normal distribution
    Samples from a normal distribution have an expected skewness of 0 
    and an expected  kurtosis of 3
    Prob < 0.05, reject H0 
    
Omnibus/Prob(Omnibus) 
    Omnibus - close to zero which would indicate normal. 
    The Prob (Omnibus) - H0 : residuals are normally distributed. 
    We hope to see something close to 1 here. 
    Prob < 0.05, reject H0 
       

Condition Number 
    This test measures the sensitivity of a function's output as compared to its input 
    When we have multicollinearity, we can expect much higher fluctuations 
    to small changes in the data, hence, we hope to see a relatively small number, 
    something below 30. 
    
Durbin-Watson   
    The Durbin Watson Test is a measure of autocorrelation (also called serial correlation) 
    in residuals from regression analysis. 
    Autocorrelation is the similarity of a time series over successive time intervals. 
    It can lead to underestimates of the standard error 
    and can cause you to think predictors are significant when they are not
    The Durbin Watson test reports a test statistic, with a value from 0 to 4, where:
        *2 is no autocorrelation.
        *0 to <2 is positive autocorrelation (common in time series data).
        *>2 to 4 is negative autocorrelation (less common in time series data).

""")

print(results.summary())
"""
                            OLS Regression Results
==============================================================================
Dep. Variable:                   MEDV   R-squared:                       0.233
Model:                            OLS   Adj. R-squared:                  0.230
Method:                 Least Squares   F-statistic:                     76.21
Date:                Sat, 02 Feb 2019   Prob (F-statistic):           1.23e-29
Time:                        11:59:31   Log-Likelihood:                -1773.3
No. Observations:                 506   AIC:                             3553.
Df Residuals:                     503   BIC:                             3565.
Df Model:                           2
Covariance Type:            nonrobust
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     22.4668      0.442     50.862      0.000      21.599      23.335
CRIM          -0.3498      0.043     -8.202      0.000      -0.434      -0.266
ZN             0.1164      0.016      7.406      0.000       0.086       0.147
==============================================================================
Omnibus:                      163.895   Durbin-Watson:                   0.756
Prob(Omnibus):                  0.000   Jarque-Bera (JB):              429.044
Skew:                           1.619   Prob(JB):                     6.83e-94
Kurtosis:                       6.140   Cond. No.                         31.9
==============================================================================

"""

##Influence tests
#Once created, an object of class OLSInfluence holds attributes and methods 
#that allow users to assess the influence of each observation. 

#For example, we can compute and extract the first few rows of DFbetas by:

from statsmodels.stats.outliers_influence import OLSInfluence
import math 

test_class = OLSInfluence(results)
print("first few rows of DFbetas (a measure of outliers)")
print(test_class.dfbetas[:5,:] ) #> 2/sqrt(N) outliers
print("outliers is values > 2/sqrt(N) ie >",2/math.sqrt(86))

where = test_class.dfbetas > 2/math.sqrt(86)
print("find index labels where that satisfies")
print(np.where(where))

print("draw influence diagram\nbigger size  or further, more leverage/influence")
input()

from statsmodels.graphics.regressionplots import *
fig, (ax1,ax2) = plt.subplots(1,2, figsize=(8,6))
plot_leverage_resid2(results, ax = ax1)
influence_plot(results, ax = ax2)
plt.show()


print("Use RANSACRegressor\nnote R^2 would decrease, but estimation is robust ")
input()

boston = load_boston()

X_train, X_test, y_train, y_test = train_test_split(boston.data, boston.target, random_state=0)

# Fit line using all data
lr = LinearRegression()
lr.fit(X_train, y_train)
print("LinearRegression train and test score")
print(lr.score(X_train, y_train))
print(lr.score(X_test, y_test))

# Robustly fit linear model with RANSAC algorithm
ransac = RANSACRegressor()
ransac.fit(X_train, y_train)
print("RANSACRegressor train and test score")
print(ransac.score(X_train, y_train))
print(ransac.score(X_test, y_test))

print("RANSACRegressor can also give outlier, Find oulier ")
inlier_mask = ransac.inlier_mask_
outlier_mask = np.logical_not(inlier_mask)
print("y outliers")
print(y_train[outlier_mask])
print("and row index ")
print(np.where(outlier_mask))


print("Compare estimated coefficients")
print("Estimated coefficients (linear regression, RANSAC):")
df = pd.DataFrame(index=boston.feature_names)
df['linear regression'] = lr.coef_
df['RANSAC'] = ransac.estimator_.coef_
print(df)
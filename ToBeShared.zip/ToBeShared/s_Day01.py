DAY-1
    Refresher Course based on Q&A:
    Basic datatypes 
    Control structures
    Python Data Structures
    Nested Data Structure
    Functions
    Only HandsOn:
      Working with files
      Using Modules
      Using the Standard Library




###Configuration
PyCharm
    Select new VENV or existing during project creation
    For existing, go to venv/conda env directory and select python.exe 
    New venv is created in project directory\venv 
    New conda is created in Anaconda\envs 
    To update, get it from File->Settings->Project(NAME)->Python interpreter 
    Install Package also in above place - it shows all installed packages, add click + to add more 
IntelliJ IDEA + python plugins 
    Select new VENV or existing during project creation
    For existing, go to venv/conda env directory and select python.exe 
    New venv is created in project directory\venv 
    New conda is created in Anaconda\envs 
    To update, get it from File->Project Structure->Project Settings->Project->Project SDK ->New->Python SDK 
    Install Package File->Project Structure->Project Settings->Platform->SDKs->Packages
    - it shows all installed packages, add click + to add more 
    
##Conda venv creation 
https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html

Requires environment.yml file 
eg download from https://raw.githubusercontent.com/ndas1971/Misc/master/environment-win-amd64.yml as environment.yml

C:\Anaconda3\Scripts\activate base
conda update conda 
conda env create -f environment.yml  
conda deactivate

There might be some temporary failure, so run again 
C:\Anaconda3\Scripts\activate aiml
conda env update -n aiml --file environment.yml

#Or manual creation ( specific versions, scipy=0.15.0)
conda create -n myenv python=3.6 pip numpy scipy requests beautifulsoup4 notebook  jupyter flask gevent matplotlib nbconvert nbformat openpyxl pillow pytest scikit-image scikit-learn seaborn statsmodels xlwt xlrd yellowbrick pyarrow tpot graphviz python-graphviz 
conda install -n myenv pandas 
pip install pytest-cov
conda env list

#Activate 
C:\Anaconda3\Scripts\activate myenv
jupyter notebook --notebook-dir='D:/Desktop/PPT/python/Jupyter/code'
deactivate 


###Jupyter Kernel creation (INTERNAL)
With pyspark 
set PYTHONPATH=%SPARK_HOME%\python;%PYTHONPATH%
set PYTHONPATH=%SPARK_HOME%\python\lib\py4j-0.10.7-src.zip;%PYTHONPATH%
jupyter notebook 

Then you need to create session etc 
#OR 
set PYSPARK_DRIVER_PYTHON=jupyter
set PYSPARK_DRIVER_PYTHON_OPTS='notebook'
pyspark 
Session is autocreated with master[*]

#in conda env 
$ conda env config vars list
$ conda env config vars set PYSPARK_DRIVER_PYTHON=jupyter
$ conda env config vars set PYSPARK_DRIVER_PYTHON_OPTS='notebook'
$ conda activate aiml

#Or Create Pyspark Kernel  
#https://jupyter-client.readthedocs.io/en/stable/kernels.html
jupyter-kernels-3-768x288.jpg
#Find out data path 
$ jupyter --paths
config:
    C:\Users\das\.jupyter
    C:\Anaconda3\etc\jupyter
    C:\ProgramData\jupyter
data:
    C:\Users\das\AppData\Roaming\jupyter
    C:\Anaconda3\share\jupyter
    C:\ProgramData\jupyter
runtime:
    C:\Users\das\AppData\Roaming\jupyter\runtime

#C:\Anaconda3\share\jupyter\kernels\PySpark
{
  "display_name": "PySpark",
  "language": "python",
  "argv": [
    "C:\\Anaconda3\\python.exe",
    "-m",
    "ipykernel",
    "-f",
    "{connection_file}"
  ],
  "env": {
    "SPARK_HOME": "C:\\spark",
    "PYTHONPATH": "C:\\spark\\python;C:\\spark\\python\\lib\\py4j-0.10.7-src.zip",
    "PYSPARK_DRIVER_PYTHON": "C:\\Anaconda3\\python.exe",
    "PYSPARK_PYTHON": "C:\\Anaconda3\\python.exe"      
  }
}

#For any virtual env eg aiml 
#C:\Anaconda3\envs\aiml\share\jupyter\kernels\PySpark\kernel.json
{
  "display_name": "PySpark",
  "language": "python",
  "argv": [
    "C:\\Anaconda3\\envs\\aiml\\python.exe",
    "-m",
    "ipykernel",
    "-f",
    "{connection_file}"
  ],
  "env": {
    "SPARK_HOME": "C:\\spark",
    "PYTHONPATH": "C:\\spark\\python;C:\\spark\\python\\lib\\py4j-0.10.7-src.zip;C:\\Anaconda3\\envs\\aiml\\python36.zip;C:\\Anaconda3\\envs\\aiml\\DLLs;C:\\Anaconda3\\envs\\aiml\\lib;C:\\Anaconda3\\envs\\aiml;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages\\win32;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages\\win32\\lib;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages\\Pythonwin",
    "PYSPARK_DRIVER_PYTHON": "C:\\Anaconda3\\envs\\aiml\\python.exe",
    "PYSPARK_PYTHON": "C:\\Anaconda3\\envs\\aiml\\python.exe",
    "PATH": "C:\\Anaconda3\\envs\\aiml;C:\\Anaconda3\\envs\\aiml\\Library\\mingw-w64\\bin;C:\\Anaconda3\\envs\\aiml\\Library\\usr\\bin;C:\\Anaconda3\\envs\\aiml\\Library\\bin;C:\\Anaconda3\\envs\\aiml\\Scripts;C:\\Anaconda3\\envs\\aiml\\bin;C:\\MiKTeX\\miktex\\bin\\x64;C:\\Users\\Das\\bin;C:\\windows\\system32\\wbem;C:\\windows\\system32;C:\\Windows\\SysWOW64\\WINDOW~1\\v1.0" ,
    "JAVA_HOME": "C:\\Program Files\\Java\\jdk1.8.0_65"
    }
}
#Auto generated sc and context 
#C:\Anaconda3\envs\aiml\share\jupyter\kernels\PySparkAuto\kernel.json
{
  "display_name": "PySparkAuto",
  "language": "python",
  "argv": [
    "C:\\Anaconda3\\envs\\aiml\\python.exe",
    "-m",
    "ipykernel",
    "-f",
    "{connection_file}"
  ],
  "env": {
    "SPARK_HOME": "C:\\spark",
    "PYTHONPATH": "C:\\spark\\python;C:\\spark\\python\\lib\\py4j-0.10.7-src.zip;C:\\Anaconda3\\envs\\aiml\\python36.zip;C:\\Anaconda3\\envs\\aiml\\DLLs;C:\\Anaconda3\\envs\\aiml\\lib;C:\\Anaconda3\\envs\\aiml;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages\\win32;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages\\win32\\lib;C:\\Anaconda3\\envs\\aiml\\lib\\site-packages\\Pythonwin",
    "PYSPARK_DRIVER_PYTHON": "C:\\Anaconda3\\envs\\aiml\\python.exe",
    "PYSPARK_PYTHON": "C:\\Anaconda3\\envs\\aiml\\python.exe",
    "PYTHONSTARTUP": "C:\\spark\\python\\pyspark\\shell.py" ,
    "PATH": "C:\\Anaconda3\\envs\\aiml;C:\\Anaconda3\\envs\\aiml\\Library\\mingw-w64\\bin;C:\\Anaconda3\\envs\\aiml\\Library\\usr\\bin;C:\\Anaconda3\\envs\\aiml\\Library\\bin;C:\\Anaconda3\\envs\\aiml\\Scripts;C:\\Anaconda3\\envs\\aiml\\bin;C:\\MiKTeX\\miktex\\bin\\x64;C:\\Users\\Das\\bin;C:\\windows\\system32\\wbem;C:\\windows\\system32;C:\\Windows\\SysWOW64\\WINDOW~1\\v1.0" ,
    "JAVA_HOME": "C:\\Program Files\\Java\\jdk1.8.0_65"
    }
}



#Check in jupyter 
!jupyter kernelspec list 
%pycat C:\Anaconda3\envs\aiml\share\jupyter\kernels\PySparkAuto\kernel.json 

### Basic datatypes 

a = 1
type(a)  # int 
f = 1.2 
type(f)  # float 
s = "OK"  
type(s)  #str 
b = True 
type(b) # bool 

#all numeric ops possible 
a + 1 
a / 2
a // 2 
a % 2 

#boolean ops 
a == 1 
s == "OK" and a == 1
True and False 
True or False 
not True

#conversion 
s = "1"
int(s)
float(s)
a = 1
str(a)
bool(a)

#print 
print(1,2,a,f) 


###Control structures

#if 
a = 1 
if  a > 1:
    print("greater")
elif a < 1:
    print("lesser")
else:
    print("equal")
    
#for loop with numbers 
for e in range(1,10,1):
    if e == 2:
        break
else:
    print("not broken ealier")


import sys   #importing a module 
#another style 
from sys import argv  #for commandline handling 
#another style - alias 
import sys as SYS 
#or 
#from sys import *   #all imports 

#first arg is always file name 
if len(sys.argv) == 2:
    first_arg = argv[1]  #index starts from 0 
elif len(sys.argv) == 3:
    second_arg = sys.argv[2]
else:
    print("give only 1 or 2 arg")

#int 
a = 1
#float 
f = 1.2 
#bool 
b = True #False 
#comparison 
print( "and", a == 1 and f == 1.2)
print( "or", a != 1 or f >= 1.2)
print( "not" , not a <= 1)

#string - immutable 
s = "OK"    #or 'OK' or """Multiline string""" , r"raw string"
#list - mutable, indexing and duplicates - possible 
lst = [1,2]
#tuple - immutable, indexing and duplicates - possible 
t = (1,2)
#set , unique , nut duplicates not allowed 
st = {1,2}
#dict - keys are like set 
d = {'OK': 2}

#length 
print(len(s), len(lst), len(t), len(st), len(d))

#contains checking 
print('O' in s, 1 in lst, 1 not in t, 2 in st, 'OK' in d  )

#equality 
print(s == 'OK', t != (1,2,3)  ) #and others 

#each element - iteration 
for e in lst:  #or s, t, st 
    print(e) 
    
for k, v in d.items():
    print(k, v, "again value", d[k])
    
#indexing - only string, list, tuple 
print(lst[0], s[-1], t[1:], t[1:3:2])  #slice - start:end:step 

#concatenation or add 
s2 = s + " NOK"   
lst2 = lst + [3,4]
lst2.append(30)

t2 = t + (3,4)

st.add(20)

d['nok'] = 20 #creation of new key 
d['ok'] = 20 # update 


#conversion 
a2 = int(f)    #type name as method 
st4 = set(t) 

#zip 
print( list(zip(['a', 'b'],['d', 'f'])))
#enumerate 
print( list(enumerate(['a', 'b'])))


#basic function 
def f(x,y):
    return x+y 

f(2,3) 
f(y=2, x=3)
f(2, y=3)

def g(x, y=20):
    return x+y 
    
g(2)
g(2,2)

def f(*x):
    return x 
    
f(1)
f(1,2,3)

l = [1,2,3,4]
f(*l)

then LEGB 
def f(x):
    def g(y):
        return x+y 
    return g 
    
f(2)(3)   


lambda 
f = lambda x: x*x 
f(2)
why do we need it - function as object 
def f(x,y):
    return x(y)
    
f(lambda x:x*x, 20)

list(map(lambda x: x*x, [1,2,3,4])
list(filter(lambda x: x%2 == 0, [1,2,3,4]))


Module user defined 
    show reload 
    show what __init__.py can contain 
    Running modules individually as a program - __name__=='__main__'
    Include hands On 
        mean 
        sd 
        checksum 
        
#__init__.py 
from mex import square 
#Usage 
#from pkg import square 

__all__ = ['square']
#Usage 
#from pkg import * 

def cube(x):
    return x*x*x 
    
#Usage 
#from pkg import cube  

#not so standardised 
__version__ = '0.1'
__author__ = 'Name '

#usage 
#import pkg 
#pkg.__version__ 

##Reload 
import importlib
importlib.reload(module)


Show default std lib 
    show based on content 
    
    
import math 
dir(math)

import datetime 
dir(datetime)
datetime.date(2018,1,1) + datetime.timedelta(days=365)
datetime.date(2018,1,1) - datetime.date.today()
datetime.datetime.now()
str(datetime.datetime.now())

#Given a directory, find out the file Name having max size recursively 
import os.path 
import glob
def getMaxFilename(path):
    def get_files(path, ed={}):
        files = glob.glob(os.path.join(path, "*"))
        for file in files:
            if os.path.isfile(file):
                ed[file] =  os.path.getsize(file)
        for file in files:
            if not os.path.isfile(file):
                get_files(file, ed)
        return ed
    allfiles = get_files(path)
    sted = sorted(allfiles, key=lambda k: allfiles[k])
    return sted[-1]
    


###Ansible Cheat Sheet

Control Machine / Node
    a system where Ansible is installed and configured to connect and execute commands on nodes.
Node:
    a server controlled by Ansible.
Inventory File
    a file that contains information about the servers Ansible controls, typically located at /etc/ansible/hosts.
Playbook
    a file containing a series of tasks to be executed on a remote server.
Role
    a collection of playbooks and other files that are relevant to a goal such as installing a web server.
Play
    a full Ansible run. A play can have several playbooks and roles, included from a single playbook that acts as entry point.

##Testing Connectivity to Nodes
ansible all -m ping

##Connecting as a Different User
#By default, Ansible tries to connect to the nodes 
#as your current system user, using its corresponding SSH keypair. 

#To connect as a different user
ansible all -m ping -u sammy
ansible-playbook myplaybook.yml -u sammy

##Using a Custom SSH Key
ansible all -m ping --private-key=~/.ssh/custom_id
ansible-playbook myplaybook.yml --private-key=~/.ssh/custom_id

##Using Password-Based Authentication
#This will make Ansible prompt you for the password of the user on the remote server that you’re attempting to connect as:
ansible all -m ping --ask-pass
ansible-playbook myplaybook.yml --ask-pass

#Providing the sudo Password If the remote user needs 
ansible all -m ping --ask-become-pass
ansible-playbook myplaybook.yml --ask-become-pass

#Using a Custom Inventory File
#The default inventory file is typically located at /etc/ansible/hosts
ansible all -m ping -i my_custom_inventory
ansible-playbook myplaybook.yml -i my_custom_inventory

#Using a Dynamic Inventory File
#https://github.com/ansible/ansible-examples
ansible all -m ping -i digital_ocean.py

#Running ad-hoc Commands
ansible all -a "uname -a"
ansible server1 -m apt -a "name=vim"  #install vim package 
ansible server1 -m apt -a "name=vim" --check

#Running Playbooks
ansible-playbook myplaybook.yml
ansible-playbook -l server1 myplaybook.yml

#Getting Information about a Play
ansible-playbook myplaybook.yml --list-tasks
ansible-playbook myplaybook.yml --list-hosts
ansible-playbook myplaybook.yml --list-tags

#Controlling Playbook Execution
ansible-playbook myplaybook.yml --start-at-task="Set Up Nginx"
ansible-playbook myplaybook.yml --tags=mysql,nginx
ansible-playbook myplaybook.yml --skip-tags=mysql


###Using Ansible Vault to Store Sensitive Data

#Creating a New Encrypted File
#You can create a new encrypted Ansible file with:
ansible-vault create credentials.yml

#This command will perform the following actions:
1.First, it will prompt you to enter a new password. You’ll need to provide this password whenever you access the file contents, whether it’s for editing, viewing, or just running playbooks or commands using those values.
2.Next, it will open your default command-line editor so you can populate the file with the desired contents.
3.Finally, when you’re done editing, ansible-vault will save the file as encrypted data.

#Encrypting an Existing Ansible File
ansible-vault encrypt credentials.yml

#Viewing the Contents of an Encrypted File
ansible-vault view credentials.yml

#Editing an Encrypted File
ansible-vault edit credentials.yml

#Decrypting Encrypted Files
ansible-vault decrypt credentials.yml

#Using Multiple Vault Passwords
#Ansible supports multiple vault passwords grouped by different vault IDs. 
#This is useful if you want to have dedicated vault passwords for different environments, such as development, testing, and production environments.
ansible-vault create --vault-id dev@prompt credentials_dev.yml
#This will create a new vault ID named dev that uses prompt as password source. 

#By combining this method with group variable files, 
#you’ll be able to have separate ansible vaults for each application environment:
ansible-vault create --vault-id prod@prompt credentials_prod.yml

#to view, edit, or decrypt these files
ansible-vault edit credentials_dev.yml --vault-id dev@prompt 


#Using a Password File
#If you need to automate the process of provisioning servers with Ansible using a third-party tool, 
#you’ll need a way to provide the vault password without being prompted for it. 

#You can do that by using a password file with ansible-vault.
#A password file can be a plain text file or an executable script. 

#If the file is an executable script, 
#the output produced by this script will be used as the vault password. 
#Otherwise, the raw contents of the file will be used as vault password.

#To use a password file with ansible-vault
ansible-vault create --vault-id dev@path/to/passfile credentials_dev.yml

#The official Ansible repository contains a few examples of vault scripts that you can use for reference 
#when creating a custom script that suits the particular needs of your project.


##Running a Playbook with Data Encrypted via Ansible Vault
ansible-playbook myplaybook.yml --ask-vault-pass

#If you used a password file instead of prompting for the password
ansible-playbook myplaybook.yml --vault-password-file my_vault_password.py

#If you’re using data encrypted under a vault ID
ansible-playbook myplaybook.yml --vault-id dev@prompt

#If using a password file with your vault ID
ansible-playbook myplaybook.yml --vault-id dev@vault_password.py

#If your play uses multiple vaults, 
#you should provide a --vault-id parameter for each of them, in no particular order:
ansible-playbook myplaybook.yml --vault-id dev@vault_password.py --vault-id test@prompt --vault-id ci@prompt



###Debugging
ansible-playbook myplaybook.yml -v
ansible-playbook myplaybook.yml -vvvv


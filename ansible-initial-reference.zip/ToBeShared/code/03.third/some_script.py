from __future__ import print_function, division
import os 
import sys 

print(sys.argv)

print(os.getenv('PATH'))
print(os.getenv('USER'))

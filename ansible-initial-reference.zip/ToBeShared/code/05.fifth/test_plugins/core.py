from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import operator 


from ansible import errors
from ansible.utils.display import Display

display = Display()
#Usage 
#display.warning("The 'started' test expects an async task, but a non-async task was tested")

#value is 'var' passed from LHS ie LHS is test(args)..
def test_in(value, seq):
    """Check if value is in seq.
    """
    return value in seq


class TestModule(object):
    ''' Custom core jinja2 tests '''

    def tests(self):
        return {            
            'in':               test_in,
            '==':               operator.eq,
            'eq':               operator.eq,
            'equalto':          operator.eq,
            '!=':               operator.ne,
            'ne':               operator.ne,
            '>':                operator.gt,
            'gt':               operator.gt,
            'greaterthan':      operator.gt,
            'ge':               operator.ge,
            '>=':               operator.ge,
            '<':                operator.lt,
            'lt':               operator.lt,
            'lessthan':         operator.lt,
            '<=':               operator.le,
            'le':               operator.le,            
        }

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type


from ansible.plugins.action import ActionBase
from ansible.utils.vars import merge_hash
import dateutil.parser

#This preprocesses the module 
#if this does not have any associated module 
#remove  self._execute_module(...)  call 
#and directly update the result and return 

class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        self._supports_async = True
        results = super(ActionModule, self).run(tmp, task_vars)

        if 'format' not in self._task.args:
            self._task.args['format'] = "%b %d %Y %H:%M:%S"

        wrap_async = self._task.async_val and not self._connection.has_native_async
        #now call the module
        results = merge_hash(results, self._execute_module(task_vars=task_vars, wrap_async=wrap_async))

        if not wrap_async:
            # remove a temporary path we created
            self._remove_tmp_path(self._connection._shell.tmpdir)
            
        #Now reformats the 'output'
        #'Mon, Mar  4, 2019  7:35:53 PM
        
        date =  dateutil.parser.parse(results['output'].strip())
        results['output'] = date.strftime(self._task.args['format'])
        return results

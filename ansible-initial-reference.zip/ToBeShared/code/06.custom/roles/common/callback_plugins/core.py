from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = '''
    callback: file_log
    type: notification
    short_description: write playbook output to log file(Similar to builtin log_plays)
    version_added: custom
    description:
      - This callback writes playbook output to a file 
    requirements:
     - None
'''

import os
import os.path 
import time

from ansible.module_utils._text import to_bytes
from ansible.plugins.callback import CallbackBase





class CallbackModule(CallbackBase):

    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = 'notification'  # always it is notification, other option stdout= who controls stdout!!
    CALLBACK_NAME = 'file_log'
    CALLBACK_NEEDS_WHITELIST = True  #False # always enable 
    #Make it True to disable and enable it via ansible.cfg 
    #callback_whitelist = file_log  #, timer, mail, profile_roles
    #But it that case, update path in callback_plugins (seperated by colons)
    #https://docs.ansible.com/ansible/latest/reference_appendices/config.html#default-callback-plugin-path

    TIME_FORMAT = "%b %d %Y %H:%M:%S"
    MSG_FORMAT = "%(now)s - %(category)s - %(data)s\n\n"
    
    def __init__(self):
        super(CallbackModule, self).__init__()
        #any other configuration
        #self.option = os.getenv('FILE_LOG_OPTION')

    def log(self, host, category, data):
        path = os.path.join(os.path.abspath(os.curdir), "%s.log" % (host,))
        now = time.strftime(self.TIME_FORMAT, time.localtime())

        msg = self.MSG_FORMAT % dict(now=now, category=category, data=data)
        with open(path, "ab") as fd:
            fd.write(to_bytes(msg))

    #Ansible would call these methods  when below events happen , override those 
    #there are many V2* methods, check lib\ansible\plugins\callback\__init__.py
    def runner_on_failed(self, host, res, ignore_errors=False):
        self.log(host, 'FAILED', res)

    def runner_on_ok(self, host, res):
        self.log(host, 'OK', res)

    def runner_on_skipped(self, host, item=None):
        self.log(host, 'SKIPPED', '...')

    def runner_on_unreachable(self, host, res):
        self.log(host, 'UNREACHABLE', res)

    def runner_on_async_failed(self, host, res, jid):
        self.log(host, 'ASYNC_FAILED', res)

    def playbook_on_import_for_host(self, host, imported_file):
        self.log(host, 'IMPORTED', imported_file)

    def playbook_on_not_import_for_host(self, host, missing_file):
        self.log(host, 'NOTIMPORTED', missing_file)

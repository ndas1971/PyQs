from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import operator 


from ansible import errors
from ansible.utils.display import Display

display = Display()
#Usage 
#display.warning("The 'started' test expects an async task, but a non-async task was tested")

#value is 'var' passed from LHS ie LHS | filter(args)
def mul_filter(value, no):
    """Check if value is in seq.
    """
    return value * no


class FilterModule(object):
    ''' Ansible core jinja2 filters '''

    def filters(self):
        return {
            'mul': mul_filter,            
        }

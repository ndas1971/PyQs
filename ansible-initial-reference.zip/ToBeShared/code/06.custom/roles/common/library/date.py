from __future__ import absolute_import, division, print_function
__metaclass__ = type

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: date

short_description: Executes date command 

version_added: "latest"

description:
    - "Executes date command "

options:
    format:
        description:
            - some formatting info, handled in action plugins 
        required: true

extends_documentation_fragment:
    - commands

author:
    - Somebody 
'''

EXAMPLES = '''
# Pass in a message
- name: Test date command 
  date:
    format: "%b %d %Y %H:%M:%S"

# pass in a message and have changed true
- name: Test with a message and changed output
  action: date
  register: result 
  
- debug:
    msg: "{{ result }}"

'''

RETURN = '''
command:
    description: date 
    type: str
output:
    description: The output date 
'''

from ansible.module_utils.basic import AnsibleModule

'''
For below 
 module_args = dict(
        format=dict(type='str', required=False),        
    )
Usage would be 
date:
  format: ...
OR 
date: format="%b %d %Y %H:%M:%S"
  
Note few are free_form Modules eg command, script etc 
There, we need to pass any args to module like below (note args is task key)
as those do not take key=value args
command:  free_form_command 
args:
  chdir: ...

'''

def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        format=dict(type='str', required=False, default="%b %d %Y %H:%M:%S", aliases=['date_format']),
        #others , for example 
        #new=dict(type='bool', required=False, default=False)
        #state=dict(type='str', default='present', choices=['absent', 'build-dep', 'installed', 'latest', 'present', 'removed', 'present', 'fixed']),
        #deb=dict(type='path'),
        #policy_rc_d=dict(type='int', default=None),
    )
    '''
    Other options for parameters 
    type
        type allows you to define the type of the value accepted for the argument. 
        The default value for type is str. Possible values are:
            str
            list
            dict
            bool
            int
            float
            path
            raw
            jsonarg
            json
            bytes
            bits
        The raw type, performs no type validation or type casing, 
        and maintains the type of the passed value.
    elements
        elements works in combination with type when type='list'. 
        elements can then be defined as elements='int' or any other type, 
        indicating that each element of the specified list should be of that type.
    default
        The default option allows sets a default value for the argument for the scenario when the argument is not provided to the module. 
        When not specified, the default value is None.
    fallback
        fallback accepts a tuple where the first argument is a callable (function) 
        that will be used to perform the lookup, based on the second argument. 
        The second argument is a list of values to be accepted by the callable.
        The most common callable used is env_fallback which will allow an argument 
        to optionally use an environment variable when the argument is not supplied.
        Example:
            username=dict(fallback=(env_fallback, ['ANSIBLE_NET_USERNAME']))
    choices
        choices accepts a list of choices that the argument will accept. 
        The types of choices should match the type.
    required
        required accepts a boolean, either True or False 
        that indicates that the argument is required. 
        This should not be used in combination with default.        
    no_log
        no_log indicates that the value of the argument should not be logged or displayed.        
    aliases
        aliases accepts a list of alternative argument names for the argument, 
        such as the case where the argument is name 
        but the module accepts aliases=['pkg'] to allow pkg to be interchangably with name        
    options
        options implements the ability to create a sub-argument_spec, 
        where the sub options of the top level argument are also validated 
        using the attributes discussed in this section. 
        The example at the top of this section demonstrates use of options. 
        type or elements should be dict is this case.        
    apply_defaults
        apply_defaults works alongside options and allows the default of the sub-options 
        to be applied even when the top-level argument is not supplied.
        In the example of the argument_spec at the top of this section, 
        it would allow module.params['top_level']['second_level'] to be defined, 
        even if the user does not provide top_level when calling the module.        
    removed_in_version
        removed_in_version indicates which version of Ansible a deprecated argument will be removed in.
  
    '''

    # seed the result dict in the object
    # we primarily care about changed and other result 
    # change is if this module effectively modified the target

    result = dict(
        changed=False,  #make it True if it modifies the remote system 
        command='date',
        output='',
        rc=1,        
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    '''
    def __init__(self, argument_spec, bypass_checks=False, no_log=False,
             check_invalid_arguments=None, mutually_exclusive=None, required_together=None,
             required_one_of=None, add_file_common_args=False, supports_check_mode=False,
             required_if=None, required_by=None):

    Common code for quickly building an ansible module in Python
    (although you can write modules with anything that can return JSON)
    '''
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
        #others could be 
        
    )
    '''
    Other args can be 
    #no argument required etc checking 
    bypass_checks=True
    
    #no logging
    no_log=True, 
    
    #must be one required - list of list 
    required_one_of=[['autoremove', 'deb', 'package', 'update_cache', 'upgrade']], 
    
    #required both - list of list 
    required_together=[['username', 'password'],
                           ['server_proxy_hostname', 'server_proxy_port'],
                           ['server_proxy_user', 'server_proxy_password']],
                           
    #these options can not happen together - list of list 
    mutually_exclusive=[['deb', 'package', 'upgrade']],  
    mutually_exclusive=[['activationkey', 'username'],
                        ['activationkey', 'consumer_id'],
                        ['activationkey', 'environment'],
                        ['activationkey', 'autosubscribe'],
                        ['force', 'consumer_id'],
                        ['pool', 'pool_ids']],
    #if 'state' value is 'present' , username' or(based on last arg) 'activationkey' must be there - list of list 
    #last arg is True at least one requirement of  should be present, else all requirements should be present.
    required_if=[['state', 'present', ['username', 'activationkey'], True]],

    #arg 'cron_file' is required by arg 'user'
    required_by=dict(cron_file=('user',),   )
    
    #add FILE_COMMON_ARGUMENTS to module args list if 
    add_file_common_args=True, 
    FILE_COMMON_ARGUMENTS = dict(
            # These are things we want. About setting metadata (mode, ownership, permissions in general) on
            # created files (these are used by set_fs_attributes_if_different and included in
            # load_file_common_arguments)
            mode=dict(type='raw'),
            owner=dict(),
            group=dict(),
            seuser=dict(),
            serole=dict(),
            selevel=dict(),
            setype=dict(),
            attributes=dict(aliases=['attr']),

            # The following are not about perms and should not be in a rewritten file_common_args
            src=dict(),  # Maybe dest or path would be appropriate but src is not
            follow=dict(type='bool', default=False),  # Maybe follow is appropriate because it determines whether to follow symlinks for permission purposes too
            force=dict(type='bool'),

            # not taken by the file module, but other action plugins call the file module so this ignores
            # them for now. In the future, the caller should take care of removing these from the module
            # arguments before calling the file module.
            content=dict(no_log=True),  # used by copy
            backup=dict(),  # Used by a few modules to create a remote backup before updating the file
            remote_src=dict(),  # used by assemble
            regexp=dict(),  # used by assemble
            delimiter=dict(),  # used by assemble
            directory_mode=dict(),  # used by copy
            unsafe_writes=dict(type='bool'),  # should be available to any module using atomic_move
        )
    
    '''
    
    '''
    AnsibleModule has below 
    
    
    Methods 
      @property
      def tmpdir(self)
      def warn(self, warning)
      def deprecate(self, msg, version=None)
      def load_file_common_arguments(self, params)
      def selinux_mls_enabled(self)
      def selinux_enabled(self)
      def selinux_initial_context(self)
      def selinux_default_context(self, path, mode=0)
      def selinux_context(self, path)
      def user_and_group(self, path, expand=True)
      def find_mount_point(self, path)
      def is_special_selinux_path(self, path)
      def set_default_selinux_context(self, path, changed)
      def set_context_if_different(self, path, context, changed, diff=None)
      def set_owner_if_different(self, path, owner, changed, diff=None, expand=True)
      def set_group_if_different(self, path, group, changed, diff=None, expand=True)
      def set_mode_if_different(self, path, mode, changed, diff=None, expand=True)
      def set_attributes_if_different(self, path, attributes, changed, diff=None, expand=True)
      def get_file_attributes(self, path)
      def _symbolic_mode_to_octal(cls, path_stat, symbolic_mode)
      def _apply_operation_to_mode(user, operator, mode_to_apply, current_mode)
      def _get_octal_mode_from_symbolic_perms(path_stat, user, perms, use_umask)
      def or_reduce(mode, perm)
      def set_fs_attributes_if_different(self, file_args, changed, diff=None, expand=True)
      def check_file_absent_if_check_mode(self, file_path)
      def set_directory_attributes_if_different(self, file_args, changed, diff=None, expand=True)
      def set_file_attributes_if_different(self, file_args, changed, diff=None, expand=True)
      def add_path_info(self, kwargs)
      def safe_eval(self, value, locals=None, include_exceptions=False)
      def debug(self, msg)
      def log(self, msg, log_args=None)
      def get_bin_path(self, arg, required=False, opt_dirs=None)
      def boolean(self, arg)
      def jsonify(self, data)
      def from_json(self, data)
      def add_cleanup_file(self, path)
      def do_cleanup_files(self)
      def exit_json(self, **kwargs)
      def fail_json(self, **kwargs)
      def fail_on_missing_params(self, required_params=None)
      def digest_from_file(self, filename, algorithm)
      def md5(self, filename)
      def sha1(self, filename)
      def sha256(self, filename)
      def backup_local(self, fn)
      def cleanup(self, tmpfile)
      def preserved_copy(self, src, dest)
      def atomic_move(self, src, dest, unsafe_writes=False)
      def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None,
      def append_to_file(self, filename, str)
      def bytes_to_human(self, size)
      def human_to_bytes(self, number, isbits=False)
    '''
    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        return result
        
    '''    
    def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None,
                    use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding='utf-8', errors='surrogate_or_strict',
                    expand_user_and_vars=True, pass_fds=None, before_communicate_callback=None):

        Execute a command, returns rc, stdout, and stderr.

        :arg args: is the command to run
            * If args is a list, the command will be run with shell=False.
            * If args is a string and use_unsafe_shell=False it will split args to a list and run with shell=False
            * If args is a string and use_unsafe_shell=True it runs with shell=True.
        :kw check_rc: Whether to call fail_json in case of non zero RC.
            Default False
        :kw close_fds: See documentation for subprocess.Popen(). Default True
        :kw executable: See documentation for subprocess.Popen(). Default None
        :kw data: If given, information to write to the stdin of the command
        :kw binary_data: If False, append a newline to the data.  Default False
        :kw path_prefix: If given, additional path to find the command in.
            This adds to the PATH environment variable so helper commands in
            the same directory can also be found
        :kw cwd: If given, working directory to run the command inside
        :kw use_unsafe_shell: See `args` parameter.  Default False
        :kw prompt_regex: Regex string (not a compiled regex) which can be
            used to detect prompts in the stdout which would otherwise cause
            the execution to hang (especially if no input data is specified)
        :kw environ_update: dictionary to *update* os.environ with
        :kw umask: Umask to be used when running the command. Default None
        :kw encoding: Since we return native strings, on python3 we need to
            know the encoding to use to transform from bytes to text.  If you
            want to always get bytes back, use encoding=None.  The default is
            "utf-8".  This does not affect transformation of strings given as
            args.
        :kw errors: Since we return native strings, on python3 we need to
            transform stdout and stderr from bytes to text.  If the bytes are
            undecodable in the ``encoding`` specified, then use this error
            handler to deal with them.  The default is ``surrogate_or_strict``
            which means that the bytes will be decoded using the
            surrogateescape error handler if available (available on all
            python3 versions we support) otherwise a UnicodeError traceback
            will be raised.  This does not affect transformations of strings
            given as args.
        :kw expand_user_and_vars: When ``use_unsafe_shell=False`` this argument
            dictates whether ``~`` is expanded in paths and environment variables
            are expanded before running the command. When ``True`` a string such as
            ``$SHELL`` will be expanded regardless of escaping. When ``False`` and
            ``use_unsafe_shell=False`` no path or variable expansion will be done.
        :kw pass_fds: When running on python3 this argument
            dictates which file descriptors should be passed
            to an underlying ``Popen`` constructor.
        :kw before_communicate_callback: This function will be called
            after ``Popen`` object will be created
            but before communicating to the process.
            (``Popen`` object will be passed to callback as a first argument)
        :returns: A 3-tuple of return code (integer), stdout (native string),
            and stderr (native string).  On python2, stdout and stderr are both
            byte strings.  On python3, stdout and stderr are text strings converted
            according to the encoding and errors parameters.  If you want byte
            strings on python3, use encoding=None to turn decoding to text off.
    '''
    rc, out, err = module.run_command('/usr/bin/date --iso-8601=seconds', use_unsafe_shell=True)

    result['rc'] = rc 
    result['output'] = out 
    #we can access module params as given by users 
    #module.params is a dict 
    result['format'] = module.params['format'] #it's a dict, so could have used  D.get(k[,d]) 
   
    if rc != 0:
        result['output'] = err
        module.fail_json(msg='non-zero return code', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)

def main():
    run_module()

if __name__ == '__main__':
    main()
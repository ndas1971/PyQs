from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = """
    lookup: filesize
    version_added: "0.1"
    short_description: read file size
    description:
        - This lookup returns size of file on the Ansible controller's file system.
    options:
      inkb:
        description: whether or not to give in kb 
        type: bool
        required: False
        default: False
"""

EXAMPLES = """
- debug: msg="the size of foo.txt is {{lookup('filesize', '/etc/foo.txt') }}"

- name: display multiple file sizes
  debug: var=item
  with_filesize:
    - "/path/to/foo.txt"
    - "bar.txt"  # will be looked in files/ dir relative to play or in role
    - "/path/to/biz.txt"
"""

RETURN = """
  _size:
    description:
      - size of file 
"""

from ansible.errors import AnsibleError, AnsibleParserError
from ansible.plugins.lookup import LookupBase
from ansible.module_utils._text import to_bytes, to_text #compatibility of Py2 with Py3 
from ansible.utils.display import Display
import os.path 

display = Display(verbosity=0)  #max=5, default 0, then only -vvv etc shows up 

"""
class LookupBase(AnsiblePlugin):

    def __init__(self, loader=None, templar=None, **kwargs):

        super(LookupBase, self).__init__()

        self._loader = loader
        self._templar = templar

        # Backwards compat: self._display isn't really needed, just import the global display and use that.
        self._display = display
        
    Methods Are 
    def get_basedir(self, variables)
    
    @staticmethod
    def _flatten(terms)
    
    @staticmethod
    def _combine(a, b)

    @staticmethod
    def _flatten_hash_to_list(terms) # as [{key:, value:..},..]

    def find_file_in_search_path(self, myvars, subdir, needle, ignore_missing=False)
"""


class LookupModule(LookupBase):

    def run(self, terms, variables=None, **kwargs):
        """
        When the playbook specifies a lookup, this method is run.  The
        arguments to the lookup become the arguments to this method.  One
        additional keyword argument named ``variables`` is added to the method
        call.  It contains the variables available to ansible at the time the
        lookup is templated ie available_variables is a dict of key:variable name and value as value  .  
        For instance::

            "{{ lookup('url', 'https://toshio.fedorapeople.org/one.txt', validate_certs=True) }}"

        would end up calling the lookup plugin named url's run method like this::
            run(['https://toshio.fedorapeople.org/one.txt'], variables=available_variables, validate_certs=True)

        Lookup plugins can be used within playbooks for looping.  When this
        happens, the first argument is a list containing the terms.  Lookup
        plugins can also be called from within playbooks to return their
        values into a variable or parameter.  If the user passes a string in
        this case, it is converted into a list.

        Errors encountered during execution should be returned by raising
        AnsibleError() with a message describing the error.

        Any strings returned by this method that could ever contain non-ascii
        must be converted into python's unicode type as the strings will be run
        through jinja2 which has this requirement.  You can use::

            from ansible.module_utils._text import to_text
            result_string = to_text(result_string)
        """

        ret = []
        
        #if called with with_filesize, then contains list of all paths 
        for term in terms:
            display.vvv("File lookup term: %s" % term)

            # Find the file in the expected search path
            #in role, it is role_dir_or_play_dir/files , hence 2nd arg is files 
            lookupfile = self.find_file_in_search_path(variables, 'files', term)
            display.vvv(u"File lookup using %s as file(%s)" % (lookupfile, type(lookupfile)) )
            try:
                if lookupfile:
                    #b_contents, show_data = self._loader._get_file_contents(lookupfile)
                    #contents = to_text(b_contents, errors='surrogate_or_strict')
                    size = os.path.getsize(lookupfile)
                    if kwargs.get('inkb', False):
                        size = size /1000
                    ret.append(size)
                else:
                    raise AnsibleParserError()
            except AnsibleParserError:
                raise AnsibleError("could not locate file in lookup: %s" % term)

        return ret

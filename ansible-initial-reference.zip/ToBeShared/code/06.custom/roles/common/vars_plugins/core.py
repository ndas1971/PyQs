from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = '''
    vars: role_var
    version_added: "0.1"
    short_description: dummy var 
    description:
        - Loads some var 
    options:
      howmany:
        description: how many to create
        type: int
        required: False
        default: 1
'''


from ansible.errors import AnsibleParserError
from ansible.module_utils._text import to_bytes, to_native, to_text
from ansible.plugins.vars import BaseVarsPlugin

from ansible.utils.display import Display

display = Display(verbosity=0)  #max=5, default 0, then only -vvv etc shows up 



class VarsModule(BaseVarsPlugin):
    #how to get howmany? via os.environ ???
    def get_vars(self, loader, path, entities, howmany=1):
        ''' this is abstract method so implement  '''
        super(VarsModule, self).get_vars(loader, path, entities)
        display.vvv("loader=%s(%s), path=%s(%s) entities=%s(%s)" % ( type(loader), loader, type(path), path, type(entities), entities))

        data = {to_text("from_vars_plugin"+str(i)): to_text("some_value") for i in range(howmany)}
        
        return data

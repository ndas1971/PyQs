#! /usr/bin/sh

DEMO=`echo "$1" | tr a-z A-Z `

#function create_role {
create_role () {
    mkdir -p "roles/$1/tasks"   
    touch "roles/$1/tasks/main.yml"     
    mkdir -p "roles/$1/handlers"
    touch "roles/$1/handlers/main.yml" 
    mkdir -p "roles/$1/templates"
    mkdir -p "roles/$1/files"
    mkdir -p "roles/$1/vars"
    touch "roles/$1/vars/main.yml"    
    mkdir -p "roles/$1/defaults" 
    touch "roles/$1/defaults/main.yml"    
    mkdir -p "roles/$1/meta"  
    touch "roles/$1/meta/main.yml"     
    mkdir -p "roles/$1/library"   
    mkdir -p "roles/$1/module_utils"
    mkdir -p "roles/$1/lookup_plugins"  
    
    #some initial values 
    #only leading tab is disabled 
    if [ "$DEMO" = "DEMO" ]; then
	cat <<- EOF > "roles/$1/vars/main.yml"
	var2: "this is another var"
	EOF
    fi
    return 0
}


touch hosts                    
mkdir -p group_vars
mkdir -p host_vars
touch group_vars/all

mkdir -p library
mkdir -p module_utils
mkdir -p filter_plugins
mkdir -p action_plugins
mkdir -p callback_plugins
mkdir -p lookup_plugins        

#create role 
create_role common  

touch site.yml                  
touch webservers.yml #for each group  
touch dbservers.yml    

if [ "$DEMO" = "DEMO" ]; then
#initial values 
cat << EOF > hosts
my_home_pc ansible_ssh_user=ftpuser 

[dbservers]
my_home_pc ansible_ssh_user=ftpuser 

[group1-webservers]
my_home_pc ansible_ssh_user=ftpuser 


[group2-webservers]
my_home_pc ansible_ssh_user=ftpuser 


# webservers in all locations
[webservers:children]
group1-webservers
group2-webservers

EOF


cat << EOF > site.yml
- import_playbook: webservers.yml
- import_playbook: dbservers.yml
EOF

cat << EOF > webservers.yml
---
- hosts: webservers
  roles:
    - common
    # - webtier # another role 
  tasks:
    - name: test connection
      ping:
        data : pong     #optional
      register: output 
    
    - name: Display result
      debug:
        msg: "output {{ output }} or {{ output.ping }}" 
...
EOF

cat << EOF > dbservers.yml
---
- hosts: dbservers
  roles:
    - common
    # - webtier # another role 
    
  tasks:
    - name: Display vars 
      debug:
        msg: "var1={{ var1 }}, var2={{ var2 }}"
      when: var1 is defined and var2 is defined 
...
EOF

cat << EOF > group_vars/all
var1: today
EOF


cat << EOF > roles/common/tasks/main.yml
---
- name: Execute some command 
  command: 'ls -la ~'
  register: result
  tags: [tag1, tag2]

- name: Display result of above task 
  debug: var=result.stdout_lines  # or .stdout , var is option of debug , could be written like (next line)var:
  when: result is success         # var = Mutually exclusive with the 'msg' option.
  tags: [tag1, tag2]

- name: Display result of above task 
  debug:
    msg: "output {{ result.stdout }}"
  notify:
    - notify handler1   # note changed task is shown in yellow else green 
  changed_when: true    # debug  would not report change, hence notify would not be run, hence force it 
  tags: [tag1, tag2]
...
EOF

cat << EOF > roles/common/handlers/main.yml
---
- name: notify this handler #Use name or listen having same string of 'notify:'
  debug:
    msg: "Notified"
  listen: notify handler1  
...

EOF

#Commands can be executed 

read -r -d '' HELP << EOM
#Commands can be executed

#run completely 
ansible-playbook -i hosts site.yml

#To run one tag 
ansible-playbook -i hosts site.yml --tags "tag1,tag2"

#To reconfigure just my webservers:
ansible-playbook -i hosts webservers.yml

#For one group in webservers :
ansible-playbook -i hosts webservers.yml --limit group2-webservers

# confirm what task names would be run if I ran this command and said "just ntp tasks"
ansible-playbook -i hosts webservers.yml --tags tag1 --list-tasks

# confirm what hostnames might be communicated 
ansible-playbook -i hosts webservers.yml  --list-hosts
EOM

echo "$HELP"

fi
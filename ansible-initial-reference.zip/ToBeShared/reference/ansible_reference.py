###Introduction 
Ansible is a  IT automation engine that automates cloud provisioning, 
configuration management, application deployment, intra-service orchestration, 
and many other IT needs.

Ansible works by connecting to nodes and pushing out small programs, called "Ansible modules" to them.

Orchestration is about bringing together disparate things into a coherent whole. 
There are frontend and backend services, databases, monitoring, networks and storage. 
Each has their own role to play with their own configuration and deployment 
and you canot just turn them all on at once 
Ansible is an orchestration tool that can ensure all these tasks happen in the proper order 
- that the database is up before the backend server, that the frontend server is removed from the load balancer before it’s upgraded, 
..so on 





###Your first commands
#default /etc/ansible/hosts 
vi hosts 
#add below , find out ip 
192.168.1.10 ansible_ssh_user=ftpuser #ansible_ssh_pass=password
#then execute , (load module ping(-m), -i inventory file hosts, all means all groups in hosts)
#-m <MODULE_NAME>, --module-name <MODULE_NAME>
ansible all -i hosts -m ping
#run commands , -a <MODULE_ARGS>, --args <MODULE_ARGS>
ansible all -i hosts -a "/bin/echo hello"

##Anisble config file 
Environment
    ANSIBLE_CONFIG – Override the default ansible config file
Files
    /etc/ansible/ansible.cfg – Config file, used if present
    ~/.ansible.cfg – User config file, overrides the default config if present
    check https://raw.githubusercontent.com/ansible/ansible/devel/examples/ansible.cfg
    
##With Passsword and Vault 
ansible-vault encrypt_string ftpuser --ask-vault-pass
#lets say password is passoword 
#This will produce:
!vault |
          $ANSIBLE_VAULT;1.1;AES256
          61666339353266373939333133343737653865653362313931633335616365336363343564656363
          3236313563353030326437646433306333656435373537640a666533646131343430306461343531
          34326130656164353261656636633532616638346235643161633834353538393633366265633737
          6264343763616539390a373430373831306233383165636132333339616432333063333434336537
          3163

Encryption successful

#Create below file and director (host_vars)
cd  first 
cat hosts 
#output 
#my_home_pc
mkdir -p host_vars/my_home_pc.yml 
#and add 
---
ansible_ssh_user : ftpuser 
ansible_ssh_pass : !vault |
          $ANSIBLE_VAULT;1.1;AES256
          61666339353266373939333133343737653865653362313931633335616365336363343564656363
          3236313563353030326437646433306333656435373537640a666533646131343430306461343531
          34326130656164353261656636633532616638346235643161633834353538393633366265633737
          6264343763616539390a373430373831306233383165636132333339616432333063333434336537
          3163
...


#Execute 
#Below gives error "to use the 'ssh' connection type with passwords, you must install the sshpass program"
ansible all -i hosts -m ping   --ask-vault-pass
#so install in master apt-get install sshpass
#OR Use paramiko
ansible all -i hosts -m ping  -c paramiko --ask-vault-pass



##running some playbook 
#Each play contains a list of tasks. Tasks are executed in order, one at a time, 
#against all machines matched by the host pattern, before moving on to the next task.
#ping.yml 
---
- hosts: all
  remote_user: ftpuser
  tasks:
    - name: test connection
      ping:
        data : pong     #optional
      register: output 
    
    - name: Display result
      debug:
        msg: "output {{ output }} or {{ output.ping }}"
    
    - name: Execute some command 
      command: 'ls -la ~'
      register: result
    
    - name: Display result of above task 
      debug: var=result.stdout_lines  #or .stdout , var is option of debug , could be written like (next line)var:
      when: result is success         # Mutually exclusive with the 'msg' option.
    
    - name: Display result of above task 
      debug:
        msg: "output {{ result.stdout }}"

    - debug: var=ansible_facts #configurations
    
    
        
$ ansible-playbook -i hosts ping.yml

#error, update ansible.cfg with below 
[ssh_connection]
ssh_args = -o ControlMaster=no

##Connection failure in older machine 
#default connection is ssh with below arg 
#Many older machine does not support ControlPersist, hence update that 

#ansible.cfg 
[ssh_connection]
# Leaving off ControlPersist will result in poor performance, so use
# paramiko on older platforms rather than removing it, -C controls compression use
#ssh_args = -C -o ControlMaster=auto -o ControlPersist=60s #this is default 
ssh_args = -o ControlMaster=no

#OR use transport paramiko 
#for windows use, winrm 
#by command line (-c or --connection paramiko) or by host_var , ansible_connection: paramiko
#or 
#ansible.cfg 
[defaults]
transport      = paramiko 

#Paramiko/winrm/ssh has many configuration parameters(with defaults and that works)
#but below are generally set in host_vars 
ansible_host
    The name of the host to connect to, if different from the alias you wish to give to it.
ansible_port
    The ssh port number, if not 22
ansible_user
    The default ssh user name to use. 
#Other connenction specific parameters are set in ansible.cfg under 
[ssh_connection]
[paramiko_connection]
#or by setting vars via host_vars  eg ansible_winrm_<option> or ansible_paramiko_<option>
#check 
#https://docs.ansible.com/ansible/latest/plugins/connection/paramiko_ssh.html
#https://docs.ansible.com/ansible/latest/plugins/connection/winrm.html


##to access sudo mode, there are also flags to do that:

# as ftpuser
$ ansible all -m ping -u ftpuser
# as ftpuser, sudoing to root
$ ansible all -m ping -u ftpuser --sudo
# as ftpuser, sudoing to batman
$ ansible all -m ping -u ftpuser --sudo --sudo-user batman

# With latest version of ansible `sudo` is deprecated so use become
# as ftpuser, sudoing to root
$ ansible all -m ping -u ftpuser -b
# as ftpuser, sudoing to batman
$ ansible all -m ping -u ftpuser -b --become-user batman



#When running commands, you can specify the local server by using 'localhost' or '127.0.0.1' 
ansible localhost -m ping -e 'ansible_python_interpreter="/usr/bin/env python"'

#or in  inventory file:
localhost ansible_connection=local ansible_python_interpreter="/usr/bin/env python"

##Host Key Checking
Ansible has host key checking enabled by default.
If a host is reinstalled and has a different key in 'known_hosts', 
this will result in an error message until corrected.
If a host is not initially in 'known_hosts' this will result in prompting for confirmation of the key, 
which results in an interactive experience 

#To disable this behavior, add /etc/ansible/ansible.cfg or ~/.ansible.cfg:
[defaults]
host_key_checking = False


##Quick - How to execute a shell script on a remote server using Ansible?
#Playbook:

---
- name: Transfer and execute a script.
  hosts: server
  remote_user: test_user
  sudo: yes
  tasks:
    - name: Transfer the script
      copy: src=/home/local_user/test.sh dest=/home/test_user mode=0777

    - name: Execute the script locally
      local_action: command sudo sh /home/local_user/test.sh
    
    - name: Execute the script remotely
       command: sh /home/local_user/test.sh  #default is sudo as mentioned in , sudo: yes 
    
    #Or use script 
    - name: Copy and Execute the script 
       script: /home/user/userScript.sh


##Quick - Capture template output(remote server) on the fly and execute an command 

- hosts: webservers
  vars:
    myvar: "{{ lookup('template', 'tmpl.j2') }}"
    tasks:
    - name: run command
        shell: "command < {{ myvar }}"



##Quick -How to send Ansible debug messages to another file?

- hosts: webservers
  vars:
    myvar: 'some_var'
    tasks:
     - name: print to stdout
       command: echo "My log information"
       register: logdata

     - debug: msg="{{ logdata.stdout }}"

     - lineinfile: create=yes regexp="NONEXISTENTLINE" dest=/tmp/ansible.log line="{{logdata.stdout}}" state=present
     #regexp="NONEXISTENTLINE" to allow the same message to be logged several times. 

     
##Quick - Is it possible to 'cat file' and export it's output to screen while playing a playbook and not as debug?

#Use debug(only printing module) 

- hosts: webservers
  vars:
    myvar: 'some_var'
    tasks:
     - name: Print to screen google authenticator details
       command: /bin/cat {{ google_authenticator_secret_file_location }}
       register: details
       tags: google_2fa_user
     
     - debug: msg="{{ details.stdout_lines | quote }}"  #use quote filter 
     
     #or 
     - debug: msg="{{ details.stdout_lines | regex_escape() }"
     
     #or
     
     - debug: msg="{{ details.stdout_lines | regex_replace('"', '\"') }"



##Quick - run Ansible from Python, 

import ansible.runner

runner = ansible.runner.Runner(
   module_name='ping',
   module_args='',
   pattern='web*',
   forks=10
)
datastructure = runner.run()

##Quick - How Do I Log Task Output To A File?

- hosts: webservers
  vars:
    myvar: 'some_var'
    tasks:
     - name: Run Py script
       command: <>.py  > <>.log
       become: yes
       register: PyScript
       ignore_errors: True
     
     - name: PyScript on success
       command: rm <>.log
       when: PyScript|succeeded

#OR 
- hosts: webservers
  vars:
    myvar: 'some_var'
    tasks:
     - name: Dump all vars
       action: template src=templates/dumpall.j2 dest=/tmp/ansible.all

#dumpall.j2:

Module Variables ("vars"):
--------------------------------
{{ vars | to_nice_json }} 

Environment Variables ("environment"):
--------------------------------
{{ environment | to_nice_json }} 

GROUP NAMES Variables ("group_names"):
--------------------------------
{{ group_names | to_nice_json }}

GROUPS Variables ("groups"):
--------------------------------
{{ groups | to_nice_json }}

HOST Variables ("hostvars"):
--------------------------------
{{ hostvars | to_nice_json }} 



###YAML Syntax

#list is "-SPACEelement", dict is "key:SPACEvalue"
#list - ['Ok', 'str', True, 2, 3.0]
- Ok 
- "str"
- yes
- 2 
- 3.0

#dict - {True: 2, 3.0: 2, 'Ok': 'str'}
Ok : "str"
yes : 2 
3.0 : 2
...

#list of list - [['Ok', 'str', True], 2, [3.0, 'ok', True]]
#first - is important, else it would be ['Ok - "str" - yes', 2, '3.0 - ok - yes']
- - Ok 
  - "str"
  - yes
- 2 
- - 3.0
  - ok 
  - yes


#NOK - ['Ok - "str" - yes', 2, '3.0 - ok - yes']
- Ok
 - "str"
 - yes
- 2
- 3.0
 - ok
 - yes



#dict of dict - {3.0: {'ok': True}, 'Ok': {'str': True, 2: 3}}
Ok :
    str : yes 
    2 : 3
3.0 :
    ok : yes



#list of dict - [{'Ok': {'str': True}}, {2: {'ok': True, 3.0: True}}]
- Ok :
    "str" : yes
- 2 :
    3.0 : yes 
    ok : yes



#dict of list - {2: [3.0, 'ok', True], 'Ok': ['str', True]}
Ok :
  - "str"
  - yes
2 :
  - 3.0
  - ok 
  - yes



#nested - [['Ok', {'str': 2}, {True: {'ok': [True, False, 3], 'args': 3}}], 2, [3.0]]
- - Ok 
  - str : 2
  - yes :
        args : 3
        ok :
            - yes 
            - no 
            - 3
- 2 
- - 3.0
...

#Note playbook is list of Play, each play is dict and one key is tasks 
#tasks is list of dict with keys (name, when, MODULE_NAME, register, ...)
#MODULE_NAME is dict 

# All YAML files can optionally begin with --- and end with ...
#This is part of the YAML format and indicates the start and end of a document.

#All members of a list are lines beginning at the same indentation level starting with a "- " (a dash and a space):

---
# A list of tasty fruits
fruits:
    - Apple
    - Orange
    - Strawberry
    - Mango
...

#A dictionary is represented in a simple key: value form (the colon must be followed by a space):

# An employee record
martin:
    name: Martin D'vloper
    job: Developer
    skill: Elite

#complicated data structures 
# Employee records
-  martin:
    name: Martin D'vloper
    job: Developer
    skills:
      - python
      - perl
      - pascal
-  tabitha:
    name: Tabitha Bitumen
    job: Developer
    skills:
      - lisp
      - fortran
      - erlang

#Dictionaries and lists can also be represented in an abbreviated form 
#called Flow Collections as below 

---
martin: {name: Martin D'vloper, job: Developer, skill: Elite}
fruits: ['Apple', 'Orange', 'Strawberry', 'Mango']

#specify a boolean value (true/false) in several forms
create_key: yes
needs_agent: no
knows_oop: True
likes_emacs: TRUE
uses_cvs: false

#Values can span multiple lines using | or >. 
#Spanning multiple lines using a “Literal Block Scalar” | will include the newlines 
#and any trailing spaces. 

#Using a "Folded Block Scalar" > will fold newlines to spaces; 
#In either case the indentation will be ignored. Examples are:

include_newlines: |
            exactly as you see
            will appear these three
            lines of poetry

fold_newlines: >
            this is really a
            single line of text
            despite appearances

#But Note below to include newline (double newline or newline and space)

fold_some_newlines: >
    a
    b

    c
    d
      e
    f
same_as: "a b\nc d\n  e\nf\n"

#A complete example 

---
# An employee record
name: Martin D'vloper
job: Developer
skill: Elite
employed: True
foods:
    - Apple
    - Orange
    - Strawberry
    - Mango
languages:
    perl: Elite
    python: Elite
    pascal: Lame
education: |
    4 GCSEs
    3 A-Levels
    BSc in the Internet of Things

#Note:
#A colon followed by a space (or newline) ': ' is an indicator for a mapping. 
#A space followed by the pound sign ' # ' starts a comment.

#Error 
foo: somebody said I should put a colon here: so I did
windows_drive: c:
...

#but this will work:

windows_path: c:\windows

#So wrap ' ' around them 

foo: 'somebody said I should put a colon here: so I did'

windows_drive: 'c:'

#use double quotes:
foo: "somebody said I should put a colon here: so I did"
windows_drive: "c:"

#The difference between single quotes and double quotes 
#in double quotes you can use escapes(list of allowed escapes given in YAML specification)

foo: "a \t TAB and a \n NEWLINE"

#The following is invalid YAML:

foo: "an escaped \' single quote"

#Ansible uses "{{ var }}" for variables. 
#If a value after a colon starts with a "{", YAML will think it is a dictionary, 
#Always quote it 

foo: "{{ variable }}"

#valid quotes 

foo: "{{ variable }}/additional/string/literal"
foo2: "{{ variable }}\\backslashes\\are\\also\\special\\characters"
foo3: "even if it's just a string literal it must all be quoted"
flow mapping: { key: "you { should [ use , quotes here" }

#Not valid:

foo: "E:\\path\\"rest\\of\\path

#there are a number of characters that are special , 
#cannot be used as the first character of an unquoted scalar: [] {} > | * & ! % # ` @ ,.

#to get literal string instead of boolean, use ""
non_boolean: "yes"
other_string: "False"

#YAML converts certain strings into floating-point values, such as the string 1.0. 
#quote that if you want literal string 

#So, in general, for literla string always quote that 
#for other type, use unqoted ones 


##Complex one- Understand 
#Structure is shown through indentation (one or more spaces). 
#Sequence items are denoted by a dash(eg product contain list of dict), and key value pairs within a map are separated by a colon.

--- 
invoice: 34843
date   : 2001-01-23
bill-to: &id001
    given  : Chris
    family : Dumars
    address:
        lines: |
            458 Walkman Dr.
            Suite #292
        city    : Royal Oak
        state   : MI
        postal  : 48046
ship-to: id001
product:
    - sku         : BL394D
      quantity    : 4
      description : Basketball
      price       : 450.00
    - sku         : BL4438H
      quantity    : 1
      description : Super Hoop
      price       : 2392.00
tax  : 251.42
total: 4443.52
comments: >
    Late afternoon is best.
    Backup contact is Nancy
    Billsmer @ 338-4338.
...


###Playbook Language 
#Each playbook is composed of one or more ‘plays’ in a list.

#The goal of a play is to map a group of hosts to some well defined roles, 
#represented by  tasks.
#a task is nothing more than a call to an ansible module 

#ie playbook is list of dictionaries(with key hosts, vars , remote_user, tasks, handlers ...)
#where tasks is list of dictionaries (with key name , <<module>>, notify, when, ...)
#where module is another dictionary of keys as given in module docs 
#check all keywords, https://docs.ansible.com/ansible/latest/reference_appendices/playbooks_keywords.html

#Example - playbook that contains just one play(do dry run)
ansible-playbook -i hosts examples.yml --check
#examples.yml
---
- hosts: webservers  #from hosts file, where these play wwould be applicable 
  vars:             #these are variables, can be accessed as "{{ http_port }}"
    http_port: 80
    max_clients: 200
  remote_user: root   #remote user 
  tasks:
  - name: ensure apache is at the latest version
    apt:        #this is yum module 
      name: httpd       #these are arguments to yum module , check documentation to understand meaning 
      state: latest     #'name': A package name, latest will update the specified package if it's not of the latest available version.
  - name: write the apache config file  #another task 
    template:                   #this is jinja  template module, executes the template and put the result in dest
      src: /srv/httpd.j2
      dest: /etc/httpd.conf
    notify:         #notifies any Handler named "restart apache" after the Task is run.
    - restart apache
  - name: ensure apache is running
    service:            #service module, check doc 
      name: httpd
      state: started
  handlers:
    - name: restart apache
      service:          # Service module, which can start, stop, restart, reload (and so on) system services
        name: httpd
        state: restarted
...

#Playbooks can contain multiple plays

---
- hosts: webservers
  remote_user: root

  tasks:
  - name: ensure apache is at the latest version
    apt:
      name: httpd
      state: latest
  - name: write the apache config file
    template:
      src: /srv/httpd.j2
      dest: /etc/httpd.conf

- hosts: databases
  remote_user: root

  tasks:
  - name: ensure postgresql is at the latest version
    apt:
      name: postgresql
      state: latest
  - name: ensure that postgresql is started
    service:
      name: postgresql
      state: started

##Remote users can also be defined per task:

---
- hosts: webservers
  remote_user: root
  tasks:
    - name: test connection
      ping:
      remote_user: yourname

#Support for running things as another user , 'become'

---
- hosts: webservers
  remote_user: yourname
  become: yes

#You can also use keyword become on a particular task instead of the whole play:

---
- hosts: webservers
  remote_user: yourname
  tasks:
    - service:
        name: nginx
        state: started
      become: yes
      become_method: sudo

#You can also login as you, and then become a user different than root:

---
- hosts: webservers
  remote_user: yourname
  become: yes
  become_user: postgres

#You can also use other privilege escalation methods, like su:
#to specify a password to sudo, run ansible-playbook with --ask-become-pass 
#or when using the old sudo syntax --ask-sudo-pass (-K). 
---
- hosts: webservers
  remote_user: yourname
  become: yes
  become_method: su



#You can also control the order in which hosts are run. 
#The default is to follow the order supplied by the inventory:

- hosts: all
  order: sorted
  gather_facts: False
  tasks:
    - debug:
        var: inventory_hostname

#Possible values for order are:
inventory:
    The default. The order is ‘as provided’ by the inventory
reverse_inventory:
    As the name implies, this reverses the order ‘as provided’ by the inventory
sorted:
    Hosts are alphabetically sorted by name
reverse_sorted:
    Hosts are sorted by name in reverse alphabetical order
shuffle:
    Hosts are randomly ordered each run

##Tasks list
#Each play contains a list of tasks. Tasks are executed in order, one at a time, 
#against all machines matched by the host pattern, before moving on to the next task. 

#When running the playbook, which runs top to bottom, hosts with failed tasks are taken out of the rotation for the entire playbook. 
#If things fail, simply correct the playbook file and rerun.

#Every task should have a name, which is included in the output from running the playbook. 
# the service module takes key=value arguments:

tasks:
  - name: make sure apache is running
    service:
      name: httpd
      state: started

#The command and shell modules are the only modules that just take a list of arguments 
#and don’t use the key=value form. 

tasks:
  - name: enable selinux
    command: /sbin/setenforce 1

#The command and shell module care about return codes, 
#so if you have a command whose successful exit code is not zero, you may wish to do this:

tasks:
  - name: run this command and ignore the result
    shell: /usr/bin/somecommand || /bin/true

#Or this:

tasks:
  - name: run this command and ignore the result
    shell: /usr/bin/somecommand
    ignore_errors: True

#If the action line is getting too long 
#you can break it on a space and indent any continuation lines:

tasks:
  - name: Copy ansible inventory file to client
    copy: src=/etc/ansible/hosts dest=/etc/ansible/hosts
            owner=root group=root mode=0644

#Variables can be used in action lines. 
tasks:
  - name: create a virtual host file for {{ vhost }}
    template:
      src: somefile.j2
      dest: /etc/httpd/conf.d/{{ vhost }}

##Action Shorthand
#Ansible prefers listing modules like this:

template:
    src: templates/foo.j2
    dest: /etc/foo.conf

#Early versions of Ansible used the following format, which still works:

action: template src=templates/foo.j2 dest=/etc/foo.conf


##Handlers: Running Operations On Change
#notify actions are triggered at the end of each block of tasks in a play, 
#and will only be triggered once even if notified by multiple different tasks.

#For instance, multiple resources may indicate that apache needs to be restarted 
#because they have changed a config file, but apache will only be bounced once to avoid unnecessary restarts.

#Here’s an example of restarting two services when the contents of a file change, 
#but only if the file changes:

- name: template configuration file
  template:
    src: template.j2
    dest: /etc/foo.conf
  notify:
     - restart memcached
     - restart apache

#The things listed in the notify section of a task are called handlers.
handlers:
    - name: restart memcached  #same as notify section 
      service:
        name: memcached
        state: restarted
    - name: restart apache
      service:
        name: apache
        state: restarted

#handlers can also "listen" to generic topics, and tasks can notify those topics as follows:
#This can be used to write Ansible handler with multiple tasks
# It also decouples handlers from their names, making it easier to share handlers among playbooks and roles 

handlers:
    - name: restart memcached
      service:
        name: memcached
        state: restarted
      listen: "restart web services"  #same as notify in tasks as below , this one would run 
    - name: restart apache
      service:
        name: apache
        state:restarted
      listen: "restart web services"  #same as notify in tasks as below , this one would run 

tasks:
    - name: restart everything
      command: echo "this task will restart the web services"
      notify: "restart web services"  #all handlers to 'listen' of this topic would  run 

#Notify handlers are always run in the same order they are defined, not in the order listed in the notify-statement. 
#This is also the case for handlers using listen.
#Handler names and listen topics live in a global namespace.

#If two handler tasks have the same name, only one will run. 
    
#You cannot notify a handler that is defined inside of an include. 
#As of Ansible 2.1, this does work, however the include must be static.

#handlers notified within pre_tasks, tasks, and post_tasks sections are automatically flushed in the end of section where they were notified;
#handlers notified within roles section are automatically flushed in the end of tasks section, but before any tasks handlers.

#to flush all the handler commands immediately you can do this:

tasks:
   - shell: some tasks go here
   - meta: flush_handlers
   - shell: some other tasks


##Executing A Playbook
#To run a playbook using a parallelism level of 10:

ansible-playbook playbook.yml -f 10

##Ansible-Pull
#The ansible-pull is a script that will checkout a repo of configuration instructions from git, 
#and then run ansible-playbook against that content.
#is used to up a remote copy of ansible on each managed node, each set to run via cron and update playbook source via a source repository. 
ansible-pull -U <repository> [options] [<playbook.yml>]
ansible-pull --help 


#To check the syntax of a playbook, 
ansible-playbook playbook.yml --syntax-check  --verbose

#To see what hosts would be affected by a playbook before you run it
ansible-playbook playbook.yml --list-hosts



###Module defaults
#If you find yourself calling the same module repeatedly with the same arguments, 
#it can be useful to define default arguments for that particular module 
#using the module_defaults attribute.

- hosts: localhost
  module_defaults:
    file:
      owner: root
      group: root
      mode: 0755
  tasks:
    - file:
        state: touch
        path: /tmp/file1
    - file:
        state: touch
        path: /tmp/file2
    - file:
        state: touch
        path: /tmp/file3

#The module_defaults attribute can be used at the play, block, and task level. 
#Any module arguments explicitly specified in a task will override any established default for that module argument:

- block:
    - debug:
        msg: "a different message"
  module_defaults:
    debug:
      msg: "a default message"

#It's also possible to remove any previously established defaults for a module 
#by specifying an empty dict:

- file:
    state: touch
    path: /tmp/file1
  module_defaults:
    file: {}

##UseCase - Interacting with an API that requires auth:
- hosts: localhost
  module_defaults:
    uri:
      force_basic_auth: true
      user: some_user
      password: some_password
  tasks:
    - uri:
        url: http://some.api.host/v1/whatever1
    - uri:
        url: http://some.api.host/v1/whatever2
    - uri:
        url: http://some.api.host/v1/whatever3

##Setting a default AWS region for specific EC2-related modules:

- hosts: localhost
  vars:
    my_region: us-west-2
  module_defaults:
    ec2:
      region: '{{ my_region }}'
    ec2_instance_facts:
      region: '{{ my_region }}'
    ec2_vpc_net_facts:
      region: '{{ my_region }}'

###Working with Patterns
#Patterns in Ansible are how we decide which hosts to manage. 
#This can mean what hosts to communicate with, 
#but in terms of Working With Playbooks it actually means what hosts to apply a particular configuration or IT process to.

ansible <pattern_goes_here> -m <module_name> -a <arguments>

#Such as:
ansible webservers -m service -a "name=httpd state=restarted"

#A pattern usually refers to a set of groups (which are sets of hosts) 
#– in the above case, machines in the "webservers" group.

#Anyway, to use Ansible, you'll first need to know how to tell Ansible 
#which hosts in your inventory to talk to. 
#This is done by designating particular host names or groups of hosts.

#The following patterns are equivalent and target all hosts in the inventory:
all
*

#It is also possible to address a specific host or set of hosts by name:

one.example.com
one.example.com:two.example.com
192.0.2.50
192.0.2.*

#The following patterns address one or more groups. 
#Groups separated by a colon indicate an "OR" configuration. 
#This means the host may be in either one group or the other:

webservers
webservers:dbservers

#You can exclude groups as well, for instance, all machines must be in the group webservers 
#but not in the group phoenix:

webservers:!phoenix

#You can also specify the intersection of two groups. 
#This would mean the hosts must be in the group webservers 
#and the host must also be in the group staging:

webservers:&staging

#You can do combinations:

webservers:dbservers:&staging:!phoenix

#The above configuration means "all machines in the groups 'webservers' 
#and 'dbservers' are to be managed if they are in the group 'staging' also, 
#but the machines are not to be managed if they are in the group 'phoenix' ... whew!

#You can also use variables if you want to pass some group specifiers via the "-e" argument 
#to ansible-playbook, but this is uncommonly used:

webservers:!{{excluded}}:&{{required}}

#You also don't have to manage by strictly defined groups. 
#Individual host names, IPs and groups, can also be referenced using wildcards

*.example.com
*.com

#It's also ok to mix wildcard patterns and groups at the same time:

one*.com:dbservers

#You can select a host or subset of hosts from a group by their position. 
#For example, given the following group:

[webservers]
cobweb
webbing
weber

#You can refer to hosts within the group by adding a subscript to the group name:

webservers[0]       # == cobweb
webservers[-1]      # == weber
webservers[0:2]     # == webservers[0],webservers[1]
                    # == cobweb,webbing
webservers[1:]      # == webbing,weber
webservers[:3]      # == cobweb,webbing,weber

#patterns as regular expressions, , start the pattern with a '~':

~(web|db).*\.example\.com

#you can add an exclusion criteria just by supplying the --limit flag to /usr/bin/ansible or /usr/bin/ansible-playbook:

ansible-playbook site.yml --limit datacenter2

#And if you want to read the list of hosts from a file, prefix the file name with '@'.:

ansible-playbook site.yml --limit @retry_hosts.txt

#You can use ',' instead of ':' as a host list separator. 
#The ',' is preferred specially when dealing with ranges and ipv6.




###Working With Modules
#Ansible ships with a number of modules (called the 'module library') 
#that can be executed directly on remote hosts or through Playbooks.

#Modules (also referred to as "task plugins" or "library plugins") 
#are discrete units of code that can be used from the command line or in a playbook task.

#To execute three different modules from the command line:

ansible webservers -m service -a "name=httpd state=started"
ansible webservers -m ping
ansible webservers -m command -a "/sbin/reboot -t now"

#Each module supports taking arguments. 
#Nearly all modules take key=value arguments, space delimited. 
#Some modules take no arguments, 
#and the command/shell modules simply take the string of the command you want to run.

#From playbooks, Ansible modules are executed in a very similar way:

- name: reboot the servers
  action: command /sbin/reboot -t now

#Which can be abbreviated to:

- name: reboot the servers
  command: /sbin/reboot -t now

#Another way to pass arguments to a module is using yaml syntax also called 'complex args'

- name: restart webserver
  service:
    name: httpd
    state: restarted

#All modules technically return JSON format data, 
#though if you are using the command line or playbooks, you don't really need to know much about that. 

#Modules should be idempotent, and should avoid making any changes 
#if they detect that the current state matches the desired final state. 

#When using Ansible playbooks, these modules can trigger 'change events' 
#in the form of notifying 'handlers' to run additional tasks.

#Documentation for each module can be accessed from the command line with the ansible-doc tool:

ansible-doc yum

#For a list of all available modules, run the following at a command prompt:

ansible-doc -l


###Search paths in Ansible
#Absolute paths are not an issue as they always have a known start

Config paths
    By default these should be relative to the config file, 

task evaluation 
    paths are all local, like in lookups
task execution
    which is normally on the remote, unless an action plugin is involved.

local path search order 
    Lookups and action plugins  or module does below 
    1.relative paths get attempted first with a 'files|templates|vars' appended (if not already present), 
      depending on action being taken, 'files' is the default(eg copy)
      (i.e include_vars will use vars/, template would use templates/). 
    2.The paths will be searched from most specific to most general (i.e role before play). 
      dependent roles WILL be traversed 
      (i.e task is in role1, role1 has a dependency of role2, role2 will be looked at first, 
      then role1, then play). i.e
    3.Example 
      role search path is rolename/{files|vars|templates}/, rolename/tasks/.
      play search path is playbook_dir/{files|vars|templates}/, playbook_dir/
      Note any task in rolename can use also use rolename/{files|vars|templates}/ without any prefix
    4.The current working directory (cwd) is not searched. 
      If you include a task file from a role, it will NOT trigger role behavior, 
      this only happens when running as a role, static or include_role will work. 
    5.A variable ansible_search_path var will have the search path used,  in order (but without the appended subdirs). 
      Using 5 "v"s (-vvvvv) should show the detail of the search as it happens.
    6.As for includes, they try the path of the included file first 
      and fall back to the play/role that includes them.    



###Modules - Return Values

#Ansible modules normally return a data structure that can be registered into a variable, 
#or seen directly when output by the ansible program. 

#Each module can optionally document its own unique return values 
#(visible through ansible-doc and on the main docsite.

backup_file
    For those modules that implement backup=no|yes when manipulating files, 
    a path to the backup file created.
changed
    A boolean indicating if the task had to make changes.
failed
    A boolean that indicates if the task was failed or not.
invocation
    Information on how the module was invoked.
msg
    A string with a generic message relayed to the user.
rc
    Some modules execute command line utilities or are geared for executing commands directly 
    (raw, shell, command, etc), this field contains 'return code' of these utilities.
results
    If this key exists, it indicates that a loop was present for the task 
    and that it contains a list of the normal module 'result' per item.
skipped
    A boolean that indicates if the task was skipped or not
stderr
    Some modules execute command line utilities or are geared 
    for executing commands directly (raw, shell, command, etc), 
    this field contains the error output of these utilities.
stderr_lines
    When stderr is returned we also always provide this field which is a list of strings, 
    one item per line from the original.
stdout
    Some modules execute command line utilities or are geared for executing commands directly 
    (raw, shell, command, etc). This field contains the normal output of these utilities.
stdout_lines
    When stdout is returned, Ansible always provides a list of strings, 
    each containing one item per line from the original output.
    
##Internal use
#These keys can be added by modules but will be removed from registered variables; 
#they are 'consumed' by Ansible itself.
ansible_facts
    This key should contain a dictionary which will be appended to the facts assigned 
    to the host. 
    These will be directly accessible and don't require using a registered variable.
exception
    This key can contain traceback information caused by an exception in a module. 
    It will only be displayed on high verbosity (-vvv).
warnings
    This key contains a list of strings that will be presented to the user.
deprecations
    This key contains a list of dictionaries that will be presented to the user. 
    Keys of the dictionaries are msg and version, values are string, 
    value for the version key can be an empty string.


###Working with Inventory

#The inventory file can be in one of many formats, 
#depending on the inventory plugins you have. 
#For this example, the format for /etc/ansible/hosts is an INI-like (one of Ansible’s defaults) 
mail.example.com

[webservers]
foo.example.com
bar.example.com

[dbservers]
one.example.com
two.example.com
three.example.com

#The headings in brackets are group names, which are used in classifying systems 

#A YAML version would look like:
all:
  hosts:
    mail.example.com:
  children:
    webservers:
      hosts:
        foo.example.com:
        bar.example.com:
    dbservers:
      hosts:
        one.example.com:
        two.example.com:
        three.example.com:

#It is ok to put systems in more than one group, 

#If you have hosts that run on non-standard SSH ports , put the port number after the hostname 
badwolf.example.com:5309

#You can also describe hosts via variables:
#In INI:
jumper ansible_port=5555 ansible_host=192.0.2.50

#In YAML:
...
  hosts:
    jumper:
      ansible_port: 5555
      ansible_host: 192.0.2.50

#trying to ansible against the host alias 'jumper' 
#will contact 192.0.2.50 on port 5555. 

#For a lot of hosts following similar patterns
[webservers]
www[01:50].example.com

#For numeric patterns, leading zeros can be included or removed, as desired. 
#Ranges are inclusive. 
#You can also define alphabetic ranges:
[databases]
db-[a:f].example.com

#You can also select the connection type and user on a per host basis:
[targets]

localhost              ansible_connection=local
other1.example.com     ansible_connection=ssh        ansible_user=mpdehaan
other2.example.com     ansible_connection=ssh        ansible_user=mdehaan

##Host Variables
#to assign variables to hosts that will be used later in playbooks:

[atlanta]
host1 http_port=80 maxRequestsPerChild=808
host2 http_port=303 maxRequestsPerChild=909

##Group Variables
#Variables can also be applied to an entire group at once:
#The INI way:

[atlanta]
host1
host2

[atlanta:vars]
ntp_server=ntp.atlanta.example.com
proxy=proxy.atlanta.example.com

#The YAML version:
atlanta:
  hosts:
    host1:
    host2:
  vars:
    ntp_server: ntp.atlanta.example.com
    proxy: proxy.atlanta.example.com

##Groups of Groups, and Group Variables
#to make groups of groups using the :children suffix in INI or the children: entry in YAML. 
#You can apply variables using :vars or vars:

[atlanta]
host1
host2

[raleigh]
host2
host3

[southeast:children]
atlanta
raleigh

[southeast:vars]
some_server=foo.southeast.example.com
halon_system_timeout=30
self_destruct_countdown=60
escape_pods=2

[usa:children]
southeast
northeast
southwest
northwest
#in YAML
all:
  children:
    usa:
      children:
        southeast:
          children:
            atlanta:
              hosts:
                host1:
                host2:
            raleigh:
              hosts:
                host2:
                host3:
          vars:
            some_server: foo.southeast.example.com
            halon_system_timeout: 30
            self_destruct_countdown: 60
            escape_pods: 2
        northeast:
        northwest:
        southwest:

#Note 
Any host that is member of a child group is automatically a member of the parent group.
A child group’s variables will have higher precedence (override) a parent group’s variables.
Groups can have multiple parents and children, but not circular relationships.
Hosts can also be in multiple groups, but there will only be one instance of a host, merging the data from the multiple groups.

##Default groups
##There are two default groups: all and ungrouped. 
#all contains every host. 
#ungrouped contains all hosts that don’t have another group aside from all. 

#Though all and ungrouped are always present, 
#they can be implicit and not appear in group listings like group_names.


##Splitting Out Host and Group Specific Data
#The preferred practice in Ansible is to not store variables in the main inventory file.

#In addition to storing variables directly in the inventory file, 
#host and group variables can be stored in individual files relative to the inventory file 
#(not directory, it is always the file).

#These variable files are in YAML format. 
#Valid file extensions include ‘.yml’, ‘.yaml’, ‘.json’, or no file extension. 

#Assuming the inventory file path is:
/etc/ansible/hosts

#If the host is named ‘foosball’, and in groups ‘raleigh’ and ‘webservers’, 
#variables in YAML files at the following locations will be made available to the host:

/etc/ansible/group_vars/raleigh # can optionally end in '.yml', '.yaml', or '.json'
/etc/ansible/group_vars/webservers
/etc/ansible/host_vars/foosball

#suppose you have hosts grouped by datacenter, 
#and each datacenter uses some different servers. 
#The data in the groupfile ‘/etc/ansible/group_vars/raleigh’ for the ‘raleigh’ 
---
ntp_server: acme.example.org
database_server: storage.example.org

#As an advanced use case, you can create directories named after your groups or hosts, 
#and Ansible will read all the files in these directories in lexicographical order. 
#An example with the ‘raleigh’ group:

/etc/ansible/group_vars/raleigh/db_settings
/etc/ansible/group_vars/raleigh/cluster_settings

#The group_vars/ and host_vars/ directories can exist in the playbook directory 
#OR the inventory directory. 
#If both paths exist, variables in the playbook directory will override variables set in the inventory directory.


##How Variables Are Merged
#By default variables are merged/flattened to the specific host before a play is run. 
#This keeps Ansible focused on the Host and Task, so groups don’t really survive outside of inventory and host matching. 
#By default, Ansible overwrites variables including the ones defined for a group and/or host 
#(see the hash_merge setting to change this) . 
#The order/precedence is (from lowest to highest):
    all group (because it is the ‘parent’ of all other groups)
    parent group
    child group
    host

#When groups of the same parent/child level are merged, it is done alphabetically, 
#and the last group loaded overwrites the previous groups. 
#For example, an a_group will be merged with b_group 
#and b_group vars that match will overwrite the ones in a_group.



#Starting in Ansible version 2.4, 
#users can use the group variable ansible_group_priority to change the merge order 
#for groups of the same level (after the parent/child order is resolved). 
#The larger the number, the later it will be merged, giving it higher priority. 
#This variable defaults to 1 if not set.

a_group:
    testvar: a
    ansible_group_priority: 10
b_group：
    testvar: b

##List of Behavioral Inventory Parameters
#setting the following variables control how Ansible interacts with remote hosts.

##Host connection:
ansible_connection
    Connection type to the host. 
    This can be the name of any of ansible’s connection plugins. 
    SSH protocol types are smart, ssh or paramiko. 
    The default is smart. 
    
#General for all connections:
ansible_host
    The name of the host to connect to, if different from the alias you wish to give to it.
ansible_port
    The ssh port number, if not 22
ansible_user
    The default ssh user name to use.

#Specific to the SSH connection:
ansible_ssh_pass
    The ssh password to use 
    (never store this variable in plain text; always use a vault)
ansible_ssh_private_key_file
    Private key file used by ssh. Useful if using multiple keys and you don’t want to use SSH agent.
ansible_ssh_common_args
    This setting is always appended to the default command line for sftp, scp, and ssh. Useful to configure a ProxyCommand for a certain host (or group).
ansible_sftp_extra_args
    This setting is always appended to the default sftp command line.
ansible_scp_extra_args
    This setting is always appended to the default scp command line.
ansible_ssh_extra_args
    This setting is always appended to the default ssh command line.
ansible_ssh_pipelining
    Determines whether or not to use SSH pipelining. 
    This can override the pipelining setting in ansible.cfg.
    SSH pipelining is an Ansible feature to reduce the number of connections to a host.
    Ansible will normally create a temporary directory under ~/.ansible (via ssh), 
    then for each task, copy the module source to the directory (using sftp or scp) 
    and execute the module (ssh again).
    With pipelining enabled, Ansible will connect only once per task using ssh to execute python,
    and write the module source to its stdin. 
    Even with persistent ssh connections enabled, it's a noticeable improvement to make only one ssh connection per task.
    Unfortunately, pipelining is disabled by default ,
    because it is incompatible with sudo's requiretty setting (or su, which always requires a tty)
ansible_ssh_executable (added in version 2.2)
    This setting overrides the default behavior to use the system ssh. This can override the ssh_executable setting in ansible.cfg.

#Privilege escalation 
ansible_become
    Equivalent to ansible_sudo or ansible_su, allows to force privilege escalation
ansible_become_method
    Allows to set privilege escalation method
ansible_become_user
    Equivalent to ansible_sudo_user or ansible_su_user, allows to set the user you become through privilege escalation
ansible_become_pass
    Equivalent to ansible_sudo_pass or ansible_su_pass, allows you to set the privilege escalation password (never store this variable in plain text; always use a vault. See Variables and Vaults)
ansible_become_exe
    Equivalent to ansible_sudo_exe or ansible_su_exe, allows you to set the executable for the escalation method selected
ansible_become_flags
    Equivalent to ansible_sudo_flags or ansible_su_flags, allows you to set the flags passed to the selected escalation method. This can be also set globally in ansible.cfg in the sudo_flags option

#Remote host environment parameters:
ansible_shell_type
    The shell type of the target system. 
    You should not use this setting unless you have set the ansible_shell_executable 
    to a non-Bourne (sh) compatible shell.
    By default commands are formatted using sh-style syntax. 
    Setting this to csh or fish will cause commands executed on target systems 
    to follow those shell’s syntax instead.
ansible_python_interpreter
    The target host python path. This is useful for systems with more than one Python or not located at /usr/bin/python such as *BSD, or where /usr/bin/python is not a 2.X series Python. We do not use the /usr/bin/env mechanism as that requires the remote user’s path to be set right and also assumes the python executable is named python, where the executable might be named something like python2.6.
ansible_*_interpreter
    Works for anything such as ruby or perl and works just like ansible_python_interpreter. 
    This replaces shebang of modules which will run on that host.
ansible_shell_executable
    This sets the shell the ansible controller will use on the target machine, overrides executable in ansible.cfg which defaults to /bin/sh. You should really only change it if is not possible to use /bin/sh (i.e. /bin/sh is not installed on the target machine or cannot be run from sudo.).

#Examples from an Ansible-INI host file:
some_host         ansible_port=2222     ansible_user=manager
aws_host          ansible_ssh_private_key_file=/home/example/.ssh/aws.pem
freebsd_host      ansible_python_interpreter=/usr/local/bin/python
ruby_module_host  ansible_ruby_interpreter=/usr/bin/ruby.1.9.3

##Non-SSH connection types
#With the host specific parameter ansible_connection=<connector>, 
#the connection type can be changed. 
#The following non-SSH based connectors are available:

local
    This connector can be used to deploy the playbook to the control machine itself.
docker
    This connector deploys the playbook directly into Docker containers 
    using the local Docker client. 
    The following parameters are processed by this connector:
        ansible_host
            The name of the Docker container to connect to.
        ansible_user
            The user name to operate within the container. The user must exist inside the container.
        ansible_become
            If set to true the become_user will be used to operate within the container.
        ansible_docker_extra_args
            Could be a string with any additional arguments understood by Docker, which are not command specific. This parameter is mainly used to configure a remote Docker daemon to use.

#Here is an example of how to instantly deploy to created containers:

- name: create jenkins container
  docker_container:
    docker_host: myserver.net:4243
    name: my_jenkins
    image: jenkins

- name: add container to inventory
  add_host:
    name: my_jenkins
    ansible_connection: docker
    ansible_docker_extra_args: "--tlsverify --tlscacert=/path/to/ca.pem --tlscert=/path/to/client-cert.pem --tlskey=/path/to/client-key.pem -H=tcp://myserver.net:4243"
    ansible_user: jenkins
  changed_when: false

- name: create directory for ssh keys
  delegate_to: my_jenkins
  file:
    path: "/var/jenkins_home/.ssh/jupiter"
    state: directory

    
    
###Working With Dynamic Inventory
#https://docs.ansible.com/ansible/latest/user_guide/intro_dynamic_inventory.html

#If your Ansible inventory fluctuates over time, 
#with hosts spinning up and shutting down in response to business demands, 
#the static inventory solutions described in Working with Inventory will not serve your needs.

#You may need to track hosts from multiple sources: cloud providers, LDAP, Cobbler, 
#and/or enterprise CMDB systems.

#Ansible integrates all of these options via a dynamic external inventory system. 
#Ansible supports two ways to connect with external inventory: Inventory Plugins 
#and inventory scripts <https://github.com/ansible/ansible/tree/devel/contrib/inventory>.

##Inventory Script Example: Cobbler
#Ansible integrates seamlessly with Cobbler, a Linux installation server 
#originally written by Michael DeHaan and now led by James Cammarata, who works for Ansible.

#To tie Ansible’s inventory to Cobbler, 
#copy https://raw.githubusercontent.com/ansible/ansible/devel/contrib/inventory/cobbler.py
# to /etc/ansible and chmod +x the file. 
#Run cobblerd any time you use Ansible and use the -i command line option (e.g. -i /etc/ansible/cobbler.py) 
#to communicate with Cobbler using Cobbler’s XMLRPC API.

#Add a cobbler.ini file in /etc/ansible 
#so Ansible knows where the Cobbler server is 
[cobbler]

# Set Cobbler's hostname or IP address
host = http://127.0.0.1/cobbler_api

# API calls to Cobbler can be slow. For this reason, we cache the results of an API
# call. Set this to the path you want cache files to be written to. Two files
# will be written to this directory:
#   - ansible-cobbler.cache
#   - ansible-cobbler.index

cache_path = /tmp

# The number of seconds a cache file is considered valid. After this many
# seconds, a new API call will be made, and the cache file will be updated.

cache_max_age = 900




###Using Variables

##Creating valid variable names
#Variable names should be letters, numbers, and underscores. 
#Variables should always start with a letter.

#YAML also dictionaries which map keys to values. 
foo:
  field1: one
  field2: two

#reference a specific field in the dictionary 
foo['field1']
#OR
foo.field1

#Must use bracket notation instead of dot notation 
#if you use keys which start and end with two underscores (Those are reserved for special meanings in python) 
#or are any of the known public attributes:
add, append, as_integer_ratio, bit_length, capitalize, center, clear, conjugate, copy, 
count, decode, denominator, difference, difference_update, discard, 
encode, endswith, expandtabs, extend, find, format, fromhex, fromkeys, get, 
has_key, hex, imag, index, insert, intersection, intersection_update, isalnum, 
isalpha, isdecimal, isdigit, isdisjoint, is_integer, islower, isnumeric, isspace, 
issubset, issuperset, istitle, isupper, items, iteritems, iterkeys, itervalues, join, 
keys, ljust, lower, lstrip, numerator, partition, pop, popitem, real, remove, replace, 
reverse, rfind, rindex, rjust, rpartition, rsplit, rstrip, setdefault, sort, split, 
splitlines, startswith, strip, swapcase, symmetric_difference, symmetric_difference_update, 
title, translate, union, update, upper, values, viewitems, viewkeys, viewvalues, zfill.

#You can define variables via 
1.Defining variables in included files and roles
2.Defining variables in a playbook
3.Defining variables in inventory file 

##Defining variables in a playbook
- hosts: webservers
  vars:
    http_port: 80
    
    
    
##Using variables with Jinja2
#Jinja2 includes many built-in filters and Ansible supplies many more filters.

My amp goes to {{ http_port }}

#OR use the same syntax in playbooks

template: src=foo.cfg.j2 dest={{ remote_install_path }}/foo.cfg

#Inside a template you automatically have access to all variables that are in scope for a host.
#and you can also read variables about other hosts. 
 
#ansible allows Jinja2 loops and conditionals in templates, but in playbooks, 
#we do not use them. 

#Note , use "" if {{ starts after : 
#This won’t work:

- hosts: app_servers
  vars:
      app_path: {{ base_path }}/22

#COrrect 

- hosts: app_servers
  vars:
       app_path: "{{ base_path }}/22"




##Variables discovered from systems: Facts
#To see what information is available

- debug: var=ansible_facts

#To see the 'raw' information as gathered:
ansible hostname -m setup

#This will return a large amount of variable data
#the first level keys can be used directly 
{
    "ansible_all_ipv4_addresses": [
        "REDACTED IP ADDRESS"
    ],
    "ansible_all_ipv6_addresses": [
        "REDACTED IPV6 ADDRESS"
    ],
    "ansible_apparmor": {
        "status": "disabled"
    },
    "ansible_architecture": "x86_64",
    "ansible_bios_date": "11/28/2013",
    "ansible_bios_version": "4.1.5",
    "ansible_cmdline": {
        "BOOT_IMAGE": "/boot/vmlinuz-3.10.0-862.14.4.el7.x86_64",
        "console": "ttyS0,115200",
        "no_timer_check": true,
        "nofb": true,
        "nomodeset": true,
        "ro": true,
        "root": "LABEL=cloudimg-rootfs",
        "vga": "normal"
    },
    "ansible_date_time": {
        "date": "2018-10-25",
        "day": "25",
        "epoch": "1540469324",
        "hour": "12",
        "iso8601": "2018-10-25T12:08:44Z",
        "iso8601_basic": "20181025T120844109754",
        "iso8601_basic_short": "20181025T120844",
        "iso8601_micro": "2018-10-25T12:08:44.109968Z",
        "minute": "08",
        "month": "10",
        "second": "44",
        "time": "12:08:44",
        "tz": "UTC",
        "tz_offset": "+0000",
        "weekday": "Thursday",
        "weekday_number": "4",
        "weeknumber": "43",
        "year": "2018"
    },
    "ansible_default_ipv4": {
        "address": "REDACTED",
        "alias": "eth0",
        "broadcast": "REDACTED",
        "gateway": "REDACTED",
        "interface": "eth0",
        "macaddress": "REDACTED",
        "mtu": 1500,
        "netmask": "255.255.255.0",
        "network": "REDACTED",
        "type": "ether"
    },
    "ansible_default_ipv6": {},
    "ansible_device_links": {
        "ids": {},
        "labels": {
            "xvda1": [
                "cloudimg-rootfs"
            ],
            "xvdd": [
                "config-2"
            ]
        },
        "masters": {},
        "uuids": {
            "xvda1": [
                "cac81d61-d0f8-4b47-84aa-b48798239164"
            ],
            "xvdd": [
                "2018-10-25-12-05-57-00"
            ]
        }
    },
    "ansible_devices": {
        "xvda": {
            "holders": [],
            "host": "",
            "links": {
                "ids": [],
                "labels": [],
                "masters": [],
                "uuids": []
            },
            "model": null,
            "partitions": {
                "xvda1": {
                    "holders": [],
                    "links": {
                        "ids": [],
                        "labels": [
                            "cloudimg-rootfs"
                        ],
                        "masters": [],
                        "uuids": [
                            "cac81d61-d0f8-4b47-84aa-b48798239164"
                        ]
                    },
                    "sectors": "83883999",
                    "sectorsize": 512,
                    "size": "40.00 GB",
                    "start": "2048",
                    "uuid": "cac81d61-d0f8-4b47-84aa-b48798239164"
                }
            },
            "removable": "0",
            "rotational": "0",
            "sas_address": null,
            "sas_device_handle": null,
            "scheduler_mode": "deadline",
            "sectors": "83886080",
            "sectorsize": "512",
            "size": "40.00 GB",
            "support_discard": "0",
            "vendor": null,
            "virtual": 1
        },
        "xvdd": {
            "holders": [],
            "host": "",
            "links": {
                "ids": [],
                "labels": [
                    "config-2"
                ],
                "masters": [],
                "uuids": [
                    "2018-10-25-12-05-57-00"
                ]
            },
            "model": null,
            "partitions": {},
            "removable": "0",
            "rotational": "0",
            "sas_address": null,
            "sas_device_handle": null,
            "scheduler_mode": "deadline",
            "sectors": "131072",
            "sectorsize": "512",
            "size": "64.00 MB",
            "support_discard": "0",
            "vendor": null,
            "virtual": 1
        },
        "xvde": {
            "holders": [],
            "host": "",
            "links": {
                "ids": [],
                "labels": [],
                "masters": [],
                "uuids": []
            },
            "model": null,
            "partitions": {
                "xvde1": {
                    "holders": [],
                    "links": {
                        "ids": [],
                        "labels": [],
                        "masters": [],
                        "uuids": []
                    },
                    "sectors": "167770112",
                    "sectorsize": 512,
                    "size": "80.00 GB",
                    "start": "2048",
                    "uuid": null
                }
            },
            "removable": "0",
            "rotational": "0",
            "sas_address": null,
            "sas_device_handle": null,
            "scheduler_mode": "deadline",
            "sectors": "167772160",
            "sectorsize": "512",
            "size": "80.00 GB",
            "support_discard": "0",
            "vendor": null,
            "virtual": 1
        }
    },
    "ansible_distribution": "CentOS",
    "ansible_distribution_file_parsed": true,
    "ansible_distribution_file_path": "/etc/redhat-release",
    "ansible_distribution_file_variety": "RedHat",
    "ansible_distribution_major_version": "7",
    "ansible_distribution_release": "Core",
    "ansible_distribution_version": "7.5.1804",
    "ansible_dns": {
        "nameservers": [
            "127.0.0.1"
        ]
    },
    "ansible_domain": "",
    "ansible_effective_group_id": 1000,
    "ansible_effective_user_id": 1000,
    "ansible_env": {
        "HOME": "/home/zuul",
        "LANG": "en_US.UTF-8",
        "LESSOPEN": "||/usr/bin/lesspipe.sh %s",
        "LOGNAME": "zuul",
        "MAIL": "/var/mail/zuul",
        "PATH": "/usr/local/bin:/usr/bin",
        "PWD": "/home/zuul",
        "SELINUX_LEVEL_REQUESTED": "",
        "SELINUX_ROLE_REQUESTED": "",
        "SELINUX_USE_CURRENT_RANGE": "",
        "SHELL": "/bin/bash",
        "SHLVL": "2",
        "SSH_CLIENT": "23.253.245.60 55672 22",
        "SSH_CONNECTION": "23.253.245.60 55672 104.130.127.149 22",
        "USER": "zuul",
        "XDG_RUNTIME_DIR": "/run/user/1000",
        "XDG_SESSION_ID": "1",
        "_": "/usr/bin/python2"
    },
    "ansible_eth0": {
        "active": true,
        "device": "eth0",
        "ipv4": {
            "address": "REDACTED",
            "broadcast": "REDACTED",
            "netmask": "255.255.255.0",
            "network": "REDACTED"
        },
        "ipv6": [
            {
                "address": "REDACTED",
                "prefix": "64",
                "scope": "link"
            }
        ],
        "macaddress": "REDACTED",
        "module": "xen_netfront",
        "mtu": 1500,
        "pciid": "vif-0",
        "promisc": false,
        "type": "ether"
    },
    "ansible_eth1": {
        "active": true,
        "device": "eth1",
        "ipv4": {
            "address": "REDACTED",
            "broadcast": "REDACTED",
            "netmask": "255.255.224.0",
            "network": "REDACTED"
        },
        "ipv6": [
            {
                "address": "REDACTED",
                "prefix": "64",
                "scope": "link"
            }
        ],
        "macaddress": "REDACTED",
        "module": "xen_netfront",
        "mtu": 1500,
        "pciid": "vif-1",
        "promisc": false,
        "type": "ether"
    },
    "ansible_fips": false,
    "ansible_form_factor": "Other",
    "ansible_fqdn": "centos-7-rax-dfw-0003427354",
    "ansible_hostname": "centos-7-rax-dfw-0003427354",
    "ansible_interfaces": [
        "lo",
        "eth1",
        "eth0"
    ],
    "ansible_is_chroot": false,
    "ansible_kernel": "3.10.0-862.14.4.el7.x86_64",
    "ansible_lo": {
        "active": true,
        "device": "lo",
        "ipv4": {
            "address": "127.0.0.1",
            "broadcast": "host",
            "netmask": "255.0.0.0",
            "network": "127.0.0.0"
        },
        "ipv6": [
            {
                "address": "::1",
                "prefix": "128",
                "scope": "host"
            }
        ],
        "mtu": 65536,
        "promisc": false,
        "type": "loopback"
    },
    "ansible_local": {},
    "ansible_lsb": {
        "codename": "Core",
        "description": "CentOS Linux release 7.5.1804 (Core)",
        "id": "CentOS",
        "major_release": "7",
        "release": "7.5.1804"
    },
    "ansible_machine": "x86_64",
    "ansible_machine_id": "2db133253c984c82aef2fafcce6f2bed",
    "ansible_memfree_mb": 7709,
    "ansible_memory_mb": {
        "nocache": {
            "free": 7804,
            "used": 173
        },
        "real": {
            "free": 7709,
            "total": 7977,
            "used": 268
        },
        "swap": {
            "cached": 0,
            "free": 0,
            "total": 0,
            "used": 0
        }
    },
    "ansible_memtotal_mb": 7977,
    "ansible_mounts": [
        {
            "block_available": 7220998,
            "block_size": 4096,
            "block_total": 9817227,
            "block_used": 2596229,
            "device": "/dev/xvda1",
            "fstype": "ext4",
            "inode_available": 10052341,
            "inode_total": 10419200,
            "inode_used": 366859,
            "mount": "/",
            "options": "rw,seclabel,relatime,data=ordered",
            "size_available": 29577207808,
            "size_total": 40211361792,
            "uuid": "cac81d61-d0f8-4b47-84aa-b48798239164"
        },
        {
            "block_available": 0,
            "block_size": 2048,
            "block_total": 252,
            "block_used": 252,
            "device": "/dev/xvdd",
            "fstype": "iso9660",
            "inode_available": 0,
            "inode_total": 0,
            "inode_used": 0,
            "mount": "/mnt/config",
            "options": "ro,relatime,mode=0700",
            "size_available": 0,
            "size_total": 516096,
            "uuid": "2018-10-25-12-05-57-00"
        }
    ],
    "ansible_nodename": "centos-7-rax-dfw-0003427354",
    "ansible_os_family": "RedHat",
    "ansible_pkg_mgr": "yum",
    "ansible_processor": [
        "0",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz",
        "1",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz",
        "2",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz",
        "3",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz",
        "4",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz",
        "5",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz",
        "6",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz",
        "7",
        "GenuineIntel",
        "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz"
    ],
    "ansible_processor_cores": 8,
    "ansible_processor_count": 8,
    "ansible_processor_threads_per_core": 1,
    "ansible_processor_vcpus": 8,
    "ansible_product_name": "HVM domU",
    "ansible_product_serial": "REDACTED",
    "ansible_product_uuid": "REDACTED",
    "ansible_product_version": "4.1.5",
    "ansible_python": {
        "executable": "/usr/bin/python2",
        "has_sslcontext": true,
        "type": "CPython",
        "version": {
            "major": 2,
            "micro": 5,
            "minor": 7,
            "releaselevel": "final",
            "serial": 0
        },
        "version_info": [
            2,
            7,
            5,
            "final",
            0
        ]
    },
    "ansible_python_version": "2.7.5",
    "ansible_real_group_id": 1000,
    "ansible_real_user_id": 1000,
    "ansible_selinux": {
        "config_mode": "enforcing",
        "mode": "enforcing",
        "policyvers": 31,
        "status": "enabled",
        "type": "targeted"
    },
    "ansible_selinux_python_present": true,
    "ansible_service_mgr": "systemd",
    "ansible_ssh_host_key_ecdsa_public": "REDACTED KEY VALUE",
    "ansible_ssh_host_key_ed25519_public": "REDACTED KEY VALUE",
    "ansible_ssh_host_key_rsa_public": "REDACTED KEY VALUE",
    "ansible_swapfree_mb": 0,
    "ansible_swaptotal_mb": 0,
    "ansible_system": "Linux",
    "ansible_system_capabilities": [
        ""
    ],
    "ansible_system_capabilities_enforced": "True",
    "ansible_system_vendor": "Xen",
    "ansible_uptime_seconds": 151,
    "ansible_user_dir": "/home/zuul",
    "ansible_user_gecos": "",
    "ansible_user_gid": 1000,
    "ansible_user_id": "zuul",
    "ansible_user_shell": "/bin/bash",
    "ansible_user_uid": 1000,
    "ansible_userspace_architecture": "x86_64",
    "ansible_userspace_bits": "64",
    "ansible_virtualization_role": "guest",
    "ansible_virtualization_type": "xen",
    "gather_subset": [
        "all"
    ],
    "module_setup": true
}

#first disk may be referenced in a template or playbook as:

{{ ansible_facts['devices']['xvda']['model'] }}

#the hostname as the system reports it is:

{{ ansible_facts['nodename'] }}

##Disabling facts

- hosts: whatever
  gather_facts: no

##Date and time fact from remote 
tasks:
 - name: Ansible date fact example
   debug:
     var=ansible_date_time.date

#The output will be
ok: [127.0.0.1] => {
"ansible_date_time.date": "2017-07-27"
}

#other formats of the timestamp by changing the parameter after ansible_date_time
"date": "2017-07-27",
"day": "27",
"epoch": "1501173540",
"hour": "22",
"iso8601": "2017-07-27T16:39:00Z",
"iso8601_basic": "20170727T220900129160",
"iso8601_basic_short": "20170727T220900",
"iso8601_micro": "2017-07-27T16:39:00.129240Z",
"minute": "09",
"month": "07",
"second": "00",
"time": "22:09:00",
"tz": "IST",
"tz_offset": "+0530",
"weekday": "Thursday",
"weekday_number": "4",
"weeknumber": "30",
"year": "2017"

#For example
tasks:
  - name: Ansible date timestamp example
    debug:
      var=ansible_date_time.epoch

##From local 
- hosts: all
  tasks:
    - debug: msg="{{ lookup('pipe','date') }}"

#or 
- hosts: all
  tasks:
    - debug: msg="{{ lookup('pipe','date +%Y-%m-%d-%H-%M-%S') }}
 
  
##Date and time fact from remote 
tasks:
 - name: Ansible date fact example
   debug:
     var=ansible_date_time.date

#The output will be
ok: [127.0.0.1] => {
"ansible_date_time.date": "2017-07-27"
}

#other formats of the timestamp by changing the parameter after ansible_date_time
"date": "2017-07-27",
"day": "27",
"epoch": "1501173540",
"hour": "22",
"iso8601": "2017-07-27T16:39:00Z",
"iso8601_basic": "20170727T220900129160",
"iso8601_basic_short": "20170727T220900",
"iso8601_micro": "2017-07-27T16:39:00.129240Z",
"minute": "09",
"month": "07",
"second": "00",
"time": "22:09:00",
"tz": "IST",
"tz_offset": "+0530",
"weekday": "Thursday",
"weekday_number": "4",
"weeknumber": "30",
"year": "2017"

#For example
tasks:
  - name: Ansible date timestamp example
    debug:
      var=ansible_date_time.epoch

##From local 
- hosts: all
  tasks:
    - debug: msg="{{ lookup('pipe','date') }}"

#or 
- hosts: all
  tasks:
    - debug: msg="{{ lookup('pipe','date +%Y-%m-%d-%H-%M-%S') }}
 
  
  
##Local facts (facts.d)
#it means 'locally supplied user values' as opposed to “centrally supplied user values”, 


#If a remotely managed system has an /etc/ansible/facts.d directory, 
#any files in this directory ending in .fact, can be JSON, INI, 
#or executable files returning JSON, and these can supply local facts in Ansible. 

#An alternate directory can be specified using the fact_path play keyword.

#For example, assume /etc/ansible/facts.d/preferences.fact contains:
[general]
asdf=1
bar=2

#This will produce a hash variable fact named general with asdf and bar as members. 

#To validate this, run the following:
#The key part in the key=value pairs will be converted into lowercase inside the ansible_local variabl
ansible <hostname> -m setup -a "filter=ansible_local"

#Output 
"ansible_local": {
        "preferences": {
            "general": {
                "asdf" : "1",
                "bar"  : "2"
            }
        }
 }

#And this data can be accessed in a template/playbook as:

{{ ansible_local['preferences']['general']['asdf'] }}

#If you have a playbook that is copying over a custom fact and then running it, 
#making an explicit call to re-run the setup module can allow that fact to be used 
#during that particular play. 
#Otherwise, it will be available in the next play that gathers fact information. 
- hosts: webservers
  tasks:
    - name: create directory for ansible custom facts
      file: state=directory recurse=yes path=/etc/ansible/facts.d
    - name: install custom ipmi fact
      copy: src=ipmi.fact dest=/etc/ansible/facts.d
    - name: re-read facts after adding custom fact
      setup: filter=ansible_local

##Ansible version
#To adapt playbook behavior to specific version of ansible, 
#a variable ansible_version is available, with the following structure:

"ansible_version": {
    "full": "2.0.0.2",
    "major": 2,
    "minor": 0,
    "revision": 0,
    "string": "2.0.0.2"
}

##Caching Facts
#it is possible for one server to reference variables about another
#when caching is disabled(by default)

{{ hostvars['asdf.example.com']['ansible_facts']['os_family'] }}

#However this is not performant as ansible needs to talk to other server 
#Use caching enabled which saves facts between playbook runs and still above works 

# change the gathering setting to smart or explicit or set gather_facts to False in most plays.


#Currently, Ansible ships with two persistent cache plugins: redis and jsonfile.
#To configure fact caching using redis, enable it in ansible.cfg as follows:
[defaults]
gathering = smart
fact_caching = redis
fact_caching_timeout = 86400
# seconds

#To get redis up and running, perform the equivalent OS commands:
yum install redis
service redis start
pip install redis

#and Python redis library should be installed from pip

#To configure fact caching using jsonfile, enable it in ansible.cfg as follows:
[defaults]
gathering = smart
fact_caching = jsonfile
fact_caching_connection = /path/to/cachedir #local filesystem path to a writeable directory
fact_caching_timeout = 86400
# seconds


##Registering variables
#Use of -v when executing playbooks will show possible values for the results.


- hosts: web_servers
  tasks:
     - shell: /usr/bin/foo
       register: foo_result
       ignore_errors: True

     - shell: /usr/bin/bar
       when: foo_result.rc == 5

#Registered variables are valid on the host the remainder of the playbook run, 
#which is the same as the lifetime of “facts” in Ansible.

#When using register with a loop, the data structure placed in the variable 
#during the loop will contain a results attribute, 
#that is a list of all responses from the module. 

#If a task fails or is skipped, the variable still is registered with a failure or skipped status, 
#the only way to avoid registering a variable is using tags.


##Accessing complex variable data


{{ ansible_facts["eth0"]["ipv4"]["address"] }}

#OR alternatively:

{{ ansible_facts.eth0.ipv4.address }}

#access the first element of an array:

{{ foo[0] }}



##Accessing information about other hosts with magic variables
#List of all predefined variables 
#https://docs.ansible.com/ansible/latest/reference_appendices/special_variables.html#special-variables


#The most commonly used magic variables are 
hostvars, groups, group_names,  inventory_hostname.

#hostvars lets you access variables for another host, including facts that have been gathered about that host. 

{{ hostvars['test.example.com']['ansible_facts']['distribution'] }}

#groups is a list of all the groups (and hosts) in the inventory. 
#This can be used to enumerate all hosts within a group.

{% for host in groups['app_servers'] %}
   # something that applies to all app servers.
{% endfor %}

#A frequently used idiom is walking a group to find all IP addresses in that group.

{% for host in groups['app_servers'] %}
   {{ hostvars[host]['ansible_facts']['eth0']['ipv4']['address'] }}
{% endfor %}


#group_names is a list (array) of all the groups the current host is in. 

{% if 'webserver' in group_names %}
   # some part of a configuration file that only applies to webservers
{% endif %}

#inventory_hostname is the name of the hostname as configured in Ansible’s inventory host file.
#If you have a long FQDN, you can use inventory_hostname_short, 
#which contains the part up to the first period, without the rest of the domain.

##Other useful magic variables refer to the current play or playbook, including:
ansible_play_hosts 
    the full list of all hosts still active in the current play.
ansible_play_batch 
    available as a list of hostnames that are in scope for the current ‘batch’ of the play. 
    The batch size is defined by serial, when not set it is equivalent to the whole play 
    (making it the same as ansible_play_hosts).

ansible_playbook_python 
    the path to the python executable used to invoke the Ansible command line tool.

inventory_dir 
    the pathname of the directory holding Ansible’s inventory host file, 
inventory_file 
    the pathname and the filename pointing to the Ansible’s inventory host file.

playbook_dir 
    contains the playbook base directory.

ansible_check_mode 
    a boolean magic variable which will be set to True if you run Ansible with --check.
    
    
    
##Defining variables in files
#by using an external variables file, or files, just like this:

---

- hosts: all
  remote_user: root
  vars:
    favcolor: blue
  vars_files:
    - /vars/external_vars.yml

  tasks:

  - name: this is just a placeholder
    command: /bin/echo foo

#external_vars.yml

---
# in the above example, this would be vars/external_vars.yml
somevar: somevalue
password: magic

##Passing variables on the command line
#key=value format,  are interpreted as strings

ansible-playbook release.yml --extra-vars "version=1.23.45 other_variable=foo"
#JSON string format, can mention number as well 
ansible-playbook release.yml --extra-vars '{"version":"1.23.45","other_variable":"foo"}'
ansible-playbook arcade.yml --extra-vars '{"pacman":"mrs","ghosts":["inky","pinky","clyde","sue"]}'

#YAML string format:

ansible-playbook release.yml --extra-vars '
version: "1.23.45"
other_variable: foo'

ansible-playbook arcade.yml --extra-vars '
pacman: mrs
ghosts:
- inky
- pinky
- clyde
- sue'

##vars from a JSON or YAML file:

ansible-playbook release.yml --extra-vars "@some_file.json"

##Escaping quotes and other special characters:
#for both your markup (e.g. JSON), and for the shell you’re operating in.:

ansible-playbook arcade.yml --extra-vars "{\"name\":\"Conan O\'Brien\"}"
ansible-playbook arcade.yml --extra-vars '{"name":"Conan O'\\\''Brien"}'
ansible-playbook script.yml --extra-vars "{\"dialog\":\"He said \\\"I just can\'t get enough of those single and double-quotes"\!"\\\"\"}"


##Variable precedence: Where should I put a variable?

#If multiple variables of the same name are defined in different places, 
#they get overwritten in a certain order.

#Here is the order of precedence from least to greatest (the last listed variables winning prioritization):
#Basically, anything that goes into “role defaults” (the defaults folder inside the role) is the most malleable and easily overridden
command line values (eg “-u user”)
role defaults [1]
inventory file or script group vars [2]
inventory group_vars/all [3]
playbook group_vars/all [3]
inventory group_vars/* [3]
playbook group_vars/* [3]
inventory file or script host vars [2]
inventory host_vars/* [3]
playbook host_vars/* [3]
host facts / cached set_facts [4]
play vars
play vars_prompt
play vars_files
role vars (defined in role/vars/main.yml)
block vars (only for tasks in block)
task vars (only for the task)
include_vars
set_facts / registered vars
role (and include_role) params
include params
extra vars (always win precedence)


###jinja - Filters

##Filters For Formatting Data

{{ some_variable | to_json }}
{{ some_variable | to_yaml }}

#For human readable output, you can use:

{{ some_variable | to_nice_json }}
{{ some_variable | to_nice_yaml }}

#to change the indentation of both (new in version 2.2):

{{ some_variable | to_nice_json(indent=2) }}
{{ some_variable | to_nice_yaml(indent=8) }}

#reading in some already formatted data

{{ some_variable | from_json }}
{{ some_variable | from_yaml }}

#for example:
tasks:
  - shell: cat /some/path/to/file.json
    register: result

  - set_fact:
      myvar: "{{ result.stdout | from_json }}"

#To parse multi-document yaml strings, the from_yaml_all filter is provided. 
#The from_yaml_all filter will return a generator of parsed yaml documents.

tasks:
  - shell: cat /some/path/to/multidoc-file.yaml
    register: result
  - debug:
      msg: '{{ item }}'
    loop: '{{ result.stdout | from_yaml_all | list }}'

    
##Forcing Variables To Be Defined
#The default behavior from ansible and ansible.cfg is to fail if variables are undefined, 

#This allows an explicit check with this feature off:
{{ variable | mandatory }}

#The variable value will be used as is, 
#but the template evaluation will raise an error if it is undefined.


##Defaulting Undefined Variables
{{ some_variable | default(5) }}


#To use the default value when variables evaluate to false 
#or an empty string you have to set the second parameter to true:
{{ lookup('env', 'MY_USER') | default('admin', true) }}

##Omitting Parameters
#To use the default filter to omit module parameters using the special omit variable:

- name: touch files with an optional mode
  file: dest={{ item.path }} state=touch mode={{ item.mode | default(omit) }}
  loop:
    - path: /tmp/foo
    - path: /tmp/bar
    - path: /tmp/baz
      mode: "0444"

#For the first two files in the list, 
#the default mode will be determined by the umask of the system 
#as the mode= parameter will not be sent to the file module 
#while the final file will receive the mode=0444 option.



##List Filters
#These filters all operate on list variables.

#To get the minimum/max value from list of numbers:
{{ list1 | min }}
{{ [3, 4, 2] | max }}

#Flatten a list (same thing the flatten lookup does):

{{ [3, [4, 2] ] | flatten }}

#Flatten only the first level of a list (akin to the items lookup):

{{ [3, [4, [2]] ] | flatten(levels=1) }}

##Set Theory Filters
#All these functions return a unique set from sets or lists.
{{ list1 | unique }}
{{ list1 | union(list2) }}
{{ list1 | intersect(list2) }}
{{ list1 | difference(list2) }}
{{ list1 | symmetric_difference(list2) }}

##Dict Filter
#To turn a dictionary into a list of items, suitable for looping, use dict2items:
{{ dict | dict2items }}

#Which turns:

tags:
  Application: payment
  Environment: dev

#into:

- key: Application
  value: payment
- key: Environment
  value: dev

#turns a list of dicts with 2 keys, into a dict, 
#mapping the values of those keys into key: value pairs:

{{ tags | items2dict }}

#Which turns:

tags:
  - key: Application
    value: payment
  - key: Environment
    value: dev

#into:
Application: payment
Environment: dev

#items2dict accepts 2 keyword arguments, key_name and value_name 
#that allow configuration of the names of the keys to use for the transformation:

{{ tags | items2dict(key_name='key', value_name='value') }}

##zip and zip_longest filters
#To get a list combining the elements of other lists use zip:

- name: give me list combo of two lists
  debug:
   msg: "{{ [1,2,3,4,5] | zip(['a','b','c','d','e','f']) | list }}"

- name: give me shortest combo of two lists
  debug:
    msg: "{{ [1,2,3] | zip(['a','b','c','d','e','f']) | list }}"

#To always exhaust all list use zip_longest:

- name: give me longest combo of three lists , fill with X
  debug:
    msg: "{{ [1,2,3] | zip_longest(['a','b','c','d','e','f'], [21, 22, 23], fillvalue='X') | list }}"

#these filters can be used to contruct a dict:

{{ dict(keys_list | zip(values_list)) }}

#Which turns:

list_one:
  - one
  - two
list_two:
  - apple
  - orange

#into:

one: apple
two: orange

##subelements Filter
#Produces a product of an object, and subelement values of that object, 
#similar to the subelements lookup:

{{ users | subelements('groups', skip_missing=True) }}

#Which turns:

users:
  - name: alice
    authorized:
      - /tmp/alice/onekey.pub
      - /tmp/alice/twokey.pub
    groups:
      - wheel
      - docker
  - name: bob
    authorized:
      - /tmp/bob/id_rsa.pub
    groups:
      - docker

#Into:

-
  - name: alice
    groups:
      - wheel
      - docker
    authorized:
      - /tmp/alice/onekey.pub
  - wheel
-
  - name: alice
    groups:
      - wheel
      - docker
    authorized:
      - /tmp/alice/onekey.pub
  - docker
-
  - name: bob
    authorized:
      - /tmp/bob/id_rsa.pub
    groups:
      - docker
  - docker

#An example of using this filter with loop:
- name: Set authorized ssh key, extracting just that data from 'users'
  authorized_key:
    user: "{{ item.0.name }}"
    key: "{{ lookup('file', item.1) }}"
  loop: "{{ users | subelements('authorized') }}"

##Random Mac Address Filter
#This filter can be used to generate a random MAC address from a string prefix.

#To get a random MAC address from a string prefix starting with ‘52:54:00’:

"{{ '52:54:00' | random_mac }}"
# => '52:54:00:ef:1c:03'

##Random Number Filter
#This filter can be used similar to the default jinja2 random filter 
#(returning a random item from a sequence of items), 
#but can also generate a random number based on a range.

#To get a random item from a list:

"{{ ['a','b','c'] | random }}"
# => 'c'

#To get a random number between 0 and a specified number:

"{{ 60 | random }} * * * * root /script/from/cron"
# => '21 * * * * root /script/from/cron'

#Get a random number from 0 to 100 but in steps of 10:

{{ 101 | random(step=10) }}
# => 70

#Get a random number from 1 to 100 but in steps of 10:

{{ 101 | random(1, 10) }}
# => 31
{{ 101 | random(start=1, step=10) }}
# => 51

#To initialize the random number generator from a seed. This way, you can create random-but-idempotent numbers:

"{{ 60 | random(seed=inventory_hostname) }} * * * * root /script/from/cron"

##Shuffle Filter
#This filter will randomize an existing list, giving a different order every invocation.

#To get a random list from an existing list:

{{ ['a','b','c'] | shuffle }}
# => ['c','a','b']
{{ ['a','b','c'] | shuffle }}
# => ['b','c','a']

#To shuffle a list idempotent. All you need is a seed

{{ ['a','b','c'] | shuffle(seed=inventory_hostname) }}
# => ['b','a','c']

##Math
{{ myvar | log }}
{{ myvar | log(10) }}
{{ myvar | pow(2) }}
{{ myvar | pow(5) }}
{{ myvar | root }}
{{ myvar | root(5) }} #5th root 
{{ myvar | abs }}
{{ myvar | round(2) }}

##JSON Query Filter
#to extract only a small set of data within json 
#This filter is built upon jmespath

domain_definition:
    domain:
        cluster:
            - name: "cluster1"
            - name: "cluster2"
        server:
            - name: "server11"
              cluster: "cluster1"
              port: "8080"
            - name: "server12"
              cluster: "cluster1"
              port: "8090"
            - name: "server21"
              cluster: "cluster2"
              port: "9080"
            - name: "server22"
              cluster: "cluster2"
              port: "9090"
        library:
            - name: "lib1"
              target: "cluster1"
            - name: "lib2"
              target: "cluster2"

#To extract all clusters from this structure
- name: "Display all cluster names"
  debug:
    var: item
  loop: "{{ domain_definition | json_query('domain.cluster[*].name') }}"

#for all server names:

- name: "Display all server names"
  debug:
    var: item
  loop: "{{ domain_definition | json_query('domain.server[*].name') }}"

#ports from cluster1:

- name: "Display all ports from cluster1"
  debug:
    var: item
  loop: "{{ domain_definition | json_query(server_name_cluster1_query) }}"
  vars:
    server_name_cluster1_query: "domain.server[?cluster=='cluster1'].port"

#Or, alternatively print out the ports in a comma separated string:

- name: "Display all ports from cluster1 as a string"
  debug:
    msg: "{{ domain_definition | json_query('domain.server[?cluster==`cluster1`].port') | join(', ') }}"

#quoting literals using backticks avoids escaping quotes and maintains readability.
#Or, using YAML single quote escaping:

- name: "Display all ports from cluster1"
  debug:
    var: item
  loop: "{{ domain_definition | json_query('domain.server[?cluster==''cluster1''].port') }}"

#Escaping single quotes within single quotes in YAML is done by doubling the single quote.

#get a hash map with all ports and names of a cluster:

- name: "Display all server ports and names from cluster1"
  debug:
    var: item
  loop: "{{ domain_definition | json_query(server_name_cluster1_query) }}"
  vars:
    server_name_cluster1_query: "domain.server[?cluster=='cluster2'].{name: name, port: port}"

##Quick JMESPath (JSON Matching Expression paths)
>>> import jmespath
>>> path = jmespath.search('foo.bar', {'foo': {'bar': 'baz'}})
'baz'
#Query syntax 
{"a": "foo", "b": "bar", "c": "baz"}            
    a   
    gives foo 
{"a": {"b": {"c": {"d": "value"}}}}             
    a.b.c.d 
    gives value 
["a", "b", "c", "d", "e", "f"]
    [1]
    gives "b"
{"a": {
  "b": {
    "c": [
      {"d": [0, [1, 2]]},
      {"d": [3, 4]}
    ]
  }
}}     
    a.b.c[0].d[1][0]
    gives 1
[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    [0:5] or [:5] or with step [::2] eg reverse [::-1]
    gives (end is exclusive)
    [
      0,
      1,
      2,
      3,
      4
    ]

{
  "people": [
    {"first": "James", "last": "d"},
    {"first": "Jacob", "last": "e"},
    {"first": "Jayden", "last": "f"},
    {"missing": "different"}
  ],
  "foo": {"bar": "baz"}
}
    List and Slice Projections, using * as wildcard
    people[*].first
    gives [
      "James",
      "Jacob",
      "Jayden"
    ]
    people[:2].first
    gives [
      "James",
      "Jacob"
    ]
    
{
  "ops": {
    "functionA": {"numArgs": 2},
    "functionB": {"numArgs": 3},
    "functionC": {"variadic": true}
  }
}  
    Object Projections
    Whereas a list projection is defined for a JSON array, an object projection is defined for a JSON object.
    ops.*.numArgs
    gives [
          2,
          3
        ]

{
  "reservations": [
    {
      "instances": [
        {"state": "running"},
        {"state": "stopped"}
      ]
    },
    {
      "instances": [
        {"state": "terminated"},
        {"state": "runnning"}
      ]
    }
  ]
}
    Flatten Projections 
    reservations[*].instances[*].state
    gives [
      [
        "running",
        "stopped"
      ],
      [
        "terminated",
        "runnning"
      ]
    ]
    
[
  [0, 1],
  2,
  [3],
  4,
  [5, [6, 7]]
]
    [] for flatten a list 
    gives     [
      0,
      1,
      2,
      3,
      4,
      5,
      [
        6,
        7
      ]
    ]

{
  "machines": [
    {"name": "a", "state": "running"},
    {"name": "b", "state": "stopped"},
    {"name": "b", "state": "running"}
  ]
}
    Filter projections 
    machines[?state=='running'].name
    gives [
      "a",
      "b"
    ]
    equivalent to 
    result = []
    foreach machine in inputData['machines']
      if machine['state'] == 'running'
        result.insert_at_end(machine['name'])
    return result


{
  "people": [
    {"first": "James", "last": "d"},
    {"first": "Jacob", "last": "e"},
    {"first": "Jayden", "last": "f"},
    {"missing": "different"}
  ],
  "foo": {"bar": "baz"}
}
    Pipe Expressions, <expression> | <expression>
    people[*].first | [0]
    gives "James" , first element of the list from expression1 


{
  "people": [
    {
      "name": "a",
      "state": {"name": "up"}
    },
    {
      "name": "b",
      "state": {"name": "down"}
    },
    {
      "name": "c",
      "state": {"name": "up"}
    }
  ]
}
    Multiselect 
    A multiselect list creates a list and a multiselect hash creates a JSON object.
    people[].[name, state.name]
    gives [
      [
        "a",
        "up"
      ],
      [
        "b",
        "down"
      ],
      [
        "c",
        "up"
      ]
    ]
    people[].{Name: name, State: state.name}
    gives     [
      {
        "Name": "a",
        "State": "up"
      },
      {
        "Name": "b",
        "State": "down"
      },
      {
        "Name": "c",
        "State": "up"
      }
    ]
    
{
  "people": [
    {
      "name": "b",
      "age": 30,
      "state": {"name": "up"}
    },
    {
      "name": "a",
      "age": 50,
      "state": {"name": "down"}
    },
    {
      "name": "c",
      "age": 40,
      "state": {"name": "up"}
    }
  ]
}
    Functions , check http://jmespath.org/specification.html#builtin-functions
    length(people) 
    gives 3
    max_by(people, &age).name 
    gives "a"
    myarray[?contains(@, 'foo') == `true`]
    @ character refers to the current element being evaluated in myarra
    gives [
      "foo",
      "foobar",
      "barfoo",
      "barfoobaz"
    ]
    
    
    
##IP address filter
#To test if a string is a valid IP address:
{{ myvar | ipaddr }}

#a specific IP protocol version:

{{ myvar | ipv4 }}
{{ myvar | ipv6 }}

#To extract specific information from an IP address. 
#For example, to get the IP address itself from a CIDR, you can use:

{{ '192.0.2.1/24' | ipaddr('address') }}


##Network CLI filters
#To convert the output of a network device CLI command into structured JSON output
{{ output | parse_cli('path/to/spec') }}

#The parse_cli filter will load the spec file and pass the command output through it, 
#returning JSON output. 

#The YAML spec file defines how to parse the CLI output.
#example of a valid spec file that will parse the output from the show vlan command.

---
vars:
  vlan:
    vlan_id: "{{ item.vlan_id }}"
    name: "{{ item.name }}"
    enabled: "{{ item.state != 'act/lshut' }}"
    state: "{{ item.state }}"

keys:
  vlans:
    value: "{{ vlan }}"
    items: "^(?P<vlan_id>\\d+)\\s+(?P<name>\\w+)\\s+(?P<state>active|act/lshut|suspended)"
  state_static:
    value: present

#The spec file above will return a JSON data structure that is a 
#list of hashes with the parsed VLAN information.

#OR could be parsed into a hash by using the key and values directives
---
vars:
  vlan:
    key: "{{ item.vlan_id }}"
    values:
      vlan_id: "{{ item.vlan_id }}"
      name: "{{ item.name }}"
      enabled: "{{ item.state != 'act/lshut' }}"
      state: "{{ item.state }}"

keys:
  vlans:
    value: "{{ vlan }}"
    items: "^(?P<vlan_id>\\d+)\\s+(?P<name>\\w+)\\s+(?P<state>active|act/lshut|suspended)"
  state_static:
    value: present

#Common use case for parsing CLI commands is to break a large command into blocks that can be parsed. 
#This can be done using the start_block and end_block directives to break the command into blocks that can be parsed.
#The example  will parse the output of show interface into a list of hashes.
---
vars:
  interface:
    name: "{{ item[0].match[0] }}"
    state: "{{ item[1].state }}"
    mode: "{{ item[2].match[0] }}"

keys:
  interfaces:
    value: "{{ interface }}"
    start_block: "^Ethernet.*$"
    end_block: "^$"
    items:
      - "^(?P<name>Ethernet\\d\\/\\d*)"
      - "admin state is (?P<state>.+),"
      - "Port mode is (.+)"


#The network filters also support parsing the output of a CLI command using the TextFSM library. To parse the CLI output with TextFSM use the following filter:
#Use of the TextFSM filter requires the TextFSM library to be installed.
{{ output.stdout[0] | parse_cli_textfsm('path/to/fsm') }}


##Network XML filters
#To convert the XML output of a network device command into structured JSON output
{{ output | parse_xml('path/to/spec') }}

#Below is an example of a valid spec file that will parse the output 
#from the show vlan | display xml command.

---
vars:
  vlan:
    vlan_id: "{{ item.vlan_id }}"
    name: "{{ item.name }}"
    desc: "{{ item.desc }}"
    enabled: "{{ item.state.get('inactive') != 'inactive' }}"
    state: "{% if item.state.get('inactive') == 'inactive'%} inactive {% else %} active {% endif %}"

keys:
  vlans:
    value: "{{ vlan }}"
    top: configuration/vlans/vlan
    items:
      vlan_id: vlan-id
      name: name
      desc: description
      state: ".[@inactive='inactive']"

#The spec file above will return a JSON data structure that is a list of hashes with the parsed VLAN information.

#OR could be parsed into a hash by using the key and values directives
---
vars:
  vlan:
    key: "{{ item.vlan_id }}"
    values:
        vlan_id: "{{ item.vlan_id }}"
        name: "{{ item.name }}"
        desc: "{{ item.desc }}"
        enabled: "{{ item.state.get('inactive') != 'inactive' }}"
        state: "{% if item.state.get('inactive') == 'inactive'%} inactive {% else %} active {% endif %}"

keys:
  vlans:
    value: "{{ vlan }}"
    top: configuration/vlans/vlan
    items:
      vlan_id: vlan-id
      name: name
      desc: description
      state: ".[@inactive='inactive']"

#The value of top is the XPath relative to the XML root node. 

#In the example XML output given below, the value of top is configuration/vlans/vlan, 
#which is an XPath expression relative to the root node (<rpc-reply>). 
#configuration in the value of top is the outer most container node, 
#and vlan is the inner-most container node.

#items is a dictionary of key-value pairs that map user-defined names to XPath expressions 
#that select elements. 
#The Xpath expression is relative to the value of the XPath value contained in top. 
#For example, the vlan_id in the spec file is a user defined name and its value vlan-id is the relative to the value of XPath in top

#Attributes of XML tags can be extracted using XPath expressions. 
#The value of state in the spec is an XPath expression used to get the attributes of the vlan tag in output XML.:

<rpc-reply>
  <configuration>
    <vlans>
      <vlan inactive="inactive">
       <name>vlan-1</name>
       <vlan-id>200</vlan-id>
       <description>This is vlan-1</description>
      </vlan>
    </vlans>
  </configuration>
</rpc-reply>


##Hashing filters
#To get the sha1 hash of a string:

{{ 'test1' | hash('sha1') }}

#To get the md5 hash of a string:

{{ 'test1' | hash('md5') }}

#Get a string checksum:

{{ 'test2' | checksum }}

#Other hashes (platform dependent):

{{ 'test2' | hash('blowfish') }}

#To get a sha512 password hash (random salt):

{{ 'passwordsaresecret' | password_hash('sha512') }}

#To get a sha256 password hash with a specific salt:

{{ 'secretpassword' | password_hash('sha256', 'mysecretsalt') }}

#An idempotent method to generate unique hashes per system is 
#to use a salt that is consistent between runs:

{{ 'secretpassword' | password_hash('sha512', 65534 | random(seed=inventory_hostname) | string) }}

#Hash types available depend on the master system running ansible, 
#hash depends on hashlib password_hash depends on passlib (https://passlib.readthedocs.io/en/stable/lib/passlib.hash.html).

#Some hash types allow providing a rounds parameter:

{{ 'secretpassword' | password_hash('sha256', 'mysecretsalt', rounds=10000) }}


##Combining hashes/dictionaries
#The combine filter allows hashes to be merged. 
#For example, the following would override keys in one hash:

{{ {'a':1, 'b':2} | combine({'b':3}) }}

#The resulting hash would be:

{'a':1, 'b':3}

#The filter also accepts an optional recursive=True parameter to not only override keys in the first hash, 
#but also recurse into nested hashes and merge their keys too

{{ {'a':{'foo':1, 'bar':2}, 'b':2} | combine({'a':{'bar':3, 'baz':4}}, recursive=True) }}

#This would result in:

{'a':{'foo':1, 'bar':3, 'baz':4}, 'b':2}

#The filter can also take multiple arguments to merge:
#In this case, keys in d would override those in c, which would override those in b, and so on.
{{ a | combine(b, c, d) }}


##Extracting values from containers

#The extract filter is used to map from a list of indices to a list of values 
#from a container (hash or array):

{{ [0,2] | map('extract', ['x','y','z']) | list }}
{{ ['x','y'] | map('extract', {'x': 42, 'y': 31}) | list }}

#The results of the above expressions would be:
['x', 'z']
[42, 31]

#The filter can take another argument:

{{ groups['x'] | map('extract', hostvars, 'ec2_ip_address') | list }}

#This takes the list of hosts in group ‘x’, looks them up in hostvars, 
#and then looks up the ec2_ip_address of the result. 
#The final result is a list of IP addresses for the hosts in group ‘x’.

#The third argument to the filter can also be a list, 
#for a recursive lookup inside the container:

{{ ['a'] | map('extract', b, ['x','y']) | list }}

#This would return a list containing the value of b[‘a’][‘x’][‘y’].


##Comment Filter
#The comment filter allows to decorate the text with a chosen comment style. 
{{ "Plain style (default)" | comment }}

#will produce this output:

#
# Plain style (default)
#

#Similar way can be applied style for C (//...), C block (/*...*/), Erlang (%...) and XML (<!--...-->):

{{ "C style" | comment('c') }}
{{ "C block style" | comment('cblock') }}
{{ "Erlang style" | comment('erlang') }}
{{ "XML style" | comment('xml') }}

#If you need a specific comment character that is not included by any of the above
{{ "My Special Case" | comment(decoration="! ") }}

#producing:

!
! My Special Case
!

#The filter can also be applied to any Ansible variable.
#For example to make the output of the ansible_managed variable more readable, 
#we can change the definition in the ansible.cfg file to this:

[defaults]

ansible_managed = This file is managed by Ansible.%n
  template: {file}
  date: %Y-%m-%d %H:%M:%S
  user: {uid}
  host: {host}

#then use the variable with the comment filter:

{{ ansible_managed | comment }}

#which will produce this output:

#
# This file is managed by Ansible.
#
# template: /home/ansible/env/dev/ansible_managed/roles/role1/templates/test.j2
# date: 2015-09-10 11:02:58
# user: ansible
# host: myhost
#



##URL Split Filter
#The urlsplit filter extracts the fragment, hostname, netloc, password, path, port, query, scheme, and username from an URL. With no arguments, returns a dictionary of all the fields:

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('hostname') }}
# => 'www.acme.com'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('netloc') }}
# => 'user:password@www.acme.com:9000'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('username') }}
# => 'user'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('password') }}
# => 'password'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('path') }}
# => '/dir/index.html'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('port') }}
# => '9000'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('scheme') }}
# => 'http'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('query') }}
# => 'query=term'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit('fragment') }}
# => 'fragment'

{{ "http://user:password@www.acme.com:9000/dir/index.html?query=term#fragment" | urlsplit }}
# =>
#   {
#       "fragment": "fragment",
#       "hostname": "www.acme.com",
#       "netloc": "user:password@www.acme.com:9000",
#       "password": "password",
#       "path": "/dir/index.html",
#       "port": 9000,
#       "query": "query=term",
#       "scheme": "http",
#       "username": "user"
#   }

##Regular Expression Filters

#To search a string with a regex, use the “regex_search” filter:
# search for "foo" in "foobar"
{{ 'foobar' | regex_search('(foo)') }}

# will return empty if it cannot find a match
{{ 'ansible' | regex_search('(foobar)') }}

# case insensitive search in multiline mode
{{ 'foo\nBAR' | regex_search("^bar", multiline=True, ignorecase=True) }}

#To search for all occurrences of regex matches
# Return a list of all IPv4 addresses in the string
{{ 'Some DNS servers are 8.8.8.8 and 8.8.4.4' | regex_findall('\\b(?:[0-9]{1,3}\\.){3}[0-9]{1,3}\\b') }}

#To replace text in a string with regex, use the “regex_replace” filter:
# convert "ansible" to "able"
{{ 'ansible' | regex_replace('^a.*i(.*)$', 'a\\1') }}

# convert "foobar" to "bar"
{{ 'foobar' | regex_replace('^f.*o(.*)$', '\\1') }}

# convert "localhost:80" to "localhost, 80" using named groups
{{ 'localhost:80' | regex_replace('^(?P<host>.+):(?P<port>\\d+)$', '\\g<host>, \\g<port>') }}

# convert "localhost:80" to "localhost"
{{ 'localhost:80' | regex_replace(':80') }}

# add "https://" prefix to each item in a list
{{ hosts | map('regex_replace', '^(.*)$', 'https://\\1') | list }}


#To escape special characters within a regex, use the “regex_escape” filter:
# convert '^f.*o(.*)$' to '\^f\.\*o\(\.\*\)\$'
{{ '^f.*o(.*)$' | regex_escape() }}





##Other Useful Filters

#To add quotes for shell usage:

- shell: echo {{ string_value | quote }}

#To use one value on true and another on false (new in version 1.9):

{{ (name == "John") | ternary('Mr','Ms') }}

#To concatenate a list into a string:

{{ list | join(" ") }}

#To get the last name of a file path, like ‘foo.txt’ out of ‘/etc/asdf/foo.txt’:

{{ path | basename }}

#To get the last name of a windows style file path (new in version 2.0):

{{ path | win_basename }}

#To separate the windows drive letter from the rest of a file path (new in version 2.0):

{{ path | win_splitdrive }}

#To get only the windows drive letter:

{{ path | win_splitdrive | first }}

#To get the rest of the path without the drive letter:

{{ path | win_splitdrive | last }}

#To get the directory from a path:

{{ path | dirname }}

#To get the directory from a windows path (new version 2.0):

{{ path | win_dirname }}

#To expand a path containing a tilde (~) character (new in version 1.5):

{{ path | expanduser }}

#To expand a path containing environment variables:

{{ path | expandvars }}


#To get the real path of a link (new in version 1.8):

{{ path | realpath }}

#To get the relative path of a link, from a start point (new in version 1.7):

{{ path | relpath('/etc') }}

#To get the root and extension of a path or filename (new in version 2.0):

# with path == 'nginx.conf' the return would be ('nginx', '.conf')
{{ path | splitext }}

#To work with Base64 encoded strings:

{{ encoded | b64decode }}
{{ decoded | b64encode }}

#you can define the type of encoding to use, the default is utf-8:

{{ encoded | b64decode(encoding='utf-16-le') }}
{{ decoded | b64encode(encoding='utf-16-le') }}



#To create a UUID from a string (new in version 1.9):

{{ hostname | to_uuid }}

#To cast values as certain types
- debug:
    msg: test
  when: some_string_value | bool

##To make use of one attribute from each item in a list of complex variables, 
#use the "map" filter 

# get a comma-separated list of the mount points (e.g. "/,/mnt/stuff") on a host
{{ ansible_mounts | map(attribute='mount') | join(',') }}

##To get date object from string use the to_datetime filter, (new in version in 2.2):

# Get total amount of seconds between two dates. Default date format is %Y-%m-%d %H:%M:%S but you can pass your own format
{{ (("2016-08-14 20:00:12" | to_datetime) - ("2015-12-25" | to_datetime('%Y-%m-%d'))).total_seconds()  }}

# Get remaining seconds after delta has been calculated. NOTE: This does NOT convert years, days, hours, etc to seconds. For that, use total_seconds()
{{ (("2016-08-14 20:00:12" | to_datetime) - ("2016-08-14 18:00:00" | to_datetime)).seconds  }}
# This expression evaluates to "12" and not "132". Delta is 2 hours, 12 seconds

# get amount of days between two dates. This returns only number of days and discards remaining hours, minutes, and seconds
{{ (("2016-08-14 20:00:12" | to_datetime) - ("2015-12-25" | to_datetime('%Y-%m-%d'))).days  }}

##To format a date using a string (like with the shell date command), 
#use the strftime filter:
#https://docs.python.org/2/library/time.html#time.strftime
# Display year-month-day
{{ '%Y-%m-%d' | strftime }}

# Display hour:min:sec
{{ '%H:%M:%S' | strftime }}

# Use ansible_date_time.epoch fact
{{ '%Y-%m-%d %H:%M:%S' | strftime(ansible_date_time.epoch) }}

# Use arbitrary epoch value
{{ '%Y-%m-%d' | strftime(0) }}          # => 1970-01-01
{{ '%Y-%m-%d' | strftime(1441357287) }} # => 2015-09-04


##Few Itertools filters 
'product': itertools.product,
'permutations': itertools.permutations,
'combinations': itertools.combinations,

##Combination Filters
#This set of filters returns a list of combined lists. To get permutations of a list:

- name: give me largest permutations (order matters)
  debug:
    msg: "{{ [1,2,3,4,5] | permutations | list }}"

- name: give me permutations of sets of three
  debug:
    msg: "{{ [1,2,3,4,5] | permutations(3) | list }}"

Combinations always require a set size:

- name: give me combinations for sets of two
  debug:
    msg: "{{ [1,2,3,4,5] | combinations(2) | list }}"

##Debugging Filters
#Use the type_debug filter to display the underlying Python type of a variable. 
{{ myvar | type_debug }}



##Plugins Lookups
#Lookup plugins allow access to outside data sources. 
#Like all templating, these plugins are evaluated on the Ansible control machine, 
#and can include reading the filesystem as well as contacting external datastores and services. 
#This data is then made available using the standard templating system in Ansible.



# Lookups occur on the local computer, not on the remote computer.
# They are executed with in the directory containing the role or play, 
#as opposed to local tasks which are executed with the directory of the executed script.

# You can pass wantlist=True to lookups to use in jinja2 template for loops.


#Some lookups pass arguments to a shell. 
#When using variables from a remote/untrusted source, use the |quote filter to ensure safe usage.

#One way of using lookups is to populate variables. 
#These macros are evaluated each time they are used in a task (or template):

vars:
  motd_value: "{{ lookup('file', '/etc/motd') }}"
tasks:
  - debug:
      msg: "motd value is {{ motd_value }}"

##Dictionary Views
#In Python2, the dict.keys(), dict.values(), and dict.items() methods returns a list. 
#Jinja2 returns that to Ansible via a string representation 
#that Ansible can turn back into a list. 

#In Python3, those methods return a dictionary view object. 
#The string representation that Jinja2 returns for dictionary views 
#cannot be parsed back into a list by Ansible. 
#It is, however, easy to make this portable by using the list filter whenever using dict.keys(), dict.values(), or dict.items():

vars:
  hosts:
    testhost1: 127.0.0.2
    testhost2: 127.0.0.3
tasks:
  - debug:
      msg: '{{ item }}'
    # Only works with Python 2
    #loop: "{{ hosts.keys() }}"
    # Works with both Python 2 and Python 3
    loop: "{{ hosts.keys() | list }}"

dict.iteritems()

#In Python2, dictionaries have iterkeys(), itervalues(), and iteritems() methods. 
#These methods have been removed in Python3. 
#Playbooks and Jinja2 templates should use dict.keys(), dict.values(), and dict.items() 
#in order to be compatible with both Python2 and Python3:

vars:
  hosts:
    testhost1: 127.0.0.2
    testhost2: 127.0.0.3
tasks:
  - debug:
      msg: '{{ item }}'
    # Only works with Python 2
    #loop: "{{ hosts.iteritems() }}"
    # Works with both Python 2 and Python 3
    loop: "{{ hosts.items() | list }}"
    
##How to filter, join and map lists in Ansible
#list_operators.yml
#list all network interfaces
- hosts: all
  tasks:
    - name: print interfaces
      debug:
        msg: "{{ ansible_interfaces }}"

$ansible-playbook -c local -i 'localhost,' list_operators.yml


##Filter a list in Ansible
#To include only "eth" or "wlan" types of interfaces
- hosts: all
  tasks:
    - name: print interfaces
      debug:
        msg: "{{ ansible_interfaces | select('match', '^(eth|wlan)[0-9]+') | list }}"


##Map list elements in Ansible
- hosts: all
  tasks:
    - name: print interfaces
      debug:
        msg: "{{ ansible_interfaces | map('upper') | list }}"


##Merge two lists into one in Ansible
- hosts: all
  tasks:
    - name: print interfaces
      debug:
        msg: "{{ ansible_interfaces + [\"VETH-1\", \"VETH-2\"] }}"



            
##Advanced list operations in Ansible
"selectattr" filter in Ansible is useful for filtering lists 
based on attributes of the objects in the list      	
        selectattr('name', 'match', 'eth[2-9]')
Ansible's "sum" filter can be used for reducing lists into new objects (including lists)
        sum(attribute='ips', start=[])
        
##Example 
{
    "addresses": {
        "private_ext": [
            {
                "type": "fixed",
                "addr": "172.16.2.100"
            }
        ],
        "private_man": [
            {
                "type": "fixed",
                "addr": "172.16.1.100"
            },
            {
                "type": "floating",
                "addr": "10.90.80.10"
            }
        ]
    }
}
#Use 
- debug: msg="{{ addresses | json_query(\"private_man[?type=='fixed'].addr\") }}"
#OR 
network.addresses.private_man | selectattr("type", "equalto", "fixed")
#OR ,Ansible also has the tests match and search, which take regular expressions:
network.addresses.private_man | selectattr("type", "match", "^fixed$")
#To reduce the list of dicts to a list of strings, so you only get a list of the addr fields
... | map(attribute='addr') | list

#Or if you want a comma separated string:
... | map(attribute='addr') | join(',')

#Combined, it would look like this.
- debug: msg={{ network.addresses.private_man | selectattr("type", "equalto", "fixed") | map(attribute='addr') | join(',') }}

##Complete example 
	
# file host_vars/HOST/interfaces-eth1.yml
interfaces_eth1:
 - gw: 10.10.10.1
   name: eth1
   ips:
     - {ip: 10.10.10.104, owner: TEST, project: The Project}
     - {ip: 10.10.10.105, owner: Our Client, project: The Project}

	
# file host_vars/HOST/interfaces-eth2.yml 
interfaces_eth2:
 - gw: 10.10.10.1 
   name: eth2 
   ips:
    - {ip: 10.10.10.204, owner: TEST, project: The Project}
    - {ip: 10.10.10.205, owner: Our Client, project: The Project}
    - {ip: 10.10.10.206, owner: Our Client, project: The Project}
    - {ip: 10.10.10.207, owner: Our Client, project: The Project}
    - {ip: 10.10.10.208, owner: Our Client, project: The Project}
    - {ip: 10.10.10.209, owner: Our Client, project: The Project}

#combine all per-interface configs into a single config file for an instance like this:

# file host_vars/HOST/interfaces.yml
interfaces: "{{ interfaces_eth1 }} + {{ interfaces_eth2 }}"

#On each instance, we have at least 1 IP address dedicated to monitoring 
#and checking if the given interface is up and running. 
#Such IP address has the owner field set to "TEST". 
#Find at least one "TEST" IP on each instance.
	
# file playbook.yml
- hosts: all
 tasks:
 - set_fact:
 test_ip: "{{ interfaces 
 | selectattr('name', 'match', 'eth[2-9]') 
 | sum(attribute='ips', start=[]) 
 | selectattr('owner', 'equalto', 'TEST') 
 | map(attribute='ip') 
 | list 
 | first 
 | default('NOT_FOUND') }}"
 - debug:
 msg: "The TEST IP is {{ test_ip }}"
 
##Few Ansible filter docs 
def subelements(obj, subelements, skip_missing=False):
    '''Accepts a dict or list of dicts, and a dotted accessor and produces a product
    of the element and the results of the dotted accessor

    >>> obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    >>> subelements(obj, 'groups')
    [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

    '''
def do_groupby(environment, value, attribute):
    """Overridden groupby filter for jinja2, to address an issue with
    jinja2>=2.9.0,<2.9.5 where a namedtuple was returned which
    has repr that prevents ansible.template.safe_eval.safe_eval from being
    able to parse and eval the data.

    jinja2<2.9.0,>=2.9.5 is not affected, as <2.9.0 uses a tuple, and
    >=2.9.5 uses a standard tuple repr on the namedtuple.

    The adaptation here, is to run the jinja2 `do_groupby` function, and
    cast all of the namedtuples to a regular tuple.

    See https://github.com/ansible/ansible/issues/20098

    We may be able to remove this in the future.
    """
    
def extract(item, container, morekeys=None):
    from jinja2.runtime import Undefined

    value = container[item]

    if value is not Undefined and morekeys is not None:
        if not isinstance(morekeys, list):
            morekeys = [morekeys]

        try:
            value = reduce(lambda d, k: d[k], morekeys, value)
        except KeyError:
            value = Undefined()

    return value
    
def combine(*terms, **kwargs):
    recursive = kwargs.get('recursive', False)
    if len(kwargs) > 1 or (len(kwargs) == 1 and 'recursive' not in kwargs):
        raise AnsibleFilterError("'recursive' is the only valid keyword argument")

    dicts = []
    for t in terms:
        if isinstance(t, MutableMapping):
            dicts.append(t)
        elif isinstance(t, list):
            dicts.append(combine(*t, **kwargs))
        else:
            raise AnsibleFilterError("|combine expects dictionaries, got " + repr(t))

    if recursive:
        return reduce(merge_hash, dicts)
    else:
        return dict(itertools.chain(*map(iteritems, dicts)))



##Jinja builtin filters 
abs(number)
    Return the absolute value of the argument.
attr(obj, name)
    Get an attribute of an object. foo|attr("bar") works like foo.bar 
    just that always an attribute is returned and items are not looked up.
batch(value, linecount, fill_with=None)
    A filter that batches items. 
    It works pretty much like slice just the other way round. 
    It returns a list of lists with the given number of items. 
    If you provide a second parameter this is used to fill up missing items. 
    <table>
    {%- for row in items|batch(3, '&nbsp;') %}
      <tr>
      {%- for column in row %}
        <td>{{ column }}</td>
      {%- endfor %}
      </tr>
    {%- endfor %}
    </table>
capitalize(s)
    Capitalize a value. The first character will be uppercase, all others lowercase.
center(value, width=80)
    Centers the value in a field of a given width.
default(value, default_value=u'', boolean=False)
    If the value is undefined it will return the passed default value, otherwise the value of the variable:
    {{ my_variable|default('my_variable is not defined') }}
    This will output the value of my_variable if the variable was defined, otherwise 'my_variable is not defined'. If you want to use default with variables that evaluate to false you have to set the second parameter to true:
    {{ ''|default('the string was empty', true) }}
    Aliases:	d
dictsort(value, case_sensitive=False, by='key', reverse=False)
    Sort a dict and yield (key, value) pairs. Because python dicts are unsorted you may want to use this function to order them by either key or value:
    {% for item in mydict|dictsort %}
        sort the dict by key, case insensitive
    {% for item in mydict|dictsort(reverse=true) %}
        sort the dict by key, case insensitive, reverse order
    {% for item in mydict|dictsort(true) %}
        sort the dict by key, case sensitive
    {% for item in mydict|dictsort(false, 'value') %}
        sort the dict by value, case insensitive
escape(s)
    Convert the characters &, <, >, ‘, and ” in string s to HTML-safe sequences. Use this if you need to display text that might contain such characters in HTML. Marks return value as markup string.
    Aliases:	e
filesizeformat(value, binary=False)
    Format the value like a ‘human-readable’ file size (i.e. 13 kB, 4.1 MB, 102 Bytes, etc). Per default decimal prefixes are used (Mega, Giga, etc.), if the second parameter is set to True the binary prefixes are used (Mebi, Gibi).
first(seq)
    Return the first item of a sequence.
float(value, default=0.0)
    Convert the value into a floating point number. If the conversion doesn’t work it will return 0.0. You can override this default using the first parameter.
forceescape(value)
    Enforce HTML escaping. This will probably double escape variables.
format(value, *args, **kwargs)
    Apply python string formatting on an object:
    {{ "%s - %s"|format("Hello?", "Foo!") }}
        -> Hello? - Foo!
groupby(value, attribute)
    Group a sequence of objects by a common attribute.
    If you for example have a list of dicts or objects that represent persons with gender, first_name and last_name attributes and you want to group all users by genders you can do something like the following snippet:
    <ul>
    {% for group in persons|groupby('gender') %}
        <li>{{ group.grouper }}<ul>
        {% for person in group.list %}
            <li>{{ person.first_name }} {{ person.last_name }}</li>
        {% endfor %}</ul></li>
    {% endfor %}
    </ul>
    Additionally it’s possible to use tuple unpacking for the grouper and list:
    <ul>
    {% for grouper, list in persons|groupby('gender') %}
        ...
    {% endfor %}
    </ul>
    As you can see the item we’re grouping by is stored in the grouper attribute and the list contains all the objects that have this grouper in common.
    Changed in version 2.6: It’s now possible to use dotted notation to group by the child attribute of another attribute.
indent(s, width=4, first=False, blank=False, indentfirst=None)
    Return a copy of the string with each line indented by 4 spaces. The first line and blank lines are not indented by default.
    Parameters:	
        width – Number of spaces to indent by.
        first – Don’t skip indenting the first line.
        blank – Don’t skip indenting empty lines.
    Changed in version 2.10: Blank lines are not indented by default.
    Rename the indentfirst argument to first.
int(value, default=0, base=10)
    Convert the value into an integer. If the conversion doesn’t work it will return 0. You can override this default using the first parameter. You can also override the default base (10) in the second parameter, which handles input with prefixes such as 0b, 0o and 0x for bases 2, 8 and 16 respectively. The base is ignored for decimal numbers and non-string values.
join(value, d=u'', attribute=None)
    Return a string which is the concatenation of the strings in the sequence. The separator between elements is an empty string per default, you can define it with the optional parameter:
    {{ [1, 2, 3]|join('|') }}
        -> 1|2|3
    {{ [1, 2, 3]|join }}
        -> 123
    It is also possible to join certain attributes of an object:
    {{ users|join(', ', attribute='username') }}
    New in version 2.6: The attribute parameter was added.
last(seq)
    Return the last item of a sequence.
length(object)
    Return the number of items of a sequence or mapping.
    Aliases:	count
list(value)
    Convert the value into a list. If it was a string the returned list will be a list of characters.
lower(s)
    Convert a value to lowercase.
map()
    Applies a filter on a sequence of objects or looks up an attribute. 
    This is useful when dealing with lists of objects but you are really only interested in a certain value of it.
    The basic usage is mapping on an attribute. 
    Imagine you have a list of users but you are only interested in a list of usernames:
    Users on this page: {{ users|map(attribute='username')|join(', ') }}
    Alternatively you can let it invoke a filter by passing the name of the filter 
    and the arguments afterwards. A good example would be applying a text conversion filter on a sequence:
    Users on this page: {{ titles|map('lower')|join(', ') }}
max(value, case_sensitive=False, attribute=None)
    Return the largest item from the sequence.
    {{ [1, 2, 3]|max }}
        -> 3
    Parameters:	
        case_sensitive – Treat upper and lower case strings as distinct.
        attribute – Get the object with the max value of this attribute.
min(value, case_sensitive=False, attribute=None)
    Return the smallest item from the sequence.
    {{ [1, 2, 3]|min }}
        -> 1
    Parameters:	
        case_sensitive – Treat upper and lower case strings as distinct.
        attribute – Get the object with the max value of this attribute.
pprint(value, verbose=False)
    Pretty print a variable. Useful for debugging.
    With Jinja 1.2 onwards you can pass it a parameter. If this parameter is truthy the output will be more verbose (this requires pretty)
random(seq)
    Return a random item from the sequence.
reject()
    Filters a sequence of objects by applying a test to each object, and rejecting the objects with the test succeeding.
    If no test is specified, each object will be evaluated as a boolean.
    Example usage:
    {{ numbers|reject("odd") }}
    New in version 2.7.
rejectattr()
    Filters a sequence of objects by applying a test to the specified attribute of each object, and rejecting the objects with the test succeeding.
    If no test is specified, the attribute’s value will be evaluated as a boolean.
    {{ users|rejectattr("is_active") }}
    {{ users|rejectattr("email", "none") }}
    New in version 2.7.
replace(s, old, new, count=None)
    Return a copy of the value with all occurrences of a substring replaced with a new one. The first argument is the substring that should be replaced, the second is the replacement string. If the optional third argument count is given, only the first count occurrences are replaced:
    {{ "Hello World"|replace("Hello", "Goodbye") }}
        -> Goodbye World
    {{ "aaaaargh"|replace("a", "d'oh, ", 2) }}
        -> d'oh, d'oh, aaargh
reverse(value)
    Reverse the object or return an iterator that iterates over it the other way round.
round(value, precision=0, method='common')
    Round the number to a given precision. The first parameter specifies the precision (default is 0), the second the rounding method:
        'common' rounds either up or down
        'ceil' always rounds up
        'floor' always rounds down
    If you don’t specify a method 'common' is used.
    {{ 42.55|round }}
        -> 43.0
    {{ 42.55|round(1, 'floor') }}
        -> 42.5
    Note that even if rounded to 0 precision, a float is returned. If you need a real integer, pipe it through int:
    {{ 42.55|round|int }}
        -> 43
safe(value)
    Mark the value as safe which means that in an environment with automatic escaping enabled this variable will not be escaped.
select()
    Filters a sequence of objects by applying a test to each object, and only selecting the objects with the test succeeding.
    If no test is specified, each object will be evaluated as a boolean.
    Example usage:
    {{ numbers|select("odd") }}
    {{ numbers|select("odd") }}
    {{ numbers|select("divisibleby", 3) }}
    {{ numbers|select("lessthan", 42) }}
    {{ strings|select("equalto", "mystring") }}
    
selectattr()
    Filters a sequence of objects by applying a test to the specified attribute of each object, and only selecting the objects with the test succeeding.
    If no test is specified, the attribute’s value will be evaluated as a boolean.
    Example usage:
    {{ users|selectattr("is_active") }}
    {{ users|selectattr("email", "none") }}
    New in version 2.7.
slice(value, slices, fill_with=None)
    Slice an iterator and return a list of lists containing those items. Useful if you want to create a div containing three ul tags that represent columns:
    <div class="columwrapper">
      {%- for column in items|slice(3) %}
        <ul class="column-{{ loop.index }}">
        {%- for item in column %}
          <li>{{ item }}</li>
        {%- endfor %}
        </ul>
      {%- endfor %}
    </div>
    If you pass it a second argument it’s used to fill missing values on the last iteration.
sort(value, reverse=False, case_sensitive=False, attribute=None)
    Sort an iterable. Per default it sorts ascending, if you pass it true as first argument it will reverse the sorting.
    If the iterable is made of strings the third parameter can be used to control the case sensitiveness of the comparison which is disabled by default.
    {% for item in iterable|sort %}
        ...
    {% endfor %}
    It is also possible to sort by an attribute (for example to sort by the date of an object) by specifying the attribute parameter:
    {% for item in iterable|sort(attribute='date') %}
        ...
    {% endfor %}
    Changed in version 2.6: The attribute parameter was added.
string(object)
    Make a string unicode if it isn’t already. That way a markup string is not converted back to unicode.
striptags(value)
    Strip SGML/XML tags and replace adjacent whitespace by one space.
sum(iterable, attribute=None, start=0)
    Returns the sum of a sequence of numbers plus the value of parameter ‘start’ (which defaults to 0). When the sequence is empty it returns start.
    It is also possible to sum up only certain attributes:
    Total: {{ items|sum(attribute='price') }}
    Changed in version 2.6: The attribute parameter was added to allow suming up over attributes. Also the start parameter was moved on to the right.
title(s)
    Return a titlecased version of the value. I.e. words will start with uppercase letters, all remaining characters are lowercase.
tojson(value, indent=None)
    Dumps a structure to JSON so that it’s safe to use in <script> tags. It accepts the same arguments and returns a JSON string. Note that this is available in templates through the |tojson filter which will also mark the result as safe. Due to how this function escapes certain characters this is safe even if used outside of <script> tags.
    The following characters are escaped in strings:
        <
        >
        &
        '
    This makes it safe to embed such strings in any place in HTML with the notable exception of double quoted attributes. In that case single quote your attributes or HTML escape it in addition.
    The indent parameter can be used to enable pretty printing. Set it to the number of spaces that the structures should be indented with.
    Note that this filter is for use in HTML contexts only.
    New in version 2.9.
trim(value)
    Strip leading and trailing whitespace.
truncate(s, length=255, killwords=False, end='...', leeway=None)
    Return a truncated copy of the string. The length is specified with the first parameter which defaults to 255. If the second parameter is true the filter will cut the text at length. Otherwise it will discard the last word. If the text was in fact truncated it will append an ellipsis sign ("..."). If you want a different ellipsis sign than "..." you can specify it using the third parameter. Strings that only exceed the length by the tolerance margin given in the fourth parameter will not be truncated.
    {{ "foo bar baz qux"|truncate(9) }}
        -> "foo..."
    {{ "foo bar baz qux"|truncate(9, True) }}
        -> "foo ba..."
    {{ "foo bar baz qux"|truncate(11) }}
        -> "foo bar baz qux"
    {{ "foo bar baz qux"|truncate(11, False, '...', 0) }}
        -> "foo bar..."
    The default leeway on newer Jinja2 versions is 5 and was 0 before but can be reconfigured globally.
unique(value, case_sensitive=False, attribute=None)
    Returns a list of unique items from the the given iterable.
    {{ ['foo', 'bar', 'foobar', 'FooBar']|unique }}
        -> ['foo', 'bar', 'foobar']
    The unique items are yielded in the same order as their first occurrence in the iterable passed to the filter.
    Parameters:	
        case_sensitive – Treat upper and lower case strings as distinct.
        attribute – Filter objects with unique values for this attribute.
upper(s)
    Convert a value to uppercase.
urlencode(value)
    Escape strings for use in URLs (uses UTF-8 encoding). It accepts both dictionaries and regular strings as well as pairwise iterables.
    New in version 2.7.
urlize(value, trim_url_limit=None, nofollow=False, target=None, rel=None)
    Converts URLs in plain text into clickable links.
    If you pass the filter an additional integer it will shorten the urls to that number. Also a third argument exists that makes the urls “nofollow”:
    {{ mytext|urlize(40, true) }}
        links are shortened to 40 chars and defined with rel="nofollow"
    If target is specified, the target attribute will be added to the <a> tag:
    {{ mytext|urlize(40, target='_blank') }}
    Changed in version 2.8+: The target parameter was added.
wordcount(s)
    Count the words in that string.
wordwrap(s, width=79, break_long_words=True, wrapstring=None)
    Return a copy of the string passed to the filter wrapped after 79 characters. You can override this default using the first parameter. If you set the second parameter to false Jinja will not split words apart if they are longer than width. By default, the newlines will be the default newlines for the environment, but this can be changed using the wrapstring keyword argument.
    New in version 2.7: Added support for the wrapstring parameter.
xmlattr(d, autospace=True)
    Create an SGML/XML attribute string based on the items in a dict. All values that are neither none nor undefined are automatically escaped:
    <ul{{ {'class': 'my_list', 'missing': none,
            'id': 'list-%d'|format(variable)}|xmlattr }}>
    ...
    </ul>
    Results in something like this:
    <ul class="my_list" id="list-42">
    ...
    </ul>
    As you can see it automatically prepends a space in front of the item if the filter returned something unless the second parameter is false.
    
    


###jinja2 - Tests
#Tests in Jinja are a way of evaluating template expressions and returning True or False. 
#Jinja tests are used for comparisons, whereas filters are used for data manipulation, 

#tests always execute on the Ansible controller, not on the target of a task, as they test local data.

##Test syntax
#The syntax for using a jinja test is as follows:

variable is test_name

#Such as:
result is failed

##Testing strings
#To match strings against a substring or a regex, use the match or search filter:
#match requires a complete match in the string, while search only requires matching a subset of the string.

vars:
  url: "http://example.com/users/foo/resources/bar"

tasks:
    - debug:
        msg: "matched pattern 1"
      when: url is match("http://example.com/users/.*/resources/.*")

    - debug:
        msg: "matched pattern 2"
      when: url is search("/users/.*/resources/.*")

    - debug:
        msg: "matched pattern 3"
      when: url is search("/users/")

##Version Comparison
#In 2.5 version_compare was renamed to version

{{ ansible_facts['distribution_version'] is version('12.04', '>=') }}

#The version test accepts the following operators:
<, lt, <=, le, >, gt, >=, ge, ==, =, eq, !=, <>, ne

#This test also accepts a 3rd parameter,
#strict which defines if strict version parsing should be used. 
#The default is False, but this setting as True uses more strict version parsing:

{{ sample_version_var is version('1.0', operator='lt', strict=True) }}


##Set theory tests
#In 2.5 issubset and issuperset were renamed to subset and superset

#To see if a list includes or is included by another list, you can use subset and superset:
vars:
    a: [1,2,3,4,5]
    b: [2,3]
tasks:
    - debug:
        msg: "A includes B"
      when: a is superset(b)

    - debug:
        msg: "B is included in A"
      when: b is subset(a)

#use 'any' and 'all' to check if any or all elements in a list are true or not:

vars:
  mylist:
      - 1
      - "{{ 3 == 3 }}"
      - True
  myotherlist:
      - False
      - True
tasks:

  - debug:
      msg: "all are true!"
    when: mylist is all

  - debug:
      msg: "at least one is true"
    when: myotherlist is any

    
    
##Testing paths
#In 2.5 the following tests were renamed to remove the is_ prefix

#The following tests can provide information about a path on the controller:

- debug:
    msg: "path is a directory"
  when: mypath is directory

- debug:
    msg: "path is a file"
  when: mypath is file

- debug:
    msg: "path is a symlink"
  when: mypath is link

- debug:
    msg: "path already exists"
  when: mypath is exists

- debug:
    msg: "path is {{ (mypath is abs)|ternary('absolute','relative')}}"

- debug:
    msg: "path is the same file as path2"
  when: mypath is same_file(path2)

- debug:
    msg: "path is a mount"
  when: mypath is mount

##Task results
#to check the status of tasks:

tasks:

  - shell: /usr/bin/foo
    register: result
    ignore_errors: True

  - debug:
      msg: "it failed"
    when: result is failed

  # in most cases you'll want a handler, but if you want to do something right now, this is nice
  - debug:
      msg: "it changed"
    when: result is changed

  - debug:
      msg: "it succeeded in Ansible >= 2.1"
    when: result is succeeded

  - debug:
      msg: "it succeeded"
    when: result is success

  - debug:
      msg: "it was skipped"
    when: result is skipped


    

    
##jinja2 builtin tests 
callable(object)
    Return whether the object is callable (i.e., some kind of function). 
    Note that classes are callable, as are instances with a __call__() method.
defined(value)
    Return true if the variable is defined:
    {% if variable is defined %}
        value of variable: {{ variable }}
    {% else %}
        variable is not defined
    {% endif %}
    See the default() filter for a simple way to set undefined variables.
divisibleby(value, num)
    Check if a variable is divisible by a number.
eq(a, b)
    Aliases:	==, equalto
escaped(value)
    Check if the value is escaped.
even(value)
    Return true if the variable is even.
ge(a, b)
    Aliases:	>=
gt(a, b)
    Aliases:	>, greaterthan
in(value, seq)
    Check if value is in seq.
    New in version 2.10.
iterable(value)
    Check if it’s possible to iterate over an object.
le(a, b)
    Aliases:	<=
lower(value)
    Return true if the variable is lowercased.
lt(a, b)
    Aliases:	<, lessthan
mapping(value)
    Return true if the object is a mapping (dict etc.).
    New in version 2.6.
ne(a, b)
    Aliases:	!=
none(value)
    Return true if the variable is none.
number(value)
    Return true if the variable is a number.
odd(value)
    Return true if the variable is odd.
sameas(value, other)
    Check if an object points to the same memory address than another object:
    {% if foo.attribute is sameas false %}
        the foo attribute really is the `False` singleton
    {% endif %}
sequence(value)
    Return true if the variable is a sequence. Sequences are variables that are iterable.
string(value)
    Return true if the object is a string.
undefined(value)
    Like defined() but the other way round.
upper(value)
    Return true if the variable is uppercased.
    
    
##jinja2 - List of Global Functions
range([start, ]stop[, step])
    Return a list containing an arithmetic progression of integers. range(i, j) returns [i, i+1, i+2, ..., j-1]; start (!) defaults to 0. When step is given, it specifies the increment (or decrement). For example, range(4) and range(0, 4, 1) return [0, 1, 2, 3]. The end point is omitted! These are exactly the valid indices for a list of 4 elements.
    This is useful to repeat a template block multiple times, e.g. to fill a list. Imagine you have 7 users in the list but you want to render three empty items to enforce a height with CSS:
    <ul>
    {% for user in users %}
        <li>{{ user.username }}</li>
    {% endfor %}
    {% for number in range(10 - users|count) %}
        <li class="empty"><span>...</span></li>
    {% endfor %}
    </ul>
lipsum(n=5, html=True, min=20, max=100)
    Generates some lorem ipsum for the template. By default, five paragraphs of HTML are generated with each paragraph between 20 and 100 words. If html is False, regular text is returned. This is useful to generate simple contents for layout testing.
dict(**items)
    A convenient alternative to dict literals. {'foo': 'bar'} is the same as dict(foo='bar').
class cycler(*items)
    The cycler allows you to cycle among values similar to how loop.cycle works. Unlike loop.cycle, you can use this cycler outside of loops or over multiple loops.
    This can be very useful if you want to show a list of folders and files with the folders on top but both in the same list with alternating row colors.
    The following example shows how cycler can be used:
    {% set row_class = cycler('odd', 'even') %}
    <ul class="browser">
    {% for folder in folders %}
      <li class="folder {{ row_class.next() }}">{{ folder|e }}</li>
    {% endfor %}
    {% for filename in files %}
      <li class="file {{ row_class.next() }}">{{ filename|e }}</li>
    {% endfor %}
    </ul>
    A cycler has the following attributes and methods:
    reset()
        Resets the cycle to the first item.
    next()
        Goes one item ahead and returns the then-current item.
    current
        Returns the current item.
class joiner(sep=', ')
    A tiny helper that can be used to “join” multiple sections. A joiner is passed a string and will return that string every time it’s called, except the first time (in which case it returns an empty string). You can use this to join things:
    {% set pipe = joiner("|") %}
    {% if categories %} {{ pipe() }}
        Categories: {{ categories|join(", ") }}
    {% endif %}
    {% if author %} {{ pipe() }}
        Author: {{ author() }}
    {% endif %}
    {% if can_edit %} {{ pipe() }}
        <a href="?action=edit">Edit</a>
    {% endif %}
class namespace(...)
    Creates a new container that allows attribute assignment using the {% set %} tag:
    {% set ns = namespace() %}
    {% set ns.foo = 'bar' %}
    The main purpose of this is to allow carrying a value from within a loop body to an outer scope. Initial values can be provided as a dict, as keyword arguments, or both (same behavior as Python’s dict constructor):
    {% set ns = namespace(found=false) %}
    {% for item in items %}
        {% if item.check_something() %}
            {% set ns.found = true %}
        {% endif %}
        * {{ item.title }}
    {% endfor %}
    Found item having something: {{ ns.found }}
      

###Conditionals


##The When Statement
#contains a raw Jinja2 expression without double curly braces 

tasks:
  - name: "shut down Debian flavored systems"
    command: /sbin/shutdown -t now
    when: ansible_facts['os_family'] == "Debian"
    # note that all variables can be directly in conditionals without double curly braces

#You can also use parentheses to group conditions:

tasks:
  - name: "shut down CentOS 6 and Debian 7 systems"
    command: /sbin/shutdown -t now
    when: (ansible_facts['distribution'] == "CentOS" and ansible_facts['distribution_major_version'] == "6") or
          (ansible_facts['distribution'] == "Debian" and ansible_facts['distribution_major_version'] == "7")

#Multiple conditions that all need to be true (a logical 'and') can also be specified as a list:

tasks:
  - name: "shut down CentOS 6 systems"
    command: /sbin/shutdown -t now
    when:
      - ansible_facts['distribution'] == "CentOS"
      - ansible_facts['distribution_major_version'] == "6"

#A number of Jinja2 "tests" and "filters" can also be used in when statements, 
#some of which are unique and provided by Ansible. 

#Suppose we want to ignore the error of one statement 
#and then decide to do something conditionally based on success or failure:
#both success and succeeded work (fail/failed, etc).

tasks:
  - command: /bin/false
    register: result
    ignore_errors: True

  - command: /bin/something
    when: result is failed

  # In older versions of ansible use ``success``, now both are valid but succeeded uses the correct tense.
  - command: /bin/something_else
    when: result is succeeded

  - command: /bin/still/something_else
    when: result is skipped

#To see what facts are available on a particular system
- debug: var=ansible_facts

#to do a math operation comparison on on a string , use int filter 

tasks:
  - shell: echo "only on Red Hat 6, derivatives, and later"
    when: ansible_facts['os_family'] == "RedHat" and ansible_facts['lsb']['major_release']|int >= 6

##Variables defined in the playbooks or inventory can also be used. 
#An example may be the execution of a task based on a variable’s boolean value:

vars:
  epic: true

#Then a conditional execution might look like:

tasks:
    - shell: echo "This certainly is epic!"
      when: epic

#or:

tasks:
    - shell: echo "This certainly isn't epic!"
      when: not epic

#If a required variable has not been set, 
#you can skip or fail using Jinja2’s defined test

tasks:
    - shell: echo "I've got '{{ foo }}' and am not afraid to use it!"
      when: foo is defined

    - fail: msg="Bailing out. this play requires 'bar'"
      when: bar is undefined

      
##Loops and Conditionals

#Combining when with loops 
#be aware that the when statement is processed separately for each item. This is by design:

tasks:
    - command: echo {{ item }}
      loop: [ 0, 2, 4, 6, 8, 10 ]
      when: item > 5

#If you need to skip the whole task depending on the loop variable being defined, 
#used the |default filter to provide an empty iterator:

- command: echo {{ item }}
  loop: "{{ mylist|default([]) }}"
  when: item > 5

#If using a dict in a loop:

- command: echo {{ item.key }}
  loop: "{{ query('dict', mydict|default({})) }}"
  when: item.value > 5

  
##Loading in Custom Facts
#To run them, just make a call to your own custom fact gathering module 
#at the top of list of tasks, and variables returned there will be accessible to future tasks:

tasks:
    - name: gather site specific fact data
      action: site_facts
    - command: /usr/bin/thingy
      when: my_custom_fact_just_retrieved_from_the_remote_system == '1234'

      
      
##Applying 'when' to roles, imports, and includes
#if you have several tasks that all share the same conditional statement, 
#affix the conditional to a task include statement as below.
#All the tasks get evaluated, but the conditional is applied to each and every task:

- import_tasks: tasks/sometasks.yml
  when: "'reticulating splines' in output"

#Or with a role:

- hosts: webservers
  roles:
     - role: debian_stock_config
       when: ansible_facts['os_family'] == 'Debian'

#You will note a lot of 'skipped' output by default in Ansible 
#when using this approach on systems that don't match the criteria. 

#In many cases the group_by module can be a more streamlined way to accomplish the same thing


#When a conditional is used with include_* tasks instead of imports, 
#it is applied only to the include task itself and not to any other tasks within the included file(s). 
#A common situation where this distinction is important is as follows:

# We wish to include a file to define a variable when it is not
# already defined

# main.yml
- import_tasks: other_tasks.yml # note "import"
  when: x is not defined

# other_tasks.yml
- set_fact:
    x: foo
- debug:
    var: x

#This expands at include time to the equivalent of:

- set_fact:
    x: foo
  when: x is not defined
- debug:
    var: x
  when: x is not defined

  
  
##Conditional Imports
#To do certain things differently in a playbook based on certain criteria. 
#Having one playbook that works on multiple platforms and OS versions is a good example.

#As an example, the name of the Apache package may be different between CentOS and Debian, 
#but it is easily handled with a minimum of syntax in an Ansible Playbook:
#The variable "ansible_facts['os_family']" is being interpolated into the list of filenames being defined for vars_files.

---
- hosts: all
  remote_user: root
  vars_files:
    - "vars/common.yml"
    - [ "vars/{{ ansible_facts['os_family'] }}.yml", "vars/os_defaults.yml" ]
  tasks:
  - name: make sure apache is started
    service: name={{ apache }} state=started


#YAML files contain just keys and values:

---
# for vars/RedHat.yml
apache: httpd
somethingelse: 42



##Selecting Files And Templates Based On Variables
#To copy, or a template you will use may depend on a variable. 

#The following construct selects the first available file appropriate 
#for the variables of a given host
#The following example shows how to template out a configuration file 
#that was very different between, say, CentOS and Debian:

#query and lookup are same, query returns list 
#first_found – return first file found from list

- name: template a file
  template:
      src: "{{ item }}"
      dest: /etc/myapp/foo.conf
  loop: "{{ query('first_found', { 'files': myfiles, 'paths': mypaths}) }}"
  vars:
    myfiles:
      - "{{ansible_facts['distribution']}}.conf"
      -  default.conf
    mypaths: ['search_location_one/somedir/', '/opt/other_location/somedir/']

    
##Register Variables
#The 'register' keyword decides what variable to save a result in. 
#The resulting variables can be used in templates, action lines, or when statements. 

- name: test play
  hosts: all

  tasks:

      - shell: cat /etc/motd
        register: motd_contents

      - shell: echo "motd contains the word hi"
        when: motd_contents.stdout.find('hi') != -1

#the registered variable's string contents are accessible with the 'stdout' value. 
#The registered result can be used in the loop of a task 
#if it is converted into a list (or already is a list) as shown below. 

#"stdout_lines" is already available on the object as well 
#though you could also call "home_dirs.stdout.split()" if you wanted, 
#and could split by other fields:

- name: registered variable usage as a loop list
  hosts: all
  tasks:

    - name: retrieve the list of home directories
      command: ls /home
      register: home_dirs

    - name: add home dirs to the backup spooler
      file:
        path: /mnt/bkspool/{{ item }}
        src: /home/{{ item }}
        state: link
      loop: "{{ home_dirs.stdout_lines }}"
      # same as loop: "{{ home_dirs.stdout.split() }}"

#the registered variable's string contents are accessible with the 'stdout' value. 
#You may check the registered variable's string contents for emptiness:

- name: check registered variable for emptiness
  hosts: all

  tasks:

      - name: list contents of directory
        command: ls mydir
        register: contents

      - name: check contents for emptiness
        debug:
          msg: "Directory is empty"
        when: contents.stdout == ""

##Commonly Used Facts

#The following Facts are frequently used in Conditionals 
ansible_facts['distribution']
    Possible values (sample, not complete list):
        Alpine
        Altlinux
        Amazon
        Archlinux
        ClearLinux
        Coreos
        Debian
        Fedora
        Gentoo
        Mandriva
        NA
        OpenWrt
        OracleLinux
        RedHat
        Slackware
        SMGL
        SUSE
        VMwareESX

ansible_facts['distribution_major_version']
    This will be the major version of the operating system. 
    For example, the value will be 16 for Ubuntu 16.04.
ansible_facts['os_family']
    Possible values (sample, not complete list):
        AIX
        Alpine
        Altlinux
        Archlinux
        Darwin
        Debian
        FreeBSD
        Gentoo
        HP-UX
        Mandrake
        RedHat
        SGML
        Slackware
        Solaris
        Suse

        
        
        
###Loops

#Before 2.5 Ansible mainly used the with_<lookup> keywords to create loops, 
#the loop keyword is basically analogous to with_list.

##Standard Loops
- name: add several users
  user:
    name: "{{ item }}"
    state: present
    groups: "wheel"
  loop:
     - testuser1
     - testuser2

#Or with  a YAML list in variables file, or in the 'vars' section
loop: "{{ somelist }}"

#The above would be the equivalent of:

- name: add user testuser1
  user:
    name: "testuser1"
    state: present
    groups: "wheel"
- name: add user testuser2
  user:
    name: "testuser2"
    state: present
    groups: "wheel"

#Some plugins like, the yum and apt modules can take lists directly to their options, 
#this is more optimal than looping over the task. 
- name: optimal yum
  yum:
    name: "{{list_of_packages}}"
    state: present

- name: non optimal yum, not only slower but might cause issues with interdependencies
  yum:
    name: "{{item}}"
    state: present
  loop: "{{list_of_packages}}"

#Note that the types of items you iterate over do not have to be simple lists of strings. 
#If you have a list of hashes, you can reference subkeys using things like:

- name: add several users
  user:
    name: "{{ item.name }}"
    state: present
    groups: "{{ item.groups }}"
  loop:
    - { name: 'testuser1', groups: 'wheel' }
    - { name: 'testuser2', groups: 'root' }

#when combining Conditionals with a loop, 
#the when: statement is processed separately for each item. 


##To loop over a dict, use the dict2items Dict Filter:

- name: create a tag dictionary of non-empty tags
  set_fact:
    tags_dict: "{{ (tags_dict|default({}))|combine({item.key: item.value}) }}"
  loop: "{{ tags|dict2items }}"
  vars:
    tags:
      Environment: dev
      Application: payment
      Another: "{{ doesnotexist|default() }}"
  when: item.value != ""


##Complex loops
#use Jinja2 expressions to create complex lists: 
#For example, using the 'nested' lookup, you can combine lists:
#product is cartesian product 

- name: give users access to multiple databases
  mysql_user:
    name: "{{ item[0] }}"
    priv: "{{ item[1] }}.*:ALL"
    append_privs: yes
    password: "foo"
  loop: "{{ ['alice', 'bob'] |product(['clientdb', 'employeedb', 'providerdb'])|list }}"

##Using lookup vs query with loop
#In Ansible 2.5 a new jinja2 function was introduced named query, 
#query provides a simpler interface and a more predictable output from lookup plugins, ensuring better compatibility with loop.

#In certain situations the lookup function may not return a list which loop requires.
#But query always returns list (equiavlent to lookup with wantList=True )

loop: "{{ query('inventory_hostnames', 'all') }}"
#OR 
loop: "{{ lookup('inventory_hostnames', 'all', wantlist=True) }}"



##Do-Until Loops
#To retry a task until a certain condition is met
#The task returns the results returned by the last task run. 
#The results of individual retries can be viewed by -vv option. 
#The registered variable will also have a new key "attempts" 
#which will have the number of the retries for the task.

- shell: /usr/bin/foo
  register: result
  until: result.stdout.find("all systems go") != -1
  retries: 5
  delay: 10



##Using register with a loop
#After using register with a loop, 
#the data structure placed in the variable will contain a 'results' attribute 
#that is a list of all responses from the module.


- shell: "echo {{ item }}"
  loop:
    - "one"
    - "two"
  register: echo

#This differs from the data structure returned when using register without a loop:

{
    "changed": true,
    "msg": "All items completed",
    "results": [
        {
            "changed": true,
            "cmd": "echo \"one\" ",
            "delta": "0:00:00.003110",
            "end": "2013-12-19 12:00:05.187153",
            "invocation": {
                "module_args": "echo \"one\"",
                "module_name": "shell"
            },
            "item": "one",
            "rc": 0,
            "start": "2013-12-19 12:00:05.184043",
            "stderr": "",
            "stdout": "one"
        },
        {
            "changed": true,
            "cmd": "echo \"two\" ",
            "delta": "0:00:00.002920",
            "end": "2013-12-19 12:00:05.245502",
            "invocation": {
                "module_args": "echo \"two\"",
                "module_name": "shell"
            },
            "item": "two",
            "rc": 0,
            "start": "2013-12-19 12:00:05.242582",
            "stderr": "",
            "stdout": "two"
        }#
    ]
}

#Subsequent loops over the registered variable to inspect the results may look like:
- name: Fail if return code is not 0
  fail:
    msg: "The command ({{ item.cmd }}) did not have a 0 return code"
  when: item.rc != 0
  loop: "{{ echo.results }}"

#During iteration, the result of the current item will be placed in that variable:

- shell: echo "{{ item }}"
  loop:
    - one
    - two
  register: echo
  changed_when: echo.stdout != "one"

##Looping over the inventory
#To loop over the inventory, or just a subset of it, there are multiple ways. 

#One can use a regular loop with the ansible_play_batch or groups variables

# show all the hosts in the inventory
- debug:
    msg: "{{ item }}"
  loop: "{{ groups['all'] }}"

# show all the hosts in the current play
- debug:
    msg: "{{ item }}"
  loop: "{{ ansible_play_batch }}"

#There is also a specific lookup plugin inventory_hostnames 
# show all the hosts in the inventory
- debug:
    msg: "{{ item }}"
  loop: "{{ query('inventory_hostnames', 'all') }}"

# show all the hosts matching the pattern, ie all but the group www
- debug:
    msg: "{{ item }}"
  loop: "{{ query('inventory_hostnames', 'all!www') }}"

  
  
##Loop Control
#In 2.0 you are able to use loops and task includes (but not playbook includes). 
#This adds the ability to loop over the set of tasks in one shot.

# Ansible by default sets the loop variable item for each loop, 
#which causes these nested loops to overwrite the value of item from the "outer" loops. 

#As of Ansible 2.1, the loop_control option can be used 
#to specify the name of the variable to be used for the loop:

# main.yml
- include_tasks: inner.yml
  loop:
    - 1
    - 2
    - 3
  loop_control:
    loop_var: outer_item

# inner.yml
- debug:
    msg: "outer item={{ outer_item }} inner item={{ item }}"
  loop:
    - a
    - b
    - c

#When using complex data structures for looping the display might get a bit too "busy",
#this is where the label directive comes to help:
#This will now display just the label field instead of the whole structure per item, 
#it defaults to {{ item }} to display things as usual.
- name: create servers
  digital_ocean:
    name: "{{ item.name }}"
    state: present
  loop:
    - name: server1
      disks: 3gb
      ram: 15Gb
      network:
        nic01: 100Gb
        nic02: 10Gb
        ...
  loop_control:
    label: "{{ item.name }}"



#Another option to loop control is pause, 
#which allows you to control the time (in seconds) between execution of items in a task loop.:

# main.yml
- name: create servers, pause 3s before creating next
  digital_ocean:
    name: "{{ item }}"
    state: present
  loop:
    - server1
    - server2
  loop_control:
    pause: 3

#If you need to keep track of where you are in a loop, 
#you can use the index_var option to loop control to specify a variable name to contain the current loop index.:

- name: count our fruit
  debug:
    msg: "{{ item }} with index {{ my_idx }}"
  loop:
    - apple
    - banana
    - pear
  loop_control:
    index_var: my_idx

    
    
##Migrating from with_X to loop
#the recommended way to perform loops is the use the new loop keyword 
#instead of with_X style loops.

##with_list
#with_list is directly replaced by loop.

- name: with_list
  debug:
    msg: "{{ item }}"
  with_list:
    - one
    - two

- name: with_list -> loop
  debug:
    msg: "{{ item }}"
  loop:
    - one
    - two

##with_items
#with_items is replaced by loop and the flatten filter.

- name: with_items
  debug:
    msg: "{{ item }}"
  with_items: "{{ items }}"

- name: with_items -> loop
  debug:
    msg: "{{ item }}"
  loop: "{{ items|flatten(levels=1) }}"

##with_indexed_items
#with_indexed_items is replaced by loop, the flatten filter and loop_control.index_var.

- name: with_indexed_items
  debug:
    msg: "{{ item.0 }} - {{ item.1 }}"
  with_indexed_items: "{{ items }}"

- name: with_indexed_items -> loop
  debug:
    msg: "{{ index }} - {{ item }}"
  loop: "{{ items|flatten(levels=1) }}"
  loop_control:
    index_var: index

##with_flattened
#with_flattened is replaced by loop and the flatten filter.

- name: with_flattened
  debug:
    msg: "{{ item }}"
  with_flattened: "{{ items }}"

- name: with_flattened -> loop
  debug:
    msg: "{{ item }}"
  loop: "{{ items|flatten }}"

##with_together
#with_together is replaced by loop and the zip filter.

- name: with_together
  debug:
    msg: "{{ item.0 }} - {{ item.1 }}"
  with_together:
    - "{{ list_one }}"
    - "{{ list_two }}"

- name: with_together -> loop
  debug:
    msg: "{{ item.0 }} - {{ item.1 }}"
  loop: "{{ list_one|zip(list_two)|list }}"

##with_dict
#with_dict can be substituted by loop and either the dictsort or dict2items filters.

- name: with_dict
  debug:
    msg: "{{ item.key }} - {{ item.value }}"
  with_dict: "{{ dictionary }}"

- name: with_dict -> loop (option 1)
  debug:
    msg: "{{ item.key }} - {{ item.value }}"
  loop: "{{ dictionary|dict2items }}"

- name: with_dict -> loop (option 2)
  debug:
    msg: "{{ item.0 }} - {{ item.1 }}"
  loop: "{{ dictionary|dictsort }}"

##with_sequence
#with_sequence is replaced by loop and the range function, and potentially the format filter.

- name: with_sequence
  debug:
    msg: "{{ item }}"
  with_sequence: start=0 end=4 stride=2 format=testuser%02x

- name: with_sequence -> loop
  debug:
    msg: "{{ 'testuser%02x' | format(item) }}"
  # range is exclusive of the end point
  loop: "{{ range(0, 4 + 1, 2)|list }}"

##with_subelements
#with_subelements is replaced by loop and the subelements filter.

- name: with_subelements
  debug:
    msg: "{{ item.0.name }} - {{ item.1 }}"
  with_subelements:
    - "{{ users }}"
    - mysql.hosts

- name: with_subelements -> loop
  debug:
    msg: "{{ item.0.name }} - {{ item.1 }}"
  loop: "{{ users|subelements('mysql.hosts') }}"

##with_nested/with_cartesian
#with_nested and with_cartesian are replaced by loop and the product filter.

- name: with_nested
  debug:
    msg: "{{ item.0 }} - {{ item.1 }}"
  with_nested:
    - "{{ list_one }}"
    - "{{ list_two }}"

- name: with_nested -> loop
  debug:
    msg: "{{ item.0 }} - {{ item.1 }}"
  loop: "{{ list_one|product(list_two)|list }}"

##with_random_choice
#with_random_choice is replaced by just use of the random filter, without need of loop.

- name: with_random_choice
  debug:
    msg: "{{ item }}"
  with_random_choice: "{{ my_list }}"

- name: with_random_choice -> loop (No loop is needed here)
  debug:
    msg: "{{ my_list|random }}"
  tags: random

  
  
###Blocks
#Blocks allow for logical grouping of tasks and in play error handling. 
#Most of what you can apply to a single task (with the exception of loops) 
#can be applied at the block level, 
#which also makes it much easier to set data or directives common to the tasks. 

#This does not mean the directive affects the block itself, 
#but is inherited by the tasks enclosed by a block. 
#i.e. a when will be applied to the tasks, not the block itself.

#each of the 3 tasks will be executed after appending the when condition 
#from the block and evaluating it in the task's context. 
#Also they inherit the privilege escalation directives enabling "become to root" 
#for all the enclosed tasks.
 tasks:
   - name: Install Apache
     block:
       - yum:
           name: "{{ item }}"
           state: installed
         with_items:
           - httpd
           - memcached
       - template:
           src: templates/src.j2
           dest: /etc/foo.conf
       - service:
           name: bar
           state: started
           enabled: True
     when: ansible_facts['distribution'] == 'CentOS'
     become: true
     become_user: root



##Error Handling
#Blocks also introduce the ability to handle errors in a way similar 
#to exceptions in most programming languages. 
#Blocks only deal with 'failed' status of a task. 
#A bad task definition, an undefined variable or an unreachable host are not rescuable errors.

#This will 'revert' the failed status of the task for the run 
#and the play will continue as if it had succeeded.
 tasks:
 - name: Handle the error
   block:
     - debug:
         msg: 'I execute normally'
     - name: i force a failure
       command: /bin/false
     - debug:
         msg: 'I never execute, due to the above task failing, :-('
   rescue:
     - debug:
         msg: 'I caught an error, can do stuff here to fix it, :-)'



##There is also an always section, that will run no matter what the task status is.

 - name: Always do X
   block:
     - debug:
         msg: 'I execute normally'
     - name: i force a failure
       command: /bin/false
     - debug:
         msg: 'I never execute :-('
   always:
     - debug:
         msg: "This always executes, :-)"

##They can be added 'all' together to do complex error handling
#The tasks in the block would execute normally, 
#if there is any error the rescue section would get executed 
#with whatever you need to do to recover from the previous error. 
#The always section runs no matter what previous error did or did not occur in the block and rescue sections. 
#It should be noted that the play continues if a rescue section completes successfully 
#as it 'erases' the error status (but not the reporting), 
#this means it won't trigger max_fail_percentage nor any_errors_fatal configurations 
#but will appear in the playbook statistics.

- name: Attempt and graceful roll back demo
  block:
    - debug:
        msg: 'I execute normally'
    - name: i force a failure
      command: /bin/false
    - debug:
        msg: 'I never execute, due to the above task failing, :-('
  rescue:
    - debug:
        msg: 'I caught an error'
    - name: i force a failure in middle of recovery! >:-)
      command: /bin/false
    - debug:
        msg: 'I also never execute :-('
  always:
    - debug:
        msg: "This always executes"


##Another example is how to run handlers after an error occurred :

 tasks:
   - name: Attempt and graceful roll back demo
     block:
       - debug:
           msg: 'I execute normally'
         notify: run me even after an error
       - command: /bin/false
     rescue:
       - name: make sure all handlers run
         meta: flush_handlers
 handlers:
    - name: run me even after an error
      debug:
        msg: 'This handler runs even on error'

##Ansible also provides a couple of variables for tasks in the rescue portion of a block:
ansible_failed_task
    The task that returned 'failed' and triggered the rescue. 
    For example, to get the name use ansible_failed_task.name.
ansible_failed_result
    The captured return result of the failed task that triggered the rescue. 
    This would equate to having used this var in the register keyword. 
    
 




###Prompts

#When running a playbook, you may wish to prompt the user for certain input, 
#and can do so with the 'vars_prompt' section.

---
- hosts: all
  remote_user: root

  vars:
    from: "camelot"

  vars_prompt:
    - name: "name"
      prompt: "what is your name?"
    - name: "quest"
      prompt: "what is your quest?"
    - name: "favcolor"
      prompt: "what is your favorite color?"

#Prompts for individual vars_prompt variables will be skipped for any variable 
#that is already defined through the command line --extra-vars option, 
#or when running from a non-interactive session (such as cron or Ansible Tower). 


#If you have a variable that changes infrequently, 
#it might make sense to provide a default value that can be overridden. 
#This can be accomplished using the default argument:

vars_prompt:

  - name: "release_version"
    prompt: "Product release version"
    default: "1.0"

#An alternative form of vars_prompt allows for hiding input from the user, 
#and may later support some other options, but otherwise works equivalently:

vars_prompt:

  - name: "some_password"
    prompt: "Enter password"
    private: yes

  - name: "release_version"
    prompt: "Product release version"
    private: no

#If Passlib is installed, vars_prompt can also encrypt the entered value so you can use it, 
#for instance, with the user module to define a password:

vars_prompt:

  - name: "my_password2"
    prompt: "Enter password2"
    private: yes
    encrypt: "sha512_crypt"
    confirm: yes
    salt_size: 7
#the only parameters accepted are 'salt' or 'salt_size'
#You can use any crypt scheme supported by 'Passlib':
des_crypt - DES Crypt
bsdi_crypt - BSDi Crypt
bigcrypt - BigCrypt
crypt16 - Crypt16
md5_crypt - MD5 Crypt
bcrypt - BCrypt
sha1_crypt - SHA-1 Crypt
sun_md5_crypt - Sun MD5 Crypt
sha256_crypt - SHA-256 Crypt
sha512_crypt - SHA-512 Crypt
apr_md5_crypt - Apache's MD5-Crypt variant
phpass - PHPass' Portable Hash
pbkdf2_digest - Generic PBKDF2 Hashes
cta_pbkdf2_sha1 - Cryptacular's PBKDF2 hash
dlitz_pbkdf2_sha1 - Dwayne Litzenberger's PBKDF2 hash
scram - SCRAM Hash
bsd_nthash - FreeBSD's MCF-compatible nthash encoding

#When Passlib is not installed the crypt library is used as fallback. 
bcrypt - BCrypt
md5_crypt - MD5 Crypt
sha256_crypt - SHA-256 Crypt
sha512_crypt - SHA-512 Crypt
    
    
    
###Tags
#If you have a large playbook, it may become useful to be able to run only a specific part of it 
#rather than running everything in the playbook. 

#Ansible supports a "tags:" attribute for this reason.

#When you execute a playbook, you can filter tasks based on tags in two ways:
1.On the command line, with the --tags or --skip-tags options
2.In Ansible configuration settings, with the TAGS_RUN and TAGS_SKIP options

#Tags can be applied to many structures in Ansible 
#example that tags two tasks with different tags:

tasks:
    - yum:
        name: "{{ item }}"
        state: installed
      loop:
         - httpd
         - memcached
      tags:
         - packages

    - template:
        src: templates/src.j2
        dest: /etc/foo.conf
      tags:
         - configuration

#If you wanted to just run the "configuration" and "packages" part of a very long playbook
ansible-playbook example.yml --tags "configuration,packages"

#On the other hand, if you want to run a playbook without certain tagged tasks
ansible-playbook example.yml --skip-tags "packages"



##Tag Reuse
#You can apply the same tag to more than one task. 
#When a play is run using the --tags command-line option, 
#all tasks with that tag name will be run.

---
# file: roles/common/tasks/main.yml

- name: be sure ntp is installed
  yum:
    name: ntp
    state: installed
  tags: ntp

- name: be sure ntp is configured
  template:
    src: ntp.conf.j2
    dest: /etc/ntp.conf
  notify:
    - restart ntpd
  tags: ntp

- name: be sure ntpd is running and enabled
  service:
    name: ntpd
    state: started
    enabled: yes
  tags: ntp

  
##Tag Inheritance
#Adding tags: to a play, 
#or to statically imported tasks and roles, adds those tags to all of the contained tasks. 

#This is referred to as tag inheritance. 
#Tag inheritance is not applicable to dynamic inclusions such as include_role and include_tasks.

#When you apply tags: attributes to structures other than tasks, 
#Ansible processes the tag attribute to apply ONLY to the tasks they contain. 

#This example tags all tasks in the two plays. 
#The first play has all its tasks tagged with 'bar', 
#and the second has all its tasks tagged with 'foo':

- hosts: all
  tags:
    - bar
  tasks:
    ...

- hosts: all
  tags: ['foo']
  tasks:
    ...

#You may also apply tags to the tasks imported by roles:
#All of these apply the specified tags to EACH task inside the play, imported file, or role, 
roles:
  - role: webserver
    vars:
      port: 5000
    tags: [ 'web', 'foo' ]

#And to import_role: and import_tasks: statements:

- import_role:
    name: myrole
  tags: [web,foo]

- import_tasks: foo.yml
  tags: [web,foo]


#Tags are applied down the dependency chain. 
#In order for a tag to be inherited to a dependent role's tasks, 
#the tag should be applied to the role declaration or static import, 
#not to all the tasks within the role.

#There is no way to 'import only these tags'; 

#Listing of tags 
ansible-playbook --list-tasks --list-tags


#The above information does not apply to include_tasks, include_roles, or other dynamic includes. 
#Tags applied to either of these only tag the include itself.

#To use tags with tasks and roles intended for dynamic inclusions, 
#all needed tasks should be explicitly tagged at the task level; 
#or block: may be used to tag more than one task at once. 
#The include itself should also be tagged.

- hosts: all
  tasks:
  - include_role:
      name: myrole
    tags: mytag

#Role tasks file:

- block:
    - name: First task to run
    ...
    - name: Second task to run
    ...
  tags:
    - mytag


##Special Tags
#There is a special 'always' tag that will always run a task, 
#unless specifically skipped (--skip-tags always)

tasks:

    - debug:
        msg: "Always runs"
      tags:
        - always

    - debug:
        msg: "runs when you use tag1"
      tags:
        - tag1

#Another special tag is 'never', 
#which will prevent a task from running unless a tag is specifically requested.
#the task will only run when the debug or never tag is explicitly requested.
Example:

tasks:
  - debug: msg='{{ showmevar}}'
    tags: [ 'never', 'debug' ]



#There are another 3 special keywords for tags: 
tagged, untagged , all
#which run only tagged, only untagged and all tasks respectively.
#By default, Ansible runs as if '--tags all' had been specified.


###Using Vault in playbooks

#The "Vault" is a feature of Ansible that allows you to keep sensitive data such as passwords 
#or keys in encrypted files, rather than as plaintext in playbooks or roles. 

#These vault files can then be distributed or placed in source control.

#To enable this feature, a command line tool, ansible-vault is used to edit files, 
#and a command line flag --ask-vault-pass or --vault-password-file is used. 

#You can also modify your ansible.cfg file to specify the location of a password file 
#or configure Ansible to always prompt for the password. 

#These options require no command line flag usage.


##Running a Playbook With Vault

#To specify the vault-password interactively:
ansible-playbook site.yml --ask-vault-pass

#This prompt will then be used to decrypt (in memory only) 
#any vault encrypted files that are accessed. 
#Currently this requires that all files be encrypted with the same password.

#Alternatively, passwords can be specified with a file or a script 
#(the script version will require Ansible 1.7 or later). 

#When using this flag, ensure permissions on the file are 
#such that no one else can access your key and do not add your key to source control:
ansible-playbook site.yml --vault-password-file ~/.vault_pass.txt

ansible-playbook site.yml --vault-password-file ~/.vault_pass.py

#The password should be a string stored as a single line in the file.

#You can also set ANSIBLE_VAULT_PASSWORD_FILE environment variable, 
#e.g. ANSIBLE_VAULT_PASSWORD_FILE=~/.vault_pass.txt 
#and Ansible will automatically search for the password in that file.

#If you are using a script instead of a flat file, 
#ensure that it is marked as executable, and that the password is printed to standard output. 
#If your script needs to prompt for data, prompts can be sent to standard error.

#This is something you may wish to do if using Ansible from a continuous integration system like Jenkins.

#The --vault-password-file option can also be used with the ansible-pull command if you wish, 
#though this would require distributing the keys to your nodes, so understand the implications 
#– vault is more intended for push mode.


##Single Encrypted Variable
#As of version 2.3, Ansible can now use a vaulted variable 
#that lives in an otherwise 'clear text' YAML file:

notsecret: myvalue
mysecret: !vault |
          $ANSIBLE_VAULT;1.1;AES256
          66386439653236336462626566653063336164663966303231363934653561363964363833313662
          6431626536303530376336343832656537303632313433360a626438346336353331386135323734
          62656361653630373231613662633962316233633936396165386439616533353965373339616234
          3430613539666330390a313736323265656432366236633330313963326365653937323833366536
          34623731376664623134383463316265643436343438623266623965636363326136
other_plain_text: othervalue

#To create a vaulted variable, use 
ansible-vault encrypt_string 

#This vaulted variable will be decrypted with the supplied vault secret 
#and used as a normal variable. 
#The ansible-vault command line supports stdin and stdout for encrypting data on the fly, 


##What Can Be Encrypted With Vault

#Ansible Vault can encrypt any structured data file used by Ansible. 
#This can include "group_vars/" or "host_vars/" inventory variables, 
#variables loaded by "include_vars" or "vars_files", 
#or variable files passed on the ansible-playbook command line with -e @file.yml or -e @file.json. 

#Role variables and defaults are also included.
#Ansible tasks, handlers, and so on are also data so these can be encrypted with vault as well. 
#To hide the names of variables that you're using, you can encrypt the task files in their entirety.

#Ansible Vault can also encrypt arbitrary files, even binary files. 
#If a vault-encrypted file is given as the src argument to the copy, template, unarchive, script or assemble modules, 
#the file will be placed at the destination on the target host decrypted (assuming a valid vault password is supplied when running the play).



##Creating Encrypted Files

#To create a new encrypted data file, run the following command:
ansible-vault create foo.yml

#First you will be prompted for a password. 
#The password used with vault currently must be the same for all files you wish to use together at the same time.

#After providing a password, 
#the tool will launch whatever editor you have defined with $EDITOR, and defaults to vi 
#(before 2.1 the default was vim). 
#Once you are done with the editor session, the file will be saved as encrypted data.

#The default cipher is AES (which is shared-secret based).


##Editing Encrypted Files
ansible-vault edit foo.yml

##Rekeying Encrypted Files
#Should you wish to change your password on a vault-encrypted file or files, 
#you can do so with the rekey command:

ansible-vault rekey foo.yml bar.yml baz.yml

#This command can rekey multiple data files at once 
#and will ask for the original password and also the new password.


##Encrypting Unencrypted Files
ansible-vault encrypt foo.yml bar.yml baz.yml

##Decrypting Encrypted Files
ansible-vault decrypt foo.yml bar.yml baz.yml

##Viewing Encrypted Files
ansible-vault view foo.yml bar.yml baz.yml

##Use encrypt_string to create encrypted variables to embed in yaml

#The ansible-vault encrypt_string command will encrypt 
#and format a provided string into a format that can be included in ansible-playbook YAML files.

#To encrypt a string provided as a cli arg:

ansible-vault encrypt_string --vault-id a_password_file 'foobar' --name 'the_secret'

#Result:

the_secret: !vault |
      $ANSIBLE_VAULT;1.1;AES256
      62313365396662343061393464336163383764373764613633653634306231386433626436623361
      6134333665353966363534333632666535333761666131620a663537646436643839616531643561
      63396265333966386166373632626539326166353965363262633030333630313338646335303630
      3438626666666137650a353638643435666633633964366338633066623234616432373231333331
      6564

#To use a vault-id label for 'dev' vault-id:

ansible-vault encrypt_string --vault-id dev@password 'foooodev' --name 'the_dev_secret'

#Result:

the_dev_secret: !vault |
          $ANSIBLE_VAULT;1.2;AES256;dev
          30613233633461343837653833666333643061636561303338373661313838333565653635353162
          3263363434623733343538653462613064333634333464660a663633623939393439316636633863
          61636237636537333938306331383339353265363239643939666639386530626330633337633833
          6664656334373166630a363736393262666465663432613932613036303963343263623137386239
          6330

#To encrypt a string read from stdin and name it 'db_password':

echo -n 'letmein' | ansible-vault encrypt_string --vault-id dev@password --stdin-name 'db_password'

#Result:

Reading plaintext input from stdin. (ctrl-d to end input)
db_password: !vault |
          $ANSIBLE_VAULT;1.2;AES256;dev
          61323931353866666336306139373937316366366138656131323863373866376666353364373761
          3539633234313836346435323766306164626134376564330a373530313635343535343133316133
          36643666306434616266376434363239346433643238336464643566386135356334303736353136
          6565633133366366360a326566323363363936613664616364623437336130623133343530333739
          3039

#To be prompted for a string to encrypt, encrypt it, and give it the name 'new_user_password':

ansible-vault encrypt_string --vault-id dev@./password --stdin-name 'new_user_password'

#Output:

Reading plaintext input from stdin. (ctrl-d to end input)

#User enters 'hunter2' and hits ctrl-d.

#Result:

new_user_password: !vault |
          $ANSIBLE_VAULT;1.2;AES256;dev
          37636561366636643464376336303466613062633537323632306566653533383833366462366662
          6565353063303065303831323539656138653863353230620a653638643639333133306331336365
          62373737623337616130386137373461306535383538373162316263386165376131623631323434
          3866363862363335620a376466656164383032633338306162326639643635663936623939666238
          3161


##Vault Ids and Multiple Vault Passwords
#A vault id is an identifier for one or more vault secrets. 
#Since Ansible 2.4, Ansible supports multiple vault passwords. 
#Vault ids is a way to provide a label for a particular vault password.

#Vault encrypted content can specify which vault id it was encrypted with.

#Prior to Ansible 2.4, only one vault password could be used at a time. 
##so any vault files or vars that needed to be decrypted all had to use the same password.

#Since Ansible 2.4, vault files or vars that are encrypted with different passwords 
#can be used at the same time.

#For example, a playbook can now include a vars file encrypted with a 'dev' vault id 
#and a 'prod' vault id.


##Providing Vault Passwords
#to use a password store in the text file /path/to/my/vault-password-file:

ansible-playbook --vault-id /path/to/my/vault-password-file site.yml

#To prompt for a password:

ansible-playbook --vault-id @prompt site.yml

#To get the password from a vault password executable script my-vault-password.py:

ansible-playbook --vault-id my-vault-password.py

#The value for --vault-id can specify the type of vault id (prompt, a file path, etc) 
#and a label for the vault id ('dev', 'prod', 'cloud', etc)

#For example, to use a password file dev-password for the vault-id 'dev':

ansible-playbook --vault-id dev@dev-password site.yml

#To prompt for the 'dev' vault id:

ansible-playbook --vault-id dev@prompt site.yml

##Prior to Ansible 2.4

#To be prompted for a vault password, use the --ask-vault-pass cli option:

ansible-playbook --ask-vault-pass site.yml

##To specify a vault password in a text file 'dev-password', use the --vault-password-file option:

ansible-playbook --vault-password-file dev-password site.yml

#There is a config option (DEFAULT_VAULT_PASSWORD_FILE) to specify a vault password file 
#to use without requiring the --vault-password-file cli option.


##Multiple vault passwords
# --vault-id can be provided multiple times.

#If multiple vault passwords are provided, by default Ansible will attempt 
#to decrypt vault content by trying each vault secret in the order 
#they were provided on the command line.

#For example, to use a 'dev' password read from a file 
#and to be prompted for the 'prod' password:

ansible-playbook --vault-id dev@dev-password --vault-id prod@prompt site.yml

#In the above case, the 'dev' password will be tried first, 
#then the 'prod' password for cases where Ansible doesn't know which vault id is used to encrypt something.

#If the vault content was encrypted using a --vault-id option, then the label of the vault id is stored with the vault content. 
#When Ansible knows the right vault-id, it will try the matching vault id's secret first before trying the rest of the vault-ids.

#There is a config option (DEFAULT_VAULT_ID_MATCH ) to force the vault content's vault id label to match with one of the provided vault ids. 
#But the default is to try the matching id first, then try the other vault ids in order.

#There is also a config option (DEFAULT_VAULT_IDENTITY_LIST) 
#to specify a default list of vault ids to use. 

#For example, instead of requiring the cli option on every use, 
#the (DEFAULT_VAULT_IDENTITY_LIST) config option can be used:

ansible-playbook --vault-id dev@dev-password --vault-id prod@prompt site.yml

#The --vault-id can be used in lieu of the --vault-password-file 
#or --ask-vault-pass options, or it can be used in combination with them.

#When using ansible-vault commands that encrypt content (ansible-vault encrypt, ansible-vault encrypt_string, etc) 
#only one vault-id can be used.


##Speeding Up Vault Operations
#By default, Ansible uses PyCrypto to encrypt and decrypt vault files. 
#If you have many encrypted files, decrypting them at startup may cause a perceptible delay. 
#To speed this up, install the cryptography package:

$ pip install cryptography


##Vault Format
#A vault encrypted file is a UTF-8 encoded txt file.

#The file format includes a newline terminated header.
$ANSIBLE_VAULT;1.1;AES256


###Start and Step

#Start-at-task
#If you want to start executing your playbook at a particular task, 
#you can do so with the --start-at-task option:

ansible-playbook playbook.yml --start-at-task="install packages"

##Step

#Playbooks can also be executed interactively with --step:

ansible-playbook playbook.yml --step

#This will cause ansible to stop on each task, and ask if it should execute that task. 
#Say you had a task called "configure ssh", the playbook run will stop and ask:

Perform task: configure ssh (y/n/c):

###Playbook Keywords - Play 
any_errors_fatal
    Force any un-handled task errors on any host to propagate to all hosts and end the play.
become
    Boolean that controls if privilege escalation is used or not on Task execution.
become_flags
    A string of flag(s) to pass to the privilege escalation program when become is True.
become_method
    Which method of privilege escalation to use (such as sudo or su).
become_user
    User that you 'become' after using privilege escalation. The remote/login user must have permissions to become this user.
check_mode
    A boolean that controls if a task is executed in 'check' mode
connection
    Allows you to change the connection plugin used for tasks to execute on the target.
debugger
    Enable debugging tasks based on state of the task result. See Playbook Debugger
diff
    Toggle to make tasks return 'diff' information or not.
environment
    A dictionary that gets converted into environment vars to be provided for the task upon execution.
fact_path
    Set the fact path option for the fact gathering plugin controlled by gather_facts.
force_handlers
    Will force notified handler execution for hosts even if they failed during the play. Will not trigger if the play itself fails.
gather_facts
    A boolean that controls if the play will automatically run the 'setup' task to gather facts for the hosts.
gather_subset
    Allows you to pass subset options to the fact gathering plugin controlled by gather_facts.
gather_timeout
    Allows you to set the timeout for the fact gathering plugin controlled by gather_facts.
handlers
    A section with tasks that are treated as handlers, these won't get executed normally, only when notified after each section of tasks is complete.
hosts
    A list of groups, hosts or host pattern that translates into a list of hosts that are the play's target.
ignore_errors
    Boolean that allows you to ignore task failures and continue with play. It does not affect connection errors.
ignore_unreachable
    Boolean that allows you to ignore unreachable hosts and continue with play. This does not affect other task errors (see ignore_errors) but is useful for groups of volatile/ephemeral hosts.
max_fail_percentage
    can be used to abort the run after a given percentage of hosts in the current batch has failed.
module_defaults
    Specifies default parameter values for modules.
name
    Identifier. Can be used for documentation, in or tasks/handlers.
no_log
    Boolean that controls information disclosure.
order
    Controls the sorting of hosts as they are used for executing the play. Possible values are inventory (default), sorted, reverse_sorted, reverse_inventory and shuffle.
port
    Used to override the default port used in a connection.
post_tasks
    A list of tasks to execute after the tasks section.
pre_tasks
    A list of tasks to execute before roles.
remote_user
    User used to log into the target via the connection plugin.
roles
    List of roles to be imported into the play
run_once
    Boolean that will bypass the host loop, forcing the task to attempt to execute on the first host available and afterwards apply any results and facts to all active hosts in the same batch.
serial
    Explicitly define how Ansible batches the execution of the current play on the play's target
strategy
    Allows you to choose the connection plugin to use for the play.
tags
    Tags applied to the task or included tasks, this allows selecting subsets of tasks from the command line.
tasks
    Main list of tasks to execute in the play, they run after roles and before post_tasks.
vars
    Dictionary/map of variables
vars_files
    List of files that contain vars to include in the play.
vars_prompt
    list of variables to prompt for.

###Playbook Keywords - Role
any_errors_fatal
    Force any un-handled task errors on any host to propagate to all hosts and end the play.
become
    Boolean that controls if privilege escalation is used or not on Task execution.
become_flags
    A string of flag(s) to pass to the privilege escalation program when become is True.
become_method
    Which method of privilege escalation to use (such as sudo or su).
become_user
    User that you 'become' after using privilege escalation. The remote/login user must have permissions to become this user.
check_mode
    A boolean that controls if a task is executed in 'check' mode
connection
    Allows you to change the connection plugin used for tasks to execute on the target.
debugger
    Enable debugging tasks based on state of the task result. See Playbook Debugger
delegate_facts
    Boolean that allows you to apply facts to a delegated host instead of inventory_hostname.
delegate_to
    Host to execute task instead of the target (inventory_hostname). Connection vars from the delegated host will also be used for the task.
diff
    Toggle to make tasks return 'diff' information or not.
environment
    A dictionary that gets converted into environment vars to be provided for the task upon execution.
ignore_errors
    Boolean that allows you to ignore task failures and continue with play. It does not affect connection errors.
ignore_unreachable
    Boolean that allows you to ignore unreachable hosts and continue with play. This does not affect other task errors (see ignore_errors) but is useful for groups of volatile/ephemeral hosts.
module_defaults
    Specifies default parameter values for modules.
name
    Identifier. Can be used for documentation, in or tasks/handlers.
no_log
    Boolean that controls information disclosure.
port
    Used to override the default port used in a connection.
remote_user
    User used to log into the target via the connection plugin.
run_once
    Boolean that will bypass the host loop, forcing the task to attempt to execute on the first host available and afterwards apply any results and facts to all active hosts in the same batch.
tags
    Tags applied to the task or included tasks, this allows selecting subsets of tasks from the command line.
vars
    Dictionary/map of variables
when
    Conditional expression, determines if an iteration of a task is run or not.

###Playbook Keywords - Block
always
    List of tasks, in a block, that execute no matter if there is an error in the block or not.
any_errors_fatal
    Force any un-handled task errors on any host to propagate to all hosts and end the play.
become
    Boolean that controls if privilege escalation is used or not on Task execution.
become_flags
    A string of flag(s) to pass to the privilege escalation program when become is True.
become_method
    Which method of privilege escalation to use (such as sudo or su).
become_user
    User that you 'become' after using privilege escalation. The remote/login user must have permissions to become this user.
block
    List of tasks in a block.
check_mode
    A boolean that controls if a task is executed in 'check' mode
connection
    Allows you to change the connection plugin used for tasks to execute on the target.
debugger
    Enable debugging tasks based on state of the task result. See Playbook Debugger
delegate_facts
    Boolean that allows you to apply facts to a delegated host instead of inventory_hostname.
delegate_to
    Host to execute task instead of the target (inventory_hostname). Connection vars from the delegated host will also be used for the task.
diff
    Toggle to make tasks return 'diff' information or not.
environment
    A dictionary that gets converted into environment vars to be provided for the task upon execution.
ignore_errors
    Boolean that allows you to ignore task failures and continue with play. It does not affect connection errors.
ignore_unreachable
    Boolean that allows you to ignore unreachable hosts and continue with play. This does not affect other task errors (see ignore_errors) but is useful for groups of volatile/ephemeral hosts.
module_defaults
    Specifies default parameter values for modules.
name
    Identifier. Can be used for documentation, in or tasks/handlers.
no_log
    Boolean that controls information disclosure.
port
    Used to override the default port used in a connection.
remote_user
    User used to log into the target via the connection plugin.
rescue
    List of tasks in a block that run if there is a task error in the main block list.
run_once
    Boolean that will bypass the host loop, forcing the task to attempt to execute on the first host available and afterwards apply any results and facts to all active hosts in the same batch.
tags
    Tags applied to the task or included tasks, this allows selecting subsets of tasks from the command line.
vars
    Dictionary/map of variables
when
    Conditional expression, determines if an iteration of a task is run or not.

###Playbook Keywords - Task
action
    The 'action' to execute for a task, it normally translates into a C(module) 
    or action plugin.
any_errors_fatal
    Force any un-handled task errors on any host to propagate to all hosts and end the play.
args
    DEPRECATED, A secondary way to add arguments into a task. Takes a dictionary in which keys map to options and values.
async
    Run a task asynchronously if the C(action) supports this; value is maximum runtime in seconds.
become
    Boolean that controls if privilege escalation is used or not on Task execution.
become_flags
    A string of flag(s) to pass to the privilege escalation program when become is True.
become_method
    Which method of privilege escalation to use (such as sudo or su).
become_user
    User that you 'become' after using privilege escalation. The remote/login user must have permissions to become this user.
changed_when
    Conditional expression that overrides the task's normal 'changed' status.
check_mode
    A boolean that controls if a task is executed in 'check' mode
connection
    Allows you to change the connection plugin used for tasks to execute on the target.
debugger
    Enable debugging tasks based on state of the task result. See Playbook Debugger
delay
    Number of seconds to delay between retries. This setting is only used in combination with until.
delegate_facts
    Boolean that allows you to apply facts to a delegated host instead of inventory_hostname.
delegate_to
    Host to execute task instead of the target (inventory_hostname). Connection vars from the delegated host will also be used for the task.
diff
    Toggle to make tasks return 'diff' information or not.
environment
    A dictionary that gets converted into environment vars to be provided for the task upon execution.
failed_when
    Conditional expression that overrides the task's normal 'failed' status.
ignore_errors
    Boolean that allows you to ignore task failures and continue with play. It does not affect connection errors.
ignore_unreachable
    Boolean that allows you to ignore unreachable hosts and continue with play. This does not affect other task errors (see ignore_errors) but is useful for groups of volatile/ephemeral hosts.
local_action
    Same as action but also implies delegate_to: localhost
loop
    Takes a list for the task to iterate over, saving each list element into the item variable (configurable via loop_control)
loop_control
    Several keys here allow you to modify/set loop behaviour in a task.
module_defaults
    Specifies default parameter values for modules.
name
    Identifier. Can be used for documentation, in or tasks/handlers.
no_log
    Boolean that controls information disclosure.
notify
    List of handlers to notify when the task returns a 'changed=True' status.
poll
    Sets the polling interval in seconds for async tasks (default 10s).
port
    Used to override the default port used in a connection.
register
    Name of variable that will contain task status and module return data.
remote_user
    User used to log into the target via the connection plugin.
retries
    Number of retries before giving up in a until loop. This setting is only used in combination with until.
run_once
    Boolean that will bypass the host loop, forcing the task to attempt to execute on the first host available and afterwards apply any results and facts to all active hosts in the same batch.
tags
    Tags applied to the task or included tasks, this allows selecting subsets of tasks from the command line.
until
    This keyword implies a 'retries loop' that will go on until the condition supplied here is met or we hit the retries limit.
vars
    Dictionary/map of variables
when
    Conditional expression, determines if an iteration of a task is run or not.
with_<lookup_plugin>
    The same as loop but magically adds the output of any lookup plugin to generate the item list.



###Creating Reusable Playbooks
#there are three ways to do this: includes, imports, and roles.

Includes and imports allow users to break up large playbooks into smaller files, 
which can be used across multiple parent playbooks or even multiple times within the same Playbook.

Roles allow more than just tasks to be packaged together 
and can include variables, handlers, or even modules and other plugins. 
Unlike includes and imports, roles can also be uploaded and shared via Ansible Galaxy.

##Dynamic vs. Static
#Ansible has two modes of operation for reusable content: dynamic and static.

#If you use any import* Task (import_playbook, import_tasks, etc.), it will be static. 
#If you use any include* Task (include_tasks, include_role, etc.), it will be dynamic.

#The bare include task (which was used for both Task files and Playbook-level includes) is still available, 
#however it is now considered deprecated.


##Differences Between Static and Dynamic
Ansible pre-processes all static imports during Playbook parsing time.
Dynamic includes are processed during runtime at the point in which that task is encountered.

#When it comes to Ansible task options like tags and conditional statements (when:):
For static imports, the parent task options will be copied to all child tasks contained 
 within the import.
For dynamic includes, the task options will only apply to the dynamic task as it is evaluated, 
 and will not be copied to child tasks.


Roles were  statically included via the special 'roles: 'option for a given play 
and were always executed first before any other play tasks (unless pre_tasks were used). 
OR use include_role option to allow roles to be executed inline with other tasks.


The primary advantage of using include* statements is looping. 
When a loop is used with an include, the included tasks or role will be executed once 
for each item in the loop.

#Using include* does have some limitations when compared to import* statements:
Tags which only exist inside a dynamic include will not show up in --list-tags output.
Tasks which only exist inside a dynamic include will not show up in --list-tasks output.
You cannot use notify to trigger a handler name which comes from inside a dynamic include 
You cannot use --start-at-task to begin execution at a task inside a dynamic include.

#Using import* can also have some limitations when compared to dynamic includes:
loops cannot be used with imports at all.
When using variables for the target file or role name, 
variables from inventory sources (host/group vars, etc.) cannot be used.


##Importing Playbooks

#The plays and tasks in each playbook listed will be run in the order they are listed, 
#just as if they had been defined here directly.
- import_playbook: webservers.yml
- import_playbook: databases.yml

#Prior to 2.4 only include was available and worked for both playbooks and tasks 
#as both import and include.


#Including and Importing Task Files

# common_tasks.yml
- name: placeholder foo
  command: /bin/foo
- name: placeholder bar
  command: /bin/bar

#then use import_tasks or include_tasks to execute the tasks in a file in the main task list:

tasks:
- import_tasks: common_tasks.yml
# or
- include_tasks: common_tasks.yml

#OR  pass variables into imports and includes:

tasks:
- import_tasks: wordpress.yml
  vars:
    wp_user: timmy
- import_tasks: wordpress.yml
  vars:
    wp_user: alice
- import_tasks: wordpress.yml
  vars:
    wp_user: bob

#Task include and import statements can be used at arbitrary depth.
#You can mix in includes along with your regular non-included tasks and handlers.

#Static and dynamic can be mixed, however this is not recommended as it may lead to difficult-to-diagnose bugs in your playbooks.
#The key=value syntax for passing variables to import and include is deprecated. Use YAML vars: instead.

#Includes and imports can also be used in the handlers: section. 

# more_handlers.yml
- name: restart apache
  service: name=apache state=restarted

#And in your main playbook file:
handlers:
- include_tasks: more_handlers.yml
# or
- import_tasks: more_handlers.yml

Note

###Roles 
#Roles are ways of automatically loading certain vars_files, tasks, 
#and handlers based on a known file structure. 
#Grouping content by roles also allows easy sharing of roles with other users.

#Example project structure:
site.yml
webservers.yml
fooservers.yml
roles/
   common/  #atleast one dir of below, exclude if not used , role name is 'common' 
     tasks/
        main.yml
     handlers/
        main.yml
     files/
        main.yml
     templates/
        main.yml
     vars/
        main.yml
     defaults/
        main.yml
     meta/
        main.yml
   webservers/
     tasks/
        main.yml
     defaults/
        main.yml
     meta/
        main.yml
   my custom_role_name/
     tasks/
        main.yml
     defaults/
        main.yml
     meta/
        main.yml
#Meaning 
tasks - contains the main list of tasks to be executed by the role.
handlers - contains handlers, which may be used by this role or even anywhere outside this role.
defaults - default variables for the role 
vars - other variables for the role 
files - contains files which can be deployed via this role.
templates - contains templates which can be deployed via this role.
meta - defines some meta data for this role. See below for more details.

#Other YAML files may be included in certain directories. 
#For example, it is common practice to have platform-specific tasks included 
#from the tasks/main.yml file:

# roles/example/tasks/main.yml
- name: added in 2.4, previously you used 'include'
  import_tasks: redhat.yml
  when: ansible_facts['os_family']|lower == 'redhat'
- import_tasks: debian.yml
  when: ansible_facts['os_family']|lower == 'debian'

# roles/example/tasks/redhat.yml
- yum:
    name: "httpd"
    state: present

# roles/example/tasks/debian.yml
- apt:
    name: "apache2"
    state: present

    
##Using Roles
#The classic (original) way to use roles is via the roles: option for a given play:

---
- hosts: webservers
  roles:
     - common
     - webservers

#This designates the following behaviors, for each role ‘x’:
If roles/x/tasks/main.yml exists, tasks listed therein will be added to the play.
If roles/x/handlers/main.yml exists, handlers listed therein will be added to the play.
If roles/x/vars/main.yml exists, variables listed therein will be added to the play.
If roles/x/defaults/main.yml exists, variables listed therein will be added to the play.
If roles/x/meta/main.yml exists, any role dependencies listed therein will be added to the list of roles (1.3 and later).
#Any copy, script, template or include tasks (in the role) can reference files in roles/x/{files,templates,tasks}/ (dir depends on task) 
#without having to path them relatively or absolutely.


#When roles are defined in the classic manner, 
#they are treated as static imports and processed during playbook parsing.


#When used in this manner, the order of execution for your playbook is as follows:
Any pre_tasks defined in the play.
Any handlers triggered so far will be run.
Each role listed in roles will execute in turn. 
Any role dependencies defined in the roles meta/main.yml will be run first, 
subject to tag filtering and conditionals.
Any tasks defined in the play.
Any handlers triggered so far will be run.
Any post_tasks defined in the play.
Any handlers triggered so far will be run.


#If using tags with tasks (as a means of only running part of a playbook), 
#be sure to also tag your pre_tasks, post_tasks, and role dependencies 
#and pass those along as well


#As of Ansible 2.4, Can use roles inline with any other tasks using import_role or include_role:
#(as static and dynamic)
---

- hosts: webservers
  tasks:
  - debug:
      msg: "before we run our role"
  - import_role:
      name: example
  - include_role:
      name: example
  - debug:
      msg: "after we ran our role"


#The name used for the role can be a simple name 
#or it can be a fully qualified path:

---

- hosts: webservers
  roles:
    - role: '/path/to/my/roles/common'

#Roles can accept other keywords:

---

- hosts: webservers
  roles:
    - common
    - role: foo_app_instance
      vars:
         dir: '/opt/a'
         app_port: 5000
    - role: foo_app_instance
      vars:
         dir: '/opt/b'
         app_port: 5001

#Or, using the newer syntax:

---

- hosts: webservers
  tasks:
  - include_role:
       name: foo_app_instance
    vars:
      dir: '/opt/a'
      app_port: 5000
  ...

Y#ou can conditionally import a role and execute it’s tasks:

---

- hosts: webservers
  tasks:
  - include_role:
      name: some_role
    when: "ansible_facts['os_family'] == 'RedHat'"

#to assign tags to the tasks inside the roles you specify

---

- hosts: webservers
  roles:
    - role: bar
      tags: ["foo"]
    # using YAML shorthand, this is equivalent to the above
    - { role: foo, tags: ["bar", "baz"] }

#using the newer syntax:

---

- hosts: webservers
  tasks:
  - import_role:
      name: foo
    tags:
    - bar
    - baz

#To understand further , use 
import yaml
print(yaml.load(yaml_document)) #yaml_document is string of above 
#[{'tasks': [{'import_role': {'name': 'foo'}, 'tags': ['bar', 'baz']}], 'hosts':'webservers'}]

#This tags all of the tasks in that role with the tags specified, 
#appending to any tags that are specified inside the role.

#On the other hand you might just want to tag the import of the role itself: Use include_role 
#The tags in this example will not be added to tasks inside an include_role, 
#you can use a surrounding block directive to do both.
- hosts: webservers
  tasks:
  - include_role:
      name: bar
    tags:
     - foo

#[{'tasks': [{'tags': ['foo'], 'include_role': {'name': 'bar'}}], 'hosts': 'webservers'}]


#There is no facility to import a role while specifying a subset of tags to execute. 
#If you find yourself building a role with lots of tags 
#and you want to call subsets of the role at different times, 
#you should consider just splitting that role into multiple roles.


##Role Duplication and Execution
#Ansible will only allow a role to execute once, even if defined multiple times, 
#if the parameters defined on the role are not different for each definition

---
- hosts: webservers
  roles:
  - foo  #the role foo will only be run once
  - foo

#To make roles run more than once, there are two options:
Pass different parameters in each role definition.
Add allow_duplicates: true to the meta/main.yml file for the role.

#Example 1 - passing different parameters:

---
- hosts: webservers
  roles:
  - role: foo
    vars:
         message: "first"
  - { role: foo, vars: { message: "second" } }

#Example 2 - using allow_duplicates: true:

# playbook.yml
---
- hosts: webservers
  roles:
  - foo
  - foo

# roles/foo/meta/main.yml
---
allow_duplicates: true



##Role Default Variables
#Role default variables allow you to set default variables for included or dependent roles 
#To create defaults,  add a defaults/main.yml file in your role directory. 
#These variables will have the lowest priority of any variables available, 
#and can be easily overridden by any other variable, including inventory variables.
#defaults/main.yml
base_debian_upgrade: false
base_debian_dist_upgrade: false


##Role Dependencies
#Role dependencies allow you to automatically pull in other roles when using a role. 
#Role dependencies are stored in the meta/main.yml file contained within the role directory, 
#This file should contain a list of roles and parameters to insert before the specified role, 

#roles/myapp/meta/main.yml:

---
dependencies:
  - role: common
    vars:
      some_parameter: 3
  - role: apache
    vars:
      apache_port: 80
  - role: postgres
    vars:
      dbname: blarg
      other_parameter: 12

#Role dependencies must use the classic role definition style.
#Role dependencies are always executed before the role that includes them, and may be recursive. 
#Dependencies also follow the duplication rules specified above. 
#If another role also lists it as a dependency, it will not be run again based on the same rules given above.

#Always remember that when using allow_duplicates: true, 
#it needs to be in the dependent role's meta/main.yml, not the parent.

#For example, a role named car depends on a role named wheel as follows:

---
dependencies:
- role: wheel
  vars:
     n: 1
- role: wheel
  vars:
     n: 2
- role: wheel
  vars:
     n: 3
- role: wheel
  vars:
     n: 4

#And the wheel role depends on two roles: tire and brake. 
#The meta/main.yml for wheel would then contain the following:

---
dependencies:
- role: tire
- role: brake

#And the meta/main.yml for tire and brake would contain the following:

---
allow_duplicates: true

#The resulting order of execution would be as follows:

tire(n=1)
brake(n=1)
wheel(n=1)
tire(n=2)
brake(n=2)
wheel(n=2)
...
car


##Embedding Modules and Plugins In Roles
#Directory 
roles/
   my_custom_role_with_modules/
       library/
          module1
          module2
       tasks/
          main.yml
       defaults/
          main.yml
       meta/
        main.yml
        
#The module will be usable in the role itself, 
#as well as any roles that are called after this role
- hosts: webservers
  roles:
    - my_custom_role_with_modules
    - some_other_role_using_my_custom_modules
    - yet_another_role_using_my_custom_modules

#This can also be used, with some limitations, to modify modules in Ansible’s core distribution,
#for example to mock the actual behaviour 

#OR include plugins in a role, using the same schema. 
#For example, for a filter plugin:

roles/
   my_custom_role_with_filter/
       filter_plugins
          filter1
          filter2
       tasks/
          main.yml
       defaults/
          main.yml
       meta/
        main.yml
#They can then be used in a template or a jinja template in any role called 
#after 'my_custom_role_with_filter'


##Role Search Path
1.A roles/ directory, relative to the playbook file.
2.By default, in /etc/ansible/roles (cygwin ~/.ansible/roles)(check ansible --version)
3. roles_path(ansible.cfg) to search for additional roles

##Ansible Galaxy
#Ansible Galaxy is a free site for finding, downloading, rating, 
#and reviewing all kinds of community developed Ansible roles 

#server address https://galaxy.ansible.com. 
#OR use  –server option or by setting the Galaxy server value in ansible.cfg file. 

$ ansible-galaxy install username.role_name

#downloads roles to the path specified by the environment variable ANSIBLE_ROLES_PATH. 
#This can be set to a series of directories (i.e. /etc/ansible/roles:~/.ansible/roles), 
#OR override by setting the environment variable in your session, 
#defining roles_path in an ansible.cfg file, or by using the –roles-path option. 

$ ansible-galaxy install --roles-path . geerlingguy.apache

#version
$ ansible-galaxy install geerlingguy.apache,v1.0.0
#github 
$ ansible-galaxy install git+https://github.com/geerlingguy/ansible-role-apache.git,0b7cd353c0250e87a26e0499e59e7fd265cc2f25

#Use the following command to install roles included in requirements.yml:
$ ansible-galaxy install -r requirements.yml

#Each role in the file will have one or more of the following attributes:
src
    The source of the role. Use the format username.role_name, if downloading from Galaxy; otherwise, provide a URL pointing to a repository within a git based SCM. See the examples below. This is a required attribute.
scm
    Specify the SCM. As of this writing only git or hg are supported. See the examples below. Defaults to git.
version:
    The version of the role to download. Provide a release tag value, commit hash, or branch name. Defaults to master.
name:
    Download the role to a specific name. Defaults to the Galaxy name when downloading from Galaxy, otherwise it defaults to the name of the repository.

#Example requirements.yml:

# from galaxy
- src: yatesr.timezone

# from GitHub
- src: https://github.com/bennojoy/nginx

# from GitHub, overriding the name and specifying a specific tag
- src: https://github.com/bennojoy/nginx
  version: master
  name: nginx_role

# from a webserver, where the role is packaged in a tar.gz
- src: https://some.webserver.example.com/files/master.tar.gz
  name: http-role

# from Bitbucket
- src: git+https://bitbucket.org/willthames/git-ansible-galaxy
  version: v1.4

# from Bitbucket, alternative syntax and caveats
- src: https://bitbucket.org/willthames/hg-ansible-galaxy
  scm: hg

# from GitLab or other git-based scm, using git+ssh
- src: git@gitlab.company.com:mygroup/ansible-base.git
  scm: git
  version: "0.1"  # quoted, so YAML doesn't parse this as a floating-point value

##Installing multiple roles from multiple files
#Use the following command to install roles includes in requirements.yml + webserver.yml
$ ansible-galaxy install -r requirements.yml

#Content of the requirements.yml file:

# from galaxy
- src: yatesr.timezone

- include: <path_to_requirements>/webserver.yml

#Content of the webserver.yml file:

# from github
- src: https://github.com/bennojoy/nginx

# from Bitbucket
- src: git+https://bitbucket.org/willthames/git-ansible-galaxy
  version: v1.4

  
  
##Dependencies
#hen you install a role that has dependencies, 
#those dependencies will automatically be installed.

#specify role dependencies in the meta/main.yml
#If the source of a role is Galaxy, specify the role in the format username.role_name. 
#The more complex format used in requirements.yml is also supported

#Tags are inherited down the dependency chain. 
#In order for tags to be applied to a role and all its dependencies, 
#the tag should be applied to the role, not to all the tasks within a role.

#Roles listed as dependencies are subject to conditionals and tag filtering, 
#and may not execute fully depending on what tags and conditionals are applied.

#Dependencies found in Galaxy can be specified as follows:
dependencies:
  - geerlingguy.apache
  - geerlingguy.ansible

#The complex form can also be used as follows:
dependencies:
  - src: geerlingguy.ansible
  - src: git+https://github.com/geerlingguy/ansible-role-composer.git
    version: 775396299f2da1f519f0d8885022ca2d6ee80ee8
    name: composer

##Create roles
#Use the init command to initialize the base structure of a new role, 
ansible-galaxy init test-role-1

#test-role-1 directory in cwd will contain the following:
#If a directory matching the name of the role already exists in the current working directory, 
#the init command will result in an error. To ignore the error use the –force option.

.travis.yml
README.md
defaults/
    main.yml
files/
handlers/
    main.yml
meta/
    main.yml
tasks/
    main.yml
templates/
tests/
    inventory
    test.yml
vars/
    main.yml

#And meta/main.yml 
galaxy_info:
  role_name: foo
  author: your name
  description: your description
  company: your company (optional)

  # If the issue tracker for your role is not on github, uncomment the
  # next line and provide a value
  # issue_tracker_url: http://example.com/issue/tracker

  # Some suggested licenses:
  # - BSD (default)
  # - MIT
  # - GPLv2
  # - GPLv3
  # - Apache
  # - CC-BY
  license: license (GPLv2, CC-BY, etc)

  min_ansible_version: 1.2

  # If this a Container Enabled role, provide the minimum Ansible Container version.
  # min_ansible_container_version:

  # Optionally specify the branch Galaxy will use when accessing the GitHub
  # repo for this role. During role install, if no tags are available,
  # Galaxy will use this branch. During import Galaxy will access files on
  # this branch. If Travis integration is configured, only notifications for this
  # branch will be accepted. Otherwise, in all cases, the repo's default branch
  # (usually master) will be used.
  #github_branch:

  #
  # platforms is a list of platforms, and each platform has a name and a list of versions.
  #
  # platforms:
  # - name: Fedora
  #   versions:
  #   - all
  #   - 25
  # - name: SomePlatform
  #   versions:
  #   - all
  #   - 1.0
  #   - 7
  #   - 99.99

  galaxy_tags: []
    # List tags for your role here, one per line. A tag is a keyword that describes
    # and categorizes the role. Users find roles by searching for tags. Be sure to
    # remove the '[]' above, if you add tags to this list.
    #
    # NOTE: A tag is limited to a single word comprised of alphanumeric characters.
    #       Maximum 20 tags per role.

dependencies: []
  # List your role dependencies here, one per line. Be sure to remove the '[]' above,
  # if you add dependencies to this list.
  
  

##Using a Custom Role Skeleton
#A custom role skeleton directory can be supplied as follows:

$ ansible-galaxy init --role-skeleton=/path/to/skeleton role_name

#When a skeleton is provided, init will:
copy all files and directories from the skeleton to the new role
any .j2 files found outside of a templates folder will be rendered as templates. 
The only useful variable at the moment is role_name
The .git folder and any .git_keep files will not be copied

##Search for Roles
#Search the Galaxy database by tags, platforms, author and multiple keywords. For example:

$ ansible-galaxy search elasticsearch --author geerlingguy

#The search command will return a list of the first 1000 results matching your search:

Found 2 roles matching your search:

Name                              Description
----                              -----------
geerlingguy.elasticsearch         Elasticsearch for Linux.
geerlingguy.elasticsearch-curator Elasticsearch curator for Linux.

##Get more information about a role
$ ansible-galaxy info username.role_name

#This returns everything found in Galaxy for the role:

Role: username.role_name
    description: Installs and configures a thing, a distributed, highly available NoSQL thing.
    active: True
    commit: c01947b7bc89ebc0b8a2e298b87ab416aed9dd57
    commit_message: Adding travis
    commit_url: https://github.com/username/repo_name/commit/c01947b7bc89ebc0b8a2e298b87ab
    company: My Company, Inc.
    created: 2015-12-08T14:17:52.773Z
    download_count: 1
    forks_count: 0
    github_branch:
    github_repo: repo_name
    github_user: username
    id: 6381
    is_valid: True
    issue_tracker_url:
    license: Apache
    min_ansible_version: 1.4
    modified: 2015-12-08T18:43:49.085Z
    namespace: username
    open_issues_count: 0
    path: /Users/username/projects/roles
    scm: None
    src: username.repo_name
    stargazers_count: 0
    travis_status_url: https://travis-ci.org/username/repo_name.svg?branch=master
    version:
    watchers_count: 1

##List installed roles

$ ansible-galaxy list
#output 
- chouseknecht.role-install_mongod, master
- chouseknecht.test-role-1, v1.0.2
- chrismeyersfsu.role-iptables, master
- chrismeyersfsu.role-required_vars, master

##Remove an installed role
$ ansible-galaxy remove username.role_name


##Authenticate with Galaxy
#Using the import, delete and setup commands to manage  roles on the Galaxy website requires authentication,
# and the login command can be used to do just that. 
#Before you can use the login command, you must create an account on the Galaxy website.

#The login command requires using your GitHub credentials. 
#You can use your username and password, or you can create a personal access token. 
If you choose to create a token, grant minimal access to the token, as it is used just to verify identify.

#For example , using a GitHub username and password:

$ ansible-galaxy login

We need your GitHub login to identify you.
This information will not be sent to Galaxy, only to api.github.com.
The password will not be displayed.

Use --github-token if you do not want to enter your password.

Github Username: dsmith
Password for dsmith:
Successfully logged into Galaxy as dsmith

##Travis integrations
#You can create an integration or connection between a role in Galaxy and Travis(CI framework integrated with GITHUB). 
#Once the connection is established, a build in Travis will automatically trigger an import in Galaxy, updating the search index with the latest information about the role.

$ ansible-galaxy setup travis github_user github_repo xxx-travis-token-xxx

#To instruct Travis to notify Galaxy when a build completes, 
#add the following to  .travis.yml file:

notifications:
    webhooks: https://galaxy.ansible.com/api/v1/notifications/

##List Travis integrations
$ ansible-galaxy setup --list


ID         Source     Repo
---------- ---------- ----------
2          travis     github_user/github_repo
1          travis     github_user/github_repo

##Remove Travis integrations

$ ansible-galaxy setup --remove ID


##Multi-role Repositories
#a role is a git repository. 
#Galaxy v3.0 introduced multi-role repositories, 
#providing the ability to combine multiple roles into a single git repository.

#Installing a mult-role repository requires using the mazer command line tool 
#available at the Ansible Mazer project.


##pre_task and post_task 
#use the pre_tasks to do some tasks before roles

#!/usr/bin/env ansible-playbook

---
- hosts: all
  become: true
  pre_tasks:
    - name: start tasks and sent notifiaction to HipChat
      hipchat:
        color: purple
        token: "{{ hipchat_token }}"
        room: "{{ hipchat_room }}"
        msg: "[Start] Run 'foo/setup.yml' playbook on {{ ansible_nodename }}."

  roles:
    - chusiang.vim-and-vi-mode

  vars:
    ...

  tasks:
    - name: include main task
      include: tasks/main.yml

  post_tasks:
    - name: finish tasks and sent notifiaction to HipChat
      hipchat:
        color: green
        token: "{{ hipchat_token }}"
        room: "{{ hipchat_room }}"
        msg: "[Finish] Run 'foo/setup.yml' playbook on {{ ansible_nodename }}."

# vim:ft=ansible :




###Ansible Playbook Bundles
#An Ansible Playbook Bundle (APB) is a lightweight application definition 
#consisting of several named playbooks and a metadata file. 

#An APB defines a short lived container capable of orchestrating the deployment of applications 
#to an OpenShift Origin cluster(a cluster framework) running the Ansible Service Broker. 
#The short lived container holds a copy of the APB, plus an Ansible runtime environment, 
#and any files required to perform the orchestration, 
#including: playbooks, roles, and dependencies.


#Using the mazer command line tool

$ mazer init --type apb test-apb-1

#The command to create an APB using galaxy(getting deprecated)
ansible-galaxy init --type apb test-apb-1

#The test-apb-1 directory will contain the following:

.travis.yml
Dockerfile
Makefile
README.md
apb.yml
defaults/
    main.yml
files/
handlers/
    main.yml
meta/
    main.yml
playbooks/
    deprovision.yml
    provision.yml
tasks/
    main.yml
templates/
tests/
    ansible.cfg
    inventory
    test.yml
vars/
    main.yml

#Check more at 
#https://docs.openshift.com/container-platform/3.7/apb_devel/writing/getting_started.html


###Understanding Privilege Escalation

##Become
#Ansible allows you to 'become' another user, 
#different from the user that logged into the machine (remote user). 

#This is done using existing privilege escalation tools such as sudo, su, pfexec, doas, pbrun, dzdo, ksu, runas, machinectl and others.

#Prior to version 1.9, Ansible mostly allowed the use of sudo and a limited use of su to allow a login/remote user to become a different user 
#and execute tasks and create resources with the second user's permissions. 
#As of Ansible version 1.9, become supersedes the old sudo/su, while still being backwards compatible. 

#Become vars and directives are independent. 
#For example, setting become_user does not set become.


##Directive 
#These can be set from play to task level, 
#but are overridden by connection variables as they can be host specific.

become
    set to yes to activate privilege escalation.
become_user
    set to user with desired privileges — the user you become, 
    NOT the user you login as. 
    Does NOT imply become: yes, to allow it to be set at host level.
become_method
    (at play or task level) overrides the default method set in ansible.cfg, 
    set to sudo/su/pbrun/pfexec/doas/dzdo/ksu/runas/machinectl
become_flags
    (at play or task level) permit the use of specific flags for the tasks or role. 
    One common use is to change the user to nobody when the shell is set to no login. 
    Added in Ansible 2.2.

#For example, to manage a system service (which requires root privileges) 
#when connected as a non-root user 
#(this takes advantage of the fact that the default value of become_user is root):

- name: Ensure the httpd service is running
  service:
    name: httpd
    state: started
  become: yes

#To run a command as the apache user:

- name: Run a command as the apache user
  command: somecommand
  become: yes
  become_user: apache

#To do something as the nobody user when the shell is nologin:

- name: Run a command as nobody
  command: somecommand
  become: yes
  become_method: su
  become_user: nobody
  become_flags: '-s /bin/sh'

##Connection variables in inventory file 

#Each allows you to set an option per group and/or host, 
#these are normally defined in inventory but can be used as normal variables.

ansible_become
    equivalent of the become directive, decides if privilege escalation is used or not.
ansible_become_method
    which privilege escalation method should be used
ansible_become_user
    set the user you become through privilege escalation; 
    does not imply ansible_become: yes
ansible_become_pass
    set the privilege escalation password. 
    Use Vault in playbooks to avoid having secrets in plain text

#For example, if you want to run all tasks as root on a server named webserver, 
#but you can only connect as the manager user, you could use an inventory entry like this:

webserver ansible_user=manager ansible_become=yes

#Command line options
--ask-become-pass, -K
 	ask for privilege escalation password; 
    does not imply become will be used. 
    Note that this password will be used for all hosts.
--become, -b 	
    run operations with become (no password implied)
--become-method=BECOME_METHOD
 	privilege escalation method to use (default=sudo), 
    valid choices: [ sudo | su | pbrun | pfexec | doas | dzdo | ksu | runas | machinectl ]
--become-user=BECOME_USER
 	run operations as this user (default=root), does not imply –become/-b
    For those from Pre 1.9 , sudo and su still work

#For those using old playbooks will not need to be changed, even though they are deprecated, 
#sudo and su directives, variables and options will continue to work. 

#You cannot mix directives on the same object (become and sudo) though, 


##Limitations
Becoming an Unprivileged User
    Ansible 2.0.x and below has a limitation with regards to becoming an unprivileged user 
    that can be a security risk if users are not aware of it. 
    Ansible modules are executed on the remote machine 
    by first substituting the parameters into the module file, 
    then copying the file to the remote machine, 
    and finally executing it there.
    
    Everything is fine if the module file is executed without using become, 
    when the become_user is root, or when the connection to the remote machine is made as root. 
    In these cases the module file is created with permissions 
    that only allow reading by the user and root.
    
    The problem occurs when the become_user is an unprivileged user. 
    Ansible 2.0.x and below make the module file world readable in this case, 
    as the module file is written as the user that Ansible connects as, 
    but the file needs to be readable by the user Ansible is set to become.
    
    In Ansible 2.1, this window is further narrowed: 
    If the connection is made as a privileged user (root), 
    then Ansible 2.1 and above will use chown to set the file's owner to the unprivileged user being switched to. 
    This means both the user making the connection and the user being switched to via become 
    must be unprivileged in order to trigger this problem.

    If any of the parameters passed to the module are sensitive in nature, 
    then those pieces of data are located in a world readable module file for the duration of the Ansible module execution. 
    Once the module is done executing, Ansible will delete the temporary file. 
    If you trust the client machines then there's no problem here. 
    If you do not trust the client machines then this is a potential danger.
    
    Ways to resolve this include:
    Use pipelining. When pipelining is enabled, Ansible doesnot save the module to a temporary file on the client. 
    Instead it pipes the module to the remote python interpreter's stdin. 
    Pipelining does not work for python modules involving file transfer 
    (for example: copy, fetch, template), or for non-python modules.
    (Available in Ansible 2.1) Install POSIX.1e filesystem acl support on the managed host. 
    If the temporary directory on the remote host is mounted with POSIX acls enabled 
    and the setfacl tool is in the remote PATH then Ansible will use POSIX acls 
    to share the module file with the second unprivileged user instead of having to make the file readable by everyone.
    Don't perform an action on the remote machine by becoming an unprivileged user. 
    Temporary files are protected by UNIX file permissions when you become root or do not use become. 
    In Ansible 2.1 and above, UNIX file permissions are also secure 
    if you make the connection to the managed machine as root 
    and then use become to an unprivileged account.
    
Connection Plugin Support
    Privilege escalation methods must also be supported by the connection plugin used. 
    Most connection plugins will warn if they do not support become. 
    Some will just ignore it as they always run as root (jail, chroot, etc).
    
Only one method may be enabled per host
    Methods cannot be chained. You cannot use sudo /bin/su - to become a user, 
    you need to have privileges to run the command as that user in sudo 
    or be able to su directly to it (the same for pbrun, pfexec or other supported methods).
    
Can't limit escalation to certain commands
    Privilege escalation permissions have to be general. 
    Ansible does not always use a specific command to do something 
    but runs modules (code) from a temporary file name which changes every time. 
    If you have '/sbin/service' or '/bin/chmod' as the allowed commands this will fail 
    with ansible as those paths won't match with the temporary file 
    that ansible creates to run the module.
    
Environment variables populated by pam_systemd
    For most Linux distributions using systemd as their init, 
    the default methods used by become do not open a new "session", in the sense of systemd. 
    Because the pam_systemd module will not fully initialize a new session, 
    you might have surprises compared to a normal session opened through ssh: 
    some environment variables set by pam_systemd, most notably XDG_RUNTIME_DIR, 
    are not populated for the new user and instead inherited or just emptied.

    This might cause trouble when trying to invoke systemd commands that depend on XDG_RUNTIME_DIR to access the bus:
        $ echo $XDG_RUNTIME_DIR
        $ systemctl --user status
        Failed to connect to bus: Permission denied
    To force become to open a new systemd session that goes through pam_systemd, 
    you can use become_method: machinectl.


Become and Networks
    As of version 2.6, Ansible supports become for privilege escalation 
    (entering enable mode or privileged EXEC mode) on all Ansible-maintained platforms 
    that support enable mode: eos`, ios, and nxos. 
    Using become replaces the authorize and auth_pass options in a provider dictionary.

    You must set the connection type to either connection: network_cli 
    or connection: httpapi to use become for privilege escalation on network devices. 
    Check the Platform Options and Network modules documentation for details.

    You can use escalated privileges on only the specific tasks that need them, 
    on an entire play, or on all plays. 
    Adding become: yes and become_method: enable instructs Ansible to enter enable mode 
    before executing the task, play, or playbook where those parameters are set.

    If you see this error message, the task that generated it requires enable mode to succeed:
        Invalid input (privileged mode required)
#To set enable mode for a specific task, add become at the task level:
- name: Gather facts (eos)
  eos_facts:
    gather_subset:
      - "!hardware"
  become: yes
  become_method: enable

#To set enable mode for all tasks in a single play, add become at the play level:

- hosts: eos-switches
  become: yes
  become_method: enable
  tasks:
    - name: Gather facts (eos)
      eos_facts:
        gather_subset:
          - "!hardware"

##Setting enable mode for all tasks
#Often you wish for all tasks in all plays to run using privilege mode, 
#that is best achieved by using group_vars:

#group_vars/eos.yml

ansible_connection: network_cli
ansible_network_os: eos
ansible_user: myuser
ansible_become: yes
ansible_become_method: enable

#Passwords for enable mode
#If you need a password to enter enable mode, you can specify it in one of two ways:
providing the --ask-become-pass command line option
setting the ansible_become_pass connection variable(Use vault)


##authorize and auth_pass
#Ansible still supports enable mode with connection: local for legacy playbooks. 
#To enter enable mode with connection: local, use the module options authorize and auth_pass:

- hosts: eos-switches
  ansible_connection: local
  tasks:
    - name: Gather facts (eos)
      eos_facts:
        gather_subset:
          - "!hardware"
      provider:
        authorize: yes
        auth_pass: " {{ secret_auth_pass }}"

##Become and Windows
#Since Ansible 2.3, become can be used on Windows hosts through the runas method. 
#Become on Windows uses the same inventory setup and invocation arguments 
#as become on a non-Windows host, so the setup and variable names are the same 
#as what is defined in this document.

#While become can be used to assume the identity of another user, 
#there are other uses for it with Windows hosts. 
#One important use is to bypass some of the limitations that are imposed 
#when running on WinRM, such as constrained network delegation 
#or accessing forbidden system calls like the WUA API. 
#You can use become with the same user as ansible_user 
#to bypass these limitations and run commands that are not normally accessible in a WinRM session.


##Administrative Rights
#Many tasks in Windows require administrative privileges to complete. 
#When using the runas become method, Ansible will attempt to run the module 
#with the full privileges that are available to the remote user. 
#If it fails to elevate the user token, it will continue to use the limited token during execution.

#Before Ansible 2.5, a token was only able to be elevated when UAC was disabled 
#or the remote user had the SeTcbPrivilege assigned. 
#This restriction has been lifted in Ansible 2.5 
#and a user that is a member of the BUILTIN\Administrators group should have an elevated token 
#during the module execution.

#To determine the type of token that Ansible was able to get, 
#run the following task and check the output:

- win_whoami:
  become: yes

#Under the GROUP INFORMATION section, 
#the Mandatory Label entry determines whether the user has Administrative rights. 
Medium
    Ansible failed to get an elevated token and ran under a limited token. 
    Only a subset of the privileges assigned to user are available during the module execution and the user does not have administrative rights.
High
    An elevated token was used and all the privileges assigned to the user are available during the module execution.
System
    The NT AUTHORITY\System account is used and has the highest level of privileges available.

#The output will also show the list of privileges that have been granted to the user. 
#When State==Disabled, the privileges have not been enabled but can be if required. 
#In most scenarios these privileges are automatically enabled when required.

#If running on a version of Ansible that is older than 2.5 
#or the normal runas escalation process fails, an elevated token can be retrieved by:
    Set the become_user to System which has full control over the operating system.
    Grant SeTcbPrivilege to the user Ansible connects with on WinRM. 
    SeTcbPrivilege is a high-level privilege that grants full control over the operating system. 
    No user is given this privilege by default, and care should be taken if you grant this privilege to a user or group. 
    You can use the below task to set this privilege on a Windows host:
    - name: grant the ansible user the SeTcbPrivilege right
      win_user_right:
        name: SeTcbPrivilege
        users: '{{ansible_user}}'
        action: add
    Turn UAC off on the host and reboot before trying to become the user. 
    UAC is a security protocol that is designed to run accounts with the least privilege principle. 
    You can turn UAC off by running the following tasks:
    - name: turn UAC off
      win_regedit:
        path: HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system
        name: EnableLUA
        data: 0
        type: dword
        state: present
      register: uac_result
    - name: reboot after disabling UAC
      win_reboot:
      when: uac_result is changed

      
##Local Service Accounts
#Prior to Ansible version 2.5, become only worked with a local or domain user account. 
#Local service accounts like System or NetworkService could not be used as become_user in these older versions. 
#This restriction has been lifted since the 2.5 release of Ansible. 
#The three service accounts that can be set under become_user are:
    System
    NetworkService
    LocalService
#Because local service accounts do not have passwords, 
#the ansible_become_password parameter is not required and is ignored if specified.


##Accounts without a Password
#As a general security best practice, you should avoid allowing accounts without passwords.
#Ansible can be used to become an account that does not have a password (like the Guest account). 
#To become an account without a password, set up the variables like normal 
#but either do not define ansible_become_pass or set ansible_become_pass: ''.

#Before become can work on an account like this, 
#the local policy Accounts: 
#Limit local account use of blank passwords to console logon only must be disabled. 
#This can either be done through a Group Policy Object (GPO) or with this Ansible task:

#This is only for accounts that do not have a password. 
#You still need to set the account's password under ansible_become_pass 
#if the become_user has a password.
- name: allow blank password on become
  win_regedit:
    path: HKLM:\SYSTEM\CurrentControlSet\Control\Lsa
    name: LimitBlankPasswordUse
    data: 0
    type: dword
    state: present



##Become Flags
#Ansible 2.5 adds the become_flags parameter to the runas become method. 
#This parameter can be set using the become_flags task directive 
#or set in Ansible's configuration using ansible_become_flags. 
#The two valid values that are initially supported for this parameter are 
#logon_type and logon_flags.

#These flags should only be set when becoming a normal user account, not a local service account like LocalSystem.

#The key logon_type sets the type of logon operation to perform. 
#The value can be set to one of the following:
interactive
    The default logon type. The process will be run under a context that is the same as when running a process locally. This bypasses all WinRM restrictions and is the recommended method to use.
batch
    Runs the process under a batch context that is similar to a scheduled task with a password set. This should bypass most WinRM restrictions and is useful if the become_user is not allowed to log on interactively.
new_credentials
    Runs under the same credentials as the calling user, but outbound connections are run under the context of the become_user and become_password, similar to runas.exe /netonly. The logon_flags flag should also be set to netcredentials_only. Use this flag if the process needs to access a network resource (like an SMB share) using a different set of credentials.
network
    Runs the process under a network context without any cached credentials. This results in the same type of logon session as running a normal WinRM process without credential delegation, and operates under the same restrictions.
network_cleartext
    Like the network logon type, but instead caches the credentials so it can access network resources. This is the same type of logon session as running a normal WinRM process with credential delegation.



#The logon_flags key specifies how Windows will log the user on when creating the new process. 
#The value can be set to none or multiple of the following:
with_profile
    The default logon flag set. The process will load the user's profile in the HKEY_USERS registry key to HKEY_CURRENT_USER.
netcredentials_only
    The process will use the same token as the caller but will use the become_user and become_password when accessing a remote resource. This is useful in inter-domain scenarios where there is no trust relationship, and should be used with the new_credentials logon_type.

#By default logon_flags=with_profile is set, 
#if the profile should not be loaded set logon_flags= or if the profile should be loaded 
#with netcredentials_only, set logon_flags=with_profile,netcredentials_only.

#Here are some examples of how to use become_flags with Windows tasks:

- name: copy a file from a fileshare with custom credentials
  win_copy:
    src: \\server\share\data\file.txt
    dest: C:\temp\file.txt
    remote_src: yex
  vars:
    ansible_become: yes
    ansible_become_method: runas
    ansible_become_user: DOMAIN\user
    ansible_become_pass: Password01
    ansible_become_flags: logon_type=new_credentials logon_flags=netcredentials_only

- name: run a command under a batch logon
  win_whoami:
  become: yes
  become_flags: logon_type=batch

- name: run a command and not load the user profile
  win_whomai:
  become: yes
  become_flags: logon_flags=

##Windows Limitations
1.Running a task with async and become on Windows Server 2008, 2008 R2 and Windows 7 only works 
  when using Ansible 2.7 or newer.
2.By default, the become user logs on with an interactive session, 
  so it must have the right to do so on the Windows host. 
  If it does not inherit the SeAllowLogOnLocally privilege 
  or inherits the SeDenyLogOnLocally privilege, the become process will fail. 
  Either add the privilege or set the logon_type flag to change the logon type used.
3.Prior to Ansible version 2.3, become only worked when ansible_winrm_transport 
  was either basic or credssp. 
  This restriction has been lifted since the 2.4 release of Ansible 
  for all hosts except Windows Server 2008 (non R2 version).

    
    
###Asynchronous Actions and Polling

#By default tasks in playbooks block, meaning the connections stay open until the task is done on each node. 
#This may not always be desirable, or you may be running operations 
#that take longer than the SSH timeout.

#To avoid blocking or timeout issues, 
#you can use asynchronous mode to run all of your tasks at once 
#and then poll until they are done.

#To launch a task asynchronously, specify its maximum runtime (async)
#and how frequently you would like to poll for status(poll) 

#The default poll value is 10 seconds if you do not specify a value for poll:
#There is no default for the async time limit. 
#If you leave off the 'async' keyword, the task runs synchronously, which is Ansible's default.

---

- hosts: all
  remote_user: root

  tasks:

  - name: simulate long running op (15 sec), wait for up to 45 sec, poll every 5 sec
    command: /bin/sleep 15
    async: 45
    poll: 5

#Using a higher value for --forks will result in kicking off asynchronous tasks even faster. 
#This also increases the efficiency of polling.

#Alternatively, if you do not need to wait on the task to complete, 
#you may run the task asynchronously by specifying a poll value of 0:

---

- hosts: all
  remote_user: root

  tasks:

  - name: simulate long running op, allow to run for 45 sec, fire and forget
    command: /bin/sleep 15
    async: 45
    poll: 0

#You shouldn't attempt run a task asynchronously by specifying a poll value of 0
#to with operations that require exclusive locks (such as yum transactions) 
#if you expect to run other commands later in the playbook against those same resources.



#If you would like to perform a task asynchronously 
#and check on it later you can perform a task similar to the following:

#If the value of async: is not high enough, this will cause the "check on it later" task to fail 
#because the temporary status file that the async_status: is looking for will not have been written or no longer exist

---
# Requires ansible 1.8+
- name: 'YUM - async task'
  yum:
    name: docker-io
    state: installed
  async: 1000
  poll: 0
  register: yum_sleeper

- name: 'YUM - check on async task'
  async_status:
    jid: "{{ yum_sleeper.ansible_job_id }}"
  register: job_result
  until: job_result.finished
  retries: 30


#If you would like to run multiple asynchronous tasks 
#while limiting the amount of tasks running concurrently

# main.yml

- name: Run items asynchronously in batch of two items
  vars:
    sleep_durations:
      - 1
      - 2
      - 3
      - 4
      - 5
    durations: "{{ item }}"
  include_tasks: execute_batch.yml
  loop:
    - "{{ sleep_durations | batch(2) | list }}"


# execute_batch.yml

- name: Async sleeping for batched_items
  command: sleep {{ async_item }}
  async: 45
  poll: 0
  loop: "{{ durations }}"
  loop_control:
    loop_var: "async_item"
  register: async_results

- name: Check sync status
  async_status:
    jid: "{{ async_result_item.ansible_job_id }}"
  loop: "{{ async_results.results }}"
  loop_control:
    loop_var: "async_result_item"
  register: async_poll_results
  until: async_poll_results.finished
  retries: 30

  
  
###Check Mode ("Dry Run")

#When ansible-playbook is executed with --check it will not make any changes on remote systems.
#Instead, any module instrumented to support 'check mode' 
#(which contains most of the primary core modules, but it is not required that all modules do this) 
#will report what changes they would have made rather than making them. 

#Other modules that do not support check mode will also take no action, 
#but just will not report what changes they might have made.

#Check mode is just a simulation, and if you have steps that use conditionals 
#that depend on the results of prior commands, it may be less useful for you. 
#However it is great for one-node-at-time basic configuration management use cases.

ansible-playbook foo.yml --check


##Enabling or disabling check mode for tasks
#Force a task to run in check mode, even when the playbook is called without --check. 
#This is called check_mode: yes.

#Force a task to run in normal mode and make changes to the system, even when the playbook is called with --check. 
#This is called check_mode: no.

#Prior to version 2.2 only the equivalent of check_mode: no existed. 
#The notation for that was always_run: yes.

#Instead of yes/no you can use a Jinja2 expression, just like the when clause.

tasks:
  - name: this task will make changes to the system even in check mode
    command: /something/to/run --even-in-check-mode
    check_mode: no

  - name: this task will always run under checkmode and not change the system
    lineinfile:
        line: "important config"
        dest: /path/to/myconfig.conf
        state: present
    check_mode: yes
    
    

##Information about check mode in variables
#If you want to skip, or ignore errors on some tasks in check mode 
#you can use a boolean magic variable ansible_check_mode which will be set to True during check mode.

tasks:
  - name: this task will be skipped in check mode
    git:
      repo: ssh://git@github.com/mylogin/hello.git
      dest: /home/mylogin/hello
    when: not ansible_check_mode

  - name: this task will ignore errors in check mode
    git:
      repo: ssh://git@github.com/mylogin/hello.git
      dest: /home/mylogin/hello
    ignore_errors: "{{ ansible_check_mode }}"

    
    
##Showing Differences with --diff
#The --diff option to ansible-playbook works great with --check 
# but can also be used by itself. 
#When this flag is supplied and the module supports this, 
#Ansible will report back the changes made 
#or, if used with --check, the changes that would have been made. 

#This is mostly used in modules that manipulate files (i.e. template) 
#but other modules might also show 'before and after' information (i.e. user). 

#Since the diff feature produces a large amount of output, 
#it is best used when checking a single host at a time. For example:
ansible-playbook foo.yml --check --diff --limit foo.example.com

#The --diff option can reveal sensitive information. 
#This option can disabled for tasks by specifying diff: no.

tasks:
  - name: this task will not report a diff when the file changes
    template:
      src: secret.conf.j2
      dest: /etc/secret.conf
      owner: root
      group: root
      mode: '0600'
    diff: no

    
    
###Playbook Debugger

#Ansible includes a debugger as part of the strategy plugins. 
#This debugger enables you to debug as task. 
#You have access to all of the features of the debugger in the context of the task. 

#You can then, for example, check or set the value of variables, 
#update module arguments, and re-run the task with the new variables 
#and arguments to help resolve the cause of the failure.


##Using the debugger keyword
#The debugger keyword can be used on any block where you provide a name attribute, 
#such as a play, role, block or task.

#The debugger keyword accepts several values:
always
    Always invoke the debugger, regardless of the outcome
never
    Never invoke the debugger, regardless of the outcome
on_failed
    Only invoke the debugger if a task fails
on_unreachable
    Only invoke the debugger if the a host was unreachable
on_skipped
    Only invoke the debugger if the task is skipped

#These options override any global configuration to enable or disable the debugger.


##On a task

- name: Execute a command
  command: false
  debugger: on_failed

##On a play

- name: Play
  hosts: all
  debugger: on_skipped
  tasks:
    - name: Execute a command
      command: true
      when: False

##When provided at a generic level and a more specific level, the more specific wins:
- name: Play
  hosts: all
  debugger: never
  tasks:
    - name: Execute a command
      command: false
      debugger: on_failed

##Configuration or environment variable
#In ansible.cfg:
[defaults]
enable_task_debugger = True

#As an environment variable:
ANSIBLE_ENABLE_TASK_DEBUGGER=True ansible-playbook -i hosts site.yml


##As a Strategy
#This is a backwards compatible method, to match Ansible versions before 2.5, 
#and may be removed in a future release

#To use the debug strategy, change the strategy attribute like this:
- hosts: test
  strategy: debug
  tasks:
  ...

#If you don't want change the code, 
#you can define ANSIBLE_STRATEGY=debug environment variable in order to enable the debugger, 
#or modify ansible.cfg such as:
[defaults]
strategy = debug

#For example, run the playbook below:

- hosts: test
  debugger: on_failed
  gather_facts: no
  vars:
    var1: value1
  tasks:
    - name: wrong variable
      ping: data={{ wrong_var }}

#The debugger is invoked since the wrong_var variable is undefined.


##Available Commands in debuger 
p(print) task/task_vars/host/result
    Print values used to execute a module:
#Example 
[192.0.2.10] TASK: install package (debug)> p task
TASK: install package
[192.0.2.10] TASK: install package (debug)> p task.args
{u'name': u'{{ pkg_name }}'}
[192.0.2.10] TASK: install package (debug)> p task_vars
{u'ansible_all_ipv4_addresses': [u'192.0.2.10'],
 u'ansible_architecture': u'x86_64',
 ...
}
[192.0.2.10] TASK: install package (debug)> p task_vars['pkg_name']
u'bash'
[192.0.2.10] TASK: install package (debug)> p host
192.0.2.10
[192.0.2.10] TASK: install package (debug)> p result._result
{'_ansible_no_log': False,
 'changed': False,
 u'failed': True,
 ...
 u'msg': u"No package matching 'not_exist' is available"}
 
##Available Commands in debuger
task.args[key] = value
    Update module's argument.

#If you run a playbook like this:

- hosts: test
  strategy: debug
  gather_facts: yes
  vars:
    pkg_name: not_exist
  tasks:
    - name: install package
      apt: name={{ pkg_name }}

#Debugger is invoked due to wrong package name, so let's fix the module's args:
[192.0.2.10] TASK: install package (debug)> p task.args
{u'name': u'{{ pkg_name }}'}
[192.0.2.10] TASK: install package (debug)> task.args['name'] = 'bash'
[192.0.2.10] TASK: install package (debug)> p task.args
{u'name': 'bash'}
[192.0.2.10] TASK: install package (debug)> redo #Then the task runs again with new args.

##Available Commands in debuger
task_vars[key] = value
    Update task_vars.

#Let's use the same playbook above, but fix task_vars instead of args:
[192.0.2.10] TASK: install package (debug)> p task_vars['pkg_name']
u'not_exist'
[192.0.2.10] TASK: install package (debug)> task_vars['pkg_name'] = 'bash'
[192.0.2.10] TASK: install package (debug)> p task_vars['pkg_name']
'bash'
[192.0.2.10] TASK: install package (debug)> redo #Then the task runs again with new task_vars.

##Available Commands in debuger
r(edo)
    Run the task again.
c(ontinue)
    Just continue.
q(uit)
    Quit from the debugger. The playbook execution is aborted.
    
    
    
###Delegation, Rolling Updates, and Local Actions

#Additional features allow for tuning the orders in which things complete, 
#and assigning a batch window size for how many machines to process at once 
#during a rolling update.

#Be aware that certain tasks are impossible to delegate, 
#i.e. include, add_host, debug, etc as they always execute on the controller.


##Rolling Update Batch Size
#By default, Ansible will try to manage all of the machines referenced in a play in parallel. 
#For a rolling update use case, you can define how many hosts Ansible should manage 
#at a single time by using the serial keyword:

- name: test play
  hosts: webservers
  serial: 2
  gather_facts: False
  tasks:
  - name: task one
    comand: hostname
  - name: task two
    command: hostname

#In the above example, if we had 4 hosts in the group 'webservers', 
#2 would complete the play completely before moving on to the next 2 hosts:


#The serial keyword can also be specified as a percentage, 
#which will be applied to the total number of hosts in a play, 
#in order to determine the number of hosts per pass:

- name: test play
  hosts: webservers
  serial: "30%"

#If the number of hosts does not divide equally into the number of passes, 
#the final pass will contain the remainder.

#As of Ansible 2.2, the batch sizes can be specified as a list, as follows:
- name: test play
  hosts: webservers
  serial:
  - 1
  - 5
  - 10

#In the above example, the first batch would contain a single host, 
#the next would contain 5 hosts, and (if there are any hosts left), 
#every following batch would contain 10 hosts until all available hosts are used.

#It is also possible to list multiple batch sizes as percentages:
- name: test play
  hosts: webservers
  serial:
  - "10%"
  - "20%"
  - "100%"

#You can also mix and match the values:
- name: test play
  hosts: webservers
  serial:
  - 1
  - 5
  - "20%"

  
##Maximum Failure Percentage
#By default, Ansible will continue executing actions as long as there are hosts in the batch that have not yet failed. 
#The batch size for a play is determined by the serial parameter. 
#If serial is not set, then batch size is all the hosts specified in the hosts: field. 

#In some situations, such as with the rolling updates described above, 
#it may be desirable to abort the play when a certain threshold of failures have been reached. 

#To achieve this, you can set a maximum failure percentage on a play as follows:

- hosts: webservers
  max_fail_percentage: 30
  serial: 10

#In the above example, if more than 3 of the 10 servers in the group were to fail, 
#the rest of the play would be aborted.
#The percentage set must be exceeded, not equaled. 




##Delegation
#If you want to perform a task on one host with reference to other hosts, 
#use the 'delegate_to' keyword on a task. 

#This is ideal for placing nodes in a load balanced pool, or removing them. 
#It is also very useful for controlling outage windows. 

#Be aware that it does not make sense to delegate all tasks, debug, add_host, include, etc always get executed on the controller. Using this with the 'serial' keyword to control the number of hosts executing at one time is also a good idea:

---

- hosts: webservers
  serial: 5

  tasks:

  - name: take out of load balancer pool
    command: /usr/bin/take_out_of_pool {{ inventory_hostname }}
    delegate_to: 127.0.0.1

  - name: actual steps would go here
    yum:
      name: acme-web-stack
      state: latest

  - name: add back to load balancer pool
    command: /usr/bin/add_back_to_pool {{ inventory_hostname }}
    delegate_to: 127.0.0.1

#These commands will run on 127.0.0.1, which is the machine running Ansible. 
#There is also a shorthand syntax that you can use on a per-task basis: 'local_action'. 
#Here is the same playbook as above, but using the shorthand syntax for delegating to 127.0.0.1:

---

# ...

  tasks:

  - name: take out of load balancer pool
    local_action: command /usr/bin/take_out_of_pool {{ inventory_hostname }}

# ...

  - name: add back to load balancer pool
    local_action: command /usr/bin/add_back_to_pool {{ inventory_hostname }}

#A common pattern is to use a local action to call 'rsync' 
#to recursively copy files to the managed servers

---
# ...
  tasks:

  - name: recursively copy files from management server to target
    local_action: command rsync -a /path/to/files {{ inventory_hostname }}:/path/to/target/

#Note that you must have passphrase-less SSH keys or an ssh-agent configured for this to work, 
#otherwise rsync will need to ask for a passphrase.

#In case you have to specify more arguments you can use the following syntax:

---
# ...
  tasks:

  - name: Send summary mail
    local_action:
      module: mail
      subject: "Summary Mail"
      to: "{{ mail_recipient }}"
      body: "{{ mail_body }}"
    run_once: True


    
    
##Delegated facts
#By default, any fact gathered by a delegated task are assigned to the inventory_hostname 
#(the current host) instead of the host which actually produced the facts 
#(the delegated to host). 

#The directive delegate_facts may be set to True to assign the task's gathered facts 
#to the delegated host instead of the current one.:

- hosts: app_servers
  tasks:
    - name: gather facts from db servers
      setup:
      delegate_to: "{{item}}"
      delegate_facts: True
      loop: "{{groups['dbservers']}}"

#The above will gather facts for the machines in the dbservers group 
#and assign the facts to those machines and not to app_servers. 
#This way you can lookup hostvars['dbhost1']['default_ipv4']['address'] 
#even though dbservers were not part of the play, or left out by using –limit.


##Run Once
#In some cases there may be a need to only run a task one time for a batch of hosts.
#This can be achieved by configuring "run_once" on a task:

---
# ...

  tasks:

    # ...

    - command: /opt/application/upgrade_db.py
      run_once: true

    # ...

#This directive forces the task to attempt execution on the first host in the current batch 
#and then applies all results and facts to all the hosts in the same batch.

#This approach is similar to applying a conditional to a task such as:

- command: /opt/application/upgrade_db.py
  when: inventory_hostname == webservers[0]

#But the results are applied to all the hosts.
#Like most tasks, this can be optionally paired with "delegate_to" to specify an individual host to execute on:

- command: /opt/application/upgrade_db.py
  run_once: true
  delegate_to: web01.example.org

#As always with delegation, the action will be executed on the delegated host, 
#but the information is still that of the original host in the task.

#When used together with "serial", tasks marked as "run_once" will be run on one host in each serial batch. 
#If it's crucial that the task is run only once regardless of "serial" mode, 
#use 
when: inventory_hostname == ansible_play_hosts[0] 

#Any conditional (i.e when:) will use the variables of the 'first host' 
#to decide if the task runs or not, no other hosts will be tested.



##Local Playbooks
#It may be useful to use a playbook locally, rather than by connecting over SSH. 

#This can be useful for assuring the configuration of a system 
#by putting a playbook in a crontab. 
#This may also be used to run a playbook inside an OS installer, such as an Anaconda kickstart.

#To run an entire playbook locally, set the "hosts:" line to "hosts: 127.0.0.1" 
#and then run the playbook like so:
ansible-playbook playbook.yml --connection=local

#Alternatively, a local connection can be used in a single playbook play, 
#even if other plays in the playbook use the default remote connection type:

- hosts: 127.0.0.1
  connection: local

@@@
##Interrupt execution on any error

#With the ''any_errors_fatal'' option, 
#any failure on any host in a multi-host play will be treated as fatal 
#and Ansible will exit immediately without waiting for the other hosts.

#For example, consider a service located in many datacenters with some load balancers to pass traffic from users to the service. 
#There is a deploy playbook to upgrade service deb-packages. The playbook has the stages:
    # disable traffic on load balancers (must be turned off simultaneously)
    # gracefully stop the service
    # upgrade software (this step includes tests and starting the service)
    # enable traffic on the load balancers (which should be turned on simultaneously)

#The service cant be stopped with "alive" load balancers; they must be disabled first. 
#Because of this, the second stage can't be played if any server failed in the first stage.

---
- hosts: load_balancers_dc_a
  any_errors_fatal: True
  tasks:
  - name: 'shutting down datacenter [ A ]'
    command: /usr/bin/disable-dc

- hosts: frontends_dc_a
  tasks:
  - name: 'stopping service'
    command: /usr/bin/stop-software
  - name: 'updating software'
    command: /usr/bin/upgrade-software

- hosts: load_balancers_dc_a
  tasks:
  - name: 'Starting datacenter [ A ]'
    command: /usr/bin/enable-dc


##Setting the Environment (and Working With Proxies)
#To configure  environment by using the 'environment' keyword. 

- hosts: all
  remote_user: root

  tasks:

    - apt: name=cobbler state=installed
      environment:
        http_proxy: http://proxy.example.com:8080

#The environment can also be stored in a variable, and accessed like so:

- hosts: all
  remote_user: root

  # here we make a variable named "proxy_env" that is a dictionary
  vars:
    proxy_env:
      http_proxy: http://proxy.example.com:8080

  tasks:

    - apt: name=cobbler state=installed
      environment: "{{proxy_env}}"

#use it at a play level:

- hosts: testhost

  roles:
     - php
     - nginx

  environment:
    http_proxy: http://proxy.example.com:8080

#The most logical place to define an environment hash might be a group_vars file

---
# file: group_vars/boston

ntp_server: ntp.bos.example.com
backup: bak.bos.example.com
proxy_env:
  http_proxy: http://proxy.bos.example.com:8080
  https_proxy: http://proxy.bos.example.com:8080

  
  
##Working With Language-Specific Version Managers
#Some language-specific version managers (such as rbenv and nvm) require environment variables 
#be set while these tools are in use. 

#When using these tools manually, they usually require sourcing some environment variables 
#via a script or lines added to your shell configuration file. 
#In Ansible, you can instead use the environment directive:

---
#A playbook demonstrating a common npm workflow:
# - Check for package.json in the application directory
# - If package.json exists:
#   * Run npm prune
#   * Run npm install

- hosts: application
  become: false

  vars:
    node_app_dir: /var/local/my_node_app

  environment:
    NVM_DIR: /var/local/nvm
    PATH: /var/local/nvm/versions/node/v4.2.1/bin:{{ ansible_env.PATH }}

  tasks:
  - name: check for package.json
    stat:
      path: '{{ node_app_dir }}/package.json'
    register: packagejson

  - name: npm prune
    command: npm prune
    args:
      chdir: '{{ node_app_dir }}'
    when: packagejson.stat.exists

  - name: npm install
    npm:
      path: '{{ node_app_dir }}'
    when: packagejson.stat.exists

#To simply specify the environment for a single task:

---
- name: install ruby 2.3.1
  command: rbenv install {{ rbenv_ruby_version }}
  args:
    creates: '{{ rbenv_root }}/versions/{{ rbenv_ruby_version }}/bin/ruby'
  vars:
    rbenv_root: /usr/local/rbenv
    rbenv_ruby_version: 2.3.1
  environment:
    CONFIGURE_OPTS: '--disable-install-doc'
    RBENV_ROOT: '{{ rbenv_root }}'
    PATH: '{{ rbenv_root }}/bin:{{ rbenv_root }}/shims:{{ rbenv_plugins }}/ruby-build/bin:{{ ansible_env.PATH }}'

    
    
###Error Handling In Playbooks

#Ansible normally has defaults that make sure to check the return codes of commands 
#and modules and it fails fast – forcing an error to be dealt with unless you decide otherwise.

#Sometimes a command that returns different than 0 isn't an error. 
#Sometimes a command might not always need to report that it 'changed' the remote system. 

##Ignoring Failed Commands
#Generally playbooks will stop executing any more steps on a host that has a task fail. 
#Sometimes, though, you want to continue on. 

- name: this will not be counted as a failure
  command: /bin/false
  ignore_errors: yes

##Resetting Unreachable Hosts
#Connection failures set hosts as 'UNREACHABLE', which will remove them from the list of active hosts for the run. 
#To recover from these issues you can use 
meta: clear_host_errors 
#to have all currently flagged hosts reactivated, so subsequent tasks can try to use them again.


##Handlers and Failure
#When a task fails on a host, handlers which were previously notified will not be run on that host. 
#This can lead to cases where an unrelated failure can leave a host in an unexpected state. 

#You can change this behavior with the --force-handlers command-line option, 
#or by including 
force_handlers: True 
#in a play, or 
force_handlers = True 
#in ansible.cfg. 
#When handlers are forced, they will run when notified even if a task fails on that host. 
#(Note that certain errors could still prevent the handler from running, such as a host becoming unreachable.)


##Controlling What Defines Failure

- name: Fail task when the command error output prints FAILED
  command: /usr/bin/example-command -x -y -z
  register: command_result
  failed_when: "'FAILED' in command_result.stderr"

#or based on the return code:

- name: Fail task when both files are identical
  raw: diff foo/file1 bar/file2
  register: diff_cmd
  failed_when: diff_cmd.rc == 0 or diff_cmd.rc >= 2

#In previous version of Ansible, this can still be accomplished as follows:

- name: this command prints FAILED when it fails
  command: /usr/bin/example-command -x -y -z
  register: command_result
  ignore_errors: True

- name: fail the play if the previous command did not succeed
  fail:
    msg: "the command failed"
  when: "'FAILED' in command_result.stderr"

  
##Overriding The Changed Result
#When a shell/command or other module runs it will typically report "changed" status 
#based on whether it thinks it affected machine state.

#To override the "changed" result such that it does not appear in report output 
#or does not cause handlers to fire:

tasks:

  - shell: /usr/bin/billybass --mode="take me to the river"
    register: bass_result
    changed_when: "bass_result.rc != 2"

  # this will never report 'changed' status
  - shell: wall 'beep'
    changed_when: False

    
    
##Aborting the play
#To abort the entire play on failure, not just skip remaining tasks for a host.

#The any_errors_fatal play option will mark all hosts as failed if any fails, 
#causing an immediate abort:

- hosts: somehosts
  any_errors_fatal: true
  roles:
    - myrole

#for finer-grained control 
max_fail_percentage 
#can be used to abort the run after a given percentage of hosts has failed.



###Advanced Syntax


##Unsafe or Raw Strings
#Ansible provides an internal data type for declaring variable values as "unsafe". 
#This means that the data held within the variables value should be treated as unsafe preventing unsafe character subsitition and information disclosure.

#Jinja2 contains functionality for escaping, or telling Jinja2 to not template data 
#by means of functionality such as {% raw %} ... {% endraw %}, 
#however this uses a more comprehensive implementation to ensure 
#that the value is never templated.

#Using YAML tags, you can also mark a value as "unsafe" by using the !unsafe tag such as:

---
my_unsafe_variable: !unsafe 'this variable has {{ characters that should not be treated as a jinja2 template'

#In a playbook, this may look like:

---
hosts: all
vars:
    my_unsafe_variable: !unsafe 'unsafe value'
tasks:
    ...

#For complex variables such as hashes or arrays, 
#!unsafe should be used on the individual elements such as:

---
my_unsafe_array:
    - !unsafe 'unsafe element'
    - 'safe element'

my_unsafe_hash:
    unsafe_key: !unsafe 'unsafe value'

    
    


###Working With Plugins - Action Plugins - prerequiste of module's actual functionality 
#Action plugins act in conjunction with modules to execute the actions required by playbook tasks. 
#They usually execute automatically in the background doing prerequisite work before modules execute.

#The 'normal' action plugin is used for modules that do not already have an action plugin.

##Enabling Action Plugins
#You can enable a custom action plugin by either dropping it into 
#the action_plugins directory adjacent to your play, inside a role, 
#or by putting it in one of the action plugin directory sources configured in ansible.cfg.


##Using Action Plugins
#Action plugin are executed by default when an associated module is used; 
#no action is required.


##Plugin List
ansible-doc -t action -l #to see the list of available plugins. 
ansible-doc -t action <plugin name> #to see specific documentation and examples.



###Working With Plugins - Cache Plugins
#Cache plugin implement a backend caching mechanism that allows Ansible 
#to store gathered facts or inventory source data without the performance hit of retrieving them from source.

#The default cache plugin is the memory plugin, 
#which only caches the data for the current execution of Ansible. 
#Other plugins with persistent storage are available to allow caching the data across runs.

#You can use a separate cache plugin for inventory and facts. 
#If an inventory-specific cache plugin is not provided and inventory caching is enabled, 
#the fact cache plugin is used for inventory.


##Enabling Fact Cache Plugins
#Only one fact cache plugin can be active at a time.

export ANSIBLE_CACHE_PLUGIN=jsonfile

#or in the ansible.cfg file:
[defaults]
fact_caching=redis

#You will also need to configure other settings specific to each plugin. 
#Consult the individual plugin documentation or the Ansible configuration for more details.

#A custom cache plugin is enabled by dropping it into a cache_plugins directory adjacent 
#to your play, inside a role, 
#or by putting it in one of the directory sources configured in ansible.cfg.


##Enabling Inventory Cache Plugins
#Inventory may be cached using a file-based cache plugin (like jsonfile). 

#The inventory cache is disabled by default. 
#You may enable it via environment variable:

export ANSIBLE_INVENTORY_CACHE=True

#or in the ansible.cfg file:

[inventory]
cache=True

#or if the inventory plugin accepts a YAML configuration source, in the configuration file:
# dev.aws_ec2.yaml
plugin: aws_ec2
cache: True

#Similarly with fact cache plugins, only one inventory cache plugin can be active at a time 
#and may be set via environment variable:

export ANSIBLE_INVENTORY_CACHE_PLUGIN=jsonfile

#or in the ansible.cfg file:

[inventory]
cache_plugin=jsonfile

#or if the inventory plugin accepts a YAML configuration source, in the configuration file:

# dev.aws_ec2.yaml
plugin: aws_ec2
cache_plugin: jsonfile

##Plugin List
ansible-doc -t cache -l #to see the list of available plugins. 
ansible-doc -t cache <plugin name> #to see specific documentation and examples.

##Available list 
jsonfile – JSON formatted files.
memcached – Use memcached DB for cache
memory – RAM backed, non persistent
mongodb – Use MongoDB for caching
pickle – Pickle formatted files.
redis – Use Redis DB for cache
yaml – YAML formatted files.


###Working With Plugins - Callback Plugins
#Callback plugins enable adding new behaviors to Ansible when responding to events. 
#By default, callback plugins control most of the output you see when running the command line programs, 
#but can also be used to add additional output, integrate with other tools and marshall the events to a storage backend.


##Enabling Callback Plugins
#You can activate a custom callback by either dropping it into a callback_plugins directory adjacent to your play, inside a role, 
#or by putting it in one of the callback directory sources configured in ansible.cfg.

#Plugins are loaded in alphanumeric order. 
#For example, a plugin implemented in a file named 1_first.py would run 
#before a plugin file named 2_second.py.

#Most callbacks shipped with Ansible are disabled by default 
#and need to be whitelisted in your ansible.cfg file in order to function

callback_whitelist = timer, mail, profile_roles

##Managing stdout
#You can only have one plugin be the main manager of your console output. 
#If you want to replace the default, 
#you should define CALLBACK_TYPE = stdout in the subclass 
#and then configure the stdout plugin in ansible.cfg
stdout_callback = dense

#or for my custom callback:
stdout_callback = mycallback

##Managing AdHoc
#The ansible ad hoc command specifically uses a different callback plugin for stdout, 
#so there is an extra setting in Ansible Configuration Settings you need to add 
#to use the stdout callback defined above:

[defaults]
bin_ansible_callbacks=True

#You can also set this as an environment variable:

export ANSIBLE_LOAD_CALLBACK_PLUGINS=1

##Plugin List
ansible-doc -t callback -l #to see the list of available plugins. 
ansible-doc -t callback <plugin name> #to see specific documents and examples.

##Available plugins 
actionable – shows only items that need attention
cgroup_memory_recap – Profiles maximum memory usage of tasks and full execution using cgroups
context_demo – demo callback that adds play/task context
counter_enabled – adds counters to the output items (tasks and hosts/task)
debug – formatted stdout/stderr display
default – default Ansible screen output
dense – minimal stdout output
foreman – Sends events to Foreman
full_skip – suppresses tasks if all hosts skipped
grafana_annotations – send ansible events as annotations on charts to grafana over http api.
hipchat – post task events to hipchat
jabber – post task events to a jabber server
json – Ansible screen output as JSON
junit – write playbook output to a JUnit file.
log_plays – write playbook output to log file
logdna – Sends playbook logs to LogDNA
logentries – Sends events to Logentries
logstash – Sends events to Logstash
mail – Sends failure events via email
minimal – minimal Ansible screen output
null – Don't display stuff to screen
oneline – oneline Ansible screen output
osx_say – oneline Ansible screen output
profile_roles – adds timing information to roles
profile_tasks – adds time information to tasks
selective – only print certain tasks
skippy – Ansible screen output that ignores skipped status
slack – Sends play events to a Slack channel
splunk – Sends task result events to Splunk HTTP Event Collector
stderr – Splits output, sending failed tasks to stderr
sumologic – Sends task result events to Sumologic
syslog_json – sends JSON events to syslog
timer – Adds time to play stats
tree – Save host events to files
unixy – condensed Ansible output
yaml – yaml-ized Ansible screen output


##Details 
timer – Adds time to play stats 
    This callback just adds total play duration to the play stats.
    
mail – Sends failure events via email   
    anisble.cfg entries:
        [callback_mail]
        bcc = VALUE
        cc = VALUE
        smtphost = localhost #env:SMTPHOST
        smtpport = 25
        sender = VALUE
        to = root

    
###Working With Plugins - Connection Plugins
#Connection plugins allow Ansible to connect to the target hosts so it can execute tasks on them. 

#Ansible ships with many connection plugins, but only one can be used per host at a time.

#By default, Ansible ships with several plugins. 
#The most commonly used are the paramiko SSH, native ssh (just called ssh), 
#and local connection types. 

#All of these can be used in playbooks and with /usr/bin/ansible 
#to decide how you want to talk to remote machines.

##ssh Plugins
#Because ssh is the default protocol used in system administration 
#and the protocol most used in Ansible, ssh options are included in the command line tools. 


##Enabling Connection Plugins
#You can extend Ansible to support other transports (such as SNMP or message bus) 
#by dropping a custom plugin into the connection_plugins directory.


##Using Connection Plugins
#The transport can be changed via configuration, at the command line (-c, --connection), 
#as a 'connection' keyword in your play, or by setting a variable, most often in your inventory. 
#For example, for Windows machines you might want to use the winrm plugin.

#Most connection plugins can operate with a minimum configuration. 
#By default they use the inventory hostname and defaults to find the target host.

#The following are connection variables common to most connection plugins:
ansible_host
    The name of the host to connect to, if different from the inventory hostname.
ansible_port
    The ssh port number, for ssh and paramiko_ssh it defaults to 22.
ansible_user
    The default user name to use for log in. Most plugins default to the 'current user running Ansible'.

##Plugin List
ansible-doc -t connection -l #to see the list of available plugins. 
ansible-doc -t connection <plugin name> #to see detailed documentation and examples.

##Available plugins 
buildah – Interact with an existing buildah container
chroot – Interact with local chroot
docker – Run tasks in docker containers
funcd – Use funcd to connect to target
httpapi – Use httpapi to run command on network appliances
iocage – Run tasks in iocage jails
jail – Run tasks in jails
kubectl – Execute tasks in pods running on Kubernetes.
libvirt_lxc – Run tasks in lxc containers via libvirt
local – execute on controller
lxc – Run tasks in lxc containers via lxc python library
lxd – Run tasks in lxc containers via lxc CLI
netconf – Provides a persistent connection using the netconf protocol
network_cli – Use network_cli to run command on network appliances
oc – Execute tasks in pods running on OpenShift.
paramiko_ssh – Run tasks via python ssh (paramiko)
persistent – Use a persistent unix socket for connection
psrp – Run tasks over Microsoft PowerShell Remoting Protocol
saltstack – Allow ansible to piggyback on salt minions
ssh – connect via ssh client binary
winrm – Run tasks over Microsoft's WinRM
zone – Run tasks in a zone instance



###Working With Plugins - Inventory Plugins
#Inventory plugins allow users to point at data sources to compile the inventory of hosts 
#that Ansible uses to target tasks, either via the -i /path/to/file 
#and/or -i 'host1, host2' command line parameters or from other configuration sources.


##Enabling Inventory Plugins
#Most inventory plugins shipped with Ansible are disabled by default 
#and need to be whitelisted in your ansible.cfg file in order to function. 

[inventory]
enable_plugins = host_list, script, yaml, ini, auto

#This list also establishes the order in which each plugin tries to parse an inventory source. 
#Any plugins left out of the list will not be considered, 
#so you can 'optimize' your inventory loading by minimizing it to what you actually use. 

#For example:

[inventory]
enable_plugins = advanced_host_list, constructed, yaml

##Using Inventory Plugins
#The only requirement for using an inventory plugin after it is enabled is 
#to provide an inventory source to parse. 
#Ansible will try to use the list of enabled inventory plugins, 
#in order, against each inventory source provided. 
#Once an inventory plugin succeeds at parsing a source, 
#any remaining inventory plugins will be skipped for that source.

#To start using an inventory plugin with a YAML configuration source, 
#create a file with the accepted filename schema for the plugin in question, 
#then add plugin: plugin_name. 
#Each plugin documents any naming restrictions. 
#For example, the aws_ec2 inventory plugin:

# demo.aws_ec2.yml
plugin: aws_ec2

#Or for the openstack plugin:

# clouds.yml
plugin: openstack

#The auto inventory plugin is enabled by default 
#and works by using the plugin field to indicate the plugin that should attempt to parse it. 
#You can configure the whitelist/precedence of inventory plugins used to parse source 
#using the ansible.cfg ['inventory'] enable_plugins list. 

#After enabling the plugin and providing any required options 
#you can view the populated inventory with 
ansible-inventory -i demo.aws_ec2.yml --graph
#Output 
@all:
  |--@aws_ec2:
  |  |--ec2-12-345-678-901.compute-1.amazonaws.com
  |  |--ec2-98-765-432-10.compute-1.amazonaws.com
  |--@ungrouped:

#You can set the default inventory path (via inventory in the ansible.cfg [defaults] section 
#or the ANSIBLE_HOSTS environment variable) to your inventory source(s). 

#Now running ansible-inventory --graph should yield the same output 
#as when you passed your YAML configuration source(s) directly. 
#You can add custom inventory plugins to your plugin path to use in the same way.

#Your inventory source might be a directory of inventory configuration files. 
#The constructed inventory plugin only operates on those hosts already in inventory, 
#so you may want the constructed inventory configuration parsed at a particular point 
#Ansible parses the directory recursively, alphabetically. 
#You cannot configure the parsing approach, so name your files to make it work predictably. 

#Inventory plugins that extend constructed features directly can work around 
#that restriction by adding constructed options in addition to the inventory plugin options. 
#Otherwise, you can use -i with multiple sources to impose a specific order, 
-i demo.aws_ec2.yml -i clouds.yml -i constructed.yml.

#You can create dynamic groups using host variables with the constructed keyed_groups option. 
#The option groups can also be used to create groups and compose creates 
#and modifies host variables. 
#Here is an aws_ec2 example utilizing constructed features:

# demo.aws_ec2.yml
plugin: aws_ec2
regions:
  - us-east-1
  - us-east-2
keyed_groups:
  # add hosts to tag_Name_value groups for each aws_ec2 host's tags.Name variable
  - key: tags.Name
    prefix: tag_Name_
    separator: ""
groups:
  # add hosts to the group development if any of the dictionary's keys or values is the word 'devel'
  development: "'devel' in (tags|list)"
compose:
  # set the ansible_host variable to connect with the private IP address without changing the hostname
  ansible_host: private_ip_address

#Now the output of ansible-inventory -i demo.aws_ec2.yml --graph:

@all:
  |--@aws_ec2:
  |  |--ec2-12-345-678-901.compute-1.amazonaws.com
  |  |--ec2-98-765-432-10.compute-1.amazonaws.com
  |  |--...
  |--@development:
  |  |--ec2-12-345-678-901.compute-1.amazonaws.com
  |  |--ec2-98-765-432-10.compute-1.amazonaws.com
  |--@tag_Name_ECS_Instance:
  |  |--ec2-98-765-432-10.compute-1.amazonaws.com
  |--@tag_Name_Test_Server:
  |  |--ec2-12-345-678-901.compute-1.amazonaws.com
  |--@ungrouped

##Plugin List
ansible-doc -t inventory -l #to see the list of available plugins. 
ansible-doc -t inventory <plugin name> #to see plugin-specific documentation and examples.
##Available plugins 
advanced_host_list – Parses a 'host list' with ranges
auto – Loads and executes an inventory plugin specified in a YAML config
aws_ec2 – ec2 inventory source
aws_rds – rds instance source
azure_rm – Azure Resource Manager inventory plugin
constructed – Uses Jinja2 to construct vars and groups based on existing inventory.
foreman – foreman inventory source
gcp_compute – Google Cloud Compute Engine inventory source
generator – Uses Jinja2 to construct hosts and groups from patterns
host_list – Parses a 'host list' string
ini – Uses an Ansible INI file as inventory source.
k8s – Kubernetes (K8s) inventory source
nmap – Uses nmap to find hosts to target
openshift – OpenShift inventory source
openstack – OpenStack inventory source
scaleway – Scaleway inventory source
script – Executes an inventory script that returns JSON
tower – Ansible dynamic inventory plugin for Ansible Tower.
virtualbox – virtualbox inventory source
vmware_vm_inventory – VMware Guest inventory source
vultr – Vultr inventory source
yaml – Uses a specific YAML file as an inventory source.

    
    
###Working With Plugins - Lookup Plugins

##Lookup plugins allow Ansible to access data from outside sources. 
#This can include reading the filesystem in addition to contacting external datastores and services. 

#Like all templating, these plugins are evaluated on the Ansible control machine, 
#not on the target/remote.

#The data returned by a lookup plugin is made available 
#using the standard templating system in Ansible, 
#and are typically used to load variables or templates with information from those systems.

#Lookups are an Ansible-specific extension to the Jinja2 templating language.

#Lookups are executed with a working directory relative to the role or play, 
#as opposed to local tasks, which are executed relative the executed script.
    
#Since Ansible version 1.9, you can pass wantlist=True to lookups to use in Jinja2 template "for" loops.
    
#Some lookups pass arguments to a shell. When using variables from a remote/untrusted source, use the |quote filter to ensure safe usage.

##Enabling Lookup Plugins
#You can activate a custom lookup by either dropping it into a lookup_plugins directory adjacent to your play, inside a role, 
#or by putting it in one of the lookup directory sources configured in ansible.cfg.


##Using Lookup Plugins
#Lookup plugins can be used anywhere you can use templating in Ansible: 
#in a play, in variables file, or in a Jinja2 template for the template module.

vars:
  file_contents: "{{lookup('file', 'path/to/file.txt')}}"

#Lookups are an integral part of loops. 
#Wherever you see with_, the part after the underscore is the name of a lookup. 

#This is also the reason most lookups output lists and take lists as input; 
#for example, with_items uses the items lookup:

tasks:
  - name: count to 3
    debug: msg={{item}}
    with_items: [1, 2, 3]

#You can combine lookups with Filters, Tests and even each other 
#to do some complex data generation and manipulation

tasks:
  - name: valid but useless and over complicated chained lookups and filters
    debug: msg="find the answer here:\n{{ lookup('url', 'https://google.com/search/?q=' + item|urlencode)|join(' ') }}"
    with_nested:
      - "{{lookup('consul_kv', 'bcs/' + lookup('file', '/the/question') + ', host=localhost, port=2000')|shuffle}}"
      - "{{lookup('sequence', 'end=42 start=2 step=2')|map('log', 4)|list)}}"
      - ['a', 'c', 'd', 'c']

#You can now control how errors behave in all lookup plugins by setting errors to ignore, warn, or strict. 
#The default setting is strict, which causes the task to fail. 

#To ignore errors:

- name: file doesnt exist, but i dont care .. file plugin itself warns anyways ...
  debug: msg="{{ lookup('file', '/idontexist', errors='ignore') }}"

[WARNING]: Unable to find '/idontexist' in expected paths (use -vvvvv to see paths)

ok: [localhost] => {
    "msg": ""
}

#To get a warning instead of a failure:

- name: file doesnt exist, let me know, but continue
  debug: msg="{{ lookup('file', '/idontexist', errors='warn') }}"

[WARNING]: Unable to find '/idontexist' in expected paths (use -vvvvv to see paths)

[WARNING]: An unhandled exception occurred while running the lookup plugin 'file'. Error was a <class 'ansible.errors.AnsibleError'>, original message: could not locate file in lookup: /idontexist

ok: [localhost] => {
    "msg": ""
}

#Fatal error (the default):

- name: file doesnt exist, FAIL (this is the default)
  debug: msg="{{ lookup('file', '/idontexist', errors='strict') }}"

[WARNING]: Unable to find '/idontexist' in expected paths (use -vvvvv to see paths)

fatal: [localhost]: FAILED! => {"msg": "An unhandled exception occurred while running the lookup plugin 'file'. Error was a <class 'ansible.errors.AnsibleError'>, original message: could not locate file in lookup: /idontexist"}



##query
#In Ansible 2.5, a new jinja2 function called query was added for invoking lookup plugins. 
#The difference between lookup and query is largely that query will always return a list. 

#The default behavior of lookup is to return a string of comma separated values. 
#lookup can be explicitly configured to return a list using wantlist=True.

#This was done primarily to provide an easier and more consistent interface 
#for interacting with the new loop keyword, while maintaining backwards compatibiltiy with other uses of lookup.

#The following examples are equivalent:
lookup('dict', dict_variable, wantlist=True)
query('dict', dict_variable) #wantlist =True is implicit 

#Additionally, q was introduced as a shortform of query:
q('dict', dict_variable)

##Plugin List
ansible-doc -t lookup -l #to see the list of available plugins. 
ansible-doc -t lookup <plugin name> #to see specific documents and examples.

##Available plugins 
aws_account_attribute – Look up AWS account attributes.
aws_service_ip_ranges – Look up the IP ranges for services provided in AWS such as EC2 and S3.
aws_ssm – Get the value for a SSM parameter or all parameters under a path.
cartesian – returns the cartesian product of lists
chef_databag – fetches data from a Chef Databag
config – Lookup current Ansible configuration values
conjur_variable – Fetch credentials from CyberArk Conjur.
consul_kv – Fetch metadata from a Consul key value store.
cpm_metering – Get Power and Current data from WTI OOB/Combo and PDU devices
cpm_status – Get status and parameters from WTI OOB and PDU devices.
credstash – retrieve secrets from Credstash on AWS
csvfile – read data from a TSV or CSV file
cyberarkpassword – get secrets from CyberArk AIM
dict – returns key/value pair items from dictionaries
dig – query DNS using the dnspython library
dnstxt – query a domain(s)'s DNS txt fields
env – read the value of environment variables
etcd – get info from an etcd server
file – read file contents
fileglob – list files matching a pattern
filetree – recursively match all files in a directory tree
first_found – return first file found from list
flattened – return single list completely flattened
grafana_dashboard – list or search grafana dashboards
hashi_vault – retrieve secrets from HashiCorp's vault
hiera – get info from hiera data
indexed_items – rewrites lists to return 'indexed items'
ini – read data from a ini file
inventory_hostnames – list of inventory hosts matching a host pattern
items – list of items
k8s – Query the K8s API
keyring – grab secrets from the OS keyring
lastpass – fetch data from lastpass
lines – read lines from command
list – simply returns what it is given.
mongodb – lookup info from MongoDB
nested – composes a list with nested elements of other lists
nios – Query Infoblox NIOS objects
nios_next_ip – Return the next available IP address for a network
nios_next_network – Return the next available network range for a network-container
onepassword – fetch field values from 1Password
onepassword_raw – fetch raw json data from 1Password
password – retrieve or generate a random password, stored in a file
passwordstore – manage passwords with passwordstore.org's pass utility
pipe – read output from a command
random_choice – return random element from list
redis – fetch data from Redis
redis_kv – fetch data from Redis
sequence – generate a list based on a number sequence
shelvefile – read keys from Python shelve file
subelements – traverse nested key from a list of dictionaries
template – retrieve contents of file after templating with Jinja2
together – merges lists into synchronized list
url – return contents from URL
vars – Lookup templated value of variables
    
    
###Lookup Plugins - cartesian – returns the cartesian product of lists

- name: Example of the change in the description
  debug: msg="{{ [1,2,3]|lookup('cartesian', [a, b])}}"

- name: loops over the cartesian product of the supplied lists
  debug: msg="{{item}}"
  with_cartesian:
    - "{{list1}}"
    - "{{list2}}"
    - [1,2,3,4,5,6]


###Lookup Plugins - config – Lookup current Ansible configuration values
#Retrieves the value of an Ansible configuration setting.
#You can use ansible-config list to see all available settings.

- name: Show configured default become user
  debug: msg="{{ lookup('config', 'DEFAULT_BECOME_USER')}}"

- name: print out role paths
  debug:
    msg: "These are the configured role paths: {{lookup('config', 'DEFAULT_ROLES_PATH')}}"

- name: find retry files, skip if missing that key
  find:
    paths: "{{lookup('config', 'RETRY_FILES_SAVE_PATH')|default(playbook_dir, True)}}"
    patterns: "*.retry"

- name: see the colors
  debug: msg="{{item}}"
  loop: "{{lookup('config', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP', wantlist=True)}}"

- name: skip if bad value in var
  debug: msg="{{ lookup('config', config_in_var, on_missing='skip')}}"
  var:
    config_in_var: UNKNOWN

    

###Lookup Plugins - csvfile – read data from a TSV or CSV file
#The csvfile lookup reads the contents of a file in CSV (comma-separated value) format. 
#The lookup looks for the row where the first column matches keyname, 
#and returns the value in the second column, unless a different column is specified.
#The default is for TSV files (tab delimited) not CSV (comma delimited) 


- name:  Match 'Li' on the first column, return the second column (0 based index)
  debug: msg="The atomic number of Lithium is {{ lookup('csvfile', 'Li file=elements.csv delimiter=,') }}"

- name: msg="Match 'Li' on the first column, but return the 3rd column (columns start counting after the match)"
  debug: msg="The atomic mass of Lithium is {{ lookup('csvfile', 'Li file=elements.csv delimiter=, col=2') }}"

###Lookup Plugins - nested – composes a list with nested elements of other lists
#Takes the input lists and returns a list with elements 
#that are lists composed of the elements of the input lists


- name: give users access to multiple databases
  mysql_user:
    name: "{{ item[0] }}"
    priv: "{{ item[1] }}.*:ALL"
    append_privs: yes
    password: "foo"
  with_nested:
    - [ 'alice', 'bob' ]
    - [ 'clientdb', 'employeedb', 'providerdb' ]
# As with the case of 'with_items' above, you can use previously defined variables.:

- name: here, 'users' contains the above list of employees
  mysql_user:
    name: "{{ item[0] }}"
    priv: "{{ item[1] }}.*:ALL"
    append_privs: yes
    password: "foo"
  with_nested:
    - "{{ users }}"
    - [ 'clientdb', 'employeedb', 'providerdb' ]


###Lookup Plugins - dict – returns key/value pair items from dictionaries
#Takes dictionaries as input and returns a list with each item in the list 
#being a dictionary with 'key' and 'value' as keys to the previous dictionary's structure.


vars:
  users:
    alice:
      name: Alice Appleworth
      telephone: 123-456-7890
    bob:
      name: Bob Bananarama
      telephone: 987-654-3210
tasks:
  # with predefined vars
  - name: Print phone records
    debug:
      msg: "User {{ item.key }} is {{ item.value.name }} ({{ item.value.telephone }})"
    loop: "{{ lookup('dict', users) }}"
  # with inline dictionary
  - name: show dictionary
    debug:
      msg: "{{item.key}}: {{item.value}}"
    with_dict: {a: 1, b: 2, c: 3}
  # Items from loop can be used in when: statements
  - name: set_fact when alice in key
    set_fact:
      alice_exists: true
    loop: "{{ lookup('dict', users) }}"
    when: "'alice' in item.key"


###Lookup Plugins - env – read the value of environment variables
#Allows you to query the environment variables available on the controller 
#when you invoked Ansible.

- debug: msg="{{ lookup('env','HOME') }} is an environment variable"



###Lookup Plugins - file – read file contents
#This lookup returns the contents from a file on the Ansible controller's file system.
#if read in variable context, the file can be interpreted as YAML if the content is valid to the parser.
#this lookup does not understand 'globing', use the fileglob lookup instead.


- debug: msg="the value of foo.txt is {{lookup('file', '/etc/foo.txt') }}"

- name: display multiple file contents
  debug: var=item
  with_file:
    - "/path/to/foo.txt"
    - "bar.txt"  # will be looked in files/ dir relative to play or in role
    - "/path/to/biz.txt"

    
###Lookup Plugins - fileglob – list files matching a pattern
#Matches all files in a single directory, non-recursively, that match a pattern. 
#It calls Python's "glob" library.
#Patterns are only supported on files, not directory/paths.
#Matching is against local system files.


- name: display content of all .txt files in dir
  debug: msg={{lookup('fileglob', '/my/path/*.txt')}}

- name: Copy each file over that matches the given pattern
  copy:
    src: "{{ item }}"
    dest: "/etc/fooapp/"
    owner: "root"
    mode: 0600
  with_fileglob:
    - "/playbooks/files/fooapp/*"

###Lookup Plugins - filetree – recursively match all files in a directory tree
#This lookup enables you to template a complete tree of files on a target system while retaining permissions and ownership.
#Supports directories, files and symlinks, including SELinux and other file properties
#If you provide more than one path, it will implement a with_first_found logic, and will not process entries it already processed in previous paths. This enables merging different trees in order of importance, or add role_vars to specific paths to influence different instances of the same role.



- name: Create directories
  file:
    path: /web/{{ item.path }}
    state: directory
    mode: '{{ item.mode }}'
  with_filetree: web/
  when: item.state == 'directory'

- name: Template files
  template:
    src: '{{ item.src }}'
    dest: /web/{{ item.path }}
    mode: '{{ item.mode }}'
  with_filetree: web/
  when: item.state == 'file'

- name: Recreate symlinks
  file:
    src: '{{ item.src }}'
    dest: /web/{{ item.path }}
    state: link
    force: yes
    mode: '{{ item.mode }}'
  with_filetree: web/
  when: item.state == 'link'

###Lookup Plugins - first_found – return first file found from list
#this lookup checks a list of files and paths and returns the full path to the first combination found.
#As all lookups, when fed relative paths it will try use the current task's location first and go up the chain to the containing role/play/include/etc's location.
#The list of files has precedence over the paths searched. i.e, A task in a role has a 'file1' in the play's relative path, this will be used, 'file2' in role's relative path will not.


- name: show first existing file
  debug: msg={{lookup('first_found', findme)}}
  vars:
    findme:
      - "/path/to/foo.txt"
      - "bar.txt"  # will be looked in files/ dir relative to role and/or play
      - "/path/to/biz.txt"

- name: |
        copy first existing file found to /some/file,
        looking in relative directories from where the task is defined and
        including any play objects that contain it
  copy: src={{lookup('first_found', findme)}} dest=/some/file
  vars:
    findme:
      - foo
      - "{{inventory_hostname}}"
      - bar

- name: same copy but specific paths
  copy: src={{lookup('first_found', params)}} dest=/some/file
  vars:
    params:
      files:
        - foo
        - "{{inventory_hostname}}"
        - bar
      paths:
        - /tmp/production
        - /tmp/staging

- name: INTERFACES | Create Ansible header for /etc/network/interfaces
  template:
    src: "{{ lookup('first_found', findme)}}"
    dest: "/etc/foo.conf"
  vars:
    findme:
      - "{{ ansible_virtualization_type }}_foo.conf"
      - "default_foo.conf"

- name: read vars from first file found, use 'vars/' relative subdir
  include_vars: "{{lookup('first_found', params)}}"
  vars:
    params:
      files:
        - '{{ansible_os_distribution}}.yml'
        - '{{ansible_os_family}}.yml'
        - default.yml
      paths:
        - 'vars'



###Lookup Plugins - flattened – return single list completely flattened
#given one or more lists, this lookup will flatten any list elements found recursively until only 1 list is left.
#unlike 'items' which only flattens 1 level, this plugin will continue to flatten until it cannot find lists anymore.
#aka highlander plugin, there can only be one (list).

- name: "'unnest' all elements into single list"
  debug: msg="all in one list {{lookup('flattened', [1,2,3,[5,6]], [a,b,c], [[5,6,1,3], [34,a,b,c]])}}"


###Lookup Plugins - indexed_items – rewrites lists to return 'indexed items'
#use this lookup if you want to loop over an array and also get the numeric index of where you are in the array as you go
#any list given will be transformed with each resulting element having the it's previous position in item.0 and its value in item.1


- name: indexed loop demo
  debug:
    msg: "at array position {{ item.0 }} there is a value {{ item.1 }}"
  with_indexed_items:
    - "{{ some_list }}"


###Lookup Plugins - ini – read data from a ini file
#The ini lookup reads the contents of a file in INI format key1=value1. This plugin retrieve the value on the right side after the equal sign '=' of a given section [section].
#You can also read a property file which - in this case - does not contain section.


- debug: msg="User in integration is {{ lookup('ini', 'user section=integration file=users.ini') }}"
- debug: msg="User in production  is {{ lookup('ini', 'user section=production  file=users.ini') }}"

- debug: msg="user.name is {{ lookup('ini', 'user.name type=properties file=user.properties') }}"

- debug:
    msg: "{{ item }}"
  with_ini:
    - value[1-2]
    - section: section1
    - file: "lookup.ini"
    - re: true


###Lookup Plugins - inventory_hostnames – list of inventory hosts matching a host pattern
#This lookup understands 'host patterns' as used by the hosts: keyword in plays and can return a list of matching hosts from inventory
#this is only worth for 'hostname patterns' it is easier to loop over the group/group_names variables otherwise.


- name: show all the hosts matching the pattern, i.e. all but the group www
  debug:
    msg: "{{ item }}"
  with_inventory_hostnames:
    - all:!www


###Lookup Plugins - items – list of items
#this lookup returns a list of items given to it, if any of the top level items is also a list it will flatten it, but it will not recurse
#this is the standard lookup used for loops in most examples
#check out the 'flattened' lookup for recursive flattening
#if you do not want flattening nor any other transformation look at the 'list' lookup.


- name: "loop through list"
  debug:
    msg: "An item: {{item}}"
  with_items:
    - 1
    - 2
    - 3

- name: add several users
  user:
    name: "{{ item }}"
    groups: "wheel"
    state: present
  with_items:
     - testuser1
     - testuser2

- name: "loop through list from a variable"
  debug:
    msg: "An item: {{item}}"
  with_items: "{{ somelist }}"

- name: more complex items to add several users
  user:
    name: "{{ item.name }}"
    uid: "{{ item.uid }}"
    groups: "{{ item.groups }}"
    state: present
  with_items:
     - { name: testuser1, uid: 1002, groups: "wheel, staff" }
     - { name: testuser2, uid: 1003, groups: staff }


###Lookup Plugins - lines – read lines from command
#Run one or more commands and split the output into lines, returning them as a list
#Like all lookups, this runs on the Ansible controller and is unaffected by other keywords such as 'become'. If you need to use different permissions, you must change the command or run Ansible as another user.
#Alternatively, you can use a shell/command task that runs against localhost and registers the result.

- name: We could read the file directly, but this shows output from command
  debug: msg="{{ item }} is an output line from running cat on /etc/motd"
  with_lines: cat /etc/motd

- name: More useful example of looping over a command result
  shell: "/usr/bin/frobnicate {{ item }}"
  with_lines:
    - "/usr/bin/frobnications_per_host --param {{ inventory_hostname }}"



###Lookup Plugins - list – simply returns what it is given.
#this is mostly a noop, to be used as a with_list loop when you dont want the content transformed in any way.


- name: unlike with_items you will get 3 items from this loop, the 2nd one being a list
  debug: var=item
  with_list:
    - 1
    - [2,3]
    - 4


###Lookup Plugins - mongodb – lookup info from MongoDB
#The MongoDB lookup runs the find() command on a given collection on a given MongoDB server.
#The result is a list of jsons, so slightly different from what PyMongo returns. In particular, timestamps are converted to epoch integers.
#The below requirements are needed on the local master node that executes this lookup.
#pymongo >= 2.4 (python library)

- hosts: all
  gather_facts: false
  vars:
    mongodb_parameters:
      #mandatory parameters
      database: 'local'
      #optional
      collection: "startup_log"
      connection_string: "mongodb://localhost/"
      extra_connection_parameters: { "ssl" : True , "ssl_certfile": /etc/self_signed_certificate.pem" }
      #optional query  parameters, we accept any parameter from the normal mongodb query.
      filter:  { "hostname": "batman" }
      projection: { "pid": True    , "_id" : False , "hostname" : True }
      skip: 0
      limit: 1
      sort:  [ [ "startTime" , "ASCENDING" ] , [ "age", "DESCENDING" ] ]
  tasks:
    - debug: msg="Mongo has already started with the following PID [{{ item.pid }}]"
      with_mongodb: "{{mongodb_parameters}}"

###Lookup Plugins - pipe – read output from a command
#Run a command and return the output
#Like all lookups this runs on the Ansible controller and is unaffected by other keywords, such as become, so if you need to different permissions you must change the command or run Ansible as another user.
#Alternatively you can use a shell/command task that runs against localhost and registers the result.

- name: raw result of running date command"
  debug: msg="{{ lookup('pipe','date') }}"

- name: Always use quote filter to make sure your variables are safe to use with shell
  debug: msg="{{ lookup('pipe','getent ' + myuser|quote ) }}"


###Lookup Plugins - random_choice – return random element from list
#The 'random_choice' feature can be used to pick something at random. While it's not a load balancer (there are modules for those), it can somewhat be used as a poor man's load balancer in a MacGyver like situation.
#At a more basic level, they can be used to add chaos and excitement to otherwise predictable automation environments.

- name: Magic 8 ball for MUDs
  debug:
    msg: "{{ item }}"
  with_random_choice:
     - "go through the door"
     - "drink from the goblet"
     - "press the red button"
     - "do nothing"

###Lookup Plugins - sequence – generate a list based on a number sequence
#generates a sequence of items. You can specify a start value, an end value, an optional "stride" value that specifies the number of steps to increment the sequence, and an optional printf-style format string.
#Arguments can be specified as key=value pair strings or as a shortcut form of the arguments string is also accepted: [start-]end[/stride][:format].
#Numerical values can be specified in decimal, hexadecimal (0x3f8) or octal (0600).
#Starting at version 1.9.2, negative strides are allowed.

- name: create some test users
  user:
    name: "{{ item }}"
    state: present
    groups: "evens"
  with_sequence: start=0 end=32 format=testuser%02x

- name: create a series of directories with even numbers for some reason
  file:
    dest: "/var/stuff/{{ item }}"
    state: directory
  with_sequence: start=4 end=16 stride=2

- name: a simpler way to use the sequence plugin create 4 groups
  group:
    name: "group{{ item }}"
    state: present
  with_sequence: count=4

- name: the final countdown
  debug: msg={{item}} seconds to detonation
  with_sequence: end=0 start=10

  
###Lookup Plugins - template – retrieve contents of file after templating with Jinja2
#this is mostly a noop, to be used as a with_list loop 
#when you dont want the content transformed in any way.


- name: show templating results
  debug: msg="{{ lookup('template', './some_template.j2') }}



###Lookup Plugins - together – merges lists into synchronized list
#Creates a list with the iterated elements of the supplied lists
#To clarify with an example, [ 'a', 'b' ] and [ 1, 2 ] turn into [ ('a',1), ('b', 2) ]
#This is basically the same as the 'zip_longest' filter and Python function
#Any 'unbalanced' elements will be substituted with 'None'

- name: item.0 returns from the 'a' list, item.1 returns from the '1' list
  debug:
    msg: "{{ item.0 }} and {{ item.1 }}"
  with_together:
    - ['a', 'b', 'c', 'd']
    - [1, 2, 3, 4]



###Lookup Plugins - url – return contents from URL
#Returns the content of the URL requested to be used as data in play.

- name: url lookup splits lines by default
  debug: msg="{{item}}"
  loop: "{{ lookup('url', 'https://github.com/gremlin.keys', wantlist=True) }}"

- name: display ip ranges
  debug: msg="{{ lookup('url', 'https://ip-ranges.amazonaws.com/ip-ranges.json', split_lines=False) }}"



###Lookup Plugins - vars – Lookup templated value of variables
#Retrieves the value of an Ansible variable.


- name: Show value of 'variablename'
  debug: msg="{{ lookup('vars', 'variabl' + myvar)}}"
  vars:
    variablename: hello
    myvar: ename

- name: Show default empty since i dont have 'variablnotename'
  debug: msg="{{ lookup('vars', 'variabl' + myvar, default='')}}"
  vars:
    variablename: hello
    myvar: notename

- name: Produce an error since i dont have 'variablnotename'
  debug: msg="{{ lookup('vars', 'variabl' + myvar)}}"
  ignore_errors: True
  vars:
    variablename: hello
    myvar: notename

- name: find several related variables
  debug: msg="{{ lookup('vars', 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all') }}"

- name: alternate way to find some 'prefixed vars' in loop
  debug: msg="{{ lookup('vars', 'ansible_play_' + item) }}"
  loop:
    - hosts
    - batch
    - hosts_all


   
    
    
    
    
    
    
    
    
    
    
    

###Working With Plugins - Shell Plugins
#Shell plugins work to ensure that the basic commands Ansible runs are properly formatted 
#to work with the target machine and allow the user to configure certain behaviors related to how Ansible executes tasks.


##Enabling Shell Plugins
#You can add a custom shell plugin by dropping it into a shell_plugins directory 
#adjacent to your play, inside a role, or by putting it in one of the shell plugin directory sources configured in ansible.cfg.

#You should not alter which plugin is used unless you have a setup in which 
#the default /bin/sh is not a POSIX compatible shell or is not available for execution.


##Available plugins 
csh – C shell (/bin/csh)
fish – fish shell (/bin/fish)
powershell – Windows Powershell
sh – POSIX shell (/bin/sh)



###Working With Plugins - Strategy Plugins
#Strategy plugins control the flow of play execution by handling task and host scheduling.

##Enabling Strategy Plugins
#Strategy plugins shipped with Ansible are enabled by default. 
#You can enable a custom strategy plugin by putting it in one of the lookup directory sources configured in ansible.cfg.


##Using Strategy Plugins
#Only one strategy plugin can be used in a play, but you can use different ones for each play in a playbook or ansible run. 
#The default is the linear plugin.
# You can change this default in Ansible configuration using an environment variable:

export ANSIBLE_STRATEGY=free

#or in the ansible.cfg file:

[defaults]
strategy=linear

#You can also specify the strategy plugin in the play via the strategy keyword in a play:

- hosts: all
  strategy: debug
  tasks:
    - copy: src=myhosts dest=/etc/hosts
      notify: restart_tomcat

    - package: name=tomcat state=present

  handlers:
    - name: restart_tomcat
      service: name=tomcat state=restarted

##Plugin List
ansible-doc -t strategy -l #to see the list of available plugins. 
ansible-doc -t strategy <plugin name> #to see plugin-specific specific documentation and examples.

##Available plugins 
debug – Executes tasks in interactive debug session.
free – Executes tasks on each host independently
host_pinned – Executes tasks on each host without interruption
linear – Executes tasks in a linear fashion



###Working With Plugins - Vars Plugins
#Vars plugins inject additional variable data into Ansible runs 
#that did not come from an inventory source, playbook, or command line. 
#Playbook constructs like 'host_vars' and 'group_vars' work using vars plugins.

#Vars plugins were partially implemented in Ansible 2.0 
#and rewritten to be fully implemented starting with Ansible 2.4.

#The host_group_vars plugin shipped with Ansible enables reading variables 
#from Host Variables and Group Variables.

##Enabling Vars Plugins
#You can activate a custom vars plugin by either dropping it into a vars_plugins directory adjacent to your play, inside a role, 
#or by putting it in one of the directory sources configured in ansible.cfg.


##Using Vars Plugins
#Vars plugins are used automatically after they are enabled.


##Plugin Lists
ansible-doc -t vars -l #to see the list of available plugins. 
ansible-doc -t vars <plugin name> #to see specific plugin-specific documentation and examples.

##Available plugins 
host_group_vars – In charge of loading group_vars and host_vars


        
        
###Ansible Tower

#Ansible Tower (formerly 'AWX') is a web-based solution that makes Ansible even more easy to use for IT teams of all kinds. 
#It's designed to be the hub for all of your automation tasks.

#Tower allows you to control access to who can access what, 
#even allowing sharing of SSH credentials without someone being able to transfer those credentials. 

#Inventory can be graphically managed or synced with a wide variety of cloud sources. 
#It logs all of your jobs, integrates well with LDAP, and has an amazing browsable REST API. 

#Command line tools are available for easy integration with Jenkins as well. 
#Provisioning callbacks provide great support for autoscaling topologies.



###Calling Ansible from Python API
#Because Ansible relies on forking processes, this API is not thread safe.
#Ansible emits warnings and errors via the display object, which prints directly to stdout, 
#stderr and the Ansible log.

#The source code for the ansible command line tools (lib/ansible/cli/) is available on Github.


#This example is a simple demonstration that shows how to minimally run a couple of tasks:

#!/usr/bin/env python

import json
import shutil
from collections import namedtuple
from ansible.parsing.dataloader import DataLoader
from ansible.vars.manager import VariableManager
from ansible.inventory.manager import InventoryManager
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.plugins.callback import CallbackBase
import ansible.constants as C

class ResultCallback(CallbackBase):
    """A sample callback plugin used for performing an action as results come in

    If you want to collect all results into a single object for processing at
    the end of the execution, look into utilizing the ``json`` callback plugin
    or writing your own custom callback plugin
    """
    def v2_runner_on_ok(self, result, **kwargs):
        """Print a json representation of the result

        This method could store the result in an instance attribute for retrieval later
        """
        host = result._host
        print(json.dumps({host.name: result._result}, indent=4))

# since API is constructed for CLI it expects certain options to always be set, named tuple 'fakes' the args parsing options object
Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
options = Options(connection='local', module_path=['/to/mymodules'], forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)

# initialize needed objects
loader = DataLoader() # Takes care of finding and reading yaml, json and ini files
passwords = dict(vault_pass='secret')

# Instantiate our ResultCallback for handling results as they come in. Ansible expects this to be one of its main display outlets
results_callback = ResultCallback()

# create inventory, use path to host config file as source or hosts in a comma separated string
inventory = InventoryManager(loader=loader, sources='localhost,')

# variable manager takes care of merging all the different sources to give you a unifed view of variables available in each context
variable_manager = VariableManager(loader=loader, inventory=inventory)

# create datastructure that represents our play, including tasks, this is basically what our YAML loader does internally.
play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Create play object, playbook objects use .load instead of init or new methods,
# this will also automatically create the task objects from the info provided in play_source
play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Run it - instantiate task queue manager, which takes care of forking and setting up all objects to iterate over host list and tasks
tqm = None
try:
    tqm = TaskQueueManager(
              inventory=inventory,
              variable_manager=variable_manager,
              loader=loader,
              options=options,
              passwords=passwords,
              stdout_callback=results_callback,  # Use our custom callback instead of the ``default`` callback plugin, which prints to stdout
          )
    result = tqm.run(play) # most interesting data for a play is actually sent to the callback's methods
finally:
    # we always need to cleanup child procs and the structres we use to communicate with them
    if tqm is not None:
        tqm.cleanup()

    # Remove ansible tmpdir
    shutil.rmtree(C.DEFAULT_LOCAL_TMP, True)





###Adding modules and plugins locally

##Adding a module locally
#Ansible automatically loads all executable files found in certain directories as modules, 
1.any directory added to the ANSIBLE_LIBRARY environment variable 
($ANSIBLE_LIBRARY takes a colon-separated list like $PATH)
2.~/.ansible/plugins/modules/
3./usr/share/ansible/plugins/modules/

#To confirm that my_custom_module is available:
ansible-doc -t module my_custom_module

#To use a local module only in certain playbooks:
#store it in a sub-directory called 'library' in the directory that contains the playbook(s)

#To use a local module only in a single role:
#store it in a sub-directory called 'library' within that role



##Adding a plugin locally
#Ansible loads plugins automatically , loading each type of plugin separately 
#from a directory named for the type of plugin. 
action_plugins*
cache_plugins
callback_plugins
connection_plugins
filter_plugins*
inventory_plugins
lookup_plugins
shell_plugins
strategy_plugins
test_plugins*
vars_plugins

#create or add a local plugin in any of these locations:
1.any directory added to the relevant ANSIBLE_plugin_type_PLUGINS environment variable 
(these variables, such as $ANSIBLE_INVENTORY_PLUGINS and $ANSIBLE_VARS_PLUGINS take colon-separated lists like $PATH)
2.the directory named for the correct plugin_type within ~/.ansible/plugins/ 
for example, ~/.ansible/plugins/callback_plugins
3.the directory named for the correct plugin_type within /usr/share/ansible/plugins/ 
for example, /usr/share/ansible/plugins/plugin_type/action_plugins


#To confirm that plugins/plugin_type/my_custom_plugin is available:
ansible-doc -t <plugin_type> my_custom_lookup_plugin.
#For example, 
ansible-doc -t lookup my_custom_lookup_plugin

#To use your local plugin only in certain playbooks:
#store it in a sub-directory for the correct plugin_type 
#(for example, callback_plugins or inventory_plugins) in the directory that contains the playbook(s)

#To use your local plugin only in a single role:
#store it in a sub-directory for the correct plugin_type 
#(for example, cache_plugins or strategy_plugins) within that role

#When shipped as part of a role, 
#the plugin will be available as soon as the role is called in the play.


###Ansible module development

##Environment setup
#Due to dependencies (for example ansible -> paramiko -> pynacl -> libffi):
sudo apt update
sudo apt install build-essential libssl-dev libffi-dev python-dev

##Common environment setup
Clone the Ansible repository: $ git clone https://github.com/ansible/ansible.git
Change directory into the repository root dir: $ cd ansible
Create a virtual environment: $ python3 -m venv venv 
(or for Python 2 $ virtualenv venv. Note, this requires you to install the virtualenv package: 
$ pip install virtualenv)
Activate the virtual environment: $ . venv/bin/activate
Install development requirements: $ pip install -r requirements.txt
Run the environment setup script for each new dev shell process: $ . hacking/env-setup

#After the initial setup above, every time you are ready to start developing Ansible 
#you should be able to just run the following from the root of the Ansible repo: 
$ . venv/bin/activate && . hacking/env-setup


##Starting a new module

#To create a new module:
#Navigate to the correct directory for your new module: 
$ cd lib/ansible/modules/cloud/azure/
#Create your new module file: 
$ touch my_new_test_module.py
#Paste the content below into your new module file. 
#It includes the required Ansible format and documentation and some example code.
#Modify and extend the code to do what you want your new module to do.

##Standard Template 
#!/usr/bin/python

# Copyright: (c) 2018, Terry Jones <terry.jones@example.org>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: my_sample_module

short_description: This is my sample module

version_added: "2.4"

description:
    - "This is my longer description explaining my sample module"

options:
    name:
        description:
            - This is the message to send to the sample module
        required: true
    new:
        description:
            - Control to demo if the result of this module is changed or not
        required: false

extends_documentation_fragment:
    - azure

author:
    - Your Name (@yourhandle)
'''

EXAMPLES = '''
# Pass in a message
- name: Test with a message
  my_new_test_module:
    name: hello world

# pass in a message and have changed true
- name: Test with a message and changed output
  my_new_test_module:
    name: hello world
    new: true

# fail the module
- name: Test failure of the module
  my_new_test_module:
    name: fail me
'''

RETURN = '''
original_message:
    description: The original name param that was passed in
    type: str
message:
    description: The output message that the sample module generates
'''

from ansible.module_utils.basic import AnsibleModule

def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        name=dict(type='str', required=True),
        new=dict(type='bool', required=False, default=False)
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # change is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        original_message='',
        message=''
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        return result

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)
    result['original_message'] = module.params['name']
    result['message'] = 'goodbye'

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    if module.params['new']:
        result['changed'] = True

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result
    if module.params['name'] == 'fail me':
        module.fail_json(msg='You requested this to fail', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)

def main():
    run_module()

if __name__ == '__main__':
    main()
    
    
    
##Extended Template 
#!/usr/bin/python
# Copyright (c) 2018 Julio Lajara
# Copyright (c) 2017 Ansible Project
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/old-licenses/gpl-2.0.html)

# Last Updated: 02/05/2018 Ansible Version: 2.4
#
# All modules must have the following sections defined in this order:
#
# 1. Copyright (When adding a copyright line after completing a significant feature or rewrite, add the newer line above
#               the older one).
# 2. ANSIBLE_METADATA
# 3. DOCUMENTATION
# 4. EXAMPLES
# 5. RETURN
# 6. Python imports
#
# The script shebang should always be `#!/usr/bin/python` so that `ansible_python_interpretter` works.

# `ANSIBLE_METADATA` contains information about the module for use by other tools.
# * `metadata_version` is the version of the `ANSIBLE_METADATA` schema, not the version of the module.
# * Promoting a module's status or supported_by status should only be done by members of the Ansible Core Team.
#
# Version 1.1 Metadata Format:
#
# metadata_version:
#   An "X.Y" formatted string. X and Y are integers which define the metadata format version.
#   Modules shipped with Ansible are tied to an Ansible release, so we will only ship with a single version of the
#   metadata. We'll increment Y if we add fields or legal values to an existing field. We'll increment X if we remove
#   fields or values or change the type or meaning of a field. Current metadata_version is "1.1"
#
# supported_by:	
#   This field records who supports the module. Default value is community. Values are:
#
#   * core
#   * network
#   * certified
#   * community
#   * curated (Deprecated. Modules in this category should probably be core or certified instead)
#
#   For information on what the support level values entail, please see
#   (Modules Support)[http://docs.ansible.com/ansible/modules_support.html].
#
# status:	
#   This field records information about the module that is important to the end user. It's a list of strings.
#   The default value is a single element list ["preview"]. The following strings are valid statuses and have the
#   following meanings:
#
#   stableinterface:
# 	  This means that the module's parameters are stable. Every effort will be made not to remove parameters or
#     change their meaning. It is not a rating of the module's code quality.
#   preview:
#     This module is a tech preview. This means it may be unstable, the parameters may change, or it may require
#     libraries or web services that are themselves subject to incompatible changes.
#   deprecated:
#     This module is deprecated and will no longer be available in a future release.
#   removed:
#     This module is not present in the release. A stub is kept so that documentation can be built.
#     The documentation helps users port from the removed module to new modules.
ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

# The following fields can be used and are all required unless specified otherwise:
#
# module:	
#   The name of the module. This must be the same as the filename, without the `.py` extension.
#
# short_description:
#   A short description which is displayed on the All Modules page and `ansible-doc -l`.
#   As the short description is displayed by `ansible-doc -l` without the category grouping it needs enough detail to
#   explain its purpose without the context of the directory structure in which it lives.
#   Unlike `description:` this field should not have a trailing full stop.
#
# description:	
#   A detailed description (generally two or more sentences).
#   Must be written in full sentences, i.e. with capital letters and fullstops.
#   Shouldn't mention the name module.
#
# version_added:	
#   The version of Ansible when the module was added. This is a string, and not a float, i.e. version_added: "2.1"
#
# author:	
#   Name of the module author in the form First Last (@GitHubID).
#   Use a multi-line list if there is more than one author.
#
# deprecated:	
#   If this module is deprecated, detail when that happened, and what to use instead, e.g.
#   `Deprecated in 2.3. Use M(whatmoduletouseinstead) instead`. Ensure CHANGELOG.md is updated to reflect this.
#
# options:
#   One per module argument:
#
#   option-name:
#     * Declarative operation (not CRUD)–this makes it easy for a user not to care what the existing state is,
#       just about the final state, for example online:, rather than is_online:.
#     * The name of the option should be consistent with the rest of the module, as well as other modules in the same
#       category.
#
#     description:	
#       * Detailed explanation of what this option does. It should be written in full sentences.
#       * Should not list the options values (that's what choices: is for), though it should explain what the values do
#         if they aren't obvious.
#       * If an optional parameter is sometimes required this need to be reflected in the documentation, e.g.
#         "Required when I(state=present)."
#       * Mutually exclusive options must be documented as the final sentence on each of the options.
#
#     required:	
#       * Only needed if true, otherwise it is assumed to be false.
#
#     default:	
#       * If required is false/missing, default may be specified (assumed 'null' if missing).
#       * Ensure that the default parameter in the docs matches the default parameter in the code.
#       * The default option must not be listed as part of the description.
#       * If the option is a boolean value, you can use any of the boolean values recognized by Ansible:
#         (such as true/false or yes/no). Choose the one that reads better in the context of the option.
#
#     choices:	
#       * List of option values. Should be absent if empty.
#
#     type:	
#       * If an argument is type='bool', this field should be set to type: bool and no choices should be specified.
#
#     aliases:	
#       * List of option name aliases; generally not needed.
#
#     version_added:	
#       * Only needed if this option was extended after initial Ansible release, i.e. this is greater than the top level
#         version_added field. This is a string, and not a float, i.e. version_added: "2.3".
#
#     suboptions:	
#       * If this option takes a dict, you can define it here. See azure_rm_securitygroup, os_ironic_node for examples.
#
# requirements:	
#   List of requirements, and minimum versions (if applicable)
#
# notes:	
#   Details of any important information that doesn't fit in one of the above sections; for example if check_mode isn't
#   supported, or a link to external documentation.                             
DOCUMENTATION = '''
---
module: my_sample_module

short_description: This is my sample module

version_added: "2.4"

description:
    - "This is my longer description explaining my sample module"

options:
    name:
        description:
            - This is the message to send to the sample module
        required: true
    new:
        description:
            - Control to demo if the result of this module is changed or not
        required: false

extends_documentation_fragment:
    - azure

author:
    - Your Name (@yourhandle)
'''

# Examples should demonstrate real world usage, and be written in multi-line plain-text YAML format.
# Ensure that examples are kept in sync with the options during the PR review and any following code refactor.
# As per playbook best practice, a name: should be specified.
EXAMPLES = '''
# Pass in a message
- name: Test with a message
  my_new_test_module:
    name: hello world

# pass in a message and have changed true
- name: Test with a message and changed output
  my_new_test_module:
    name: hello world
    new: true

# fail the module
- name: Test failure of the module
  my_new_test_module:
    name: fail me
'''

# The following fields can be used and are all required unless specified otherwise.
#
# return name:
#   Name of the returned field.
#
#   description:	
#     Detailed description of what this value represents.
#
#   returned:	
#     When this value is returned, such as always, on success, always
#
#   type:	
#     Data type
#
#   sample:	
#     One or more examples.
#
#   version_added:	
#     Only needed if this return was extended after initial Ansible release, i.e. this is greater than the top level
#     version_added field. This is a string, and not a float, i.e. version_added: "2.3".
#
#   contains:	
#     Optional, if you set type: complex you can detail the dictionary here by repeating the above elements.
# 
#     return name:	
#       One per return
#
#     description:
#       Detailed description of what this value represents.
#
#     returned:
#       When this value is returned, such as always, on success, always
#
#     type:
#       Data type
#
#     sample:
#       One or more examples.
#
#     version_added:
#       Only needed if this return was extended after initial Ansible release, i.e. this is greater than the top level
#       version_added field. This is a string, and not a float, i.e. version_added: "2.3".
#
# For complex nested returns type can be specified as `type: complex`.
RETURN = '''
original_message:
    description: The original name param that was passed in
    type: str
message:
    description: The output message that the sample module generates
'''

# Formatting options
#
# Formatting functions can be used in documentation to format options.
#
# These formatting functions are U() for URLs, I() for option names, C() for files and option values and M() for module
# names. Module names should be specified as M(module) to create a link to the online documentation for that module.

# Documentation fragments
#
# Some categories of modules share common documentation, such as details on how to authenticate options, or file mode
# settings. Rather than duplicate that information it can be shared using docs_fragments.
#
# These shared fragments are similar to the standard documentation block used in a module, they are just contained in a
# `ModuleDocFragment` class.
#
# All the existing docs_fragments can be found in `lib/ansible/utils/module_docs_fragments/`.
#
# To include, simply add in `extends_documentation_fragment: FRAGMENT_NAME` into your module.
# 
# Examples can be found by searching for `extends_documentation_fragment` under the Ansible source tree.

# Ansible modules can only access the ansible.module_utils API. If you need to execute other Ansible modules, this can
# only be done from an Ansible Action Plugin.
#
# The use of "wildcard" imports such as from module_utils.basic import * is no longer allowed.
from ansible.module_utils.basic import AnsibleModule

# Ansible facts
from ansible.module_utils.facts.namespace import PrefixFactNamespace
from ansible.module_utils.facts import ansible_collector, default_collectors

# Ensure module code meets (Development Guidelines)[https://docs.ansible.com/ansible/2.4/dev_guide/developing_modules_checklist.html]
def run_module():
    # define the available arguments/parameters that a user can pass to
    # the module
    module_args = dict(
        name=dict(type='str', required=True),
        new=dict(type='bool', required=False, default=False)
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # change is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task.
    # If you want to update the Ansible facts, use the `ansible_facts` property.
    result = dict(
        changed=False,
        ansible_facts=dict()
    )

    # initialize the Ansible facts collector.
    # Collector classes define the high level categories of collectors.
    # Filter spec sets the variable fact regex filter.
    # Gather subset is the subset of facts to gather.
    # Minimal gather subset is the subset of facts to always gather regardless of the gather subset filter.
    # namespace is a fact namespace (like ohai or ansible).
    # prefix is the string to append the facts collected.
    all_collector_classes = default_collectors.collectors
    filter_spec = '*'
    gather_subset = ['distribution', 'platform', 'user']
    minimal_gather_subset = gather_subset
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode. It also supports defining advanced conditionals
    # for validating the argument specification.
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # Create our fact collector instance and use the module instance to
    # collect the facts using the Ansible facts modules.
    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                filter_spec=filter_spec,
                                                namespace=namespace,
                                                gather_subset=gather_subset,
                                                minimal_gather_subset=minimal_gather_subset)

    facts_dict = fact_collector.collect(module=module)

    # Update the ansible_facts in our return struct so that its available to other tasks
    result['ansible_facts']['my_custom_fact'] = facts_dict['ansible_user_id']
 
    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result
    if module.params['name'] == 'fail me':
        module.fail_json(msg='You requested this to fail', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)

def main():
    run_module()

if __name__ == '__main__':
    main()

##Exercising module code locally
#If you module does not need to target a remote host
#Create an arguments file, a basic JSON config file that passes parameters to module 
#/tmp/args.json 

{
    "ANSIBLE_MODULE_ARGS": {
        "name": "hello",
        "new": true
    }
}

#activate it: 
$ . venv/bin/activate
$ . hacking/env-setup
#Run your test module locally and directly: 
$ python ./my_new_test_module.py /tmp/args.json

#output 
{"changed": true, "state": {"original_message": "hello", "new_message": "goodbye"}, "invocation": {"module_args": {"name": "hello", "new": true}}}


##Exercising module code in a playbook
#Create a playbook in any directory: 
$ touch testmod.yml

#Add the following to the new playbook file:

- name: test my new module
  hosts: localhost
  tasks:
  - name: run the new module
    my_new_test_module:
      name: 'hello'
      new: true
    register: testout
  - name: dump test output
    debug:
      msg: '{{ testout }}'

#Run the playbook and analyze the output: 
$ ansible-playbook ./testmod.yml

#Sanity tests
#You can run through Ansible's sanity checks in a container:

$ ansible-test sanity -v --docker --python 2.7 MODULE_NAME

#Note that this example requires Docker to be installed and running. 
#To not use a container for this, choose to use --tox instead of --docker.

##Unit tests

#add unit tests for  module in ./test/units/modules

#setup testing environment
#Install the requirements (outside of your virtual environment): 
$ pip3 install -r ./test/runner/requirements/units.txt
#(you must run . hacking/env-setup prior to this)
#To run all tests do the following: 
$ ansible-test units --python 3.5 

#Ansible uses pytest for unit testing.
#To run pytest against a single test module, 
#(provide the path to the test module appropriately):

$ pytest -r a --cov=. --cov-report=html --fulltrace --color yes test/units/modules/.../test/my_new_test_module.py







##AnsibleModule 

Argument spec
    The argument_spec provided to AnsibleModule defines the supported arguments for a module, 
    module = AnsibleModule(argument_spec=dict(
        top_level=dict(
            type='dict',
            options=dict(
                second_level=dict(
                    default=True,
                    type='bool',
                )
            )
        )
    ))

type
    type allows you to define the type of the value accepted for the argument. 
    The default value for type is str. Possible values are:
        str
        list
        dict
        bool
        int
        float
        path
        raw
        jsonarg
        json
        bytes
        bits
    The raw type, performs no type validation or type casing, 
    and maintains the type of the passed value.


elements
    elements works in combination with type when type='list'. 
    elements can then be defined as elements='int' or any other type, 
    indicating that each element of the specified list should be of that type.


default
    The default option allows sets a default value for the argument for the scenario when the argument is not provided to the module. 
    When not specified, the default value is None.


fallback
    fallback accepts a tuple where the first argument is a callable (function) 
    that will be used to perform the lookup, based on the second argument. 
    The second argument is a list of values to be accepted by the callable.
    The most common callable used is env_fallback which will allow an argument 
    to optionally use an environment variable when the argument is not supplied.
    Example:
        username=dict(fallback=(env_fallback, ['ANSIBLE_NET_USERNAME']))

choices
    choices accepts a list of choices that the argument will accept. 
    The types of choices should match the type.

required
    required accepts a boolean, either True or False 
    that indicates that the argument is required. 
    This should not be used in combination with default.
    
no_log
    no_log indicates that the value of the argument should not be logged or displayed.
    
aliases
    aliases accepts a list of alternative argument names for the argument, 
    such as the case where the argument is name 
    but the module accepts aliases=['pkg'] to allow pkg to be interchangably with name
    
options
    options implements the ability to create a sub-argument_spec, 
    where the sub options of the top level argument are also validated 
    using the attributes discussed in this section. 
    The example at the top of this section demonstrates use of options. 
    type or elements should be dict is this case.
    
apply_defaults
    apply_defaults works alongside options and allows the default of the sub-options 
    to be applied even when the top-level argument is not supplied.
    In the example of the argument_spec at the top of this section, 
    it would allow module.params['top_level']['second_level'] to be defined, 
    even if the user does not provide top_level when calling the module.
    
removed_in_version
    removed_in_version indicates which version of Ansible a deprecated argument will be removed in.


##Returning a new fact from a python module could be done like:
module.exit_json(msg=message, ansible_facts=dict(leptons=5000, colors=my_colors))

##instantiating the module class like:

def main():
    module = AnsibleModule(
        argument_spec = dict(
            state     = dict(default='present', choices=['present', 'absent']),
            name      = dict(required=True),
            enabled   = dict(required=True, type='bool'),
            something = dict(aliases=['whatever'])
        )
    )
    
#Successful returns are made like this:
module.exit_json(changed=True, something_else=12345)

#failures are just as simple (where msg is a required parameter to explain the error):
module.fail_json(msg="Something fatal happened")

#There are also other useful functions in the module class, such as module.sha1(path)().
# See lib/ansible/module_utils/basic.py in the source checkout for implementation details.

#modules developed this way are best tested with the hacking/test-module script 
#in the git source checkout. 
#Because of the magic involved, this is really the only way the scripts can function outside of Ansible.

    
    
    
    
    
    
    
    

###Developing plugins

##Raising errors
#by raising AnsibleError() or a similar class with a message describing the error. 
#When wrapping other exceptions into error messages, use the to_text Ansible function 
#to ensure proper string compatibility across Python versions:

from ansible.module_utils._text import to_native

try:
    cause_an_exception()
except Exception as e:
    raise AnsibleError('Something happened, this was original exception: %s' % to_native(e))

##String encoding
#You must convert any strings returned by your plugin into Python's unicode type. 
#Converting to unicode ensures that these strings can run through Jinja2. 
from ansible.module_utils._text import to_text
result_string = to_text(result_string)

#To define configurable options for plugin, 
#describe them in the DOCUMENTATION section of the python file. 

#To add a configurable option to plugin, define it in this format:
options:
  option_name:
    description: describe this config option
    default: default value for this config option
    env:
      - name: NAME_OF_ENV_VAR
    ini:
      - section: section_of_ansible.cfg_where_this_config_option_is_defined
        key: key_used_in_ansible.cfg
    required: True/False
    type: boolean/float/integer/list/none/path/pathlist/pathspec/string/tmppath
    version_added: X.x

#To access the configuration settings in your plugin, use 
self.get_option(option_name)
#For most plugin types, the controller pre-populates the settings. 
#If you need to populate settings explicitly, use a 
self.set_options()

#Note plugins are placed in specific directory 
#and the class name must be exactly as shown below with it's inheritance 
#check doc at lib/ansible/plugins/..


###Creating Callback plugins
#Callback plugins add new behaviors to Ansible when responding to events. 
#By default, callback plugins control most of the output when running the command line programs.

from ansible.plugins.callback import CallbackBase

class CallbackModule(CallbackBase):
    pass

#From there, override the specific methods from the CallbackBase 
#that you want to provide a callback for. 
#For plugins intended for use with Ansible version 2.0 and later, override methods 
#that start with v2. 
#For a complete list of methods , see __init__.py in the lib/ansible/plugins/callback directory.

#example of how Ansible's timer plugin 

# Make coding more python3-ish, this is required for contributions to Ansible
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

# not only visible to ansible-doc, it also 'declares' the options 
#the plugin requires and how to configure them.
DOCUMENTATION = '''
  callback: timer
  callback_type: aggregate
  requirements:
    - whitelist in configuration
  short_description: Adds time to play stats
  version_added: "2.0"
  description:
      - This callback just adds total play duration to the play stats.
  options:
    format_string:
      description: format of the string shown to user at play end
      ini:
        - section: callback_timer
          key: format_string
      env:
        - name: ANSIBLE_CALLBACK_TIMER_FORMAT
      default: "Playbook run took %s days, %s hours, %s minutes, %s seconds"
'''
from datetime import datetime

from ansible.plugins.callback import CallbackBase


class CallbackModule(CallbackBase):
    """
    This callback module tells you how long your plays ran for.
    """
    #required 
    #CALLBACK_TYPE is mostly needed to distinguish 'stdout' plugins from the rest, 
    #since you can only load one plugin that writes to stdout.
    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = 'aggregate'
    CALLBACK_NAME = 'timer'

    # only needed if you ship it and don't want to enable by default
    CALLBACK_NEEDS_WHITELIST = True

    def __init__(self):

        # make sure the expected objects are present, calling the base's __init__
        super(CallbackModule, self).__init__()

        # start the timer when the plugin is loaded, the first play should start a few milliseconds after.
        self.start_time = datetime.now()

    def _days_hours_minutes_seconds(self, runtime):
        ''' internal helper method for this callback '''
        minutes = (runtime.seconds // 60) % 60
        r_seconds = runtime.seconds - (minutes * 60)
        return runtime.days, runtime.seconds // 3600, minutes, r_seconds

    # this is only event we care about for display, when the play shows its summary stats; the rest are ignored by the base class
    def v2_playbook_on_stats(self, stats):
        end_time = datetime.now()
        runtime = end_time - self.start_time

        # Shows the usage of a config option declared in the DOCUMENTATION variable. Ansible will have set it when it loads the plugin.
        # Also note the use of the display object to print to screen. This is available to all callbacks, and you should use this over printing yourself
        self._display.display(self._plugin_options['format_string'] % (self._days_hours_minutes_seconds(runtime)))




### Creating Lookup plugins
#Lookup plugins pull in data from external data stores. 
#Lookup plugins can be used within playbooks both for looping 
#For example playbook language constructs like with_fileglob and with_items are implemented via lookup plugins 
#OR to return values into a variable or parameter.

#Lookup plugins can retrieve and return any type of data. 
#When writing lookup plugins, always return data of a consistent type 
#that can be easily consumed in a playbook. 
#Avoid parameters that change the returned data type. 

#If there is a need to return a single value sometimes and a complex dictionary other times, 
#write two different lookup plugins.

#Example this lookup returns the contents of a text file as a variable:

# python 3 headers, required if submitting to Ansible
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = """
      lookup: file
        author: Daniel Hokka Zakrisson <daniel@hozac.com>
        version_added: "0.9"
        short_description: read file contents
        description:
            - This lookup returns the contents from a file on the Ansible controller's file system.
        options:
          _terms:
            description: path(s) of files to read
            required: True
        notes:
          - if read in variable context, the file can be interpreted as YAML if the content is valid to the parser.
          - this lookup does not understand globing --- use the fileglob lookup instead.
"""
from ansible.errors import AnsibleError, AnsibleParserError
from ansible.plugins.lookup import LookupBase

try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()


class LookupModule(LookupBase):

    def run(self, terms, variables=None, **kwargs):
        # lookups in general are expected to both take a list as input and output a list
        # this is done so they work with the looping construct 'with_'.
        ret = []
        for term in terms:
            display.debug("File lookup term: %s" % term)

            # Find the file in the expected search path, using a class method
            # that implements the 'expected' search path for Ansible plugins.
            lookupfile = self.find_file_in_search_path(variables, 'files', term)

            # Don't use print or your own logging, the display class
            # takes care of it in a unified way.
            display.vvvv(u"File lookup using %s as file" % lookupfile)
            try:
                if lookupfile:
                    contents, show_data = self._loader._get_file_contents(lookupfile)
                    ret.append(contents.rstrip())
                else:
                    # Always use ansible error classes to throw 'final' exceptions,
                    # so the Ansible engine will know how to deal with them.
                    # The Parser error indicates invalid options passed
                    raise AnsibleParserError()
            except AnsibleParserError:
                raise AnsibleError("could not locate file in lookup: %s" % term)

        return ret

#usages 

---
- hosts: all
  vars:
     contents: "{{ lookup('file', '/etc/foo.txt') }}"

  tasks:

     - debug:
         msg: the value of foo.txt is {{ contents }} as seen today {{ lookup('pipe', 'date +"%Y-%m-%d"') }}

###Creating Vars plugins
#Vars plugins inject additional variable data into Ansible runs 
#that did not come from an inventory source, playbook, or command line. 


#loader: Ansible's DataLoader. The DataLoader can read files, auto-load JSON/YAML and decrypt vaulted data, and cache read files.
#path: this is 'directory data' for every inventory source and the current play's playbook directory, so they can search for data in reference to them. get_vars will be called at least once per available path.
#entities: these are host or group names that are pertinent to the variables needed. The plugin will get called once for hosts and again for groups.
#Example -Playbook constructs like 'host_vars' and 'group_vars' work using vars plugins.

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = '''
    vars: host_group_vars
    version_added: "2.4"
    short_description: In charge of loading group_vars and host_vars
    description:
        - Loads YAML vars into corresponding groups/hosts in group_vars/ and host_vars/ directories.
        - Files are restricted by extension to one of .yaml, .json, .yml or no extension.
        - Hidden (starting with '.') and backup (ending with '~') files and directories are ignored.
        - Only applies to inventory sources that are existing paths.
    options:
      _valid_extensions:
        default: [".yml", ".yaml", ".json"]
        description:
          - "Check all of these extensions when looking for 'variable' files which should be YAML or JSON or vaulted versions of these."
          - 'This affects vars_files, include_vars, inventory and vars plugins among others.'
        env:
          - name: ANSIBLE_YAML_FILENAME_EXT
        ini:
          - section: yaml_valid_extensions
            key: defaults
        type: list
'''

import os
from ansible import constants as C
from ansible.errors import AnsibleParserError
from ansible.module_utils._text import to_bytes, to_native, to_text
from ansible.plugins.vars import BaseVarsPlugin
from ansible.inventory.host import Host
from ansible.inventory.group import Group
from ansible.utils.vars import combine_vars

FOUND = {}


class VarsModule(BaseVarsPlugin):

    def get_vars(self, loader, path, entities, cache=True):
        ''' parses the inventory file '''

        if not isinstance(entities, list):
            entities = [entities]

        super(VarsModule, self).get_vars(loader, path, entities)

        data = {}
        for entity in entities:
            if isinstance(entity, Host):
                subdir = 'host_vars'
            elif isinstance(entity, Group):
                subdir = 'group_vars'
            else:
                raise AnsibleParserError("Supplied entity must be Host or Group, got %s instead" % (type(entity)))

            # avoid 'chroot' type inventory hostnames /path/to/chroot
            if not entity.name.startswith(os.path.sep):
                try:
                    found_files = []
                    # load vars
                    b_opath = os.path.realpath(to_bytes(os.path.join(self._basedir, subdir)))
                    opath = to_text(b_opath)
                    key = '%s.%s' % (entity.name, opath)
                    if cache and key in FOUND:
                        found_files = FOUND[key]
                    else:
                        # no need to do much if path does not exist for basedir
                        if os.path.exists(b_opath):
                            if os.path.isdir(b_opath):
                                self._display.debug("\tprocessing dir %s" % opath)
                                found_files = loader.find_vars_files(opath, entity.name)
                                FOUND[key] = found_files
                            else:
                                self._display.warning("Found %s that is not a directory, skipping: %s" % (subdir, opath))

                    for found in found_files:
                        new_data = loader.load_from_file(found, cache=True, unsafe=True)
                        if new_data:  # ignore empty files
                            data = combine_vars(data, new_data)

                except Exception as e:
                    raise AnsibleParserError(to_native(e))
        return data


###Creating your own Ansible filter plugins
#class name must be FilterModule

#Example - a_filter
#file: /home/user/filter_plugins/my_filters.py
#!/usr/bin/python
class FilterModule(object):
    def filters(self):
        return {
            'a_filter': self.a_filter,
            'another_filter': self.b_filter
        }

    def a_filter(self, a_variable):
        a_new_variable = a_variable + ' CRAZY NEW FILTER'
        return a_new_variable

#File: /home/user/my_playbook.yml
---
- hosts: localhost
  tasks:
    - name: Print a message
      debug:
        msg: "{{'test'|a_filter}}"

#with /etc/ansible/hosts
#Localhost
localhost ansible_connection=local
user@ansibletest:~$

#Execute 
$ansible-playbook my_playbook.yml

PLAY ***************************************************************************

TASK [setup] *******************************************************************
ok: [localhost]

TASK [Print a message] *********************************************************
ok: [localhost] => {
    "msg": "test CRAZY NEW FILTER"
}

PLAY RECAP *********************************************************************
localhost                  : ok=2    changed=0    unreachable=0    failed=0



#there was only one variable passed to our function.  
#In this case, it was the variable to the left of the pipe. 
#In the case of filters, that will always be  first variable 
#however, To add more. 
#!/usr/bin/python
class FilterModule(object):
    def filters(self):
        return {
            'a_filter': self.a_filter,
            'another_filter': self.b_filter
        }

    def a_filter(self, a_variable):
        a_new_variable = a_variable + ' CRAZY NEW FILTER'
        return a_new_variable

    def b_filter(self, a_variable, another_variable, yet_another_variable):
        a_new_variable = a_variable + ' - ' + another_variable + ' - ' + yet_another_variable
        return a_new_variable

#usage 
---
- hosts: localhost
  tasks:
    - name: Print a message
      debug:
        msg: "{{'test'|another_filter('the','filters')}}"



###Creating Action plugin 
#Action plugins act in conjunction with modules to execute the actions required by playbook tasks
#Action plugin are executed by default when an associated module is used



# Standard base includes and define this as a metaclass of type
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

# Important contants
from ansible import constants as C
# Common error handlers
from ansible.errors import AnsibleError
# Use Ansible's builtin boolean type if needed
from ansible.module_utils.parsing.convert_bool import boolean
# ADT base class for our Ansible Action Plugin
from ansible.plugins.action import ActionBase

# Load the display hander to send logging to CLI or relevant display mechanism
try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()

# Create our plugin based off of ActionBase from ansible.plugins.action . Our plugin class must be named ActionModule
#
# At a minimum, our ActionModule must have a defined run method.
#
# An Action Plugin must always have an associated Ansible module of the same name even if the module will not be doing
# any work. It is common practice for the module to at least have a documentation fragment even if its not actually
# doing anything. If a module does have an associated Action Plugin, the Action Plugin will always override the module
# and run instead of the module. If you want your module to still run, you would then have to explicitly run it from
# inside your Action Plugin.
#
# Useful methods inherited from ActionBase (other methods are available for transfering/managing files,
# temporary file cleanup):
#
# * _execute_module: Instance method used to find and execute another Ansible module.
# * _remote_expand_user: Expand a tilde in a file PATH.
#
# Useful instance properties inherited from ActionBase:
#
# * self._connection: An ansible.plugins.connection instance of a ConnectionBase subclass.
#   * Useful methods are exec_command, fetch_file, and put_file .
# * self._display: A deprecated ansible.utils.display Display instance. Use the display global
#   above instead.
# * self._loader: An ansible.parsing.dataloader DataLoader instance.
#   * Data loader used to parse JSON/YAML files or string with built in Ansible Vault encryption support.
# * self._play_context: An ansible.playbook.play_context PlayContext instance that encapsulates
#   a connection instance and play details.
# * self._shared_loader_obj: An ansible.plugins.loader PluginLoader subclass instance.
#   * Loads plugins from configured plugin directories.
#   * ansible.plugins.loader contains instances of PluginLoader specialized to finding different types of plugins.
# * self._task: An ansible.playbook.task Task instance for the current task.
#   * Contains action, args, parent, role and other task properties.
#
class ActionModule(ActionBase):
    # Some plugins may use class constants to control behavior.
    # In the case of TRANSFERS_FILES it is used by ActionBase to determine at which point in execution
    # temporary directories need to be available if your Action Plugin is using modules to
    # transfer files.
    TRANSFERS_FILES = False

    # The run method is the main Action Plugin driver. All work is done from within this method.
    #
    # tmp: Temporary directory. Sometimes an action plugin sets up
    #      a temporary directory and then calls another module. This parameter
    #      allows us to reuse the same directory for both.
    # task_vars: The variables (host vars, group vars, config vars, etc) associated with this task.
    #            Note that while this will contain Ansible facts from the host, they should be used
    #            with caution as a user running Ansible can disable their collection. If you want
    #            make sure that your Action Plugin always has access to the ones it needs, you may
    #            want to consider running the setup module directly in the run the method and getting
    #            the Ansible facts that way.
    #            The stragety plugin which manages running tasks on instances uses an ansible.vars.manager
    #            VariableManager instance to retrieve this context specific dict of variables.
    def run(self, tmp=None, task_vars=None):
        # Initialize our parent. The returned result is normally an empty dict unless you are inheriting
        # from another subclass of ActionBase that does other tasks in its run instance method. Otherwise,
        # all the run will do is a validation.
        #
        # For a list of common properties included in a result, see ansible/utils/module_docs_fragments/return_common.py
        result = super(ActionModule, self).run(tmp, task_vars)

        # Initialize result object with some of the return_common values:
        result.update(
            dict(
                changed=False,
                failed=False,
                msg='',
                skipped=False
            )
        )

        # Define support for check mode and async
        self._supports_check_mode = True
        self._supports_async = False

        # Execute another Ansible module
        setup_module_args=dict(
            gather_subset='all',
            gather_timeout=10
        )

        # Run the setup module to collect facts
        #
        # delete_remote_tmp: Boolean that determines whether the remote tmp directory and files are deleted.
        # module_name: The name of the Ansible module to run.
        # module_args: A dict of arguments to provide to the Ansible module.
        # persist_files: Boolean that determins whether or not to keep temporary files.
        # task_vars: The task variables for the current play context.
        # tmp: The path to the temporary directory.
        # wrap_async: Boolean that controls whether or not the task is run asyncronously.
        setup_result = self._execute_module(
            delete_remote_tmp=True,
            module_name='setup',
            module_args=setup_module_args,
            persist_files=False,
            task_vars=task_vars,
            tmp=tmp,
            wrap_async=self._task.async
        )

        if setup_result['ansible_facts']['ansible_system'] != 'Linux':
            result['failed'] = True

        return result
        
##Example of debug modules action plugin 
#Module file: lib\ansible\modules\utilities\logic\debug.py
from __future__ import absolute_import, division, print_function
__metaclass__ = type


ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['stableinterface'],
                    'supported_by': 'core'}


DOCUMENTATION = '''
---
module: debug
short_description: Print statements during execution
description:
     - This module prints statements during execution and can be useful
       for debugging variables or expressions without necessarily halting
       the playbook. Useful for debugging together with the 'when:' directive.
     - This module is also supported for Windows targets.
version_added: "0.8"
options:
  msg:
    description:
      - The customized message that is printed. If omitted, prints a generic
        message.
    required: false
    default: "Hello world!"
  var:
    description:
      - A variable name to debug.  Mutually exclusive with the 'msg' option.
      - Be aware that this option already runs in Jinja2 context and has an implicit ``{{ }}`` wrapping,
        so you should not be using Jinja2 delimiters unless you are looking for double interpolation.
  verbosity:
    description:
      - A number that controls when the debug is run, if you set to 3 it will only run debug when -vvv or above
    required: False
    default: 0
    version_added: "2.1"
notes:
    - This module is also supported for Windows targets.
author:
    - "Dag Wieers (@dagwieers)"
    - "Michael DeHaan"
'''

EXAMPLES = '''
# Example that prints the loopback address and gateway for each host
- debug:
    msg: "System {{ inventory_hostname }} has uuid {{ ansible_product_uuid }}"

- debug:
    msg: "System {{ inventory_hostname }} has gateway {{ ansible_default_ipv4.gateway }}"
  when: ansible_default_ipv4.gateway is defined

- shell: /usr/bin/uptime
  register: result

- debug:
    var: result
    verbosity: 2

- name: Display all variables/facts known for a host
  debug:
    var: hostvars[inventory_hostname]
    verbosity: 4

# Example that prints two lines of messages, but only if there's an environment value set
- debug:
    msg:
      - "Provisioning based on YOUR_KEY which is: '{{ lookup('env', 'YOUR_KEY') }}"
      - "These servers were built using the password of '{{ password_used }}'. Please retain this for later use."
'''


##Action plugin for debug module 
#file : lib\ansible\plugins\action\debug.py



from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible.errors import AnsibleUndefinedVariable
from ansible.module_utils.six import string_types
from ansible.module_utils._text import to_text
from ansible.plugins.action import ActionBase


class ActionModule(ActionBase):
    ''' Print statements during execution '''

    TRANSFERS_FILES = False
    _VALID_ARGS = frozenset(('msg', 'var', 'verbosity'))

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        if 'msg' in self._task.args and 'var' in self._task.args:
            return {"failed": True, "msg": "'msg' and 'var' are incompatible options"}

        result = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer has any effect

        # get task verbosity
        verbosity = int(self._task.args.get('verbosity', 0))

        if verbosity <= self._display.verbosity:
            if 'msg' in self._task.args:
                result['msg'] = self._task.args['msg']

            elif 'var' in self._task.args:
                try:
                    results = self._templar.template(self._task.args['var'], convert_bare=True, fail_on_undefined=True)
                    if results == self._task.args['var']:
                        # if results is not str/unicode type, raise an exception
                        if not isinstance(results, string_types):
                            raise AnsibleUndefinedVariable
                        # If var name is same as result, try to template it
                        results = self._templar.template("{{" + results + "}}", convert_bare=True, fail_on_undefined=True)
                except AnsibleUndefinedVariable as e:
                    results = u"VARIABLE IS NOT DEFINED!"
                    if self._display.verbosity > 0:
                        results += u": %s" % to_text(e)

                if isinstance(self._task.args['var'], (list, dict)):
                    # If var is a list or dict, use the type as key to display
                    result[to_text(type(self._task.args['var']))] = results
                else:
                    result[self._task.args['var']] = results
            else:
                result['msg'] = 'Hello world!'

            # force flag to make debug output module always verbose
            result['_ansible_verbose_always'] = True
        else:
            result['skipped_reason'] = "Verbosity threshold not met."
            result['skipped'] = True

        result['failed'] = False

        return result

        
##Example of command module 
#file:lib\ansible\modules\commands\command.py
#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2012, Michael DeHaan <michael.dehaan@gmail.com>, and others
# Copyright: (c) 2016, Toshio Kuratomi <tkuratomi@ansible.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function
__metaclass__ = type


ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['stableinterface'],
                    'supported_by': 'core'}

DOCUMENTATION = r'''
---
module: command
short_description: Execute commands on targets
version_added: historical
description:
     - The C(command) module takes the command name followed by a list of space-delimited arguments.
     - The given command will be executed on all selected nodes.
     - The command(s) will not be
       processed through the shell, so variables like C($HOME) and operations
       like C("<"), C(">"), C("|"), C(";") and C("&") will not work.
       Use the M(shell) module if you need these features.
     - To create C(command) tasks that are easier to read,
       pass parameters using the C(args) L(task keyword,../reference_appendices/playbooks_keywords.html#task).
     - For Windows targets, use the M(win_command) module instead.
options:
  free_form:
    description:
      - The command module takes a free form command to run.
      - There is no actual parameter named 'free form'.
      - See the examples on how to use this module.
    required: yes
  argv:
    description:
      - Passes the command as a list rather than a string.
      - Use C(argv) to avoid quoting values that would otherwise be interpreted incorrectly (for example "user name").
      - Only the string or the list form can be
        provided, not both.  One or the other must be provided.
    version_added: "2.6"
  creates:
    description:
      - A filename or (since 2.0) glob pattern. If it already exists, this step B(won't) be run.
  removes:
    description:
      - A filename or (since 2.0) glob pattern. If it already exists, this step B(will) be run.
    version_added: "0.8"
  chdir:
    description:
      - Change into this directory before running the command.
    version_added: "0.6"
  warn:
    description:
      - Enable or disable task warnings.
    type: bool
    default: yes
    version_added: "1.8"
  stdin:
    description:
      - Set the stdin of the command directly to the specified value.
    version_added: "2.4"
  stdin_add_newline:
    type: bool
    default: yes
    description:
      - If set to C(yes), append a newline to stdin data.
    version_added: "2.8"
  strip_empty_ends:
    description:
      - Strip empty lines from the end of stdout/stderr in result.
    version_added: "2.8"
    type: bool
    default: yes
notes:
    -  If you want to run a command through the shell (say you are using C(<), C(>), C(|), etc), you actually want the M(shell) module instead.
       Parsing shell metacharacters can lead to unexpected commands being executed if quoting is not done correctly so it is more secure to
       use the C(command) module when possible.
    -  " C(creates), C(removes), and C(chdir) can be specified after the command.
       For instance, if you only want to run a command if a certain file does not exist, use this."
    -  Check mode is supported when passing C(creates) or C(removes). If running in check mode and either of these are specified, the module will
       check for the existence of the file and report the correct changed status. If these are not supplied, the task will be skipped.
    -  The C(executable) parameter is removed since version 2.4. If you have a need for this parameter, use the M(shell) module instead.
    -  For Windows targets, use the M(win_command) module instead.
    -  For rebooting systems, use the M(reboot) or M(win_reboot) module.
seealso:
- module: raw
- module: script
- module: shell
- module: win_command
author:
    - Ansible Core Team
    - Michael DeHaan
'''

EXAMPLES = r'''
- name: return motd to registered var
  command: cat /etc/motd
  register: mymotd

- name: Run command if /path/to/database does not exist (without 'args').
  command: /usr/bin/make_database.sh db_user db_name creates=/path/to/database

# 'args' is a task keyword, passed at the same level as the module
- name: Run command if /path/to/database does not exist (with 'args').
  command: /usr/bin/make_database.sh db_user db_name
  args:
    creates: /path/to/database

- name: Change the working directory to somedir/ and run the command as db_owner if /path/to/database does not exist.
  command: /usr/bin/make_database.sh db_user db_name
  become: yes
  become_user: db_owner
  args:
    chdir: somedir/
    creates: /path/to/database

# 'argv' is a parameter, indented one level from the module
- name: Use 'argv' to send a command as a list - leave 'command' empty
  command:
    argv:
      - /usr/bin/make_database.sh
      - Username with whitespace
      - dbname with whitespace

- name: safely use templated variable to run command. Always use the quote filter to avoid injection issues.
  command: cat {{ myfile|quote }}
  register: myoutput
'''

RETURN = r'''
cmd:
  description: the cmd that was run on the remote machine
  returned: always
  type: list
  sample:
  - echo
  - hello
delta:
  description: cmd end time - cmd start time
  returned: always
  type: str
  sample: 0:00:00.001529
end:
  description: cmd end time
  returned: always
  type: str
  sample: '2017-09-29 22:03:48.084657'
start:
  description: cmd start time
  returned: always
  type: str
  sample: '2017-09-29 22:03:48.083128'
'''

import datetime
import glob
import os
import shlex

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils._text import to_native
from ansible.module_utils.common.collections import is_iterable


def check_command(module, commandline):
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}
    commands = {'curl': 'get_url or uri', 'wget': 'get_url or uri',
                'svn': 'subversion', 'service': 'service',
                'mount': 'mount', 'rpm': 'yum, dnf or zypper', 'yum': 'yum', 'apt-get': 'apt',
                'tar': 'unarchive', 'unzip': 'unarchive', 'sed': 'replace, lineinfile or template',
                'dnf': 'dnf', 'zypper': 'zypper'}
    become = ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']
    if isinstance(commandline, list):
        command = commandline[0]
    else:
        command = commandline.split()[0]
    command = os.path.basename(command)

    disable_suffix = "If you need to use command because {mod} is insufficient you can add" \
                     " 'warn: false' to this command task or set 'command_warnings=False' in" \
                     " ansible.cfg to get rid of this message."
    substitutions = {'mod': None, 'cmd': command}

    if command in arguments:
        msg = "Consider using the {mod} module with {subcmd} rather than running '{cmd}'.  " + disable_suffix
        substitutions['mod'] = 'file'
        substitutions['subcmd'] = arguments[command]
        module.warn(msg.format(**substitutions))

    if command in commands:
        msg = "Consider using the {mod} module rather than running '{cmd}'.  " + disable_suffix
        substitutions['mod'] = commands[command]
        module.warn(msg.format(**substitutions))

    if command in become:
        module.warn("Consider using 'become', 'become_method', and 'become_user' rather than running %s" % (command,))


def main():

    # the command module is the one ansible module that does not take key=value args
    # hence don't copy this one if you are looking to build others!
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            # The default for this really comes from the action plugin
            warn=dict(type='bool', default=True),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    shell = module.params['_uses_shell']
    chdir = module.params['chdir']
    executable = module.params['executable']
    args = module.params['_raw_params']
    argv = module.params['argv']
    creates = module.params['creates']
    removes = module.params['removes']
    warn = module.params['warn']
    stdin = module.params['stdin']
    stdin_add_newline = module.params['stdin_add_newline']
    strip = module.params['strip_empty_ends']

    if not shell and executable:
        module.warn("As of Ansible 2.4, the parameter 'executable' is no longer supported with the 'command' module. Not using '%s'." % executable)
        executable = None

    if (not args or args.strip() == '') and not argv:
        module.fail_json(rc=256, msg="no command given")

    if args and argv:
        module.fail_json(rc=256, msg="only command or argv can be given, not both")

    if not shell and args:
        args = shlex.split(args)

    args = args or argv

    # All args must be strings
    if is_iterable(args, include_strings=False):
        args = [to_native(arg, errors='surrogate_or_strict', nonstring='simplerepr') for arg in args]

    if chdir:
        chdir = os.path.abspath(chdir)
        os.chdir(chdir)

    if creates:
        # do not run the command if the line contains creates=filename
        # and the filename already exists.  This allows idempotence
        # of command executions.
        if glob.glob(creates):
            module.exit_json(
                cmd=args,
                stdout="skipped, since %s exists" % creates,
                changed=False,
                rc=0
            )

    if removes:
        # do not run the command if the line contains removes=filename
        # and the filename does not exist.  This allows idempotence
        # of command executions.
        if not glob.glob(removes):
            module.exit_json(
                cmd=args,
                stdout="skipped, since %s does not exist" % removes,
                changed=False,
                rc=0
            )

    if warn:
        check_command(module, args)

    startd = datetime.datetime.now()

    if not module.check_mode:
        rc, out, err = module.run_command(args, executable=executable, use_unsafe_shell=shell, encoding=None, data=stdin, binary_data=(not stdin_add_newline))
    elif creates or removes:
        rc = 0
        out = err = b'Command would have run if not in check mode'
    else:
        module.exit_json(msg="skipped, running in check mode", skipped=True)

    endd = datetime.datetime.now()
    delta = endd - startd

    if strip:
        out = out.rstrip(b"\r\n")
        err = err.rstrip(b"\r\n")

    result = dict(
        cmd=args,
        stdout=out,
        stderr=err,
        rc=rc,
        start=str(startd),
        end=str(endd),
        delta=str(delta),
        changed=True,
    )

    if rc != 0:
        module.fail_json(msg='non-zero return code', **result)

    module.exit_json(**result)


if __name__ == '__main__':
    main()

    
#File: lib\ansible\modules\commands\command.py
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible import constants as C
from ansible.plugins.action import ActionBase
from ansible.utils.vars import merge_hash


class ActionModule(ActionBase):

    def run(self, tmp=None, task_vars=None):
        self._supports_async = True
        results = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer has any effect

        # Command module has a special config option to turn off the command nanny warnings
        if 'warn' not in self._task.args:
            self._task.args['warn'] = C.COMMAND_WARNINGS

        wrap_async = self._task.async_val and not self._connection.has_native_async
        results = merge_hash(results, self._execute_module(task_vars=task_vars, wrap_async=wrap_async))

        if not wrap_async:
            # remove a temporary path we created
            self._remove_tmp_path(self._connection._shell.tmpdir)

        return results

###Best Practices

#The order/precedence for merging group_vars and host_vars is (from lowest to highest):
1.all group (because it is the ‘parent’ of all other groups)
2.parent group
3.child group
4.host
#When groups of the same parent/child level are merged, it is done alphabetically, 
#and the last group loaded overwrites the previous groups. 
#For example, an a_group will be merged with b_group and b_group vars that match will overwrite the ones in a_group.


##Directory Layout
#The top level of the directory would contain files and directories like so:

production                # inventory file for production servers
staging                   # inventory file for staging or testing environment

group_vars/
   group1.yml             # here we assign variables to particular groups
   group2.yml             #autoloaded 
host_vars/
   hostname1.yml          # here we assign variables to particular systems
   hostname2.yml          #autoloaded 

library/                  # if any custom modules, put them here (optional)
module_utils/             # if any custom module_utils to support modules, put them here (optional)
filter_plugins/           # if any custom filter plugins, put them here (optional)

site.yml                  # master playbook
webservers.yml            # playbook for webserver tier
dbservers.yml             # playbook for dbserver tier

roles/
    common/               # this hierarchy represents a "role"
        tasks/            #
            main.yml      #  <-- tasks file can include smaller files if warranted
        handlers/         #
            main.yml      #  <-- handlers file
        templates/        #  <-- files for use with the template resource
            ntp.conf.j2   #  <------- templates end in .j2
        files/            #
            bar.txt       #  <-- files for use with the copy resource
            foo.sh        #  <-- script files for use with the script resource
        vars/             #
            main.yml      #  <-- variables associated with this role
        defaults/         #
            main.yml      #  <-- default lower priority variables for this role
        meta/             #
            main.yml      #  <-- role dependencies
        library/          # roles can also include custom modules
        module_utils/     # roles can also include custom module_utils
        lookup_plugins/   # or other types of plugins, like lookup in this case

    webtier/              # same kind of structure as "common" was above, done for the webtier role
    monitoring/           # ""
    fooapp/               # ""

    
##How to Differentiate Staging vs Production
#It is suggested that you define groups based on purpose of the host (roles) and also geography or datacenter location (if applicable):

# file: production

[atlanta-webservers]
www-atl-1.example.com
www-atl-2.example.com

[boston-webservers]
www-bos-1.example.com
www-bos-2.example.com

[atlanta-dbservers]
db-atl-1.example.com
db-atl-2.example.com

[boston-dbservers]
db-bos-1.example.com

# webservers in all geos
[webservers:children]
atlanta-webservers
boston-webservers

# dbservers in all geos
[dbservers:children]
atlanta-dbservers
boston-dbservers

# everything in the atlanta geo
[atlanta:children]
atlanta-webservers
atlanta-dbservers

# everything in the boston geo
[boston:children]
boston-webservers
boston-dbservers

##Group And Host Variables
#You can also assign variables to groups
#For instance, atlanta has its own NTP servers, so when setting up ntp.conf, 
#we should use them. 

---
# file: group_vars/atlanta
ntp: ntp-atlanta.example.com
backup: backup-atlanta.example.com

#Maybe the webservers have some configuration 
---
# file: group_vars/webservers
apacheMaxRequestsPerChild: 3000
apacheMaxClients: 900

#If we had any default values, or values that were universally true, 
#we would put them in a file called group_vars/all:

---
# file: group_vars/all
ntp: ntp-boston.example.com
backup: backup-boston.example.com

#We can define specific hardware variance in systems in a host_vars file, 

---
# file: host_vars/db-bos-1.example.com
foo_agent_port: 86
bar_agent_port: 99



##Top Level Playbooks Are Separated By Role
#In site.yml, we import a playbook that defines our entire infrastructure. 

---
# file: site.yml
- import_playbook: webservers.yml
- import_playbook: dbservers.yml

#In a file like webservers.yml (also at the top level), 
#we map the configuration of the webservers group to the roles 
#performed by the webservers group:

---
# file: webservers.yml
- hosts: webservers
  roles:
    - common
    - webtier

#The idea here is that we can choose to configure our whole infrastructure by "running" site.yml 
#or we could just choose to run a subset by running webservers.yml. 

ansible-playbook site.yml --limit webservers
ansible-playbook webservers.yml



##Task And Handler Organization For A Role

#Below is an example tasks file that explains how a role works. 
#common role here just sets up NTP

---
# file: roles/common/tasks/main.yml

- name: be sure ntp is installed
  yum:
    name: ntp
    state: installed
  tags: ntp

- name: be sure ntp is configured
  template:
    src: ntp.conf.j2
    dest: /etc/ntp.conf
  notify:
    - restart ntpd
  tags: ntp

- name: be sure ntpd is running and enabled
  service:
    name: ntpd
    state: started
    enabled: yes
  tags: ntp

#Here is an example handlers file. 
#handlers are only fired when certain tasks report changes, 
#and are run at the end of each play:

---
# file: roles/common/handlers/main.yml
- name: restart ntpd
  service:
    name: ntpd
    state: restarted


##Usecase based on above organizations 

#run completely 
ansible-playbook -i production site.yml

#To reconfigure NTP on everything:

ansible-playbook -i production site.yml --tags ntp

#To reconfigure just my webservers:

ansible-playbook -i production webservers.yml

#For just my webservers in Boston:

ansible-playbook -i production webservers.yml --limit boston

#For just the first 10, and then the next 10:

ansible-playbook -i production webservers.yml --limit boston[0:9]
ansible-playbook -i production webservers.yml --limit boston[10:19]

#just basic ad-hoc stuff is also possible:

ansible boston -i production -m ping
ansible boston -i production -m command -a '/sbin/reboot'

#some useful commands 

# confirm what task names would be run if I ran this command and said "just ntp tasks"
ansible-playbook -i production webservers.yml --tags ntp --list-tasks

# confirm what hostnames might be communicated with if I said "limit to boston"
ansible-playbook -i production webservers.yml --limit boston --list-hosts


##Some Notes 
Staging vs Production
    Testing things in a staging environment before trying in production is always a great idea. 
    Your environments need not be the same size 
    and you can use group variables to control the differences between those environments.

Rolling Updates
    Understand the 'serial' keyword. 
    If updating a webserver farm you really want to use it to control 
    how many machines you are updating at once in the batch.

Always Mention The State
    The 'state' parameter is optional to a lot of modules. 
    Whether 'state=present' or 'state=absent', 
    it is always best to leave that parameter in your playbooks to make it clear, 
    especially as some modules support additional states.
    
Bundling Ansible Modules With Playbooks
    If a playbook has a ./library directory relative to its YAML file, 
    this directory can be used to add ansible modules that will automatically be 
    in the ansible module path. 
    This is a great way to keep modules that go with a playbook together. 

Whitespace and Comments
    Generous use of whitespace to break things up, 
    and use of comments (which start with ‘#'), is encouraged.
    
Always Name Tasks
    It is possible to leave off the 'name' for a given task, 
    though it is recommended to provide a description about 
    why something is being done instead. 
    This name is shown when the playbook is run.
    
Version Control
    Use version control. 
    Keep your playbooks and inventory file in git (or another version control system), 
    and commit when you make changes to them. 
    This way you have an audit trail describing when 
    and why you changed the rules that are automating your infrastructure.
    
Variables and Vaults
    A best practice approach for this is to start with a group_vars/ subdirectory named after the group. 
    Inside of this subdirectory, create two files named vars and vault. 
    Inside of the vars file, define all of the variables needed, including any sensitive ones.
    Next, copy all of the sensitive variables over to the vault file 
    and prefix these variables with vault_. 
    You should adjust the variables in the vars file to point to the matching vault_ variables using jinja2 syntax, 
    and ensure that the vault file is vault encrypted.
    
Group By Roles
    A system can be in multiple groups. 
     Having groups named after things like webservers and dbservers is very good idea 
     repeated in the examples because it's a very powerful concept.

##Operating System and Distribution Variance
#When dealing with a parameter that is different between two different operating systems, 
#a great way to handle this is by using the group_by module.

#This makes a dynamic group of hosts matching certain criteria, 
#even if that group is not defined in the inventory file:

---
#This will throw all systems into a dynamic group based on the operating system name.

 - name: talk to all hosts just so we can learn about them
   hosts: all
   tasks:
     - name: Classify hosts depending on their OS distribution
       group_by:
         key: os_{{ ansible_facts['distribution'] }}

 # now just on the CentOS hosts...
 - hosts: os_CentOS
   gather_facts: False
   tasks:
     - # tasks that only happen on CentOS go here
     
# now just on the Debian hosts...
 - hosts: os_Debian
   gather_facts: False
   tasks:
     - # tasks that only happen on CentOS go here
     
     

#If group-specific settings are needed

---
# file: group_vars/all
asdf: 10

---
# file: group_vars/os_CentOS
asdf: 42

#This can be used not only to set variables, 
#but also to apply certain roles to only certain systems.

#Alternatively, if only variables are needed:

- hosts: all
  tasks:
    - name: Set OS distribution dependant variables
      include_vars: "os_{{ ansible_facts['distribution'] }}.yml"
    - debug:
        var: asdf


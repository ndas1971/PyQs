###ansible-vault
#encryption/decryption utility for Ansible data files
ansible-vault [create|decrypt|edit|encrypt|encrypt_string|rekey|view] [options] [vaultfile.yml]

#can encrypt any structured data file used by Ansible. 
#This can include group_vars/ or host_vars/ inventory variables, 
#variables loaded by include_vars or vars_files, or variable files passed 
#on the ansible-playbook command line with -e @file.yml or -e @file.json. 
#Role variables and defaults are also included

#Because Ansible tasks, handlers, and other objects are data, 
#these can also be encrypted with vault. 
#If you’d like to not expose what variables you are using, 
#you can keep an individual task file entirely encrypted.

#The password used with vault currently must be the same for all files you wish to use 
#together at the same time.

Common Options 
    --ask-vault-pass
        ask for vault password
    --new-vault-id <NEW_VAULT_ID>
        the new vault identity to use for rekey
    --new-vault-password-file
        new vault password file for rekey
    --vault-id
        the vault identity to use
    --vault-password-file
        vault password file
    --version
        show program’s version number and exit
    -h, --help
        show this help message and exit
    -v, --verbose
        verbose mode (-vvv for more, -vvvv to enable connection debugging)
        
Actions
    encrypt
        encrypt the supplied file using the provided vault secret
            --encrypt-vault-id <ENCRYPT_VAULT_ID>
                the vault id used to encrypt (required if more than vault-id is provided)
            --output
                output file name for encrypt or decrypt; use - for stdout
    rekey
        re-encrypt a vaulted file with a new secret, the previous secret is required
            --encrypt-vault-id <ENCRYPT_VAULT_ID>
                the vault id used to encrypt (required if more than vault-id is provided)
    encrypt_string
        encrypt the supplied string using the provided vault secret
            --encrypt-vault-id <ENCRYPT_VAULT_ID>
                the vault id used to encrypt (required if more than vault-id is provided)
            --output
                output file name for encrypt or decrypt; use - for stdout
            --stdin-name <ENCRYPT_STRING_STDIN_NAME>
                Specify the variable name for stdin
            -n, --name
                Specify the variable name
            -p, --prompt
                Prompt for the string to encrypt
        edit
            open and decrypt an existing vaulted file in an editor, that will be encryped again when closed
                --encrypt-vault-id <ENCRYPT_VAULT_ID>
                    the vault id used to encrypt (required if more than vault-id is provided)
        create
            create and open a file in an editor that will be encryped with the provided vault secret when closed
                --encrypt-vault-id <ENCRYPT_VAULT_ID>
                    the vault id used to encrypt (required if more than vault-id is provided)
        decrypt
            decrypt the supplied file using the provided vault secret
                --output
                    output file name for encrypt or decrypt; use - for stdout
        view
            open, decrypt and view an existing vaulted file using a pager using the supplied vault secret
Environment
    ANSIBLE_CONFIG – Override the default ansible config file
Files
    /etc/ansible/ansible.cfg – Config file, used if present
    ~/.ansible.cfg – User config file, overrides the default config if present



###ansible-doc
#plugin documentation tool
ansible-doc [-l|-F|-s] [options] [-t <plugin type> ] [plugin]

#displays information on modules installed in Ansible libraries. 
#It displays a terse listing of plugins and their short descriptions, 
#provides a printout of their DOCUMENTATION strings, 
#and it can create a short “snippet” which can be pasted into a playbook.

Common Options
    --version
        show program’s version number and exit
    -F, --list_files
        Show plugin names and their source files without summaries (implies –list)
    -M, --module-path
        prepend colon-separated path(s) to module library (default=[u’/home/jenkins/.ansible/plugins/modules’, u’/usr/share/ansible/plugins/modules’])
    -a, --all
        For internal testing only Show documentation for all plugins.
    -h, --help
        show this help message and exit
    -j, --json
        For internal testing only Dump json metadata for all plugins.
    -l, --list
        List available plugins
    -s, --snippet
        Show playbook snippet for specified plugin(s)
    -t <TYPE>, --type <TYPE>
        Choose which plugin type (defaults to “module”)
    -v, --verbose
        verbose mode (-vvv for more, -vvvv to enable connection debugging)
Environment
    ANSIBLE_CONFIG – Override the default ansible config file
Files
    /etc/ansible/ansible.cfg – Config file, used if present
    ~/.ansible.cfg – User config file, overrides the default config if present

    
    
###ansible-console
#REPL console for executing Ansible tasks.
ansible-console [<host-pattern>] [options]

#a REPL that allows for running ad-hoc tasks against a chosen inventory 
#(based on dominis’ ansible-shell)

Common Options
    --ask-su-pass
        ask for su password (deprecated, use become)
    --ask-sudo-pass
        ask for sudo password (deprecated, use become)
    --ask-vault-pass
        ask for vault password
    --become-method <BECOME_METHOD>
        privilege escalation method to use (default=sudo), valid choices: [ sudo | su | pbrun | pfexec | doas | dzdo | ksu | runas | pmrun | enable | machinectl ]
    --become-user <BECOME_USER>
        run operations as this user (default=root)
    --list-hosts
        outputs a list of matching hosts; does not execute anything else
    --playbook-dir <BASEDIR>
        Since this tool does not use playbooks, use this as a subsitute playbook directory.This sets the relative path for many features including roles/ group_vars/ etc.
    --private-key, --key-file
        use this file to authenticate the connection
    --scp-extra-args <SCP_EXTRA_ARGS>
        specify extra arguments to pass to scp only (e.g. -l)
    --sftp-extra-args <SFTP_EXTRA_ARGS>
        specify extra arguments to pass to sftp only (e.g. -f, -l)
    --ssh-common-args <SSH_COMMON_ARGS>
        specify common arguments to pass to sftp/scp/ssh (e.g. ProxyCommand)
    --ssh-extra-args <SSH_EXTRA_ARGS>
        specify extra arguments to pass to ssh only (e.g. -R)
    --step
        one-step-at-a-time: confirm each task before running
    --syntax-check
        perform a syntax check on the playbook, but do not execute it
    --vault-id
        the vault identity to use
    --vault-password-file
        vault password file
    --version
        show program’s version number and exit
    -C, --check
        don’t make any changes; instead, try to predict some of the changes that may occur
    -D, --diff
        when changing (small) files and templates, show the differences in those files; works great with –check
    -K, --ask-become-pass
        ask for privilege escalation password
    -M, --module-path
        prepend colon-separated path(s) to module library (default=[u’/home/jenkins/.ansible/plugins/modules’, u’/usr/share/ansible/plugins/modules’])
    -R <SU_USER>, --su-user <SU_USER>
        run operations with su as this user (default=None) (deprecated, use become)
    -S, --su
        run operations with su (deprecated, use become)
    -T <TIMEOUT>, --timeout <TIMEOUT>
        override the connection timeout in seconds (default=10)
    -U <SUDO_USER>, --sudo-user <SUDO_USER>
        desired sudo user (default=root) (deprecated, use become)
    -b, --become
        run operations with become (does not imply password prompting)
    -c <CONNECTION>, --connection <CONNECTION>
        connection type to use (default=smart)
    -f <FORKS>, --forks <FORKS>
        specify number of parallel processes to use (default=5)
    -h, --help
        show this help message and exit
    -i, --inventory, --inventory-file
        specify inventory host path or comma separated host list. –inventory-file is deprecated
    -k, --ask-pass
        ask for connection password
    -l <SUBSET>, --limit <SUBSET>
        further limit selected hosts to an additional pattern
    -s, --sudo
        run operations with sudo (nopasswd) (deprecated, use become)
    -u <REMOTE_USER>, --user <REMOTE_USER>
        connect as this user (default=None)
    -v, --verbose
        verbose mode (-vvv for more, -vvvv to enable connection debugging)
Environment
    ANSIBLE_CONFIG – Override the default ansible config file
Files
    /etc/ansible/ansible.cfg – Config file, used if present
    ~/.ansible.cfg – User config file, overrides the default config if present
    
    
###ansible-playbook
#Runs Ansible playbooks, executing the defined tasks on the targeted hosts.
ansible-playbook [options] playbook.yml [playbook2 ...]

#the tool to run Ansible playbooks, which are a configuration and multinode deployment system. 

Common Options
    --ask-su-pass
        ask for su password (deprecated, use become)
    --ask-sudo-pass
        ask for sudo password (deprecated, use become)
    --ask-vault-pass
        ask for vault password
    --become-method <BECOME_METHOD>
        privilege escalation method to use (default=sudo), valid choices: [ sudo | su | pbrun | pfexec | doas | dzdo | ksu | runas | pmrun | enable | machinectl ]
    --become-user <BECOME_USER>
        run operations as this user (default=root)
    --flush-cache
        clear the fact cache for every host in inventory
    --force-handlers
        run handlers even if a task fails
    --list-hosts
        outputs a list of matching hosts; does not execute anything else
    --list-tags
        list all available tags
    --list-tasks
        list all tasks that would be executed
    --private-key, --key-file
        use this file to authenticate the connection
    --scp-extra-args <SCP_EXTRA_ARGS>
        specify extra arguments to pass to scp only (e.g. -l)
    --sftp-extra-args <SFTP_EXTRA_ARGS>
        specify extra arguments to pass to sftp only (e.g. -f, -l)
    --skip-tags
        only run plays and tasks whose tags do not match these values
    --ssh-common-args <SSH_COMMON_ARGS>
        specify common arguments to pass to sftp/scp/ssh (e.g. ProxyCommand)
    --ssh-extra-args <SSH_EXTRA_ARGS>
        specify extra arguments to pass to ssh only (e.g. -R)
    --start-at-task <START_AT_TASK>
        start the playbook at the task matching this name
    --step
        one-step-at-a-time: confirm each task before running
    --syntax-check
        perform a syntax check on the playbook, but do not execute it
    --vault-id
        the vault identity to use
    --vault-password-file
        vault password file
    --version
        show program’s version number and exit
    -C, --check
        don’t make any changes; instead, try to predict some of the changes that may occur
    -D, --diff
        when changing (small) files and templates, show the differences in those files; works great with –check
    -K, --ask-become-pass
        ask for privilege escalation password
    -M, --module-path
        prepend colon-separated path(s) to module library (default=[u’/home/jenkins/.ansible/plugins/modules’, u’/usr/share/ansible/plugins/modules’])
    -R <SU_USER>, --su-user <SU_USER>
        run operations with su as this user (default=None) (deprecated, use become)
    -S, --su
        run operations with su (deprecated, use become)
    -T <TIMEOUT>, --timeout <TIMEOUT>
        override the connection timeout in seconds (default=10)
    -U <SUDO_USER>, --sudo-user <SUDO_USER>
        desired sudo user (default=root) (deprecated, use become)
    -b, --become
        run operations with become (does not imply password prompting)
    -c <CONNECTION>, --connection <CONNECTION>
        connection type to use (default=smart)
    -e, --extra-vars
        set additional variables as key=value or YAML/JSON, if filename prepend with @
    -f <FORKS>, --forks <FORKS>
        specify number of parallel processes to use (default=5)
    -h, --help
        show this help message and exit
    -i, --inventory, --inventory-file
        specify inventory host path or comma separated host list. –inventory-file is deprecated
    -k, --ask-pass
        ask for connection password
    -l <SUBSET>, --limit <SUBSET>
        further limit selected hosts to an additional pattern
    -s, --sudo
        run operations with sudo (nopasswd) (deprecated, use become)
    -t, --tags
        only run plays and tasks tagged with these values
    -u <REMOTE_USER>, --user <REMOTE_USER>
        connect as this user (default=None)
    -v, --verbose
        verbose mode (-vvv for more, -vvvv to enable connection debugging)
Environment
    ANSIBLE_CONFIG – Override the default ansible config file
Files
    /etc/ansible/ansible.cfg – Config file, used if present
    ~/.ansible.cfg – User config file, overrides the default config if present
    
    
    
###ansible
#Define and run a single task ‘playbook’ against a set of hosts
ansible <host-pattern> [options]

#an extra-simple tool/framework/API for doing ‘remote things’. 
#this command allows you to define and run a single task ‘playbook’ against a set of hosts

Common Options
    --ask-su-pass
        ask for su password (deprecated, use become)
    --ask-sudo-pass
        ask for sudo password (deprecated, use become)
    --ask-vault-pass
        ask for vault password
    --become-method <BECOME_METHOD>
        privilege escalation method to use (default=sudo), valid choices: [ sudo | su | pbrun | pfexec | doas | dzdo | ksu | runas | pmrun | enable | machinectl ]
    --become-user <BECOME_USER>
        run operations as this user (default=root)
    --list-hosts
        outputs a list of matching hosts; does not execute anything else
    --playbook-dir <BASEDIR>
        Since this tool does not use playbooks, use this as a subsitute playbook directory.This sets the relative path for many features including roles/ group_vars/ etc.
    --private-key, --key-file
        use this file to authenticate the connection
    --scp-extra-args <SCP_EXTRA_ARGS>
        specify extra arguments to pass to scp only (e.g. -l)
    --sftp-extra-args <SFTP_EXTRA_ARGS>
        specify extra arguments to pass to sftp only (e.g. -f, -l)
    --ssh-common-args <SSH_COMMON_ARGS>
        specify common arguments to pass to sftp/scp/ssh (e.g. ProxyCommand)
    --ssh-extra-args <SSH_EXTRA_ARGS>
        specify extra arguments to pass to ssh only (e.g. -R)
    --syntax-check
        perform a syntax check on the playbook, but do not execute it
    --vault-id
        the vault identity to use
    --vault-password-file
        vault password file
    --version
        show program’s version number and exit
    -B <SECONDS>, --background <SECONDS>
        run asynchronously, failing after X seconds (default=N/A)
    -C, --check
        don’t make any changes; instead, try to predict some of the changes that may occur
    -D, --diff
        when changing (small) files and templates, show the differences in those files; works great with –check
    -K, --ask-become-pass
        ask for privilege escalation password
    -M, --module-path
        prepend colon-separated path(s) to module library (default=[u’/home/jenkins/.ansible/plugins/modules’, u’/usr/share/ansible/plugins/modules’])
    -P <POLL_INTERVAL>, --poll <POLL_INTERVAL>
        set the poll interval if using -B (default=15)
    -R <SU_USER>, --su-user <SU_USER>
        run operations with su as this user (default=None) (deprecated, use become)
    -S, --su
        run operations with su (deprecated, use become)
    -T <TIMEOUT>, --timeout <TIMEOUT>
        override the connection timeout in seconds (default=10)
    -U <SUDO_USER>, --sudo-user <SUDO_USER>
        desired sudo user (default=root) (deprecated, use become)
    -a <MODULE_ARGS>, --args <MODULE_ARGS>
        module arguments
    -b, --become
        run operations with become (does not imply password prompting)
    -c <CONNECTION>, --connection <CONNECTION>
        connection type to use (default=smart)
    -e, --extra-vars
        set additional variables as key=value or YAML/JSON, if filename prepend with @
    -f <FORKS>, --forks <FORKS>
        specify number of parallel processes to use (default=5)
    -h, --help
        show this help message and exit
    -i, --inventory, --inventory-file
        specify inventory host path or comma separated host list. –inventory-file is deprecated
    -k, --ask-pass
        ask for connection password
    -l <SUBSET>, --limit <SUBSET>
        further limit selected hosts to an additional pattern
    -m <MODULE_NAME>, --module-name <MODULE_NAME>
        module name to execute (default=command)
    -o, --one-line
        condense output
    -s, --sudo
        run operations with sudo (nopasswd) (deprecated, use become)
    -t <TREE>, --tree <TREE>
        log output to this directory
    -u <REMOTE_USER>, --user <REMOTE_USER>
        connect as this user (default=None)
    -v, --verbose
        verbose mode (-vvv for more, -vvvv to enable connection debugging)
Environment
    ANSIBLE_CONFIG – Override the default ansible config file
Files
    /etc/ansible/ansible.cfg – Config file, used if present
    ~/.ansible.cfg – User config file, overrides the default config if present
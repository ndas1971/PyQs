###Cloud modules - Amazon
    aws_acm_facts – Retrieve certificate facts from AWS Certificate Manager service
    aws_api_gateway – Manage AWS API Gateway APIs
    aws_application_scaling_policy – Manage Application Auto Scaling Scaling Policies
    aws_az_facts – Gather facts about availability zones in AWS.
    aws_batch_compute_environment – Manage AWS Batch Compute Environments
    aws_batch_job_definition – Manage AWS Batch Job Definitions
    aws_batch_job_queue – Manage AWS Batch Job Queues
    aws_caller_facts – Get facts about the user and account being used to make AWS calls.
    aws_config_aggregation_authorization – Manage cross-account AWS Config authorizations
    aws_config_aggregator – Manage AWS Config aggregations across multiple accounts
    aws_config_delivery_channel – Manage AWS Config delivery channels
    aws_config_recorder – Manage AWS Config Recorders
    aws_config_rule – Manage AWS Config resources
    aws_direct_connect_connection – Creates, deletes, modifies a DirectConnect connection
    aws_direct_connect_gateway – Manage AWS Direct Connect Gateway.
    aws_direct_connect_link_aggregation_group – Manage Direct Connect LAG bundles.
    aws_direct_connect_virtual_interface – Manage Direct Connect virtual interfaces.
    aws_eks_cluster – Manage Elastic Kubernetes Service Clusters
    aws_elasticbeanstalk_app – create, update, and delete an elastic beanstalk application
    aws_glue_connection – Manage an AWS Glue connection
    aws_glue_job – Manage an AWS Glue job
    aws_inspector_target – Create, Update and Delete Amazon Inspector Assessment Targets
    aws_kms – Perform various KMS management tasks.
    aws_kms_facts – Gather facts about AWS KMS keys
    aws_region_facts – Gather facts about AWS regions.
    aws_s3 – manage objects in S3.
    aws_s3_bucket_facts – Lists S3 buckets in AWS
    aws_s3_cors – Manage CORS for S3 buckets in AWS
    aws_ses_identity – Manages SES email and domain identity
    aws_ses_identity_policy – Manages SES sending authorization policies
    aws_sgw_facts – Fetch AWS Storage Gateway facts
    aws_ssm_parameter_store – Manage key-value pairs in aws parameter store.
    aws_waf_condition – create and delete WAF Conditions
    aws_waf_facts – Retrieve facts for WAF ACLs, Rule , Conditions and Filters.
    aws_waf_rule – create and delete WAF Rules
    aws_waf_web_acl – create and delete WAF Web ACLs
    cloudformation – Create or delete an AWS CloudFormation stack
    cloudformation_facts – Obtain facts about an AWS CloudFormation stack
    cloudformation_stack_set – Manage groups of CloudFormation stacks
    cloudfront_distribution – create, update and delete aws cloudfront distributions.
    cloudfront_facts – Obtain facts about an AWS CloudFront distribution
    cloudfront_invalidation – create invalidations for aws cloudfront distributions
    cloudfront_origin_access_identity – create, update and delete origin access identities for a cloudfront distribution.
    cloudtrail – manage CloudTrail create, delete, update
    cloudwatchevent_rule – Manage CloudWatch Event rules and targets
    cloudwatchlogs_log_group – create or delete log_group in CloudWatchLogs
    cloudwatchlogs_log_group_facts – get facts about log_group in CloudWatchLogs
    data_pipeline – Create and manage AWS Datapipelines
    dynamodb_table – Create, update or delete AWS Dynamo DB tables.
    dynamodb_ttl – set TTL for a given DynamoDB table.
    ec2 – create, terminate, start or stop an instance in ec2
    ec2_ami – create or destroy an image in ec2
    ec2_ami_copy – copies AMI between AWS regions, return new image id
    ec2_ami_facts – Gather facts about ec2 AMIs
    ec2_ami_find – Searches for AMIs to obtain the AMI ID and other information (D)
    ec2_asg – Create or delete AWS Autoscaling Groups
    ec2_asg_facts – Gather facts about ec2 Auto Scaling Groups (ASGs) in AWS
    ec2_asg_lifecycle_hook – Create, delete or update AWS ASG Lifecycle Hooks.
    ec2_customer_gateway – Manage an AWS customer gateway
    ec2_customer_gateway_facts – Gather facts about customer gateways in AWS
    ec2_eip – manages EC2 elastic IP (EIP) addresses.
    ec2_eip_facts – List EC2 EIP details
    ec2_elb – De-registers or registers instances from EC2 ELBs
    ec2_elb_facts – Gather facts about EC2 Elastic Load Balancers in AWS
    ec2_elb_lb – Creates or destroys Amazon ELB.
    ec2_eni – Create and optionally attach an Elastic Network Interface (ENI) to an instance
    ec2_eni_facts – Gather facts about ec2 ENI interfaces in AWS
    ec2_group – maintain an ec2 VPC security group.
    ec2_group_facts – Gather facts about ec2 security groups in AWS.
    ec2_instance – Create & manage EC2 instances
    ec2_instance_facts – Gather facts about ec2 instances in AWS
    ec2_key – create or delete an ec2 key pair
    ec2_lc – Create or delete AWS Autoscaling Launch Configurations
    ec2_lc_facts – Gather facts about AWS Autoscaling Launch Configurations
    ec2_lc_find – Find AWS Autoscaling Launch Configurations
    ec2_metadata_facts – Gathers facts (instance metadata) about remote hosts within ec2
    ec2_metric_alarm – Create/update or delete AWS Cloudwatch ‘metric alarms’
    ec2_placement_group – Create or delete an EC2 Placement Group
    ec2_placement_group_facts – List EC2 Placement Group(s) details
    ec2_remote_facts – Gather facts about ec2 instances in AWS (D)
    ec2_scaling_policy – Create or delete AWS scaling policies for Autoscaling groups
    ec2_snapshot – creates a snapshot from an existing volume
    ec2_snapshot_copy – copies an EC2 snapshot and returns the new Snapshot ID.
    ec2_snapshot_facts – Gather facts about ec2 volume snapshots in AWS
    ec2_tag – create and remove tags on ec2 resources.
    ec2_vol – create and attach a volume, return volume id and device map
    ec2_vol_facts – Gather facts about ec2 volumes in AWS
    ec2_vpc_dhcp_option – Manages DHCP Options, and can ensure the DHCP options for the given VPC match what’s requested
    ec2_vpc_dhcp_option_facts – Gather facts about dhcp options sets in AWS
    ec2_vpc_egress_igw – Manage an AWS VPC Egress Only Internet gateway
    ec2_vpc_endpoint – Create and delete AWS VPC Endpoints.
    ec2_vpc_endpoint_facts – Retrieves AWS VPC endpoints details using AWS methods.
    ec2_vpc_igw – Manage an AWS VPC Internet gateway
    ec2_vpc_igw_facts – Gather facts about internet gateways in AWS
    ec2_vpc_nacl – create and delete Network ACLs.
    ec2_vpc_nacl_facts – Gather facts about Network ACLs in an AWS VPC
    ec2_vpc_nat_gateway – Manage AWS VPC NAT Gateways.
    ec2_vpc_nat_gateway_facts – Retrieves AWS VPC Managed Nat Gateway details using AWS methods.
    ec2_vpc_net – Configure AWS virtual private clouds
    ec2_vpc_net_facts – Gather facts about ec2 VPCs in AWS
    ec2_vpc_peer – create, delete, accept, and reject VPC peering connections between two VPCs.
    ec2_vpc_peering_facts – Retrieves AWS VPC Peering details using AWS methods.
    ec2_vpc_route_table – Manage route tables for AWS virtual private clouds
    ec2_vpc_route_table_facts – Gather facts about ec2 VPC route tables in AWS
    ec2_vpc_subnet – Manage subnets in AWS virtual private clouds
    ec2_vpc_subnet_facts – Gather facts about ec2 VPC subnets in AWS
    ec2_vpc_vgw – Create and delete AWS VPN Virtual Gateways.
    ec2_vpc_vgw_facts – Gather facts about virtual gateways in AWS
    ec2_vpc_vpn – Create, modify, and delete EC2 VPN connections.
    ec2_vpc_vpn_facts – Gather facts about VPN Connections in AWS.
    ec2_win_password – gets the default administrator password for ec2 windows instances
    ecs_attribute – manage ecs attributes
    ecs_cluster – create or terminate ecs clusters
    ecs_ecr – Manage Elastic Container Registry repositories
    ecs_service – create, terminate, start or stop a service in ecs
    ecs_service_facts – list or describe services in ecs
    ecs_task – run, start or stop a task in ecs
    ecs_taskdefinition – register a task definition in ecs
    ecs_taskdefinition_facts – describe a task definition in ecs
    efs – create and maintain EFS file systems
    efs_facts – Get information about Amazon EFS file systems
    elasticache – Manage cache clusters in Amazon Elasticache.
    elasticache_facts – Retrieve facts for AWS Elasticache clusters
    elasticache_parameter_group – Manage cache security groups in Amazon Elasticache.
    elasticache_snapshot – Manage cache snapshots in Amazon Elasticache.
    elasticache_subnet_group – manage Elasticache subnet groups
    elb_application_lb – Manage an Application load balancer
    elb_application_lb_facts – Gather facts about application ELBs in AWS
    elb_classic_lb – Creates or destroys Amazon ELB.
    elb_classic_lb_facts – Gather facts about EC2 Elastic Load Balancers in AWS
    elb_instance – De-registers or registers instances from EC2 ELBs
    elb_network_lb – Manage a Network Load Balancer
    elb_target – Manage a target in a target group
    elb_target_facts – Gathers which target groups a target is associated with.
    elb_target_group – Manage a target group for an Application or Network load balancer
    elb_target_group_facts – Gather facts about ELB target groups in AWS
    execute_lambda – Execute an AWS Lambda function
    iam – Manage IAM users, groups, roles and keys
    iam_cert – Manage server certificates for use on ELBs and CloudFront
    iam_group – Manage AWS IAM groups
    iam_managed_policy – Manage User Managed IAM policies
    iam_mfa_device_facts – List the MFA (Multi-Factor Authentication) devices registered for a user
    iam_policy – Manage IAM policies for users, groups, and roles
    iam_role – Manage AWS IAM roles
    iam_role_facts – Gather information on IAM roles
    iam_server_certificate_facts – Retrieve the facts of a server certificate
    iam_user – Manage AWS IAM users
    kinesis_stream – Manage a Kinesis Stream.
    lambda – Manage AWS Lambda functions
    lambda_alias – Creates, updates or deletes AWS Lambda function aliases.
    lambda_event – Creates, updates or deletes AWS Lambda function event mappings.
    lambda_facts – Gathers AWS Lambda function details as Ansible facts
    lambda_policy – Creates, updates or deletes AWS Lambda policy statements.
    lightsail – Create or delete a virtual machine instance in AWS Lightsail
    rds – create, delete, or modify an Amazon rds instance
    rds_instance – Manage RDS instances
    rds_instance_facts – obtain facts about one or more RDS instances
    rds_param_group – manage RDS parameter groups
    rds_snapshot_facts – obtain facts about one or more RDS snapshots
    rds_subnet_group – manage RDS database subnet groups
    redshift – create, delete, or modify an Amazon Redshift instance
    redshift_facts – Gather facts about Redshift cluster(s)
    redshift_subnet_group – manage Redshift cluster subnet groups
    route53 – add or delete entries in Amazons Route53 DNS service
    route53_facts – Retrieves route53 details using AWS methods
    route53_health_check – add or delete health-checks in Amazons Route53 DNS service
    route53_zone – add or delete Route53 zones
    s3_bucket – Manage S3 buckets in AWS, Ceph, Walrus and FakeS3
    s3_lifecycle – Manage s3 bucket lifecycle rules in AWS
    s3_logging – Manage logging facility of an s3 bucket in AWS
    s3_sync – Efficiently upload multiple files to S3
    s3_website – Configure an s3 bucket as a website
    sns – Send Amazon Simple Notification Service (SNS) messages
    sns_topic – Manages AWS SNS topics and subscriptions
    sqs_queue – Creates or deletes AWS SQS queues.
    sts_assume_role – Assume a role using AWS Security Token Service and obtain temporary credentials
    sts_session_token – Obtain a session token from the AWS Security Token Service

###Cloud modules - Atomic
    atomic_container – Manage the containers on the atomic host platform
    atomic_host – Manage the atomic host platform
    atomic_image – Manage the container images on the atomic host platform
###Cloud modules - Azure
    azure – create or terminate a virtual machine in azure (D)
    azure_rm_acs – Manage an Azure Container Service Instance (ACS).
    azure_rm_aks – Manage a managed Azure Container Service (AKS) Instance.
    azure_rm_aks_facts – Get Azure Kubernetes Service facts.
    azure_rm_appgateway – Manage Application Gateway instance.
    azure_rm_appserviceplan – Manage App Service Plan
    azure_rm_appserviceplan_facts – Get azure app service plan facts.
    azure_rm_autoscale – Manage Azure autoscale setting.
    azure_rm_autoscale_facts – Get Azure Auto Scale Setting facts.
    azure_rm_availabilityset – Manage Azure availability set.
    azure_rm_availabilityset_facts – Get availability set facts.
    azure_rm_containerinstance – Manage an Azure Container Instance.
    azure_rm_containerregistry – Manage an Azure Container Registry.
    azure_rm_containerregistry_facts – Get Azure Container Registry facts.
    azure_rm_deployment – Create or destroy Azure Resource Manager template deployments
    azure_rm_dnsrecordset – Create, delete and update DNS record sets and records.
    azure_rm_dnsrecordset_facts – Get DNS Record Set facts.
    azure_rm_dnszone – Manage Azure DNS zones.
    azure_rm_dnszone_facts – Get DNS zone facts.
    azure_rm_functionapp – Manage Azure Function Apps
    azure_rm_functionapp_facts – Get Azure Function App facts
    azure_rm_image – Manage Azure image.
    azure_rm_keyvault – Manage Key Vault instance.
    azure_rm_keyvaultkey – Use Azure KeyVault keys.
    azure_rm_keyvaultsecret – Use Azure KeyVault Secrets.
    azure_rm_loadbalancer – Manage Azure load balancers.
    azure_rm_loadbalancer_facts – Get load balancer facts.
    azure_rm_managed_disk – Manage Azure Manage Disks
    azure_rm_managed_disk_facts – Get managed disk facts.
    azure_rm_mysqldatabase – Manage MySQL Database instance.
    azure_rm_mysqldatabase_facts – Get Azure MySQL Database facts.
    azure_rm_mysqlserver – Manage MySQL Server instance.
    azure_rm_mysqlserver_facts – Get Azure MySQL Server facts.
    azure_rm_networkinterface – Manage Azure network interfaces.
    azure_rm_networkinterface_facts – Get network interface facts.
    azure_rm_postgresqldatabase – Manage PostgreSQL Database instance.
    azure_rm_postgresqldatabase_facts – Get Azure PostgreSQL Database facts.
    azure_rm_postgresqlserver – Manage PostgreSQL Server instance.
    azure_rm_postgresqlserver_facts – Get Azure PostgreSQL Server facts.
    azure_rm_publicipaddress – Manage Azure Public IP Addresses.
    azure_rm_publicipaddress_facts – Get public IP facts.
    azure_rm_resource – Create any Azure resource.
    azure_rm_resource_facts – Generic facts of Azure resources.
    azure_rm_resourcegroup – Manage Azure resource groups.
    azure_rm_resourcegroup_facts – Get resource group facts.
    azure_rm_route – Manage Azure route resource.
    azure_rm_routetable – Manage Azure route table resource.
    azure_rm_routetable_facts – Get route table facts.
    azure_rm_securitygroup – Manage Azure network security groups.
    azure_rm_securitygroup_facts – Get security group facts.
    azure_rm_sqldatabase – Manage SQL Database instance.
    azure_rm_sqlfirewallrule – Manage Firewall Rule instance.
    azure_rm_sqlserver – Manage SQL Server instance
    azure_rm_sqlserver_facts – Get SQL Server facts.
    azure_rm_storageaccount – Manage Azure storage accounts.
    azure_rm_storageaccount_facts – Get storage account facts.
    azure_rm_storageblob – Manage blob containers and blob objects.
    azure_rm_subnet – Manage Azure subnets.
    azure_rm_trafficmanagerendpoint – Manage Azure Traffic Manager endpoint.
    azure_rm_trafficmanagerendpoint_facts – Get Azure Traffic Manager endpoint facts
    azure_rm_trafficmanagerprofile – Manage Azure Traffic Manager profile.
    azure_rm_trafficmanagerprofile_facts – Get Azure Traffic Manager profile facts
    azure_rm_virtualmachine – Manage Azure virtual machines.
    azure_rm_virtualmachine_extension – Managed Azure Virtual Machine extension
    azure_rm_virtualmachine_facts – Get virtual machine facts.
    azure_rm_virtualmachine_scaleset – Manage Azure virtual machine scale sets.
    azure_rm_virtualmachine_scaleset_facts – Get Virtual Machine Scale Set facts
    azure_rm_virtualmachineimage_facts – Get virtual machine image facts.
    azure_rm_virtualnetwork – Manage Azure virtual networks.
    azure_rm_virtualnetwork_facts – Get virtual network facts.
    azure_rm_webapp – Manage Web App instance.
    azure_rm_webapp_facts – Get azure web app facts.
###Cloud modules - Centurylink
    clc_aa_policy – Create or Delete Anti Affinity Policies at CenturyLink Cloud.
    clc_alert_policy – Create or Delete Alert Policies at CenturyLink Cloud.
    clc_blueprint_package – deploys a blue print package on a set of servers in CenturyLink Cloud.
    clc_firewall_policy – Create/delete/update firewall policies
    clc_group – Create/delete Server Groups at Centurylink Cloud
    clc_loadbalancer – Create, Delete shared loadbalancers in CenturyLink Cloud.
    clc_modify_server – modify servers in CenturyLink Cloud.
    clc_publicip – Add and Delete public ips on servers in CenturyLink Cloud.
    clc_server – Create, Delete, Start and Stop servers in CenturyLink Cloud.
    clc_server_snapshot – Create, Delete and Restore server snapshots in CenturyLink Cloud.
###Cloud modules - Cloudscale
    cloudscale_floating_ip – Manages floating IPs on the cloudscale.ch IaaS service
    cloudscale_server – Manages servers on the cloudscale.ch IaaS service
###Cloud modules - Cloudstack
    cs_account – Manages accounts on Apache CloudStack based clouds.
    cs_affinitygroup – Manages affinity groups on Apache CloudStack based clouds.
    cs_cluster – Manages host clusters on Apache CloudStack based clouds.
    cs_configuration – Manages configuration on Apache CloudStack based clouds.
    cs_disk_offering – Manages disk offerings on Apache CloudStack based clouds.
    cs_domain – Manages domains on Apache CloudStack based clouds.
    cs_facts – Gather facts on instances of Apache CloudStack based clouds.
    cs_firewall – Manages firewall rules on Apache CloudStack based clouds.
    cs_host – Manages hosts on Apache CloudStack based clouds.
    cs_instance – Manages instances and virtual machines on Apache CloudStack based clouds.
    cs_instance_facts – Gathering facts from the API of instances from Apache CloudStack based clouds.
    cs_instance_nic – Manages NICs of an instance on Apache CloudStack based clouds.
    cs_instance_nic_secondaryip – Manages secondary IPs of an instance on Apache CloudStack based clouds.
    cs_instancegroup – Manages instance groups on Apache CloudStack based clouds.
    cs_ip_address – Manages public IP address associations on Apache CloudStack based clouds.
    cs_iso – Manages ISO images on Apache CloudStack based clouds.
    cs_loadbalancer_rule – Manages load balancer rules on Apache CloudStack based clouds.
    cs_loadbalancer_rule_member – Manages load balancer rule members on Apache CloudStack based clouds.
    cs_network – Manages networks on Apache CloudStack based clouds.
    cs_network_acl – Manages network access control lists (ACL) on Apache CloudStack based clouds.
    cs_network_acl_rule – Manages network access control list (ACL) rules on Apache CloudStack based clouds.
    cs_network_offering – Manages network offerings on Apache CloudStack based clouds.
    cs_nic – Manages NICs and secondary IPs of an instance on Apache CloudStack based clouds (D)
    cs_pod – Manages pods on Apache CloudStack based clouds.
    cs_portforward – Manages port forwarding rules on Apache CloudStack based clouds.
    cs_project – Manages projects on Apache CloudStack based clouds.
    cs_region – Manages regions on Apache CloudStack based clouds.
    cs_resourcelimit – Manages resource limits on Apache CloudStack based clouds.
    cs_role – Manages user roles on Apache CloudStack based clouds.
    cs_role_permission – Manages role permissions on Apache CloudStack based clouds.
    cs_router – Manages routers on Apache CloudStack based clouds.
    cs_securitygroup – Manages security groups on Apache CloudStack based clouds.
    cs_securitygroup_rule – Manages security group rules on Apache CloudStack based clouds.
    cs_service_offering – Manages service offerings on Apache CloudStack based clouds.
    cs_snapshot_policy – Manages volume snapshot policies on Apache CloudStack based clouds.
    cs_sshkeypair – Manages SSH keys on Apache CloudStack based clouds.
    cs_staticnat – Manages static NATs on Apache CloudStack based clouds.
    cs_storage_pool – Manages Primary Storage Pools on Apache CloudStack based clouds.
    cs_template – Manages templates on Apache CloudStack based clouds.
    cs_user – Manages users on Apache CloudStack based clouds.
    cs_vmsnapshot – Manages VM snapshots on Apache CloudStack based clouds.
    cs_volume – Manages volumes on Apache CloudStack based clouds.
    cs_vpc – Manages VPCs on Apache CloudStack based clouds.
    cs_vpc_offering – Manages vpc offerings on Apache CloudStack based clouds.
    cs_vpn_connection – Manages site-to-site VPN connections on Apache CloudStack based clouds.
    cs_vpn_customer_gateway – Manages site-to-site VPN customer gateway configurations on Apache CloudStack based clouds.
    cs_vpn_gateway – Manages site-to-site VPN gateways on Apache CloudStack based clouds.
    cs_zone – Manages zones on Apache CloudStack based clouds.
    cs_zone_facts – Gathering facts of zones from Apache CloudStack based clouds.
###Cloud modules - Digital_Ocean
    digital_ocean – Create/delete a droplet/SSH_key in DigitalOcean
    digital_ocean_account_facts – Gather facts about DigitalOcean User account
    digital_ocean_block_storage – Create/destroy or attach/detach Block Storage volumes in DigitalOcean
    digital_ocean_certificate – Manage certificates in DigitalOcean.
    digital_ocean_certificate_facts – Gather facts about DigitalOcean certificates
    digital_ocean_domain – Create/delete a DNS domain in DigitalOcean
    digital_ocean_domain_facts – Gather facts about DigitalOcean Domains
    digital_ocean_floating_ip – Manage DigitalOcean Floating IPs
    digital_ocean_floating_ip_facts – DigitalOcean Floating IPs facts
    digital_ocean_image_facts – Gather facts about DigitalOcean images
    digital_ocean_load_balancer_facts – Gather facts about DigitalOcean load balancers
    digital_ocean_region_facts – Gather facts about DigitalOcean regions
    digital_ocean_size_facts – Gather facts about DigitalOcean Droplet sizes
    digital_ocean_snapshot_facts – Gather facts about DigitalOcean Snapshot
    digital_ocean_sshkey – Manage DigitalOcean SSH keys
    digital_ocean_sshkey_facts – DigitalOcean SSH keys facts
    digital_ocean_tag – Create and remove tag(s) to DigitalOcean resource.
    digital_ocean_tag_facts – Gather facts about DigitalOcean tags
    digital_ocean_volume_facts – Gather facts about DigitalOcean volumes
###Cloud modules - Dimensiondata
    dimensiondata_network – Create, update, and delete MCP 1.0 & 2.0 networks
    dimensiondata_vlan – Manage a VLAN in a Cloud Control network domain.
###Cloud modules - Docker
    docker_container – manage docker containers
    docker_image – Manage docker images.
    docker_image_facts – Inspect docker images
    docker_login – Log into a Docker registry.
    docker_network – Manage Docker networks
    docker_secret – Manage docker secrets.
    docker_service – Manage docker services and containers.
    docker_swarm – Manage Swarm cluster
    docker_swarm_service – docker swarm service
    docker_volume – Manage Docker volumes
###Cloud modules - Google
    gc_storage – This module manages objects/buckets in Google Cloud Storage.
    gcdns_record – Creates or removes resource records in Google Cloud DNS
    gcdns_zone – Creates or removes zones in Google Cloud DNS
    gce – create or terminate GCE instances
    gce_eip – Create or Destroy Global or Regional External IP addresses.
    gce_img – utilize GCE image resources
    gce_instance_template – create or destroy instance templates of Compute Engine of GCP.
    gce_labels – Create, Update or Destroy GCE Labels.
    gce_lb – create/destroy GCE load-balancer resources
    gce_mig – Create, Update or Destroy a Managed Instance Group (MIG).
    gce_net – create/destroy GCE networks and firewall rules
    gce_pd – utilize GCE persistent disk resources
    gce_snapshot – Create or destroy snapshots for GCE storage volumes
    gce_tag – add or remove tag(s) to/from GCE instances
    gcp_backend_service – Create or Destroy a Backend Service.
    gcp_compute_address – Creates a GCP Address
    gcp_compute_address_facts – Gather facts for GCP Address
    gcp_compute_backend_bucket – Creates a GCP BackendBucket
    gcp_compute_backend_bucket_facts – Gather facts for GCP BackendBucket
    gcp_compute_backend_service – Creates a GCP BackendService
    gcp_compute_backend_service_facts – Gather facts for GCP BackendService
    gcp_compute_disk – Creates a GCP Disk
    gcp_compute_disk_facts – Gather facts for GCP Disk
    gcp_compute_firewall – Creates a GCP Firewall
    gcp_compute_firewall_facts – Gather facts for GCP Firewall
    gcp_compute_forwarding_rule – Creates a GCP ForwardingRule
    gcp_compute_forwarding_rule_facts – Gather facts for GCP ForwardingRule
    gcp_compute_global_address – Creates a GCP GlobalAddress
    gcp_compute_global_address_facts – Gather facts for GCP GlobalAddress
    gcp_compute_global_forwarding_rule – Creates a GCP GlobalForwardingRule
    gcp_compute_global_forwarding_rule_facts – Gather facts for GCP GlobalForwardingRule
    gcp_compute_health_check – Creates a GCP HealthCheck
    gcp_compute_health_check_facts – Gather facts for GCP HealthCheck
    gcp_compute_http_health_check – Creates a GCP HttpHealthCheck
    gcp_compute_http_health_check_facts – Gather facts for GCP HttpHealthCheck
    gcp_compute_https_health_check – Creates a GCP HttpsHealthCheck
    gcp_compute_https_health_check_facts – Gather facts for GCP HttpsHealthCheck
    gcp_compute_image – Creates a GCP Image
    gcp_compute_image_facts – Gather facts for GCP Image
    gcp_compute_instance – Creates a GCP Instance
    gcp_compute_instance_facts – Gather facts for GCP Instance
    gcp_compute_instance_group – Creates a GCP InstanceGroup
    gcp_compute_instance_group_facts – Gather facts for GCP InstanceGroup
    gcp_compute_instance_group_manager – Creates a GCP InstanceGroupManager
    gcp_compute_instance_group_manager_facts – Gather facts for GCP InstanceGroupManager
    gcp_compute_instance_template – Creates a GCP InstanceTemplate
    gcp_compute_instance_template_facts – Gather facts for GCP InstanceTemplate
    gcp_compute_network – Creates a GCP Network
    gcp_compute_network_facts – Gather facts for GCP Network
    gcp_compute_route – Creates a GCP Route
    gcp_compute_route_facts – Gather facts for GCP Route
    gcp_compute_router – Creates a GCP Router
    gcp_compute_router_facts – Gather facts for GCP Router
    gcp_compute_ssl_certificate – Creates a GCP SslCertificate
    gcp_compute_ssl_certificate_facts – Gather facts for GCP SslCertificate
    gcp_compute_ssl_policy – Creates a GCP SslPolicy
    gcp_compute_ssl_policy_facts – Gather facts for GCP SslPolicy
    gcp_compute_subnetwork – Creates a GCP Subnetwork
    gcp_compute_subnetwork_facts – Gather facts for GCP Subnetwork
    gcp_compute_target_http_proxy – Creates a GCP TargetHttpProxy
    gcp_compute_target_http_proxy_facts – Gather facts for GCP TargetHttpProxy
    gcp_compute_target_https_proxy – Creates a GCP TargetHttpsProxy
    gcp_compute_target_https_proxy_facts – Gather facts for GCP TargetHttpsProxy
    gcp_compute_target_pool – Creates a GCP TargetPool
    gcp_compute_target_pool_facts – Gather facts for GCP TargetPool
    gcp_compute_target_ssl_proxy – Creates a GCP TargetSslProxy
    gcp_compute_target_ssl_proxy_facts – Gather facts for GCP TargetSslProxy
    gcp_compute_target_tcp_proxy – Creates a GCP TargetTcpProxy
    gcp_compute_target_tcp_proxy_facts – Gather facts for GCP TargetTcpProxy
    gcp_compute_target_vpn_gateway – Creates a GCP TargetVpnGateway
    gcp_compute_target_vpn_gateway_facts – Gather facts for GCP TargetVpnGateway
    gcp_compute_url_map – Creates a GCP UrlMap
    gcp_compute_url_map_facts – Gather facts for GCP UrlMap
    gcp_compute_vpn_tunnel – Creates a GCP VpnTunnel
    gcp_compute_vpn_tunnel_facts – Gather facts for GCP VpnTunnel
    gcp_container_cluster – Creates a GCP Cluster
    gcp_container_node_pool – Creates a GCP NodePool
    gcp_dns_managed_zone – Creates a GCP ManagedZone
    gcp_dns_resource_record_set – Creates a GCP ResourceRecordSet
    gcp_forwarding_rule – Create, Update or Destroy a Forwarding_Rule.
    gcp_healthcheck – Create, Update or Destroy a Healthcheck.
    gcp_pubsub_subscription – Creates a GCP Subscription
    gcp_pubsub_topic – Creates a GCP Topic
    gcp_spanner_database – Creates a GCP Database
    gcp_spanner_instance – Creates a GCP Instance
    gcp_sql_database – Creates a GCP Database
    gcp_sql_instance – Creates a GCP Instance
    gcp_sql_user – Creates a GCP User
    gcp_storage_bucket – Creates a GCP Bucket
    gcp_storage_bucket_access_control – Creates a GCP BucketAccessControl
    gcp_target_proxy – Create, Update or Destroy a Target_Proxy.
    gcp_url_map – Create, Update or Destory a Url_Map.
    gcpubsub – Create and Delete Topics/Subscriptions, Publish and pull messages on PubSub
    gcpubsub_facts – List Topics/Subscriptions and Messages from Google PubSub.
    gcspanner – Create and Delete Instances/Databases on Spanner
###Cloud modules - Heroku
    heroku_collaborator – Add or delete app collaborators on Heroku
###Cloud modules - Linode
    linode – Manage instances on the Linode Public Cloud
###Cloud modules - Lxc
    lxc_container – Manage LXC Containers
###Cloud modules - Lxd
    lxd_container – Manage LXD Containers
    lxd_profile – Manage LXD profiles
###Cloud modules - Memset
    memset_dns_reload – Request reload of Memset’s DNS infrastructure,
    memset_zone – Creates and deletes Memset DNS zones.
    memset_zone_domain – Create and delete domains in Memset DNS zones.
    memset_zone_record – Create and delete records in Memset DNS zones.
###Cloud modules - Misc
    cloud_init_data_facts – Retrieve facts of cloud-init.
    helm – Manages Kubernetes packages with the Helm package manager
    ovirt – oVirt/RHEV platform management
    proxmox – management of instances in Proxmox VE cluster
    proxmox_kvm – Management of Qemu(KVM) Virtual Machines in Proxmox VE cluster.
    proxmox_template – management of OS templates in Proxmox VE cluster
    rhevm – RHEV/oVirt automation
    serverless – Manages a Serverless Framework project
    terraform – Manages a Terraform deployment (and plans)
    virt – Manages virtual machines supported by libvirt
    virt_net – Manage libvirt network configuration
    virt_pool – Manage libvirt storage pools
    xenserver_facts – get facts reported on xenserver
###Cloud modules - Oneandone
    oneandone_firewall_policy – Configure 1&1 firewall policy.
    oneandone_load_balancer – Configure 1&1 load balancer.
    oneandone_monitoring_policy – Configure 1&1 monitoring policy.
    oneandone_private_network – Configure 1&1 private networking.
    oneandone_public_ip – Configure 1&1 public IPs.
    oneandone_server – Create, destroy, start, stop, and reboot a 1&1 Host server.
###Cloud modules - Online
    online_user_facts – Gather facts about Online user.
###Cloud modules - Opennebula
    one_host – Manages OpenNebula Hosts
    one_image – Manages OpenNebula images
    one_image_facts – Gather facts about OpenNebula images
    one_service – Deploy and manage OpenNebula services
    one_vm – Creates or terminates OpenNebula instances
###Cloud modules - Openstack
    os_auth – Retrieve an auth token
    os_client_config – Get OpenStack Client config
    os_coe_cluster_template – Add/Remove COE cluster template from OpenStack Cloud
    os_flavor_facts – Retrieve facts about one or more flavors
    os_floating_ip – Add/Remove floating IP from an instance
    os_group – Manage OpenStack Identity Groups
    os_image – Add/Delete images from OpenStack Cloud
    os_image_facts – Retrieve facts about an image within OpenStack.
    os_ironic – Create/Delete Bare Metal Resources from OpenStack
    os_ironic_inspect – Explicitly triggers baremetal node introspection in ironic.
    os_ironic_node – Activate/Deactivate Bare Metal Resources from OpenStack
    os_keypair – Add/Delete a keypair from OpenStack
    os_keystone_domain – Manage OpenStack Identity Domains
    os_keystone_domain_facts – Retrieve facts about one or more OpenStack domains
    os_keystone_endpoint – Manage OpenStack Identity service endpoints
    os_keystone_role – Manage OpenStack Identity Roles
    os_keystone_service – Manage OpenStack Identity services
    os_listener – Add/Delete a listener for a load balancer from OpenStack Cloud
    os_loadbalancer – Add/Delete load balancer from OpenStack Cloud
    os_member – Add/Delete a member for a pool in load balancer from OpenStack Cloud
    os_network – Creates/removes networks from OpenStack
    os_networks_facts – Retrieve facts about one or more OpenStack networks.
    os_nova_flavor – Manage OpenStack compute flavors
    os_nova_host_aggregate – Manage OpenStack host aggregates
    os_object – Create or Delete objects and containers from OpenStack
    os_pool – Add/Delete a pool in the load balancing service from OpenStack Cloud
    os_port – Add/Update/Delete ports from an OpenStack cloud.
    os_port_facts – Retrieve facts about ports within OpenStack.
    os_project – Manage OpenStack Projects
    os_project_access – Manage OpenStack compute flavors acceess
    os_project_facts – Retrieve facts about one or more OpenStack projects
    os_quota – Manage OpenStack Quotas
    os_recordset – Manage OpenStack DNS recordsets
    os_router – Create or delete routers from OpenStack
    os_security_group – Add/Delete security groups from an OpenStack cloud.
    os_security_group_rule – Add/Delete rule from an existing security group
    os_server – Create/Delete Compute Instances from OpenStack
    os_server_action – Perform actions on Compute Instances from OpenStack
    os_server_facts – Retrieve facts about one or more compute instances
    os_server_group – Manage OpenStack server groups
    os_server_metadata – Add/Update/Delete Metadata in Compute Instances from OpenStack
    os_server_volume – Attach/Detach Volumes from OpenStack VM’s
    os_stack – Add/Remove Heat Stack
    os_subnet – Add/Remove subnet to an OpenStack network
    os_subnets_facts – Retrieve facts about one or more OpenStack subnets.
    os_user – Manage OpenStack Identity Users
    os_user_facts – Retrieve facts about one or more OpenStack users
    os_user_group – Associate OpenStack Identity users and groups
    os_user_role – Associate OpenStack Identity users and roles
    os_volume – Create/Delete Cinder Volumes
    os_volume_snapshot – Create/Delete Cinder Volume Snapshots
    os_zone – Manage OpenStack DNS zones
###Cloud modules - Ovh
    ovh_ip_loadbalancing_backend – Manage OVH IP LoadBalancing backends
###Cloud modules - Ovirt
    ovirt_affinity_group – Module to manage affinity groups in oVirt/RHV
    ovirt_affinity_label – Module to manage affinity labels in oVirt/RHV
    ovirt_affinity_label_facts – Retrieve facts about one or more oVirt/RHV affinity labels
    ovirt_api_facts – Retrieve facts about the oVirt/RHV API
    ovirt_auth – Module to manage authentication to oVirt/RHV
    ovirt_cluster – Module to manage clusters in oVirt/RHV
    ovirt_cluster_facts – Retrieve facts about one or more oVirt/RHV clusters
    ovirt_datacenter – Module to manage data centers in oVirt/RHV
    ovirt_datacenter_facts – Retrieve facts about one or more oVirt/RHV datacenters
    ovirt_disk – Module to manage Virtual Machine and floating disks in oVirt/RHV
    ovirt_disk_facts – Retrieve facts about one or more oVirt/RHV disks
    ovirt_external_provider – Module to manage external providers in oVirt/RHV
    ovirt_external_provider_facts – Retrieve facts about one or more oVirt/RHV external providers
    ovirt_group – Module to manage groups in oVirt/RHV
    ovirt_group_facts – Retrieve facts about one or more oVirt/RHV groups
    ovirt_host – Module to manage hosts in oVirt/RHV
    ovirt_host_facts – Retrieve facts about one or more oVirt/RHV hosts
    ovirt_host_network – Module to manage host networks in oVirt/RHV
    ovirt_host_pm – Module to manage power management of hosts in oVirt/RHV
    ovirt_host_storage_facts – Retrieve facts about one or more oVirt/RHV HostStorages (applicable only for block storage)
    ovirt_mac_pool – Module to manage MAC pools in oVirt/RHV
    ovirt_network – Module to manage logical networks in oVirt/RHV
    ovirt_network_facts – Retrieve facts about one or more oVirt/RHV networks
    ovirt_nic – Module to manage network interfaces of Virtual Machines in oVirt/RHV
    ovirt_nic_facts – Retrieve facts about one or more oVirt/RHV virtual machine network interfaces
    ovirt_permission – Module to manage permissions of users/groups in oVirt/RHV
    ovirt_permission_facts – Retrieve facts about one or more oVirt/RHV permissions
    ovirt_quota – Module to manage datacenter quotas in oVirt/RHV
    ovirt_quota_facts – Retrieve facts about one or more oVirt/RHV quotas
    ovirt_scheduling_policy_facts – Retrieve facts about one or more oVirt scheduling policies
    ovirt_snapshot – Module to manage Virtual Machine Snapshots in oVirt/RHV
    ovirt_snapshot_facts – Retrieve facts about one or more oVirt/RHV virtual machine snapshots
    ovirt_storage_connection – Module to manage storage connections in oVirt
    ovirt_storage_domain – Module to manage storage domains in oVirt/RHV
    ovirt_storage_domain_facts – Retrieve facts about one or more oVirt/RHV storage domains
    ovirt_storage_template_facts – Retrieve facts about one or more oVirt/RHV templates relate to a storage domain.
    ovirt_storage_vm_facts – Retrieve facts about one or more oVirt/RHV virtual machines relate to a storage domain.
    ovirt_tag – Module to manage tags in oVirt/RHV
    ovirt_tag_facts – Retrieve facts about one or more oVirt/RHV tags
    ovirt_template – Module to manage virtual machine templates in oVirt/RHV
    ovirt_template_facts – Retrieve facts about one or more oVirt/RHV templates
    ovirt_user – Module to manage users in oVirt/RHV
    ovirt_user_facts – Retrieve facts about one or more oVirt/RHV users
    ovirt_vm – Module to manage Virtual Machines in oVirt/RHV
    ovirt_vm_facts – Retrieve facts about one or more oVirt/RHV virtual machines
    ovirt_vmpool – Module to manage VM pools in oVirt/RHV
    ovirt_vmpool_facts – Retrieve facts about one or more oVirt/RHV vmpools
###Cloud modules - Packet
    packet_device – Manage a bare metal server in the Packet Host.
    packet_sshkey – Create/delete an SSH key in Packet host.
###Cloud modules - Profitbricks
    profitbricks – Create, destroy, start, stop, and reboot a ProfitBricks virtual machine.
    profitbricks_datacenter – Create or destroy a ProfitBricks Virtual Datacenter.
    profitbricks_nic – Create or Remove a NIC.
    profitbricks_volume – Create or destroy a volume.
    profitbricks_volume_attachments – Attach or detach a volume.
###Cloud modules - Pubnub
    pubnub_blocks – PubNub blocks management module.
###Cloud modules - Rackspace
    rax – create / delete an instance in Rackspace Public Cloud
    rax_cbs – Manipulate Rackspace Cloud Block Storage Volumes
    rax_cbs_attachments – Manipulate Rackspace Cloud Block Storage Volume Attachments
    rax_cdb – create/delete or resize a Rackspace Cloud Databases instance
    rax_cdb_database – create / delete a database in the Cloud Databases
    rax_cdb_user – create / delete a Rackspace Cloud Database
    rax_clb – create / delete a load balancer in Rackspace Public Cloud
    rax_clb_nodes – add, modify and remove nodes from a Rackspace Cloud Load Balancer
    rax_clb_ssl – Manage SSL termination for a Rackspace Cloud Load Balancer.
    rax_dns – Manage domains on Rackspace Cloud DNS
    rax_dns_record – Manage DNS records on Rackspace Cloud DNS
    rax_facts – Gather facts for Rackspace Cloud Servers
    rax_files – Manipulate Rackspace Cloud Files Containers
    rax_files_objects – Upload, download, and delete objects in Rackspace Cloud Files
    rax_identity – Load Rackspace Cloud Identity
    rax_keypair – Create a keypair for use with Rackspace Cloud Servers
    rax_meta – Manipulate metadata for Rackspace Cloud Servers
    rax_mon_alarm – Create or delete a Rackspace Cloud Monitoring alarm.
    rax_mon_check – Create or delete a Rackspace Cloud Monitoring check for an existing entity.
    rax_mon_entity – Create or delete a Rackspace Cloud Monitoring entity
    rax_mon_notification – Create or delete a Rackspace Cloud Monitoring notification.
    rax_mon_notification_plan – Create or delete a Rackspace Cloud Monitoring notification plan.
    rax_network – create / delete an isolated network in Rackspace Public Cloud
    rax_queue – create / delete a queue in Rackspace Public Cloud
    rax_scaling_group – Manipulate Rackspace Cloud Autoscale Groups
    rax_scaling_policy – Manipulate Rackspace Cloud Autoscale Scaling Policy
###Cloud modules - Scaleway
    scaleway_compute – Scaleway compute management module
    scaleway_image_facts – Gather facts about the Scaleway images available.
    scaleway_ip_facts – Gather facts about the Scaleway ips available.
    scaleway_organization_facts – Gather facts about the Scaleway organizations available.
    scaleway_security_group_facts – Gather facts about the Scaleway security groups available.
    scaleway_server_facts – Gather facts about the Scaleway servers available.
    scaleway_snapshot_facts – Gather facts about the Scaleway snapshots available.
    scaleway_sshkey – Scaleway SSH keys management module
    scaleway_volume – Scaleway volumes management module
    scaleway_volume_facts – Gather facts about the Scaleway volumes available.
###Cloud modules - #Smartos
    imgadm – Manage SmartOS images
    smartos_image_facts – Get SmartOS image details.
    vmadm – Manage SmartOS virtual machines and zones.
###Cloud modules - Softlayer
    sl_vm – create or cancel a virtual instance in SoftLayer
###Cloud modules - Spotinst
    spotinst_aws_elastigroup – Create, update or delete Spotinst AWS Elastigroups
###Cloud modules - Univention
    udm_dns_record – Manage dns entries on a univention corporate server
    udm_dns_zone – Manage dns zones on a univention corporate server
    udm_group – Manage of the posix group
    udm_share – Manage samba shares on a univention corporate server
    udm_user – Manage posix users on a univention corporate server
###Cloud modules - Vmware
    vca_fw – add remove firewall rules in a gateway in a vca
    vca_nat – add remove nat rules in a gateway in a vca
    vca_vapp – Manages vCloud Air vApp instances.
    vcenter_folder – Manage folders on given datacenter
    vcenter_license – Manage VMware vCenter license keys
    vmware_about_facts – Provides information about VMware server to which user is connecting to
    vmware_category – Manage VMware categories
    vmware_category_facts – Gather facts about VMware tag categories
    vmware_cfg_backup – Backup / Restore / Reset ESXi host configuration
    vmware_cluster – Manage VMware vSphere clusters
    vmware_cluster_facts – Gather facts about clusters available in given vCenter
    vmware_datacenter – Manage VMware vSphere Datacenters
    vmware_datastore_cluster – Manage VMware vSphere datastore clusters
    vmware_datastore_facts – Gather facts about datastores available in given vCenter
    vmware_datastore_maintenancemode – Place a datastore into maintenance mode
    vmware_deploy_ovf – Deploys a VMware virtual machine from an OVF or OVA file
    vmware_dns_config – Manage VMware ESXi DNS Configuration
    vmware_drs_rule_facts – Gathers facts about DRS rule on the given cluster
    vmware_dvs_host – Add or remove a host from distributed virtual switch
    vmware_dvs_portgroup – Create or remove a Distributed vSwitch portgroup.
    vmware_dvswitch – Create or remove a distributed vSwitch
    vmware_guest – Manages virtual machines in vCenter
    vmware_guest_boot_facts – Gather facts about boot options for the given virtual machine
    vmware_guest_boot_manager – Manage boot options for the given virtual machine
    vmware_guest_custom_attribute_defs – Manage custom attributes definitions for virtual machine from VMWare
    vmware_guest_custom_attributes – Manage custom attributes from VMWare for the given virtual machine
    vmware_guest_disk_facts – Gather facts about disks of given virtual machine
    vmware_guest_facts – Gather facts about a single VM
    vmware_guest_file_operation – Files operation in a VMware guest operating system without network
    vmware_guest_find – Find the folder path(s) for a virtual machine by name or UUID
    vmware_guest_move – Moves virtual machines in vCenter
    vmware_guest_powerstate – Manages power states of virtual machines in vCenter
    vmware_guest_snapshot – Manages virtual machines snapshots in vCenter
    vmware_guest_snapshot_facts – Gather facts about virtual machine’s snapshots in vCenter
    vmware_guest_tools_wait – Wait for VMware tools to become available
    vmware_host – Add / Remove ESXi host to / from vCenter
    vmware_host_acceptance – Manage acceptance level of ESXi host
    vmware_host_capability_facts – Gathers facts about an ESXi host’s capability information
    vmware_host_config_facts – Gathers facts about an ESXi host’s advance configuration information
    vmware_host_config_manager – Manage advance configurations about an ESXi host
    vmware_host_datastore – Manage a datastore on ESXi host
    vmware_host_dns_facts – Gathers facts about an ESXi host’s DNS configuration information
    vmware_host_facts – Gathers facts about remote ESXi hostsystem
    vmware_host_firewall_facts – Gathers facts about an ESXi host’s firewall configuration information
    vmware_host_firewall_manager – Manage firewall configurations about an ESXi host
    vmware_host_lockdown – Manage administrator permission for the local administrative account for the ESXi host
    vmware_host_ntp – Manage NTP configurations about an ESXi host
    vmware_host_ntp_facts – Gathers facts about NTP configuration on an ESXi host
    vmware_host_package_facts – Gathers facts about available packages on an ESXi host
    vmware_host_powerstate – Manages power states of host systems in vCenter
    vmware_host_service_facts – Gathers facts about an ESXi host’s services
    vmware_host_service_manager – Manage services on a given ESXi host
    vmware_host_ssl_facts – Gather facts of ESXi host system about SSL
    vmware_host_vmnic_facts – Gathers facts about vmnics available on the given ESXi host
    vmware_local_role_facts – Gather facts about local roles on an ESXi host
    vmware_local_role_manager – Manage local roles on an ESXi host
    vmware_local_user_facts – Gather facts about users on the given ESXi host
    vmware_local_user_manager – Manage local users on an ESXi host
    vmware_maintenancemode – Place a host into maintenance mode
    vmware_migrate_vmk – Migrate a VMK interface from VSS to VDS
    vmware_portgroup – Create a VMware portgroup
    vmware_portgroup_facts – Gathers facts about an ESXi host’s portgroup configuration
    vmware_resource_pool – Add/remove resource pools to/from vCenter
    vmware_resource_pool_facts – Gathers facts about resource pool information
    vmware_tag – Manage VMware tags
    vmware_tag_facts – Manage VMware tag facts
    vmware_target_canonical_facts – Return canonical (NAA) from an ESXi host system
    vmware_vm_facts – Return basic facts pertaining to a vSphere virtual machine guest
    vmware_vm_shell – Run commands in a VMware guest operating system
    vmware_vm_vm_drs_rule – Configure VMware DRS Affinity rule for virtual machine in given cluster
    vmware_vm_vss_dvs_migrate – Migrates a virtual machine from a standard vswitch to distributed
    vmware_vmkernel – Manage a VMware VMkernel Interface aka. Virtual NICs of host system.
    vmware_vmkernel_facts – Gathers VMKernel facts about an ESXi host
    vmware_vmkernel_ip_config – Configure the VMkernel IP Address
    vmware_vmotion – Move a virtual machine using vMotion, and/or its vmdks using storage vMotion.
    vmware_vsan_cluster – Configure VSAN clustering on an ESXi host
    vmware_vswitch – Manage a VMware Standard Switch to an ESXi host.
    vmware_vswitch_facts – Gathers facts about an ESXi host’s vswitch configurations
    vsphere_copy – Copy a file to a vCenter datastore
    vsphere_guest – Create/delete/manage a guest VM through VMware vSphere. (D)
###Cloud modules - Vultr
    vultr_account_facts – Gather facts about the Vultr account.
    vultr_block_storage – Manages block storage volumes on Vultr.
    vultr_block_storage_facts – Gather facts about the Vultr block storage volumes available.
    vultr_dns_domain – Manages DNS domains on Vultr.
    vultr_dns_domain_facts – Gather facts about the Vultr DNS domains available.
    vultr_dns_record – Manages DNS records on Vultr.
    vultr_firewall_group – Manages firewall groups on Vultr.
    vultr_firewall_group_facts – Gather facts about the Vultr firewall groups available.
    vultr_firewall_rule – Manages firewall rules on Vultr.
    vultr_network – Manages networks on Vultr.
    vultr_network_facts – Gather facts about the Vultr networks available.
    vultr_os_facts – Gather facts about the Vultr OSes available.
    vultr_plan_facts – Gather facts about the Vultr plans available.
    vultr_region_facts – Gather facts about the Vultr regions available.
    vultr_server – Manages virtual servers on Vultr.
    vultr_server_facts – Gather facts about the Vultr servers available.
    vultr_ssh_key – Manages ssh keys on Vultr.
    vultr_ssh_key_facts – Gather facts about the Vultr SSH keys available.
    vultr_startup_script – Manages startup scripts on Vultr.
    vultr_startup_script_facts – Gather facts about the Vultr startup scripts available.
    vultr_user – Manages users on Vultr.
    vultr_user_facts – Gather facts about the Vultr user available.
###Cloud modules - Webfaction
    webfaction_app – Add or remove applications on a Webfaction host
    webfaction_db – Add or remove a database on Webfaction
    webfaction_domain – Add or remove domains and subdomains on Webfaction
    webfaction_mailbox – Add or remove mailboxes on Webfaction
    webfaction_site – Add or remove a website on a Webfaction host
###Clustering modules - Misc
    consul – Add, modify & delete services within a consul cluster.
    consul_acl – Manipulate Consul ACL keys and rules
    consul_kv – Manipulate entries in the key/value store of a consul cluster
    consul_session – Manipulate consul sessions
    etcd3 – Set or delete key value pairs from an etcd3 cluster
    pacemaker_cluster – Manage pacemaker clusters
    znode – Create, delete, retrieve, and update znodes using ZooKeeper
###Clustering modules - K8S
    k8s – Manage Kubernetes (K8s) objects
    k8s_facts – Describe Kubernetes (K8s) objects
    k8s_scale – Set a new size for a Deployment, ReplicaSet, Replication Controller, or Job.
    kubernetes – Manage Kubernetes resources (D)
###Clustering modules - Openshift
    oc – Manage OpenShift Resources (D)
###Commands modules - Misc 
    command – Executes a command on a remote node
    expect – Executes a command and responds to prompts.
    psexec – Runs commands on a remote Windows host based on the PsExec model
    raw – Executes a low-down and dirty SSH command
    script – Runs a local script on a remote node after transferring it
    shell – Execute commands in nodes.
    telnet – Executes a low-down and dirty telnet command

###Database modules - Influxdb
    influxdb_database – Manage InfluxDB databases
    influxdb_query – Query data points from InfluxDB.
    influxdb_retention_policy – Manage InfluxDB retention policies
    influxdb_user – Manage InfluxDB users
    influxdb_write – Write data points into InfluxDB.
###Database modules - Misc
    elasticsearch_plugin – Manage Elasticsearch plugins
    kibana_plugin – Manage Kibana plugins
    redis – Various redis commands, slave and flush
    riak – This module handles some common Riak operations
###Database modules - Mongodb
    mongodb_parameter – Change an administrative parameter on a MongoDB server.
    mongodb_user – Adds or removes a user from a MongoDB database.
###Database modules - Mssql
    mssql_db – Add or remove MSSQL databases from a remote host.
###Database modules - Mysql
    mysql_db – Add or remove MySQL databases from a remote host.
    mysql_replication – Manage MySQL replication
    mysql_user – Adds or removes a user from a MySQL database.
    mysql_variables – Manage MySQL global variables
###Database modules - Postgresql
    postgresql_db – Add or remove PostgreSQL databases from a remote host.
    postgresql_ext – Add or remove PostgreSQL extensions from a database.
    postgresql_lang – Adds, removes or changes procedural languages with a PostgreSQL database.
    postgresql_privs – Grant or revoke privileges on PostgreSQL database objects.
    postgresql_schema – Add or remove PostgreSQL schema from a remote host
    postgresql_user – Adds or removes a users (roles) from a PostgreSQL database.
###Database modules - Proxysql
    proxysql_backend_servers – Adds or removes mysql hosts from proxysql admin interface.
    proxysql_global_variables – Gets or sets the proxysql global variables.
    proxysql_manage_config – Writes the proxysql configuration settings between layers.
    proxysql_mysql_users – Adds or removes mysql users from proxysql admin interface.
    proxysql_query_rules – Modifies query rules using the proxysql admin interface.
    proxysql_replication_hostgroups – Manages replication hostgroups using the proxysql admin interface.
    proxysql_scheduler – Adds or removes schedules from proxysql admin interface.
###Database modules - Vertica
    vertica_configuration – Updates Vertica configuration parameters.
    vertica_facts – Gathers Vertica database facts.
    vertica_role – Adds or removes Vertica database roles and assigns roles to them.
    vertica_schema – Adds or removes Vertica database schema and roles.
    vertica_user – Adds or removes Vertica database users and assigns roles.
###Files modules
    acl – Sets and retrieves file ACL information.
    archive – Creates a compressed archive of one or more files or trees
    assemble – Assembles a configuration file from fragments
    blockinfile – Insert/update/remove a text block surrounded by marker lines
    copy – Copies files to remote locations
    fetch – Fetches a file from remote nodes
    file – Sets attributes of files
    find – Return a list of files based on specific criteria
    ini_file – Tweak settings in INI files
    iso_extract – Extract files from an ISO image
    lineinfile – Manage lines in text files
    patch – Apply patch files using the GNU patch tool
    replace – Replace all instances of a particular string in a file using a back-referenced regular expression.
    stat – Retrieve file or file system status
    synchronize – A wrapper around rsync to make common tasks in your playbooks quick and easy.
    tempfile – Creates temporary files and directories.
    template – Templates a file out to a remote server
    unarchive – Unpacks an archive after (optionally) copying it from the local machine.
    xattr – Manage user defined extended attributes
    xml – Manage bits and pieces of XML files or strings
###Monitoring modules - Misc 
    airbrake_deployment – Notify airbrake about app deployments
    bigpanda – Notify BigPanda about deployments
    circonus_annotation – create an annotation in circonus
    datadog_event – Posts events to Datadog service
    datadog_monitor – Manages Datadog monitors
    grafana_dashboard – Manage Grafana dashboards
    grafana_datasource – Manage Grafana datasources
    grafana_plugin – Manage Grafana plugins via grafana-cli
    honeybadger_deployment – Notify Honeybadger.io about app deployments
    icinga2_feature – Manage Icinga2 feature
    icinga2_host – Manage a host in Icinga2
    librato_annotation – create an annotation in librato
    logentries – Module for tracking logs via logentries.com
    logicmonitor – Manage your LogicMonitor account through Ansible Playbooks
    logicmonitor_facts – Collect facts about LogicMonitor objects
    logstash_plugin – Manage Logstash plugins
    monit – Manage the state of a program monitored via Monit
    nagios – Perform common tasks in Nagios related to downtime and notifications.
    newrelic_deployment – Notify newrelic about app deployments
    pagerduty – Create PagerDuty maintenance windows
    pagerduty_alert – Trigger, acknowledge or resolve PagerDuty incidents
    pingdom – Pause/unpause Pingdom alerts
    rollbar_deployment – Notify Rollbar about app deployments
    sensu_check – Manage Sensu checks
    sensu_client – Manages Sensu client configuration
    sensu_handler – Manages Sensu handler configuration
    sensu_silence – Manage Sensu silence entries
    sensu_subscription – Manage Sensu subscriptions
    spectrum_device – Creates/deletes devices in CA Spectrum.
    stackdriver – Send code deploy and annotation events to stackdriver
    statusio_maintenance – Create maintenance windows for your status.io dashboard
    uptimerobot – Pause and start Uptime Robot monitoring
###Monitoring modules - Zabbix
    zabbix_group – Zabbix host groups creates/deletes
    zabbix_group_facts – Gather facts about Zabbix hostgroup
    zabbix_host – Zabbix host creates/updates/deletes
    zabbix_host_facts – Gather facts about Zabbix host
    zabbix_hostmacro – Zabbix host macro creates/updates/deletes
    zabbix_maintenance – Create Zabbix maintenance windows
    zabbix_proxy – Zabbix proxy creates/deletes/gets/updates
    zabbix_screen – Zabbix screen creates/updates/deletes
    zabbix_template – create/delete/dump zabbix template
###Net Tools modules - Misc 
    cloudflare_dns – manage Cloudflare DNS records
    dnsimple – Interface with dnsimple.com (a DNS hosting service)
    dnsmadeeasy – Interface with dnsmadeeasy.com (a DNS hosting service).
    haproxy – Enable, disable, and set weights for HAProxy backend servers using socket commands.
    ip_netns – Manage network namespaces
    ipify_facts – Retrieve the public IP of your internet gateway.
    ipinfoio_facts – Retrieve IP geolocation facts of a host’s IP address
    lldp – get details reported by lldp
    netcup_dns – manage Netcup DNS records
    nmcli – Manage Networking
    nsupdate – Manage DNS records.
    omapi_host – Setup OMAPI hosts.
    snmp_facts – Retrieve facts for a device using SNMP.
###Net Tools modules - Basics
    get_url – Downloads files from HTTP, HTTPS, or FTP to node
    slurp – Slurps a file from remote nodes
    uri – Interacts with webservices
###Net Tools modules - Exoscale
    exo_dns_domain – Manages domain records on Exoscale DNS API.
    exo_dns_record – Manages DNS records on Exoscale DNS.
###Net Tools modules - Infinity
    infinity – manage Infinity IPAM using Rest API
###Net Tools modules - Ldap
    ldap_attr – Add or remove LDAP attribute values.
    ldap_entry – Add or remove LDAP entries.
    ldap_passwd – Set passwords in LDAP.
###Net Tools modules - Nios
    nios_a_record – Configure Infoblox NIOS A records
    nios_aaaa_record – Configure Infoblox NIOS AAAA records
    nios_cname_record – Configure Infoblox NIOS CNAME records
    nios_dns_view – Configure Infoblox NIOS DNS views
    nios_host_record – Configure Infoblox NIOS host records
    nios_mx_record – Configure Infoblox NIOS MX records
    nios_naptr_record – Configure Infoblox NIOS NAPTR records
    nios_network – Configure Infoblox NIOS network object
    nios_network_view – Configure Infoblox NIOS network views
    nios_ptr_record – Configure Infoblox NIOS PTR records
    nios_srv_record – Configure Infoblox NIOS SRV records
    nios_txt_record – Configure Infoblox NIOS txt records
    nios_zone – Configure Infoblox NIOS DNS zones
###Network modules - A10
    a10_server – Manage A10 Networks AX/SoftAX/Thunder/vThunder devices’ server object.
    a10_server_axapi3 – Manage A10 Networks AX/SoftAX/Thunder/vThunder devices
    a10_service_group – Manage A10 Networks AX/SoftAX/Thunder/vThunder devices’ service groups.
    a10_virtual_server – Manage A10 Networks AX/SoftAX/Thunder/vThunder devices’ virtual servers.
###Network modules - Aci
    aci_aaa_user – Manage AAA users (aaa:User)
    aci_aaa_user_certificate – Manage AAA user certificates (aaa:UserCert)
    aci_access_port_to_interface_policy_leaf_profile – Manage Fabric interface policy leaf profile interface selectors (infra:HPortS, infra:RsAccBaseGrp, infra:PortBlk)
    aci_aep – Manage attachable Access Entity Profile (AEP) objects (infra:AttEntityP, infra:ProvAcc)
    aci_aep_to_domain – Bind AEPs to Physical or Virtual Domains (infra:RsDomP)
    aci_ap – Manage top level Application Profile (AP) objects (fv:Ap)
    aci_bd – Manage Bridge Domains (BD) objects (fv:BD)
    aci_bd_subnet – Manage Subnets (fv:Subnet)
    aci_bd_to_l3out – Bind Bridge Domain to L3 Out (fv:RsBDToOut)
    aci_config_rollback – Provides rollback and rollback preview functionality (config:ImportP)
    aci_config_snapshot – Manage Config Snapshots (config:Snapshot, config:ExportP)
    aci_contract – Manage contract resources (vz:BrCP)
    aci_contract_subject – Manage initial Contract Subjects (vz:Subj)
    aci_contract_subject_to_filter – Bind Contract Subjects to Filters (vz:RsSubjFiltAtt)
    aci_domain – Manage physical, virtual, bridged, routed or FC domain profiles (phys:DomP, vmm:DomP, l2ext:DomP, l3ext:DomP, fc:DomP)
    aci_domain_to_encap_pool – Bind Domain to Encap Pools (infra:RsVlanNs)
    aci_domain_to_vlan_pool – Bind Domain to VLAN Pools (infra:RsVlanNs)
    aci_encap_pool – Manage encap pools (fvns:VlanInstP, fvns:VxlanInstP, fvns:VsanInstP)
    aci_encap_pool_range – Manage encap ranges assigned to pools (fvns:EncapBlk, fvns:VsanEncapBlk)
    aci_epg – Manage End Point Groups (EPG) objects (fv:AEPg)
    aci_epg_monitoring_policy – Manage monitoring policies (mon:EPGPol)
    aci_epg_to_contract – Bind EPGs to Contracts (fv:RsCons, fv:RsProv)
    aci_epg_to_domain – Bind EPGs to Domains (fv:RsDomAtt)
    aci_fabric_node – Manage Fabric Node Members (fabric:NodeIdentP)
    aci_filter – Manages top level filter objects (vz:Filter)
    aci_filter_entry – Manage filter entries (vz:Entry)
    aci_firmware_source – Manage firmware image sources (firmware:OSource)
    aci_interface_policy_fc – Manage Fibre Channel interface policies (fc:IfPol)
    aci_interface_policy_l2 – Manage Layer 2 interface policies (l2:IfPol)
    aci_interface_policy_leaf_policy_group – Manage fabric interface policy leaf policy groups (infra:AccBndlGrp, infra:AccPortGrp)
    aci_interface_policy_leaf_profile – Manage fabric interface policy leaf profiles (infra:AccPortP)
    aci_interface_policy_lldp – Manage LLDP interface policies (lldp:IfPol)
    aci_interface_policy_mcp – Manage MCP interface policies (mcp:IfPol)
    aci_interface_policy_ospf – Manage OSPF interface policies (ospf:IfPol)
    aci_interface_policy_port_channel – Manage port channel interface policies (lacp:LagPol)
    aci_interface_policy_port_security – Manage port security (l2:PortSecurityPol)
    aci_interface_selector_to_switch_policy_leaf_profile – Bind interface selector profiles to switch policy leaf profiles (infra:RsAccPortP)
    aci_l3out – Manage Layer 3 Outside (L3Out) objects (l3ext:Out)
    aci_l3out_route_tag_policy – Manage route tag policies (l3ext:RouteTagPol)
    aci_rest – Direct access to the Cisco APIC REST API
    aci_static_binding_to_epg – Bind static paths to EPGs (fv:RsPathAtt)
    aci_switch_leaf_selector – Bind leaf selectors to switch policy leaf profiles (infra:LeafS, infra:NodeBlk, infra:RsAccNodePGrep)
    aci_switch_policy_leaf_profile – Manage switch policy leaf profiles (infra:NodeP)
    aci_switch_policy_vpc_protection_group – Manage switch policy explicit vPC protection groups (fabric:ExplicitGEp, fabric:NodePEp).
    aci_taboo_contract – Manage taboo contracts (vz:BrCP)
    aci_tenant – Manage tenants (fv:Tenant)
    aci_tenant_action_rule_profile – Manage action rule profiles (rtctrl:AttrP)
    aci_tenant_ep_retention_policy – Manage End Point (EP) retention protocol policies (fv:EpRetPol)
    aci_tenant_span_dst_group – Manage SPAN destination groups (span:DestGrp)
    aci_tenant_span_src_group – Manage SPAN source groups (span:SrcGrp)
    aci_tenant_span_src_group_to_dst_group – Bind SPAN source groups to destination groups (span:SpanLbl)
    aci_vlan_pool – Manage VLAN pools (fvns:VlanInstP)
    aci_vlan_pool_encap_block – Manage encap blocks assigned to VLAN pools (fvns:EncapBlk)
    aci_vrf – Manage contexts or VRFs (fv:Ctx)
###Network modules - Aireos
    aireos_command – Run commands on remote devices running Cisco WLC
    aireos_config – Manage Cisco WLC configurations
###Network modules - Aos
    aos_asn_pool – Manage AOS ASN Pool (D)
    aos_blueprint – Manage AOS blueprint instance (D)
    aos_blueprint_param – Manage AOS blueprint parameter values (D)
    aos_blueprint_virtnet – Manage AOS blueprint parameter values (D)
    aos_device – Manage Devices on AOS Server (D)
    aos_external_router – Manage AOS External Router (D)
    aos_ip_pool – Manage AOS IP Pool (D)
    aos_logical_device – Manage AOS Logical Device (D)
    aos_logical_device_map – Manage AOS Logical Device Map (D)
    aos_login – Login to AOS server for session token (D)
    aos_rack_type – Manage AOS Rack Type (D)
    aos_template – Manage AOS Template (D)
###Network modules - Aruba
    aruba_command – Run commands on remote devices running Aruba Mobility Controller
    aruba_config – Manage Aruba configuration sections
###Network modules - Asa
    asa_acl – Manage access-lists on a Cisco ASA
    asa_command – Run arbitrary commands on Cisco ASA devices
    asa_config – Manage configuration sections on Cisco ASA devices
###Network modules - Avi
    avi_actiongroupconfig – Module for setup of ActionGroupConfig Avi RESTful Object
    avi_alertconfig – Module for setup of AlertConfig Avi RESTful Object
    avi_alertemailconfig – Module for setup of AlertEmailConfig Avi RESTful Object
    avi_alertscriptconfig – Module for setup of AlertScriptConfig Avi RESTful Object
    avi_alertsyslogconfig – Module for setup of AlertSyslogConfig Avi RESTful Object
    avi_analyticsprofile – Module for setup of AnalyticsProfile Avi RESTful Object
    avi_api_session – Avi API Module
    avi_api_version – Avi API Version Module
    avi_applicationpersistenceprofile – Module for setup of ApplicationPersistenceProfile Avi RESTful Object
    avi_applicationprofile – Module for setup of ApplicationProfile Avi RESTful Object
    avi_authprofile – Module for setup of AuthProfile Avi RESTful Object
    avi_autoscalelaunchconfig – Module for setup of AutoScaleLaunchConfig Avi RESTful Object
    avi_backup – Module for setup of Backup Avi RESTful Object
    avi_backupconfiguration – Module for setup of BackupConfiguration Avi RESTful Object
    avi_certificatemanagementprofile – Module for setup of CertificateManagementProfile Avi RESTful Object
    avi_cloud – Module for setup of Cloud Avi RESTful Object
    avi_cloudconnectoruser – Module for setup of CloudConnectorUser Avi RESTful Object
    avi_cloudproperties – Module for setup of CloudProperties Avi RESTful Object
    avi_cluster – Module for setup of Cluster Avi RESTful Object
    avi_clusterclouddetails – Module for setup of ClusterCloudDetails Avi RESTful Object
    avi_controllerproperties – Module for setup of ControllerProperties Avi RESTful Object
    avi_customipamdnsprofile – Module for setup of CustomIpamDnsProfile Avi RESTful Object
    avi_dnspolicy – Module for setup of DnsPolicy Avi RESTful Object
    avi_errorpagebody – Module for setup of ErrorPageBody Avi RESTful Object
    avi_errorpageprofile – Module for setup of ErrorPageProfile Avi RESTful Object
    avi_gslb – Module for setup of Gslb Avi RESTful Object
    avi_gslbapplicationpersistenceprofile – Module for setup of GslbApplicationPersistenceProfile Avi RESTful Object
    avi_gslbgeodbprofile – Module for setup of GslbGeoDbProfile Avi RESTful Object
    avi_gslbhealthmonitor – Module for setup of GslbHealthMonitor Avi RESTful Object
    avi_gslbservice – Module for setup of GslbService Avi RESTful Object
    avi_gslbservice_patch_member – Avi API Module
    avi_hardwaresecuritymodulegroup – Module for setup of HardwareSecurityModuleGroup Avi RESTful Object
    avi_healthmonitor – Module for setup of HealthMonitor Avi RESTful Object
    avi_httppolicyset – Module for setup of HTTPPolicySet Avi RESTful Object
    avi_ipaddrgroup – Module for setup of IpAddrGroup Avi RESTful Object
    avi_ipamdnsproviderprofile – Module for setup of IpamDnsProviderProfile Avi RESTful Object
    avi_l4policyset – Module for setup of L4PolicySet Avi RESTful Object
    avi_microservicegroup – Module for setup of MicroServiceGroup Avi RESTful Object
    avi_network – Module for setup of Network Avi RESTful Object
    avi_networkprofile – Module for setup of NetworkProfile Avi RESTful Object
    avi_networksecuritypolicy – Module for setup of NetworkSecurityPolicy Avi RESTful Object
    avi_pkiprofile – Module for setup of PKIProfile Avi RESTful Object
    avi_pool – Module for setup of Pool Avi RESTful Object
    avi_poolgroup – Module for setup of PoolGroup Avi RESTful Object
    avi_poolgroupdeploymentpolicy – Module for setup of PoolGroupDeploymentPolicy Avi RESTful Object
    avi_prioritylabels – Module for setup of PriorityLabels Avi RESTful Object
    avi_role – Module for setup of Role Avi RESTful Object
    avi_scheduler – Module for setup of Scheduler Avi RESTful Object
    avi_seproperties – Module for setup of SeProperties Avi RESTful Object
    avi_serverautoscalepolicy – Module for setup of ServerAutoScalePolicy Avi RESTful Object
    avi_serviceengine – Module for setup of ServiceEngine Avi RESTful Object
    avi_serviceenginegroup – Module for setup of ServiceEngineGroup Avi RESTful Object
    avi_snmptrapprofile – Module for setup of SnmpTrapProfile Avi RESTful Object
    avi_sslkeyandcertificate – Module for setup of SSLKeyAndCertificate Avi RESTful Object
    avi_sslprofile – Module for setup of SSLProfile Avi RESTful Object
    avi_stringgroup – Module for setup of StringGroup Avi RESTful Object
    avi_systemconfiguration – Module for setup of SystemConfiguration Avi RESTful Object
    avi_tenant – Module for setup of Tenant Avi RESTful Object
    avi_trafficcloneprofile – Module for setup of TrafficCloneProfile Avi RESTful Object
    avi_useraccount – Avi UserAccount Module
    avi_useraccountprofile – Module for setup of UserAccountProfile Avi RESTful Object
    avi_virtualservice – Module for setup of VirtualService Avi RESTful Object
    avi_vrfcontext – Module for setup of VrfContext Avi RESTful Object
    avi_vsdatascriptset – Module for setup of VSDataScriptSet Avi RESTful Object
    avi_vsvip – Module for setup of VsVip Avi RESTful Object
    avi_wafpolicy – Module for setup of WafPolicy Avi RESTful Object
    avi_wafprofile – Module for setup of WafProfile Avi RESTful Object
    avi_webhook – Module for setup of Webhook Avi RESTful Object
###Network modules - Bigswitch
    bcf_switch – Create and remove a bcf switch.
    bigmon_chain – Create and remove a bigmon inline service chain.
    bigmon_policy – Create and remove a bigmon out-of-band policy.
###Network modules - Citrix
    netscaler – Manages Citrix NetScaler entities (D)
###Network modules - Cli
    cli_command – Run a cli command on cli-based network devices
    cli_config – Push text based configuration to network devices over network_cli
###Network modules - Cloudengine
    ce_aaa_server – Manages AAA server global configuration on HUAWEI CloudEngine switches.
    ce_aaa_server_host – Manages AAA server host configuration on HUAWEI CloudEngine switches.
    ce_acl – Manages base ACL configuration on HUAWEI CloudEngine switches.
    ce_acl_advance – Manages advanced ACL configuration on HUAWEI CloudEngine switches.
    ce_acl_interface – Manages applying ACLs to interfaces on HUAWEI CloudEngine switches.
    ce_bfd_global – Manages BFD global configuration on HUAWEI CloudEngine devices.
    ce_bfd_session – Manages BFD session configuration on HUAWEI CloudEngine devices.
    ce_bfd_view – Manages BFD session view configuration on HUAWEI CloudEngine devices.
    ce_bgp – Manages BGP configuration on HUAWEI CloudEngine switches.
    ce_bgp_af – Manages BGP Address-family configuration on HUAWEI CloudEngine switches.
    ce_bgp_neighbor – Manages BGP peer configuration on HUAWEI CloudEngine switches.
    ce_bgp_neighbor_af – Manages BGP neighbor Address-family configuration on HUAWEI CloudEngine switches.
    ce_command – Run arbitrary command on HUAWEI CloudEngine devices.
    ce_config – Manage Huawei CloudEngine configuration sections.
    ce_dldp – Manages global DLDP configuration on HUAWEI CloudEngine switches.
    ce_dldp_interface – Manages interface DLDP configuration on HUAWEI CloudEngine switches.
    ce_eth_trunk – Manages Eth-Trunk interfaces on HUAWEI CloudEngine switches.
    ce_evpn_bd_vni – Manages EVPN VXLAN Network Identifier (VNI) on HUAWEI CloudEngine switches.
    ce_evpn_bgp – Manages BGP EVPN configuration on HUAWEI CloudEngine switches.
    ce_evpn_bgp_rr – Manages RR for the VXLAN Network on HUAWEI CloudEngine switches.
    ce_evpn_global – Manages global configuration of EVPN on HUAWEI CloudEngine switches.
    ce_facts – Gets facts about HUAWEI CloudEngine switches.
    ce_file_copy – Copy a file to a remote cloudengine device over SCP on HUAWEI CloudEngine switches.
    ce_info_center_debug – Manages information center debug configuration on HUAWEI CloudEngine switches.
    ce_info_center_global – Manages outputting logs on HUAWEI CloudEngine switches.
    ce_info_center_log – Manages information center log configuration on HUAWEI CloudEngine switches.
    ce_info_center_trap – Manages information center trap configuration on HUAWEI CloudEngine switches.
    ce_interface – Manages physical attributes of interfaces on HUAWEI CloudEngine switches.
    ce_interface_ospf – Manages configuration of an OSPF interface instanceon HUAWEI CloudEngine switches.
    ce_ip_interface – Manages L3 attributes for IPv4 and IPv6 interfaces on HUAWEI CloudEngine switches.
    ce_link_status – Get interface link status on HUAWEI CloudEngine switches.
    ce_mlag_config – Manages MLAG configuration on HUAWEI CloudEngine switches.
    ce_mlag_interface – Manages MLAG interfaces on HUAWEI CloudEngine switches.
    ce_mtu – Manages MTU settings on HUAWEI CloudEngine switches.
    ce_netconf – Run an arbitrary netconf command on HUAWEI CloudEngine switches.
    ce_netstream_aging – Manages timeout mode of NetStream on HUAWEI CloudEngine switches.
    ce_netstream_export – Manages netstream export on HUAWEI CloudEngine switches.
    ce_netstream_global – Manages global parameters of NetStream on HUAWEI CloudEngine switches.
    ce_netstream_template – Manages NetStream template configuration on HUAWEI CloudEngine switches.
    ce_ntp – Manages core NTP configuration on HUAWEI CloudEngine switches.
    ce_ntp_auth – Manages NTP authentication configuration on HUAWEI CloudEngine switches.
    ce_ospf – Manages configuration of an OSPF instance on HUAWEI CloudEngine switches.
    ce_ospf_vrf – Manages configuration of an OSPF VPN instance on HUAWEI CloudEngine switches.
    ce_reboot – Reboot a HUAWEI CloudEngine switches.
    ce_rollback – Set a checkpoint or rollback to a checkpoint on HUAWEI CloudEngine switches.
    ce_sflow – Manages sFlow configuration on HUAWEI CloudEngine switches.
    ce_snmp_community – Manages SNMP community configuration on HUAWEI CloudEngine switches.
    ce_snmp_contact – Manages SNMP contact configuration on HUAWEI CloudEngine switches.
    ce_snmp_location – Manages SNMP location configuration on HUAWEI CloudEngine switches.
    ce_snmp_target_host – Manages SNMP target host configuration on HUAWEI CloudEngine switches.
    ce_snmp_traps – Manages SNMP traps configuration on HUAWEI CloudEngine switches.
    ce_snmp_user – Manages SNMP user configuration on HUAWEI CloudEngine switches.
    ce_startup – Manages a system startup information on HUAWEI CloudEngine switches.
    ce_static_route – Manages static route configuration on HUAWEI CloudEngine switches.
    ce_stp – Manages STP configuration on HUAWEI CloudEngine switches.
    ce_switchport – Manages Layer 2 switchport interfaces on HUAWEI CloudEngine switches.
    ce_vlan – Manages VLAN resources and attributes on Huawei CloudEngine switches.
    ce_vrf – Manages VPN instance on HUAWEI CloudEngine switches.
    ce_vrf_af – Manages VPN instance address family on HUAWEI CloudEngine switches.
    ce_vrf_interface – Manages interface specific VPN configuration on HUAWEI CloudEngine switches.
    ce_vrrp – Manages VRRP interfaces on HUAWEI CloudEngine devices.
    ce_vxlan_arp – Manages ARP attributes of VXLAN on HUAWEI CloudEngine devices.
    ce_vxlan_gateway – Manages gateway for the VXLAN network on HUAWEI CloudEngine devices.
    ce_vxlan_global – Manages global attributes of VXLAN and bridge domain on HUAWEI CloudEngine devices.
    ce_vxlan_tunnel – Manages VXLAN tunnel configuration on HUAWEI CloudEngine devices.
    ce_vxlan_vap – Manages VXLAN virtual access point on HUAWEI CloudEngine Devices.
###Network modules - Cloudvision
    cv_server_provision – Provision server port by applying or removing template configuration to an Arista CloudVision Portal configlet that is applied to a switch.
###Network modules - Cnos
    cnos_backup – Backup the current running or startup configuration to a remote server on devices running Lenovo CNOS
    cnos_bgp – Manage BGP resources and attributes on devices running CNOS
    cnos_command – Run arbitrary commands on Lenovo CNOS devices
    cnos_conditional_command – Execute a single command based on condition on devices running Lenovo CNOS
    cnos_conditional_template – Manage switch configuration using templates based on condition on devices running Lenovo CNOS
    cnos_config – Manage Lenovo CNOS configuration sections
    cnos_factory – Reset the switch startup configuration to default (factory) on devices running Lenovo CNOS.
    cnos_facts – Collect facts from remote devices running Lenovo CNOS
    cnos_image – Perform firmware upgrade/download from a remote server on devices running Lenovo CNOS
    cnos_interface – Manage interface configuration on devices running Lenovo CNOS
    cnos_portchannel – Manage portchannel (port channel) configuration on devices running Lenovo CNOS
    cnos_reload – Perform switch restart on devices running Lenovo CNOS
    cnos_rollback – Roll back the running or startup configuration from a remote server on devices running Lenovo CNOS
    cnos_save – Save the running configuration as the startup configuration on devices running Lenovo CNOS
    cnos_showrun – Collect the current running configuration on devices running on CNOS
    cnos_template – Manage switch configuration using templates on devices running Lenovo CNOS
    cnos_vlag – Manage VLAG resources and attributes on devices running Lenovo CNOS
    cnos_vlan – Manage VLAN resources and attributes on devices running Lenovo CNOS
###Network modules - Cumulus
    nclu – Configure network interfaces using NCLU
###Network modules - Dellos10
    dellos10_command – Run commands on remote devices running Dell OS10
    dellos10_config – Manage Dell EMC Networking OS10 configuration sections
    dellos10_facts – Collect facts from remote devices running Dell EMC Networking OS10
###Network modules - Dellos6
    dellos6_command – Run commands on remote devices running Dell OS6
    dellos6_config – Manage Dell EMC Networking OS6 configuration sections
    dellos6_facts – Collect facts from remote devices running Dell EMC Networking OS6
###Network modules - Dellos9
    dellos9_command – Run commands on remote devices running Dell OS9
    dellos9_config – Manage Dell EMC Networking OS9 configuration sections
    dellos9_facts – Collect facts from remote devices running Dell EMC Networking OS9
###Network modules - Edgeos
    edgeos_command – Run one or more commands on EdgeOS devices
    edgeos_config – Manage EdgeOS configuration on remote device
    edgeos_facts – Collect facts from remote devices running EdgeOS
###Network modules - Enos
    enos_command – Run arbitrary commands on Lenovo ENOS devices
    enos_config – Manage Lenovo ENOS configuration sections
    enos_facts – Collect facts from remote devices running Lenovo ENOS
###Network modules - Eos
    eos_banner – Manage multiline banners on Arista EOS devices
    eos_command – Run arbitrary commands on an Arista EOS device
    eos_config – Manage Arista EOS configuration sections
    eos_eapi – Manage and configure Arista EOS eAPI.
    eos_facts – Collect facts from remote devices running Arista EOS
    eos_interface – Manage Interface on Arista EOS network devices
    eos_l2_interface – Manage L2 interfaces on Arista EOS network devices.
    eos_l3_interface – Manage L3 interfaces on Arista EOS network devices.
    eos_linkagg – Manage link aggregation groups on Arista EOS network devices
    eos_lldp – Manage LLDP configuration on Arista EOS network devices
    eos_logging – Manage logging on network devices
    eos_static_route – Manage static IP routes on Arista EOS network devices
    eos_system – Manage the system attributes on Arista EOS devices
    eos_user – Manage the collection of local users on EOS devices
    eos_vlan – Manage VLANs on Arista EOS network devices
    eos_vrf – Manage VRFs on Arista EOS network devices
###Network modules - Exos
    exos_command – Run commands on remote devices running Extreme EXOS
    exos_config – Manage Extreme Networks EXOS configuration sections
    exos_facts – Collect facts from devices running Extreme EXOS
###Network modules - F5
    bigip_appsvcs_extension – Manage application service deployments
    bigip_asm_policy – Manage BIG-IP ASM policies
    bigip_cli_alias – Manage CLI aliases on a BIG-IP
    bigip_cli_script – Manage CLI scripts on a BIG-IP
    bigip_command – Run arbitrary command on F5 devices
    bigip_config – Manage BIG-IP configuration sections
    bigip_configsync_action – Perform different actions related to config-sync
    bigip_data_group – Manage data groups on a BIG-IP
    bigip_device_auth – Manage system authentication on a BIG-IP
    bigip_device_connectivity – Manages device IP configuration settings for HA on a BIG-IP
    bigip_device_dns – Manage BIG-IP device DNS settings
    bigip_device_facts – Collect facts from F5 BIG-IP devices
    bigip_device_group – Manage device groups on a BIG-IP
    bigip_device_group_member – Manages members in a device group
    bigip_device_httpd – Manage HTTPD related settings on BIG-IP
    bigip_device_license – Manage license installation and activation on BIG-IP devices
    bigip_device_ntp – Manage NTP servers on a BIG-IP
    bigip_device_sshd – Manage the SSHD settings of a BIG-IP
    bigip_device_trust – Manage the trust relationships between BIG-IPs
    bigip_facts – Collect facts from F5 BIG-IP devices (D)
    bigip_firewall_address_list – Manage address lists on BIG-IP AFM
    bigip_firewall_dos_profile – Manage AFM DoS profiles on a BIG-IP
    bigip_firewall_policy – Manage AFM security firewall policies on a BIG-IP
    bigip_firewall_port_list – Manage port lists on BIG-IP AFM
    bigip_firewall_rule – Manage AFM Firewall rules
    bigip_firewall_rule_list – Manage AFM security firewall policies on a BIG-IP
    bigip_gtm_datacenter – Manage Datacenter configuration in BIG-IP
    bigip_gtm_facts – Collect facts from F5 BIG-IP GTM devices (D)
    bigip_gtm_global – Manages global GTM settings
    bigip_gtm_monitor_bigip – Manages F5 BIG-IP GTM BIG-IP monitors
    bigip_gtm_monitor_external – Manages external GTM monitors on a BIG-IP
    bigip_gtm_monitor_firepass – Manages F5 BIG-IP GTM FirePass monitors
    bigip_gtm_monitor_http – Manages F5 BIG-IP GTM http monitors
    bigip_gtm_monitor_https – Manages F5 BIG-IP GTM https monitors
    bigip_gtm_monitor_tcp – Manages F5 BIG-IP GTM tcp monitors
    bigip_gtm_monitor_tcp_half_open – Manages F5 BIG-IP GTM tcp half-open monitors
    bigip_gtm_pool – Manages F5 BIG-IP GTM pools
    bigip_gtm_pool_member – Manage GTM pool member settings
    bigip_gtm_server – Manages F5 BIG-IP GTM servers
    bigip_gtm_virtual_server – Manages F5 BIG-IP GTM virtual servers
    bigip_gtm_wide_ip – Manages F5 BIG-IP GTM wide ip
    bigip_hostname – Manage the hostname of a BIG-IP
    bigip_iapp_service – Manages TCL iApp services on a BIG-IP
    bigip_iapp_template – Manages TCL iApp templates on a BIG-IP
    bigip_iapplx_package – Manages Javascript iApp packages on a BIG-IP
    bigip_irule – Manage iRules across different modules on a BIG-IP
    bigip_log_destination – Manages log destinations on a BIG-IP.
    bigip_log_publisher – Manages log publishers on a BIG-IP
    bigip_management_route – Manage system management routes on a BIG-IP
    bigip_monitor_dns – Manage DNS monitors on a BIG-IP
    bigip_monitor_external – Manages external LTM monitors on a BIG-IP
    bigip_monitor_http – Manages F5 BIG-IP LTM http monitors
    bigip_monitor_https – Manages F5 BIG-IP LTM https monitors
    bigip_monitor_snmp_dca – Manages BIG-IP SNMP data collecting agent (DCA) monitors
    bigip_monitor_tcp – Manages F5 BIG-IP LTM tcp monitors
    bigip_monitor_tcp_echo – Manages F5 BIG-IP LTM tcp echo monitors
    bigip_monitor_tcp_half_open – Manages F5 BIG-IP LTM tcp half-open monitors
    bigip_monitor_udp – Manages F5 BIG-IP LTM udp monitors
    bigip_node – Manages F5 BIG-IP LTM nodes
    bigip_partition – Manage BIG-IP partitions
    bigip_policy – Manage general policy configuration on a BIG-IP
    bigip_policy_rule – Manage LTM policy rules on a BIG-IP
    bigip_pool – Manages F5 BIG-IP LTM pools
    bigip_pool_member – Manages F5 BIG-IP LTM pool members
    bigip_profile_client_ssl – Manages client SSL profiles on a BIG-IP
    bigip_profile_dns – Manage DNS profiles on a BIG-IP
    bigip_profile_http – Manage HTTP profiles on a BIG-IP
    bigip_profile_http_compression – Manage HTTP compression profiles on a BIG-IP
    bigip_profile_oneconnect – Manage OneConnect profiles on a BIG-IP
    bigip_profile_persistence_src_addr – Manage source address persistence profiles
    bigip_profile_tcp – Manage TCP profiles on a BIG-IP
    bigip_profile_udp – Manage UDP profiles on a BIG-IP
    bigip_provision – Manage BIG-IP module provisioning
    bigip_qkview – Manage qkviews on the device
    bigip_remote_role – Manage remote roles on a BIG-IP
    bigip_remote_syslog – Manipulate remote syslog settings on a BIG-IP
    bigip_routedomain – Manage route domains on a BIG-IP
    bigip_selfip – Manage Self-IPs on a BIG-IP system
    bigip_service_policy – Manages service policies on a BIG-IP.
    bigip_smtp – Manages SMTP settings on the BIG-IP
    bigip_snat_pool – Manage SNAT pools on a BIG-IP
    bigip_snmp – Manipulate general SNMP settings on a BIG-IP
    bigip_snmp_community – Manages SNMP communities on a BIG-IP.
    bigip_snmp_trap – Manipulate SNMP trap information on a BIG-IP
    bigip_software_image – Manage software images on a BIG-IP
    bigip_software_install – Install software images on a BIG-IP
    bigip_software_update – Manage the software update settings of a BIG-IP
    bigip_ssl_certificate – Import/Delete certificates from BIG-IP
    bigip_ssl_key – Import/Delete SSL keys from BIG-IP
    bigip_static_route – Manipulate static routes on a BIG-IP
    bigip_sys_db – Manage BIG-IP system database variables
    bigip_sys_global – Manage BIG-IP global settings
    bigip_timer_policy – Manage timer policies on a BIG-IP
    bigip_traffic_group – Manages traffic groups on BIG-IP
    bigip_trunk – Manage trunks on a BIG-IP
    bigip_tunnel – Manage tunnels on a BIG-IP
    bigip_ucs – Manage upload, installation and removal of UCS files
    bigip_ucs_fetch – Fetches a UCS file from remote nodes
    bigip_user – Manage user accounts and user attributes on a BIG-IP
    bigip_vcmp_guest – Manages vCMP guests on a BIG-IP
    bigip_virtual_address – Manage LTM virtual addresses on a BIG-IP
    bigip_virtual_server – Manage LTM virtual servers on a BIG-IP
    bigip_vlan – Manage VLANs on a BIG-IP system
    bigip_wait – Wait for a BIG-IP condition before continuing
    bigiq_application_fasthttp – Manages BIG-IQ FastHTTP applications
    bigiq_application_fastl4_tcp – Manages BIG-IQ FastL4 TCP applications
    bigiq_application_fastl4_udp – Manages BIG-IQ FastL4 UDP applications
    bigiq_application_http – Manages BIG-IQ HTTP applications
    bigiq_application_https_offload – Manages BIG-IQ HTTPS offload applications
    bigiq_application_https_waf – Manages BIG-IQ HTTPS WAF applications
    bigiq_regkey_license – Manages licenses in a BIG-IQ registration key pool
    bigiq_regkey_license_assignment – Manage regkey license assignment on BIG-IPs from a BIG-IQ
    bigiq_regkey_pool – Manages registration key pools on BIG-IQ
    bigiq_utility_license – Manage utility licenses on a BIG-IQ
    bigiq_utility_license_assignment – Manage utility license assignment on BIG-IPs from a BIG-IQ
###Network modules - Files
    net_get – Copy a file from a network device to Ansible Controller
    net_put – Copy a file from Ansible Controller to a network device
###Network modules - Fortimanager
    fmgr_provisioning – Provision devices via FortiMananger
    fmgr_script – Add/Edit/Delete and execute scripts
###Network modules - Fortios
    fortios_address – Manage fortios firewall address objects
    fortios_config – Manage config on Fortinet FortiOS firewall devices
    fortios_ipv4_policy – Manage IPv4 policy objects on Fortinet FortiOS firewall devices
    fortios_webfilter – Configure webfilter capabilities of FortiGate and FortiOS.
###Network modules - Ftd
    ftd_configuration – Manages configuration on Cisco FTD devices over REST API
    ftd_file_download – Downloads files from Cisco FTD devices over HTTP(S)
    ftd_file_upload – Uploads files to Cisco FTD devices over HTTP(S)
###Network modules - Illumos
    dladm_etherstub – Manage etherstubs on Solaris/illumos systems.
    dladm_iptun – Manage IP tunnel interfaces on Solaris/illumos systems.
    dladm_linkprop – Manage link properties on Solaris/illumos systems.
    dladm_vlan – Manage VLAN interfaces on Solaris/illumos systems.
    dladm_vnic – Manage VNICs on Solaris/illumos systems.
    flowadm – Manage bandwidth resource control and priority for protocols, services and zones on Solaris/illumos systems
    ipadm_addr – Manage IP addresses on an interface on Solaris/illumos systems
    ipadm_addrprop – Manage IP address properties on Solaris/illumos systems.
    ipadm_if – Manage IP interfaces on Solaris/illumos systems.
    ipadm_ifprop – Manage IP interface properties on Solaris/illumos systems.
    ipadm_prop – Manage protocol properties on Solaris/illumos systems.
###Network modules - Interface
    net_interface – Manage Interface on network devices
    net_linkagg – Manage link aggregation groups on network devices
    net_lldp_interface – Manage LLDP interfaces configuration on network devices
###Network modules - Ios
    ios_banner – Manage multiline banners on Cisco IOS devices
    ios_command – Run commands on remote devices running Cisco IOS
    ios_config – Manage Cisco IOS configuration sections
    ios_facts – Collect facts from remote devices running Cisco IOS
    ios_interface – Manage Interface on Cisco IOS network devices
    ios_l2_interface – Manage Layer-2 interface on Cisco IOS devices.
    ios_l3_interface – Manage Layer-3 interfaces on Cisco IOS network devices.
    ios_linkagg – Manage link aggregation groups on Cisco IOS network devices
    ios_lldp – Manage LLDP configuration on Cisco IOS network devices.
    ios_logging – Manage logging on network devices
    ios_ping – Tests reachability using ping from Cisco IOS network devices
    ios_static_route – Manage static IP routes on Cisco IOS network devices
    ios_system – Manage the system attributes on Cisco IOS devices
    ios_user – Manage the aggregate of local users on Cisco IOS device
    ios_vlan – Manage VLANs on IOS network devices
    ios_vrf – Manage the collection of VRF definitions on Cisco IOS devices
###Network modules - Iosxr
    iosxr_banner – Manage multiline banners on Cisco IOS XR devices
    iosxr_command – Run commands on remote devices running Cisco IOS XR
    iosxr_config – Manage Cisco IOS XR configuration sections
    iosxr_facts – Collect facts from remote devices running IOS XR
    iosxr_interface – Manage Interface on Cisco IOS XR network devices
    iosxr_logging – Configuration management of system logging services on network devices
    iosxr_netconf – Configures NetConf sub-system service on Cisco IOS-XR devices
    iosxr_system – Manage the system attributes on Cisco IOS XR devices
    iosxr_user – Manage the aggregate of local users on Cisco IOS XR device
###Network modules - Ironware
    ironware_command – Run arbitrary commands on Extreme IronWare devices
    ironware_config – Manage configuration sections on Extreme Ironware devices
    ironware_facts – Collect facts from devices running Extreme Ironware
###Network modules - Junos
    junos_banner – Manage multiline banners on Juniper JUNOS devices
    junos_command – Run arbitrary commands on an Juniper JUNOS device
    junos_config – Manage configuration on devices running Juniper JUNOS
    junos_facts – Collect facts from remote devices running Juniper Junos
    junos_interface – Manage Interface on Juniper JUNOS network devices
    junos_l2_interface – Manage Layer-2 interface on Juniper JUNOS network devices
    junos_l3_interface – Manage L3 interfaces on Juniper JUNOS network devices
    junos_linkagg – Manage link aggregation groups on Juniper JUNOS network devices
    junos_lldp – Manage LLDP configuration on Juniper JUNOS network devices
    junos_lldp_interface – Manage LLDP interfaces configuration on Juniper JUNOS network devices
    junos_logging – Manage logging on network devices
    junos_netconf – Configures the Junos Netconf system service
    junos_package – Installs packages on remote devices running Junos
    junos_rpc – Runs an arbitrary RPC over NetConf on an Juniper JUNOS device
    junos_scp – Transfer files from or to remote devices running Junos
    junos_static_route – Manage static IP routes on Juniper JUNOS network devices
    junos_system – Manage the system attributes on Juniper JUNOS devices
    junos_user – Manage local user accounts on Juniper JUNOS devices
    junos_vlan – Manage VLANs on Juniper JUNOS network devices
    junos_vrf – Manage the VRF definitions on Juniper JUNOS devices
###Network modules - Layer2
    net_l2_interface – Manage Layer-2 interface on network devices
    net_vlan – Manage VLANs on network devices
###Network modules - Layer3
    net_l3_interface – Manage L3 interfaces on network devices
    net_vrf – Manage VRFs on network devices
###Network modules - Meraki
    meraki_admin – Manage administrators in the Meraki cloud
    meraki_config_template – Manage configuration templates in the Meraki cloud
    meraki_device – Manage devices in the Meraki cloud
    meraki_mr_l3_firewall – Manage MR access point layer 3 firewalls in the Meraki cloud
    meraki_mx_l3_firewall – Manage MX appliance layer 3 firewalls in the Meraki cloud
    meraki_network – Manage networks in the Meraki cloud
    meraki_organization – Manage organizations in the Meraki cloud
    meraki_snmp – Manage organizations in the Meraki cloud
    meraki_ssid – Manage wireless SSIDs in the Meraki cloud
    meraki_switchport – Manage switchports on a switch in the Meraki cloud
    meraki_vlan – Manage VLANs in the Meraki cloud
###Network modules - Netact
    netact_cm_command – Manage network configuration data in Nokia Core and Radio networks
###Network modules - Netconf
    netconf_config – netconf device configuration
    netconf_get – Fetch configuration/state data from NETCONF enabled network devices.
    netconf_rpc – Execute operations on NETCONF enabled network devices.
###Network modules - Netscaler
    netscaler_cs_action – Manage content switching actions
    netscaler_cs_policy – Manage content switching policy
    netscaler_cs_vserver – Manage content switching vserver
    netscaler_gslb_service – Manage gslb service entities in Netscaler.
    netscaler_gslb_site – Manage gslb site entities in Netscaler.
    netscaler_gslb_vserver – Configure gslb vserver entities in Netscaler.
    netscaler_lb_monitor – Manage load balancing monitors
    netscaler_lb_vserver – Manage load balancing vserver configuration
    netscaler_nitro_request – Issue Nitro API requests to a Netscaler instance.
    netscaler_save_config – Save Netscaler configuration.
    netscaler_server – Manage server configuration
    netscaler_service – Manage service configuration in Netscaler
    netscaler_servicegroup – Manage service group configuration in Netscaler
    netscaler_ssl_certkey – Manage ssl cerificate keys.
###Network modules - Netvisor
    pn_cluster – CLI command to create/delete a cluster.
    pn_ospf – CLI command to add/remove ospf protocol to a vRouter.
    pn_ospfarea – CLI command to add/remove ospf area to/from a vrouter.
    pn_show – Run show commands on nvOS device.
    pn_trunk – CLI command to create/delete/modify a trunk.
    pn_vlag – CLI command to create/delete/modify vlag.
    pn_vlan – CLI command to create/delete a VLAN.
    pn_vrouter – CLI command to create/delete/modify a vrouter.
    pn_vrouterbgp – CLI command to add/remove/modify vrouter-bgp.
    pn_vrouterif – CLI command to add/remove/modify vrouter-interface.
    pn_vrouterlbif – CLI command to add/remove vrouter-loopback-interface.
###Network modules - Nos
    nos_command – Run commands on remote devices running Extreme Networks NOS
    nos_config – Manage Extreme Networks NOS configuration sections
    nos_facts – Collect facts from devices running Extreme NOS
###Network modules - Nso
    nso_action – Executes Cisco NSO actions and verifies output.
    nso_config – Manage Cisco NSO configuration and service synchronization.
    nso_query – Query data from Cisco NSO.
    nso_show – Displays data from Cisco NSO.
    nso_verify – Verifies Cisco NSO configuration.
###Network modules - Nuage
    nuage_vspk – Manage Nuage VSP environments
###Network modules - Nxos
    nxos_aaa_server – Manages AAA server global configuration.
    nxos_aaa_server_host – Manages AAA server host-specific configuration.
    nxos_acl – Manages access list entries for ACLs.
    nxos_acl_interface – Manages applying ACLs to interfaces.
    nxos_banner – Manage multiline banners on Cisco NXOS devices
    nxos_bgp – Manages BGP configuration.
    nxos_bgp_af – Manages BGP Address-family configuration.
    nxos_bgp_neighbor – Manages BGP neighbors configurations.
    nxos_bgp_neighbor_af – Manages BGP address-family’s neighbors configuration.
    nxos_command – Run arbitrary command on Cisco NXOS devices
    nxos_config – Manage Cisco NXOS configuration sections
    nxos_evpn_global – Handles the EVPN control plane for VXLAN.
    nxos_evpn_vni – Manages Cisco EVPN VXLAN Network Identifier (VNI).
    nxos_facts – Gets facts about NX-OS switches
    nxos_feature – Manage features in NX-OS switches.
    nxos_file_copy – Copy a file to a remote NXOS device.
    nxos_gir – Trigger a graceful removal or insertion (GIR) of the switch.
    nxos_gir_profile_management – Create a maintenance-mode or normal-mode profile for GIR.
    nxos_hsrp – Manages HSRP configuration on NX-OS switches.
    nxos_igmp – Manages IGMP global configuration.
    nxos_igmp_interface – Manages IGMP interface configuration.
    nxos_igmp_snooping – Manages IGMP snooping global configuration.
    nxos_install_os – Set boot options like boot, kickstart image and issu.
    nxos_interface – Manages physical attributes of interfaces.
    nxos_interface_ospf – Manages configuration of an OSPF interface instance.
    nxos_ip_interface – Manages L3 attributes for IPv4 and IPv6 interfaces. (D)
    nxos_l2_interface – Manage Layer-2 interface on Cisco NXOS devices.
    nxos_l3_interface – Manage L3 interfaces on Cisco NXOS network devices
    nxos_linkagg – Manage link aggregation groups on Cisco NXOS devices.
    nxos_lldp – Manage LLDP configuration on Cisco NXOS network devices.
    nxos_logging – Manage logging on network devices
    nxos_ntp – Manages core NTP configuration.
    nxos_ntp_auth – Manages NTP authentication.
    nxos_ntp_options – Manages NTP options.
    nxos_nxapi – Manage NXAPI configuration on an NXOS device.
    nxos_ospf – Manages configuration of an ospf instance.
    nxos_ospf_vrf – Manages a VRF for an OSPF router.
    nxos_overlay_global – Configures anycast gateway MAC of the switch.
    nxos_pim – Manages configuration of a PIM instance.
    nxos_pim_interface – Manages PIM interface configuration.
    nxos_pim_rp_address – Manages configuration of an PIM static RP address instance.
    nxos_ping – Tests reachability using ping from Nexus switch.
    nxos_portchannel – Manages port-channel interfaces. (D)
    nxos_reboot – Reboot a network device.
    nxos_rollback – Set a checkpoint or rollback to a checkpoint.
    nxos_rpm – Install patch or feature rpms on Cisco NX-OS devices.
    nxos_smu – Perform SMUs on Cisco NX-OS devices.
    nxos_snapshot – Manage snapshots of the running states of selected features.
    nxos_snmp_community – Manages SNMP community configs.
    nxos_snmp_contact – Manages SNMP contact info.
    nxos_snmp_host – Manages SNMP host configuration.
    nxos_snmp_location – Manages SNMP location information.
    nxos_snmp_traps – Manages SNMP traps.
    nxos_snmp_user – Manages SNMP users for monitoring.
    nxos_static_route – Manages static route configuration
    nxos_switchport – Manages Layer 2 switchport interfaces. (D)
    nxos_system – Manage the system attributes on Cisco NXOS devices
    nxos_udld – Manages UDLD global configuration params.
    nxos_udld_interface – Manages UDLD interface configuration params.
    nxos_user – Manage the collection of local users on Nexus devices
    nxos_vlan – Manages VLAN resources and attributes.
    nxos_vpc – Manages global VPC configuration
    nxos_vpc_interface – Manages interface VPC configuration
    nxos_vrf – Manages global VRF configuration.
    nxos_vrf_af – Manages VRF AF.
    nxos_vrf_interface – Manages interface specific VRF configuration.
    nxos_vrrp – Manages VRRP configuration on NX-OS switches.
    nxos_vtp_domain – Manages VTP domain configuration.
    nxos_vtp_password – Manages VTP password configuration.
    nxos_vtp_version – Manages VTP version configuration.
    nxos_vxlan_vtep – Manages VXLAN Network Virtualization Endpoint (NVE).
    nxos_vxlan_vtep_vni – Creates a Virtual Network Identifier member (VNI)
###Network modules - Onyx
    onyx_bgp – Configures BGP on Mellanox ONYX network devices
    onyx_command – Run commands on remote devices running Mellanox ONYX
    onyx_config – Manage Mellanox ONYX configuration sections
    onyx_facts – Collect facts from Mellanox ONYX network devices
    onyx_igmp – Configures IGMP globl parameters
    onyx_interface – Manage Interfaces on Mellanox ONYX network devices
    onyx_l2_interface – Manage Layer-2 interface on Mellanox ONYX network devices
    onyx_l3_interface – Manage L3 interfaces on Mellanox ONYX network devices
    onyx_linkagg – Manage link aggregation groups on Mellanox ONYX network devices
    onyx_lldp – Manage LLDP configuration on Mellanox ONYX network devices
    onyx_lldp_interface – Manage LLDP interfaces configuration on Mellanox ONYX network devices
    onyx_magp – Manage MAGP protocol on Mellanox ONYX network devices
    onyx_mlag_ipl – Manage IPL (inter-peer link) on Mellanox ONYX network devices
    onyx_mlag_vip – Configures MLAG VIP on Mellanox ONYX network devices
    onyx_ospf – Manage OSPF protocol on Mellanox ONYX network devices
    onyx_pfc_interface – Manage priority flow control on ONYX network devices
    onyx_protocol – Enables/Disables protocols on Mellanox ONYX network devices
    onyx_vlan – Manage VLANs on Mellanox ONYX network devices
###Network modules - Opx
    opx_cps – CPS operations on networking device running Openswitch (OPX)
###Network modules - Ordnance
    ordnance_config – Manage Ordnance configuration sections
    ordnance_facts – Collect facts from Ordnance Virtual Routers over SSH
###Network modules - Ovs
    openvswitch_bridge – Manage Open vSwitch bridges
    openvswitch_db – Configure open vswitch database.
    openvswitch_port – Manage Open vSwitch ports
###Network modules - Panos
    panos_admin – Add or modify PAN-OS user accounts password.
    panos_admpwd – change admin password of PAN-OS device using SSH with SSH key
    panos_cert_gen_ssh – generates a self-signed certificate using SSH protocol with SSH key
    panos_check – check if PAN-OS device is ready for configuration
    panos_commit – commit firewall’s candidate configuration
    panos_dag – create a dynamic address group
    panos_dag_tags – Create tags for DAG’s on PAN-OS devices.
    panos_import – import file on PAN-OS devices
    panos_interface – configure data-port network interface for DHCP
    panos_lic – apply authcode to a device/instance
    panos_loadcfg – load configuration on PAN-OS device
    panos_match_rule – Test for match against a security rule on PAN-OS devices or Panorama management console.
    panos_mgtconfig – configure management settings of device
    panos_nat_policy – create a policy NAT rule (D)
    panos_nat_rule – create a policy NAT rule
    panos_object – create/read/update/delete object in PAN-OS or Panorama
    panos_op – execute arbitrary OP commands on PANW devices (e.g. show interface all)
    panos_pg – create a security profiles group
    panos_query_rules – PANOS module that allows search for security rules in PANW NGFW devices.
    panos_restart – restart a device
    panos_sag – Create a static address group.
    panos_security_policy – Create security rule policy on PanOS devices. (D)
    panos_security_rule – Create security rule policy on PAN-OS devices or Panorama management console.
    panos_set – Execute arbitrary commands on a PAN-OS device using XPath and element
###Network modules - Protocol
    net_lldp – Manage LLDP service configuration on network devices
###Network modules - Radware
    vdirect_commit – Commits pending configuration changes on Radware devices
    vdirect_file – Uploads a new or updates an existing runnable file into Radware vDirect server
    vdirect_runnable – Runs templates and workflow actions in Radware vDirect server
###Network modules - Routeros
    routeros_command – Run commands on remote devices running MikroTik RouterOS
###Network modules - Routing
    net_static_route – Manage static IP routes on network appliances (routers, switches et. al.)
###Network modules - Slxos
    slxos_command – Run commands on remote devices running Extreme Networks SLX-OS
    slxos_config – Manage Extreme Networks SLX-OS configuration sections
    slxos_facts – Collect facts from devices running Extreme SLX-OS
    slxos_interface – Manage Interfaces on Extreme SLX-OS network devices
    slxos_l2_interface – Manage Layer-2 interface on Extreme Networks SLX-OS devices.
    slxos_l3_interface – Manage L3 interfaces on Extreme Networks SLX-OS network devices.
    slxos_linkagg – Manage link aggregation groups on Extreme Networks SLX-OS network devices
    slxos_lldp – Manage LLDP configuration on Extreme Networks SLX-OS network devices.
    slxos_vlan – Manage VLANs on Extreme Networks SLX-OS network devices
###Network modules - Sros
    sros_command – Run commands on remote devices running Nokia SR OS
    sros_config – Manage Nokia SR OS device configuration
    sros_rollback – Configure Nokia SR OS rollback
###Network modules - System
    net_banner – Manage multiline banners on network devices
    net_logging – Manage logging on network devices
    net_ping – Tests reachability using ping from a network device
    net_system – Manage the system attributes on network devices
    net_user – Manage the aggregate of local users on network device
###Network modules - Voss
    voss_command – Run commands on remote devices running Extreme VOSS
    voss_facts – Collect facts from remote devices running Extreme VOSS
###Network modules - Vyos
    vyos_banner – Manage multiline banners on VyOS devices
    vyos_command – Run one or more commands on VyOS devices
    vyos_config – Manage VyOS configuration on remote device
    vyos_facts – Collect facts from remote devices running VyOS
    vyos_interface – Manage Interface on VyOS network devices
    vyos_l3_interface – Manage L3 interfaces on VyOS network devices
    vyos_linkagg – Manage link aggregation groups on VyOS network devices
    vyos_lldp – Manage LLDP configuration on VyOS network devices
    vyos_lldp_interface – Manage LLDP interfaces configuration on VyOS network devices
    vyos_logging – Manage logging on network devices
    vyos_static_route – Manage static IP routes on Vyatta VyOS network devices
    vyos_system – Run set system commands on VyOS devices
    vyos_user – Manage the collection of local users on VyOS device
    vyos_vlan – Manage VLANs on VyOS network devices
###Notification modules
    bearychat – Send BearyChat notifications
    campfire – Send a message to Campfire
    catapult – Send a sms / mms using the catapult bandwidth api
    cisco_spark – Send a message to a Cisco Spark Room or Individual.
    flowdock – Send a message to a flowdock
    grove – Sends a notification to a grove.io channel
    hall – Send notification to Hall
    hipchat – Send a message to Hipchat.
    irc – Send a message to an IRC channel
    jabber – Send a message to jabber user or chat room
    logentries_msg – Send a message to logentries.
    mail – Send an email
    mattermost – Send Mattermost notifications
    mqtt – Publish a message on an MQTT topic for the IoT
    nexmo – Send a SMS via nexmo
    office_365_connector_card – Use webhooks to create Connector Card messages within an Office 365 group
    pushbullet – Sends notifications to Pushbullet
    pushover – Send notifications via https://pushover.net
    rocketchat – Send notifications to Rocket Chat
    say – Makes a computer to speak.
    sendgrid – Sends an email with the SendGrid API
    slack – Send Slack notifications
    snow_record – Create/Delete/Update records in ServiceNow
    syslogger – Log messages in the syslog
    telegram – module for sending notifications via telegram
    twilio – Sends a text message to a mobile phone through Twilio.
    typetalk – Send a message to typetalk

###Packaging modules - Language
    bower – Manage bower packages with bower
    bundler – Manage Ruby Gem dependencies with Bundler
    composer – Dependency Manager for PHP
    cpanm – Manages Perl library dependencies.
    easy_install – Installs Python libraries
    gem – Manage Ruby gems
    maven_artifact – Downloads an Artifact from a Maven Repository
    npm – Manage node.js packages with npm
    pear – Manage pear/pecl packages
    pip – Manages Python library dependencies
    yarn – Manage node.js packages with Yarn
###Packaging modules - Os
    apk – Manages apk packages
    apt – Manages apt-packages
    apt_key – Add or remove an apt key
    apt_repository – Add and remove APT repositories
    apt_rpm – apt_rpm package manager
    dnf – Manages packages with the dnf package manager
    dpkg_selections – Dpkg package selection selections
    flatpak – Manage flatpaks
    flatpak_remote – Manage flatpak repository remotes
    homebrew – Package manager for Homebrew
    homebrew_cask – Install/uninstall homebrew casks.
    homebrew_tap – Tap a Homebrew repository.
    layman – Manage Gentoo overlays
    macports – Package manager for MacPorts
    openbsd_pkg – Manage packages on OpenBSD
    opkg – Package manager for OpenWrt
    package – Generic OS package manager
    package_facts – package information as facts
    pacman – Manage packages with pacman
    pkg5 – Manages packages with the Solaris 11 Image Packaging System
    pkg5_publisher – Manages Solaris 11 Image Packaging System publishers
    pkgin – Package manager for SmartOS, NetBSD, et al.
    pkgng – Package manager for FreeBSD >= 9.0
    pkgutil – Manage CSW-Packages on Solaris
    portage – Package manager for Gentoo
    portinstall – Installing packages from FreeBSD’s ports system
    pulp_repo – Add or remove Pulp repos from a remote host.
    redhat_subscription – Manage registration and subscriptions to RHSM using the subscription-manager command
    rhn_channel – Adds or removes Red Hat software channels
    rhn_register – Manage Red Hat Network registration using the rhnreg_ks command
    rhsm_repository – Manage RHSM repositories using the subscription-manager command
    rpm_key – Adds or removes a gpg key from the rpm db
    slackpkg – Package manager for Slackware >= 12.2
    sorcery – Package manager for Source Mage GNU/Linux
    svr4pkg – Manage Solaris SVR4 packages
    swdepot – Manage packages with swdepot package manager (HP-UX)
    swupd – Manages updates and bundles in ClearLinux systems.
    urpmi – Urpmi manager
    xbps – Manage packages with XBPS
    yum – Manages packages with the yum package manager
    yum_repository – Add or remove YUM repositories
    zypper – Manage packages on SUSE and openSUSE
    zypper_repository – Add and remove Zypper repositories
###Remote Management modules - Misc 
    wakeonlan – Send a magic Wake-on-LAN (WoL) broadcast packet
###Remote Management modules - Cobbler
    cobbler_sync – Sync Cobbler
    cobbler_system – Manage system objects in Cobbler
###Remote Management modules - Cpm
    cpm_user – Get various status and parameters from WTI OOB and PDU devices
###Remote Management modules - Foreman
    foreman – Manage Foreman Resources
    katello – Manage Katello Resources
###Remote Management modules - Hpilo
    hpilo_boot – Boot system using specific media through HP iLO interface
    hpilo_facts – Gather facts through an HP iLO interface
    hponcfg – Configure HP iLO interface using hponcfg
###Remote Management modules - Imc
    imc_rest – Manage Cisco IMC hardware through its REST API
###Remote Management modules - Ipmi
    ipmi_boot – Management of order of boot devices
    ipmi_power – Power management for machine
###Remote Management modules - Manageiq
    manageiq_alert_profiles – Configuration of alert profiles for ManageIQ
    manageiq_alerts – Configuration of alerts in ManageIQ
    manageiq_policies – Management of resource policy_profiles in ManageIQ.
    manageiq_provider – Management of provider in ManageIQ.
    manageiq_tags – Management of resource tags in ManageIQ.
    manageiq_user – Management of users in ManageIQ.
###Remote Management modules - Oneview
    oneview_datacenter_facts – Retrieve facts about the OneView Data Centers
    oneview_enclosure_facts – Retrieve facts about one or more Enclosures
    oneview_ethernet_network – Manage OneView Ethernet Network resources
    oneview_ethernet_network_facts – Retrieve the facts about one or more of the OneView Ethernet Networks
    oneview_fc_network – Manage OneView Fibre Channel Network resources.
    oneview_fc_network_facts – Retrieve the facts about one or more of the OneView Fibre Channel Networks
    oneview_fcoe_network – Manage OneView FCoE Network resources
    oneview_fcoe_network_facts – Retrieve the facts about one or more of the OneView FCoE Networks
    oneview_logical_interconnect_group – Manage OneView Logical Interconnect Group resources
    oneview_logical_interconnect_group_facts – Retrieve facts about one or more of the OneView Logical Interconnect Groups
    oneview_network_set – Manage HPE OneView Network Set resources
    oneview_network_set_facts – Retrieve facts about the OneView Network Sets
    oneview_san_manager – Manage OneView SAN Manager resources
    oneview_san_manager_facts – Retrieve facts about one or more of the OneView SAN Managers
###Remote Management modules - Redfish
    redfish_command – Manages Out-Of-Band controllers using Redfish APIs
    redfish_config – Manages Out-Of-Band controllers using Redfish APIs
    redfish_facts – Manages Out-Of-Band controllers using Redfish APIs
###Remote Management modules - Stacki
    stacki_host – Add or remove host to stacki front-end
###Remote Management modules - Ucs
    ucs_ip_pool – Configures IP address pools on Cisco UCS Manager
    ucs_lan_connectivity – Configures LAN Connectivity Policies on Cisco UCS Manager
    ucs_mac_pool – Configures MAC address pools on Cisco UCS Manager
    ucs_ntp_server – Configures NTP server on Cisco UCS Manager
    ucs_san_connectivity – Configures SAN Connectivity Policies on Cisco UCS Manager
    ucs_storage_profile – Configures storage profiles on Cisco UCS Manager
    ucs_timezone – Configures timezone on Cisco UCS Manager
    ucs_uuid_pool – Configures server UUID pools on Cisco UCS Manager
    ucs_vhba_template – Configures vHBA templates on Cisco UCS Manager
    ucs_vlans – Configures VLANs on Cisco UCS Manager
    ucs_vnic_template – Configures vNIC templates on Cisco UCS Manager
    ucs_vsans – Configures VSANs on Cisco UCS Manager
    ucs_wwn_pool – Configures WWNN or WWPN pools on Cisco UCS Manager
###Source Control modules
    bzr – Deploy software (or files) from bzr branches
    git – Deploy software (or files) from git checkouts
    git_config – Read and write git configuration
    github_deploy_key – Manages deploy keys for GitHub repositories.
    github_hooks – Manages GitHub service hooks.
    github_issue – View GitHub issue.
    github_key – Manage GitHub access keys.
    github_release – Interact with GitHub Releases
    gitlab_deploy_key – Manages GitLab project deploy keys.
    gitlab_group – Creates/updates/deletes Gitlab Groups
    gitlab_hooks – Manages GitLab project hooks.
    gitlab_project – Creates/updates/deletes Gitlab Projects
    gitlab_user – Creates/updates/deletes Gitlab Users
    hg – Manages Mercurial (hg) repositories
    subversion – Deploys a subversion repository

###Storage modules- Emc
    emc_vnx_sg_member – Manage storage group member on EMC VNX
###Storage modules- Glusterfs
    gluster_peer – Attach/Detach peers to/from the cluster
    gluster_volume – Manage GlusterFS volumes
###Storage modules- Ibm
    ibm_sa_host – Adds hosts to or removes them from IBM Spectrum Accelerate storage systems.
    ibm_sa_pool – Handles pools on an IBM Spectrum Accelerate storage array.
    ibm_sa_vol – Handle volumes on an IBM Spectrum Accelerate storage array
###Storage modules- Infinidat
    infini_export – Create, Delete or Modify NFS Exports on Infinibox
    infini_export_client – Create, Delete or Modify NFS Client(s) for existing exports on Infinibox
    infini_fs – Create, Delete or Modify filesystems on Infinibox
    infini_host – Create, Delete and Modify Hosts on Infinibox
    infini_pool – Create, Delete and Modify Pools on Infinibox
    infini_vol – Create, Delete or Modify volumes on Infinibox
###Storage modules- Netapp
    na_cdot_aggregate – Manage NetApp cDOT aggregates. (D)
    na_cdot_license – Manage NetApp cDOT protocol and feature licenses (D)
    na_cdot_lun – Manage NetApp cDOT luns (D)
    na_cdot_qtree – Manage qtrees (D)
    na_cdot_svm – Manage NetApp cDOT svm (D)
    na_cdot_user – useradmin configuration and management (D)
    na_cdot_user_role – useradmin configuration and management (D)
    na_cdot_volume – Manage NetApp cDOT volumes (D)
    na_elementsw_access_group – NetApp Element Software Manage Access Groups
    na_elementsw_account – NetApp Element Software Manage Accounts
    na_elementsw_admin_users – NetApp Element Software Manage Admin Users
    na_elementsw_backup – NetApp Element Software Create Backups
    na_elementsw_check_connections – NetApp Element Software Check connectivity to MVIP and SVIP.
    na_elementsw_cluster – NetApp Element Software Create Cluster
    na_elementsw_cluster_pair – NetApp Element Software Manage Cluster Pair
    na_elementsw_drive – NetApp Element Software Manage Node Drives
    na_elementsw_ldap – NetApp Element Software Manage ldap admin users
    na_elementsw_network_interfaces – NetApp Element Software Configure Node Network Interfaces
    na_elementsw_node – NetApp Element Software Node Operation
    na_elementsw_snapshot – NetApp Element Software Manage Snapshots
    na_elementsw_snapshot_restore – NetApp Element Software Restore Snapshot
    na_elementsw_snapshot_schedule – NetApp Element Software Snapshot Schedules
    na_elementsw_vlan – NetApp Element Software Manage VLAN
    na_elementsw_volume – NetApp Element Software Manage Volumes
    na_elementsw_volume_clone – NetApp Element Software Create Volume Clone
    na_elementsw_volume_pair – NetApp Element Software Volume Pair
    na_ontap_aggregate – NetApp ONTAP manage aggregates.
    na_ontap_autosupport – NetApp ONTAP manage Autosupport
    na_ontap_broadcast_domain – NetApp ONTAP manage broadcast domains..
    na_ontap_broadcast_domain_ports – NetApp ONTAP manage broadcast domain ports
    na_ontap_cg_snapshot – NetApp ONTAP manage consistency group snapshot
    na_ontap_cifs – NetApp ONTAP manage cifs-share
    na_ontap_cifs_acl – NetApp ONTAP manage cifs-share-access-control
    na_ontap_cifs_server – NetApp ONTAP CIFS server configuration
    na_ontap_cluster – NetApp ONTAP cluster - create, join, add license
    na_ontap_cluster_ha – NetApp ONTAP Manage HA status for cluster
    na_ontap_cluster_peer – NetApp ONTAP Manage Cluster peering
    na_ontap_command – NetApp ONTAP Run any cli command
    na_ontap_disks – NetApp ONTAP Assign disks to nodes
    na_ontap_dns – NetApp ONTAP Create, delete, modify DNS servers.
    na_ontap_export_policy – NetApp ONTAP manage export-policy
    na_ontap_export_policy_rule – NetApp ONTAP manage export policy rules
    na_ontap_fcp – NetApp ONTAP Start, Stop and Enable FCP services.
    na_ontap_firewall_policy – NetApp ONTAP Manage a firewall policy
    na_ontap_gather_facts – NetApp information gatherer
    na_ontap_igroup – NetApp ONTAP iSCSI igroup configuration
    na_ontap_interface – NetApp ONTAP LIF configuration
    na_ontap_iscsi – NetApp ONTAP manage iSCSI service
    na_ontap_job_schedule – NetApp ONTAP Job Schedule
    na_ontap_license – NetApp ONTAP protocol and feature licenses
    na_ontap_lun – NetApp ONTAP manage LUNs
    na_ontap_lun_map – NetApp ONTAP LUN maps
    na_ontap_motd – Setup motd on cDOT
    na_ontap_net_ifgrp – NetApp Ontap modify network interface group
    na_ontap_net_port – NetApp ONTAP network ports.
    na_ontap_net_routes – NetApp ONTAP network routes
    na_ontap_net_vlan – NetApp ONTAP network VLAN
    na_ontap_nfs – NetApp ONTAP NFS status
    na_ontap_node – NetApp ONTAP Rename a node.
    na_ontap_ntp – NetApp ONTAP NTP server
    na_ontap_qtree – NetApp ONTAP manage qtrees
    na_ontap_service_processor_network – NetApp ONTAP service processor network
    na_ontap_snapmirror – NetApp ONTAP Manage SnapMirror
    na_ontap_snapshot – NetApp ONTAP manage Snapshots
    na_ontap_snmp – NetApp ONTAP SNMP community
    na_ontap_software_update – NetApp ONTAP Update Software
    na_ontap_svm – Manage NetApp ONTAP svm
    na_ontap_svm_options – NetApp ONTAP Modify SVM Options
    na_ontap_ucadapter – NetApp ONTAP UC adapter configuration
    na_ontap_user – NetApp ONTAP user configuration and management
    na_ontap_user_role – NetApp ONTAP user role configuration and management
    na_ontap_volume – NetApp ONTAP manage volumes.
    na_ontap_volume_clone – NetApp ONTAP manage volume clones.
    na_ontap_vserver_peer – NetApp ONTAP Vserver peering
    netapp_e_alerts – NetApp E-Series manage email notification settings
    netapp_e_amg – NetApp E-Series create, remove, and update asynchronous mirror groups
    netapp_e_amg_role – NetApp E-Series update the role of a storage array within an Asynchronous Mirror Group (AMG).
    netapp_e_amg_sync – NetApp E-Series conduct synchronization actions on asynchronous mirror groups.
    netapp_e_asup – NetApp E-Series manage auto-support settings
    netapp_e_auditlog – NetApp E-Series manage audit-log configuration
    netapp_e_auth – NetApp E-Series set or update the password for a storage array.
    netapp_e_facts – NetApp E-Series retrieve facts about NetApp E-Series storage arrays
    netapp_e_flashcache – NetApp E-Series manage SSD caches
    netapp_e_global – NetApp E-Series manage global settings configuration
    netapp_e_host – NetApp E-Series manage eseries hosts
    netapp_e_hostgroup – NetApp E-Series manage array host groups
    netapp_e_iscsi_interface – NetApp E-Series manage iSCSI interface configuration
    netapp_e_iscsi_target – NetApp E-Series manage iSCSI target configuration
    netapp_e_ldap – NetApp E-Series manage LDAP integration to use for authentication
    netapp_e_lun_mapping – NetApp E-Series create, delete, or modify lun mappings
    netapp_e_mgmt_interface – NetApp E-Series management interface configuration
    netapp_e_snapshot_group – NetApp E-Series manage snapshot groups
    netapp_e_snapshot_images – NetApp E-Series create and delete snapshot images
    netapp_e_snapshot_volume – NetApp E-Series manage snapshot volumes.
    netapp_e_storage_system – NetApp E-Series Web Services Proxy manage storage arrays
    netapp_e_storagepool – NetApp E-Series manage disk groups and disk pools
    netapp_e_syslog – NetApp E-Series manage syslog settings
    netapp_e_volume – NetApp E-Series manage storage volumes (standard and thin)
    netapp_e_volume_copy – NetApp E-Series create volume copy pairs
    sf_account_manager – Manage SolidFire accounts (D)
    sf_check_connections – Check connectivity to MVIP and SVIP. (D)
    sf_snapshot_schedule_manager – Manage SolidFire snapshot schedules (D)
    sf_volume_access_group_manager – Manage SolidFire Volume Access Groups (D)
    sf_volume_manager – Manage SolidFire volumes (D)
###Storage modules- Purestorage
    purefa_ds – Configure FlashArray Directory Service
    purefa_facts – Collect facts from Pure Storage FlashArray
    purefa_hg – Manage hostgroups on Pure Storage FlashArrays
    purefa_host – Manage hosts on Pure Storage FlashArrays
    purefa_pg – Manage protection groups on Pure Storage FlashArrays
    purefa_pgsnap – Manage local protection group snapshots on Pure Storage FlashArrays
    purefa_snap – Manage volume snapshots on Pure Storage FlashArrays
    purefa_volume – Manage volumes on Pure Storage FlashArrays
    purefb_facts – Collect facts from Pure Storage FlashBlade
    purefb_fs – Manage filesystemon Pure Storage FlashBlade`
    purefb_snap – Manage filesystem snapshots on Pure Storage FlashBlades
###Storage modules- Zfs
    zfs – Manage zfs
    zfs_facts – Gather facts about ZFS datasets.
    zpool_facts – Gather facts about ZFS pools.
###System modules
    aix_inittab – Manages the inittab on AIX
    aix_lvol – Configure AIX LVM logical volumes
    alternatives – Manages alternative programs for common commands
    at – Schedule the execution of a command or script file via the at command
    authorized_key – Adds or removes an SSH authorized key
    awall – Manage awall policies
    beadm – Manage ZFS boot environments on FreeBSD/Solaris/illumos systems.
    capabilities – Manage Linux capabilities
    cron – Manage cron.d and crontab entries
    cronvar – Manage variables in crontabs
    crypttab – Encrypted Linux block devices
    dconf – Modify and read dconf database
    debconf – Configure a .deb package
    facter – Runs the discovery program facter on the remote system
    filesystem – Makes a filesystem
    firewalld – Manage arbitrary ports/services with firewalld
    gconftool2 – Edit GNOME Configurations
    getent – A wrapper to the unix getent utility
    group – Add or remove groups
    hostname – Manage hostname
    interfaces_file – Tweak settings in /etc/network/interfaces files
    iptables – Modify the systems iptables
    java_cert – Uses keytool to import/remove key from java keystore(cacerts)
    java_keystore – Create or delete a Java keystore in JKS format.
    kernel_blacklist – Blacklist kernel modules
    known_hosts – Add or remove a host from the known_hosts file
    locale_gen – Creates or removes locales
    lvg – Configure LVM volume groups
    lvol – Configure LVM logical volumes
    make – Run targets in a Makefile
    mksysb – Generates AIX mksysb rootvg backups.
    modprobe – Load or unload kernel modules
    mount – Control active and configured mount points
    nosh – Manage services with nosh
    ohai – Returns inventory data from Ohai
    open_iscsi – Manage iscsi targets with open-iscsi
    openwrt_init – Manage services on OpenWrt.
    osx_defaults – osx_defaults allows users to read, write, and delete macOS user defaults from Ansible
    pam_limits – Modify Linux PAM limits
    pamd – Manage PAM Modules
    parted – Configure block device partitions
    ping – Try to connect to host, verify a usable python and return pong on success
    puppet – Runs puppet
    python_requirements_facts – Show python path and assert dependency versions
    reboot – Reboot a machine
    runit – Manage runit services
    seboolean – Toggles SELinux booleans
    sefcontext – Manages SELinux file context mapping definitions
    selinux – Change policy and state of SELinux
    selinux_permissive – Change permissive domain in SELinux policy
    seport – Manages SELinux network port type definitions
    service – Manage services
    service_facts – Return service state information as fact data
    setup – Gathers facts about remote hosts
    solaris_zone – Manage Solaris zones
    svc – Manage daemontools services
    sysctl – Manage entries in sysctl.conf.
    systemd – Manage services
    sysvinit – Manage SysV services.
    timezone – Configure timezone setting
    ufw – Manage firewall with UFW
    user – Manage user accounts
    vdo – Module to control VDO
###Utilities modules - Helper
    meta – Execute Ansible ‘actions’
###Utilities modules - Logic
    assert – Asserts given expressions are true
    async_status – Obtain status of asynchronous task
    debug – Print statements during execution
    fail – Fail with custom message
    import_playbook – Import a playbook
    import_role – Import a role into a play
    import_tasks – Import a task list
    include – Include a play or task list
    include_role – Load and execute a role
    include_tasks – Dynamically include a task list
    include_vars – Load variables from files, dynamically within a task
    pause – Pause playbook execution
    set_fact – Set host facts from a task
    set_stats – Set stats for the current ansible run
    wait_for – Waits for a condition before continuing
    wait_for_connection – Waits until remote system is reachable/usable
###Web Infrastructure modules - Misc 
    apache2_mod_proxy – Set and/or get members’ attributes of an Apache httpd 2.4 mod_proxy balancer pool
    apache2_module – Enables/disables a module of the Apache2 webserver.
    deploy_helper – Manages some of the steps common in deploying projects.
    django_manage – Manages a Django application.
    ejabberd_user – Manages users for ejabberd servers
    gunicorn – Run gunicorn with various settings.
    htpasswd – manage user files for basic authentication
    jboss – deploy applications to JBoss
    jenkins_job – Manage jenkins jobs
    jenkins_job_facts – Get facts about Jenkins jobs
    jenkins_plugin – Add or remove Jenkins plugin
    jenkins_script – Executes a groovy script in the jenkins instance
    jira – create and modify issues in a JIRA instance
    nginx_status_facts – Retrieve nginx status facts.
    rundeck_acl_policy – Manage Rundeck ACL policies.
    rundeck_project – Manage Rundeck projects.
    supervisorctl – Manage the state of a program or group of programs running via supervisord
    taiga_issue – Creates/deletes an issue in a Taiga Project Management Platform
###Web Infrastructure modules - Ansible_Tower 
    tower_credential – create, update, or destroy Ansible Tower credential.
    tower_credential_type – Create, update, or destroy custom Ansible Tower credential type.
    tower_group – create, update, or destroy Ansible Tower group.
    tower_host – create, update, or destroy Ansible Tower host.
    tower_inventory – create, update, or destroy Ansible Tower inventory.
    tower_inventory_source – create, update, or destroy Ansible Tower inventory source.
    tower_job_cancel – Cancel an Ansible Tower Job.
    tower_job_launch – Launch an Ansible Job.
    tower_job_list – List Ansible Tower jobs.
    tower_job_template – create, update, or destroy Ansible Tower job template.
    tower_job_wait – Wait for Ansible Tower job to finish.
    tower_label – create, update, or destroy Ansible Tower label.
    tower_organization – create, update, or destroy Ansible Tower organizations
    tower_project – create, update, or destroy Ansible Tower projects
    tower_role – create, update, or destroy Ansible Tower role.
    tower_settings – Modify Ansible Tower settings.
    tower_team – create, update, or destroy Ansible Tower team.
    tower_user – create, update, or destroy Ansible Tower user.
    tower_workflow_template – create, update, or destroy Ansible Tower workflow template.
###Windows modules
    win_acl – Set file/directory/registry permissions for a system user or group
    win_acl_inheritance – Change ACL inheritance
    win_audit_policy_system – Used to make changes to the system wide Audit Policy
    win_audit_rule – Adds an audit rule to files, folders, or registry keys
    win_certificate_store – Manages the certificate store
    win_chocolatey – Manage packages using chocolatey
    win_chocolatey_config – Manages Chocolatey config settings
    win_chocolatey_feature – Manages Chocolatey features
    win_chocolatey_source – Manages Chocolatey sources
    win_command – Executes a command on a remote Windows node
    win_copy – Copies files to remote locations on windows hosts
    win_defrag – Consolidate fragmented files on local volumes
    win_disk_facts – Show the attached disks and disk information of the target host
    win_disk_image – Manage ISO/VHD/VHDX mounts on Windows hosts
    win_dns_client – Configures DNS lookup on Windows hosts
    win_domain – Ensures the existence of a Windows domain
    win_domain_computer – Manage computers in Active Directory
    win_domain_controller – Manage domain controller/member server state for a Windows host
    win_domain_group – Creates, modifies or removes domain groups
    win_domain_membership – Manage domain/workgroup membership for a Windows host
    win_domain_user – Manages Windows Active Directory user accounts
    win_dotnet_ngen – Runs ngen to recompile DLLs after .NET updates
    win_dsc – Invokes a PowerShell DSC configuration
    win_environment – Modify environment variables on windows hosts
    win_eventlog – Manage Windows event logs
    win_eventlog_entry – Write entries to Windows event logs
    win_feature – Installs and uninstalls Windows Features on Windows Server
    win_file – Creates, touches or removes files or directories
    win_file_version – Get DLL or EXE file build version
    win_find – Return a list of files based on specific criteria
    win_firewall – Enable or disable the Windows Firewall
    win_firewall_rule – Windows firewall automation
    win_get_url – Downloads file from HTTP, HTTPS, or FTP to node
    win_group – Add and remove local groups
    win_group_membership – Manage Windows local group membership
    win_hostname – Manages local Windows computer name.
    win_hotfix – Install and uninstalls Windows hotfixes
    win_iis_virtualdirectory – Configures a virtual directory in IIS
    win_iis_webapplication – Configures IIS web applications
    win_iis_webapppool – Configure IIS Web Application Pools
    win_iis_webbinding – Configures a IIS Web site binding
    win_iis_website – Configures a IIS Web site
    win_lineinfile – Ensure a particular line is in a file, or replace an existing line using a back-referenced regular expression
    win_mapped_drive – Map network drives for users
    win_msg – Sends a message to logged in users on Windows hosts
    win_msi – Installs and uninstalls Windows MSI files (D)
    win_nssm – NSSM - the Non-Sucking Service Manager
    win_owner – Set owner
    win_package – Installs/uninstalls an installable package
    win_pagefile – Query or change pagefile configuration
    win_path – Manage Windows path environment variables
    win_pester – Run Pester tests on Windows hosts
    win_ping – A windows version of the classic ping module
    win_power_plan – Changes the power plan of a Windows system
    win_product_facts – Provides Windows product information (product id, product key)
    win_psexec – Runs commands (remotely) as another (privileged) user
    win_psmodule – Adds or removes a Powershell Module
    win_rabbitmq_plugin – Manage RabbitMQ plugins
    win_reboot – Reboot a windows machine
    win_reg_stat – Get information about Windows registry keys
    win_regedit – Add, change, or remove registry keys and values
    win_region – Set the region and format settings
    win_regmerge – Merges the contents of a registry file into the windows registry
    win_robocopy – Synchronizes the contents of two directories using Robocopy
    win_route – Add or remove a static route
    win_say – Text to speech module for Windows to speak messages and optionally play sounds
    win_scheduled_task – Manage scheduled tasks
    win_scheduled_task_stat – Get information about Windows Scheduled Tasks
    win_security_policy – Change local security policy settings
    win_service – Manage and query Windows services
    win_share – Manage Windows shares
    win_shell – Execute shell commands on target hosts
    win_shortcut – Manage shortcuts on Windows
    win_stat – Get information about Windows files
    win_tempfile – Creates temporary files and directories
    win_template – Templates a file out to a remote server
    win_timezone – Sets Windows machine timezone
    win_toast – Sends Toast windows notification to logged in users on Windows 10 or later hosts
    win_unzip – Unzips compressed files and archives on the Windows node
    win_updates – Download and install Windows updates
    win_uri – Interacts with webservices
    win_user – Manages local Windows user accounts
    win_user_right – Manage Windows User Rights
    win_wait_for – Waits for a condition before continuing
    win_wait_for_process – Waits for a process to exist or not exist before continuing.
    win_wakeonlan – Send a magic Wake-on-LAN (WoL) broadcast packet
    win_webpicmd – Installs packages using Web Platform Installer command-line
    win_whoami – Get information about the current user and process
    win_xml – Add XML fragment to an XML parent
###Messaging modules
    rabbitmq_binding – This module manages rabbitMQ bindings
    rabbitmq_exchange – This module manages rabbitMQ exchanges
    rabbitmq_parameter – Adds or removes parameters to RabbitMQ
    rabbitmq_plugin – Manage RabbitMQ plugins
    rabbitmq_policy – Manage the state of policies in RabbitMQ.
    rabbitmq_queue – This module manages rabbitMQ queues
    rabbitmq_user – Adds or removes users to RabbitMQ
    rabbitmq_vhost – Manage the state of a virtual host in RabbitMQ
###Inventory modules
    add_host – add a host (and alternatively a group) to the ansible-playbook in-memory inventory
    group_by – Create Ansible groups based on facts
###Identity modules
    onepassword_facts – Fetch facts from 1Password items
###Identity modules - Cyberark
    cyberark_authentication – Module for CyberArk Vault Authentication using PAS Web Services SDK
    cyberark_user – Module for CyberArk User Management using PAS Web Services SDK
###Identity modules - Ipa
    ipa_config – Manage Global FreeIPA Configuration Settings
    ipa_dnsrecord – Manage FreeIPA DNS records
    ipa_dnszone – Manage FreeIPA DNS Zones
    ipa_group – Manage FreeIPA group
    ipa_hbacrule – Manage FreeIPA HBAC rule
    ipa_host – Manage FreeIPA host
    ipa_hostgroup – Manage FreeIPA host-group
    ipa_role – Manage FreeIPA role
    ipa_service – Manage FreeIPA service
    ipa_subca – Manage FreeIPA Lightweight Sub Certificate Authorities.
    ipa_sudocmd – Manage FreeIPA sudo command
    ipa_sudocmdgroup – Manage FreeIPA sudo command group
    ipa_sudorule – Manage FreeIPA sudo rule
    ipa_user – Manage FreeIPA users
    ipa_vault – Manage FreeIPA vaults
###Identity modules - Keycloak
    keycloak_client – Allows administration of Keycloak clients via Keycloak API
    keycloak_clienttemplate – Allows administration of Keycloak client templates via Keycloak API
###Identity modules - Opendj
    opendj_backendprop – Will update the backend configuration of OpenDJ via the dsconfig set-backend-prop command.
###Crypto modules
    certificate_complete_chain – Complete certificate chain given a set of untrusted and root certificates
    openssl_certificate – Generate and/or check OpenSSL certificates
    openssl_csr – Generate OpenSSL Certificate Signing Request (CSR)
    openssl_dhparam – Generate OpenSSL Diffie-Hellman Parameters
    openssl_pkcs12 – Generate OpenSSL PKCS#12 archive.
    openssl_privatekey – Generate OpenSSL private keys.
    openssl_publickey – Generate an OpenSSL public key from its private key.
###Acme
    acme_account – Create, modify or delete ACME accounts
    acme_account_facts – Retrieves information on ACME accounts
    acme_certificate – Create SSL/TLS certificates with the ACME protocol
    acme_certificate_revoke – Revoke certificates with the ACME protocol
    acme_challenge_cert_helper – Prepare certificates required for ACME challenges such as tls-alpn-01
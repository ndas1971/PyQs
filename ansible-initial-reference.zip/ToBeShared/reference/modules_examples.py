###command – Executes a command on a remote node
#The command module takes the command name followed by a list of space-delimited arguments.
#The given command will be executed on all selected nodes. 
#It will not be processed through the shell, so variables like $HOME and operations like "<", ">", "|", ";" and "&" will not work (use the shell module if you need these features).
#For Windows targets, use the win_command module instead.
#For rebooting systems, use the reboot or win_reboot module
Parameters
    argv
        Allows the user to provide the command as a list vs. a string. 
        Only the string or the list form can be provided, not both. 
        One or the other must be provided.
    chdir
        Change into this directory before running the command.
    creates
        A filename or (since 2.0) glob pattern. If it already exists, this step won't be run.
    free_form
        required
        The command module takes a free form command to run. 
        There is no parameter actually named 'free form'. 
    removes
        A filename or (since 2.0) glob pattern. If it already exists, this step will be run.
    stdin
        Set the stdin of the command directly to the specified value.
    warn
        boolean
        Choices:
        no
        yes (default)
        If command_warnings are on in ansible.cfg, do not warn about this particular line if set to no.

##Examples - command
- name: return motd to registered var
  command: cat /etc/motd
  register: mymotd
  
- name: Run the command if the specified file does not exist.
  command: /usr/bin/make_database.sh arg1 arg2
  args:
    creates: /path/to/database
    
# You can also use the 'args' form to provide the options.
- name: This command will change the working directory to somedir/ and will only run when /path/to/database doesn't exist.
  command: /usr/bin/make_database.sh arg1 arg2
  args:
    chdir: somedir/
    creates: /path/to/database
    
- name: use argv to send the command as a list.  Be sure to leave command empty
  command:
  args:
    argv:
      - echo
      - testing
      
- name: safely use templated variable to run command. Always use the quote filter to avoid injection issues.
  command: cat {{ myfile|quote }}
  register: myoutput
  
##Return Values
#Key 	
cmd
    list
    always 	
    the cmd that was run on the remote machine
    Sample:
    ['echo', 'hello']
delta
    string
    always 	
    cmd end time - cmd start time
    Sample:
    0.001529
end
    string
    always 	
    cmd end time
    Sample:
    2017-09-29 22:03:48.084657
start
    string
    always 	
    cmd start time
    Sample:
    2017-09-29 22:03:48.083128
    
    
###expect – Executes a command and responds to prompts.
#The expect module executes a command and responds to prompts.
#The given command will be executed on all selected nodes. It will not be processed through the shell, so variables like $HOME and operations like "<", ">", "|", and "&" will not work.
Parameter 	
    chdir
        Change into this directory before running the command.
    command
        required
        The command module takes command to run.
    creates
        A filename, when it already exists, this step will not be run.
    echo
        Default:no
        Whether or not to echo out your response strings.
    removes
        A filename, when it does not exist, this step will not be run.
    responses
        required
        Mapping of expected string/regex and string to respond with. 
        If the response is a list, successive matches return successive responses. 
    timeout
        Default:30
        Amount of time in seconds to wait for the expected strings. 
        Use null to disable timeout.

#If you want to run a command through the shell (say you are using <, >, |, etc), 
#you must specify a shell in the command such as /bin/bash c "/path/to/something | grep else".

#The question, or key, under responses is a python regex match. 
#Case insensitive searches are indicated with a prefix of ?i.

#By default, if a question is encountered multiple times, its string response will be repeated. 
#If you need different responses for successive question matches, 
#instead of a string response, use a list of strings as the response. 

#The expect module is designed for simple scenarios. 
#For more complex needs, consider the use of expect code with the shell or script modules. 


    
##Examples - expect 
- name: Case insensitive password string match
  expect:
    command: passwd username
    responses:
      (?i)password: "MySekretPa$$word"
  # you don't want to show passwords in your logs
  no_log: true

- name: Generic question with multiple different responses
  expect:
    command: /path/to/custom/command
    responses:
      Question:
        - response1
        - response2
        - response3
    
    
###raw – Executes a lowdown and dirty SSH command
#Executes a lowdown and dirty SSH command, not going through the module subsystem. 
#A common case is installing python on a system without python installed by default. 
#Standard output, error output and return code are returned when available. 
#This module does not require python on the remote system, much like the script module.
#This module is also supported for Windows targets.

Parameter 	
    executable
        change the shell used to execute the command. 
        Should be an absolute path to the executable.
        when using privilege escalation (become), a default shell will be assigned if one is not provided as privilege escalation requires a shell.
    free_form
        required
        the raw module takes a free form command to run. There is no parameter actually named 'free form'; see the examples!


##Examples - raw 
- name: Bootstrap a host without python2 installed
  raw: dnf install -y python2 python2-dnf libselinux-python

- name: Run a command that uses non-posix shell-isms (in this example /bin/sh doesn't handle redirection and wildcards together but bash does)
  raw: cat < /tmp/*txt
  args:
    executable: /bin/bash

- name: safely use templated variables. Always use quote filter to avoid injection issues.
  raw: "{{package_mgr|quote}} {{pkg_flags|quote}} install {{python|quote}}"
  
  
  
###script – Runs a local script on a remote node after transferring it
# The script module takes the script name followed by a list of spacedelimited arguments.
# The local script at path will be transferred to the remote node and then executed.
# The given script will be processed through the shell environment on the remote node.
# This module does not require python on the remote system, much like the raw module.
# This module is also supported for Windows targets.
    
Parameter 
    chdir
        Change into this directory on the remote node before running the script.
    creates
        A filename on the remote node, when it already exists, this step will not be run.
    decrypt
        boolean
            Choices:
            no
            yes (default)
        This option controls the autodecryption of source files using vault.
    executable
        Name or path of a executable to invoke the script with.
    free_form
        required
        Path to the local script file followed by optional arguments.
        There is no parameter actually named 'free form'
    removes
        A filename on the remote node, when it does not exist, this step will not be run.

##Examples - script 
- name: Run a script with arguments
  script: /some/local/script.sh --some-argument 1234

- name: Run a script only if file.txt does not exist on the remote node
  script: /some/local/create_file.sh --some-argument 1234
  args:
    creates: /the/created/file.txt

- name: Run a script only if file.txt exists on the remote node
  script: /some/local/remove_file.sh --some-argument 1234
  args:
    removes: /the/removed/file.txt

- name: Run a script using an executable in a non-system path
  script: /some/local/script
  args:
    executable: /some/remote/executable

- name: Run a script using an executable in a system path
  script: /some/local/script.py
  args:
    executable: python3
    
    
    
###shell – Execute commands in nodes.
#The shell module takes the command name followed by a list of spacedelimited arguments. It is almost exactly like the command module but runs the command through a shell (/bin/sh) on the remote node.
#For Windows targets, use the win_shell module instead.

Parameter 
chdir
    cd into this directory before running the command
creates
    a filename, when it already exists, this step will not be run.
executable
    change the shell used to execute the command. Should be an absolute path to the executable.
free_form
    required
    The shell module takes a free form command to run, as a string. 
    There's not an actual option named "free form". 
removes
    a filename, when it does not exist, this step will not be run.
stdin
    Set the stdin of the command directly to the specified value.
warn
    boolean
        Choices:
        no
        yes (default)
    if command warnings are on in ansible.cfg, do not warn about this particular line if set to no/false.

#To sanitize any variables passed to the shell module, you should use "{{ var | quote }}" instead of just "{{ var }}" 


##Examples - shell
- name: Execute the command in remote shell; stdout goes to the specified file on the remote.
  shell: somescript.sh >> somelog.txt

- name: Change the working directory to somedir/ before executing the command.
  shell: somescript.sh >> somelog.txt
  args:
    chdir: somedir/

# You can also use the 'args' form to provide the options.
- name: This command will change the working directory to somedir/ and will only run when somedir/somelog.txt doesn't exist.
  shell: somescript.sh >> somelog.txt
  args:
    chdir: somedir/
    creates: somelog.txt

- name: Run a command that uses non-posix shell-isms (in this example /bin/sh doesn't handle redirection and wildcards together but bash does)
  shell: cat < /tmp/*txt
  args:
    executable: /bin/bash

- name: Run a command using a templated variable (always use quote filter to avoid injection)
  shell: cat {{ myfile|quote }}

# You can use shell to run other executables to perform actions inline
- name: Run expect to wait for a successful PXE boot via out-of-band CIMC
  shell: |
    set timeout 300
    spawn ssh admin@{{ cimc_host }}

    expect "password:"
    send "{{ cimc_password }}\n"

    expect "\n{{ cimc_name }}"
    send "connect host\n"

    expect "pxeboot.n12"
    send "\n"

    exit 0
  args:
    executable: /usr/bin/expect
  delegate_to: localhost

# Disabling warnings
- name: Using curl to connect to a host via SOCKS proxy (unsupported in uri). Ordinarily this would throw a warning.
  shell: curl --socks5 localhost:9000 http://www.ansible.com
  args:
    warn: False
    
   
   
###telnet – Executes a lowdown and dirty telnet command
#Executes a lowdown and dirty telnet command, not going through the module subsystem.
#This is mostly to be used for enabling ssh on devices that only have telnet enabled by default.
#The environment keyword does not work with this task
Parameter 	
    command
        required
        List of commands to be executed in the telnet session.
        aliases: commands
    host
        Default:remote_addr
        The host/target on which to execute the command
    login_prompt
        Default: login:
        Login or username prompt to expect
    password
        The password for login
    password_prompt
        Default: Password:
        Login or username prompt to expect
    pause
        Default:1
        Seconds to pause between each command issued
    port
        Default:23
        Remote port to use
    prompts
        Default:[u'$']
        List of prompts expected before sending next command
    send_newline
        boolean
            Choices:
            no (default)
            yes
        Sends a newline character upon successful connection to start the terminal session.
    timeout
        Default:120
        timeout for remote operations
    user
        Default:remote_user
        The user for login

    
##Examples - telnet 
- name: send configuration commands to IOS
  telnet:
    user: cisco
    password: cisco
    login_prompt: "Username: "
    prompts:
      - "[>|#]"
    command:
      - terminal length 0
      - configure terminal
      - hostname ios01

- name: run show commands
  telnet:
    user: cisco
    password: cisco
    login_prompt: "Username: "
    prompts:
      - "[>|#]"
    command:
      - terminal length 0
      - show version
      
      
      
###copy – Copies files to remote locations
# The copy module copies a file from the local or remote machine to a location on the remote machine. Use the fetch module to copy files from remote locations to the local box. If you need variable interpolation in copied files, use the template module.
# For Windows targets, use the win_copy module instead.
#The copy module recursively copy facility does not scale to lots (>hundreds) of files. 
#For alternative, see synchronize module, which is a wrapper around rsync.
Parameter 	
    attributes
        Attributes the file or directory should have. 
        To get supported flags look at the man page for chattr on the target system. 
        This string should contain the attributes in the same order as the one displayed by lsattr.
        = operator is assumed as default, otherwise + or  operators need to be included in the string.
        aliases: attr
    backup
        boolean
            Choices:
            no (default)
            yes
        Create a backup file including the timestamp information so you can get the original file back 
        if you somehow clobbered it incorrectly.
    checksum
        SHA1 checksum of the file being transferred. 
        Used to validate that the copy of the file was successful.
        If this is not provided, ansible will use the local calculated checksum of the src file.
    content
        When used instead of src, sets the contents of a file directly to the specified value. 
        For anything advanced or with formatting also look at the template module.
    decrypt
        boolean
            Choices:
            no
            yes (default)
        This option controls the autodecryption of source files using vault.
    dest
        required
        Remote absolute path where the file should be copied to. 
        If src is a directory, this must be a directory too. 
        If dest is a nonexistent path and if either dest ends with "/" or src is a directory, dest is created. 
        If src and dest are files, the parent directory of dest isnot created: 
        the task fails if it doesn't already exist.
    directory_mode
        When doing a recursive copy set the mode for the directories. 
        If this is not set we will use the system defaults. 
        The mode is only set on directories which are newly created, 
        and will not affect those that already existed.
    follow
        boolean
            Choices:
            no (default)
            yes
        This flag indicates that filesystem links in the destination, if they exist, 
        should be followed.
    force
        boolean
            Choices:
            no
            yes (default)
        the default is yes, which will replace the remote file when contents are different than the source. 
        If no, the file will only be transferred if the destination does not exist.
        aliases: thirsty
    group
        Name of the group that should own the file/directory, as would be fed to chown.
    local_follow
        boolean
            Choices:
            no
            yes (default)
        This flag indicates that filesystem links in the source tree, 
        if they exist, should be followed.
    mode
        Mode the file or directory should be. 
        For those used to /usr/bin/chmod remember that modes are actually octal numbers. 
        You must either add a leading zero so that Ansible YAML parser knows it is an octal number 
        (like 0644 or 01777) or quote it (like '644' or '1777') 
        so Ansible receives a string and can do its own conversion from string into number. 
        Giving Ansible a number without following one of these rules will end up 
        with a decimal number which will have unexpected results. 
        The mode may be specified as a symbolic mode (for example, u+rwx or u=rw,g=r,o=r). 
        The mode may also be the special string preserve. 
        preserve means that the file will be given the same permissions as the source file.
    owner
        Name of the user that should own the file/directory, as would be fed to chown.
    remote_src
        boolean
            Choices:
            no (default)
            yes
        If no, it will search for src at originating/master machine.
        If yes it will go to the remote/target machine for the src. Default is no.
        Currently remote_src does not support recursive copying.
        remote_src only works with mode=preserve as of version 2.6.
    selevel
        Default:s0
        Level part of the SELinux file context. 
        This is the MLS/MCS attribute, sometimes known as the range. _default feature works as for seuser.
    serole
        Role part of SELinux file context, _default feature works as for seuser.
    setype
        Type part of SELinux file context, _default feature works as for seuser.
    seuser
        User part of SELinux file context. Will default to system policy, if applicable. If set to _default, it will use the user portion of the policy if available.
    src
        Local path to a file to copy to the remote server; can be absolute or relative. 
        If path is a directory, it is copied recursively. 
        In this case, if path ends with "/", only inside contents of that directory are copied to destination. 
        Otherwise, if it does not end with "/", the directory itself with all contents is copied. 
        This behavior is similar to Rsync.
    unsafe_writes
        boolean
            Choices:
            no (default)
            yes
        By default this module uses atomic operations to prevent data corruption or inconsistent reads from the target files, but sometimes systems are configured or just broken in ways that prevent this. One example is docker mounted files, which cannot be updated atomically from inside the container and can only be written in an unsafe manner.
        This option allows Ansible to fall back to unsafe methods of updating files 
        when atomic operations fail (however, it doesn't force Ansible to perform unsafe writes). 
        IMPORTANT! Unsafe writes are subject to race conditions and can lead to data corruption.
    validate
        The validation command to run before copying into place. The path to the file to validate is passed in via '%s' which must be present as in the example below. The command is passed securely so shell features like expansion and pipes won't work.


##Examples - copy 
- name: example copying file with owner and permissions
  copy:
    src: /srv/myfiles/foo.conf
    dest: /etc/foo.conf
    owner: foo
    group: foo
    mode: 0644

- name: The same example as above, but using a symbolic mode equivalent to 0644
  copy:
    src: /srv/myfiles/foo.conf
    dest: /etc/foo.conf
    owner: foo
    group: foo
    mode: u=rw,g=r,o=r

- name: Another symbolic mode example, adding some permissions and removing others
  copy:
    src: /srv/myfiles/foo.conf
    dest: /etc/foo.conf
    owner: foo
    group: foo
    mode: u+rw,g-wx,o-rwx

- name: Copy a new "ntp.conf file into place, backing up the original if it differs from the copied version
  copy:
    src: /mine/ntp.conf
    dest: /etc/ntp.conf
    owner: root
    group: root
    mode: 0644
    backup: yes

- name: Copy a new "sudoers" file into place, after passing validation with visudo
  copy:
    src: /mine/sudoers
    dest: /etc/sudoers
    validate: /usr/sbin/visudo -cf %s

- name: Copy a "sudoers" file on the remote machine for editing
  copy:
    src: /etc/sudoers
    dest: /etc/sudoers.edit
    remote_src: yes
    validate: /usr/sbin/visudo -cf %s

- name: Copy using the 'content' for inline data
  copy:
    content: '# This file was moved to /etc/other.conf'
    dest: /etc/mine.conf
    

###fetch – Fetches a file from remote nodes
# This module works like copy, but in reverse. 
# It is used for fetching files from remote machines and storing them locally in a file tree, organized by hostname.
# its always append 
# it is advisable to run this module without become whenever possible.
# This module is also supported for Windows targets.

Parameter 
    dest
        required
        A directory to save the file into. 
        For example, if the dest directory is /backup a src file named /etc/profile on host host.example.com, 
        would be saved into /backup/host.example.com/etc/profile
    fail_on_missing
        boolean
            Choices:
            no
            yes (default)
        When set to 'yes', the task will fail if the remote file cannot be read for any reason. 
        Prior to Ansible2.5, setting this would only fail if the source file was missing.
    flat
        boolean
            Choices:
            no (default)
            yes
        Allows you to override the default behavior of appending hostname/path/to/file to the destination. 
        If dest ends with '/', it will use the basename of the source file, similar to the copy module. 
        Obviously this is only handy if the filenames are unique.
    src
        required
        The file on the remote system to fetch. 
        This must be a file, not a directory. 
        Recursive fetching may be supported in a later release.
    validate_checksum
        boolean
            Choices:
            no
            yes (default)
        Verify that the source and destination checksums match after the files are fetched.
        aliases: validate_md5



##Examples - fetch
# Store file into /tmp/fetched/host.example.com/tmp/somefile
- fetch:
    src: /tmp/somefile
    dest: /tmp/fetched

# Specifying a path directly
- fetch:
    src: /tmp/somefile
    dest: /tmp/prefix-{{ inventory_hostname }}
    flat: yes

# Specifying a destination path
- fetch:
    src: /tmp/uniquefile
    dest: /tmp/special/
    flat: yes

# Storing in a path relative to the playbook
- fetch:
    src: /tmp/uniquefile
    dest: special/prefix-{{ inventory_hostname }}
    flat: yes


###file – Sets attributes of files
# Sets attributes of files, symlinks, and directories, or removes files/symlinks/directories. Many other modules support the same options as the file module  including copy, template, and assemble.
# For Windows targets, use the win_file module instead.
Parameter 	
    access_time
        This parameter indicates the time the file's access time should be set to
        Should be preserve when no modification is required, YYYYMMDDHHMM.SS when using default time format, or now
        Default is None meaning that preserve is the default for state=[file,directory,link,hard] and now is default for state=touch
    access_time_format
        Default:%Y%m%d%H%M.%S
        When used with access_time, indicates the time format that must be used.
        Based on default Python format (see time.strftime doc)
    attributes
        Attributes the file or directory should have. To get supported flags look at the man page for chattr on the target system. This string should contain the attributes in the same order as the one displayed by lsattr.
        = operator is assumed as default, otherwise + or  operators need to be included in the string.
        aliases: attr
    follow
        boolean
            Choices:
            no
            yes (default)
        This flag indicates that filesystem links, if they exist, should be followed.
    force
        boolean
            Choices:
            no (default)
            yes
        force the creation of the symlinks in two cases: the source file does not exist (but will appear later); the destination exists and is a file (so, we need to unlink the "path" file and create symlink to the "src" file in place of it).
    group
        Name of the group that should own the file/directory, as would be fed to chown.
    mode
        Mode the file or directory should be. For those used to /usr/bin/chmod remember that modes are actually octal numbers. You must either add a leading zero so that Ansible's YAML parser knows it is an octal number (like 0644 or 01777) or quote it (like '644' or '1777') so Ansible receives a string and can do its own conversion from string into number. Giving Ansible a number without following one of these rules will end up with a decimal number which will have unexpected results. As of version 1.8, the mode may be specified as a symbolic mode (for example, u+rwx or u=rw,g=r,o=r).
    modification_time
        This parameter indicates the time the file's modification time should be set to
        Should be preserve when no modification is required, YYYYMMDDHHMM.SS when using default time format, or now
        Default is None meaning that preserve is the default for state=[file,directory,link,hard] and now is default for state=touch
    modification_time_format
        Default:%Y%m%d%H%M.%S
        When used with modification_time, indicates the time format that must be used.
        Based on default Python format 
    owner
        Name of the user that should own the file/directory, as would be fed to chown.          
    path
        required
        Path to the file being managed.
        aliases: dest, name
    recurse
        boolean
            Choices:
            no (default)
            yes
        recursively set the specified file attributes (applies only to directories)
    selevel
        Default:s0
        Level part of the SELinux file context. This is the MLS/MCS attribute, sometimes known as the range. _default feature works as for seuser.
    serole
        Role part of SELinux file context, _default feature works as for seuser.
    setype
        Type part of SELinux file context, _default feature works as for seuser.
    seuser
        User part of SELinux file context. Will default to system policy, if applicable. If set to _default, it will use the user portion of the policy if available.
    src
        path of the file to link to (applies only to state=link and state=hard). Will accept absolute, relative and nonexisting paths. Relative paths are relative to the file being created (path) which is how the UNIX command ln s SRC DEST treats relative paths.
    state
            Choices:
            absent
            directory
            file (default)
            hard
            link
            touch
        If directory, all intermediate subdirectories will be created if they do not exist. 
        Since Ansible 1.7 they will be created with the supplied permissions. If file, the file will NOT be created if it does not exist; see the touch value or the copy or template module if you want that behavior. If link, the symbolic link will be created or changed. Use hard for hardlinks. If absent, directories will be recursively deleted, and files or symlinks will be unlinked. Note that absent will not cause file to fail if the path does not exist as the state did not change. If touch (new in 1.4), an empty file will be created if the path does not exist, while an existing file or directory will receive updated file access and modification times (similar to the way `touch` works from the command line).
    unsafe_writes
        boolean
            Choices:
            no (default)
            yes
        By default this module uses atomic operations to prevent data corruption or inconsistent reads from the target files, but sometimes systems are configured or just broken in ways that prevent this. One example is docker mounted files, which cannot be updated atomically from inside the container and can only be written in an unsafe manner.
        This option allows Ansible to fall back to unsafe methods of updating files when atomic operations fail (however, it doesn't force Ansible to perform unsafe writes). IMPORTANT! Unsafe writes are subject to race conditions and can lead to data corruption.


##Examples - file
# change file ownership, group and mode
- file:
    path: /etc/foo.conf
    owner: foo
    group: foo
    # when specifying mode using octal numbers, add a leading 0
    mode: 0644
- file:
    path: /work
    owner: root
    group: root
    mode: 01777
- file:
    src: /file/to/link/to
    dest: /path/to/symlink
    owner: foo
    group: foo
    state: link
- file:
    src: '/tmp/{{ item.src }}'
    dest: '{{ item.dest }}'
    state: link
  with_items:
    - { src: 'x', dest: 'y' }
    - { src: 'z', dest: 'k' }

# touch a file, using symbolic modes to set the permissions (equivalent to 0644)
- file:
    path: /etc/foo.conf
    state: touch
    mode: "u=rw,g=r,o=r"

# touch the same file, but add/remove some permissions
- file:
    path: /etc/foo.conf
    state: touch
    mode: "u+rw,g-wx,o-rwx"

# touch again the same file, but dont change times
# this makes the task idempotents
- file:
    path: /etc/foo.conf
    state: touch
    mode: "u+rw,g-wx,o-rwx"
    modification_time: "preserve"
    access_time: "preserve"

# create a directory if it doesn't exist
- file:
    path: /etc/some_directory
    state: directory
    mode: 0755

# updates modification and access time of given file
- file:
    path: /etc/some_file
    state: file
    mode: 0755
    modification_time: now
    access_time: now


###find – Return a list of files based on specific criteria
    
# Return a list of files based on specific criteria. Multiple criteria are AND’d together.
# For Windows targets, use the win_find module instead.
Parameter 	
    age
        Select files whose age is equal to or greater than the specified time. 
        Use a negative age to find files equal to or less than the specified time. 
        You can choose seconds, minutes, hours, days, or weeks by specifying the first letter of any of those words (e.g., "1w").
    age_stamp
            Choices:
            atime
            ctime
            mtime (default)
        Choose the file property against which we compare age.
    contains
        One or more regex patterns which should be matched against the file content.
    depth
        Set the maximum number of levels to decend into. Setting recurse to false will override this value, which is effectively depth 1. Default is unlimited depth.
    excludes
        One or more (shell or regex) patterns, which type is controlled by use_regex option.
        Items matching an excludes pattern are culled from patterns matches. Multiple patterns can be specified using a list.
        aliases: exclude
    file_type
            Choices:
            any
            directory
            file (default)
            link
        Type of file to select.
    follow
        boolean
            Choices:
            no (default)
            yes
        Set this to true to follow symlinks in path for systems with python 2.6+.
    get_checksum
        boolean
            Choices:
            no (default)
            yes
        Set this to true to retrieve a file's sha1 checksum.
    hidden
        boolean
            Choices:
            no (default)
            yes
        Set this to true to include hidden files, otherwise they'll be ignored.
    paths
        required
        List of paths of directories to search. All paths must be fully qualified.
        aliases: name, path
    patterns
        Default:*
        One or more (shell or regex) patterns, which type is controlled by use_regex option.
        The patterns restrict the list of files to be returned to those whose basenames match at least one of the patterns specified. Multiple patterns can be specified using a list.
        aliases: pattern
    recurse
        boolean
            Choices:
            no (default)
            yes
        If target is a directory, recursively descend into the directory looking for files.
    size
        Select files whose size is equal to or greater than the specified size. Use a negative size to find files equal to or less than the specified size. Unqualified values are in bytes but b, k, m, g, and t can be appended to specify bytes, kilobytes, megabytes, gigabytes, and terabytes, respectively. Size is not evaluated for directories.
    use_regex
        boolean
            Choices:
            no (default)
            yes
        If false, the patterns are file globs (shell). If true, they are python regexes.

##Examples - find 
- name: Recursively find /tmp files older than 2 days
  find:
    paths: /tmp
    age: 2d
    recurse: yes

- name: Recursively find /tmp files older than 4 weeks and equal or greater than 1 megabyte
  find:
    paths: /tmp
    age: 4w
    size: 1m
    recurse: yes

- name: Recursively find /var/tmp files with last access time greater than 3600 seconds
  find:
    paths: /var/tmp
    age: 3600
    age_stamp: atime
    recurse: yes

- name: Find /var/log files equal or greater than 10 megabytes ending with .old or .log.gz
  find:
    paths: /var/log
    patterns: '*.old,*.log.gz'
    size: 10m

# Note that YAML double quotes require escaping backslashes but yaml single quotes do not.
- name: Find /var/log files equal or greater than 10 megabytes ending with .old or .log.gz via regex
  find:
    paths: /var/log
    patterns: "^.*?\\.(?:old|log\\.gz)$"
    size: 10m
    use_regex: yes

- name: Find /var/log all directories, exclude nginx and mysql
  find:
    paths: /var/log
    recurse: no
    file_type: directory
    excludes: 'nginx,mysql'

    
###replace – Replace all instances of a particular string in a file using a backreferenced regular expression.
# This module will replace all instances of a pattern within a file.
# It is up to the user to maintain idempotence by ensuring that the same pattern would never match any replacements made.

Parameter 
    after
        If specified, the line after the replace/remove will start. Can be used in combination with before. Uses Python regular expressions; see http://docs.python.org/2/library/re.html.
    attributes
        Attributes the file or directory should have. To get supported flags look at the man page for chattr on the target system. This string should contain the attributes in the same order as the one displayed by lsattr.
        = operator is assumed as default, otherwise + or  operators need to be included in the string.
        aliases: attr
    backup
        boolean
            Choices:
            no (default)
            yes
        Create a backup file including the timestamp information so you can get the original file back if you somehow clobbered it incorrectly.
    before
        If specified, the line before the replace/remove will occur. Can be used in combination with after. Uses Python regular expressions; see http://docs.python.org/2/library/re.html.
    encoding
        Default:utf8
        The character encoding for reading and writing the file.
    group
        Name of the group that should own the file/directory, as would be fed to chown.
    mode
        Mode the file or directory should be. For those used to /usr/bin/chmod remember that modes are actually octal numbers. You must either add a leading zero so that Ansible's YAML parser knows it is an octal number (like 0644 or 01777) or quote it (like '644' or '1777') so Ansible receives a string and can do its own conversion from string into number. Giving Ansible a number without following one of these rules will end up with a decimal number which will have unexpected results. As of version 1.8, the mode may be specified as a symbolic mode (for example, u+rwx or u=rw,g=r,o=r).
    others
        All arguments accepted by the file module also work here.
    owner
        Name of the user that should own the file/directory, as would be fed to chown.
    path
        required
        The file to modify.
        Before 2.3 this option was only usable as dest, destfile and name.
        aliases: dest, destfile, name
    regexp
        required
        The regular expression to look for in the contents of the file. Uses Python regular expressions; see http://docs.python.org/2/library/re.html. Uses MULTILINE mode, which means ^ and $ match the beginning and end of the file, as well as the beginning and end respectively of each line of the file.
        Does not use DOTALL, which means the . special character matches any character except newlines. A common mistake is to assume that a negated character set like [^#] will also not match newlines. In order to exclude newlines, they must be added to the set like [^#\n].
        Note that, as of ansible 2, short form tasks should have any escape sequences backslashescaped in order to prevent them being parsed as string literal escapes. See the examples.
    replace
        The string to replace regexp matches. 
        May contain backreferences that will get expanded with the regexp capture groups if the regexp matches. If not set, matches are removed entirely.
    selevel
        Default:s0
        Level part of the SELinux file context. This is the MLS/MCS attribute, sometimes known as the range. _default feature works as for seuser.
    serole
        Role part of SELinux file context, _default feature works as for seuser.
    setype
        Type part of SELinux file context, _default feature works as for seuser.
    seuser
        User part of SELinux file context. Will default to system policy, if applicable. If set to _default, it will use the user portion of the policy if available.
    unsafe_writes
        boolean
            Choices:
            no (default)
            yes
        By default this module uses atomic operations to prevent data corruption or inconsistent reads from the target files, but sometimes systems are configured or just broken in ways that prevent this. One example is docker mounted files, which cannot be updated atomically from inside the container and can only be written in an unsafe manner.
        This option allows Ansible to fall back to unsafe methods of updating files when atomic operations fail (however, it doesn't force Ansible to perform unsafe writes). IMPORTANT! Unsafe writes are subject to race conditions and can lead to data corruption.
    validate
        The validation command to run before copying into place. 
        The path to the file to validate is passed in via '%s' which must be present as in the example below. 
        The command is passed securely so shell features like expansion and pipes won't work.

##Examples - replace 
# Before 2.3, option 'dest', 'destfile' or 'name' was used instead of 'path'
- replace:
    path: /etc/hosts
    regexp: '(\s+)old\.host\.name(\s+.*)?$'
    replace: '\1new.host.name\2'
    backup: yes

# Replace after the expression till the end of the file (requires >=2.4)
- replace:
    path: /etc/hosts
    regexp: '(\s+)old\.host\.name(\s+.*)?$'
    replace: '\1new.host.name\2'
    after: 'Start after line.*'
    backup: yes

# Replace before the expression till the begin of the file (requires >=2.4)
- replace:
    path: /etc/hosts
    regexp: '(\s+)old\.host\.name(\s+.*)?$'
    replace: '\1new.host.name\2'
    before: 'Start before line.*'
    backup: yes

# Replace between the expressions (requires >=2.4)
- replace:
    path: /etc/hosts
    regexp: '(\s+)old\.host\.name(\s+.*)?$'
    replace: '\1new.host.name\2'
    after: 'Start after line.*'
    before: 'Start before line.*'
    backup: yes

- replace:
    path: /home/jdoe/.ssh/known_hosts
    regexp: '^old\.host\.name[^\n]*\n'
    owner: jdoe
    group: jdoe
    mode: 0644

- replace:
    path: /etc/apache/ports
    regexp: '^(NameVirtualHost|Listen)\s+80\s*$'
    replace: '\1 127.0.0.1:8080'
    validate: '/usr/sbin/apache2ctl -f %s -t'

- name: short form task (in ansible 2+) necessitates backslash-escaped sequences
  replace: dest=/etc/hosts regexp='\\b(localhost)(\\d*)\\b' replace='\\1\\2.localdomain\\2 \\1\\2'

- name: long form task does not
  replace:
    dest: /etc/hosts
    regexp: '\b(localhost)(\d*)\b'
    replace: '\1\2.localdomain\2 \1\2'


###stat – Retrieve file or file system 
# Retrieves facts for a file similar to the linux/unix ‘stat’ command.
# For Windows targets, use the win_stat module instead.

Parameter 	
    checksum_algorithm
            Choices:
            md5
            sha1 (default)
            sha224
            sha256
            sha384
            sha512
        Algorithm to determine checksum of file. Will throw an error if the host is unable to use specified algorithm.
        The remote host has to support the hashing method specified, md5 can be unavailable if the host is FIPS140 compliant.
        aliases: checksum, checksum_algo
    follow
        boolean
            Choices:
            no (default)
            yes
        Whether to follow symlinks.
    get_attributes
        boolean
            Choices:
            no
            yes (default)
        Get file attributes using lsattr tool if present.
        aliases: attr, attributes
    get_checksum
        boolean
            Choices:
            no
            yes (default)
        Whether to return a checksum of the file (default sha1).
    get_md5
        boolean
            Choices:
            no (default)
            yes
        Whether to return the md5 sum of the file.
        Will return None if not a regular file or if we're unable to use md5 (Common for FIPS140 compliant systems).
        The default of this option changed from yes to no in Ansible 2.5 and will be removed altogether in Ansible 2.9.
        Use get_checksum=true with checksum_algorithm=md5 to return an md5 hash under the checksum return value.
    get_mime
        boolean
            Choices:
            no
            yes (default)
        Use file magic and return data about the nature of the file. this uses the 'file' utility found on most Linux/Unix systems.
        This will add both `mime_type` and 'charset' fields to the return, if possible.
        In 2.3 this option changed from 'mime' to 'get_mime' and the default changed to 'Yes'.
        aliases: mime, mime_type, mimetype
    path
        required
        The full path of the file/object to get the facts of.


##Examples - stat
# Obtain the stats of /etc/foo.conf, and check that the file still belongs
# to 'root'. Fail otherwise.
- stat:
    path: /etc/foo.conf
  register: st
- fail:
    msg: "Whoops! file ownership has changed"
  when: st.stat.pw_name != 'root'

# Determine if a path exists and is a symlink. Note that if the path does
# not exist, and we test sym.stat.islnk, it will fail with an error. So
# therefore, we must test whether it is defined.
# Run this to understand the structure, the skipped ones do not pass the
# check performed by 'when'
- stat:
    path: /path/to/something
  register: sym

- debug:
    msg: "islnk isn't defined (path doesn't exist)"
  when: sym.stat.islnk is not defined

- debug:
    msg: "islnk is defined (path must exist)"
  when: sym.stat.islnk is defined

- debug:
    msg: "Path exists and is a symlink"
  when: sym.stat.islnk is defined and sym.stat.islnk

- debug:
    msg: "Path exists and isn't a symlink"
  when: sym.stat.islnk is defined and sym.stat.islnk == False


# Determine if a path exists and is a directory.  Note that we need to test
# both that p.stat.isdir actually exists, and also that it's set to true.
- stat:
    path: /path/to/something
  register: p
- debug:
    msg: "Path exists and is a directory"
  when: p.stat.isdir is defined and p.stat.isdir

# Don't do checksum
- stat:
    path: /path/to/myhugefile
    get_checksum: no

# Use sha256 to calculate checksum
- stat:
    path: /path/to/something
    checksum_algorithm: sha256


###tempfile – Creates temporary files and directories.
# The tempfile module creates temporary files and directories. mktemp command takes different  on various systems, this module helps to avoid troubles related to that. Files/directories created by module are accessible only by creator. In case you need to make them worldaccessible you need to use file module.
# For Windows targets, use the win_tempfile module instead.
Parameter 	
    path
        Location where temporary file or directory should be created. If path is not specified default system temporary directory will be used.
    prefix
        Default:ansible.
        Prefix of file/directory name created by module.
    state
            Choices:
            directory
            file (default)
        Whether to create file or directory.
    suffix
        Default:Suffix of file/directory name created by module.

##Examples - tempfile
- name: create temporary build directory
  tempfile:
    state: directory
    suffix: build

- name: create temporary file
  tempfile:
    state: file
    suffix: temp

    
###unarchive – Unpacks an archive after (optionally) copying it from the local machine.
# The unarchive module unpacks an archive.
# By default, it will copy the source file from the local system to the target before unpacking.
# Set remote_src=yes to unpack an archive which already exists on the target.
# For Windows targets, use the win_unzip module instead.
# If checksum validation is desired, use get_url or uri instead to fetch the file and set remote_src=yes.

# Requires gtar/unzip command on target host.
# Can handle .zip files using unzip as well as .tar, .tar.gz, .tar.bz2 and .tar.xz files using gtar.
# Uses gtar’s diff arg to calculate if changed or not. If this arg is not supported, it will always unpack the archive.
# Existing files/directories in the destination which are not in the archive are not touched. This is the same behavior as a normal archive extraction.
# Existing files/directories in the destination which are not in the archive are ignored for purposes of deciding if the archive should be unpacked or not.

Parameter 
    attributes
        Attributes the file or directory should have. To get supported flags look at the man page for chattr on the target system. This string should contain the attributes in the same order as the one displayed by lsattr.
        = operator is assumed as default, otherwise + or  operators need to be included in the string.
        aliases: attr
    copy
        boolean
            Choices:
            no
            yes (default)
        If true, the file is copied from local 'master' to the target machine, otherwise, the plugin will look for src archive at the target machine.
        This option has been deprecated in favor of remote_src.
        This option is mutually exclusive with remote_src.
    creates
        If the specified absolute path (file or directory) already exists, this step will not be run.
    decrypt
        boolean
            Choices:
            no
            yes (default)
        This option controls the autodecryption of source files using vault.
    dest
        required
        Remote absolute path where the archive should be unpacked.
    exclude
        List the directory and file entries that you would like to exclude from the unarchive action.
    extra_opts
        Default:Specify additional options by passing in an array.
    group
        Name of the group that should own the file/directory, as would be fed to chown.
    keep_newer
        boolean
            Choices:
            no (default)
            yes
        Do not replace existing files that are newer than files from the archive.
    list_files
        boolean
            Choices:
            no (default)
            yes
        If set to True, return the list of files that are contained in the tarball.
    mode
        Mode the file or directory should be. For those used to /usr/bin/chmod remember that modes are actually octal numbers. You must either add a leading zero so that Ansible's YAML parser knows it is an octal number (like 0644 or 01777) or quote it (like '644' or '1777') so Ansible receives a string and can do its own conversion from string into number. Giving Ansible a number without following one of these rules will end up with a decimal number which will have unexpected results. As of version 1.8, the mode may be specified as a symbolic mode (for example, u+rwx or u=rw,g=r,o=r).
    owner
        Name of the user that should own the file/directory, as would be fed to chown.
    remote_src
        boolean
            Choices:
            no (default)
            yes
        Set to yes to indicate the archived file is already on the remote system and not local to the Ansible controller.
        This option is mutually exclusive with copy.
    selevel
        Default:s0
        Level part of the SELinux file context. This is the MLS/MCS attribute, sometimes known as the range. _default feature works as for seuser.
    serole
        Role part of SELinux file context, _default feature works as for seuser.
    setype
        Type part of SELinux file context, _default feature works as for seuser.
    seuser
        User part of SELinux file context. Will default to system policy, if applicable. If set to _default, it will use the user portion of the policy if available.
    src
        required
        If remote_src=no (default), local path to archive file to copy to the target server; can be absolute or relative. If remote_src=yes, path on the target server to existing archive file to unpack.
        If remote_src=yes and src contains ://, the remote machine will download the file from the URL first. (version_added 2.0). This is only for simple cases, for full download support use the get_url module.
    unsafe_writes
        boolean
            Choices:
            no (default)
            yes
        By default this module uses atomic operations to prevent data corruption or inconsistent reads from the target files, but sometimes systems are configured or just broken in ways that prevent this. One example is docker mounted files, which cannot be updated atomically from inside the container and can only be written in an unsafe manner.
        This option allows Ansible to fall back to unsafe methods of updating files when atomic operations fail (however, it doesn't force Ansible to perform unsafe writes). IMPORTANT! Unsafe writes are subject to race conditions and can lead to data corruption.
    validate_certs
        boolean
            Choices:
            no
            yes (default)
        This only applies if using a https URL as the source of the file.
        This should only set to no used on personally controlled sites using selfsigned certificate.
        Prior to 2.2 the code worked as if this was set to yes.

##Examples - unarchive
- name: Extract foo.tgz into /var/lib/foo
  unarchive:
    src: foo.tgz
    dest: /var/lib/foo

- name: Unarchive a file that is already on the remote machine
  unarchive:
    src: /tmp/foo.zip
    dest: /usr/local/bin
    remote_src: yes

- name: Unarchive a file that needs to be downloaded (added in 2.0)
  unarchive:
    src: https://example.com/example.zip
    dest: /usr/local/bin
    remote_src: yes

- name: Unarchive a file with extra options
  unarchive:
    src: /tmp/foo.zip
    dest: /usr/local/bin
    extra_opts:
    - --transform
    - s/^xxx/yyy/


###archive – Creates a compressed archive of one or more files or trees
#Packs an archive. It is the opposite of unarchive. 
#By default, it assumes the compression source exists on the target. 
#It will not copy the source file from the local system to the target before archiving. 
#Source files can be deleted after archival by specifying remove=True.

# requires tarfile, zipfile, gzip and bzip2 packages on target host
# requires lzma or backports.lzma if using xz format
# can produce gzip, bzip2, lzma and zip compressed files or archives
    
Parameter 	
    attributes
        Attributes the file or directory should have. To get supported flags look at the man page for chattr on the target system. This string should contain the attributes in the same order as the one displayed by lsattr.
        = operator is assumed as default, otherwise + or  operators need to be included in the string.
        aliases: attr
    dest
        The file name of the destination archive. This is required when path refers to multiple files by either specifying a glob, a directory or multiple paths in a list.
    exclude_path
        Remote absolute path, glob, or list of paths or globs for the file or files to exclude from the archive
        format
            Choices:
            bz2
            gz (default)
            tar
            xz
            zip
        The type of compression to use.
    group
        Name of the group that should own the file/directory, as would be fed to chown.
    mode
        Mode the file or directory should be. For those used to /usr/bin/chmod remember that modes are actually octal numbers. You must either add a leading zero so that Ansible's YAML parser knows it is an octal number (like 0644 or 01777) or quote it (like '644' or '1777') so Ansible receives a string and can do its own conversion from string into number. Giving Ansible a number without following one of these rules will end up with a decimal number which will have unexpected results. As of version 1.8, the mode may be specified as a symbolic mode (for example, u+rwx or u=rw,g=r,o=r).
    owner
        Name of the user that should own the file/directory, as would be fed to chown.
    path
        required
        Remote absolute path, glob, or list of paths or globs for the file or files to compress or archive.
    remove
        boolean
            Choices:
            no (default)
            yes
        Remove any added source files and trees after adding to archive.
    selevel
        Default:s0
        Level part of the SELinux file context. This is the MLS/MCS attribute, sometimes known as the range. _default feature works as for seuser.
    serole
        Role part of SELinux file context, _default feature works as for seuser.
    setype
        Type part of SELinux file context, _default feature works as for seuser.
    seuser
        User part of SELinux file context. Will default to system policy, if applicable. If set to _default, it will use the user portion of the policy if available.
    unsafe_writes
        boolean
            Choices:
            no (default)
            yes
        By default this module uses atomic operations to prevent data corruption or inconsistent reads from the target files, but sometimes systems are configured or just broken in ways that prevent this. One example is docker mounted files, which cannot be updated atomically from inside the container and can only be written in an unsafe manner.
        This option allows Ansible to fall back to unsafe methods of updating files when atomic operations fail (however, it doesn't force Ansible to perform unsafe writes). IMPORTANT! Unsafe writes are subject to race conditions and can lead to data corruption.

##Examples - archive
- name: Compress directory /path/to/foo/ into /path/to/foo.tgz
  archive:
    path: /path/to/foo
    dest: /path/to/foo.tgz

- name: Compress regular file /path/to/foo into /path/to/foo.gz and remove it
  archive:
    path: /path/to/foo
    remove: yes

- name: Create a zip archive of /path/to/foo
  archive:
    path: /path/to/foo
    format: zip

- name: Create a bz2 archive of multiple files, rooted at /path
  archive:
    path:
    - /path/to/foo
    - /path/wong/foo
    dest: /path/file.tar.bz2
    format: bz2

- name: Create a bz2 archive of a globbed path, while excluding specific dirnames
  archive:
    path:
    - /path/to/foo/*
    dest: /path/file.tar.bz2
    exclude_path:
    - /path/to/foo/bar
    - /path/to/foo/baz
    format: bz2

- name: Create a bz2 archive of a globbed path, while excluding a glob of dirnames
  archive:
    path:
    - /path/to/foo/*
    dest: /path/file.tar.bz2
    exclude_path:
    - /path/to/foo/ba*
    format: bz2

###get_url – Downloads files from HTTP, HTTPS, or FTP to node
# Downloads files from HTTP, HTTPS, or FTP to the remote server. The remote server must have direct access to the remote resource.
# By default, if an environment variable <protocol>_proxy is set on the target host, requests will be sent through that proxy. This behaviour can be overridden by setting a variable for this task (see setting the environment), or by using the use_proxy option.
# HTTP redirects can redirect from HTTP to HTTPS so you should be sure that your proxy environment for both protocols is correct.
# From Ansible 2.4 when run with check, it will do a HEAD request to validate the URL but will not download the entire file or verify it against hashes.
# For Windows targets, use the win_get_url module instead.

Parameter 	
    attributes
        Attributes the file or directory should have. To get supported flags look at the man page for chattr on the target system. This string should contain the attributes in the same order as the one displayed by lsattr.
        = operator is assumed as default, otherwise + or  operators need to be included in the string.
        aliases: attr
    backup
        boolean
            Choices:
            no (default)
            yes
        Create a backup file including the timestamp information so you can get the original file back if you somehow clobbered it incorrectly.
    checksum
        Default:If a checksum is passed to this parameter, the digest of the destination file will be calculated after it is downloaded to ensure its integrity and verify that the transfer completed successfully. Format: <algorithm>:<checksum|url>, e.g. checksum="sha256:D98291AC[...]B6DC7B97", checksum="sha256:http://example.com/path/sha256sum.txt"
        If you worry about portability, only the sha1 algorithm is available on all platforms and python versions.
        The third party hashlib library can be installed for access to additional algorithms.
        Additionally, if a checksum is passed to this parameter, and the file exist under the dest location, the destination_checksum would be calculated, and if checksum equals destination_checksum, the file download would be skipped (unless force is true).
    client_cert
        PEM formatted certificate chain file to be used for SSL client authentication. This file can also include the key as well, and if the key is included, client_key is not required.
    client_key
        PEM formatted file that contains your private key to be used for SSL client authentication. If client_cert contains both the certificate and key, this option is not required.
    dest
        required
        Absolute path of where to download the file to.
        If dest is a directory, either the server provided filename or, if none provided, the base name of the URL on the remote server will be used. If a directory, force has no effect.
        If dest is a directory, the file will always be downloaded (regardless of the force option), but replaced only if the contents changed..
    force
        boolean
            Choices:
            no (default)
            yes
        If yes and dest is not a directory, will download the file every time and replace the file if the contents change. If no, the file will only be downloaded if the destination does not exist. Generally should be yes only for small local files.
        Prior to 0.6, this module behaved as if yes was the default.
    aliases: thirsty
    force_basic_auth
        boolean
            Choices:
            no (default)
            yes
        httplib2, the library used by the uri module only sends authentication information when a webservice responds to an initial request with a 401 . Since some basic auth services do not properly send a 401, logins will fail. This option forces the sending of the Basic authentication header upon initial request.
    group
        Name of the group that should own the file/directory, as would be fed to chown.
    headers
        Add custom HTTP headers to a request in hash/dict format. The hash/dict format was added in 2.6. Previous versions used a "key:value,key:value" string format. The "key:value,key:value" string format is deprecated and will be removed in version 2.10.
    mode
        Mode the file or directory should be. For those used to /usr/bin/chmod remember that modes are actually octal numbers. You must either add a leading zero so that Ansible's YAML parser knows it is an octal number (like 0644 or 01777) or quote it (like '644' or '1777') so Ansible receives a string and can do its own conversion from string into number. Giving Ansible a number without following one of these rules will end up with a decimal number which will have unexpected results. As of version 1.8, the mode may be specified as a symbolic mode (for example, u+rwx or u=rw,g=r,o=r).
    others
        all arguments accepted by the file module also work here
    owner
        Name of the user that should own the file/directory, as would be fed to chown.
    selevel
        Default:s0
        Level part of the SELinux file context. This is the MLS/MCS attribute, sometimes known as the range. _default feature works as for seuser.
    serole
        Role part of SELinux file context, _default feature works as for seuser.
    setype
        Type part of SELinux file context, _default feature works as for seuser.
    seuser
        User part of SELinux file context. Will default to system policy, if applicable. If set to _default, it will use the user portion of the policy if available.
    sha256sum
        Default:If a SHA256 checksum is passed to this parameter, the digest of the destination file will be calculated after it is downloaded to ensure its integrity and verify that the transfer completed successfully. This option is deprecated. Use checksum instead.
    timeout
        Default:10
        Timeout in seconds for URL request.
    tmp_dest
        Absolute path of where temporary file is downloaded to.
        When run on Ansible 2.5 or greater, path defaults to ansible's remote_tmp setting
        When run on Ansible prior to 2.5, it defaults to TMPDIR, TEMP or TMP env variables or a platform specific value.
        https://docs.python.org/2/library/tempfile.html#tempfile.tempdir
    unsafe_writes
        boolean
            Choices:
            no (default)
            yes
        By default this module uses atomic operations to prevent data corruption or inconsistent reads from the target files, but sometimes systems are configured or just broken in ways that prevent this. One example is docker mounted files, which cannot be updated atomically from inside the container and can only be written in an unsafe manner.
        This option allows Ansible to fall back to unsafe methods of updating files when atomic operations fail (however, it doesn't force Ansible to perform unsafe writes). IMPORTANT! Unsafe writes are subject to race conditions and can lead to data corruption.
    url
        required
        HTTP, HTTPS, or FTP URL in the form (http|https|ftp)://[user[:pass]]@host.domain[:port]/path
    url_password
        The password for use in HTTP basic authentication.
        If the url_username parameter is not specified, the url_password parameter will not be used.
    url_username
        The username for use in HTTP basic authentication.
        This parameter can be used without url_password for sites that allow empty passwords.
    use_proxy
        boolean
            Choices:
            no
            yes (default)
        if no, it will not use a proxy, even if one is defined in an environment variable on the target hosts.
    validate_certs
        boolean
            Choices:
            no
            yes (default)
        If no, SSL certificates will not be validated. This should only be used on personally controlled sites using selfsigned certificates.


##Examples - get_url
- name: Download foo.conf
  get_url:
    url: http://example.com/path/file.conf
    dest: /etc/foo.conf
    mode: 0440

- name: Download file and force basic auth
  get_url:
    url: http://example.com/path/file.conf
    dest: /etc/foo.conf
    force_basic_auth: yes

- name: Download file with custom HTTP headers
  get_url:
    url: http://example.com/path/file.conf
    dest: /etc/foo.conf
    headers:
      key1: one
      key2: two

- name: Download file with check (sha256)
  get_url:
    url: http://example.com/path/file.conf
    dest: /etc/foo.conf
    checksum: sha256:b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c

- name: Download file with check (md5)
  get_url:
    url: http://example.com/path/file.conf
    dest: /etc/foo.conf
    checksum: md5:66dffb5228a211e61d6d7ef4a86f5758

- name: Download file with checksum url (sha256)
  get_url:
    url: http://example.com/path/file.conf
    dest: /etc/foo.conf
    checksum: 'sha256:http://example.com/path/sha256sum.txt'

- name: Download file from a file path
  get_url:
    url: file:///tmp/afile.txt
    dest: /tmp/afilecopy.txt


###slurp – Slurps a file from remote nodes
# This module works like fetch. It is used for fetching a base64 encoded blob containing the data in a remote file.
# This module is also supported for Windows targets.
Parameter 	
    src
        required
        The file on the remote system to fetch. This must be a file, not a directory.

##Examples - slurp
- name: Find out what the remote machine's mounts are
  slurp:
    src: /proc/mounts
  register: mounts

- debug:
    msg: "{{ mounts['content'] | b64decode }}"

# From the commandline, find the pid of the remote machine's sshd
# $ ansible host -m slurp -a 'src=/var/run/sshd.pid'
# host | SUCCESS => {
#     "changed": false,
#     "content": "MjE3OQo=",
#     "encoding": "base64",
#     "source": "/var/run/sshd.pid"
# }
# $ echo MjE3OQo= | base64 -d
# 2179





###mail – Send an email
# This module is useful for sending emails from playbooks.
# One may wonder why automate sending emails? In complex environments there are from time to time processes that cannot be automated, either because you lack the authority to make it so, or because not everyone agrees to a common approach.
# If you cannot automate a specific step, but the step is nonblocking, sending out an email to the responsible party to make them perform their part of the bargain is an elegant way to put the responsibility in someone else’s lap.
# Of course sending out a mail can be equally useful as a way to notify one or more people in a team that a specific action has been (successfully) taken.
Parameter 	
    attach
        Default:[]
        A list of pathnames of files to attach to the message.
        Attached files will have their contenttype set to application/octetstream.
    bcc
        The emailaddress(es) the mail is being 'blind' copied to.
        This is a list, which may contain address and phrase portions.
    body
        Default:$subject
        The body of the email being sent.
    cc
        The emailaddress(es) the mail is being copied to.
        This is a list, which may contain address and phrase portions.
    charset
        Default:utf8
        The character set of email being sent.
    from
        Default:root
        The emailaddress the mail is sent from. May contain address and phrase.
    headers
        Default:[]
        A list of headers which should be added to the message.
        Each individual header is specified as header=value (see example below).
    host
        Default:localhost
        The mail server.
    password
        If SMTP requires password.
    port
        Default:25
        The mail server port.
        This must be a valid integer between 1 and 65534
    secure
            Choices:
            always
            never
            starttls
            try (default)
        If always, the connection will only send email if the connection is Encrypted. If the server doesn't accept the encrypted connection it will fail.
        If try, the connection will attempt to setup a secure SSL/TLS session, before trying to send.
        If never, the connection will not attempt to setup a secure SSL/TLS session, before sending
        If starttls, the connection will try to upgrade to a secure SSL/TLS connection, before sending. If it is unable to do so it will fail.
    subject
        required
        The subject of the email being sent.
    subtype
            Choices:
            html
            plain (default)
        The minor mime type, can be either plain or html.
        The major type is always text.
    timeout
        Default:20
        Sets the timeout in seconds for connection attempts.
    to
        Default:root
        The emailaddress(es) the mail is being sent to.
        This is a list, which may contain address and phrase portions.
        aliases: recipients
    username
        If SMTP requires username.

##Examples - mail
- name: Example playbook sending mail to root
  mail:
    subject: System {{ ansible_hostname }} has been successfully provisioned.
  delegate_to: localhost

- name: Sending an e-mail using Gmail SMTP servers
  mail:
    host: smtp.gmail.com
    port: 587
    username: username@gmail.com
    password: mysecret
    to: John Smith <john.smith@example.com>
    subject: Ansible-report
    body: System {{ ansible_hostname }} has been successfully provisioned.
  delegate_to: localhost

- name: Send e-mail to a bunch of users, attaching files
  mail:
    host: 127.0.0.1
    port: 2025
    subject: Ansible-report
    body: Hello, this is an e-mail. I hope you like it ;-)
    from: jane@example.net (Jane Jolie)
    to:
    - John Doe <j.d@example.org>
    - Suzie Something <sue@example.com>
    cc: Charlie Root <root@localhost>
    attach:
    - /etc/group
    - /tmp/avatar2.png
    headers:
    - Reply-To=john@example.com
    - X-Special="Something or other"
    charset: us-ascii
  delegate_to: localhost

- name: Sending an e-mail using the remote machine, not the Ansible controller node
  mail:
    host: localhost
    port: 25
    to: John Smith <john.smith@example.com>
    subject: Ansible-report
    body: System {{ ansible_hostname }} has been successfully provisioned.

- name: Sending an e-mail using Legacy SSL to the remote machine
  mail:
    host: localhost
    port: 25
    to: John Smith <john.smith@example.com>
    subject: Ansible-report
    body: System {{ ansible_hostname }} has been successfully provisioned.
    secure: always

- name: Sending an e-mail using StartTLS to the remote machine
  mail:
    host: localhost
    port: 25
    to: John Smith <john.smith@example.com>
    subject: Ansible-report
    body: System {{ ansible_hostname }} has been successfully provisioned.
    secure: starttls

###say – Makes a computer to speak.
# makes a computer speak! Amuse your friends, annoy your coworkers!
#The below  are needed on the host that executes this module.
#say or espeak or espeakng

Parameter 
    msg
        required
        What to say
    voice
        What voice to use

##Examples - say
- say:
    msg: '{{ inventory_hostname }} is all done'
    voice: Zarvox
  delegate_to: localhost


###syslogger – Log messages in the syslog
# Uses syslog to add log entries to the host.
# Can specify facility and priority.
Parameter 	
    facility
            Choices:
            kern
            user
            mail
            daemon (default)
            auth
            lpr
            news
            uucp
            cron
            syslog
            local0
            local1
            local2
            local3
            local4
            local5
            local6
            local7
        Set the log facility
    log_pid
        boolean
            Choices:
            no (default)
            yes
        Log the pid in brackets
    msg
        required
        This is the message to place in syslog
    priority
            Choices:
            emerg
            alert
            crit
            err
            warning
            notice
            info (default)
            debug
        Set the log priority
    
##Examples - syslogger
- name: Test syslog
  syslogger:
    msg: "Hello from ansible"
    priority: "err"
    facility: "daemon"
    log_pid: true

# Basic usage
- name: Simple Usage
  syslogger:
    msg: "I will end up as daemon.info"


###apt – Manages aptpackages
#Manages apt packages (such as for Debian/Ubuntu).
# The below  are needed on the host that executes this module.
    # pythonapt (python 2)
    # python3apt (python 3)
    # aptitude (before 2.4)
    
Parameter 	
    allow_unauthenticated
        boolean
            Choices:
            no (default)
            yes
        Ignore if packages cannot be authenticated. This is useful for bootstrapping environments that manage their own aptkey setup.
        allow_unauthenticated is only supported with state: install/present
    autoclean
        boolean
            Choices:
            no (default)
            yes
        If yes, cleans the local repository of retrieved package files that can no longer be downloaded.
    autoremove
        boolean
            Choices:
            no (default)
            yes
        If yes, remove unused dependency packages for all module states except builddep. It can also be used as the only option.
        Previous to version 2.4, autoclean was also an alias for autoremove, now it is its own separate command. See documentation for further information.
    cache_valid_time
        Default:0
        Update the apt cache if its older than the cache_valid_time. This option is set in seconds. As of Ansible 2.4, this sets update_cache=yes.
    deb
        Path to a .deb package on the remote machine.
        If :// in the path, ansible will attempt to download deb before installing. (Version added 2.1)
    default_release
        Corresponds to the t option for apt and sets pin priorities
    dpkg_options
        Default:forceconfdef,forceconfold
        Add dpkg options to apt command. Defaults to 'o "Dpkg::Options::=forceconfdef" o "Dpkg::Options::=forceconfold"'
        Options should be supplied as comma separated list
    force
        boolean
            Choices:
            no (default)
            yes
        Corresponds to the forceyes to aptget and implies allow_unauthenticated: yes
        This option will disable checking both the packages' signatures and the certificates of the web servers they are downloaded from.
        This option *is not* the equivalent of passing the f flag to aptget on the command line
        **This is a destructive operation with the potential to destroy your system, and it should almost never be used.** Please also see man aptget for more information.
    force_apt_get
        boolean
            Choices:
            no (default)
            yes
        Force usage of aptget instead of aptitude
    install_recommends
        boolean
            Choices:
            no
            yes
        Corresponds to the noinstallrecommends option for apt. yes installs recommended packages. no does not install recommended packages. By default, Ansible will use the same defaults as the operating system. Suggested packages are never installed.
        aliases: installrecommends
    name
        A list of package names, like foo, or package specifier with version, like foo=1.0. Name wildcards (fnmatch) like apt* and version wildcards like foo=1.0* are also supported.
        aliases: package, pkg
    only_upgrade
        boolean
            Choices:
            no (default)
            yes
        Only upgrade a package if it is already installed.
    purge
        boolean
            Choices:
            no (default)
            yes
        Will force purging of configuration files if the module state is set to absent.
    state
            Choices:
            absent
            builddep
            latest
            present (default)
        Indicates the desired package state. latest ensures that the latest version is installed. builddep ensures the package build dependencies are installed.
    update_cache
        boolean
            Choices:
            no (default)
            yes
        Run the equivalent of aptget update before the operation. Can be run as part of the package installation or as a separate step.
    upgrade
            Choices:
            dist
            full
            no (default)
            safe
            yes
        If yes or safe, performs an aptitude safeupgrade.
        If full, performs an aptitude fullupgrade.
        If dist, performs an aptget distupgrade.
        This does not upgrade a specific package, use state=latest for that.

##Examples - apt
- name: Update repositories cache and install "foo" package
  apt:
    name: foo
    update_cache: yes

- name: Install apache httpd but avoid starting it immediately (state=present is optional)
  apt:
    name: apache2
    state: present
  environment:
    RUNLEVEL: 1

- name: Remove "foo" package
  apt:
    name: foo
    state: absent

- name: Install the package "foo"
  apt:
    name: foo

- name: Install a list of packages
  apt:
    name: "{{ packages }}"
  vars:
    packages:
    - foo
    - foo-tools

- name: Install the version '1.00' of package "foo"
  apt:
    name: foo=1.00

- name: Update the repository cache and update package "nginx" to latest version using default release squeeze-backport
  apt:
    name: nginx
    state: latest
    default_release: squeeze-backports
    update_cache: yes

- name: Install latest version of "openjdk-6-jdk" ignoring "install-recommends"
  apt:
    name: openjdk-6-jdk
    state: latest
    install_recommends: no

- name: Upgrade all packages to the latest version
  apt:
    name: "*"
    state: latest

- name: Update all packages to the latest version
  apt:
    upgrade: dist

- name: Run the equivalent of "apt-get update" as a separate step
  apt:
    update_cache: yes

- name: Only run "update_cache=yes" if the last one is more than 3600 seconds ago
  apt:
    update_cache: yes
    cache_valid_time: 3600

- name: Pass options to dpkg on run
  apt:
    upgrade: dist
    update_cache: yes
    dpkg_options: 'force-confold,force-confdef'

- name: Install a .deb package
  apt:
    deb: /tmp/mypackage.deb

- name: Install the build dependencies for package "foo"
  apt:
    pkg: foo
    state: build-dep

- name: Install a .deb package from the internet.
  apt:
    deb: https://example.com/python-ppq_0.1-1_all.deb

- name: Remove useless packages from the cache
  apt:
    autoclean: yes

- name: Remove dependencies that are no longer required
  apt:
    autoremove: yes
    
    

###apt_key – Add or remove an apt key
#Add or remove an apt key, optionally downloading it.

Parameter 	
    data
        The keyfile contents to add to the keyring.
    file
        The path to a keyfile on the remote server to add to the keyring.
    id
        The identifier of the key.
        Including this allows check mode to correctly report the changed state.
        If specifying a subkey's id be aware that aptkey does not understand how to remove keys via a subkey id. Specify the primary key's id instead.
        This parameter is required when state is set to absent.
    keyring
        The full path to specific keyring file in /etc/apt/trusted.gpg.d/
    keyserver
        The keyserver to retrieve key from.
    state
            Choices:
            absent
            present (default)
        Ensures that the key is present (added) or absent (revoked).
    url
        The URL to retrieve key from.
    validate_certs
        boolean
            Choices:
            no
            yes (default)
        If no, SSL certificates for the target url will not be validated. This should only be used on personally controlled sites using selfsigned certificates.

##Examples - apt_key 
- name: Add an apt key by id from a keyserver
  apt_key:
    keyserver: keyserver.ubuntu.com
    id: 36A1D7869245C8950F966E92D8576A8BA88D21E9

- name: Add an Apt signing key, uses whichever key is at the URL
  apt_key:
    url: https://ftp-master.debian.org/keys/archive-key-6.0.asc
    state: present

- name: Add an Apt signing key, will not download if present
  apt_key:
    id: 473041FA
    url: https://ftp-master.debian.org/keys/archive-key-6.0.asc
    state: present

- name: Remove a Apt specific signing key, leading 0x is valid
  apt_key:
    id: 0x473041FA
    state: absent

# Use armored file since utf-8 string is expected. Must be of "PGP PUBLIC KEY BLOCK" type.
- name: Add a key from a file on the Ansible server.
  apt_key:
    data: "{{ lookup('file', 'apt.asc') }}"
    state: present

- name: Add an Apt signing key to a specific keyring file
  apt_key:
    id: 473041FA
    url: https://ftp-master.debian.org/keys/archive-key-6.0.asc
    keyring: /etc/apt/trusted.gpg.d/debian.gpg

- name: Add Apt signing key on remote server to keyring
  apt_key:
    id: 473041FA
    file: /tmp/apt.gpg
    state: present
    

###apt_repository – Add and remove APT repositories
#Add or remove an APT repositories in Ubuntu and Debian.
# The below  are needed on the host that executes this module.
    # pythonapt (python 2)
    # python3apt (python 3)
#This module works on Debian, Ubuntu and their derivatives.

Parameter 	
    codename
        Override the distribution codename to use for PPA repositories. Should usually only be set when working with a PPA on a nonUbuntu target (e.g. Debian or Mint)
    filename
        Sets the name of the source list file in sources.list.d. Defaults to a file name based on the repository source url. The .list extension will be automatically added.
    mode
        Default:0644
        The octal mode for newly created files in sources.list.d
    repo
        required
        A source string for the repository.
    state
            Choices:
            absent
            present (default)
        A source string state.
    update_cache
        boolean
            Choices:
            no
            yes (default)
        Run the equivalent of aptget update when a change occurs. Cache updates are run after making changes.
    validate_certs
        boolean
            Choices:
            no
            yes (default)
        If no, SSL certificates for the target repo will not be validated. This should only be used on personally controlled sites using selfsigned certificates.


##Examples - apt_repository
# Add specified repository into sources list.
- apt_repository:
    repo: deb http://archive.canonical.com/ubuntu hardy partner
    state: present

# Add specified repository into sources list using specified filename.
- apt_repository:
    repo: deb http://dl.google.com/linux/chrome/deb/ stable main
    state: present
    filename: google-chrome

# Add source repository into sources list.
- apt_repository:
    repo: deb-src http://archive.canonical.com/ubuntu hardy partner
    state: present

# Remove specified repository from sources list.
- apt_repository:
    repo: deb http://archive.canonical.com/ubuntu hardy partner
    state: absent

# Add nginx stable repository from PPA and install its signing key.
# On Ubuntu target:
- apt_repository:
    repo: ppa:nginx/stable

# On Debian target
- apt_repository:
    repo: 'ppa:nginx/stable'
    codename: trusty


###git – Deploy software (or files) from git checkouts
#Manage git checkouts of repositories to deploy files or software.
# The below  are needed on the host that executes this module.
    # git>=1.7.1 (the command line tool)
#If the task seems to be hanging, first verify remote host is in known_hosts. SSH will prompt user to authorize the first contact with a remote host. To avoid this prompt, one solution is to use the option accept_hostkey. Another solution is to add the remote host public key in /etc/ssh/ssh_known_hosts before calling the git module, with the following command: sshkeyscan H remote_host.com >> /etc/ssh/ssh_known_hosts.
    
Parameter 	
    accept_hostkey
        boolean
            Choices:
            no (default)
            yes
        if yes, ensure that "o StrictHostKeyChecking=no" is present as an ssh option.
    archive
        Specify archive file path with extension. If specified, creates an archive file of the specified format containing the tree structure for the source tree. Allowed archive formats ["zip", "tar.gz", "tar", "tgz"]
        This will clone and perform git archive from local directory as not all git servers support git archive.
    bare
        boolean
            Choices:
            no (default)
            yes
        if yes, repository will be created as a bare repo, otherwise it will be a standard repo with a workspace.
    clone
        boolean
            Choices:
            no
            yes (default)
        If no, do not clone the repository if it does not exist locally
    depth
        Create a shallow clone with a history truncated to the specified number or revisions. The minimum possible value is 1, otherwise ignored. Needs git>=1.9.1 to work correctly.
    dest
        required
        The path of where the repository should be checked out. This parameter is required, unless clone is set to no.
    executable
        Path to git executable to use. If not supplied, the normal mechanism for resolving binary paths will be used.
    force
        boolean
            Choices:
            no (default)
            yes
        If yes, any modified files in the working repository will be discarded. Prior to 0.7, this was always 'yes' and could not be disabled. Prior to 1.9, the default was `yes`
    key_file
        Specify an optional private key file path, on the target host, to use for the checkout.
    recursive
        boolean
            Choices:
            no
            yes (default)
        if no, repository will be cloned without the recursive option, skipping submodules.
    reference
        Reference repository (see "git clone reference ...")
    refspec
        Add an additional refspec to be fetched. If version is set to a SHA1 not reachable from any branch or tag, this option may be necessary to specify the ref containing the SHA1. Uses the same syntax as the 'git fetch' command. An example value could be "refs/meta/config".
    remote
        Default:origin
        Name of the remote.
    repo
        required
        git, SSH, or HTTP(S) protocol address of the git repository.
        aliases: name
    separate_git_dir
        The path to place the cloned repository. If specified, Git repository can be separated from working tree.
    ssh_opts
        Creates a wrapper script and exports the path as GIT_SSH which git then automatically uses to override ssh arguments. An example value could be "o StrictHostKeyChecking=no"
    track_submodules
        boolean
            Choices:
            no (default)
            yes
        if yes, submodules will track the latest commit on their master branch (or other branch specified in .gitmodules). If no, submodules will be kept at the revision specified by the main project. This is equivalent to specifying the remote flag to git submodule update.
    umask
        The umask to set before doing any checkouts, or any other repository maintenance.
    update
        boolean
            Choices:
            no
            yes (default)
        If no, do not retrieve new revisions from the origin repository
        Operations like archive will work on the existing (old) repository and might not respond to changes to the options version or remote.
    verify_commit
        boolean
            Choices:
            no (default)
            yes
        if yes, when cloning or checking out a version verify the signature of a GPG signed commit. This requires git version>=2.1.0 to be installed. The commit MUST be signed and the public key MUST be present in the GPG keyring.
    version
        Default:HEAD
        What version of the repository to check out. This can be the literal string HEAD, a branch name, a tag name. It can also be a SHA1 hash, in which case refspec needs to be specified if the given revision is not already available.

    
##Examples - git 
# Example git checkout from Ansible Playbooks
- git:
    repo: 'https://foosball.example.org/path/to/repo.git'
    dest: /srv/checkout
    version: release-0.22

# Example read-write git checkout from github
- git:
    repo: ssh://git@github.com/mylogin/hello.git
    dest: /home/mylogin/hello

# Example just ensuring the repo checkout exists
- git:
    repo: 'https://foosball.example.org/path/to/repo.git'
    dest: /srv/checkout
    update: no

# Example just get information about the repository whether or not it has
# already been cloned locally.
- git:
    repo: 'https://foosball.example.org/path/to/repo.git'
    dest: /srv/checkout
    clone: no
    update: no

# Example checkout a github repo and use refspec to fetch all pull requests
- git:
    repo: https://github.com/ansible/ansible-examples.git
    dest: /src/ansible-examples
    refspec: '+refs/pull/*:refs/heads/*'

# Example Create git archive from repo
- git:
    repo: https://github.com/ansible/ansible-examples.git
    dest: /src/ansible-examples
    archive: /tmp/ansible-examples.zip

# Example clone a repo with separate git directory
- git:
    repo: https://github.com/ansible/ansible-examples.git
    dest: /src/ansible-examples
    separate_git_dir: /src/ansible-examples.git


###ping – Try to connect to host, verify a usable python and return pong on success
# A trivial test module, this module always returns pong on successful contact. It does not make sense in playbooks, but it is useful from /usr/bin/ansible to verify the ability to login and that a usable Python is configured.
# This is NOT ICMP ping, this is just a trivial test module that requires Python on the remotenode.
# For Windows targets, use the win_ping module instead.
# For Network targets, use the net_ping module instead.

Parameter 
data
    Default:pong
    Data to return for the ping return value.
    If this parameter is set to crash, the module will cause an exception.


##Examples - ping 
# ansible webservers -m ping

# Example from an Ansible Playbook
- ping:

# Induce an exception to see what happens
- ping:
    data: crash


###setup – Gathers facts about remote hosts
# This module is automatically called by playbooks to gather useful variables about remote hosts that can be used in playbooks. It can also be executed directly by /usr/bin/ansible to check what variables are available to a host. Ansible provides many facts about the system, automatically.
# This module is also supported for Windows targets.
# More ansible facts will be added with successive releases. If facter or ohai are installed, variables from these programs will also be snapshotted into the JSON file for usage in templating. These variables are prefixed with facter_ and ohai_ so it’s easy to tell their source. All variables are bubbled up to the caller. Using the ansible facts and choosing to not install facter and ohai means you can avoid Rubydependencies on your remote systems. (See also facter and ohai.)
# The filter option filters only the first level subkey below ansible_facts.
# If the target host is Windows, you will not currently have the ability to use filter as this is provided by a simpler implementation of the module.
# If the target host is Windows you can now use fact_path. Make sure that this path exists on the target host. Files in this path MUST be PowerShell scripts (*.ps1) and their output must be formattable in JSON (Ansible will take care of this). Test the output of your scripts. This option was added in Ansible 2.1.

Parameter 	
    fact_path
        Default:/etc/ansible/facts.d
        path used for local ansible facts (*.fact)  files in this dir will be run (if executable) and their results be added to ansible_local facts if a file is not executable it is read. Check  for Windows options. (from 2.1 on) File/results format can be json or iniformat
    filter
        Default:*
        if supplied, only return facts that match this shellstyle (fnmatch) wildcard.
    gather_subset
        Default:all
        if supplied, restrict the additional facts collected to the given subset. Possible values: all, min, hardware, network, virtual, ohai, and facter. Can specify a list of values to specify a larger subset. Values can also be used with an initial ! to specify that that specific subset should not be collected. For instance: !hardware,!network,!virtual,!ohai,!facter. If !all is specified then only the min subset is collected. To avoid collecting even the min subset, specify !all,!min. To collect only specific facts, use !all,!min, and specify the particular fact subsets. Use the filter parameter if you do not want to display some collected facts.
    gather_timeout
        Default:10
        Set the default timeout in seconds for individual fact gathering
    
##Examples - setup 
# Display facts from all hosts and store them indexed by I(hostname) at C(/tmp/facts).
# ansible all -m setup --tree /tmp/facts

# Display only facts regarding memory found by ansible on all hosts and output them.
# ansible all -m setup -a 'filter=ansible_*_mb'

# Display only facts returned by facter.
# ansible all -m setup -a 'filter=facter_*'

# Collect only facts returned by facter.
# ansible all -m setup -a 'gather_subset=!all,!any,facter'

- name: Collect only facts returned by facter
  setup:
    gather_subset:
      - '!all'
      - '!any'
      - facter

# Display only facts about certain interfaces.
# ansible all -m setup -a 'filter=ansible_eth[0-2]'

# Restrict additional gathered facts to network and virtual (includes default minimum facts)
# ansible all -m setup -a 'gather_subset=network,virtual'

# Collect only network and virtual (excludes default minimum facts)
# ansible all -m setup -a 'gather_subset=!all,!any,network,virtual'

# Do not call puppet facter or ohai even if present.
# ansible all -m setup -a 'gather_subset=!facter,!ohai'

# Only collect the default minimum amount of facts:
# ansible all -m setup -a 'gather_subset=!all'

# Collect no facts, even the default minimum subset of facts:
# ansible all -m setup -a 'gather_subset=!all,!min'

# Display facts from Windows hosts with custom facts stored in C(C:\custom_facts).
# ansible windows -m setup -a "fact_path='c:\custom_facts'"


###jenkins_job – Manage jenkins jobs
#Manage Jenkins jobs by using Jenkins REST API.
# The below  are needed on the host that executes this module.
    # pythonjenkins >= 0.4.12
    # lxml >= 3.3.3
    
Parameter 	
    config
        config in XML format.
        Required if job does not yet exist.
        Mutually exclusive with enabled.
        Considered if state=present.
    enabled
        boolean
            Choices:
            no
            yes
        Whether the job should be enabled or disabled.
        Mutually exclusive with config.
        Considered if state=present.
    name
        required
        Name of the Jenkins job.
    password
        Password to authenticate with the Jenkins server.
    state
            Choices:
            present (default)
            absent
        Attribute that specifies if the job has to be created or deleted.
    token
        API token used to authenticate alternatively to password.
    url
        Default:http://localhost:8080
        URL where the Jenkins server is accessible.
    user
        User to authenticate with the Jenkins server.

##Examples - jenkins job
# Create a jenkins job using basic authentication
- jenkins_job:
    config: "{{ lookup('file', 'templates/test.xml') }}"
    name: test
    password: admin
    url: http://localhost:8080
    user: admin

# Create a jenkins job using the token
- jenkins_job:
    config: "{{ lookup('template', 'templates/test.xml.j2') }}"
    name: test
    token: asdfasfasfasdfasdfadfasfasdfasdfc
    url: http://localhost:8080
    user: admin

# Delete a jenkins job using basic authentication
- jenkins_job:
    name: test
    password: admin
    state: absent
    url: http://localhost:8080
    user: admin

# Delete a jenkins job using the token
- jenkins_job:
    name: test
    token: asdfasfasfasdfasdfadfasfasdfasdfc
    state: absent
    url: http://localhost:8080
    user: admin

# Disable a jenkins job using basic authentication
- jenkins_job:
    name: test
    password: admin
    enabled: False
    url: http://localhost:8080
    user: admin

# Disable a jenkins job using the token
- jenkins_job:
    name: test
    token: asdfasfasfasdfasdfadfasfasdfasdfc
    enabled: False
    url: http://localhost:8080
    user: admin


###jira – create and modify issues in a JIRA instance
#Create and modify issues in a JIRA instance.

Parameter 	
    assignee
        Sets the assignee on create or transition operations. Note not all transitions will allow this.
    comment
        The comment text to add.
    description
        The issue description, where appropriate.
    fields
        This is a freeform data structure that can contain arbitrary data. This is passed directly to the JIRA REST API (possibly after merging with other required data, as when passed to create). See examples for more information, and the JIRA REST API for the structure required for various fields.
    inwardissue
        Set issue from which link will be created.
    issue
        An existing issue key to operate on.
    issuetype
        The issue type, for issue creation.
    linktype
        Set type of link, when action 'link' selected.
    operation
        required
            Choices:
            create
            comment
            edit
            fetch
            transition
            link
        The operation to perform.
        aliases: command
    outwardissue
        Set issue to which link will be created.
    password
        required
        The password to login with.
    project
        The project for this operation. Required for issue creation.
        The desired ; only relevant for the transition operation.
    summary
        The issue summary, where appropriate.
    timeout
        Default:10
        Set timeout, in seconds, on requests to JIRA API.
    uri
        required
        Base URI for the JIRA instance.
    username
        required
        The username to login with.
    validate_certs
        Default:yes
        Require valid SSL certificates (set to `false` if you'd like to use selfsigned certificates)


##Examples - jira
# Create a new issue and add a comment to it:
- name: Create an issue
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    project: ANS
    operation: create
    summary: Example Issue
    description: Created using Ansible
    issuetype: Task
  register: issue

- name: Comment on issue
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    issue: '{{ issue.meta.key }}'
    operation: comment
    comment: A comment added by Ansible

# Assign an existing issue using edit
- name: Assign an issue using free-form fields
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    issue: '{{ issue.meta.key}}'
    operation: edit
    assignee: ssmith

# Create an issue with an existing assignee
- name: Create an assigned issue
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    project: ANS
    operation: create
    summary: Assigned issue
    description: Created and assigned using Ansible
    issuetype: Task
    assignee: ssmith

# Edit an issue
- name: Set the labels on an issue using free-form fields
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    issue: '{{ issue.meta.key }}'
    operation: edit
  args:
    fields:
        labels:
          - autocreated
          - ansible

# Retrieve metadata for an issue and use it to create an account
- name: Get an issue
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    project: ANS
    operation: fetch
    issue: ANS-63
  register: issue

- name: Create a unix account for the reporter
  become: true
  user:
    name: '{{ issue.meta.fields.creator.name }}'
    comment: '{{ issue.meta.fields.creator.displayName }}'

# You can get list of valid linktypes at /rest/api/2/issueLinkType
# url of your jira installation.
- name: Create link from HSP-1 to MKY-1
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    operation: link
    linktype: Relates
    inwardissue: HSP-1
    outwardissue: MKY-1

# Transition an issue by target status
- name: Close the issue
  jira:
    uri: '{{ server }}'
    username: '{{ user }}'
    password: '{{ pass }}'
    issue: '{{ issue.meta.key }}'
    operation: transition
    status: Done


###win_copy – Copies files to remote locations on windows hosts
# The win_copy module copies a file on the local box to remote windows locations.
# For nonWindows targets, use the copy module instead.

Parameter 	
    content
        When used instead of src, sets the contents of a file directly to the specified value. This is for simple values, for anything complex or with formatting please switch to the template module.
    decrypt
        boolean
            Choices:
            no
            yes (default)
        This option controls the autodecryption of source files using vault.
    dest
        path / required
        Remote absolute path where the file should be copied to. If src is a directory, this must be a directory too.
        Use \ for path separators or \\ when in "double quotes".
        If dest ends with \ then source or the contents of source will be copied to the directory without renaming.
        If dest is a nonexistent path, it will only be created if dest ends with "/" or "\", or src is a directory.
        If src and dest are files and if the parent directory of dest doesn't exist, then the task will fail.
    force
        boolean
            Choices:
            no
            yes (default)
        If set to yes, the file will only be transferred if the content is different than destination.
        If set to no, the file will only be transferred if the destination does not exist.
        If set to no, no checksuming of the content is performed which can help improve performance on larger files.
    local_follow
        boolean
            Choices:
            no
            yes (default)
        This flag indicates that filesystem links in the source tree, if they exist, should be followed.
    remote_src
        boolean
            Choices:
            no (default)
            yes
        If no, it will search for src at originating/master machine.
        If yes, it will go to the remote/target machine for the src.
    src
        path / required
        Local path to a file to copy to the remote server; can be absolute or relative.
        If path is a directory, it is copied (including the source folder name) recursively to dest.
        If path is a directory and ends with "/", only the inside contents of that directory are copied to the destination. Otherwise, if it does not end with "/", the directory itself with all contents is copied.
        If path is a file and dest ends with "\", the file is copied to the folder with the same filename.


##Examples - win_copy
- name: Copy a single file
  win_copy:
    src: /srv/myfiles/foo.conf
    dest: C:\Temp\renamed-foo.conf

- name: Copy a single file keeping the filename
  win_copy:
    src: /src/myfiles/foo.conf
    dest: C:\Temp\

- name: Copy folder to C:\Temp (results in C:\Temp\temp_files)
  win_copy:
    src: files/temp_files
    dest: C:\Temp

- name: Copy folder contents recursively
  win_copy:
    src: files/temp_files/
    dest: C:\Temp

- name: Copy a single file where the source is on the remote host
  win_copy:
    src: C:\Temp\foo.txt
    dest: C:\ansible\foo.txt
    remote_src: yes

- name: Copy a folder recursively where the source is on the remote host
  win_copy:
    src: C:\Temp
    dest: C:\ansible
    remote_src: yes

- name: Set the contents of a file
  win_copy:
    content: abc123
    dest: C:\Temp\foo.txt


###win_environment – Modify environment variables on windows hosts
# Uses .net Environment to set or remove environment variables and can set at User, Machine or Process level.
# User level environment variables will be set, but not available until the user has logged off and on again.

Parameter 	
    level
        required
            Choices:
            machine
            user
            process
        The level at which to set the environment variable.
        Use machine to set for all users.
        Use user to set for the current user that ansible is connected as.
        Use process to set for the current process. Probably not that useful.
    name
        required
        The name of the environment variable.
    state
            Choices:
            absent
            present (default)
        Set to present to ensure environment variable is set.
        Set to absent to ensure it is removed.
    value
        The value to store in the environment variable.
        Must be set when state=present and cannot be an empty string.
        Can be omitted for state=absent.

##Examples - win_environment
- name: Set an environment variable for all users
  win_environment:
    state: present
    name: TestVariable
    value: Test value
    level: machine

- name: Remove an environment variable for the current user
  win_environment:
    state: absent
    name: TestVariable
    level: user


###win_file – Creates, touches or removes files or directories
# Creates (empty) files, updates file modification stamps of existing files, and can create or remove directories.
# Unlike file, does not modify ownership, permissions or manipulate links.
# For nonWindows targets, use the file module instead.

Parameter 	
    path
        path / required
        Path to the file being managed.
        aliases: dest, name
    state
            Choices:
            absent
            directory
            file
            touch
        If directory, all immediate subdirectories will be created if they do not exist.
        If file, the file will NOT be created if it does not exist, see the copy or template module if you want that behavior. If absent, directories will be recursively deleted, and files will be removed.
        If touch, an empty file will be created if the path does not exist, while an existing file or directory will receive updated file access and modification times (similar to the way touch works from the command line).


##Examples - win_file
- name: Touch a file (creates if not present, updates modification time if present)
  win_file:
    path: C:\Temp\foo.conf
    state: touch

- name: Remove a file, if present
  win_file:
    path: C:\Temp\foo.conf
    state: absent

- name: Create directory structure
  win_file:
    path: C:\Temp\folder\subfolder
    state: directory

- name: Remove directory structure
  win_file:
    path: C:\Temp
    state: absent


###win_file_version – Get DLL or EXE file build version
#Get DLL or EXE file build version.

Parameter 	
    path
        path / required
        File to get version.
        Always provide absolute path.

##Examples - win_file_version
- name: Get acm instance version
  win_file_version:
    path: C:\Windows\System32\cmd.exe
  register: exe_file_version

- debug:
    msg: '{{ exe_file_version }}'


###win_find – Return a list of files based on specific criteria
# Return a list of files based on specified criteria.
# Multiple criteria are AND’d together.
# For nonWindows targets, use the find module instead.

Parameter 
    age
        Select files or folders whose age is equal to or greater than the specified time. Use a negative age to find files equal to or less than the specified time. You can choose seconds, minutes, hours, days or weeks by specifying the first letter of an of those words (e.g., "2s", "10d", 1w").
    age_stamp
            Choices:
            atime
            ctime
            mtime (default)
        Choose the file property against which we compare age. The default attribute we compare with is the last modification time.
    checksum_algorithm
            Choices:
            md5
            sha1 (default)
            sha256
            sha384
            sha512
        Algorithm to determine the checksum of a file. Will throw an error if the host is unable to use specified algorithm.
    file_type
            Choices:
            directory
            file (default)
        Type of file to search for.
    follow
        boolean
            Choices:
            no (default)
            yes
        Set this to yes to follow symlinks in the path.
        This needs to be used in conjunction with recurse.
    get_checksum
        boolean
            Choices:
            no
            yes (default)
        Whether to return a checksum of the file in the return info (default sha1), use checksum_algorithm to change from the default.
    hidden
        boolean
            Choices:
            no (default)
            yes
        Set this to include hidden files or folders.
    paths
        required
        List of paths of directories to search for files or folders in. This can be supplied as a single path or a list of paths.
    patterns
        One or more (powershell or regex) patterns to compare filenames with. The type of pattern matching is controlled by use_regex option. The patterns retrict the list of files or folders to be returned based on the filenames. For a file to be matched it only has to match with one pattern in a list provided.
    recurse
        boolean
            Choices:
            no (default)
            yes
        Will recursively descend into the directory looking for files or folders.
    size
        Select files or folders whose size is equal to or greater than the specified size. Use a negative value to find files equal to or less than the specified size. You can specify the size with a suffix of the byte type i.e. kilo = k, mega = m... Size is not evaluated for symbolic links.
    use_regex
        boolean
            Choices:
            no (default)
            yes
        Will set patterns to run as a regex check if set to yes.

##Examples - win_find
- name: Find files in path
  win_find:
    paths: D:\Temp

- name: Find hidden files in path
  win_find:
    paths: D:\Temp
    hidden: yes

- name: Find files in multiple paths
  win_find:
    paths:
    - C:\Temp
    - D:\Temp

- name: Find files in directory while searching recursively
  win_find:
    paths: D:\Temp
    recurse: yes

- name: Find files in directory while following symlinks
  win_find:
    paths: D:\Temp
    recurse: yes
    follow: yes

- name: Find files with .log and .out extension using powershell wildcards
  win_find:
    paths: D:\Temp
    patterns: [ '*.log', '*.out' ]

- name: Find files in path based on regex pattern
  win_find:
    paths: D:\Temp
    patterns: out_\d{8}-\d{6}.log

- name: Find files older than 1 day
  win_find:
    paths: D:\Temp
    age: 86400

- name: Find files older than 1 day based on create time
  win_find:
    paths: D:\Temp
    age: 86400
    age_stamp: ctime

- name: Find files older than 1 day with unit syntax
  win_find:
    paths: D:\Temp
    age: 1d

- name: Find files newer than 1 hour
  win_find:
    paths: D:\Temp
    age: -3600

- name: Find files newer than 1 hour with unit syntax
  win_find:
    paths: D:\Temp
    age: -1h

- name: Find files larger than 1MB
  win_find:
    paths: D:\Temp
    size: 1048576

- name: Find files larger than 1GB with unit syntax
  win_find:
    paths: D:\Temp
    size: 1g

- name: Find files smaller than 1MB
  win_find:
    paths: D:\Temp
    size: -1048576

- name: Find files smaller than 1GB with unit syntax
  win_find:
    paths: D:\Temp
    size: -1g

- name: Find folders/symlinks in multiple paths
  win_find:
    paths:
    - C:\Temp
    - D:\Temp
    file_type: directory

- name: Find files and return SHA256 checksum of files found
  win_find:
    paths: C:\Temp
    get_checksum: yes
    checksum_algorithm: sha256

- name: Find files and do not return the checksum
  win_find:
    paths: C:\Temp
    get_checksum: no


###win_get_url – Downloads file from HTTP, HTTPS, or FTP to node
#Downloads files from HTTP, HTTPS, or FTP to the remote server. The remote server must have direct access to the remote resource.
#For nonWindows targets, use the get_url module instead.

Parameter 	
    dest
        path / required
        The location to save the file at the URL.
        Be sure to include a filename and extension as appropriate.
    force
        boolean
            Choices:
            no
            yes (default)
        If yes, will always download the file. If no, will only download the file if it does not exist or the remote file has been modified more recently than the local file.
        This works by sending an http HEAD request to retrieve last modified time of the requested resource, so for this to work, the remote web server must support HEAD requests.
    force_basic_auth
        boolean
            Choices:
            no (default)
            yes
        If yes, will add a Basic authentication header on the initial request.
        If no, will use Microsoft's WebClient to handle authentication.
    headers
        dictionary
        Add custom HTTP headers to a request (as a dictionary).
    proxy_password
        Proxy authentication password.
    proxy_url
        The full URL of the proxy server to download through.
    proxy_username
        Proxy authentication username.
    skip_certificate_validation
        boolean
            Choices:
            no (default)
            yes
        This option is deprecated since v2.4, please use validate_certs instead.
        If yes, SSL certificates will not be validated. This should only be used on personally controlled sites using selfsigned certificates.
    timeout
        integer
        Default:10
        Timeout in seconds for URL request.
    url
        required
        The full URL of a file to download.
    url_password
        Basic authentication password.
        aliases: password
    url_username
        Basic authentication username.
        aliases: username
    use_proxy
        boolean
            Choices:
            no
            yes (default)
        If no, it will not use a proxy, even if one is defined in an environment variable on the target hosts.
    validate_certs
        boolean
            Choices:
            no
            yes (default)
        If no, SSL certificates will not be validated. This should only be used on personally controlled sites using selfsigned certificates.
        If skip_certificate_validation was set, it overrides this option.

##Examples - win_get_url
- name: Download earthrise.jpg to specified path
  win_get_url:
    url: http://www.example.com/earthrise.jpg
    dest: C:\Users\RandomUser\earthrise.jpg

- name: Download earthrise.jpg to specified path only if modified
  win_get_url:
    url: http://www.example.com/earthrise.jpg
    dest: C:\Users\RandomUser\earthrise.jpg
    force: no

- name: Download earthrise.jpg to specified path through a proxy server.
  win_get_url:
    url: http://www.example.com/earthrise.jpg
    dest: C:\Users\RandomUser\earthrise.jpg
    proxy_url: http://10.0.0.1:8080
    proxy_username: username
    proxy_password: password

- name: Download file from FTP with authentication
  win_get_url:
    url: ftp://server/file.txt
    dest: '%TEMP%\ftp-file.txt'
    url_username: ftp-user
    url_password: ftp-password


###win_path – Manage Windows path environment variables
#Allows elementbased ordering, addition, and removal of Windows path environment variables.

Parameter 
    elements
        required
        A single path element, or a list of path elements (ie, directories) to add or remove.
        When multiple elements are included in the list (and state is present), the elements are guaranteed to appear in the same relative order in the resultant path value.
        Variable expansions (eg, %VARNAME%) are allowed, and are stored unexpanded in the target path element.
        Any existing path elements not mentioned in elements are always preserved in their current order.
        New path elements are appended to the path, and existing path elements may be moved closer to the end to satisfy the requested ordering.
        Paths are compared in a caseinsensitive fashion, and trailing backslashes are ignored for comparison purposes. However, note that trailing backslashes in YAML require quotes.
    name
        Default:PATH
        Target path environment variable name.
    scope
            Choices:
            machine (default)
            user
        The level at which the environment variable specified by name should be managed (either for the current user or global machine scope).
    state
            Choices:
            absent
            present
        Whether the path elements specified in elements should be present or absent.

##Examples - win_path
- name: Ensure that system32 and Powershell are present on the global system path, and in the specified order
  win_path:
    elements:
    - '%SystemRoot%\system32'
    - '%SystemRoot%\system32\WindowsPowerShell\v1.0'

- name: Ensure that C:\Program Files\MyJavaThing is not on the current user's CLASSPATH
  win_path:
    name: CLASSPATH
    elements: C:\Program Files\MyJavaThing
    scope: user
    state: absent


###win_reboot – Reboot a windows machine
#Reboot a Windows machine, wait for it to go down, come back up, and respond to commands.

Parameter 	
    connect_timeout
        integer
        Default:5
        Maximum seconds to wait for a single successful TCP connection to the WinRM endpoint before trying again
        aliases: connect_timeout_sec
    msg
        Default:Reboot initiated by Ansible
        Message to display to users
    post_reboot_delay
        integer
        Default:0
        Seconds to wait after the reboot was successful and the connection was reestablished
        This is useful if you want wait for something to settle despite your connection already working
        aliases: post_reboot_delay_sec
    pre_reboot_delay
        integer
        Default:2
        Seconds for shutdown to wait before requesting reboot
        aliases: pre_reboot_delay_sec
    reboot_timeout
        integer
        Default:600
        Maximum seconds to wait for machine to reappear on the network and respond to a test command
        This timeout is evaluated separately for both network appearance and test command success (so maximum clock time is actually twice this value)
        aliases: reboot_timeout_sec
    shutdown_timeout
        integer
        Default:600
        Maximum seconds to wait for shutdown to occur
        Increase this timeout for very slow hardware, large update applications, etc
        This option has been removed since Ansible 2.5 as the win_reboot behavior has changed
        aliases: shutdown_timeout_sec
    test_command
        Default:whoami
        Command to expect success for to determine the machine is ready for management



##Examples - win_reboot
# Unconditionally reboot the machine with all defaults
- win_reboot:

# Apply updates and reboot if necessary
- win_updates:
  register: update_result
- win_reboot:
  when: update_result.reboot_required

# Reboot a slow machine that might have lots of updates to apply
- win_reboot:
    reboot_timeout: 3600


###win_service – Manage and query Windows services
# Manage and query Windows services.
# For nonWindows targets, use the service module instead.

Parameter 	
    dependencies
        list
        A list of service dependencies to set for this particular service.
        This should be a list of service names and not the display name of the service.
        This works by dependency_action to either add/remove or set the services in this list.
    dependency_action
            Choices:
            add
            remove
            set (default)
        Used in conjunction with dependency to either add the dependencies to the existing service dependencies.
        Remove the dependencies to the existing dependencies.
        Set the dependencies to only the values in the list replacing the existing dependencies.
    description
        The description to set for the service.
    desktop_interact
        boolean
            Choices:
            no (default)
            yes
        Whether to allow the service user to interact with the desktop.
        This should only be set to yes when using the LocalSystem username.
    display_name
        The display name to set for the service.
    force_dependent_services
        boolean
            Choices:
            no (default)
            yes
        If yes, stopping or restarting a service with dependent services will force the dependent services to stop or restart also.
        If no, stopping or restarting a service with dependent services may fail.
    name
        required
        Name of the service.
        If only the name parameter is specified, the module will report on whether the service exists or not without making any changes.
    password
        The password to set the service to start as.
        This and the username argument must be supplied together.
        If specifying LocalSystem, NetworkService or LocalService this field must be an empty string and not null.
    path
        The path to the executable to set for the service.
    start_mode
            Choices:
            auto
            delayed
            disabled
            manual
        Set the startup type for the service.
    state
            Choices:
            absent
            paused
            started
            stopped
            restarted
        started/stopped/absent/pause are idempotent actions that will not run commands unless necessary.
        restarted will always bounce the service.
        Only services that support the paused state can be paused, you can check the return value can_pause_and_continue.
        You can only pause a service that is already started.
    username
        The username to set the service to start as.
        This and the password argument must be supplied together when using a local or domain account.
        Set to LocalSystem to use the SYSTEM account.


##Examples - win_service
- name: Restart a service
  win_service:
    name: spooler
    state: restarted

- name: Set service startup mode to auto and ensure it is started
  win_service:
    name: spooler
    start_mode: auto
    state: started

- name: Pause a service
  win_service:
    name: Netlogon
    state: paused

# a new service will also default to the following values:
# - username: LocalSystem
# - state: stopped
# - start_mode: auto
- name: Create a new service
  win_service:
    name: service name
    path: C:\temp\test.exe

- name: Create a new service with extra details
  win_service:
    name: service name
    path: C:\temp\test.exe
    display_name: Service Name
    description: A test service description

- name: Remove a service
  win_service:
    name: service name
    state: absent

- name: Check if a service is installed
  win_service:
    name: service name
  register: service_info

- name: Set the log on user to a domain account
  win_service:
    name: service name
    state: restarted
    username: DOMAIN\User
    password: Password

- name: Set the log on user to a local account
  win_service:
    name: service name
    state: restarted
    username: .\Administrator
    password: Password

- name: Set the log on user to Local System
  win_service:
    name: service name
    state: restarted
    username: LocalSystem
    password: ""

- name: Set the log on user to Local System and allow it to interact with the desktop
  win_service:
    name: service name
    state: restarted
    username: LocalSystem
    password: ""
    desktop_interact: yes

- name: Set the log on user to Network Service
  win_service:
    name: service name
    state: restarted
    username: NT AUTHORITY\NetworkService
    password: ""

- name: Set the log on user to Local Service
  win_service:
    name: service name
    state: restarted
    username: NT AUTHORITY\LocalService
    password: ""

- name: Set dependencies to ones only in the list
  win_service:
    name: service name
    dependencies: ['service1', 'service2']

- name: Add dependencies to existing dependencies
  win_service:
    name: service name
    dependencies: ['service1', 'service2']
    dependency_action: add

- name: Remove dependencies from existing dependencies
  win_service:
    name: service name
    dependencies: ['service1', 'service2']
    dependency_action: remove


###win_stat – Get information about Windows files
# Returns information about a Windows file.
# For nonWindows targets, use the stat module instead.

Parameter 	
    checksum_algorithm
            Choices:
            md5
            sha1 (default)
            sha256
            sha384
            sha512
        Algorithm to determine checksum of file. Will throw an error if the host is unable to use specified algorithm.
    get_checksum
        boolean
            Choices:
            no
            yes (default)
        Whether to return a checksum of the file (default sha1)
    get_md5
        boolean
            Choices:
            no (default)
            yes
        Whether to return the checksum sum of the file. Between Ansible 1.9 and 2.2 this is no longer an MD5, but a SHA1 instead. As of Ansible 2.3 this is back to an MD5. Will return None if host is unable to use specified algorithm.
        The default of this option changed from yes to no in Ansible 2.5 and will be removed altogether in Ansible 2.9.
        Use get_checksum=true with checksum_algorithm=md5 to return an md5 hash under the checksum return value.
    path
        path / required
        The full path of the file/object to get the facts of; both forward and back slashes are accepted.

##Examples - win_stat
- name: Obtain information about a file
  win_stat:
    path: C:\foo.ini
  register: file_info

- name: Obtain information about a folder
  win_stat:
    path: C:\bar
  register: folder_info

- name: Get MD5 checksum of a file
  win_stat:
    path: C:\foo.ini
    get_checksum: yes
    checksum_algorithm: md5
  register: md5_checksum

- debug:
    var: md5_checksum.stat.checksum

- name: Get SHA1 checksum of file
  win_stat:
    path: C:\foo.ini
    get_checksum: yes
  register: sha1_checksum

- debug:
    var: sha1_checksum.stat.checksum

- name: Get SHA256 checksum of file
  win_stat:
    path: C:\foo.ini
    get_checksum: yes
    checksum_algorithm: sha256
  register: sha256_checksum

- debug:
    var: sha256_checksum.stat.checksum


###win_shortcut – Manage shortcuts on Windows
#Create, manage and delete Windows shortcuts
Parameter 	
    args
        Additional arguments for the executable defined in src.
    description
        Description for the shortcut.
        This is usually shown when hoovering the icon.
    dest
        path / required
        Destination file for the shortcuting file.
        File name should have a .lnk or .url extension.
        directory
    path
        Working directory for executable defined in src.
    hotkey
        Key combination for the shortcut.
        This is a combination of one or more modifiers and a key.
        Possible modifiers are Alt, Ctrl, Shift, Ext.
        Possible keys are [AZ] and [09].
    icon
        path
        Icon used for the shortcut.
        File name should have a .ico extension.
        The file name is followed by a comma and the number in the library file (.dll) or use 0 for an image file.
    src
        Executable or URL the shortcut points to.
        The executable needs to be in your PATH, or has to be an absolute path to the executable.
    state
            Choices:
            absent
            present (default)
        When absent, removes the shortcut if it exists.
        When present, creates or updates the shortcut.
    windowstyle
            Choices:
            maximized
            minimized
            normal
        Influences how the application is displayed when it is launched.

##Examples - win_shortcut
- name: Create an application shortcut on the desktop
  win_shortcut:
    src: C:\Program Files\Mozilla Firefox\Firefox.exe
    dest: C:\Users\Public\Desktop\Mozilla Firefox.lnk
    icon: C:\Program Files\Mozilla Firefox\Firefox.exe,0

- name: Create the same shortcut using environment variables
  win_shortcut:
    description: The Mozilla Firefox web browser
    src: '%ProgramFiles%\Mozilla Firefox\Firefox.exe'
    dest: '%Public%\Desktop\Mozilla Firefox.lnk'
    icon: '%ProgramFiles\Mozilla Firefox\Firefox.exe,0'
    directory: '%ProgramFiles%\Mozilla Firefox'
    hotkey: Ctrl+Alt+F

- name: Create an application shortcut for an executable in PATH to your desktop
  win_shortcut:
    src: cmd.exe
    dest: Desktop\Command prompt.lnk

- name: Create an application shortcut for the Ansible website
  win_shortcut:
    src: '%ProgramFiles%\Google\Chrome\Application\chrome.exe'
    dest: '%UserProfile%\Desktop\Ansible website.lnk'
    args: --new-window https://ansible.com/
    directory: '%ProgramFiles%\Google\Chrome\Application'
    icon: '%ProgramFiles%\Google\Chrome\Application\chrome.exe,0'
    hotkey: Ctrl+Alt+A

- name: Create a URL shortcut for the Ansible website
  win_shortcut:
    src: https://ansible.com/
    dest: '%Public%\Desktop\Ansible website.url'


###template – Templates a file out to a remote server
#Templates are processed by the Jinja2 templating language (http://jinja.pocoo.org/docs/)  documentation on the template formatting can be found in the Template Designer Documentation (http://jinja.pocoo.org/docs/templates/).
#Six additional variables can be used in templates: 
#ansible_managed (configurable via the defaults section of ansible.cfg) 
#contains a string which can be used to describe the template name, host, modification time of the template file and the owner uid. 
#template_host contains the node name of the template’s machine. 
#template_uid is the numeric user id of the owner. 
#template_path is the path of the template. 
#template_fullpath is the absolute path of the template. 
#template_run_date is the date that the template was rendered.

Parameter 	
    attributes
        Attributes the file or directory should have. To get supported flags look at the man page for chattr on the target system. This string should contain the attributes in the same order as the one displayed by lsattr.
        = operator is assumed as default, otherwise + or  operators need to be included in the string.
        aliases: attr
    backup
        boolean
            Choices:
            no (default)
            yes
        Create a backup file including the timestamp information so you can get the original file back if you somehow clobbered it incorrectly.
    block_end_string
        Default:%}
        The string marking the end of a block.
    block_start_string
        Default:{%
        The string marking the beginning of a block.
    dest
        required
        Location to render the template to on the remote machine.
    follow
        boolean
            Choices:
            no (default)
            yes
        This flag indicates that filesystem links in the destination, if they exist, should be followed.
    force
        boolean
            Choices:
            no
            yes (default)
        the default is yes, which will replace the remote file when contents are different than the source. If no, the file will only be transferred if the destination does not exist.
    group
        Name of the group that should own the file/directory, as would be fed to chown.
    lstrip_blocks
        boolean
            Choices:
            no (default)
            yes
        If this is set to True leading spaces and tabs are stripped from the start of a line to a block. Setting this option to True requires Jinja2 version >=2.7.
    mode
        Mode the file or directory should be. For those used to /usr/bin/chmod remember that modes are actually octal numbers. You must either add a leading zero so that Ansible's YAML parser knows it is an octal number (like 0644 or 01777) or quote it (like '644' or '1777') so Ansible receives a string and can do its own conversion from string into number. Giving Ansible a number without following one of these rules will end up with a decimal number which will have unexpected results. As of version 1.8, the mode may be specified as a symbolic mode (for example, u+rwx or u=rw,g=r,o=r). As of version 2.6, the mode may also be the special string preserve. preserve means that the file will be given the same permissions as the source file.
    newline_sequence
            Choices:
            \n (default)
            \r
            \r\n
        Specify the newline sequence to use for templating files.
    output_encoding
        Default:utf8
        Overrides the encoding used to write the template file defined by dest.
        It defaults to 'utf8', but any encoding supported by python can be used.
        The source template file must always be encoded using 'utf8', for homogeneity.
    owner
        Name of the user that should own the file/directory, as would be fed to chown.
    selevel
        Default:s0
        Level part of the SELinux file context. This is the MLS/MCS attribute, sometimes known as the range. _default feature works as for seuser.
    serole
        Role part of SELinux file context, _default feature works as for seuser.
    setype
        Type part of SELinux file context, _default feature works as for seuser.
    seuser
        User part of SELinux file context. Will default to system policy, if applicable. If set to _default, it will use the user portion of the policy if available.
    src
        required
        Path of a Jinja2 formatted template on the Ansible controller. This can be a relative or absolute path.
    trim_blocks
        boolean
            Choices:
            no
            yes (default)
        If this is set to True the first newline after a block is removed (block, not variable tag!).
    unsafe_writes
        boolean
            Choices:
            no (default)
            yes
        By default this module uses atomic operations to prevent data corruption or inconsistent reads from the target files, but sometimes systems are configured or just broken in ways that prevent this. One example is docker mounted files, which cannot be updated atomically from inside the container and can only be written in an unsafe manner.
        This option allows Ansible to fall back to unsafe methods of updating files when atomic operations fail (however, it doesn't force Ansible to perform unsafe writes). IMPORTANT! Unsafe writes are subject to race conditions and can lead to data corruption.
    validate
        The validation command to run before copying into place. The path to the file to validate is passed in via '%s' which must be present as in the example below. The command is passed securely so shell features like expansion and pipes won't work.
    variable_end_string
        Default:}}
        The string marking the end of a print statement.
    variable_start_string
        Default:{{
        The string marking the beginning of a print statement.

##Examples - template 
# Example from Ansible Playbooks
- template:
    src: /mytemplates/foo.j2
    dest: /etc/file.conf
    owner: bin
    group: wheel
    mode: 0644

# The same example, but using symbolic modes equivalent to 0644
- template:
    src: /mytemplates/foo.j2
    dest: /etc/file.conf
    owner: bin
    group: wheel
    mode: "u=rw,g=r,o=r"

# Create a DOS-style text file from a template
- template:
    src: config.ini.j2
    dest: /share/windows/config.ini
    newline_sequence: '\r\n'

# Copy a new "sudoers" file into place, after passing validation with visudo
- template:
    src: /mine/sudoers
    dest: /etc/sudoers
    validate: '/usr/sbin/visudo -cf %s'

# Update sshd configuration safely, avoid locking yourself out
- template:
    src: etc/ssh/sshd_config.j2
    dest: /etc/ssh/sshd_config
    owner: root
    group: root
    mode: '0600'
    validate: /usr/sbin/sshd -t -f %s
    backup: yes

    
##Quick Templates 
{% ... %} 
    for Statements
{%- ... %} 
    for Statements, 
    the whitespaces before or after that block will be removed
    If seq was a list of numbers from 1 to 9, the output would be 123456789
    Note - can be start or end of a block 
    {% for item in seq -%}
        {{ item }}
    {%- endfor %}
{{ ... }} 
    for Expressions to print to the template output
{{- ... }} 
    the whitespaces before or after that block will be removed
{# ... #} for Comments not included in the template output

#variables 
{{ foo }}
{{ foo.bar }}
{{ foo['bar'] }}

#foo.bar in Jinja2 does the following things 
check for an attribute called bar on foo (getattr(foo, 'bar'))
if there is not, check for an item 'bar' in foo (foo.__getitem__('bar'))
if there is not, return an undefined object.
#foo['bar'] does the following things 
check for an item 'bar' in foo. (foo.__getitem__('bar'))
if there is not, check for an attribute called bar on foo. (getattr(foo, 'bar'))
if there is not, return an undefined object.

#Tests ( .. is ... )can accept arguments
#If the test only takes one argument, you can leave out the parentheses
{% if loop.index is divisibleby 3 %}
{% if loop.index is divisibleby(3) %}

#Comments
{# note: commented-out template 
    {% for user in users %}
        ...
    {% endfor %}
#}

#Whitespace Control
#In the default configuration:
a single trailing newline is stripped if present
other whitespace (spaces, tabs, newlines etc.) is returned unchanged
#options 
trim_blocks
    the first newline after a template tag is removed automatically 
lstrip_blocks 
    strip tabs and spaces from the beginning of a line to the start of a block
keep_trailing_newline
    To keep single trailing newlines
#For example, without the trim_blocks and lstrip_blocks options
<div>
    {% if True %}
        yay
    {% endif %}
</div>

#gets rendered with blank lines inside the div:
<div>

        yay

</div>

#with both trim_blocks and lstrip_blocks enabled
<div>
        yay
</div>

#manually disable the lstrip_blocks behavior by putting a plus sign (+) at the start of a block:
<div>
        {%+ if something %}yay{% endif %}
</div>

#With  minus sign (-) to the start or end of a block (e.g. a For tag), a comment, or a variable expression, 
#the whitespaces before or after that block will be removed:
#If seq was a list of numbers from 1 to 9, the output would be 123456789. 
{% for item in seq -%}
    {{ item }}
{%- endfor %}


#Escaping
{{ '{{' }}
#OR For bigger sections, eg to include jinja template inside a template
{% raw %}
    <ul>
    {% for item in seq %}
        <li>{{ item }}</li>
    {% endfor %}
    </ul>
{% endraw %}



#Base Template
#base.html 
{% block head %}
<title>{% block title %}{% endblock title %} - My Webpage</title>
{% endblock head%}

#child.html 
{% extends "base.html" %}
{% block title %}Index{% endblock title %}
{% block head %}
    {{ super() }}
    <style type="text/css">
        .important { color: #336699; }
    </style>
{% endblock head %}

##For
#'e' for escaping 
{% for user in users %}
  <li>{{ user.username|e }}</li>
{% endfor %}

#for dict 
<dl>
{% for key, value in my_dict.iteritems() %}
    <dt>{{ key|e }}</dt>
    <dd>{{ value|e }}</dd>
{% endfor %}
</dl>
#Inside of a for-loop block, access below special variables:
loop.index 	    The current iteration of the loop. (1 indexed)
loop.index0 	The current iteration of the loop. (0 indexed)
loop.revindex 	The number of iterations from the end of the loop (1 indexed)
loop.revindex0 	The number of iterations from the end of the loop (0 indexed)
loop.first 	    True if first iteration.
loop.last 	    True if last iteration.
loop.length 	The number of items in the sequence.
loop.cycle 	    A helper function to cycle between a list of sequences. 
loop.depth 	    Indicates how deep in a recursive loop the rendering currently is. Starts at level 1
loop.depth0 	Indicates how deep in a recursive loop the rendering currently is. Starts at level 0
loop.previtem 	The item from the previous iteration of the loop. Undefined during the first iteration.
loop.nextitem 	The item from the following iteration of the loop. Undefined during the last iteration.
loop.changed(*val) 	True if previously called with a different value (or not called at all).

#Within a for-loop, it's possible to cycle among a list of strings/variables 
#each time through the loop by using the special loop.cycle helper:

{% for row in rows %}
    <li class="{{ loop.cycle('odd', 'even') }}">{{ row }}</li>
{% endfor %}

#Unlike in Python, it's not possible to break or continue in a loop. 
#You can, however, filter the sequence during iteration, which allows you to skip items
{% for user in users if not user.hidden %}
    <li>{{ user.username|e }}</li>
{% endfor %}

#If no iteration took place because the sequence was empty 
#or the filtering removed all the items from the sequence, 
#you can render a default block by using else:

<ul>
{% for user in users %}
    <li>{{ user.username|e }}</li>
{% else %}
    <li><em>no users found</em></li>
{% endfor %}
</ul>

#It is also possible to use loops recursively. 
#add the 'recursive' modifier to the loop definition 
#and call the 'loop' variable with the new iterable where you want to recurse.

<ul class="sitemap">
{%- for item in sitemap recursive %}
    <li><a href="{{ item.href|e }}">{{ item.title }}</a>
    {%- if item.children -%}
        <ul class="submenu">{{ loop(item.children) }}</ul>
    {%- endif %}</li>
{%- endfor %}
</ul>

#The loop variable always refers to the closest (innermost) loop. 
#If we have more than one level of loops, rebind the variable loop 
#by  {% set outer_loop = loop %} after the loop eg the loop that we want to use recursively. 
#then, call it using {{ outer_loop(…) }}

#assignments in loops will be cleared at the end of the iteration and cannot outlive the loop scope. 

#To check whether some value has changed since the last iteration or will change in the next iteration, 
#use previtem and nextitem:

{% for value in values %}
    {% if loop.previtem is defined and value > loop.previtem %}
        The value just increased!
    {% endif %}
    {{ value }}
    {% if loop.nextitem is defined and loop.nextitem > value %}
        The value will increase even more!
    {% endif %}
{% endfor %}

#If you only care whether the value changed at all, using changed is even easier:
{% for entry in entries %}
    {% if loop.changed(entry.category) %}
        <h2>{{ entry.category }}</h2>
    {% endif %}
    <p>{{ entry.message }}</p>
{% endfor %}



##If
#anything non mepty is true like python 
{% if users %}
<ul>
{% for user in users %}
    <li>{{ user.username|e }}</li>
{% endfor %}
</ul>
{% endif %}

#For multiple branches
{% if kenny.sick %}
    Kenny is sick.
{% elif kenny.dead %}
    You killed Kenny!  You bastard!!!
{% else %}
    Kenny looks okay --- so far
{% endif %}


##Filter block 
{% filter upper %}
    This text becomes uppercase
{% endfilter %}

##Assignments
#Inside code blocks, you can also assign values to variables. 
#Assignments use the set tag and can have multiple targets:

{% set navigation = [('index.html', 'Index'), ('about.html', 'About')] %}
{% set key, value = call_something() %}

#Scoping Behavior
#it is not possible to set variables inside a block and have them show up outside of it. 
#This also applies to loops. 
#The only exception to that rule are if statements which do not introduce a scope. 

{% set iterated = false %}
{% for item in seq %}
    {{ item }}
    {% set iterated = true %}   {#<--- this is wrong , you canot set inside loop and get value outside #}
{% endfor %}
{% if not iterated %} did not iterate {% endif %}

#It is not possible with Jinja syntax to do this. 
#Instead use alternative constructs like the loop else block or the special loop variable:

{% for item in seq %}
    {{ item }}
{% else %}
    did not iterate
{% endfor %}

#As of version 2.10 Use namespace objects which allow propagating of changes across scopes:
#obj.attr notation in the set tag is only allowed for namespace objects; 
#attempting to assign an attribute on any other object will raise an exception.

{% set ns = namespace(found=false) %}
{% for item in items %}
    {% if item.check_something() %}
        {% set ns.found = true %}
    {% endif %}
    * {{ item.title }}
{% endfor %}
Found item having something: {{ ns.found }}


##Block Assignments
#it's possible to also use block assignments to capture the contents of a block into a variable name. 

{% set navigation %}
    <li><a href="/">Index</a>
    <li><a href="/downloads">Downloads</a>
{% endset %}

#Starting with Jinja 2.10, the block assignment supports filters.
{% set reply | wordwrap %}
    You wrote:
    {{ message }}
{% endset %}

##Include
#Included templates have access to the variables of the active context by default
#included template would be rendered as it is at that location 
{% include 'header.html' %}
    Body
{% include 'footer.html' %}

#you can mark an include with ignore missing; 
#in which case Jinja will ignore the statement if the template to be included does not exist. 
{% include "sidebar.html" ignore missing %}

##Literals
"Hello World"
'Hello World'
    Everything between two double or single quotes is a string. 
    They are useful whenever you need a string in the template 
    (e.g. as arguments to function calls and filters, or just to extend or include a template).
42 / 42.23
    Integers and floating point numbers are created by just writing the number down. 
    If a dot is present, the number is a float, otherwise an integer. Keep in mind that, in Python, 42 and 42.0 are different (int and float, respectively).
['list', 'of’, 'objects]
    Everything between two brackets is a list
('list', 'of’, 'objects)
    Tuples are like lists that cannot be modified . 
{'dict: 'of', ...}
    A dict in Python is a structure that combines keys and values. 
    Keys must be unique and always have exactly one value. 
true / false:
    true is always true and false is always false. 
    
##Math
+
    Adds two objects together. Usually the objects are numbers, but if both are strings or lists, you can concatenate them this way. This, however, is not the preferred way to concatenate strings! For string concatenation, have a look-see at the ~ operator. {{ 1 + 1 }} is 2.
-
    Subtract the second number from the first one. {{ 3 - 2 }} is 1.

/
    Divide two numbers. The return value will be a floating point number. {{ 1 / 2 }} is {{ 0.5 }}. (Just like from __future__ import division.)

//
    Divide two numbers and return the truncated integer result. {{ 20 // 7 }} is 2.

%
    Calculate the remainder of an integer division. {{ 11 % 7 }} is 4.
*
    Multiply the left operand with the right one. {{ 2 * 2 }} would return 4. This can also be used to repeat a string multiple times. {{ '=' * 80 }} would print a bar of 80 equal signs.
**
    Raise the left operand to the power of the right operand. {{ 2**3 }} would return 8.

##Comparisons
==
    Compares two objects for equality.
!=
    Compares two objects for inequality.
>
    true if the left hand side is greater than the right hand side.
>=
    true if the left hand side is greater or equal to the right hand side.

<
    true if the left hand side is lower than the right hand side.
<=
    true if the left hand side is lower or equal to the right hand side.

##Logic
and
    Return true if the left and the right operand are true.
or
    Return true if the left or the right operand are true.
not
    negate a statement (see below).
(expr)
    group an expression.
    
##Other Operators
in
    Perform a sequence / mapping containment test. Returns true if the left operand is contained in the right. {{ 1 in [1, 2, 3] }} would, for example, return true.
is
    Performs a test.
|
    Applies a filter.

~
    Converts all operands into strings and concatenates them.
    {{ "Hello " ~ name ~ "!" }} would return (assuming name is set to 'John') Hello John!.
()
    Call a callable: {{ post.render() }}. 
    Inside of the parentheses you can use positional arguments 
    and keyword arguments like in Python:
    {{ post.render(user, full=true) }}
. or []
    Get an attribute of an object.

##Autoescape Overrides
{% autoescape true %}
    Autoescaping is active within this block
{% endautoescape %}

{% autoescape false %}
    Autoescaping is inactive within this block
{% endautoescape %}

    
    

###win_template – Templates a file out to a remote server
#Templates are processed by the Jinja2 templating language (http://jinja.pocoo.org/docs/)  documentation on the template formatting can be found in the Template Designer Documentation (http://jinja.pocoo.org/docs/templates/).
#Six additional variables can be used in templates: ansible_managed (configurable via the defaults section of ansible.cfg) contains a string which can be used to describe the template name, host, modification time of the template file and the owner uid, template_host contains the node name of the template’s machine, template_uid the owner, template_path the absolute path of the template, template_fullpath is the absolute path of the template, and template_run_date is the date that the template was rendered. Note that including a string that uses a date in the template will result in the template being marked ‘changed’ each time.

Parameter 
    block_end_string
        Default:%}
        The string marking the end of a block.
    block_start_string
        Default:{%
        The string marking the beginning of a block.
    dest
        required
        Location to render the template to on the remote machine.
    force
        boolean
            Choices:
            no
            yes (default)
        If yes, will replace the remote file when contents are different from the source.
        If no, the file will only be transferred if the destination does not exist.
    newline_sequence
            Choices:
            \n
            \r
            \r\n (default)
        Specify the newline sequence to use for templating files.
    src
        required
        Path of a Jinja2 formatted template on the local server. This can be a relative or absolute path.
    trim_blocks
        boolean
            Choices:
            no (default)
            yes
        If this is set to yes the first newline after a block is removed (block, not variable tag!).
    variable_end_string
        Default:}}
        The string marking the end of a print statement.
    variable_start_string
        Default:{{
        The string marking the beginning of a print statement.

##Examples - win_template
- name: Create a file from a Jinja2 template
  win_template:
    src: /mytemplates/file.conf.j2
    dest: C:\Temp\file.conf

- name: Create a Unix-style file from a Jinja2 template
  win_template:
    src: unix/config.conf.j2
    dest: C:\share\unix\config.conf
    newline_sequence: '\n'


###service – Manage services
# Controls services on remote hosts. Supported init systems include BSD init, OpenRC, SysV, Solaris SMF, systemd, upstart.
# For Windows targets, use the win_service module instead.
Parameter 	
    arguments
        Additional arguments provided on the command line
        aliases: args
    enabled
        boolean
            Choices:
            no
            yes
        Whether the service should start on boot. At least one of state and enabled are required.
    name
        required
        Name of the service.
    pattern
        If the service does not respond to the  command, name a substring to look for as would be found in the output of the ps command as a standin for a  result. If the string is found, the service will be assumed to be started.
    runlevel
        Default:default
        For OpenRC init scripts (ex: Gentoo) only. The runlevel that this service belongs to.
    sleep
        If the service is being restarted then sleep this many seconds between the stop and start command. This helps to workaround badly behaving init scripts that exit immediately after signaling a process to stop.
    state
            Choices:
            reloaded
            restarted
            started
            stopped
        started/stopped are idempotent actions that will not run commands unless necessary. restarted will always bounce the service. reloaded will always reload. At least one of state and enabled are required. Note that reloaded will start the service if it is not already started, even if your chosen init system wouldn't normally.
    use
        Default:auto
        The service module actually uses system specific modules, normally through auto detection, this setting can force a specific module.
        Normally it uses the value of the 'ansible_service_mgr' fact and falls back to the old 'service' module when none matching is found.


##Examples - service
- name: Start service httpd, if not started
  service:
    name: httpd
    state: started

- name: Stop service httpd, if started
  service:
    name: httpd
    state: stopped

- name: Restart service httpd, in all cases
  service:
    name: httpd
    state: restarted

- name: Reload service httpd, in all cases
  service:
    name: httpd
    state: reloaded

- name: Enable service httpd, and not touch the state
  service:
    name: httpd
    enabled: yes

- name: Start service foo, based on running process /usr/bin/foo
  service:
    name: foo
    pattern: /usr/bin/foo
    state: started

- name: Restart network service for interface eth0
  service:
    name: network
    state: restarted
    args: eth0


###systemd – Manage services
# Controls systemd services on remote hosts.
# The below  are needed on the host that executes this module.
# A system managed by systemd.

Parameter 	
    daemon_reload
        boolean
            Choices:
            no (default)
            yes
        run daemonreload before doing any other operations, to make sure systemd has read any changes.
        aliases: daemonreload
    enabled
        boolean
            Choices:
            no
            yes
        Whether the service should start on boot. At least one of state and enabled are required.
    force
        boolean
            Choices:
            no
            yes
        Whether to override existing symlinks.
    masked
        boolean
            Choices:
            no
            yes
        Whether the unit should be masked or not, a masked unit is impossible to start.
    name
        Name of the service. When using in a chroot environment you always need to specify the full name i.e. (crond.service).
        aliases: service, unit
    no_block
        boolean
            Choices:
            no (default)
            yes
        Do not synchronously wait for the requested operation to finish. Enqueued job will continue without Ansible blocking on its completion.
    scope
            Choices:
            system (default)
            user
            global
        run systemctl within a given service manager scope, either as the default system scope (system), the current user's scope (user), or the scope of all users (global).
        For systemd to work with 'user', the executing user must have its own instance of dbus started (systemd requirement). The user dbus process is normally started during normal login, but not during the run of Ansible tasks. Otherwise you will probably get a 'Failed to connect to bus: no such file or directory' error.
    state
            Choices:
            reloaded
            restarted
            started
            stopped
        started/stopped are idempotent actions that will not run commands unless necessary. restarted will always bounce the service. reloaded will always reload.
    user
        boolean
            Choices:
            no (default)
            yes
        (deprecated) run ``systemctl`` talking to the service manager of the calling user, rather than the service manager of the system.
        This option is deprecated and will eventually be removed in 2.11. The ``scope`` option should be used instead.

##Examples - systemd
- name: Make sure a service is running
  systemd:
    state: started
    name: httpd

- name: stop service cron on debian, if running
  systemd:
    name: cron
    state: stopped

- name: restart service cron on centos, in all cases, also issue daemon-reload to pick up config changes
  systemd:
    state: restarted
    daemon_reload: yes
    name: crond

- name: reload service httpd, in all cases
  systemd:
    name: httpd
    state: reloaded

- name: enable service httpd and ensure it is not masked
  systemd:
    name: httpd
    enabled: yes
    masked: no

- name: enable a timer for dnf-automatic
  systemd:
    name: dnf-automatic.timer
    state: started
    enabled: yes

- name: just force systemd to reread configs (2.4 and above)
  systemd:
    daemon_reload: yes
    
###assert – Asserts given expressions are true
# This module asserts that given expressions are true with an optional custom message.
# This module is also supported for Windows targets.


##Examples - assert

- assert: { that: "ansible_os_family != 'RedHat'" }

- assert:
    that:
      - "'foo' in some_command_result.stdout"
      - "number_of_the_counting == 3"

- name: after version 2.7 both 'msg' and 'fail_msg' can customize failing assertion message
  assert:
    that:
      - "my_param <= 100"
      - "my_param >= 0"
    fail_msg: "'my_param' must be between 0 and 100"
    success_msg: "'my_param' is between 0 and 100"

- name: please use 'msg' when ansible version is smaller than 2.7
  assert:
    that:
      - "my_param <= 100"
      - "my_param >= 0"
    msg: "'my_param' must be between 0 and 100"


###fail – Fail with custom message
# This module fails the progress with a custom message. It can be useful for bailing out when a certain condition is met using when.
# This module is also supported for Windows targets.

##Examples - fail
# Example playbook using fail and when together

- fail:
    msg: "The system may not be provisioned according to the CMDB status."
  when: cmdb_status != "to-be-staged"
  
###pause – Pause playbook execution
# Pauses playbook execution for a set amount of time, or until a prompt is acknowledged. All parameters are optional. The default behavior is to pause with a prompt.
# To pause/wait/sleep per host, use the wait_for module.
# You can use ctrl+c if you wish to advance a pause earlier than it is set to expire or if you need to abort a playbook run entirely. To continue early press ctrl+c and then c. To abort a playbook press ctrl+c and then a.
# The pause module integrates into async/parallelized playbooks without any special considerations (see Rolling Updates). When using pauses with the serial playbook parameter (as in rolling updates) you are only prompted once for the current group of hosts.
# This module is also supported for Windows targets.

##Examples - pause
# Pause for 5 minutes to build app cache.
- pause:
    minutes: 5

# Pause until you can verify updates to an application were successful.
- pause:

# A helpful reminder of what to look out for post-update.
- pause:
    prompt: "Make sure org.foo.FooOverload exception is not present"

# Pause to get some sensitive input.
- pause:
    prompt: "Enter a secret"
    echo: no
  
  
###set_fact – Set host facts from a task
# This module allows setting new variables. Variables are set on a host-by-host basis just like facts discovered by the setup module.
# These variables will be available to subsequent plays during an ansible-playbook run, but will not be saved across executions even if you use a fact cache.
# Per the standard Ansible variable precedence rules, many other types of variables have a higher priority, so this value may be overridden. See Variable Precedence Guide for more information.
# This module is also supported for Windows targets.


##Examples - set_fact
# Example setting host facts using key=value pairs, note that this always creates strings or booleans
- set_fact: one_fact="something" other_fact="{{ local_var }}"

# Example setting host facts using complex arguments
- set_fact:
     one_fact: something
     other_fact: "{{ local_var * 2 }}"
     another_fact: "{{ some_registered_var.results | map(attribute='ansible_facts.some_fact') | list }}"

# Example setting facts so that they will be persisted in the fact cache
- set_fact:
    one_fact: something
    other_fact: "{{ local_var * 2 }}"
    cacheable: true

# As of 1.8, Ansible will convert boolean strings ('true', 'false', 'yes', 'no')
# to proper boolean values when using the key=value syntax, however it is still
# recommended that booleans be set using the complex argument style:
- set_fact:
    one_fact: true
    other_fact: false
  
  
###set_stats – Set stats for the current ansible run
# This module allows setting/accumulating stats on the current ansible run, either per host or for all hosts in the run.
# This module is also supported for Windows targets.


##Examples - set_stats
# Aggregating packages_installed stat per host
- set_stats:
    data:
      packages_installed: 31

# Aggregating random stats for all hosts using complex arguments
- set_stats:
    data:
      one_stat: 11
      other_stat: "{{ local_var * 2 }}"
      another_stat: "{{ some_registered_var.results | map(attribute='ansible_facts.some_fact') | list }}"
    per_host: no


# setting stats (not aggregating)
- set_stats:
    data:
      the_answer: 42
    aggregate: no
  
  
###wait_for – Waits for a condition before continuing
# You can wait for a set amount of time timeout, this is the default if nothing is specified or just timeout is specified. This does not produce an error.
# Waiting for a port to become available is useful for when services are not immediately available after their init scripts return which is true of certain Java application servers. It is also useful when starting guests with the virt module and needing to pause until they are ready.
# This module can also be used to wait for a regex match a string to be present in a file.
# In 1.6 and later, this module can also be used to wait for a file to be available or absent on the filesystem.
# In 1.8 and later, this module can also be used to wait for active connections to be closed before continuing, useful if a node is being rotated out of a load balancer pool.
# For Windows targets, use the win_wait_for module instead.




##Examples - wait_for
- name: sleep for 300 seconds and continue with play
  wait_for: timeout=300
  delegate_to: localhost

- name: Wait for port 8000 to become open on the host, don't start checking for 10 seconds
  wait_for:
    port: 8000
    delay: 10

- name: Waits for port 8000 of any IP to close active connections, don't start checking for 10 seconds
  wait_for:
    host: 0.0.0.0
    port: 8000
    delay: 10
    state: drained

- name: Wait for port 8000 of any IP to close active connections, ignoring connections for specified hosts
  wait_for:
    host: 0.0.0.0
    port: 8000
    state: drained
    exclude_hosts: 10.2.1.2,10.2.1.3

- name: Wait until the file /tmp/foo is present before continuing
  wait_for:
    path: /tmp/foo

- name: Wait until the string "completed" is in the file /tmp/foo before continuing
  wait_for:
    path: /tmp/foo
    search_regex: completed

- name: Wait until the lock file is removed
  wait_for:
    path: /var/lock/file.lock
    state: absent

- name: Wait until the process is finished and pid was destroyed
  wait_for:
    path: /proc/3466/status
    state: absent

- name: Output customized message when failed
  wait_for:
    path: /tmp/foo
    state: present
    msg: Timeout to find file /tmp/foo

# Don't assume the inventory_hostname is resolvable and delay 10 seconds at start
- name: Wait 300 seconds for port 22 to become open and contain "OpenSSH"
  wait_for:
    port: 22
    host: '{{ (ansible_ssh_host|default(ansible_host))|default(inventory_hostname) }}'
    search_regex: OpenSSH
    delay: 10
  connection: local

# Same as above but you normally have ansible_connection set in inventory, which overrides 'connection'
- name: Wait 300 seconds for port 22 to become open and contain "OpenSSH"
  wait_for:
    port: 22
    host: '{{ (ansible_ssh_host|default(ansible_host))|default(inventory_hostname) }}'
    search_regex: OpenSSH
    delay: 10
  vars:
    ansible_connection: local
    
###wait_for_connection – Waits until remote system is reachable/usable
# Waits for a total of timeout seconds.
# Retries the transport connection after a timeout of connect_timeout.
# Tests the transport connection every sleep seconds.
# This module makes use of internal ansible transport (and configuration) and the ping/win_ping module to guarantee correct end-to-end functioning.
# This module is also supported for Windows targets.



##Examples - wait_for_connection
- name: Wait 600 seconds for target connection to become reachable/usable
  wait_for_connection:

- name: Wait 300 seconds, but only start checking after 60 seconds
  wait_for_connection:
    delay: 60
    timeout: 300

# Wake desktops, wait for them to become ready and continue playbook
- hosts: all
  gather_facts: no
  tasks:
  - name: Send magic Wake-On-Lan packet to turn on individual systems
    wakeonlan:
      mac: '{{ mac }}'
      broadcast: 192.168.0.255
    delegate_to: localhost

  - name: Wait for system to become reachable
    wait_for_connection:

  - name: Gather facts for first time
    setup:

# Build a new VM, wait for it to become ready and continue playbook
- hosts: all
  gather_facts: no
  tasks:
  - name: Clone new VM, if missing
    vmware_guest:
      hostname: '{{ vcenter_ipaddress }}'
      name: '{{ inventory_hostname_short }}'
      template: Windows 2012R2
      customization:
        hostname: '{{ vm_shortname }}'
        runonce:
        - powershell.exe -ExecutionPolicy Unrestricted -File C:\Windows\Temp\ConfigureRemotingForAnsible.ps1 -ForceNewSSLCert -EnableCredSSP
    delegate_to: localhost

  - name: Wait for system to become reachable over WinRM
    wait_for_connection:
      timeout: 900

  - name: Gather facts for first time
    setup:
    
    
###group_by – Create Ansible groups based on facts
#anisble groups contain hosts, so use 'add_host'
#Use facts to create ad-hoc groups that can be used later in a playbook.
#This module is also supported for Windows targets.
#Spaces in group names are converted to dashes ‘-‘.
#This module is also supported for Windows targets


Parameter
    key
        required
        The variables whose values will be used as groups
    parents
        Default:all
        The list of the parent groups


##Examples - group_by 

# Create groups based on the machine architecture
- group_by:
    key: machine_{{ ansible_machine }}

# Create groups like 'virt_kvm_host'
- group_by:
    key: virt_{{ ansible_virtualization_type }}_{{ ansible_virtualization_role }}

# Create nested groups
- group_by:
    key: el{{ ansible_distribution_major_version }}-{{ ansible_architecture }}
    parents:
      - el{{ ansible_distribution_major_version }}

###user – Manage user accounts
# Manage user accounts and user attributes.
# For Windows targets, use the win_user module instead.

##Examples - user 
- name: Add the user 'johnd' with a specific uid and a primary group of 'admin'
  user:
    name: johnd
    comment: John Doe
    uid: 1040
    group: admin

- name: Add the user 'james' with a bash shell, appending the group 'admins' and 'developers' to the user's groups
  user:
    name: james
    shell: /bin/bash
    groups: admins,developers
    append: yes

- name: Remove the user 'johnd'
  user:
    name: johnd
    state: absent
    remove: yes

- name: Create a 2048-bit SSH key for user jsmith in ~jsmith/.ssh/id_rsa
  user:
    name: jsmith
    generate_ssh_key: yes
    ssh_key_bits: 2048
    ssh_key_file: .ssh/id_rsa

- name: Added a consultant whose account you want to expire
  user:
    name: james18
    shell: /bin/zsh
    groups: developers
    expires: 1422403387

- name: starting at version 2.6, modify user, remove expiry time
  user:
    name: james18
    expires: -1
    
    
###net_ping – Tests reachability using ping from a network device
# Tests reachability using ping from network device to a remote destination.
# For Windows targets, use the win_ping module instead.
# For targets running Python, use the ping module instead.

##Examples - net_ping 
- name: Test reachability to 10.10.10.10 using default vrf
  net_ping:
    dest: 10.10.10.10

- name: Test reachability to 10.20.20.20 using prod vrf
  net_ping:
    dest: 10.20.20.20
    vrf: prod

- name: Test unreachability to 10.30.30.30 using default vrf
  net_ping:
    dest: 10.30.30.30
    state: absent

- name: Test reachability to 10.40.40.40 using prod vrf and setting count and source
  net_ping:
    dest: 10.40.40.40
    source: loopback0
    vrf: prod
    count: 20

###add_host – add a host (and alternatively a group) to the ansible-playbook in-memory inventory
#Use variables to create new hosts and groups in inventory for use in later plays of the same playbook. Takes variables so you can define the new hosts more fully.
#This module is also supported for Windows targets.


# This module bypasses the play host loop and only runs once for all the hosts in the play, if you need it to iterate use a with_ directive.

# The alias ‘host’ of the parameter ‘name’ is only available on >=2.4
# Since Ansible version 2.4, the inventory_dir variable is now set to None instead of the ‘global inventory source’, because you can now have multiple sources. An example was added that shows how to partially restore the previous behaviour.

##Examples - add_host

- name: add host to group 'just_created' with variable foo=42
  add_host:
    name: "{{ ip_from_ec2 }}"
    groups: just_created
    foo: 42

- name: add host to multiple groups
  add_host:
    hostname: "{{ new_ip }}"
    groups:
      - group1
      - group2

- name: add a host with a non-standard port local to your machines
  add_host:
    name: "{{ new_ip }}:{{ new_port }}"

- name: add a host alias that we reach through a tunnel (Ansible <= 1.9)
  add_host:
    hostname: "{{ new_ip }}"
    ansible_ssh_host: "{{ inventory_hostname }}"
    ansible_ssh_port: "{{ new_port }}"

- name: add a host alias that we reach through a tunnel (Ansible >= 2.0)
  add_host:
    hostname: "{{ new_ip }}"
    ansible_host: "{{ inventory_hostname }}"
    ansible_port: "{{ new_port }}"

- name: Ensure inventory vars are set to the same value as the inventory_hostname has (close to pre 2.4 behaviour)
  add_host:
    hostname: charlie
    inventory_dir: "{{inventory_dir}}"

###meta – Execute Ansible ‘actions’
#Meta tasks are a special kind of task which can influence Ansible internal execution or state. Prior to Ansible 2.0, the only meta option available was flush_handlers. As of 2.2, there are five meta tasks which can be used. Meta tasks can be used anywhere within your playbook.
#This module is also supported for Windows targets.

1.flush_handlers makes Ansible run any handler tasks which have thus far been notified. 
  Ansible inserts these tasks internally at certain points to implicitly trigger handler runs 
  (after pre/post tasks, the final role execution, and the main tasks section of your plays).
2.refresh_inventory (added in 2.0) forces the reload of the inventory, 
  which in the case of dynamic inventory scripts means they will be re-executed. 
  If the dynamic inventory script is using a cache, 
  Ansible cannot know this and has no way of refreshing it 
  (you can disable the cache or, if available for your specific inventory datasource 
  (for es.: aws), you can use the an inventory plugin instead of an inventory script). 
  This is mainly useful when additional hosts are created and users wish to use them 
  instead of using the `add_host` module."
3.noop (added in 2.0) This literally does 'nothing'. 
  It is mainly used internally and not recommended for general use.
4.clear_facts (added in 2.1) causes the gathered facts for the hosts specified 
  in the play's list of hosts to be cleared, including the fact cache.
5.clear_host_errors (added in 2.1) clears the failed state (if any) 
  from hosts specified in the play's list of hosts.
6.end_play (added in 2.2) causes the play to end without failing the host(s). 
  Note that this affects all hosts.
7.reset_connection (added in 2.3) interrupts a persistent connection 
  (i.e. ssh + control persist)


##Examples - meta 

- template:
    src: new.j2
    dest: /etc/config.txt
  notify: myhandler
- name: force all notified handlers to run at this point, not waiting for normal sync points
  meta: flush_handlers

- name: reload inventory, useful with dynamic inventories when play makes changes to the existing hosts
  cloud_guest:            # this is fake module
    name: newhost
    state: present
- name: Refresh inventory to ensure new instaces exist in inventory
  meta: refresh_inventory

- name: Clear gathered facts from all currently targeted hosts
  meta: clear_facts

- name: bring host back to play after failure
  copy:
    src: file
    dest: /etc/file
  remote_user: imightnothavepermission

- meta: clear_host_errors

- user: name={{ansible_user}} groups=input
- name: reset ssh connection to allow user changes to affect 'current login user'
  meta: reset_connection

###lineinfile – Manage lines in text files
#This module ensures a particular line is in a file, or replace an existing line using a back-referenced regular expression.

#This is primarily useful when you want to change a single line in a file only. 
#See the replace module if you want to change multiple, similar lines 
#or check blockinfile if you want to insert/update/remove a block of lines in a file. 
#For other cases, see the copy or template modules.

##Examples - lineinfile
# Before 2.3, option 'dest', 'destfile' or 'name' was used instead of 'path'
- lineinfile:
    path: /etc/selinux/config
    regexp: '^SELINUX='
    line: 'SELINUX=enforcing'

- lineinfile:
    path: /etc/sudoers
    state: absent
    regexp: '^%wheel'

# Searches for a line that begins with 127.0.0.1 and replaces it with the value of the 'line' parameter
- lineinfile:
    path: /etc/hosts
    regexp: '^127\.0\.0\.1'
    line: '127.0.0.1 localhost'
    owner: root
    group: root
    mode: 0644

- lineinfile:
    path: /etc/httpd/conf/httpd.conf
    regexp: '^Listen '
    insertafter: '^#Listen '
    line: 'Listen 8080'

- lineinfile:
    path: /etc/services
    regexp: '^# port for http'
    insertbefore: '^www.*80/tcp'
    line: '# port for http by default'

# Add a line to a file if the file does not exist, without passing regexp
- lineinfile:
    path: /tmp/testfile
    line: '192.168.1.99 foo.lab.net foo'
    create: yes

# Fully quoted because of the ': ' on the line. See the Gotchas in the YAML docs.
- lineinfile:
    path: /etc/sudoers
    state: present
    regexp: '^%wheel\s'
    line: '%wheel ALL=(ALL) NOPASSWD: ALL'

# Yaml requires escaping backslashes in double quotes but not in single quotes
- lineinfile:
    path: /opt/jboss-as/bin/standalone.conf
    regexp: '^(.*)Xms(\\d+)m(.*)$'
    line: '\1Xms${xms}m\3'
    backrefs: yes

# Validate the sudoers file before saving
- lineinfile:
    path: /etc/sudoers
    state: present
    regexp: '^%ADMIN ALL='
    line: '%ADMIN ALL=(ALL) NOPASSWD: ALL'
    validate: '/usr/sbin/visudo -cf %s'
    
###blockinfile – Insert/update/remove a text block surrounded by marker lines
#This module will insert/update/remove a block of multi-line text surrounded by customizable marker lines.
#When using ‘with_*’ loops be aware that if you do not set a unique mark the block will be overwritten on each iteration.
#As of Ansible 2.3, the dest option has been changed to path as default, but dest still works as well.
#Option follow has been removed in version 2.5, because this module modifies the contents of the file so follow=no doesn’t make sense.
#When more then one block should be handled in one file you must change the marker per task

##Examples - blockinfile

# Before 2.3, option 'dest' or 'name' was used instead of 'path'
- name: insert/update "Match User" configuration block in /etc/ssh/sshd_config
  blockinfile:
    path: /etc/ssh/sshd_config
    block: |
      Match User ansible-agent
      PasswordAuthentication no

- name: insert/update eth0 configuration stanza in /etc/network/interfaces
        (it might be better to copy files into /etc/network/interfaces.d/)
  blockinfile:
    path: /etc/network/interfaces
    block: |
      iface eth0 inet static
          address 192.0.2.23
          netmask 255.255.255.0

- name: insert/update configuration using a local file and validate it
  blockinfile:
    block: "{{ lookup('file', './local/ssh_config') }}"
    dest: "/etc/ssh/ssh_config"
    backup: yes
    validate: "/usr/sbin/sshd -T -f %s"

- name: insert/update HTML surrounded by custom markers after <body> line
  blockinfile:
    path: /var/www/html/index.html
    marker: "<!-- {mark} ANSIBLE MANAGED BLOCK -->"
    insertafter: "<body>"
    content: |
      <h1>Welcome to {{ ansible_hostname }}</h1>
      <p>Last updated on {{ ansible_date_time.iso8601 }}</p>

- name: remove HTML as well as surrounding markers
  blockinfile:
    path: /var/www/html/index.html
    marker: "<!-- {mark} ANSIBLE MANAGED BLOCK -->"
    content: ""

- name: Add mappings to /etc/hosts
  blockinfile:
    path: /etc/hosts
    block: |
      {{ item.ip }} {{ item.name }}
    marker: "# {mark} ANSIBLE MANAGED BLOCK {{ item.name }}"
  with_items:
    - { name: host1, ip: 10.10.1.10 }
    - { name: host2, ip: 10.10.1.11 }
    - { name: host3, ip: 10.10.1.12 }

###include_vars – Load variables from files, dynamically within a task
#Loads variables from a YAML/JSON files dynamically from within a file or from a directory recursively during task runtime. If loading a directory, the files are sorted alphabetically before being loaded.
#This module is also supported for Windows targets.

##Examples - include_vars

- name: Include vars of stuff.yaml into the 'stuff' variable (2.2).
  include_vars:
    file: stuff.yaml
    name: stuff

- name: Conditionally decide to load in variables into 'plans' when x is 0, otherwise do not. (2.2)
  include_vars:
    file: contingency_plan.yaml
    name: plans
  when: x == 0

- name: Load a variable file based on the OS type, or a default if not found. Using free-form to specify the file.
  include_vars: "{{ item }}"
  with_first_found:
    - "{{ ansible_distribution }}.yaml"
    - "{{ ansible_os_family }}.yaml"
    - default.yaml

- name: Bare include (free-form)
  include_vars: myvars.yaml

- name: Include all .json and .jsn files in vars/all and all nested directories (2.3)
  include_vars:
    dir: vars/all
    extensions:
        - json
        - jsn

- name: Include all default extension files in vars/all and all nested directories and save the output in test. (2.2)
  include_vars:
    dir: vars/all
    name: test

- name: Include default extension files in vars/services (2.2)
  include_vars:
    dir: vars/services
    depth: 1

- name: Include only files matching bastion.yaml (2.2)
  include_vars:
    dir: vars
    files_matching: bastion.yaml

- name: Include all .yaml files except bastion.yaml (2.3)
  include_vars:
    dir: vars
    ignore_files: [bastion.yaml]
    extensions: [yaml]


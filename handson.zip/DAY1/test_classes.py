#Execute 
#pytest -v test_classes.py
#OR with coverage 
#pytest -v  --cov=classes --cov-report term-missing test_classes.py

#Get test ids 
#pytest --collect-only test_classes.py

#Testcase - func with test prefix 
#test suite - class with Test prefix 
'''
Lots of options 
$ pytest --help 

$ pytest -v test_userh.py
#check default markers
pytest --markers  
#check default fixtures 
pytest --fixtures


To check scope 
https://docs.pytest.org/en/stable/fixture.html#fixture-scopes

#to output of  stdout
$ pytest -v -s test_userh.py

#to check builtin fixture 
 
         
#For running marker
pytest -v -m addl
pytest -v -m "not addl"

#request is optional and it contains few requestng functions 
https://docs.pytest.org/en/stable/fixture.html#fixtures-can-introspect-the-requesting-test-context
If you put print inside test, it would not print as it captures 
pytest -s            # disable all capturing


pytest -k stringexpr # only run tests with names that match the
                     # "stringExpression", e.g. "MyClass and not method"
                     # will select TestMyClass.test_something
                     # but not TestMyClass.test_method_simple
pytest test_mod.py::test_func # only run tests that match the "node ID",
                              # e.g. "test_mod.py::test_func" will select
                              # only test_func in test_mod.py
pytest test_mod.py::TestClass::test_method # run a single method in
                                             # a single class
                                             
#string expr could be
"stringexpr"
"not stringexpr"
"stringexpr1 and stringexpr2"
"stringexpr1 and not stringexpr2"
"stringexpr1 or stringexpr2"
                               
#Selecting test based on id 
#pytest -v -k "silver" test_userh.py 
#pytest -v -k "not silver" test_userh.py 
#pytest -v -k "silver or another" test_userh.py 
#pytest --collect-only  test_userh.py 
#pytest -v test_userh.py::testMany


Filter 
    -k option 
        pytest -k "silver and testMany" -v test_classes.py
    markers 
        https://docs.pytest.org/en/6.2.x/skipping.html
Fixture 
    test data 
Table testing /parametric testing 

Mock Testing 
    https://docs.pytest.org/en/6.2.x/monkeypatch.html
Skipping test 
Testing exception 
    https://docs.pytest.org/en/6.2.x/assert.html
'''


from classes import * 
import pytest 

class TestUsers:
    def test_normal_user(self, amounts):
        u = NormalUser("Normal", 100)
        #amounts = [100, -200, 300, -400, 400]
        for am in amounts:
            u.transact(am)
        assert u.balance == 700  #Pass 
        
    #update for GoldUser and SilverUser 

    def test_gold_user(self, amounts):
        u = GoldUser("Gold", 100)
        #amounts = [100, -200, 300, -400, 400]
        for am in amounts:
            u.transact(am)
        assert u.balance == 710  #Pass 
        
    def test_silver_user(self, amounts):
        u = SilverUser("Silver", 100)
        #amounts = [100, -200, 300, -400, 400]
        for am in amounts:
            u.transact(am)
        assert u.balance == 706  #Pass 
        
#
def test_ba_str():
    ba = BankAccount(100)
    assert str(ba) == "BankAccount(100)"
    
def test_count_users():
    BankUser.how_many_users = 0
    users = [GoldUser("Gold", 100), 
             SilverUser("Silver", 100), 
             NormalUser("Normal", 100), ]
    assert BankUser.count_of_users() == 3
    
#Table testing 
@pytest.mark.parametrize("user,transactions,result",[
    (SilverUser("Silver", 100) , [100, -200, 300, -400, 400] , 706),
    (GoldUser("Gold", 100) , [100, -200, 300, -400, 400] , 710),
    ],
    ids=["silver", "another"]
)
def testMany(user,transactions,result):
    for am in transactions:
        user.transact(am)
    assert user.balance == result
    

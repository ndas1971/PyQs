import spacy 
nlp = spacy.load('en_core_web_md')  # make sure to use larger model!
tokens = nlp(u'dog cat banana')

print("higher is more similar")
for token1 in tokens:
    for token2 in tokens:
        print(token1.text, token2.text, token1.similarity(token2))

print("or with doc")
doc1 = nlp("That person is dying")
doc2 = nlp("That person is dead")
doc3 = nlp("I love dog")
print("'That person is dying' vs 'That person is dead'", doc1.similarity(doc2), #.96
"'I love dog' vs 'That person is dying'", doc3.similarity(doc1)) #.63

#(higher is more similar) 
        # dog    cat     banana
# dog     1.00    0.80    0.24  
# cat     0.80    1.00    0.28  
# banana  0.24    0.28    1.00  


print('Similarity is determined by comparing word vectors or "word embeddings"(document term matrix)') 
print(doc1.vector)
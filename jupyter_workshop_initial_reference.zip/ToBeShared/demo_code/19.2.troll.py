from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt


df = pd.read_csv("https://raw.githubusercontent.com/ndas1971/Misc/master/troll.csv")

#Each row is a comment. 
#We will consider two columns: whether the comment is insulting (1) or not (0) 
#and the unicode-encoded contents of the comment:
df[['Insult', 'Comment']].tail()

#define the feature matrix X and the labels y:
X_orig = df['Comment']
y = df['Insult']

tf = TfidfVectorizer()
X = tf.fit_transform(X_orig)
print("X.shape", X.shape)

#(3947, 16469)  #There are 3947 comments and 16469 different words. 

#Let's estimate the sparsity of feature matrix, X(sparse)
#X.nnz = The number of nonzero elements in this array.
p = 100 * X.nnz / float(X.shape[0] * X.shape[1])
print(f"Sparsity of feature matrix after TfidfVectorizer: Each sample has ~{p:.2f}% non-zero features.")

#Each sample has ~0.15% non-zero features.

#train a classifier 
(X_train, X_test, y_train, y_test) =  train_test_split(X, y, test_size=.2)

#use a Bernoulli Naive Bayes classifier with a grid search on the α
bnb = GridSearchCV(BernoulliNB(),{'alpha': np.logspace(-2., 2., 50)})
bnb.fit(X_train, y_train)

#check the performance of this classifier on the test dataset:
bnb.score(X_test, y_test)
#0.761

#Create Two pipeline with ngram range , 
#Use PCA for sparse matrix ie TruncatedSVD as X would be highly sparse , else long time 
# pipe1 = Pipeline([
#     ('bow',CountVectorizer(ngram_range=(1, 2))), 
#     ('tfidf',TfidfTransformer()), #('pca', TruncatedSVD(n_components=1000)), #takes longer 
#     ('std', StandardScaler(with_mean=False)), #not to break sparsity 
#     ('clf',SGDClassifier(tol=1e-3)) ])  #has alpha 
# 
# pipe2 = Pipeline([
#     ('bow',CountVectorizer(ngram_range=(1, 2))), 
#     ('tfidf',TfidfTransformer()),  #('pca', TruncatedSVD(n_components=1000)), #takes longer 
#     ('std', MaxAbsScaler()),  #[-1, 1] such that binarize=0.0 works (BernoulliNB works with only binary features)
#     ('clf',BernoulliNB(binarize=0.0)) ])
# 
# (X_train1, X_test1, y_train1, y_test1) =  train_test_split(X_orig, y, test_size=.2, random_state=0)
# bnb1 = RandomizedSearchCV(pipe1,{'clf__alpha': np.logspace(-2., 2., 50)})
# bnb2 = RandomizedSearchCV(pipe2,{'clf__alpha': np.logspace(-2., 2., 50)})
# bnb1.fit(X_train1, y_train1)
# bnb2.fit(X_train1, y_train1)
# print("Performance of this classifier on the test dataset(SGDClassifier vs BernoulliNB):\n",
# bnb1.score(X_test1, y_test1),bnb2.score(X_test1, y_test1))
# #(0.8, 0.8189873417721519)

#Let's take a look at the words corresponding to the largest coefficients 
#(the words we find frequently in insulting comments):
# We first get the words corresponding to each feature
names = np.asarray(tf.get_feature_names())
# Next, we display the 50 words with the largest coefficients
#argsort: Returns the indices that would sort an array
print("the 50 troll words with the largest coefficients: ", ','.join(names[np.argsort( bnb.best_estimator_.coef_[0, :])[::-1][:50]]))

#you,are,your,to,the,and,of,that,is,in,it,like,have,on,not,for,just,re,with,be,an,so,this,xa0,all,idiot,what,get,up,go,****,don,stupid,no,as,do,can,***,or,but,if,know,who,about,dumb,****,me,******,because,back

#test our estimator on a few test sentences: 
print("test data:", 
    ["I totally agree with you.",
    "You are so stupid."
])
print(bnb.predict(tf.transform([
    "I totally agree with you.",
    "You are so stupid."
])))
#[0 1]
# print(bnb1.predict([
#     "I totally agree with you.",
#     "You are so stupid."
# ]))
# print(bnb2.predict([
#     "I totally agree with you.",
#     "You are so stupid."
# ]))
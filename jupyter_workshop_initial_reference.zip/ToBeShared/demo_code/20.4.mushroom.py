from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

#Poisonous mushroom model 
#Display for each class, precision, recall and f1 



from yellowbrick.classifier import *
from sklearn_pandas import gen_features

def draw_auc_confusion_matrix(X, y, estimator):
    #transformer for each column 
    feature_def = gen_features(
        columns=features,
        classes=[LabelEncoder]  #scikit_pandas can not handle OneHotEncoder after LabelEncoder as LabelEncoder expects 1D, oneHotEncoder expects 2D 
    )                           #Can use LabelBinarizer which is same as LabelEncoder, then OneHotEncoder
    X_mapper = DataFrameMapper(feature_def)
    y = LabelEncoder().fit_transform(y.values.ravel())
    #Note features categorical, so, convert them to OneHotEncoding 
    model = Pipeline([
        ('mapper', X_mapper),
        ('hotencoder', OneHotEncoder()), #OneHotEncoder requires numerical categorical 
        ('estimator', estimator)
    ])
    # Create a new figure to draw the classification report on
    fig, (ax1,ax2) = plt.subplots(1,2)
    # Instantiate the classification model and visualizer
    visualizer = ConfusionMatrix( model, ax=ax1, classes=['edible', 'poisonous'] )
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.finalize()
    visualizer = ROCAUC(model, ax=ax2, classes=['edible', 'poisonous'])
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.finalize()
    visualizer.show()

dataset = pd.read_csv('data/mushroom.csv')
names = [
    'class',
    'cap-shape',
    'cap-surface',
    'cap-color'
]
dataset.columns = names
features = ['cap-shape', 'cap-surface', 'cap-color']
target   = ['class']

X = dataset[features]
y = dataset[target]  

estimator = RandomForestClassifier()
draw_auc_confusion_matrix(X,y, estimator)
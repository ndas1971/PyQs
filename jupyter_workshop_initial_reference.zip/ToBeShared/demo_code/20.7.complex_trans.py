"""
===================================
Column Transformer with Mixed Types
===================================
"""


import numpy as np
import pandas as pd 
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.ensemble import *  
from sklearn.linear_model import *  
from sklearn.model_selection import *

np.random.seed(0)

# Load data from https://www.openml.org/d/40945
#X, y = sklearn.datasets.fetch_openml("titanic", version=1, as_frame=True, return_X_y=True)

# Alternatively X and y can be obtained directly from the frame attribute:
# X = titanic.frame.drop('survived', axis=1)
# y = titanic.frame['survived']

df_train = pd.read_csv('data/titanic_train.csv', header = 0, index_col = 'ticket')

#Unknown data set , so if required handle later
#df_test = pd.read_csv('data/titanic_test.csv', header = 0, index_col = 'ticket')
#axis=0 , means vertical(row) stacking , axis=1, columnwise append 
#df = pd.concat([df_train, df_test], keys=["train", "test"])

y = df_train['survived']
#Dont include 'name' and 'cabin'
X = df_train[['pclass', 'sex', 'age', 
        'sibsp', 'parch', 'fare',  'embarked']]

categorical_features = ['embarked', 'sex', 'pclass', 'sibsp', 'parch']
numeric_features = ['age', 'fare']
#Make this in pandas dataframe, such that we can get help from scikit-learn 
#SettingWithCopyWarning -Ignore 
#This warning is meant for below chaining 
#df[df['A'] > 2]['B'] = new_val  # new_val not set in df
#but should be corrected as 
#df.loc[df['A'] > 2, 'B'] = new_val
pd.options.mode.chained_assignment = None  # default='warn'
for col in categorical_features:
    X[col] = X.loc[:,col].astype('category')

print("X.dtypes:\n", X.dtypes)

#Fill NA 
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)])

# Append classifier to preprocessing pipeline.
# Now we have a full prediction pipeline.
clf = Pipeline(steps=[('preprocessor', preprocessor),
                      ('classifier', LogisticRegression())])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

clf.fit(X_train, y_train)
print("model score: %.3f" % clf.score(X_test, y_test))

##############################################################################
# HTML representation of ``Pipeline``
###############################################################################
# When the ``Pipeline`` is printed out in a jupyter notebook an HTML
# representation of the estimator is displayed as follows:
from sklearn import set_config
set_config(display='diagram')
clf
#Since we are inside file , so dump this to a file 
print("""
Generating pipeline_dia.html
Use as 
from IPython.display import HTML
HTML(filename='pipeline_dia.html') 
""")
with open("pipeline_dia.html", "wt") as f:
    f.write(clf._repr_html_())


###############################################################################
# Use ``ColumnTransformer`` by selecting column by data types
###############################################################################
# When dealing with a cleaned dataset, the preprocessing can be automatic by
# using the data types of the column to decide whether to treat a column as a
# numerical or categorical feature.
# :func:`sklearn.compose.make_column_selector` gives this possibility.
# First, let's only select a subset of columns to simplify our
# example.

subset_feature = categorical_features + numeric_features
X = X[subset_feature]

###############################################################################
# Then, we introspect the information regarding each column data type.

print("X.info():\n", X.info())


from sklearn.compose import make_column_selector as selector

preprocessor = ColumnTransformer(transformers=[
    ('num', numeric_transformer, selector(dtype_exclude="category")),
    ('cat', categorical_transformer, selector(dtype_include="category"))
])

# Reproduce the identical fit/score process
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

clf.fit(X_train, y_train)
print("model score: %.3f" % clf.score(X_test, y_test))

###############################################################################
# Using the prediction pipeline in a grid search
###############################################################################
# Grid search can also be performed on the different preprocessing steps
# defined in the ``ColumnTransformer`` object, together with the classifier's
# hyperparameters as part of the ``Pipeline``.
# We will search for both the imputer strategy of the numeric preprocessing
# and the regularization parameter of the logistic regression using
# :class:`sklearn.model_selection.GridSearchCV`.

param_grid = {
    'preprocessor__num__imputer__strategy': ['mean', 'median'],
    'classifier__C': [0.1, 1.0, 10, 100],
}

clf2 = Pipeline(steps=[('preprocessor', preprocessor),
                      ('classifier', LogisticRegression(solver='lbfgs', max_iter=10000))])


grid_search = GridSearchCV(clf2, param_grid, cv=10)
grid_search.fit(X_train, y_train)

print(("best logistic regression from grid search: %.3f"
       % grid_search.score(X_test, y_test)))

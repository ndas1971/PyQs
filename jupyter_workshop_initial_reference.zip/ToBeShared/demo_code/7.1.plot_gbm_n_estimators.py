"""
========================================================
Gradient Boosting Train/Test Deviance(Loss) plotting
========================================================

Demonstrate Gradient Boosting on the Boston housing dataset.

This example fits a Gradient Boosting model with least squares loss and
1000 regression trees of depth 4.

Plots like these can be used to determine the optimal number of trees 
(i.e. n_estimators) where error is minimized for early stopping

Ofcourse bias would increase but test error stats would be better

"""
print(__doc__)



import numpy as np
import matplotlib.pyplot as plt

from sklearn import ensemble
from sklearn import datasets
from sklearn.utils import shuffle
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import KFold, cross_val_score

# #############################################################################
# Load data
boston = datasets.load_boston()
X, y = shuffle(boston.data, boston.target, random_state=13)
X = X.astype(np.float32)
offset = int(X.shape[0] * 0.9)
X_train, y_train = X[:offset], y[:offset]
X_test, y_test = X[offset:], y[offset:]

# #############################################################################
# Fit regression model
params = {'n_estimators': 1000, 'max_depth': 4, 'min_samples_split': 2,
          'learning_rate': 0.01, 'loss': 'ls'}
          
def print_stat(estimators, params=params, *, clf=None,  X_train=X_train, y_train=y_train, X_test=X_test, y_test=y_test):
    if clf != None:
        n_clf = clf 
    else:
        n_params = params.copy()
        n_params['n_estimators'] = estimators 
        n_clf = ensemble.GradientBoostingRegressor(random_state=0, **n_params)
    n_clf.fit(X_train, y_train)
    print("n_estimators=", n_clf.n_estimators_ )
    mse = mean_squared_error(y_test, n_clf.predict(X_test))
    print("\tMSE: %.4f" % mse)
    CV= KFold(n_splits=5,shuffle=True)
    scores = cross_val_score(n_clf, X, y, cv=CV) 
    tscore = n_clf.score(X_train, y_train)
    print("\tTrain score", round(tscore,3))
    print("\tCross val scores: Avg:", np.round(scores.mean(), 2), " stdDev ", np.round(scores.std(),3))
    print("\tTrain-Test variation: Avg:", np.round(np.abs(scores-tscore).mean(),2), " stdDev ", np.round(np.abs(scores-tscore).std(),3))
    return n_clf           

print("Base GBT with n_estimators=1000")
clf = print_stat(1000)



#############################################################################
# Plot training deviance

# compute test set deviance
test_score = np.zeros((params['n_estimators'],), dtype=np.float64)

#staged_predict method which returns a generator 
#that yields the predictions at each stage
for i, y_pred in enumerate(clf.staged_predict(X_test)):
    #LossFunction 
    test_score[i] = clf.loss_(y_test, y_pred)

#Find float intersection, can not use numpy.intersect1d as values are not int 
def get_index(a,b, tol = 1e-3 ):
    which = np.isclose(a,b,tol)
    out = b[which]
    return np.argmax(which), out  #index, value

index, value = get_index(test_score, clf.train_score_)
print("With early stopping +/ 10%, n_estimators=", index)
for n in [int(0.9*index), index, int(1.1*index)]:
    print_stat(n)


plt.figure(figsize=(12, 6))

plt.plot(np.arange(params['n_estimators']) + 1, clf.train_score_, 'b-',
         label='Training Set Deviance(Loss)')
plt.plot(np.arange(params['n_estimators']) + 1, test_score, 'r-',
         label='Test Set Deviance(Loss)')
for n, ls in zip([int(0.9*index), index, int(1.1*index)], ['--', '-', '--']):
    plt.axvline(x=n, linestyle=ls)

plt.legend(loc='upper right')
plt.xlabel('Boosting Iterations=n_estimators in GBT')
plt.ylabel('Deviance')
plt.show()

print("""
With tuned best parameters and builtin Early stopping support 
(Note: early stopping depends on the other parameters)
========================================================
""")
b_clf = ensemble.GradientBoostingRegressor(n_estimators=1000, learning_rate=0.01,
    subsample=0.5, max_features = 0.5, 
    max_depth=4, min_samples_split=2, random_state=0,
    validation_fraction=0.2,
    n_iter_no_change=5, tol=1e-3)
print(b_clf)
print_stat(1000, clf=b_clf)
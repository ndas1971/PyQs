"""
========================
Partial Dependence Plots
========================

Interpret the partial dependence as the expected target response  
as a function of the 'target' features 

One-way PDPs tell us about the interaction between the target response 
and the target feature (e.g. linear, non-linear). 

The plot shows four one-way and one two-way partial dependence plots.

The target variables for the one-way PDP are:
median income (`MedInc`), avg. occupants per household (`AvgOccup`),
median house age (`HouseAge`), and avg. rooms per household (`AveRooms`).

We can clearly see that the median house price shows a linear relationship
with the median income (top left) and that the house price drops when the
avg. occupants per household increases (top middle).
The top right plot shows that the house age in a district does not have
a strong influence on the (median) house price; so does the average rooms
per household.
The tick marks on the x-axis represent the deciles of the feature values
in the training data.

Partial dependence plots with two target features enable us to visualize
interactions among them. The two-way partial dependence plot shows the
dependence of median house price on joint values of house age and avg.
occupants per household. We can clearly see an interaction between the
two features:
For an avg. occupancy greater than two, the house price is nearly independent
of the house age, whereas for values less than two there is a strong dependence
on age.
"""
from __future__ import print_function
print(__doc__)

import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt

from mpl_toolkits.mplot3d import Axes3D

from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.inspection import plot_partial_dependence
from sklearn.datasets import fetch_california_housing



cal_housing = fetch_california_housing()
X = pd.DataFrame(cal_housing.data, columns=cal_housing.feature_names)
y = cal_housing.target
y -= y.mean()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1,
                                                random_state=0)

#print("Training GBRT ...")
clf = GradientBoostingRegressor(n_estimators=100, max_depth=4,
                                learning_rate=0.1, loss='huber',
                                random_state=1)
clf.fit(X_train, y_train)
#print(" done.")

print("""
0->MedInc, 5 -> AveOccup, 1-> HouseAge, 2 -> AveRooms, (5,1)-> (AveOccup,HouseAge)
5 subplots , 
last one is two-way PDP, ie x,y are AveOccup,HouseAge and colormesh value is for Y ie median price 
""")
features = ['MedInc', 'AveOccup', 'HouseAge', 'AveRooms', ('AveOccup', 'HouseAge')]

fig, ((ax1, ax2,ax3),(ax4,ax5,ax6)) = plt.subplots(2, 3, figsize=(10, 6))
plot_partial_dependence(clf, X_train, features,
                                   n_jobs=3, grid_resolution=50, ax=[ax1,ax2,ax3,ax4,ax5])
plot_partial_dependence(clf, X_train, [('AveOccup', 'HouseAge')],
                                   n_jobs=3, grid_resolution=50, ax=ax6)
                     
fig.suptitle('Partial dependence of house value on nonlocation features\n'
             'for the California housing dataset')
fig.subplots_adjust(top=0.9)  # tight_layout causes overlap with suptitle
fig.show()




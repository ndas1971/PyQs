Text analysis steps
Term Frequency – Inverse Term Frequency 
Representing text in matrix
Tokenization
part of speech tagging
lemmatization
named entity recognition
coreference detection
sentiment analysis
Statistical NLP and text similarity
Syntax and Parsing techniques
Text Summarization Techniques
Semantics and Generation
-------------------------------------------
###NLP Python - using NLTK, Spacy , gensim and others 
http://www.nltk.org/book/
http://www.nltk.org/api/nltk.html

$ pip install numpy 
$ pip install nltk 
$ pip install  spacy
$ pip install stanfordcorenlp
$ pip install  gensim
$ pip install sumy



##NLP main Features and uses 
Tokenization 
    Segmenting text into words, punctuations marks etc. 
Part-of-speech (POS) 
    Tagging Assigning word types to tokens, like verb or noun. 
Dependency Parsing 
    Assigning syntactic dependency labels, describing the relations between individual tokens, 
    like subject or object. 
Stemmers
    Stemmers remove morphological affixes from words(eg ing etc), leaving only the word stem.
Lemmatization 
    Assigning the base forms of words. For example, the lemma of "was" is "be", 
    and the lemma of "rats" is "rat". 
Sentence Boundary Detection (SBD) 
    Finding and segmenting individual sentences. 
Named Entity Recognition (NER) 
    Labelling named "real-world" objects, like persons, companies or locations. 
Similarity 
    Comparing words, text spans and documents and how similar they are to each other. 
Text Classification 
    Assigning categories or labels to a whole document, or parts of a document. 
Rule-based Matching 
    Finding sequences of tokens based on their texts and linguistic annotations, 
    similar to regular expressions. 
Syntactic Parsing or Dependency Parsing And constituency Parsing 
    Dependency Parsing is the task of recognizing a sentence and assigning a syntactic structure(eg parse tree) to it. 
    These parse trees are useful in various applications like grammar checking or in the semantic analysis stage. 
    
    The task of Syntactic parsing is quite complex due to the fact that a given sentence can have multiple parse trees which we call as ambiguities. 
    Consider a sentence “Book that flight.” which can form multiple parse trees based 
    on its ambiguous part of speech tags unless these ambiguities are resolved. 
    Choosing a correct parse from the multiple possible parses is called as syntactic disambiguation. 

    Parsing algorithms like the Cocke-Kasami-Younger (CKY), Earley algorithm 
    or the Chart parsing algorithms uses a dynamic programming approach to deal with the ambiguity problems.
    
    A constituency parse tree breaks a text into sub-phrases. 
    Non-terminals in the tree are types of phrases, 
    the terminals are the words in the sentence, and the edges are unlabeled. 
    For a simple sentence "John sees Bill", a constituency parse would be:
                      Sentence
                         |
           +-------------+------------+
           |                          |
      Noun Phrase                Verb Phrase
           |                          |
         John                 +-------+--------+
                              |                |
                            Verb          Noun Phrase
                              |                |
                            sees              Bill

    A dependency parse connects words according to their relationships. 
    Each vertex in the tree represents a word, child nodes are words that are dependent on the parent, 
    and edges are labeled by the relationship. 
    A dependency parse of "John sees Bill", would be:
                  sees
                    |
            +--------------+
    subject |              | object
            |              |
          John            Bill


    You should use the parser type that gets you closest to your goal. 
    If you are interested in sub-phrases within the sentence, you probably want the constituency parse. 
    If you are interested in the dependency relationships between words, then you probably want the dependency parse.
Coreference detection
    The task of finding all expressions that refer to the same entity in a text
Text Summarization
    The target of text summarization is to reduce a textual document to a summary 
    that retains the pivotal points of the original document. 
Sentiment analysis
    Sentiment analysis aims to determine the attitude of a speaker, writer, 
    or other subject with respect to some topic or emotional reaction to a document, interaction, or event. 
Context Based Grammer 
    This deals with Analyzing Sentence Structure
    This defines how parsers analyzes a sentence and automatically build a syntax tree
Feature Based Grammers 
    This changes treatment of grammatical categories like S, NP and V from CFG 
    to structures like dictionaries(called features), where features can take on a range of values.
Semantics
    This deals with analyzing the meaning of sentences
    This improvises FCFG (feature context free grammer) to include meaning/semantics 
    to help us understanding the logic of the sentences 

    
    
    
###Accessing Text Corpora and Lexical Resources in NLTK
#See many corpus in https://www.nltk.org/book/ch02.html 

##Data download in NLTK
#Download data/corpus with nltk (has option for proxy server)
>>> import nltk
>>> nltk.download()  #set c:\nltk_data else set NLTK_DATA env var 

#Download book 
>>> from nltk.corpus import brown
>>> brown.words()
['The', 'Fulton', 'County', 'Grand', 'Jury', 'said', ...]

##Creating nltk.text.Text
f=open('my-file.txt','rt')
raw=f.read()
f.close()
tokens = nltk.word_tokenize(raw)
text = nltk.Text(tokens)

#OR for list of files 
from nltk.corpus import PlaintextCorpusReader
# RegEx or list of file names
files = ".*\.txt"   #regex
corpus0 = PlaintextCorpusReader("/path/", files)
corpus  = nltk.Text(corpus0.words())

#OR for standard corpus 
import nltk.corpus
from nltk.text import Text
moby = Text(nltk.corpus.gutenberg.words('melville-moby_dick.txt'))



##nltk Reference - class nltk.text.Text(tokens, name=None)
    Bases: object
    A wrapper around a sequence of simple (string) tokens,
    #Methods 
    collocations(num=20, window_size=2)
        Print collocations derived from the text, ignoring stopwords.
        Collocation refers to how words go together or form fixed relationships
    common_contexts(words, num=20)
        Find contexts where the specified words appear; 
        list most frequent common contexts first.
    concordance(word, width=79, lines=25)
        Print a concordance for word with the specified context window. 
        Word matching is not case-sensitive
        A concordance view shows us every occurrence of a given word
    count(word)
        Count the number of times this word appears in the text.
    dispersion_plot(words)
        Produce a plot showing the distribution of the words through the text. 
        Requires pylab(matplotlib) to be installed.
    findall(regexp)
        Find instances of the regular expression in the text
        angle brackets as non-capturing parentheses
        >>> text5.findall("<.*><.*><bro>")
        you rule bro; telling you bro; u twizted bro
    generate(words)
    index(word)
        Find the index of the first occurrence of the word in the text.
    plot(*args)
        for FreqDist.plot() 
    readability(method)
    similar(word, num=20)
        Distributional similarity: find other words which appear in the same contexts as the specified word; 
        list most similar words first.
    unicode_repr()
    vocab()

##examples  

import nltk.corpus
import nltk 
moby = nltk.Text(nltk.corpus.gutenberg.words('melville-moby_dick.txt'))


#OR 
f=open('toBeshared/data/melville-moby_dick.txt')
raw=f.read()
f.close()
tokens = nltk.word_tokenize(raw)
text = nltk.Text(tokens)

from nltk.book import *
text1

>>> type(text1)
<class 'nltk.text.Text'>

#A concordance view shows us every occurrence of a given word
>>> text1.concordance("monstrous")

#Similar term 
>>> text1.similar("monstrous")

#common_contexts allows us to examine the contexts that are shared by two or more words,
>>> text2.common_contexts(["monstrous", "very"])

#dispersion plot(requires matplotlib)
#Each stripe represents an instance of a word, and each row represents the entire text
#location of a word in the text: how many words from the beginning it appears
>>> text4.dispersion_plot(["citizens", "democracy", "freedom", "duties", "America"])


#Counting Vocabulary
>>> len(text3)
>>> sorted(set(text3)) 
>>> len(set(text3)) 

#calculate a measure of the lexical richness of the text
>>> len(set(text3)) / len(text3)  #number of distinct words is just 6% of the total number of words
0.06230453042623537

#count how often a word occurs in a text, and compute what percentage of the text is taken up by a specific word
>>> text3.count("smote")
5
>>> 100 * text4.count('a') / len(text4)
1.4643016433938312
>>>


#Frequency of words 
>>> fdist1 = FreqDist(text1) 
>>> print(fdist1) 
<FreqDist with 19317 samples and 260819 outcomes>
>>> fdist1.most_common(50)
[(',', 18713), ('the', 13721), ('.', 6862), ('of', 6536), ('and', 6024),
('a', 4569), ('to', 4542), (';', 4072), ('in', 3916), ('that', 2982),
("'", 2684), ('-', 2552), ('his', 2459), ('it', 2209), ('I', 2124),
('s', 1739), ('is', 1695), ('he', 1661), ('with', 1659), ('was', 1632),
('as', 1620), ('"', 1478), ('all', 1462), ('for', 1414), ('this', 1280),
('!', 1269), ('at', 1231), ('by', 1137), ('but', 1113), ('not', 1103),
('--', 1070), ('him', 1058), ('from', 1052), ('be', 1030), ('on', 1005),
('so', 918), ('whale', 906), ('one', 889), ('you', 841), ('had', 767),
('have', 760), ('there', 715), ('But', 705), ('or', 697), ('were', 680),
('now', 646), ('which', 640), ('?', 637), ('me', 627), ('like', 624)]
>>> fdist1['whale']
906
>>>


#to find the words from the vocabulary of the text that are more than 7 characters long
#and count of that word more than 7 
>>> fdist5 = FreqDist(text5)
>>> sorted(w for w in set(text5) if len(w) > 7 and fdist5[w] > 7)
['#14-19teens', '#talkcity_adults', '((((((((((', '........', 'Question',
'actually', 'anything', 'computer', 'cute.-ass', 'everyone', 'football',
'innocent', 'listening', 'remember', 'seriously', 'something', 'together',
'tomorrow', 'watching']


##Collocations and Bigrams
#A collocation is a sequence of words that occur together unusually often. 
#Thus 'red wine' is a collocation, whereas 'the wine' is not

#extract  from a text a list of word pairs, also known as bigrams
>>> list(bigrams(['more', 'is', 'said', 'than', 'done']))
[('more', 'is'), ('is', 'said'), ('said', 'than'), ('than', 'done')]
#words than-done is a bigram,

>>> text4.collocations()
United States; fellow citizens; four years; years ago; Federal
Government; General Government; American people; Vice President; Old
World; Almighty God; Fellow citizens; Chief Magistrate; Chief Justice;
God bless; every citizen; Indian tribes; public debt; one another;
foreign nations; political parties


#Counting Other Things
>>> [len(w) for w in text1] 
[1, 4, 4, 2, 6, 8, 4, 1, 9, 1, 1, 8, 2, 1, 4, 11, 5, 2, 1, 7, 6, 1, 3, 4, 5, 2, ...]
#frequency of lengths of words 
>>> fdist = FreqDist(len(w) for w in text1) 
>>> print(fdist)  
<FreqDist with 19 samples and 260819 outcomes>
>>> fdist
FreqDist({3: 50223, 1: 47933, 4: 42345, 2: 38513, 5: 26597, 6: 17111, 7: 14399,
  8: 9966, 9: 6428, 10: 3528, ...})
>>>

>>> fdist.most_common()
[(3, 50223), (1, 47933), (4, 42345), (2, 38513), (5, 26597), (6, 17111), (7, 14399),
(8, 9966), (9, 6428), (10, 3528), (11, 1873), (12, 1053), (13, 567), (14, 177),
(15, 70), (16, 22), (17, 12), (18, 1), (20, 1)]
>>> fdist.max()
3
>>> fdist[3]
50223
>>> fdist.freq(3)  # 20% of the words of length 3  making up the book
0.19255882431878046
>>>



##Gutenberg Corpus
#contains some 25,000 free electronic books, hosted at http://www.gutenberg.org/. 

from  nltk.corpus import gutenberg
>>> gutenberg.fileids()
['austen-emma.txt', 'austen-persuasion.txt', 'austen-sense.txt', 'bible-kjv.txt',
'blake-poems.txt', 'bryant-stories.txt', 'burgess-busterbrown.txt',
'carroll-alice.txt', 'chesterton-ball.txt', 'chesterton-brown.txt',
'chesterton-thursday.txt', 'edgeworth-parents.txt', 'melville-moby_dick.txt',
'milton-paradise.txt', 'shakespeare-caesar.txt', 'shakespeare-hamlet.txt',
'shakespeare-macbeth.txt', 'whitman-leaves.txt']
 
emma = gutenberg.words('austen-emma.txt')
>>> len(emma)
192427
 
 
# Creating Text for that 
emma = nltk.Text(nltk.corpus.gutenberg.words('austen-emma.txt'))
>>> emma.concordance("surprize")
 
#display other information about each text

for fileid in gutenberg.fileids():
     num_chars = len(gutenberg.raw(fileid))  #contents of the file without any linguistic processing
     num_words = len(gutenberg.words(fileid))
     num_sents = len(gutenberg.sents(fileid))
     num_vocab = len(set(w.lower() for w in gutenberg.words(fileid)))
     print(round(num_chars/num_words), round(num_words/num_sents), round(num_words/num_vocab), fileid)
#output 
5 25 26 austen-emma.txt
5 26 17 austen-persuasion.txt
5 28 22 austen-sense.txt
4 34 79 bible-kjv.txt
5 19 5 blake-poems.txt
4 19 14 bryant-stories.txt
4 18 12 burgess-busterbrown.txt
4 20 13 carroll-alice.txt
5 20 12 chesterton-ball.txt
5 23 11 chesterton-brown.txt
5 18 11 chesterton-thursday.txt
4 21 25 edgeworth-parents.txt
5 26 15 melville-moby_dick.txt
5 52 11 milton-paradise.txt
4 12 9 shakespeare-caesar.txt
4 12 8 shakespeare-hamlet.txt
4 12 7 shakespeare-macbeth.txt
5 36 12 whitman-leaves.txt
 
 


##Web and Chat Text
#less formal language as well

from nltk.corpus import webtext
for fileid in webtext.fileids():
    print(fileid, webtext.raw(fileid)[:65], '...')
#
firefox.txt Cookie Manager: "Don't allow sites that set removed cookies to se...
grail.txt SCENE 1: [wind] [clop clop clop] KING ARTHUR: Whoa there!  [clop...
overheard.txt White guy: So, do you have any plans for this evening? Asian girl...
pirates.txt PIRATES OF THE CARRIBEAN: DEAD MAN'S CHEST, by Ted Elliott & Terr...
singles.txt 25 SEXY MALE, seeks attrac older single lady, for discreet encoun...
wine.txt Lovely delicate, fragrant Rhone wine. Polished leather and strawb...
 
 
##Brown Corpus
#The Brown Corpus was the first million-word electronic corpus of English, created in 1961 at Brown University. 

#ID File Genre   Description
A16 ca16 news Chicago Tribune: Society Reportage 
B02 cb02 editorial Christian Science Monitor: Editorials 
C17 cc17 reviews Time Magazine: Reviews 
D12 cd12 religion Underwood: Probing the Ethics of Realtors 
E36 ce36 hobbies Norling: Renting a Car in Europe 
F25 cf25 lore Boroff: Jewish Teenage Culture 
G22 cg22 belles_lettres Reiner: Coping with Runaway Technology 
H15 ch15 government US Office of Civil and Defence Mobilization: The Family Fallout Shelter 
J17 cj19 learned Mosteller: Probability with Statistical Applications 
K04 ck04 fiction W.E.B. Du Bois: Worlds of Color 
L13 cl13 mystery Hitchens: Footsteps in the Night 
M01 cm01 science_fiction Heinlein: Stranger in a Strange Land 
N14 cn15 adventure Field: Rattlesnake Ridge 
P12 cp12 romance Callaghan: A Passion in Rome 
R06 cr06 humor Thurber: The Future, If Any, of Comedy 

#Example 
from nltk.corpus import brown
>>> brown.categories()
['adventure', 'belles_lettres', 'editorial', 'fiction', 'government', 'hobbies',
'humor', 'learned', 'lore', 'mystery', 'news', 'religion', 'reviews', 'romance',
'science_fiction']
>>> brown.words(categories='news')
['The', 'Fulton', 'County', 'Grand', 'Jury', 'said', ...]
>>> brown.words(fileids=['cg22'])
['Does', 'our', 'society', 'have', 'a', 'runaway', ',', ...]
>>> brown.sents(categories=['news', 'editorial', 'reviews'])
[['The', 'Fulton', 'County'...], ['The', 'jury', 'further'...], ...]
 
 
#freq Distribution of words 
news_text = brown.words(categories='news')
fdist = nltk.FreqDist(w.lower() for w in news_text)
modals = ['can', 'could', 'may', 'might', 'must', 'will']
for m in modals:
    print(m + ':', fdist[m], end=' ')
#output 
can: 94 could: 87 may: 93 might: 38 must: 53 will: 389
 
 
#to obtain counts for each genre of interest
#(condition, variable),  For same condition , the variable is incremented 

cfd = nltk.ConditionalFreqDist( (genre, word) for genre in brown.categories() for word in brown.words(categories=genre))
>>> genres = ['news', 'religion', 'hobbies', 'science_fiction', 'romance', 'humor']
>>> modals = ['can', 'could', 'may', 'might', 'must', 'will']
>>> cfd.tabulate(conditions=genres, samples=modals)
                 can could  may might must will
           news   93   86   66   38   50  389
       religion   82   59   78   12   54   71
        hobbies  268   58  131   22   83  264
science_fiction   16   49    4   12    8   16
        romance   74  193   11   51   45   43
          humor   16   30    8    8    9   13
 








 
###NLTK - Processing Raw Text( Tokenizer, Stemmers and Lemmatizations, Sentence Segmentation 

##Normalizing Text

raw = """DENNIS: Listen, strange women lying in ponds distributing swords
is no basis for a system of government.  Supreme executive power derives from
a mandate from the masses, not from some farcical aquatic ceremony."""
>>> tokens = word_tokenize(raw)
 
 
##Stemmers
#Stemmers remove morphological affixes from words(eg ing etc), leaving only the word stem.

#Stemming usually refers to a crude heuristic process that chops off the ends of words 
#Lemmatization usually refers to doing things properly with the use of a vocabulary and morphological analysis of words,


#The Porter and Lancaster stemmers follow their own rules for stripping affixes. 
#Observe that the Porter stemmer correctly handles the word lying (mapping it to lie), 
#while the Lancaster stemmer does not.

porter = nltk.PorterStemmer()
lancaster = nltk.LancasterStemmer()
>>> [porter.stem(t) for t in tokens]
['DENNI', ':', 'Listen', ',', 'strang', 'women', 'lie', 'in', 'pond',
'distribut', 'sword', 'is', 'no', 'basi', 'for', 'a', 'system', 'of', 'govern',
'.', 'Suprem', 'execut', 'power', 'deriv', 'from', 'a', 'mandat', 'from',
'the', 'mass', ',', 'not', 'from', 'some', 'farcic', 'aquat', 'ceremoni', '.']
>>> [lancaster.stem(t) for t in tokens]
['den', ':', 'list', ',', 'strange', 'wom', 'lying', 'in', 'pond', 'distribut',
'sword', 'is', 'no', 'bas', 'for', 'a', 'system', 'of', 'govern', '.', 'suprem',
'execut', 'pow', 'der', 'from', 'a', 'mand', 'from', 'the', 'mass', ',', 'not',
'from', 'som', 'farc', 'aqu', 'ceremony', '.']
 
 
#Porter Stemmer is a good choice if you are indexing some texts 
#and want to support search using alternative forms of words 

class IndexedText(object):
    def __init__(self, stemmer, text):
        self._text = text
        self._stemmer = stemmer
        self._index = nltk.Index((self._stem(word), i)  #Index is nothing but {key:[values..]} ie dict with values are list 
                                 for (i, word) in enumerate(text)) #same word, list of is

    def concordance(self, word, width=40):
        key = self._stem(word)
        wc = int(width/4)                # words of context, show these any words 
        for i in self._index[key]:
            lcontext = ' '.join(self._text[i-wc:i])
            rcontext = ' '.join(self._text[i:i+wc])
            ldisplay = '{:>{width}}'.format(lcontext[-width:], width=width)
            rdisplay = '{:{width}}'.format(rcontext[:width], width=width)
            print(ldisplay, rdisplay)

    def _stem(self, word):
        return self._stemmer.stem(word).lower()
 
 

>>> porter = nltk.PorterStemmer()
>>> grail = nltk.corpus.webtext.words('grail.txt')
>>> text = IndexedText(porter, grail)
>>> text.concordance('lie')
r king ! DENNIS : Listen , strange women lying in ponds distributing swords is no
 beat a very brave retreat . ROBIN : All lies ! MINSTREL : [ singing ] Bravest of
 
 

##Lemmatization
#The WordNet lemmatizer is a good choice if you want to compile the vocabulary of some texts 
#and want a list of valid lemmas (or lexicon headwords).


#The WordNet lemmatizer only removes affixes if the resulting word is in its dictionary. 
#This additional checking process makes the lemmatizer slower than the above stemmers. 
#Notice that it doesn't handle lying, but it converts women to woman.

>>> wnl = nltk.WordNetLemmatizer()
>>> [wnl.lemmatize(t) for t in tokens]
['DENNIS', ':', 'Listen', ',', 'strange', 'woman', 'lying', 'in', 'pond',
'distributing', 'sword', 'is', 'no', 'basis', 'for', 'a', 'system', 'of',
'government', '.', 'Supreme', 'executive', 'power', 'derives', 'from', 'a',
'mandate', 'from', 'the', 'mass', ',', 'not', 'from', 'some', 'farcical',
'aquatic', 'ceremony', '.']
 
 


##NLTK's Regular Expression Tokenizer
#The function nltk.regexp_tokenize() is similar to re.findall() 
#The special (?x) "verbose flag" tells Python to strip out the embedded whitespace and comments.

text = 'That U.S.A. poster-print costs $12.40...'
pattern = r'''(?x)    # set flag to allow verbose regexps
     ([A-Z]\.)+        # abbreviations, e.g. U.S.A.
   | \w+(-\w+)*        # words with optional internal hyphens
   | \$?\d+(\.\d+)?%?  # currency and percentages, e.g. $12.40, 82%
   | \.\.\.            # ellipsis
   | [][.,;"'?():-_`]  # these are separate tokens; includes ], [
 '''
>>> nltk.regexp_tokenize(text, pattern)
['That', 'U.S.A.', 'poster-print', 'costs', '$12.40', '...']
 
 

##Segmentation - Sentence Segmentation

#Most of the times, the text is only available as a stream of characters. 
#Before tokenizing the text into words, we need to segment it into sentences.

#NLTK facilitates this by including the Punkt sentence segmenter (Kiss & Strunk, 2006). 

text = nltk.corpus.gutenberg.raw('chesterton-thursday.txt')
sents = nltk.sent_tokenize(text)
>>> pprint.pprint(sents[79:89])
['"Nonsense!"',
 'said Gregory, who was very rational when anyone else\nattempted paradox.',
 '"Why do all the clerks']
 
 


 
 
 
 
 
 
 
 
 
 
###NLTK- Categorizing and Tagging Words - POS tag 

#word classes - nouns, verbs, adjectives, and adverbs

nltk.tag.pos_tag(tokens, tagset=None, lang='eng')
    Use NLTK’s currently recommended part of speech tagger to tag the given list of tokens.
        tokens (list(str)) – Sequence of tokens to be tagged
        tagset (str) – the tagset to be used, e.g. universal, wsj, brown
        lang (str) – the ISO 639 code of the language, e.g. ‘eng’ for English, ‘rus’ for Russian
    Returns:	list(tuple(str, str))

nltk.tag.pos_tag_sents(sentences, tagset=None, lang='eng')
    Use NLTK’s currently recommended part of speech tagger to tag the given list of sentences, 
    each consisting of a list of tokens.
        tokens (list(list(str))) – List of sentences to be tagged
        tagset (str) – the tagset to be used, e.g. universal, wsj, brown
        lang (str) – the ISO 639 code of the language, e.g. ‘eng’ for English, ‘rus’ for Russian
    Returns:	The list of tagged sentences, list(list(tuple(str, str)))

#A part-of-speech tagger, or POS-tagger, processes a sequence of words, 
#and attaches a part of speech tag to each word 
#Tagged tokens are encoded as tuples (tag, token), tag is such as its part of speech
CC, a coordinating conjunction; 
RB, or adverbs; 
IN, a preposition; 
NN, a noun; 
JJ, an adjective.
VBP, present tense verb 
DT: determiner
PRP: pronoun, personal
TO: "to" as preposition or infinitive marker


#Check help 
nltk.help.upenn_tagset('RB')
nltk.help.upenn_tagset('NN.*')
#for all 
>>> nltk.help.upenn_tagset()


#Example 
>>> text = word_tokenize("And now for something completely different")
>>> nltk.pos_tag(text)
[('And', 'CC'), ('now', 'RB'), ('for', 'IN'), ('something', 'NN'),
('completely', 'RB'), ('different', 'JJ')]
 
 

>>> text = nltk.word_tokenize("They refuse to permit us to obtain the refuse permit")
>>> nltk.pos_tag(text)
[('They', 'PRP'), ('refuse', 'VBP'), ('to', 'TO'), ('permit', 'VB'), ('us', 'PRP'),
('to', 'TO'), ('obtain', 'VB'), ('the', 'DT'), ('refuse', 'NN'), ('permit', 'NN')]


##A Universal Part-of-Speech Tagset - Simplified and streamlined tags 
>>> nltk.corpus.brown.tagged_words(tagset='universal')
[('The', 'DET'), ('Fulton', 'NOUN'), ...]
>>> nltk.corpus.treebank.tagged_words(tagset='universal')
[('Pierre', 'NOUN'), ('Vinken', 'NOUN'), (',', '.'), ...]

#Tagged corpora use many different conventions for tagging words. 
#To help us get started, we will be looking at a simplified tagset 
#Tag        Meaning             English Examples
ADJ         adjective           new, good, high, special, big, local 
ADP         adposition          on, of, at, with, by, into, under 
ADV         adverb              really, already, still, early, now 
CONJ        conjunction         and, or, but, if, while, although 
DET         determiner          , article the, a, some, most, every, no, which 
NOUN        noun                year, home, costs, time, Africa 
NUM         numeral             twenty-four, fourth, 1991, 14:24 
PRT         particle            at, on, out, over per, that, up, with 
PRON        pronoun             he, their, her, its, my, I, us 
VERB        verb                is, say, told, given, playing, would 
.           punctuation marks   . , ; ! 
X           other               ersatz, esprit, dunno, gr8, univeristy 



##Tagged Corpora
#By convention in NLTK, a tagged token is represented using a tuple consisting of the token and the tag. 

>>> tagged_token = nltk.tag.str2tuple('fly/NN')
>>> tagged_token
('fly', 'NN')
>>> tagged_token[0]
'fly'
>>> tagged_token[1]
'NN'
 
 
##Reading Tagged Corpora
#Several of the corpora included with NLTK have been tagged for their part-of-speech. 

#Tagged corpora for several other languages are distributed with NLTK, 
#including Chinese, Hindi, Portuguese, Spanish, Dutch and Catalan. 

#for example - Brown Corpus with a text editor:
The/at Fulton/np-tl County/nn-tl Grand/jj-tl Jury/nn-tl said/vbd Friday/nr an/at investigation/nn of/in Atlanta's/np$ recent/jj primary/nn election/nn produced/vbd / no/at evidence/nn ''/'' that/cs any/dti irregularities/nns took/vbd place/nn ./.

>>> nltk.corpus.brown.tagged_words()
[('The', 'AT'), ('Fulton', 'NP-TL'), ...]
>>> nltk.corpus.brown.tagged_words(tagset='universal')
[('The', 'DET'), ('Fulton', 'NOUN'), ...]
 
#Example - which of these tags are the most common in the news category of the Brown corpus:
>>> from nltk.corpus import brown
>>> brown_news_tagged = brown.tagged_words(categories='news', tagset='universal')
>>> tag_fd = nltk.FreqDist(tag for (word, tag) in brown_news_tagged)
>>> tag_fd.most_common()
[('NOUN', 30640), ('VERB', 14399), ('ADP', 12355), ('.', 11928), ('DET', 11389),
 ('ADJ', 6706), ('ADV', 3349), ('CONJ', 2717), ('PRON', 2535), ('PRT', 2264),
 ('NUM', 2166), ('X', 106)]
 
 
 
##Nouns
#Nouns generally refer to people, places, things, or concepts

#Example - inspect some tagged text to see what parts of speech occur before a noun, 
#with the most frequent ones first. 

>>> word_tag_pairs = nltk.bigrams(brown_news_tagged)
>>> noun_preceders = [a[1] for (a, b) in word_tag_pairs if b[1] == 'NOUN']
>>> fdist = nltk.FreqDist(noun_preceders)
>>> [tag for (tag, _) in fdist.most_common()]
['NOUN', 'DET', 'ADJ', 'ADP', '.', 'VERB', 'CONJ', 'NUM', 'ADV', 'PRT', 'PRON', 'X']
 
 
##Verbs
#Verbs are words that describe events and actions
#Example - What are the most common verbs in news text? Let's sort all the verbs by frequency:

>>> wsj = nltk.corpus.treebank.tagged_words(tagset='universal')
>>> word_tag_fd = nltk.FreqDist(wsj)
>>> [wt[0] for (wt, _) in word_tag_fd.most_common() if wt[1] == 'VERB']
['is', 'said', 'are', 'was', 'be', 'has', 'have', 'will', 'says', 'would',
 'were', 'had', 'been', 'could', "'s", 'can', 'do', 'say', 'make', 'may',
 'did', 'rose', 'made', 'does', 'expected', 'buy', 'take', 'get', 'might',
 'sell', 'added', 'sold', 'help', 'including', 'should', 'reported', ...]
 
 
 
##Advanced - Various Tagger availables in NLTK 
#in practice , use pos_tag 

#The Simple Tagger - using nltk.DefaultTagger
#the simplest possible tagger assigns the same tag(highest probable) to each token

>>> tags = [tag for (word, tag) in brown.tagged_words(categories='news')]
>>> nltk.FreqDist(tags).max()
'NN'
 
brown_tagged_sents = brown.tagged_sents(categories='news')

#create a tagger that tags everything as NN.
>>> raw = 'I do not like green eggs and ham, I do not like them Sam I am!'
>>> tokens = word_tokenize(raw)
>>> default_tagger = nltk.DefaultTagger('NN')
>>> default_tagger.tag(tokens)
[('I', 'NN'), ('do', 'NN'), ('not', 'NN'), ('like', 'NN'), ('green', 'NN'),
('eggs', 'NN'), ('and', 'NN'), ('ham', 'NN'), (',', 'NN'), ('I', 'NN'),
('do', 'NN'), ('not', 'NN'), ('like', 'NN'), ('them', 'NN'), ('Sam', 'NN'),
('I', 'NN'), ('am', 'NN'), ('!', 'NN')]
 
#Poor 
>>> default_tagger.evaluate(brown_tagged_sents)
0.13089484257215028
 
 
##The Regular Expression Tagger
 
>>> patterns = [
     (r'.*ing$', 'VBG'),               # gerunds
     (r'.*ed$', 'VBD'),                # simple past
     (r'.*es$', 'VBZ'),                # 3rd singular present
     (r'.*ould$', 'MD'),               # modals
     (r'.*\'s$', 'NN$'),               # possessive nouns
     (r'.*s$', 'NNS'),                 # plural nouns
     (r'^-?[0-9]+(.[0-9]+)?$', 'CD'),  # cardinal numbers
     (r'.*', 'NN')                     # nouns (default)
 ]
 
 
regexp_tagger = nltk.RegexpTagger(patterns)
>>> regexp_tagger.tag(brown_sents[3])
[('``', 'NN'), ('Only', 'NN'), ('a', 'NN'), ('relative', 'NN'), ('handful', 'NN'),
('of', 'NN'), ('such', 'NN'), ('reports', 'NNS'), ('was', 'NNS'), ('received', 'VBD'),
("''", 'NN'), (',', 'NN'), ('the', 'NN'), ('jury', 'NN'), ('said', 'NN'), (',', 'NN'),
('``', 'NN'), ('considering', 'VBG'), ('the', 'NN'), ('widespread', 'NN'), ...]
>>> regexp_tagger.evaluate(brown_tagged_sents)
0.20326391789486245
 

##Unigram Tagging
#Unigram taggers are based on a simple statistical algorithm: 
#for each token, assign the tag that is most likely for that particular token. 


#Separating the Training and Testing Data and train 
size = int(len(brown_tagged_sents) * 0.9)
>>> size
4160
train_sents = brown_tagged_sents[:size]
test_sents = brown_tagged_sents[size:]
 unigram_tagger = nltk.UnigramTagger(train_sents)
>>> unigram_tagger.evaluate(test_sents)
0.811721...


#Example 
from nltk.corpus import brown
brown_tagged_sents = brown.tagged_sents(categories='news')
brown_sents = brown.sents(categories='news')
unigram_tagger = nltk.UnigramTagger(brown_tagged_sents)

>>> unigram_tagger.tag(brown_sents[2007])
[('Various', 'JJ'), ('of', 'IN'), ('the', 'AT'), ('apartments', 'NNS'),
('are', 'BER'), ('of', 'IN'), ('the', 'AT'), ('terrace', 'NN'), ('type', 'NN'),
(',', ','), ('being', 'BEG'), ('on', 'IN'), ('the', 'AT'), ('ground', 'NN'),
('floor', 'NN'), ('so', 'QL'), ('that', 'CS'), ('entrance', 'NN'), ('is', 'BEZ'),
('direct', 'JJ'), ('.', '.')]
>>> unigram_tagger.evaluate(brown_tagged_sents)
0.9349006503968017
 
##The Lookup Tagger
#A lot of high-frequency words do not have the NN tag. 
#Let's find the hundred most frequent words and store their most likely tag. 
#We can then use this information as the model for a "lookup tagger" (an NLTK UnigramTagger):

fd = nltk.FreqDist(brown.words(categories='news'))
cfd = nltk.ConditionalFreqDist(brown.tagged_words(categories='news')) #condition=word, count=tag 
most_freq_words = fd.most_common(100)
likely_tags = dict((word, cfd[word].max()) for (word, _) in most_freq_words)

baseline_tagger = nltk.UnigramTagger(model=likely_tags)
>>> baseline_tagger.evaluate(brown_tagged_sents)
0.45578495136941344
 
 
#Evaluete on untagged text 
>>> sent = brown.sents(categories='news')
>>> baseline_tagger.tag(sent)
[('``', '``'), ('Only', None), ('a', 'AT'), ('relative', None),
('handful', None), ('of', 'IN'), ('such', None), ('reports', None),
('was', 'BEDZ'), ('received', None), ("''", "''"), (',', ','),
('the', 'AT'), ('jury', None), ('said', 'VBD'), (',', ','),
('``', '``'), ('considering', None), ('the', 'AT'), ('widespread', None),
('interest', None), ('in', 'IN'), ('the', 'AT'), ('election', None),
(',', ','), ('the', 'AT'), ('number', None), ('of', 'IN'),
('voters', None), ('and', 'CC'), ('the', 'AT'), ('size', None),
('of', 'IN'), ('this', 'DT'), ('city', None), ("''", "''"), ('.', '.')]
 
 
#Many words have been assigned a tag of None, 
#because they were not among the 100 most frequent words. 

#In these cases we would like to assign the default tag of NN. 
#In other words, we want to use the lookup table first, and if it is unable to assign a tag, 
#then use the default tagger, a process known as backoff 
baseline_tagger = nltk.UnigramTagger(model=likely_tags,backoff=nltk.DefaultTagger('NN'))


 
 
##General N-Gram Tagging 
#The NgramTagger class uses a tagged training corpus to determine which part-of-speech tag is most likely for each context. 

#Fir example - a bigram tagger. 
 
bigram_tagger = nltk.BigramTagger(train_sents)
>>> bigram_tagger.tag(brown_sents[2007])
[('Various', 'JJ'), ('of', 'IN'), ('the', 'AT'), ('apartments', 'NNS'),
('are', 'BER'), ('of', 'IN'), ('the', 'AT'), ('terrace', 'NN'),
('type', 'NN'), (',', ','), ('being', 'BEG'), ('on', 'IN'), ('the', 'AT'),
('ground', 'NN'), ('floor', 'NN'), ('so', 'CS'), ('that', 'CS'),
('entrance', 'NN'), ('is', 'BEZ'), ('direct', 'JJ'), ('.', '.')]

unseen_sent = brown_sents[4203]
>>> bigram_tagger.tag(unseen_sent)
[('The', 'AT'), ('population', 'NN'), ('of', 'IN'), ('the', 'AT'), ('Congo', 'NP'),
('is', 'BEZ'), ('13.5', None), ('million', None), (',', None), ('divided', None),
('into', None), ('at', None), ('least', None), ('seven', None), ('major', None),
('``', None), ('culture', None), ('clusters', None), ("''", None), ('and', None),
('innumerable', None), ('tribes', None), ('speaking', None), ('400', None),
('separate', None), ('dialects', None), ('.', None)]
 
>>> bigram_tagger.evaluate(test_sents)
0.102063...
 
 
##Combining Taggers
#1.Try tagging the token with the bigram tagger.
#2.If the bigram tagger is unable to find a tag for the token, try the unigram tagger.
#3.If the unigram tagger is also unable to find a tag, use a default tagger.

t0 = nltk.DefaultTagger('NN')
t1 = nltk.UnigramTagger(train_sents, backoff=t0)
t2 = nltk.BigramTagger(train_sents, backoff=t1)
>>> t2.evaluate(test_sents)
0.844513...
 

 
##Storing Taggers
from pickle import dump
output = open('t2.pkl', 'wb')
dump(t2, output, -1)
output.close()
#load 
from pickle import load
input = open('t2.pkl', 'rb')
tagger = load(input)
input.close()
 
#Example  
>>> text = """The board's action shows what free enterprise
        is up against in our complex maze of regulatory laws ."""
>>> tokens = text.split()
>>> tagger.tag(tokens)
[('The', 'AT'), ("board's", 'NN$'), ('action', 'NN'), ('shows', 'NNS'),
('what', 'WDT'), ('free', 'JJ'), ('enterprise', 'NN'), ('is', 'BEZ'),
('up', 'RP'), ('against', 'IN'), ('in', 'IN'), ('our', 'PP$'), ('complex', 'JJ'),
('maze', 'NN'), ('of', 'IN'), ('regulatory', 'NN'), ('laws', 'NNS'), ('.', '.')]
 
 
##Evaluating Performance

#A convenient way to look at tagging errors is the confusion matrix. 
#It charts expected tags (the gold standard) against actual tags generated by a tagger
#offdiagonal should be zero for best result 


class nltk.metrics.confusionmatrix.ConfusionMatrix(reference, test, sort_by_count=False)
    Bases: object
    The confusion matrix between a list of reference values 
    and a corresponding list of test values. 
     Note that the diagonal entries Ri=Tj of this matrix 
    corresponds to correct values; 
    and the off-diagonal entries correspond to incorrect values.
    
    Entry [r,t] of this matrix is a count of the number of times 
    that the reference value r corresponds to the test value t. E.g.:
    >>> from nltk.metrics import ConfusionMatrix
    >>> ref  = 'DET NN VB DET JJ NN NN IN DET NN'.split()
    >>> test = 'DET VB VB DET NN NN NN IN DET NN'.split()
    >>> cm = ConfusionMatrix(ref, test)
    >>> print(cm['NN', 'NN'])
    3
    key()
    pretty_format(show_percents=False, values_in_chart=True, truncate=None, sort_by_count=False)
        Returns:A multi-line string representation of this confusion matrix.
            truncate (int) – If specified, then only show the specified number of values. Any sorting (e.g., sort_by_count) will be performed before truncation.
            sort_by_count – If true, then sort by the count of each label in the reference data. I.e., labels that occur more frequently in the reference label will be towards the left edge of the matrix, and labels that occur less frequently will be towards the right edge.

  
#Example 
test_tags = [tag for sent in brown.sents(categories='editorial')
                for (word, tag) in t2.tag(sent)]
gold_tags = [tag for (word, tag) in brown.tagged_words(categories='editorial')]
print(nltk.ConfusionMatrix(gold_tags, test_tags))           
 
 

 
 
 
 
 
 
 
 
 
 

###NLTK -Learning to Classify Text - Using NaiveBayesClassifier and other classifiers 

#Before training, extract Feature 
#featuresets = list of tuple(features  , label)
#features in nltk is a dict { feature_name1: value, feature_name2:value }
#all tuples should contain the same feature_names (string)
#value can be string, int, bool etc 


        
##Example- Geneder classifications 
# Names ending in a, e and i are likely to be female, 
#while names ending in k, o, r, s and t are likely to be male. 

#Let's build a classifier to model these differences more precisely.

#Exatract feature ie last alpha 
>>> def gender_features(word):
    return {'last_letter': word[-1]}
>>> gender_features('Shrek')
{'last_letter': 'k'}
 
 
#Get Training data 
#featuresets = list of tuple(features  , label)
#features in nltk is a dict { feature_name1: value, feature_name2:value }
#all tuples should contain the same feature_names

from nltk.corpus import names
labeled_names = ([(name, 'male') for name in names.words('male.txt')] +
            [(name, 'female') for name in names.words('female.txt')])
            
#Split train and test  , (features  , label)
import random
random.shuffle(labeled_names)

featuresets = [(gender_features(n), gender) for (n, gender) in labeled_names]
train_set, test_set = featuresets[500:], featuresets[:500]
classifier = nltk.NaiveBayesClassifier.train(train_set)
 
#let's just test it out on some names that did not appear in its training data:
>>> classifier.classify(gender_features('Neo'))
'male'
>>> classifier.classify(gender_features('Trinity'))
'female'
 
#Evaluate 
>>> print(nltk.classify.accuracy(classifier, test_set))
0.77
 
 
#informative_features
#which features it found most effective for distinguishing the names' genders:

 >>> classifier.show_most_informative_features(5)
Most Informative Features
             last_letter = 'a'            female : male   =     33.2 : 1.0
             last_letter = 'k'              male : female =     32.6 : 1.0
             last_letter = 'p'              male : female =     19.7 : 1.0
             last_letter = 'v'              male : female =     18.6 : 1.0
             last_letter = 'f'              male : female =     17.3 : 1.0
 
 
#This listing shows that the names in the training set that end in "a" are female 33 times more often than they are male, 
#but names that end in "k" are male 32 times more often than they are female. 
#These ratios are known as likelihood ratios

 
 
##When working with large corpora, 
#constructing a single list that contains the features of every instance 
#can use up a large amount of memory. 

#In these cases, use the function nltk.classify.apply_features, 
#which returns an object that acts like a list 
#but does not store all the feature sets in memory:

from nltk.classify import apply_features
train_set = apply_features(gender_features, labeled_names[500:],True)
test_set = apply_features(gender_features, labeled_names[:500],True)
 
 
 

 
 
##Example - Document Classification

#In NLTK, we have examples of corpora where documents have been labeled with categories. 
#Using these corpora, we can build classifiers that will automatically tag 
#new documents with appropriate category labels



#For example - Movie Reviews Corpus, which categorizes each review as positive or negative(['neg', 'pos'])
#Classify a new movie review based on words available in that  

#document is list of tuples, [(words_list, category),...]
#Note .words(fileid) gives words from fileid, .words() gives all worlds in corpus 
#movie_reviews.categories() => ['neg', 'pos']
from nltk.corpus import movie_reviews
documents = [(list(movie_reviews.words(fileid)), category)
                for category in movie_reviews.categories()
                for fileid in movie_reviews.fileids(category)]
random.shuffle(documents)
 
 
#Create smaller subset as features 
all_words = nltk.FreqDist(w.lower() for w in movie_reviews.words()) #all_words= FreqDist
word_features = list(all_words)[:2000] #forcing list on FreqDist returns sorted list with most frequent to least frequent 

#Feature extract
#feature is wheather document contains each word of word_features or not 
def document_features(document): 
    document_words = set(document) #document is list of words 
    features = {}
    for word in word_features:
        features['contains({})'.format(word)] = (word in document_words)
    return features
 
 

>>> print(document_features(movie_reviews.words('pos/cv957_8737.txt'))) 
{'contains(waste)': False, 'contains(lot)': False, ...}
 
 
#Get featureset and train 
#featuresets = list of tuple(features  , label)
#features in nltk is a dict { feature_name1: value, feature_name2:value }
#all tuples should contain the same feature_names
featuresets = [(document_features(d), c) for (d,c) in documents]
train_set, test_set = featuresets[100:], featuresets[:100]
classifier = nltk.NaiveBayesClassifier.train(train_set)
 
 
>>> print(nltk.classify.accuracy(classifier, test_set)) 
0.81
>>> classifier.show_most_informative_features(5) 
Most Informative Features
   contains(outstanding) = True              pos : neg    =     11.1 : 1.0
        contains(seagal) = True              neg : pos    =      7.7 : 1.0
   contains(wonderfully) = True              pos : neg    =      6.8 : 1.0
         contains(damon) = True              pos : neg    =      5.9 : 1.0
        contains(wasted) = True              neg : pos    =      5.8 : 1.0
 
 
# a review that mentions "Seagal" is almost 8 times more likely to be negative than positive, 
#while a review that mentions "Damon" is about 6 times more likely to be positive.






##Example - Part-of-Speech Tagging with help of classifiers - DecisionTreeClassifier

#the most common suffixes are:
from nltk.corpus import brown
suffix_fdist = nltk.FreqDist()
>>> for word in brown.words():
        word = word.lower()
        suffix_fdist[word[-1:]] += 1
        suffix_fdist[word[-2:]] += 1
        suffix_fdist[word[-3:]] += 1
 
 
>>> common_suffixes = [suffix for (suffix, count) in suffix_fdist.most_common(100)]
>>> print(common_suffixes)
['e', ',', '.', 's', 'd', 't', 'he', 'n', 'a', 'of', 'the',
 'y', 'r', 'to', 'in', 'f', 'o', 'ed', 'nd', 'is', 'on', 'l',
 'g', 'and', 'ng', 'er', 'as', 'ing', 'h', 'at', 'es', 'or',
 're', 'it', '', 'an', "''", 'm', ';', 'i', 'ly', 'ion', ...]
 
 
 
#feature extractor function which checks a given word for these suffixes:
#featuresets = list of tuple(features  , label)
#features in nltk is a dict { feature_name1: value, feature_name2:value }
#all tuples should contain the same feature_names
>>> def pos_features(word):
        features = {}
        for suffix in common_suffixes:
            features['endswith({})'.format(suffix)] = word.lower().endswith(suffix)
        return features
 
 
#Train - label is part of speech  
tagged_words = brown.tagged_words(categories='news') #list of (word, tag)
featuresets = [(pos_features(n), g) for (n,g) in tagged_words]
 
size = int(len(featuresets) * 0.1)
train_set, test_set = featuresets[size:], featuresets[:size]
 
classifier = nltk.DecisionTreeClassifier.train(train_set)
>>> nltk.classify.accuracy(classifier, test_set)
0.62705121829935351
 
>>> classifier.classify(pos_features('cats'))
'NNS'
 
 
 
#One nice feature of decision tree models is that they are often fairly easy to interpret 
#we can even instruct NLTK to print them out as pseudocode:

>>> print(classifier.pseudocode(depth=4))
if endswith(,) == True: return ','
if endswith(,) == False:
  if endswith(the) == True: return 'AT'
  if endswith(the) == False:
    if endswith(s) == True:
      if endswith(is) == True: return 'BEZ'
      if endswith(is) == False: return 'VBZ'
    if endswith(s) == False:
      if endswith(.) == True: return '.'
      if endswith(.) == False: return 'NN'
 
 
 
 

 
##Evaluation in classification
##Accuracy
#measures the percentage of inputs in the test set that the classifier correctly labeled. 

>>> classifier = nltk.NaiveBayesClassifier.train(train_set) 
>>> print('Accuracy: {:4.2f}'.format(nltk.classify.accuracy(classifier, test_set))) 
0.75
 
##Precision and Recall
•True positives are relevant items that we correctly identified as relevant.
•True negatives are irrelevant items that we correctly identified as irrelevant.
•False positives (or Type I errors) are irrelevant items that we incorrectly identified as relevant.
•False negatives (or Type II errors) are relevant items that we incorrectly identified as irrelevant.

#Given these four numbers, we can define the following metrics:
•Precision, which indicates how many of the items that we identified were relevant, is TP/(TP+FP).
•Recall, which indicates how many of the relevant items that we identified, is TP/(TP+FN).
•The F-Measure (or F-Score), which combines the precision and recall to give a single score, is defined to be the harmonic mean of the precision and recall: (2 × Precision × Recall) / (Precision + Recall).


#A confusion matrix is a table where each cell [i,j] indicates 
#how often label j was predicted when the correct label was i. 
#Thus, the diagonal entries (i.e., cells |ii|) indicate labels that were correctly predicted, 
#and the off-diagonal entries indicate errors. 

def tag_list(tagged_sents):
    return [tag for sent in tagged_sents for (word, tag) in sent]

def apply_tagger(tagger, corpus):
    return [tagger.tag(nltk.tag.untag(sent)) for sent in corpus]

t0 = nltk.DefaultTagger('NN')
t1 = nltk.UnigramTagger(train_sents, backoff=t0)
t2 = nltk.BigramTagger(train_sents, backoff=t1)

gold = tag_list(brown.tagged_sents(categories='editorial'))
test = tag_list(apply_tagger(t2, brown.tagged_sents(categories='editorial')))

cm = nltk.ConfusionMatrix(gold, test)
>>> print(cm.pretty_format(sort_by_count=True, show_percents=True, truncate=9))
    |                                         N                      |
    |      N      I      A      J             N             V      N |
    |      N      N      T      J      .      S      ,      B      P |
----+----------------------------------------------------------------+
 NN | <11.8%>  0.0%      .   0.2%      .   0.0%      .   0.3%   0.0% |
 IN |   0.0%  <9.0%>     .      .      .   0.0%      .      .      . |
 AT |      .      .  <8.6%>     .      .      .      .      .      . |
 JJ |   1.7%      .      .  <3.9%>     .      .      .   0.0%   0.0% |
  . |      .      .      .      .  <4.8%>     .      .      .      . |
NNS |   1.5%      .      .      .      .  <3.2%>     .      .   0.0% |
  , |      .      .      .      .      .      .  <4.4%>     .      . |
 VB |   0.9%      .      .   0.0%      .      .      .  <2.4%>     . |
 NP |   1.0%      .      .   0.0%      .      .      .      .  <1.8%>|
----+----------------------------------------------------------------+
(row = reference; col = test)

 
 
 
 
 
 
 
###NLTK - Extracting Information from Text
 
##Information Extraction Architecture
  
raw text (string) as Input
 |
 v
STEP - sentence segmentation, OUTPUT - sentences - list of strings 
 |
 v
STEP - tokenization , OUTPUT - tokenized sentences - list of list of strings 
 |
 v
STEP - partof speech tagging , OUTPUT - pos-tagged sentences - list of lists of tuples 
 |
 v
STEP - entity detection, OUTPUT - chunked sentences (list of trees )
 |   Example: Named-entity recognition (NER) 
 |   Entity recognition is often performed using chunkers, 
 |   which segment multi-token sequences, and label them with the appropriate entity type. 
 |   Common entity types include ORGANIZATION, PERSON, LOCATION, DATE, TIME, MONEY, and GPE (geo-political entity).
 |   Chunkers can be constructed using rule-based systems, 
 |   such as the RegexpParser or using machine learning techniques, ConsecutiveNPChunker 
 |   In either case, part-of-speech tags are often a very important feature when searching for chunks.
 |
 |
 v
relation detection , 
 |   Once named entities have been identified in a text,Extract the relations that exist between them
 |   Relation extraction can be performed using either rule-based systems 
 |   which typically look for specific patterns in the text that connect entities and the intervening words;
 |   or using machine-learning systems which typically attempt to learn such patterns automatically from a training corpus.
 v
OUTPUT - relations (list of tuples)


##first three tasks as given earlier 
import nltk 
def ie_preprocess(document):
        sentences = nltk.sent_tokenize(document) #sentence segmentation
        sentences = [nltk.word_tokenize(sent) for sent in sentences] #tokenization 
        sentences = [nltk.pos_tag(sent) for sent in sentences] #partof speech tagging 
 
 
##Tree Reference 
#Chunker produces a Tree structure 

class nltk.tree.Tree(node, children=None)
    Bases: list
    A Tree represents a hierarchical grouping of leaves and subtrees. 
    A tree’s children are encoded as a list of leaves and subtrees, 
    where a leaf is a basic (non-tree) value; and a subtree is a nested Tree.

    The set_label() and label() methods allow individual constituents 
    to be labeled. 
    For example, syntax trees use this label to specify phrase tags, 
    such as “NP” and “VP”.

    Several Tree methods use “tree positions” to specify children 
    or descendants of a tree. 
    Tree positions are defined as follows:
            The tree position i specifies a Tree’s ith child.
            The tree position () specifies the Tree itself.
            If p is the tree position of descendant d, 
            then p+i specifies the ith child of d.

    I.e., every tree position is either a single index i, specifying tree[i]; 
    or a sequence i1, i2, ..., iN, specifying tree[i1][i2]...[iN].

    Constructor can be called in one of two ways:
        Tree(label, children) constructs a new tree with the
            specified label and list of children.
        Tree.fromstring(s) constructs a new tree by parsing the string s.

    chomsky_normal_form(factor='right', horzMarkov=None, vertMarkov=0, childChar='|', parentChar='^')
        This method can modify a tree in three ways:
                Convert a tree into its Chomsky Normal Form (CNF) equivalent – 
                    Every subtree has either two non-terminals 
                    or one terminal as its children. 
                    This process requires the creation of more”artificial” non-terminal nodes.
                Markov (vertical) smoothing of children in new artificial nodes
                Horizontal (parent) annotation of nodes
        factor (str = [left|right]) – Right or left factoring method (default = “right”)
        horzMarkov (int | None) – Markov order for sibling smoothing in artificial nodes (None (default) = include all siblings)
        vertMarkov (int | None) – Markov order for parent smoothing (0 (default) = no vertical annotation)
        childChar (str) – A string used in construction of the artificial nodes, separating the head of the original subtree from the child nodes that have yet to be expanded (default = “|”)
        parentChar (str) – A string used to separate the node representation from its vertical annotation

    collapse_unary(collapsePOS=False, collapseRoot=False, joinChar='+')
        Collapse subtrees with a single child (ie. unary productions) 
        into a new non-terminal (Tree node) joined by ‘joinChar’. 
        This is useful when working with algorithms 
        that do not allow unary productions, 
        and completely removing the unary productions would require loss of useful information. 
        The Tree is modified directly (since it is passed by reference) 
        and no value is returned.
            collapsePOS (bool) – ‘False’ (default) will not collapse the parent of leaf nodes (ie. Part-of-Speech tags) since they are always unary productions
            collapseRoot (bool) – ‘False’ (default) will not modify the root production if it is unary. For the Penn WSJ treebank corpus, this corresponds to the TOP -> productions.
            joinChar (str) – A string used to connect collapsed node values (default = “+”)

    classmethod convert(tree)
        Convert a tree between different subtypes of Tree. 
        cls determines which class will be used to encode the new tree.
        Parameters:	tree (Tree) – The tree that should be converted.
        Returns:	The new Tree.

    copy(deep=False)

    draw()
        Open a new window containing a graphical diagram of this tree.

    flatten()
        Return a flat version of the tree, 
        with all non-root non-terminals removed.
        Returns:	a tree consisting of this tree’s root connected directly to its leaves, omitting all intervening non-terminal nodes.
        Return type:	Tree
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> print(t.flatten())
        (S the dog chased the cat)

    freeze(leaf_freezer=None)

    classmethod fromstring(s, brackets='()', read_node=None, read_leaf=None, node_pattern=None, leaf_pattern=None, remove_empty_top_bracketing=False)
        Read a bracketed tree string and return the resulting tree. 
        Trees are represented as nested brackettings, such as:
        (S (NP (NNP John)) (VP (V runs)))        

    height()
        Return the height of the tree.
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> t.height()
        5
        >>> print(t[0,0])
        (D the)
        >>> t[0,0].height()
        2 

    label()
        Return the node label of the tree.
        >>> t = Tree.fromstring('(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))')
        >>> t.label()
        'S'
        
    leaf_treeposition(index)
        Returns:The tree position of the index-th leaf in this tree. 
                I.e., if tp=self.leaf_treeposition(i), then self[tp]==self.leaves()[i].
        Raises:	IndexError – If this tree contains fewer than index+1 leaves, or if index<0.

    leaves()
        Return the leaves of the tree.
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> t.leaves()
        ['the', 'dog', 'chased', 'the', 'cat']        

    node
        Outdated method to access the node value; 
        use the label() method instead.

    pformat(margin=70, indent=0, nodesep='', parens='()', quotes=False)
        Returns:A pretty-printed string representation of this tree.
        Return type:  str
 
    pformat_latex_qtree()
        Returns a representation of the tree compatible 
        with the LaTeX qtree package. 
        This consists of the string \Tree followed by the tree represented 
        in bracketed notation.
        Returns:	A latex qtree representation of this tree.
        Return type:	str

    pos()
        Return a sequence of pos-tagged words extracted from the tree.
                Return type:	list(tuple)
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> t.pos()
        [('the', 'D'), ('dog', 'N'), ('chased', 'V'), ('the', 'D'), ('cat', 'N')]  

    pprint(**kwargs)
        Print a string representation of this Tree to ‘stream’

    pretty_print(sentence=None, highlight=(), stream=None, **kwargs)
        Pretty-print this tree as ASCII or Unicode art. 

    productions()
        Generate the productions that correspond to the non-terminal nodes of the tree. 
        For each subtree of the form (P: C1 C2 ... Cn) 
        this produces a production of the form P -> C1 C2 ... Cn.
            Return type:	list(Production)
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> t.productions()
        [S -> NP VP, NP -> D N, D -> 'the', N -> 'dog', VP -> V NP, V -> 'chased',
        NP -> D N, D -> 'the', N -> 'cat']     

    set_label(label)
        Set the node label of the tree.
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> t.set_label("T")
        >>> print(t)
        (T (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))

    subtrees(filter=None)
        Generate all the subtrees of this tree, 
        optionally restricted to trees matching the filter function.
            filter (function) – the function to filter all local trees
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> for s in t.subtrees(lambda t: t.height() == 2):
                print(s)
        (D the)
        (N dog)
        (V chased)
        (D the)
        (N cat)

    treeposition_spanning_leaves(start, end)
        Returns:The tree position of the lowest descendant of this tree 
                that dominates self.leaves()[start:end].
        Raises:	ValueError – if end <= start

    treepositions(order='preorder')
            order – One of: preorder, postorder, bothorder, leaves.
        >>> t = Tree.fromstring("(S (NP (D the) (N dog)) (VP (V chased) (NP (D the) (N cat))))")
        >>> t.treepositions() 
        [(), (0,), (0, 0), (0, 0, 0), (0, 1), (0, 1, 0), (1,), (1, 0), (1, 0, 0), ...]
        >>> for pos in t.treepositions('leaves'):
                t[pos] = t[pos][::-1].upper()
        >>> print(t)
        (S (NP (D EHT) (N GOD)) (VP (V DESAHC) (NP (D EHT) (N TAC))))

    un_chomsky_normal_form(expandUnary=True, childChar='|', parentChar='^', unaryChar='+')
        This method modifies the tree in three ways:
                Transforms a tree in Chomsky Normal Form back to its original structure (branching greater than two)
                Removes any parent annotation (if it exists)
                (optional) expands unary subtrees (if previously collapsed with collapseUnary(...) )
            expandUnary (bool) – Flag to expand unary or not (default = True)
            childChar (str) – A string separating the head node from its children in an artificial node (default = “|”)
            parentChar (str) – A sting separating the node label from its parent annotation (default = “^”)
            unaryChar (str) – A string joining two non-terminals in a unary production (default = “+”)

            
#Other interesting class 

class nltk.tree.ProbabilisticMixIn(**kwargs)
    Bases: object
    A mix-in class to associate probabilities with other classes (trees, rules, etc.). 
    
    logprob()
        Return log(p), where p is the probability associated with this object.
        Return type:	float

    prob()
        Return the probability associated with this object.
        Return type:	float

    set_logprob(logprob)
        Set the log probability associated with this object to logprob. I.e., set the probability associated with this object to 2**(logprob).
        Parameters:	logprob (float) – The new log probability

    set_prob(prob)
        Set the probability associated with this object to prob.
        Parameters:	prob (float) – The new probability

class nltk.tree.ProbabilisticTree(node, children=None, **prob_kwargs)
    Bases: nltk.tree.Tree, nltk.probability.ProbabilisticMixIn



    
    
#Example 
from nltk.tree import Tree

>>> print(Tree(1, [2, Tree(3, [4]), 5]))
(1 2 (3 4) 5)
>>> vp = Tree('VP', [Tree('V', ['saw']),Tree('NP', ['him'])])
>>> s = Tree('S', [Tree('NP', ['I']), vp])
>>> print(s)
(S (NP I) (VP (V saw) (NP him)))
>>> print(s[1])
(VP (V saw) (NP him))
>>> print(s[1,1])
(NP him)
>>> t = Tree.fromstring("(S (NP I) (VP (V saw) (NP him)))")
>>> s == t
True
>>> t[1][1].set_label('X')
>>> t[1][1].label()
'X'
>>> print(t)
(S (NP I) (VP (V saw) (X him)))
>>> t[0], t[1,1] = t[1,1], t[0]
>>> print(t)
(S (X him) (VP (V saw) (NP I)))
#Tree Traversal
def traverse(t):
    try:
        t.label()
    except AttributeError:
        print(t, end=" ")
    else:
        # Now we know that t.node is defined
        print('(', t.label(), end=" ")
        for child in t:
            traverse(child)
        print(')', end=" ")

>>> t = nltk.Tree('(S (NP Alice) (VP chased (NP the rabbit)))')
>>> traverse(t)
 ( S ( NP Alice ) ( VP chased ( NP the rabbit ) ) )

The length of a tree is the number of children it has.
>>> len(t)
2


# Demonstrate tree parsing.
s = '(S (NP (DT the) (NN cat)) (VP (VBD ate) (NP (DT a) (NN cookie))))'
t = Tree.fromstring(s)
print("Convert bracketed string into tree:")
print(t)
print(t.__repr__())

print("Display tree properties:")
print(t.label())         # tree's constituent type
print(t[0])             # tree's first child
print(t[1])             # tree's second child
print(t.height())
print(t.leaves())
print(t[1])
print(t[1,1])
print(t[1,1,0])

# Demonstrate tree modification.
the_cat = t[0]
the_cat.insert(1, Tree.fromstring('(JJ big)'))
print("Tree modification:")
print(t)
t[1,1,1] = Tree.fromstring('(NN cake)')
print(t)
print()

# Tree transforms
print("Collapse unary:")
t.collapse_unary()
print(t)
print("Chomsky normal form:")
t.chomsky_normal_form()
print(t)
print()

# Demonstrate probabilistic trees.
pt = ProbabilisticTree('x', ['y', 'z'], prob=0.5)
print("Probabilistic Tree:")
print(pt)
print()

# Demonstrate parsing of treebank output format.
t = Tree.fromstring(t.pformat())
print("Convert tree to bracketed string and back again:")
print(t)
print()

# Demonstrate LaTeX output
print("LaTeX output:")
print(t.pformat_latex_qtree())
print()

# Demonstrate Productions
print("Production output:")
print(t.productions())
print()

# Demonstrate tree nodes containing objects other than strings
t.set_label(('test', 3))
print(t)


 
 
 
##Named Entity(NEs) Recognition
#Named entities are definite noun phrases that refer to specific types of individuals, 
#such as organizations, persons, dates, and so on.

##Commonly Used Types of Named Entity
#NE Type                    Examples
ORGANIZATION                Georgia-Pacific Corp., WHO 
PERSON                      Eddy Bonte, President Obama 
LOCATION                    Murray River, Mount Everest 
DATE                        June, 2008-06-29 
TIME                        two fifty a m, 1:30 p.m. 
MONEY                       175 million Canadian Dollars, GBP 10.40 
PERCENT                     twenty pct, 18.75 % 
FACILITY                    Washington Monument, Stonehenge 
GPE                         South East Asia, Midlothian 

#The goal of a named entity recognition (NER) system 
#is to identify all textual mentions of the named entities. 

#In practice use below 
nltk.chunk.ne_chunk(tagged_tokens, binary=False)
    Use NLTK’s currently recommended named entity chunker 
    to chunk the given list of tagged tokens.
nltk.chunk.ne_chunk_sents(tagged_sentences, binary=False)
    Use NLTK’s currently recommended named entity chunker 
    to chunk the given list of tagged sentences, each consisting of a list of tagged tokens.


#If we set the parameter binary=True , then named entities are just tagged as NE; 
#otherwise, the classifier adds category labels such as PERSON, ORGANIZATION, and GPE.

>>> sent = nltk.corpus.treebank.tagged_sents()[22] #any POS-tagged sentence 
>>> print(nltk.ne_chunk(sent, binary=True)) 
(S
  The/DT
  (NE U.S./NNP)
  is/VBZ
  one/CD
  ...
  according/VBG
  to/TO
  (NE Brooke/NNP T./NNP Mossman/NNP)
  ...)
 
 
>>> print(nltk.ne_chunk(sent)) 
(S
  The/DT
  (GPE U.S./NNP)
  is/VBZ
  one/CD
  ...
  according/VBG
  to/TO
  (PERSON Brooke/NNP T./NNP Mossman/NNP)
  ...)
  
#Example 
sentence = "Mark and John are working at Google."

# extract the label of each Name Entity in the text using this code
import nltk
for sent in nltk.sent_tokenize(sentence):
   for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sent))):
      if hasattr(chunk, 'label'):
         print(chunk.label(), ' '.join(c[0] for c in chunk))
         
#IOB tagging - standard way of annotating chunks

from nltk import word_tokenize, pos_tag, ne_chunk
from nltk.chunk import tree2conlltags

#This will give you a list of tuples: [(token, pos_tag, name_entity_tag)]
#better than Tree parsing 
print(tree2conlltags(ne_chunk(pos_tag(word_tokenize(my_sent))
"""[('Mark', 'NNP', 'B-PERSON'), 
    ('and', 'CC', 'O'), ('John', 'NNP', 'B-PERSON'), 
    ('are', 'VBP', 'O'), ('working', 'VBG', 'O'), 
    ('at', 'IN', 'O'), ('Google', 'NNP', 'B-ORGANIZATION'), 
    ('.', '.', 'O')] """

 
#The IEER corpus is marked up for a variety of Named Entities
#For example, the Named Entity classes in IEER include PERSON, LOCATION, ORGANIZATION, DATE and so on. 
#Within NLTK, Named Entities are represented as subtrees within a chunk structure: 
#the class name is treated as node label, while the entity mention itself appears as the leaves of the subtree

from nltk.corpus import ieer
docs = ieer.parsed_docs('NYT_19980315')
tree = docs[1].text
>>> print(tree) # doctest: +ELLIPSIS
(DOCUMENT
...
  ``It's
  a
  chance
  to
  think
  about
  first-level
  questions,''
  said
  Ms.
  (PERSON Cohn)
  ,
  a
  partner
  in
  the
  (ORGANIZATION McGlashan &AMP; Sarrail)
  firm
  in
  (LOCATION San Mateo)
  ,
  (LOCATION Calif.)
  ...)

  




    
    
    
    

##Relation Extraction
#NLTK's extract_rels use NE_CLASSES from corpus- 'ace', ‘ieer’ and ‘conll2002’ corpus
ace 
    weblogs, broadcast news, newsgroups, broadcast conversation
ieer 
    This corpus contains the NEWSWIRE development test data for the NIST 1999 IE-ER Evaluation.
conll2002 
    Dutch and Spanish data, the strings are also POS tagged.

#Once named entities have been identified in a text, we then want to extract the relations that exist between them


nltk.sem.relextract.tree2semi_rel(tree)
    Group a chunk structure into a list of ‘semi-relations’ 
    of the form (list(str), Tree).
    In order to facilitate the construction of (Tree, string, Tree) triples, 
    this identifies pairs whose first member is a list (possibly empty) 
    of terminal strings, and whose second member is a Tree of the form (NE_label, terminals).
        Parameters:	tree – a chunk tree
        Returns:	a list of pairs (list(str), Tree)
        
nltk.sem.relextract.semi_rel2reldict(pairs, window=5, trace=False)
    Converts the pairs (len > 2) generated by tree2semi_rel into a ‘reldict’
    ‘reldict’: a dictionary which stores information about the subject 
    and object NEs plus the filler between them. 
    Additionally, a left and right context of length =< window are captured (within a given input sentence).
        pairs – a pair of list(str) and Tree, as generated by tree2semi_rel, must be > 2
        window (int) – a threshold for the number of items to include in the left and right context
    Returns: ‘relation’ dictionaries whose keys are 
        ‘lcon’, ‘subjclass’, ‘subjtext’, ‘subjsym’, ‘filler’, objclass’, objtext’, 
        ‘objsym’ and ‘rcon’
    #Details 
    result = []
    while len(pairs) > 2:    
        reldict = defaultdict(str)    
        reldict['lcon'] = _join(pairs[0][0][-window:])    
        reldict['subjclass'] = pairs[0][1].label()    
        reldict['subjtext'] = _join(pairs[0][1].leaves())    
        reldict['subjsym'] = list2sym(pairs[0][1].leaves())    
        reldict['filler'] = _join(pairs[1][0])    
        reldict['untagged_filler'] = _join(pairs[1][0], untag=True)    
        reldict['objclass'] = pairs[1][1].label()    
        reldict['objtext'] = _join(pairs[1][1].leaves())    
        reldict['objsym'] = list2sym(pairs[1][1].leaves())    
        reldict['rcon'] = _join(pairs[2][0][:window])    #this requires len > 2
        result.append(reldict)    
        pairs = pairs[1:]        
    return result   

    
#The tree2semi_rel() function splits a chunk document into a list of two-member lists, 
#each of which consists of a (possibly empty) string followed by a Tree (i.e., a Named Entity):

from nltk.sem import relextract
from nltk.corpus import ieer

docs = ieer.parsed_docs('NYT_19980315')
tree = docs[1].text

pairs = relextract.tree2semi_rel(tree)
for s, tree in pairs[18:22]:
    print('("...%s", %s)' % (" ".join(s[-5:]),tree))
#OUTPUT 
("...about first-level questions,'' said Ms.", (PERSON Cohn))
("..., a partner in the", (ORGANIZATION McGlashan &AMP; Sarrail))
("...firm in", (LOCATION San Mateo))
("...,", (LOCATION Calif.))


#The function semi_rel2reldict() processes triples of these pairs, 
#i.e., pairs of the form ((string1, Tree1), (string2, Tree2), (string3, Tree3)) 
#and outputs a dictionary (a reldict) in which Tree1 is the subject of the relation, 
#string2 is the filler and Tree3 is the object of the relation. 
#string1 and string3 are stored as left and right context respectively.

reldicts = relextract.semi_rel2reldict(pairs)
for k, v in sorted(reldicts[0].items()):
    print(k, '=>', v) # doctest: +ELLIPSIS
#OUTPUT 
filler => of messages to their own ``Cyberia'' ...
lcon => transactions.'' Each week, they post
objclass => ORGANIZATION
objsym => white_house
objtext => White House
rcon => for access to its planned
subjclass => CARDINAL
subjsym => hundreds
subjtext => hundreds
untagged_filler => of messages to their own ``Cyberia'' ...



#The function relextract() allows us to filter the reldicts (generated by semi_rel2reldict)
#according to the classes of the subject and object named entities. 
#In addition, we can specify that the filler text has to match a given regular expression, 

nltk.sem.relextract.extract_rels(subjclass, objclass, doc, corpus='ace', 
        pattern=None, window=10)
    Filter the output of semi_rel2reldict according to specified NE classes 
    and a filler pattern.
    Note to use this, given only NER chunked Tree in doc 
    
    The parameters subjclass and objclass can be used to restrict the Named Entities to particular types 
    (any of ‘LOCATION’, ‘ORGANIZATION’, ‘PERSON’, ‘DURATION’, ‘DATE’, ‘CARDINAL’, ‘PERCENT’, ‘MONEY’, ‘MEASURE’).

        subjclass (str) – the class of the subject Named Entity.
        objclass (str) – the class of the object Named Entity.
        doc (ieer document or a list of chunk trees) – input document
        corpus (str) – name of the corpus to take as input;
            possible values are ace, ‘ieer’ and ‘conll2002’
        pattern (SRE_Pattern) – a regular expression for filtering the fillers of retrieved triples.
        window (int) – filters out fillers which exceed this threshold  
    Return type:list(defaultdict)
    #Inner working 
    1. It checks whether subjclass and objclassare valid by checking in NE_CLASSES[corpus]
        NE_CLASSES = {
        'ieer': ['LOCATION', 'ORGANIZATION', 'PERSON', 'DURATION',
                'DATE', 'CARDINAL', 'PERCENT', 'MONEY', 'MEASURE'],
        'conll2002': ['LOC', 'PER', 'ORG'],
        'ace': ['LOCATION', 'ORGANIZATION', 'PERSON', 'DURATION',
                'DATE', 'CARDINAL', 'PERCENT', 'MONEY', 'MEASURE', 'FACILITY', 'GPE'],
        }
      Note, it uses corpus only for these puposes, else this function is general
    2. It extracts "pairs" from your NE tagged inputs by tree2semi_rel
    3. Converts to reldict by semi_rel2reldict, Note pairs should have length 3 else, nothing gets output 
    4. Filters based on 'pattern' and subjclass, objclass and returns list(reldicts)
        reldicts = semi_rel2reldict(pairs)
        relfilter = lambda x: (x['subjclass'] == subjclass and
                               len(x['filler'].split()) <= window and
                               pattern.match(x['filler']) and
                               x['objclass'] == objclass)
        return list(filter(relfilter, reldicts))
    
 
nltk.sem.relextract.rtuple(reldict, lcon=False, rcon=False)
    Pretty print the reldict as an rtuple. 
    reldict: a relation dictionary 
    
    
#Example - we are looking for pairs of entities in the IN relation, 
#where IN has signature <ORG, LOC>.

import re
IN = re.compile(r'.*\bin\b(?!\b.+ing\b)') #lookahead assertions 
for fileid in ieer.fileids():
    for doc in ieer.parsed_docs(fileid):
        for rel in relextract.extract_rels('ORG', 'LOC', doc, corpus='ieer', pattern = IN):
            print(relextract.rtuple(rel))  # doctest: +ELLIPSIS
            
#Example 
[ORG: 'Christian Democrats'] ', the leading political forces in' [LOC: 'Italy']
[ORG: 'AP'] ') _ Lebanese guerrillas attacked Israeli forces in southern' [LOC: 'Lebanon']
[ORG: 'Security Council'] 'adopted Resolution 425. Huge yellow banners hung across intersections in' [LOC: 'Beirut']
[ORG: 'U.N.'] 'failures in' [LOC: 'Africa']
[ORG: 'U.N.'] 'peacekeeping operation in' [LOC: 'Somalia']
[ORG: 'U.N.'] 'partners on a more effective role in' [LOC: 'Africa']
[ORG: 'AP'] ') _ A bomb exploded in a mosque in central' [LOC: 'San`a']
[ORG: 'Krasnoye Sormovo'] 'shipyard in the Soviet city of' [LOC: 'Gorky']
[ORG: 'Kelab Golf Darul Ridzuan'] 'in' [LOC: 'Perak']
[ORG: 'U.N.'] 'peacekeeping operation in' [LOC: 'Somalia']
[ORG: 'WHYY'] 'in' [LOC: 'Philadelphia']
[ORG: 'McGlashan &AMP; Sarrail'] 'firm in' [LOC: 'San Mateo']
[ORG: 'Freedom Forum'] 'in' [LOC: 'Arlington']
[ORG: 'Brookings Institution'] ', the research group in' [LOC: 'Washington']
[ORG: 'Idealab'] ', a self-described business incubator based in' [LOC: 'Los Angeles']
[ORG: 'Open Text'] ', based in' [LOC: 'Waterloo']
...



#Example 
from nltk import ne_chunk, pos_tag, word_tokenize
from nltk.sem.relextract import tree2semi_rel, semi_rel2reldict, extract_rels, rtuple

text = "Tom is the cofounder of Microsoft and now he is the founder of Marcohard"
chunked = ne_chunk(pos_tag(word_tokenize(text)))
>>> chunked
Tree('S', [Tree('PERSON', [('Tom', 'NNP')]), ('is', 'VBZ'), ('the', 'DT'), ('cofounder', 'NN'), ('of', 'IN'), Tree('ORGANIZATION', [('Microsoft', 'NNP')]), ('and', 'CC'), ('now', 'RB'), ('he', 'PRP'), ('is', 'VBZ'), ('the', 'DT'), ('founder', 'NN'), ('of', 'IN'), Tree('PERSON', [('Marcohard', 'NNP')])])
>>> tree2semi_rel(chunked)
[[[], Tree('PERSON', [('Tom', 'NNP')])], [[('is', 'VBZ'), ('the', 'DT'), ('cofounder', 'NN'), ('of', 'IN')], Tree('ORGANIZATION', [('Microsoft', 'NNP')])], [[('and', 'CC'), ('now', 'RB'), ('he', 'PRP'), ('is', 'VBZ'), ('the', 'DT'), ('founder', 'NN'), ('of', 'IN')], Tree('PERSON', [('Marcohard', 'NNP')])]]
>>> len(tree2semi_rel(chunked)) > 2
True
>>> semi_rel2reldict(tree2semi_rel(chunked))
[defaultdict(<type 'str'>, {'lcon': '', 'untagged_filler': 'is the cofounder of', 'filler': 'is/VBZ the/DT cofounder/NN of/IN', 'objsym': 'microsoft', 'objclass': 'ORGANIZATION', 'objtext': 'Microsoft/NNP', 'subjsym': 'tom', 'subjclass': 'PERSON', 'rcon': 'and/CC now/RB he/PRP is/VBZ the/DT', 'subjtext': 'Tom/NNP'})]

rels = extract_rels('PER', 'GPE', chunked, corpus='ace', pattern=OF, window=10) 
for rel in rels:
    print('{0:<5}{1}'.format(i, rtuple(rel)))


#Where Pairs length is <=2 
from nltk.sem.relextract import tree2semi_rel, semi_rel2reldict
from nltk import word_tokenize, pos_tag, ne_chunk
text = "Tom is the cofounder of Microsoft"
chunked = ne_chunk(pos_tag(word_tokenize(text)))

>>> tree2semi_rel(chunked)
[[[], Tree('PERSON', [('Tom', 'NNP')])], [[('is', 'VBZ'), ('the', 'DT'), ('cofounder', 'NN'), ('of', 'IN')], Tree('ORGANIZATION', [('Microsoft', 'NNP')])]]
>>> len(tree2semi_rel(chunked))
2
>>> semi_rel2reldict(tree2semi_rel(chunked))
[]


#Another Exmaple 
#note for first line - - does not ouput any thing is len of pairs is <= 2 
import re
import nltk
from nltk.sem.relextract import extract_rels, rtuple
from nltk.tokenize import sent_tokenize, word_tokenize


with open('sample.txt', 'r') as f:
    sample = f.read()   # "Tom is the cofounder of Microsoft" 
                        #"Tom is the cofounder of Microsoft and now he is the founder of Marcohard"
sentences = sent_tokenize(sample)
tokenized_sentences = [word_tokenize(sentence) for sentence in sentences]
tagged_sentences = [nltk.tag.pos_tag(sentence) for sentence in tokenized_sentences]

OF = re.compile(r'.*\bof\b.*')

for i, sent in enumerate(tagged_sentences):
    sent = nltk.chunk.ne_chunk(sent) # ne_chunk method expects one tagged sentence
    rels = extract_rels('PER', 'GPE', sent, corpus='ace', pattern=OF, window=10) 
    for rel in rels:
        print('{0:<5}{1}'.format(i, rtuple(rel)))

            
            
#To use above when length of Pairs is == 2 
#Use own version of semi_rel2reldict by removing rcon part 
def semi_rel2reldict_mine(pairs, window=5, trace=False):
    from nltk.sem.relextract import _join, list2sym
    from collections import defaultdict
    result = []
    while len(pairs) >= 2:
        reldict = defaultdict(str)
        reldict['lcon'] = _join(pairs[0][0][-window:])
        reldict['subjclass'] = pairs[0][1].label()
        reldict['subjtext'] = _join(pairs[0][1].leaves())
        reldict['subjsym'] = list2sym(pairs[0][1].leaves())
        reldict['filler'] = _join(pairs[1][0])
        reldict['untagged_filler'] = _join(pairs[1][0], untag=True)
        reldict['objclass'] = pairs[1][1].label()
        reldict['objtext'] = _join(pairs[1][1].leaves())
        reldict['objsym'] = list2sym(pairs[1][1].leaves())
        #reldict['rcon'] = _join(pairs[2][0][:window]) 
        result.append(reldict)
        pairs = pairs[1:]
    return result
    
#Exmaple 
import re
import nltk
from nltk import ne_chunk, pos_tag, word_tokenize
from nltk.sem.relextract import extract_rels, rtuple, semi_rel2reldict, tree2semi_rel

text = "Tom is the cofounder of Microsoft"
chunked = ne_chunk(pos_tag(word_tokenize(text)))

tree2semi_rel(chunked)
#[[[], Tree('PERSON', [('Tom', 'NNP')])], [[('is', 'VBZ'), ('the', 'DT'), ('cofounder', 'NN'), ('of', 'IN')], Tree('ORGANIZATION', [('Microsoft', 'NNP')])]]

semi_rel2reldict(tree2semi_rel(chunked))
#[]

semi_rel2reldict_mine(tree2semi_rel(chunked))
#[defaultdict(<class 'str'>, {'objsym': 'microsoft', 'subjclass': 'PERSON', 'objclass': 'ORGANIZATION', 'subjtext': 'Tom/NNP', 'filler': 'is/VBZ the/DT cofounder/NN of/IN', 'subjsym': 'tom', 'lcon': '', 'untagged_filler': 'is the cofounder of', 'objtext': 'Microsoft/NNP'})]


#Then extract 
pairs = tree2semi_rel(chunked)
reldicts = semi_rel2reldict_mine(pairs)
relfilter = lambda x: (x['subjclass'] == subjclass and
                       len(x['filler'].split()) <= window and
                       pattern.match(x['filler']) and
                       x['objclass'] == objclass)
rels = list(filter(relfilter, reldicts))       
for rel in rels:
    print('{0:<5}{1}'.format(i, rtuple(rel)))   
        
        
        
        
        
        


##Advanced - Detailes of Chunking 
##Noun Phrase Chunking - NP-chunking
#where we search for chunks corresponding to individual noun phrases. 

#For example, here is some Wall Street Journal text with NP-chunks marked using brackets:
[ The/DT market/NN ] for/IN [ system-management/NN software/NN ] for/IN [ Digital/NNP ] [ 's/POS hardware/NN ] is/VBZ fragmented/JJ enough/RB that/IN [ a/DT giant/NN ] such/JJ as/IN [ Computer/NNP Associates/NNPS ] should/MD do/VB well/RB there/RB ./. 


#In order to create an NP-chunker, 
#we will first define a chunk grammar, consisting of rules that indicate how sentences should be chunked. 

#A chunk is a non-overlapping linguistic group, such as a noun phrase.
#chinks - removes anything that matches a given regular expression.


#Rule syntax 
    {regexp}         # chunk rule
    }regexp{         # chink rule
    regexp}{regexp   # split rule
    regexp{}regexp   # merge rule
    Where regexp is a regular expression for the rule. 
    Any text following the comment marker (#) will be used as the rule’s description:
    
#The differences between regular expression patterns and tag patterns are:
1.In tag patterns, '<' and '>' act as parentheses; 
  so '<NN>+' matches one or more repetitions of '<NN>', 
  not '<NN' followed by one or more repetitions of '>'.
2.Whitespace in tag patterns is ignored. 
  So '<DT> | <NN>' is equivalant to '<DT>|<NN>'
3.In tag patterns, '.' is equivalant to '[^{}<>]'; 
so '<NN.*>' matches any single tag starting with 'NN'.

#this is output of nltk.pos_tag()
>>> sentence = [("the", "DT"), ("little", "JJ"), ("yellow", "JJ"), 
        ("dog", "NN"), ("barked", "VBD"), ("at", "IN"),  ("the", "DT"), ("cat", "NN")]
        
#Example - regular Expression NP chunking 
#rule says that an NP chunk should be formed 
#whenever the chunker finds an optional determiner (DT) followed by any number of adjectives (JJ) and then a noun (NN).
grammar = "NP: {<DT>?<JJ>*<NN>}" 

cp = nltk.RegexpParser(grammar) 
result = cp.parse(sentence) 
>>> print(result) 
(S
  (NP the/DT little/JJ yellow/JJ dog/NN)
  barked/VBD
  at/IN
  (NP the/DT cat/NN))
>>> result.draw() #draw tree diagram 

#Basically the output is 
                                        S
    NP                               barked/VBD   at/IN          NP
the/DT little/JJ yellow/JJ dog/NN                           the/DT cat/NN
 
 
 


##Multiple rules for Chunking with Regular Expressions

#The first rule matches an optional determiner or possessive pronoun, zero or more adjectives, then a noun. 
#The second rule matches one or more proper nouns. 

grammar = r"""
  NP: {<DT|PP\$>?<JJ>*<NN>}   # chunk determiner/possessive, adjectives and noun
      {<NNP>+}                # chunk sequences of proper nouns
"""
cp = nltk.RegexpParser(grammar)
sentence = [("Rapunzel", "NNP"), ("let", "VBD"), ("down", "RP"), 
                 ("her", "PP$"), ("long", "JJ"), ("golden", "JJ"), ("hair", "NN")]
 
 

>>> print(cp.parse(sentence)) 
(S
  (NP Rapunzel/NNP)
  let/VBD
  down/RP
  (NP her/PP$ long/JJ golden/JJ hair/NN))
 
>>> cp.parse(sentence).draw() #draw tree diagram 


#If a tag pattern matches at overlapping locations, 
#the leftmost match takes precedence. 

>>> nouns = [("money", "NN"), ("market", "NN"), ("fund", "NN")]
>>> grammar = "NP: {<NN><NN>}  # Chunk two consecutive nouns"
>>> cp = nltk.RegexpParser(grammar)
>>> print(cp.parse(nouns))
(S (NP money/NN market/NN) fund/NN)
 
 
##Using chunker - Exploring Text Corpora

#For a tagged corpus to extract phrases matching a particular sequence of part-of-speech tags. 
#(this can be done via eg Text.findall(r"<a> (<.*>) <man>") , but chunker is easier)

>>> cp = nltk.RegexpParser('CHUNK: {<V.*> <TO> <V.*>}')  #CHUNK is label of TREE 
>>> brown = nltk.corpus.brown
>>> for sent in brown.tagged_sents():
        tree = cp.parse(sent)
        for subtree in tree.subtrees():
            if subtree.label() == 'CHUNK': print(subtree)
#OUTPUT 
(CHUNK combined/VBN to/TO achieve/VB)
(CHUNK continue/VB to/TO place/VB)
(CHUNK serve/VB to/TO protect/VB)
(CHUNK wanted/VBD to/TO wait/VB)
(CHUNK allowed/VBN to/TO place/VB)
(CHUNK expected/VBN to/TO become/VB)
...
(CHUNK seems/VBZ to/TO overtake/VB)
(CHUNK want/VB to/TO buy/VB)
 
 
##Chinking
#defines what we want to exclude from a chunk. 
#We can define a chink to be a sequence of tokens that is not included in a chunk. 

#In the following example, barked/VBD at/IN is a chink:
[ the/DT little/JJ yellow/JJ dog/NN ] barked/VBD at/IN [ the/DT cat/NN ]

grammar = r"""
  NP:
    {<.*>+}          # Chunk everything
    }<VBD|IN>+{      # Chink sequences of VBD and IN
  """
sentence = [("the", "DT"), ("little", "JJ"), ("yellow", "JJ"),
       ("dog", "NN"), ("barked", "VBD"), ("at", "IN"),  ("the", "DT"), ("cat", "NN")]
cp = nltk.RegexpParser(grammar)
>>> print(cp.parse(sentence))
(S
   (NP the/DT little/JJ yellow/JJ dog/NN)
   barked/VBD
   at/IN
   (NP the/DT cat/NN))
 
 
##Example - Three chinking rules applied to the same chunk
#                Entire chunk            Middle of a chunk              End of a chunk
Input       [a/DT little/JJ dog/NN]     [a/DT little/JJ dog/NN]         [a/DT little/JJ dog/NN] 
Operation   Chink "DT JJ NN"            Chink "JJ"                      Chink "NN" 
Pattern     }DT JJ NN{                  }JJ{                            }NN{ 
Output      a/DT little/JJ dog/NN       [a/DT] little/JJ [dog/NN]       [a/DT little/JJ] dog/NN 

 
##Representing Chunks: Tags vs Trees
#chunk structures can be represented using either tags or trees. 
#The most widespread file representation uses IOB tags. 

#In this scheme, each token is tagged with one of three special chunk tags, 
#I (inside), O (outside), or B (begin). 

#A token is tagged as B if it marks the beginning of a chunk. 
#Subsequent tokens within the chunk are tagged I. 
#All other tokens are tagged O. 

#The B and I tags are suffixed with the chunk type, e.g. B-NP, I-NP. 

#Example 
We PRP B-NP
saw VBD O
the DT B-NP
yellow JJ I-NP
dog NN I-NP



##Reading IOB Format and the CoNLL 2000 Corpus
#CoNLL 2000 corpus - Wall Street Journal text that has been tagged then chunked using the IOB notation. 
#The chunk categories provided in this corpus are NP, VP and PP. 

#As we have seen, each sentence is represented using multiple lines, as shown below:
he PRP B-NP
accepted VBD B-VP
the DT B-NP
position NN I-NP
...

#A conversion function chunk.conllstr2tree() builds a tree representation 
#from one of these multi-line strings. 

nltk.chunk.util.conllstr2tree(s, chunk_types=('NP', 'PP', 'VP'), root_label='S')
    Return a chunk structure for a single sentence encoded in the given CONLL 2000 style string.
    This function converts a CoNLL IOB string into a tree.

nltk.chunk.util.conlltags2tree(sentence, chunk_types=('NP', 'PP', 'VP'), root_label='S', strict=False)
    Convert the CoNLL IOB format to a tree.
    
nltk.chunk.util.tagstr2tree(s, chunk_label='NP', root_label='S', sep='/', source_tagset=None, target_tagset=None)
    Divide a string of bracketted tagged text into chunks and unchunked tokens, 
    and produce a Tree. Chunks are marked by square brackets ([...]). 
    Words are delimited by whitespace, and each word should have the form text/tag. 
    
    Words that do not contain a slash are assigned a tag of None.
nltk.chunk.util.ieerstr2tree(s, chunk_types=['LOCATION', 'ORGANIZATION', 'PERSON', 'DURATION', 'DATE', 'CARDINAL', 'PERCENT', 'MONEY', 'MEASURE'], root_label='S')
    Return a chunk structure containing the chunked tagged text that is encoded in the given IEER style string. 
    Convert a string of chunked tagged text in the IEER named entity format into a chunk structure. 
    Chunks are of several types, LOCATION, ORGANIZATION, PERSON, DURATION, DATE, CARDINAL, PERCENT, MONEY, and MEASURE.
    
nltk.chunk.util.tree2conllstr(tree)
    Return a multiline string where each line contains a word, tag and IOB tag. 
    Convert a tree to the CoNLL IOB string format
    
nltk.chunk.util.tree2conlltags(t)
    Return a list of 3-tuples containing (word, tag, IOB-tag). 
    Convert a tree to the CoNLL IOB tag format.
    
nltk.chunk.util.accuracy(chunker, gold)
    Score the accuracy of the chunker against the gold standard. 
    Strip the chunk information from the gold standard and rechunk it using the chunker, 
    then compute the accuracy score


#FOr example -  for NP chunks:

>>> text = '''
 he PRP B-NP
 accepted VBD B-VP
 the DT B-NP
 position NN I-NP
 of IN B-PP
 vice NN B-NP
 chairman NN I-NP
 of IN B-PP
 Carlyle NNP B-NP
 Group NNP I-NP
 , , O
 a DT B-NP
 merchant NN I-NP
 banking NN I-NP
 concern NN I-NP
 . . O
 '''
>>> nltk.chunk.conllstr2tree(text, chunk_types=['NP']).draw()
 
 

#The CoNLL 2000 corpus contains 270k words of Wall Street Journal text, 
#divided into "train" and "test" portions, annotated with part-of-speech tags and chunk tags in the IOB format. 

>>> from nltk.corpus import conll2000
>>> print(conll2000.chunked_sents('train.txt')[99])
(S
  (PP Over/IN)
  (NP a/DT cup/NN)
  (PP of/IN)
  (NP coffee/NN)
  ,/,
  (NP Mr./NNP Stone/NNP)
  (VP told/VBD)
  (NP his/PRP$ story/NN)
  ./.)
 
 

#the CoNLL 2000 corpus contains three chunk types: 
#NP chunks, which we have already seen; 
#VP chunks such as 'has already delivered'; 
#and PP chunks such as 'because of'. 

#For -  only NP chunks 
>>> print(conll2000.chunked_sents('train.txt', chunk_types=['NP'])[99])
(S
  Over/IN
  (NP a/DT cup/NN)
  of/IN
  (NP coffee/NN)
  ,/,
  (NP Mr./NNP Stone/NNP)
  told/VBD
  (NP his/PRP$ story/NN)
  ./.)
 

  

##chunk - Simple Evaluation and creating Baselines

#Establish a baseline for the trivial chunk parser cp that creates no chunks:
>>> from nltk.corpus import conll2000
>>> cp = nltk.RegexpParser("")
>>> test_sents = conll2000.chunked_sents('test.txt', chunk_types=['NP'])
>>> print(cp.evaluate(test_sents))
ChunkParse score:
    IOB Accuracy:  43.4%
    Precision:      0.0%
    Recall:         0.0%
    F-Measure:      0.0%
 
#The IOB tag accuracy indicates that more than a third of the words are tagged with O, 
#i.e. not in an NP chunk. 
#since our tagger did not find any chunks, its precision, recall, and f-measure are all zero. 


#Example - tags beginning with letters that are characteristic of noun phrase tags (e.g. CD, DT, and JJ).
grammar = r"NP: {<[CDJNP].*>+}"
cp = nltk.RegexpParser(grammar)
>>> print(cp.evaluate(test_sents))
ChunkParse score:
    IOB Accuracy:  87.7%
    Precision:     70.6%
    Recall:        67.8%
    F-Measure:     69.2%
 
 
#OR Using  training corpus to find the chunk tag (I, O, or B) that is most likely for each part-of-speech tag. 
#ie  build a chunker using a unigram tagger. 

test_sents = conll2000.chunked_sents('test.txt', chunk_types=['NP'])  #list of Tree for each sentence 
train_sents = conll2000.chunked_sents('train.txt', chunk_types=['NP']) #list of Tree

unigram_chunker = UnigramChunker(train_sents)
>>> print(unigram_chunker.evaluate(test_sents))
ChunkParse score:
    IOB Accuracy:  92.9%
    Precision:     79.9%
    Recall:        86.8%
    F-Measure:     83.2%
 
 

postags = sorted(set(pos for sent in train_sents for (word,pos) in sent.leaves()))
>>> print(unigram_chunker.tagger.tag(postags))
[('#', 'B-NP'), ('$', 'B-NP'), ("''", 'O'), ('(', 'O'), (')', 'O'),
 (',', 'O'), ('.', 'O'), (':', 'O'), ('CC', 'O'), ('CD', 'I-NP'),
 ('DT', 'B-NP'), ('EX', 'B-NP'), ('FW', 'I-NP'), ('IN', 'O'),
 ('JJ', 'I-NP'), ('JJR', 'B-NP'), ('JJS', 'I-NP'), ('MD', 'O'),
 ('NN', 'I-NP'), ('NNP', 'I-NP'), ('NNPS', 'I-NP'), ('NNS', 'I-NP'),
 ('PDT', 'B-NP'), ('POS', 'B-NP'), ('PRP', 'B-NP'), ('PRP$', 'B-NP'),
 ('RB', 'O'), ('RBR', 'O'), ('RBS', 'B-NP'), ('RP', 'O'), ('SYM', 'O'),
 ('TO', 'O'), ('UH', 'O'), ('VB', 'O'), ('VBD', 'O'), ('VBG', 'O'),
 ('VBN', 'O'), ('VBP', 'O'), ('VBZ', 'O'), ('WDT', 'B-NP'),
 ('WP', 'B-NP'), ('WP$', 'B-NP'), ('WRB', 'O'), ('', 'O')]
 
 
#BigramChunker has more score 

bigram_chunker = BigramChunker(train_sents)
>>> print(bigram_chunker.evaluate(test_sents))
ChunkParse score:
    IOB Accuracy:  93.3%
    Precision:     82.3%
    Recall:        86.8%
    F-Measure:     84.5%
 
 
 
 
##Chunk - Training Classifier-Based Chunkers - using MaxentClassifier
#Both the regular-expression based chunkers and the n-gram chunkers decide 
#what chunks to create entirely based on part-of-speech tags. 
#However, sometimes part-of-speech tags are insufficient to determine how a sentence should be chunked

#classifier-based chunker will work by assigning IOB tags to the words in a sentence, 
#and then converting those tags to chunks
#Check https://www.nltk.org/book/ch07.html

'''
>>> from nltk.tag.util import untag
>>> untag([('John', 'NNP'), ('saw', 'VBD'), ('Mary', 'NNP')])
['John', 'saw', 'Mary']

'''
class ConsecutiveNPChunkTagger(nltk.TaggerI):
    def __init__(self, train_sents): #train_sent:list of Tree
        train_set = []
        for tagged_sent in train_sents:  #One Subtree of Sentence 
            untagged_sent = nltk.tag.untag(tagged_sent)
            history = []
            for i, (word, tag) in enumerate(tagged_sent):
                featureset = npchunk_features(untagged_sent, i, history) 
                train_set.append( (featureset, tag) )
                history.append(tag)
        self.classifier = nltk.MaxentClassifier.train(train_set, algorithm='megam', trace=0)
    #tag(tokens)
    def tag(self, sentence):  #Return type:list(tuple(token, tag)) , both are string 
        history = []          #here token is each sentence 
        for i, word in enumerate(sentence):
            featureset = npchunk_features(sentence, i, history)
            tag = self.classifier.classify(featureset)
            history.append(tag)
        return zip(sentence, history)

class ConsecutiveNPChunker(nltk.ChunkParserI): 
    def __init__(self, train_sents):
        tagged_sents = [[((w,t),c) for (w,t,c) in
                         nltk.chunk.tree2conlltags(sent)]  #(word, tag, IOB-tag)
                        for sent in train_sents]  #train_sent:Tree 
        self.tagger = ConsecutiveNPChunkTagger(tagged_sents)

    def parse(self, sentence): #sentence (list(tuple)) – The list of (word, tag) tokens to be chunked
        tagged_sents = self.tagger.tag(sentence)
        conlltags = [(w,t,c) for ((w,t),c) in tagged_sents]
        return nltk.chunk.conlltags2tree(conlltags)
 
 

#Version-1 : npchunk_features, Simple - only containing pos 

def npchunk_features(sentence, i, history):
    word, pos = sentence[i]
    return {"pos": pos}

    
chunker = ConsecutiveNPChunker(train_sents)
>>> print(chunker.evaluate(test_sents))  #test_sents is gold (list(Tree)) – The list of chunked sentences to score the chunker on
ChunkParse score:
    IOB Accuracy:  92.9%
    Precision:     79.9%
    Recall:        86.7%
    F-Measure:     83.2%
 
 
#Version-2 : add a feature for the previous part-of-speech tag. 
#Adding this feature allows the classifier to model interactions between adjacent tags, 
#and results in a chunker that is closely related to the bigram chunker.

def npchunk_features(sentence, i, history):
    word, pos = sentence[i]
    if i == 0:
        prevword, prevpos = "<START>", "<START>"
    else:
        prevword, prevpos = sentence[i-1]
    return {"pos": pos, "prevpos": prevpos}

chunker = ConsecutiveNPChunker(train_sents)
>>> print(chunker.evaluate(test_sents))
ChunkParse score:
    IOB Accuracy:  93.6%
    Precision:     81.9%
    Recall:        87.2%
    F-Measure:     84.5%
 
 

#Version-3 : adding a feature for the current word, 
#since we hypothesized that word content should be useful for chunking. 
def npchunk_features(sentence, i, history):
    word, pos = sentence[i]
    if i == 0:
        prevword, prevpos = "<START>", "<START>"
    else:
        prevword, prevpos = sentence[i-1]
    return {"pos": pos, "word": word, "prevpos": prevpos}

chunker = ConsecutiveNPChunker(train_sents)
>>> print(chunker.evaluate(test_sents))
ChunkParse score:
    IOB Accuracy:  94.5%
    Precision:     84.2%
    Recall:        89.4%
    F-Measure:     86.7%
 
 

#Version-5: extending the feature extractor with a variety of additional features, 
#such as lookahead features [1], paired features [2], and complex contextual features [3]. 
#This last feature, called tags-since-dt, creates a string describing the set of all part-of-speech tags 
#that have been encountered since the most recent determiner, 
#or since the beginning of the sentence if there is no determiner before index i. .



def npchunk_features(sentence, i, history):
    word, pos = sentence[i]
    if i == 0:
        prevword, prevpos = "<START>", "<START>"
    else:
        prevword, prevpos = sentence[i-1]
    if i == len(sentence)-1:
        nextword, nextpos = "<END>", "<END>"
    else:
        nextword, nextpos = sentence[i+1]
    return {"pos": pos,
            "word": word,
            "prevpos": prevpos,
            "nextpos": nextpos, [1]
            "prevpos+pos": "%s+%s" % (prevpos, pos),  [2]
            "pos+nextpos": "%s+%s" % (pos, nextpos),
            "tags-since-dt": tags_since_dt(sentence, i)}  [3]


def tags_since_dt(sentence, i):
    tags = set()
    for word, pos in sentence[:i]:
        if pos == 'DT':
            tags = set()
        else:
            tags.add(pos)
    return '+'.join(sorted(tags))
 
 
chunker = ConsecutiveNPChunker(train_sents)
>>> print(chunker.evaluate(test_sents))
ChunkParse score:
    IOB Accuracy:  96.0%
    Precision:     88.6%
    Recall:        91.0%
    F-Measure:     89.8%
 
 

 
 
 
 
##Chunk - Recursion in Linguistic Structure : Building Nested Structure with Cascaded Chunkers
#it is possible to build chunk structures of arbitrary depth, 
#by creating a multi-stage chunk grammar containing recursive rules. 

#Example - patterns for noun phrases, prepositional phrases, verb phrases, and sentences. 

#This is a four-stage chunk grammar, 
#and can be used to create structures having a depth of at most four.
grammar = r"""
  NP: {<DT|JJ|NN.*>+}          # Chunk sequences of DT, JJ, NN
  PP: {<IN><NP>}               # Chunk prepositions followed by NP
  VP: {<VB.*><NP|PP|CLAUSE>+$} # Chunk verbs and their arguments
  CLAUSE: {<NP><VP>}           # Chunk NP, VP
  """
cp = nltk.RegexpParser(grammar)
sentence = [("Mary", "NN"), ("saw", "VBD"), ("the", "DT"), ("cat", "NN"),
    ("sit", "VB"), ("on", "IN"), ("the", "DT"), ("mat", "NN")]
 
>>> print(cp.parse(sentence))
(S
  (NP Mary/NN)
  saw/VBD
  (CLAUSE  #this result misses the VP headed by saw. 
    (NP the/DT cat/NN)
    (VP sit/VB (PP on/IN (NP the/DT mat/NN)))))
 
 
#Also, apply this chunker to a sentence having deeper nesting. 
#Notice that it fails to identify the VP chunk starting at 'saw'
>>> sentence = [("John", "NNP"), ("thinks", "VBZ"), ("Mary", "NN"),
        ("saw", "VBD"), ("the", "DT"), ("cat", "NN"), ("sit", "VB"),
        ("on", "IN"), ("the", "DT"), ("mat", "NN")]
>>> print(cp.parse(sentence))
(S
  (NP John/NNP)
  thinks/VBZ
  (NP Mary/NN)
  saw/VBD # [_saw-vbd]
  (CLAUSE
    (NP the/DT cat/NN)
    (VP sit/VB (PP on/IN (NP the/DT mat/NN)))))
 
 
#SOLUTION -  get the chunker to loop over its patterns: 
#after trying all of them,  it repeats the process.

#add an optional second argument loop to specify the number of times the set of patterns should be run
>>> cp = nltk.RegexpParser(grammar, loop=2)
>>> print(cp.parse(sentence))
(S
  (NP John/NNP)
  thinks/VBZ
  (CLAUSE
    (NP Mary/NN)
    (VP
      saw/VBD
      (CLAUSE
        (NP the/DT cat/NN)
        (VP sit/VB (PP on/IN (NP the/DT mat/NN)))))))
 
 









###NLP Identifying similar documents 

##Using spacy 
$ pip install  spacy

#with admin 
$ python -m spacy download en
#c:\python35\lib\site-packages\en_core_web_sm --> c:\python35\lib\site-packages\spacy\data\en
#linking might fail , manually create mklink /D Link Target
#mklink /D c:\python35\lib\site-packages\spacy\data\en c:\python35\lib\site-packages\en_core_web_sm

#Example  
import spacy
nlp = spacy.load('en')
doc1 = nlp('Hello hi there!')
doc2 = nlp('Hello hi there!')
doc3 = nlp('Hey whatsup?')

print(doc1.similarity(doc2)) # 0.999999954642
print(doc2.similarity(doc3)) # 0.699032527716
print(doc1.similarity(doc3)) # 0.699032527716


##Using nltk, sklearn  
import nltk, string
from sklearn.feature_extraction.text import TfidfVectorizer

nltk.download('punkt') # if necessary...

##The Porter stemmers strip affixes(eg -ing) 
stemmer = nltk.stem.porter.PorterStemmer()

remove_punctuation_map = dict((ord(char), None) for char in string.punctuation)

def stem_tokens(tokens):
    return [stemmer.stem(item) for item in tokens]

'''remove punctuation, lowercase, stem'''
def normalize(text):
    #translate:Return a copy of the string S in which each character has been mapped through the given translation table.
    return stem_tokens(nltk.word_tokenize(text.lower().translate(remove_punctuation_map)))

vectorizer = TfidfVectorizer(tokenizer=normalize, stop_words='english')

def cosine_sim(text1, text2):
    tfidf = vectorizer.fit_transform([text1, text2])
    return ((tfidf * tfidf.T).A) [0,1]  #matrix.A Return self as an ndarray object
# [0,1] is the positions in the matrix for the similarity since two text inputs will create a 2x2 symmetrical matrix

print(cosine_sim('a little bird', 'a little bird'))
print(cosine_sim('a little bird', 'a little bird chirps'))
print(cosine_sim('a little bird', 'a big dog barks'))




##Using  python + numpy

import numpy as np
from math import sqrt, log
from itertools import chain, product
from collections import defaultdict

def cosine_sim(u,v):
    return np.dot(u,v) / (sqrt(np.dot(u,u)) * sqrt(np.dot(v,v)))

def ngrams(sentence, n):
  return zip(*[sentence.split()[i:] for i in range(n)])

def tfidf(corpus, vocab):
    """
    INPUT:

    corpus = [('this is a foo bar', [1, 1, 0, 1, 1, 0, 0, 1]), 
    ('foo bar bar black sheep', [0, 2, 1, 1, 0, 0, 1, 0]), 
    ('this is a sentence', [1, 0, 0, 0, 1, 1, 0, 1])]

    vocab = ['a', 'bar', 'black', 'foo', 'is', 'sentence', 
    'sheep', 'this']

    OUTPUT:

    [[0.300, 0.300, 0.0, 0.300, 0.300, 0.0, 0.0, 0.300], 
    [0.0, 0.600, 0.600, 0.300, 0.0, 0.0, 0.600, 0.0], 
    [0.375, 0.0, 0.0, 0.0, 0.375, 0.75, 0.0, 0.375]]

    """
    def termfreq(matrix, doc, term):
        try: return matrix[doc][term] / float(sum(matrix[doc].values()))
        except ZeroDivisionError: return 0
    def inversedocfreq(matrix, term):
        try: 
            return float(len(matrix)) /sum([1 for i,_ in enumerate(matrix) if matrix[i][term] > 0])
        except ZeroDivisionError: return 0

    matrix = [{k:v for k,v in zip(vocab, i[1])} for i in corpus]
    tfidf = defaultdict(dict)
    for doc,_ in enumerate(matrix):
        for term in matrix[doc]:
            tf = termfreq(matrix,doc,term)
            idf = inversedocfreq(matrix, term)
            tfidf[doc][term] = tf*idf

    return [[tfidf[doc][term] for term in vocab] for doc,_ in enumerate(tfidf)]


def corpus2vectors(corpus):
    def vectorize(sentence, vocab):
        return [sentence.split().count(i) for i in vocab]
    vectorized_corpus = []
    vocab = sorted(set(chain(*[i.lower().split() for i in corpus])))
    for i in corpus:
        vectorized_corpus.append((i, vectorize(i, vocab)))
    return vectorized_corpus, vocab

def create_test_corpus():
    sent1 = "this is a foo bar"
    sent2 = "foo bar bar black sheep"
    sent3 = "this is a sentence"

    all_sents = [sent1,sent2,sent3]
    corpus, vocab = corpus2vectors(all_sents)
    return corpus, vocab

def test_cosine():
    corpus, vocab = create_test_corpus()

    for sentx, senty in product(corpus, corpus):
        print sentx[0]
        print senty[0]
        print "cosine =", cosine_sim(sentx[1], senty[1])
        print

def test_ngrams():
    corpus, vocab = create_test_corpus()
    for sentx in corpus:
        print sentx[0]
        print ngrams(sentx[0],2)
        print ngrams(sentx[0],3)
        print

def test_tfidf():
    corpus, vocab = create_test_corpus()
    print corpus
    print vocab
    print tfidf(corpus, vocab)


##Using gensim 

from gensim import corpora

#corpus of 9 documents 
documents = ["Human machine interface for lab abc computer applications",
             "A survey of user opinion of computer system response time",
             "The EPS user interface management system",
             "System and human system engineering testing of EPS",
             "Relation of user perceived response time to error measurement",
             "The generation of random binary unordered trees",
             "The intersection graph of paths in trees",
             "Graph minors IV Widths of trees and well quasi ordering",
             "Graph minors A survey"]


#tokenize the documents
# remove common words and tokenize
stoplist = set('for a of the and to in'.split())
texts = [[word for word in document.lower().split() if word not in stoplist]
         for document in documents]

# remove words that appear only once
from collections import defaultdict
frequency = defaultdict(int)
for text in texts:
    for token in text:
        frequency[token] += 1

texts = [[token for token in text if frequency[token] > 1]
         for text in texts]

from pprint import pprint  # pretty-printer
>>> pprint(texts)
[['human', 'interface', 'computer'],
 ['survey', 'user', 'computer', 'system', 'response', 'time'],
 ['eps', 'user', 'interface', 'system'],
 ['system', 'human', 'system', 'eps'],
 ['user', 'response', 'time'],
 ['trees'],
 ['graph', 'trees'],
 ['graph', 'minors', 'trees'],
 ['graph', 'minors', 'survey']]


#To convert documents to vectors, use a document representation called bag-of-words
#Create Dictionary (containing all unique words and their Ids )

dictionary = corpora.Dictionary(texts)
dictionary.save('/tmp/deerwester.dict')  # store the dictionary, for future reference
>>> print(dictionary)
Dictionary(12 unique tokens)

#12 tokens 
>>> print(dictionary.token2id)
{'minors': 11, 'graph': 10, 'system': 5, 'trees': 9, 'eps': 8, 'computer': 0,
'survey': 4, 'user': 7, 'human': 1, 'time': 6, 'interface': 2, 'response': 3}


#To convert tokenized documents to vectors:
new_doc = "Human computer interaction"
new_vec = dictionary.doc2bow(new_doc.lower().split())
>>> print(new_vec)  # the word "interaction" does not appear in the dictionary and is ignored
[(0, 1), (1, 1)]

#Create Corpus - containing each document into 12-D space of Dictionary ids 
corpus = [dictionary.doc2bow(text) for text in texts]
corpora.MmCorpus.serialize('/tmp/deerwester.mm', corpus)  # store to disk, for later use
>>> print(corpus)
[(0, 1), (1, 1), (2, 1)]  #ids from dictionary and it's frequency 
[(0, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]
[(2, 1), (5, 1), (7, 1), (8, 1)]
[(1, 1), (5, 2), (8, 1)]
[(3, 1), (6, 1), (7, 1)]
[(9, 1)]
[(9, 1), (10, 1)]
[(9, 1), (10, 1), (11, 1)]
[(4, 1), (10, 1), (11, 1)]

#To get similarity we need to transform into model TfIdf, or LSI or LDA to decrease the dimension if required 
#based on Corpus and Dictionary 

from gensim import corpora, models, similarities
dictionary = corpora.Dictionary.load('/tmp/deerwester.dict')
corpus = corpora.MmCorpus('/tmp/deerwester.mm') 
>>> print(corpus)
MmCorpus(9 documents, 12 features, 28 non-zero entries)

#2D LSI space because num_topics are 2 
#Latent Semantic Analysis (aka Latent Semantic Indexing)
lsi = models.LsiModel(corpus, id2word=dictionary, num_topics=2)

#For new Document, get Vector at first and then transform to LSI 
doc = "Human computer interaction"
vec_bow = dictionary.doc2bow(doc.lower().split())
>>> vec_lsi = lsi[vec_bow] # convert the query to LSI space
>>> print(vec_lsi)
[(0, -0.461821), (1, 0.070028)]

#To prepare for similarity queries, enter all documents which we want to compare against subsequent queries
#gensim.similarities.docsim.MatrixSimilarity(corpus,num_features=None)
index = similarities.MatrixSimilarity(corpus, num_features=len(dictionary))

#OR using LSI space,  transform corpus to LSI space and index it
index = similarities.MatrixSimilarity(lsi[corpus]) 

#can save and  load 
index.save('/tmp/deerwester.index')
index = similarities.MatrixSimilarity.load('/tmp/deerwester.index')

#To get similarity of vec_lsi(new doc) 
#Cosine measure returns similarities in the range <-1, 1> (the greater, the more similar), so that the first document has a score of 0.99809301 etc
sims = index[vec_lsi] # perform a similarity query against the corpus
print(list(enumerate(sims))) # print (document_number, document_similarity) 2-tuples
[(0, 0.99809301), (1, 0.93748635), (2, 0.99844527), (3, 0.9865886), (4, 0.90755945),
(5, -0.12416792), (6, -0.1063926), (7, -0.098794639), (8, 0.05004178)]


##Usage of Similarity class
#The Similarity class splits the index into several smaller sub-indexes (“shards”) in disk 
#hence Similarity scals well , but not MatrixSimilarity or SparseMatrixSimilarity  which stores into RAM 

from gensim.test.utils import get_tmpfile

index_tmpfile = get_tmpfile("index")

index = similarities.Similarity(index_tmpfile, corpus, num_features=len(dictionary)) # build the index
# get similarities between the query and all index documents
similarities = index[vec_bow] 

#or using LSI space 
index = similarities.Similarity(index_tmpfile, lsi[corpus])
similarities = index[vec_lsi]

#OR submit them all queries at once, in a batch
## the batch is simply an iterable of documents, aka gensim corpus.
for similarities in index[batch_of_documents]: 
    print(similarities)

#OR to find similarity of documents in the index to the index itself
## yield similarities of the 1st indexed document, then 2nd...
for similarities in index: 
    print(similarities)


 

   
    
###Text summarization with NLTK and sumy
#The target of the automatic text summarization is to reduce a textual document to a summary 
#that retains the pivotal points of the original document. 

#The research about text summarization is very active and during the last years many summarization algorithms  have been proposed. 



##Usinh NLTK - ranking docs 

#Example - BBC news feed - tries to extract one or more sentences that cover the main topics of the original document 

#The FrequencySummarizer tokenizes the input into sentences then computes the term frequency map of the words. 
#Then, the frequency map is filtered in order to ignore very low frequency and highly frequent words, 

#And finally, the sentences are ranked according to the frequency of the words they contain 
#and the top sentences are selected for the final summary. 

from nltk.tokenize import sent_tokenize,word_tokenize
from nltk.corpus import stopwords
from collections import defaultdict
from string import punctuation
from heapq import nlargest

class FrequencySummarizer:
  def __init__(self, min_cut=0.1, max_cut=0.9):
    """
     Initilize the text summarizer.
     Words that have a frequency term lower than min_cut 
     or higer than max_cut will be ignored.
    """
    self._min_cut = min_cut
    self._max_cut = max_cut 
    self._stopwords = set(stopwords.words('english') + list(punctuation))

  def _compute_frequencies(self, word_sent):
    """ 
      Compute the frequency of each of word.
      Input: 
       word_sent, a list of sentences already tokenized.
      Output: 
       freq, a dictionary where freq[w] is the frequency of w.
    """
    freq = defaultdict(int)
    for s in word_sent:
      for word in s:
        if word not in self._stopwords:
          freq[word] += 1
    # frequencies normalization and fitering
    m = float(max(freq.values()))
    for w in freq.keys():
      freq[w] = freq[w]/m
      if freq[w] >= self._max_cut or freq[w] <= self._min_cut:
        del freq[w]
    return freq

  def summarize(self, text, n):
    """
      Return a list of n sentences 
      which represent the summary of text.
    """
    sents = sent_tokenize(text)
    assert n <= len(sents)
    word_sent = [word_tokenize(s.lower()) for s in sents]
    self._freq = self._compute_frequencies(word_sent)
    ranking = defaultdict(int)
    for i,sent in enumerate(word_sent):
      for w in sent:
        if w in self._freq:
          ranking[i] += self._freq[w]
    sents_idx = self._rank(ranking, n)    
    return [sents[j] for j in sents_idx]

  def _rank(self, ranking, n):
    """ return the first n sentences with highest ranking """
    return nlargest(n, ranking, key=ranking.get)
    
    
    
##Usage 
import urllib2
from bs4 import BeautifulSoup

def get_only_text(url):
    """ 
    return the title and the text of the article
    at the specified url
    """
    page = urllib2.urlopen(url).read().decode('utf8')
    soup = BeautifulSoup(page)
    text = ' '.join(map(lambda p: p.text, soup.find_all('p')))
    return soup.title.text, text
 
 
feed_xml = urllib2.urlopen('http://feeds.bbci.co.uk/news/rss.xml').read()
feed = BeautifulSoup(feed_xml.decode('utf8'))
to_summarize = map(lambda p: p.text, feed.find_all('guid'))

fs = FrequencySummarizer()
for article_url in to_summarize[:5]:
    title, text = get_only_text(article_url)
    print '----------------------------------'
    print title
    for s in fs.summarize(text, 2):
        print '*',s
        
        
#And here are the results:
 ----------------------------------
BBC News - Scottish independence: Campaigns seize on Scotland powers pledge
* Speaking ahead of a visit to apprentices at an engineering firm in 
Renfrew, Deputy First Minister Nicola Sturgeon said: Only a 'Yes' vote will 
ensure we have full powers over job creation - enabling us to create more 
and better jobs across the country.
* Asked if the move smacks of panic, Mr Alexander told BBC Breakfast: 
I don't think there's any embarrassment about placing policies on the 
front page of papers with just days two go.
----------------------------------
BBC News - US air strike supports Iraqi troops under attack
* Gabriel Gatehouse reports from the front line of Peshmerga-held territory 
in northern Iraq The air strike south-west of Baghdad was the first taken as 
part of our expanded efforts beyond protecting our own people and humanitarian 
missions to hit Isil targets as Iraqi forces go on offence, as outlined in the 
president's speech last Wednesday, US Central Command said.
* But Iran's Supreme Leader Ayatollah Ali Khamenei said on Monday that the US 
had requested Iran's co-operation via the US ambassador to Iraq.


##Another example using FrequencySummarizer
 
 
from bs4 import BeautifulSoup
from urllib.request import urlopen
 
 
def get_only_text(url):
    """ 
    return the title and the text of the article
    at the specified url
    """

    page = urlopen(url)
    soup = BeautifulSoup(page)
    text = ' '.join(map(lambda p: p.text, soup.find_all('p')))

    print ("=====================")
    print (text)
    print ("=====================")

    return soup.title.text, text    
 
#Usage 
url="https://en.wikipedia.org/wiki/Deep_learning"
text = get_only_text(url)    
 
fs = FrequencySummarizer()
s = fs.summarize(str(text), 5)
print(s)





##Text Summarization with Gensim
#https://radimrehurek.com/gensim/tutorial.html

$ pip install  gensim

#TextRank is a general purpose graph-based ranking algorithm for NLP. 
#Essentially, it runs PageRank on a graph specially designed for a particular NLP task. 
#For keyphrase extraction, it builds a graph using some set of text units as vertices. 
#Edges are based on some measure of semantic or lexical similarity between the text unit vertices

from gensim.summarization.summarizer import summarize
from gensim.summarization import keywords
 

from bs4 import BeautifulSoup
from urllib.request import urlopen
 
def get_only_text(url):
    """ 
    return the title and the text of the article
    at the specified url
    """
    page = urlopen(url)
    soup = BeautifulSoup(page, "lxml")
    text = ' '.join(map(lambda p: p.text, soup.find_all('p')))
    return soup.title.text, text    
 
 
url="https://en.wikipedia.org/wiki/Deep_learning"
text = get_only_text(url)

print('Summary:')
print(summarize(text, ratio=0.01))
 
print('\nKeywords:')
print(keywords(text, ratio=0.01))
 
#Output 
Summary:
In 2003, LSTM started to become competitive with traditional speech recognizers on certain tasks.[55] Later it was combined with connectionist temporal classification (CTC)[56] in stacks of LSTM RNNs.[57] In 2015, Google\’s speech recognition reportedly experienced a dramatic performance jump of 49% through CTC-trained LSTM, which they made available through Google Voice Search.[58] In the early 2000s, CNNs processed an estimated 10% to 20% of all the checks written in the US.[59] In 2006, Hinton and Salakhutdinov showed how a many-layered feedforward neural network could be effectively pre-trained one layer at a time, treating each layer in turn as an unsupervised restricted Boltzmann machine, then fine-tuning it using supervised backpropagation.[60] Deep learning is part of state-of-the-art systems in various disciplines, particularly computer vision and automatic speech recognition (ASR).

Keywords:
 deep learning
 learned
 learn
 learns
 layer
 layered
 layers
 models
 model
 modeling
 images
 image
 recognition
 data
 networks
 network
 trained
 training
 train
 trains


##Automatic Summarization Using Different Methods from Sumy
#https://github.com/miso-belica/sumy

$ pip install sumy

##Summerization method in sumy is very vast 
Luhn – heurestic method
Edmundson heurestic method with previous statistic research
Latent Semantic Analysis
LexRank – Unsupervised approach inspired by algorithms PageRank and HITS
TextRank
SumBasic – Method that is often used as a baseline in the literature
KL-Sum – Method that greedily adds sentences to a summary so long as it decreases the KL Divergence. [5]

#Bonus_words are the words that we want to see in summary they are most informative and are significant words. 
#Stigma words are unimportant words. 
#We can use tf-idf value from information retrieval to get the list of key words.


 
from __future__ import absolute_import
from __future__ import division, print_function, unicode_literals
 
from sumy.parsers.html import HtmlParser
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer

from sumy.nlp.stemmers import Stemmer
from sumy.utils import get_stop_words
 
from sumy.summarizers.luhn import LuhnSummarizer
from sumy.summarizers.edmundson import EdmundsonSummarizer   #this is the best as 
from sumy.summarizers.lsa import LsaSummarizer
 
LANGUAGE = "english"
SENTENCES_COUNT = 10
 
 
if __name__ == "__main__":
    
    url="https://en.wikipedia.org/wiki/Deep_learning"
   
    parser = HtmlParser.from_url(url, Tokenizer(LANGUAGE))
    # or for plain text files
    # parser = PlaintextParser.from_file("document.txt", Tokenizer(LANGUAGE)) 
        
    print ("--LsaSummarizer--")    
    summarizer = LsaSummarizer()
    summarizer = LsaSummarizer(Stemmer(LANGUAGE))
    summarizer.stop_words = get_stop_words(LANGUAGE)
    for sentence in summarizer(parser.document, SENTENCES_COUNT):
        print(sentence)
         
    print ("--LuhnSummarizer--")     
    summarizer = LuhnSummarizer() 
    summarizer = LsaSummarizer(Stemmer(LANGUAGE))
    summarizer.stop_words = ("I", "am", "the", "you", "are", "me", "is", "than", "that", "this",)
    for sentence in summarizer(parser.document, SENTENCES_COUNT):
        print(sentence)
         
    print ("--EdmundsonSummarizer--")     
    summarizer = EdmundsonSummarizer() 
    words = ("deep", "learning", "neural" )
    summarizer.bonus_words = words
     
    words = ("another", "and", "some", "next",)
    summarizer.stigma_words = words
    
     
    words = ("another", "and", "some", "next",)
    summarizer.null_words = words
    for sentence in summarizer(parser.document, SENTENCES_COUNT):
        print(sentence)     
 




 
 
### NLP Using gensim - A topic modeling library - Core Feature introduction 
#Core  feature, String to Vector, Tfidf, Lsi and LDA and similarity among documents 
$ pip install gensim

import logging
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)


##From Strings to Vectors
from gensim import corpora

documents = ["Human machine interface for lab abc computer applications",
             "A survey of user opinion of computer system response time",
             "The EPS user interface management system",
             "System and human system engineering testing of EPS",
             "Relation of user perceived response time to error measurement",
             "The generation of random binary unordered trees",
             "The intersection graph of paths in trees",
             "Graph minors IV Widths of trees and well quasi ordering",
             "Graph minors A survey"]


#First, let’s tokenize the documents, remove common words 

# remove common words and tokenize
stoplist = set('for a of the and to in'.split())
texts = [[word for word in document.lower().split() if word not in stoplist]
         for document in documents]

# remove words that appear only once
from collections import defaultdict
frequency = defaultdict(int)
for text in texts:
    for token in text:
        frequency[token] += 1

texts = [[token for token in text if frequency[token] > 1]
         for text in texts]

from pprint import pprint  # pretty-printer
>>> pprint(texts)
[['human', 'interface', 'computer'],
 ['survey', 'user', 'computer', 'system', 'response', 'time'],
 ['eps', 'user', 'interface', 'system'],
 ['system', 'human', 'system', 'eps'],
 ['user', 'response', 'time'],
 ['trees'],
 ['graph', 'trees'],
 ['graph', 'minors', 'trees'],
 ['graph', 'minors', 'survey']]


#It is advantageous to represent the words only by an (integer) ids. 
#The mapping between the word and ids is called a dictionary:

dictionary = corpora.Dictionary(texts)
dictionary.save('/tmp/deerwester.dict')  # store the dictionary, for future reference
>>> print(dictionary)
Dictionary(12 unique tokens)
>>> print(dictionary.token2id)
{'minors': 11, 'graph': 10, 'system': 5, 'trees': 9, 'eps': 8, 'computer': 0,
'survey': 4, 'user': 7, 'human': 1, 'time': 6, 'interface': 2, 'response': 3}


#To actually convert tokenized documents to vectors:
new_doc = "Human computer interaction"
new_vec = dictionary.doc2bow(new_doc.lower().split())
>>> print(new_vec)  # the word "interaction" does not appear in the dictionary and is ignored
[(0, 1), (1, 1)]  #word id and frequency 

#convert all 
corpus = [dictionary.doc2bow(text) for text in texts]
corpora.MmCorpus.serialize('/tmp/deerwester.mm', corpus)  # store to disk, for later use
>>> print(corpus)  #word , frequency
[(0, 1), (1, 1), (2, 1)]
[(0, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]
[(2, 1), (5, 1), (7, 1), (8, 1)]
[(1, 1), (5, 2), (8, 1)]
[(3, 1), (6, 1), (7, 1)]
[(9, 1)]
[(9, 1), (10, 1)]
[(9, 1), (10, 1), (11, 1)]
[(4, 1), (10, 1), (11, 1)]



##Corpus Streaming – One Document at a Time

class MyCorpus(object):
    def __iter__(self):
        for line in open('mycorpus.txt'):  #https://radimrehurek.com/gensim/mycorpus.txt
            # assume there's one document per line, tokens separated by whitespace
            yield dictionary.doc2bow(line.lower().split())

corpus_memory_friendly = MyCorpus()  # doesn't load the corpus into memory!
>>> print(corpus_memory_friendly)
<__main__.MyCorpus object at 0x10d5690>

for vector in corpus_memory_friendly:  # load one vector into memory at a time
    print(vector)
[(0, 1), (1, 1), (2, 1)]
[(0, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1)]
[(2, 1), (5, 1), (7, 1), (8, 1)]
[(1, 1), (5, 2), (8, 1)]
[(3, 1), (6, 1), (7, 1)]
[(9, 1)]
[(9, 1), (10, 1)]
[(9, 1), (10, 1), (11, 1)]
[(4, 1), (10, 1), (11, 1)]


##to construct the dictionary without loading all texts into memory:

from six import iteritems
# collect statistics about all tokens
dictionary = corpora.Dictionary(line.lower().split() for line in open('mycorpus.txt'))

# remove stop words and words that appear only once
stop_ids = [dictionary.token2id[stopword] for stopword in stoplist
            if stopword in dictionary.token2id]
once_ids = [tokenid for tokenid, docfreq in iteritems(dictionary.dfs) if docfreq == 1]

# remove stop words and words that appear only once
dictionary.filter_tokens(stop_ids + once_ids)  
# remove gaps in id sequence after words that were removed
dictionary.compactify()  
>>> print(dictionary)
Dictionary(12 unique tokens)





##Corpus Formats
#the Market Matrix format

# create a toy corpus of 2 documents, as a plain Python list
corpus = [[(1, 0.5)], []]  # make one document empty
corpora.MmCorpus.serialize('/tmp/corpus.mm', corpus)


#Joachim’s SVMlight format, Blei’s LDA-C format and GibbsLDA++ format.
corpora.SvmLightCorpus.serialize('/tmp/corpus.svmlight', corpus)
corpora.BleiCorpus.serialize('/tmp/corpus.lda-c', corpus)
corpora.LowCorpus.serialize('/tmp/corpus.low', corpus)

#to load a corpus iterator from a Matrix Market file:
corpus = corpora.MmCorpus('/tmp/corpus.mm')

>>> print(corpus)
MmCorpus(2 documents, 2 features, 1 non-zero entries)


# one way of printing a corpus: load it entirely into memory
>>> print(list(corpus))  # calling list() will convert any sequence to a plain Python list
[[(1, 0.5)], []]

#To save the same Matrix Market document stream in Blei’s LDA-C format,
corpora.BleiCorpus.serialize('/tmp/corpus.lda-c', corpus)



##Gensim also contains efficient utility functions to help converting from/to numpy matrices:
import gensim
import numpy as np
numpy_matrix = np.random.randint(10, size=[5,2])  # random matrix as an example
corpus = gensim.matutils.Dense2Corpus(numpy_matrix)
numpy_matrix = gensim.matutils.corpus2dense(corpus, num_terms=number_of_corpus_features)

#from/to scipy.sparse matrices:
import scipy.sparse
scipy_sparse_matrix = scipy.sparse.random(5,2)  # random sparse matrix as example
corpus = gensim.matutils.Sparse2Corpus(scipy_sparse_matrix)
scipy_csc_matrix = gensim.matutils.corpus2csc(corpus)



##Transformation(Tf-Idf, LSI or LDA and other) interface
#LSI, LDA are used for dimensionality reduction by getting most important topics 


##Available transformations

#Term Frequency * Inverse Document Frequency,
model = models.TfidfModel(corpus, normalize=True)


#Latent Semantic Indexing, LSI (or sometimes LSA) transforms documents from either bag-of-words 
#or (preferrably) TfIdf-weighted space into a latent space of a lower dimensionality.
model = models.LsiModel(tfidf_corpus, id2word=dictionary, num_topics=300) #300 latent dimensions

#LSI training is unique in that we can continue “training” at any point
model.add_documents(another_tfidf_corpus) # now LSI has been trained on tfidf_corpus + another_tfidf_corpus
lsi_vec = model[tfidf_vec] # convert some new document into the LSI space, without affecting the model
...
model.add_documents(more_documents) # tfidf_corpus + another_tfidf_corpus + more_documents
lsi_vec = model[tfidf_vec]
...


#Random Projections, RP aim to reduce vector space dimensionality. 
#This is a very efficient (both memory- and CPU-friendly) approach to approximating TfIdf distances between documents,
model = models.RpModel(tfidf_corpus, num_topics=500)


#Latent Dirichlet Allocation, LDA is  another transformation from bag-of-words counts into a topic space of lower dimensionality. 
#LDA is a probabilistic extension of LSA (also called multinomial PCA), 
#so LDA’s topics can be interpreted as probability distributions over words. 
model = models.LdaModel(corpus, id2word=dictionary, num_topics=100)


#Hierarchical Dirichlet Process, HDP is a non-parametric bayesian method 
model = models.HdpModel(corpus, id2word=dictionary)





##Details examples for LSI 
from gensim import corpora, models, similarities

dictionary = corpora.Dictionary.load('/tmp/deerwester.dict')
corpus = corpora.MmCorpus('/tmp/deerwester.mm')


tfidf = models.TfidfModel(corpus) # step 1 -- initialize a model

#for new doc 
new_doc = "Human computer interaction"
doc_bow = dictionary.doc2bow(new_doc.lower().split())
#[(0, 1), (1, 1)]
>>> print(tfidf[doc_bow]) # step 2 -- use the model to transform vectors
[(0, 0.70710678), (1, 0.70710678)]


#Or to apply a transformation to a whole corpus:
corpus_tfidf = tfidf[corpus]
for doc in corpus_tfidf:
    print(doc)
#OUTPUT
[(0, 0.57735026918962573), (1, 0.57735026918962573), (2, 0.57735026918962573)]
[(0, 0.44424552527467476), (3, 0.44424552527467476), (4, 0.44424552527467476), (5, 0.32448702061385548), (6, 0.44424552527467476), (7, 0.32448702061385548)]
[(2, 0.5710059809418182), (5, 0.41707573620227772), (7, 0.41707573620227772), (8, 0.5710059809418182)]
[(1, 0.49182558987264147), (5, 0.71848116070837686), (8, 0.49182558987264147)]
[(3, 0.62825804686700459), (6, 0.62825804686700459), (7, 0.45889394536615247)]
[(9, 1.0)]
[(9, 0.70710678118654746), (10, 0.70710678118654746)]
[(9, 0.50804290089167492), (10, 0.50804290089167492), (11, 0.69554641952003704)]
[(4, 0.62825804686700459), (10, 0.45889394536615247), (11, 0.62825804686700459)]



#Transformations can also be serialized, one on top of another, in a sort of chain
#we transformed our Tf-Idf corpus via Latent Semantic Indexing into a latent 2-D space 
#(2-D because we set num_topics=2). 

lsi = models.LsiModel(corpus_tfidf, id2word=dictionary, num_topics=2) 

# create a double wrapper over the original corpus: bow->tfidf->fold-in-lsi
corpus_lsi = lsi[corpus_tfidf] 

#what do these two latent dimensions stand for? 
>>> lsi.print_topics(2)  #topics are printed to log
topic #0(1.594): -0.703*"trees" + -0.538*"graph" + -0.402*"minors" + -0.187*"survey" + -0.061*"system" + -0.060*"response" + -0.060*"time" + -0.058*"user" + -0.049*"computer" + -0.035*"interface"
topic #1(1.476): -0.460*"system" + -0.373*"user" + -0.332*"eps" + -0.328*"interface" + -0.320*"response" + -0.320*"time" + -0.293*"computer" + -0.280*"human" + -0.171*"survey" + 0.161*"trees"


#according to LSI, “trees”, “graph” and “minors” are all related words 
#(and contribute the most to the direction of the first topic), 
#while the second topic practically concerns itself with all the other words. 

#As expected, the first five documents are more strongly related to the second topic 
#while the remaining four documents to the first topic:
for doc in corpus_lsi: # both bow->tfidf and tfidf->lsi transformations are actually executed here, on the fly
    print(doc)
#OUTPUT - topicId and relation score 
[(0, -0.066), (1, 0.520)] # "Human machine interface for lab abc computer applications"
[(0, -0.197), (1, 0.761)] # "A survey of user opinion of computer system response time"
[(0, -0.090), (1, 0.724)] # "The EPS user interface management system"
[(0, -0.076), (1, 0.632)] # "System and human system engineering testing of EPS"
[(0, -0.102), (1, 0.574)] # "Relation of user perceived response time to error measurement"
[(0, -0.703), (1, -0.161)] # "The generation of random binary unordered trees"
[(0, -0.877), (1, -0.168)] # "The intersection graph of paths in trees"
[(0, -0.910), (1, -0.141)] # "Graph minors IV Widths of trees and well quasi ordering"
[(0, -0.617), (1, 0.054)] # "Graph minors A survey"


#Model persistency 
lsi.save('/tmp/model.lsi') # same for tfidf, lda, ...
lsi = models.LsiModel.load('/tmp/model.lsi')





##Similarity Queries 
#to determine similarity between pairs of documents,
#Use either corpus/dictionary or LSI/LDA etc tranformed corpus 

from gensim import corpora, models, similarities
dictionary = corpora.Dictionary.load('/tmp/deerwester.dict')
corpus = corpora.MmCorpus('/tmp/deerwester.mm') # comes from the first tutorial, "From strings to vectors"
>>> print(corpus)
MmCorpus(9 documents, 12 features, 28 non-zero entries)

lsi = models.LsiModel(corpus, id2word=dictionary, num_topics=2)

doc = "Human computer interaction"
vec_bow = dictionary.doc2bow(doc.lower().split())
vec_lsi = lsi[vec_bow] # convert the query to LSI space
>>> print(vec_lsi)
[(0, -0.461821), (1, 0.070028)]


#Use similarities.Similarity for large corpus as it uses disk(check earlier example)
#Use similarities.MatrixSimilarity and similarities.SparseMatrixSimilarity when data fits into RAM  
index = similarities.MatrixSimilarity(lsi[corpus]) # transform corpus to LSI space and index it

#persist 
index.save('/tmp/deerwester.index')
index = similarities.MatrixSimilarity.load('/tmp/deerwester.index')

#Performing queries
#Cosine measure returns similarities in the range <-1, 1> (the greater, the more similar)

sims = index[vec_lsi] # perform a similarity query against the corpus
>>> print(list(enumerate(sims))) # print (document_number, document_similarity) 2-tuples
[(0, 0.99809301), (1, 0.93748635), (2, 0.99844527), (3, 0.9865886), (4, 0.90755945),
(5, -0.12416792), (6, -0.1063926), (7, -0.098794639), (8, 0.05004178)]

#sort in descending order 
sims = sorted(enumerate(sims), key=lambda item: -item[1])
>>> print(sims) # print sorted (document number, similarity score) 2-tuples
[(2, 0.99844527), # The EPS user interface management system
(0, 0.99809301), # Human machine interface for lab abc computer applications
(3, 0.9865886), # System and human system engineering testing of EPS
(1, 0.93748635), # A survey of user opinion of computer system response time
(4, 0.90755945), # Relation of user perceived response time to error measurement
(8, 0.050041795), # Graph minors A survey
(7, -0.098794639), # Graph minors IV Widths of trees and well quasi ordering
(6, -0.1063926), # The intersection graph of paths in trees
(5, -0.12416792)] # The generation of random binary unordered trees









##Example - Experiments on the English Wikipedia 


##Wikipedia: Latent Semantic Analysis
#makes two passes over the 8.2GB compressed wiki dump
$ python -m gensim.scripts.make_wiki

import logging, gensim
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)


# load id->word mapping (the dictionary), one of the results of step 2 above
id2word = gensim.corpora.Dictionary.load_from_text('wiki_en_wordids.txt')
# load corpus iterator
mm = gensim.corpora.MmCorpus('wiki_en_tfidf.mm')
# mm = gensim.corpora.MmCorpus('wiki_en_tfidf.mm.bz2') # use this if you compressed the TFIDF output (recommended)

>>> print(mm)
MmCorpus(3931787 documents, 100000 features, 756379027 non-zero entries)


#compute LSA of the English Wikipedia:
# extract 400 LSI topics; use the default one-pass algorithm
#takes about 4 hours and 9 minutes
lsi = gensim.models.lsimodel.LsiModel(corpus=mm, id2word=id2word, num_topics=400)

# print the most contributing words (both positively and negatively) for each of the first ten topics
>>> lsi.print_topics(10)
topic #0(332.762): 0.425*"utc" + 0.299*"talk" + 0.293*"page" + 0.226*"article" + 0.224*"delete" + 0.216*"discussion" + 0.205*"deletion" + 0.198*"should" + 0.146*"debate" + 0.132*"be"
topic #1(201.852): 0.282*"link" + 0.209*"he" + 0.145*"com" + 0.139*"his" + -0.137*"page" + -0.118*"delete" + 0.114*"blacklist" + -0.108*"deletion" + -0.105*"discussion" + 0.100*"diff"
topic #2(191.991): -0.565*"link" + -0.241*"com" + -0.238*"blacklist" + -0.202*"diff" + -0.193*"additions" + -0.182*"users" + -0.158*"coibot" + -0.136*"user" + 0.133*"he" + -0.130*"resolves"
topic #3(141.284): -0.476*"image" + -0.255*"copyright" + -0.245*"fair" + -0.225*"use" + -0.173*"album" + -0.163*"cover" + -0.155*"resolution" + -0.141*"licensing" + 0.137*"he" + -0.121*"copies"
topic #4(130.909): 0.264*"population" + 0.246*"age" + 0.243*"median" + 0.213*"income" + 0.195*"census" + -0.189*"he" + 0.184*"households" + 0.175*"were" + 0.167*"females" + 0.166*"males"
topic #5(120.397): 0.304*"diff" + 0.278*"utc" + 0.213*"you" + -0.171*"additions" + 0.165*"talk" + -0.159*"image" + 0.159*"undo" + 0.155*"www" + -0.152*"page" + 0.148*"contribs"
topic #6(115.414): -0.362*"diff" + -0.203*"www" + 0.197*"you" + -0.180*"undo" + -0.180*"kategori" + 0.164*"users" + 0.157*"additions" + -0.150*"contribs" + -0.139*"he" + -0.136*"image"
topic #7(111.440): 0.429*"kategori" + 0.276*"categoria" + 0.251*"category" + 0.207*"kategorija" + 0.198*"kategorie" + -0.188*"diff" + 0.163*"категория" + 0.153*"categoría" + 0.139*"kategoria" + 0.133*"categorie"
topic #8(109.907): 0.385*"album" + 0.224*"song" + 0.209*"chart" + 0.204*"band" + 0.169*"released" + 0.151*"music" + 0.142*"diff" + 0.141*"vocals" + 0.138*"she" + 0.132*"guitar"
topic #9(102.599): -0.237*"league" + -0.214*"he" + -0.180*"season" + -0.174*"football" + -0.166*"team" + 0.159*"station" + -0.137*"played" + -0.131*"cup" + 0.131*"she" + -0.128*"utc"

#unseen vec
doc_lda = lsi[doc_bow]


##Wikipedia:Latent Dirichlet Allocation

# load id->word mapping (the dictionary), one of the results of step 2 above
id2word = gensim.corpora.Dictionary.load_from_text('wiki_en_wordids.txt')
# load corpus iterator
mm = gensim.corpora.MmCorpus('wiki_en_tfidf.mm')
# mm = gensim.corpora.MmCorpus('wiki_en_tfidf.mm.bz2') # use this if you compressed the TFIDF output

>>> print(mm)
MmCorpus(3931787 documents, 100000 features, 756379027 non-zero entries)


# extract 100 LDA topics, using 1 pass and updating once every 1 chunk (10,000 documents)
lda = gensim.models.ldamodel.LdaModel(corpus=mm, id2word=id2word, num_topics=100, update_every=1, chunksize=10000, passes=1)


#Unlike LSA, the topics coming from LDA are easier to interpret
#takes about 6 hours and 20 minutes 
# print the most contributing words for 20 randomly selected topics
>>> lda.print_topics(20)
topic #0: 0.009*river + 0.008*lake + 0.006*island + 0.005*mountain + 0.004*area + 0.004*park + 0.004*antarctic + 0.004*south + 0.004*mountains + 0.004*dam
topic #1: 0.026*relay + 0.026*athletics + 0.025*metres + 0.023*freestyle + 0.022*hurdles + 0.020*ret + 0.017*divisão + 0.017*athletes + 0.016*bundesliga + 0.014*medals
topic #2: 0.002*were + 0.002*he + 0.002*court + 0.002*his + 0.002*had + 0.002*law + 0.002*government + 0.002*police + 0.002*patrolling + 0.002*their
topic #3: 0.040*courcelles + 0.035*centimeters + 0.023*mattythewhite + 0.021*wine + 0.019*stamps + 0.018*oko + 0.017*perennial + 0.014*stubs + 0.012*ovate + 0.011*greyish
topic #4: 0.039*al + 0.029*sysop + 0.019*iran + 0.015*pakistan + 0.014*ali + 0.013*arab + 0.010*islamic + 0.010*arabic + 0.010*saudi + 0.010*muhammad
topic #5: 0.020*copyrighted + 0.020*northamerica + 0.014*uncopyrighted + 0.007*rihanna + 0.005*cloudz + 0.005*knowles + 0.004*gaga + 0.004*zombie + 0.004*wigan + 0.003*maccabi
topic #6: 0.061*israel + 0.056*israeli + 0.030*sockpuppet + 0.025*jerusalem + 0.025*tel + 0.023*aviv + 0.022*palestinian + 0.019*ifk + 0.016*palestine + 0.014*hebrew
topic #7: 0.015*melbourne + 0.014*rovers + 0.013*vfl + 0.012*australian + 0.012*wanderers + 0.011*afl + 0.008*dinamo + 0.008*queensland + 0.008*tracklist + 0.008*brisbane
topic #8: 0.011*film + 0.007*her + 0.007*she + 0.004*he + 0.004*series + 0.004*his + 0.004*episode + 0.003*films + 0.003*television + 0.003*best
topic #9: 0.019*wrestling + 0.013*château + 0.013*ligue + 0.012*discus + 0.012*estonian + 0.009*uci + 0.008*hockeyarchives + 0.008*wwe + 0.008*estonia + 0.007*reign
topic #10: 0.078*edits + 0.059*notability + 0.035*archived + 0.025*clearer + 0.022*speedy + 0.021*deleted + 0.016*hook + 0.015*checkuser + 0.014*ron + 0.011*nominator
topic #11: 0.013*admins + 0.009*acid + 0.009*molniya + 0.009*chemical + 0.007*ch + 0.007*chemistry + 0.007*compound + 0.007*anemone + 0.006*mg + 0.006*reaction
topic #12: 0.018*india + 0.013*indian + 0.010*tamil + 0.009*singh + 0.008*film + 0.008*temple + 0.006*kumar + 0.006*hindi + 0.006*delhi + 0.005*bengal
topic #13: 0.047*bwebs + 0.024*malta + 0.020*hobart + 0.019*basa + 0.019*columella + 0.019*huon + 0.018*tasmania + 0.016*popups + 0.014*tasmanian + 0.014*modèle
topic #14: 0.014*jewish + 0.011*rabbi + 0.008*bgwhite + 0.008*lebanese + 0.007*lebanon + 0.006*homs + 0.005*beirut + 0.004*jews + 0.004*hebrew + 0.004*caligari
topic #15: 0.025*german + 0.020*der + 0.017*von + 0.015*und + 0.014*berlin + 0.012*germany + 0.012*die + 0.010*des + 0.008*kategorie + 0.007*cross
topic #16: 0.003*can + 0.003*system + 0.003*power + 0.003*are + 0.003*energy + 0.002*data + 0.002*be + 0.002*used + 0.002*or + 0.002*using
topic #17: 0.049*indonesia + 0.042*indonesian + 0.031*malaysia + 0.024*singapore + 0.022*greek + 0.021*jakarta + 0.016*greece + 0.015*dord + 0.014*athens + 0.011*malaysian
topic #18: 0.031*stakes + 0.029*webs + 0.018*futsal + 0.014*whitish + 0.013*hyun + 0.012*thoroughbred + 0.012*dnf + 0.012*jockey + 0.011*medalists + 0.011*racehorse
topic #19: 0.119*oblast + 0.034*uploaded + 0.034*uploads + 0.033*nordland + 0.025*selsoviet + 0.023*raion + 0.022*krai + 0.018*okrug + 0.015*hålogaland + 0.015*russiae + 0.020*manga + 0.017*dragon + 0.012*theme + 0.011*dvd + 0.011*super + 0.011*hunter + 0.009*ash + 0.009*dream + 0.009*angel

#unseen vec
doc_lda = lda[doc_bow]


#the LSA implementation in gensim is truly online: 
#if the nature of the input stream changes in time, LSA will re-orient itself to reflect these changes, 

#In contrast, LDA is not truly online as the impact of later updates on the model gradually diminishes. 

#To run batch LDA (not online), train LdaModel with:
# extract 100 LDA topics, using 20 full passes, no online updates
lda = gensim.models.ldamodel.LdaModel(corpus=mm, id2word=id2word, num_topics=100, update_every=0, passes=20)





##Distributed Latent Dirichlet Allocation and Distributed Latent Semantic Analysis 
Node
    A logical working unit. Can correspond to a single physical machine, but you can also run multiple workers on one machine, resulting in multiple logical nodes.
Cluster
    Several nodes which communicate over TCP/IP. Currently, network broadcasting is used to discover and connect all communicating nodes, so the nodes must lie within the same broadcast domain.
Worker
    A process which is created on each node. To remove a node from your cluster, simply kill its worker process.
Dispatcher
    The dispatcher will be in charge of negotiating all computations, queueing and distributing (“dispatching”) individual jobs to the workers. Computations never “talk” to worker nodes directly, only through this dispatcher. Unlike workers, there can only be one active dispatcher at a time in the cluster.
#Check https://radimrehurek.com/gensim/distributed.html





###NLP using - Spacy Contains many feature of text extractions  
#contains state of world NLP algorithms 

$ pip install spacy 

##spacy-Available models - https://spacy.io/usage/models#available
#Loading models - in admin 
$ python -m spacy download en_core_web_sm
#c:\python35\lib\site-packages\en_core_web_sm --> c:\python35\lib\site-packages\spacy\data\en
#linking might fail , manually create mklink /D Link Target
#mklink /D c:\python35\lib\site-packages\spacy\data\en c:\python35\lib\site-packages\en_core_web_sm


##Pipelines in spacy 
Text -> tokenizer -> tagger -> parser -> ner... -> doc 


#Name       Component           Creates                 Description
tokenizer   Tokenizer           Doc                     Segment text into tokens. 
tagger      Tagger              Doc[i].tag              Assign part-of-speech tags. 
parser      DependencyParser    Doc[i].head, 
                                Doc[i].dep, 
                                Doc.sents, 
                                Doc.noun_chunks         Assign dependency labels. 
ner         EntityRecognizer    Doc.ents, 
                                Doc[i].ent_iob, 
                                Doc[i].ent_type         Detect and label named entities. 
textcat     TextCategorizer     Doc.cats                Assign document labels. 
... 


#The processing pipeline always depends on the statistical model and its capabilities.
"pipeline": ["tagger", "parser", "ner"]

#Example 
nlp = spacy.load('en')

nlp.pipeline
# [('tagger', <spacy.pipeline.Tagger>), ('parser', <spacy.pipeline.DependencyParser>), ('ner', <spacy.pipeline.EntityRecognizer>)]
nlp.pipe_names
# ['tagger', 'parser', 'ner']

#Disabling any components 
nlp = spacy.load('en', disable=['parser', 'tagger'])
nlp = English().from_disk('/model', disable=['ner'])

#OR 
nlp.remove_pipe('parser')
nlp.rename_pipe('ner', 'entityrecognizer')
nlp.replace_pipe('tagger', my_custom_tagger)

#Custom pipeline 
import spacy

def my_component(doc):
    print("After tokenization, this doc has %s tokens." % len(doc))
    if len(doc) < 10:
        print("This is a pretty short document.")
    return doc

nlp = spacy.load('en_core_web_sm')
nlp.add_pipe(my_component, name='print_info', first=True)
print(nlp.pipe_names) # ['print_info', 'tagger', 'parser', 'ner']
doc = nlp(u"This is a sentence.")




##Tokenization
import spacy
nlp = spacy.load('en_core_web_sm')
doc = nlp(u'Apple is looking at buying U.K. startup for $1 billion')
for token in doc:
    print(token.text, token.pos_, token.dep_)


    
##Part-of-speech tags and dependencies
#After tokenization, spaCy can parse and tag a given Doc
# This is where the statistical model comes in, which enables spaCy to make a prediction of which tag or label most likely applies in this context. 

import spacy 
nlp = spacy.load('en_core_web_sm')
doc = nlp('Apple is looking at buying U.K. startup for $1 billion')

for token in doc:
    print(token.text, token.lemma_, token.pos_, token.tag_, token.dep_,
          token.shape_, token.is_alpha, token.is_stop)


#Meaning 
Text: The original word text.
Lemma: The base form of the word.
POS: The simple part-of-speech tag.
Tag: The detailed part-of-speech tag.
Dep: Syntactic dependency, i.e. the relation between tokens.
Shape: The word shape – capitalisation, punctuation, digits.
is alpha: Is the token an alpha character?
is stop: Is the token part of a stop list, i.e. the most common words of the language?


#Output 
Apple apple PROPN NNP nsubj Xxxxx True False 
is be VERB VBZ aux xx True True 
looking look VERB VBG ROOT xxxx True False 
at at ADP IN prep xx True True 
buying buy VERB VBG pcomp xxxx True False 
U.K. u.k. PROPN NNP compound X.X. False False 
startup startup NOUN NN dobj xxxx True False 
for for ADP IN prep xxx True True 
$ $ SYM $ quantmod $ False False 
1 1 NUM CD compound d False False 
billion billion NUM CD pobj xxxx True False 


##spaCy dependency parser (uses ClearNLP)
#each child token has only one head token although a head token(token.head) can have multiple children(token.children)
#A subtree of a token can also be extracted using the token.subtree property. 
#ancestors for a token can be obtained with token.ancestors. 
#To obtain the rightmost and leftmost token of a token’s syntactic descendants - token.right_edge and token.left_edge

#use the NLTK’s tree representation. 


def tok_format(tok):
    return "_".join([tok.orth_, tok.tag_, tok.dep_])


def to_nltk_tree(node):
    if node.n_lefts + node.n_rights > 0:
        return Tree(tok_format(node), [to_nltk_tree(child) for child in node.children])
    else:
        return tok_format(node)


command = "Submit debug logs to project lead today at 9:00 AM"
en_doc = en_nlp(u'' + command) 

[to_nltk_tree(sent.root).pretty_print() for sent in en_doc.sents]


#Example - extracting the head word from a question to understand how dependency works. 
#A headword in a question can be extracted using various dependency relationships. 
#eg by extracting the Nominal Subject nsubj from the question as the headword. 

head_word = "null"
question = "What films featured the character Popeye Doyle ?" #headword = films
en_doc = en_nlp(u'' + question)
for sent in en_doc.sents:
    for token in sent:
        if token.dep == nsubj and (token.pos == NOUN or token.pos == PROPN):
            head_word = token.text
        elif token.dep == attr and (token.pos == NOUN or token.pos == PROPN):
            head_word = token.text
    print(question+" ("+head_word+")")














##Named Entities
#A named entity is a "real-world object" that's assigned a name – 
#for example, a person, a country, a product or a book title. 
#spaCy can recognise various types of named entities in a document, by asking the model for a prediction. 

import spacy 
nlp = spacy.load('en_core_web_sm')
doc = nlp(u'Apple is looking at buying U.K. startup for $1 billion')

for ent in doc.ents:
    print(ent.text, ent.start_char, ent.end_char, ent.label_)

#Meaning 
Text: The original entity text.
Start: Index of start of entity in the Doc.
End: Index of end of entity in the Doc.
Label: Entity label, i.e. type.

#Output 
Apple 0 5 ORG Companies, agencies, institutions. 
U.K. 27 31 GPE Geopolitical entity, i.e. countries, cities, states. 
$1 billion 44 54 MONEY Monetary values, including unit. 

##Accessing entity annotations
#The standard way to access entity annotations is the doc.ents  property, 
#which produces a sequence of Span  objects. 
#The entity type is accessible either as a hash value or as a string, 
#using the attributes ent.label and ent.label_. 
#The Span object acts as a sequence of tokens, so you can iterate over the entity or index into it. 
#You can also get the text form of the whole entity, as though it were a single token.

#You can also access token entity annotations using the token.ent_iob  and token.ent_type  attributes. 
#token.ent_iob indicates whether an entity starts, continues or ends on the tag. 
#If no entity type is set on a token, it will return an empty string.
IOB Scheme
    I – Token is inside an entity.
    O – Token is outside an entity.
    B – Token is the beginning of an entity.

#Example 
nlp = spacy.load('en_core_web_sm')
doc = nlp(u'San Francisco considers banning sidewalk delivery robots')

# document level
ents = [(e.text, e.start_char, e.end_char, e.label_) for e in doc.ents]
print(ents)

# token level
ent_san = [doc[0].text, doc[0].ent_iob_, doc[0].ent_type_]
ent_francisco = [doc[1].text, doc[1].ent_iob_, doc[1].ent_type_]
print(ent_san)  # [u'San', u'B', u'GPE']
print(ent_francisco)  # [u'Francisco', u'I', u'GPE']



##Setting entity annotations
#To ensure that the sequence of token annotations remains consistent, 
#you have to set entity annotations at the document level. 
#However, you can't write directly to the token.ent_iob or token.ent_type attributes, 
#so the easiest way to set entities is to assign to the doc.ents  attribute 
#and create the new entity as a Span .

#Keep in mind that you need to create a Span with the start and end index of the token, 
#not the start and end index of the entity in the document. 
#In this case, "FB" is token (0, 1) – but at the document level, 
#the entity will have the start and end indices (0, 2).

from spacy.tokens import Span

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"FB is hiring a new Vice President of global policy")
ents = [(e.text, e.start_char, e.end_char, e.label_) for e in doc.ents]
print('Before', ents)
# the model didn't recognise "FB" as an entity :(

ORG = doc.vocab.strings[u'ORG']  # get hash value of entity label
fb_ent = Span(doc, 0, 1, label=ORG) # create a Span for the new entity
doc.ents = list(doc.ents) + [fb_ent]

ents = [(e.text, e.start_char, e.end_char, e.label_) for e in doc.ents]
print('After', ents)
# [(u'FB', 0, 2, 'ORG')] 🎉





#Setting entity annotations from array - using from_array
import spacy
from spacy.attrs import ENT_IOB, ENT_TYPE

nlp = spacy.load('en_core_web_sm')
doc = nlp.make_doc(u'London is a big city in the United Kingdom.')
print('Before', list(doc.ents))  # []

header = [ENT_IOB, ENT_TYPE]
attr_array = numpy.zeros((len(doc), len(header)))
attr_array[0, 0] = 3  # B
attr_array[0, 1] = doc.vocab.strings[u'GPE']
doc.from_array(header, attr_array)
print('After', list(doc.ents))  # [London]


##Built-in entity types
#use spacy.explain() to get the description for the string representation of an entity label. 
#For example, spacy.explain("LANGUAGE") will return "any named language".

PERSON      People, including fictional. 
NORP        Nationalities or religious or political groups. 
FAC         Buildings, airports, highways, bridges, etc. 
ORG         Companies, agencies, institutions, etc. 
GPE         Countries, cities, states. 
LOC         Non-GPE locations, mountain ranges, bodies of water. 
PRODUCT     Objects, vehicles, foods, etc. (Not services.) 
EVENT       Named hurricanes, battles, wars, sports events, etc. 
WORK_OF_ART Titles of books, songs, etc. 
LAW         Named documents made into laws. 
LANGUAGE    Any named language. 
DATE        Absolute or relative dates or periods. 
TIME        Times smaller than a day. 
PERCENT     Percentage, including "%". 
MONEY       Monetary values, including unit. 
QUANTITY    Measurements, as of weight or distance. 
ORDINAL     "first", "second", etc. 
CARDINAL    Numerals that do not fall under another type. 

##Wikipedia scheme
#Models trained on Wikipedia corpus (Nothman et al., 2013) use a less fine-grained NER annotation scheme 
PER     Named person or family. 
LOC     Name of politically or geographically defined location (cities, provinces, countries, international regions, bodies of water, mountains). 
ORG     Named corporate, governmental, or other organizational entity. 
MISC    Miscellaneous entities, e.g. events, nationalities, products or works of art. 

##Training and updating the named entity recognizer - GoldParse  class
train_data = [('Who is Chaka Khan?', [(7, 17, 'PERSON')]),
              ('I like London and Berlin.', [(7, 13, 'LOC'), (18, 24, 'LOC')])]

doc = Doc(nlp.vocab, [u'rats', u'make', u'good', u'pets'])
gold = GoldParse(doc, entities=[u'U-ANIMAL', u'O', u'O', u'O'])














##Word vectors and similarity
#spaCy is able to compare two objects, and make a prediction of how similar they are. 

import spacy 
nlp = spacy.load('en_core_web_md')  # make sure to use larger model!
tokens = nlp(u'dog cat banana')

for token1 in tokens:
    for token2 in tokens:
        print(token1.text, token2.text, token1.similarity(token2))



#Meaning 
similarity: identical
similarity: similar (higher is more similar) 
similarity: dissimilar (lower is less similar)

        dog    cat     banana
dog     1.00    0.80    0.24  
cat     0.80    1.00    0.28  
banana  0.24    0.28    1.00  


#Similarity is determined by comparing word vectors or "word embeddings", 
#multi-dimensional meaning representations of a word. 
#Word vectors can be generated using an algorithm like word2vec and usually look like this:
banana.vector
array([2.02280000e-01,  -7.66180009e-02,   3.70319992e-01,
       3.28450017e-02,  -4.19569999e-01,   7.20689967e-02,
      -3.74760002e-01,   5.74599989e-02,  -1.24009997e-02,
       5.29489994e-01,  -5.23800015e-01,  -1.97710007e-01,
      -3.41470003e-01,   5.33169985e-01,  -2.53309999e-02,
       1.73800007e-01,   1.67720005e-01,   8.39839995e-01,
       5.51070012e-02,   1.05470002e-01,   3.78719985e-01,
       .......
      -2.97650009e-01,   7.89430022e-01,   3.31680000e-01,
      -1.19659996e+00,  -4.71559986e-02,   5.31750023e-01], dtype=float32)



#spaCy's small models (all packages that end in sm) don't ship with alredy generated word vectors,
#Note for similarity queryies sm model is not required , but import performance 
#download large or medium 
$ python -m spacy download en_core_web_lg

nlp = spacy.load('en_core_web_md')
tokens = nlp(u'dog cat banana afskfsd')

for token in tokens:
    print(token.text, token.has_vector, token.vector_norm, token.is_oov)


#Meaning 
Text: The original token text.
has vector: Does the token have a vector representation?
Vector norm: The L2 norm of the token's vector (the square root of the sum of the values squared)
OOV: Out-of-vocabulary





##Vocab, hashes and lexemes
#Whenever possible, spaCy tries to store data in a vocabulary, the Vocab , 
#that will be shared by multiple documents. 
#To save memory, spaCy also encodes all strings to hash values – 


#Meaning 
Token: A word, punctuation mark etc. in context, including its attributes, tags and dependencies.
Lexeme: A "word type" with no context. Includes the word shape and flags, e.g. if it's lowercase, a digit or punctuation.Each entry in the vocabulary, also called Lexeme
Doc: A processed container of tokens in context.
Vocab: The collection of lexemes.
StringStore: The dictionary mapping hash values to strings, for example 3197928453018144401 → "coffee".

#Empty Vocab 
empty_doc = Doc(Vocab())  # new Doc with empty Vocab
empty_doc.vocab.strings.add(u'coffee')  # add "coffee" and generate hash
print(empty_doc.vocab.strings[3197928453018144401])  # 'coffee' 👍

new_doc = Doc(doc.vocab)  # create new doc with first doc's vocab
print(new_doc.vocab.strings[3197928453018144401])  # 'coffee' 👍



#OR from a doc, Look up a string to get its hash, or a hash to get its string:
nlp = spacy.load('en_core_web_sm')
doc = nlp(u'I love coffee')
print(doc.vocab.strings[u'coffee'])  # 3197928453018144401
print(doc.vocab.strings[3197928453018144401])  # 'coffee'

#Each entry in the vocabulary, also called Lexeme
nlp = spacy.load('en_core_web_sm')
doc = nlp(u'I love coffee')
for word in doc:
    lexeme = doc.vocab[word.text]
    print(lexeme.text, lexeme.orth, lexeme.shape_, lexeme.prefix_, lexeme.suffix_,
          lexeme.is_alpha, lexeme.is_digit, lexeme.is_title, lexeme.lang_)


#Meaning 
Text: The original text of the lexeme.
Orth: The hash value of the lexeme.
Shape: The abstract word shape of the lexeme.
Prefix: By default, the first letter of the word string.
Suffix: By default, the last three letters of the word string.
is alpha: Does the lexeme consist of alphabetic characters?
is digit: Does the lexeme consist of digits?

#Output 
I 4690420944186131903 X I I True False 
love 3702023516439754181 xxxx l ove True False 
coffee 3197928453018144401 xxxx c fee True False 


##Serialization
#All container classes, i.e. Language , Doc , Vocab  and StringStore  have the following methods available:
#Method     Returns     Example
to_bytes    bytes       nlp.to_bytes() 
from_bytes  object      nlp.from_bytes(bytes) 
to_disk     -           nlp.to_disk('/path') 
from_disk   object      nlp.from_disk('/path') 

#Example 
text = open('customer_feedback_627.txt', 'r').read() # open a document
doc = nlp(text) # process it
doc.to_disk('/customer_feedback_627.bin') # save the processed Doc


#Later 
from spacy.tokens import Doc # to create empty Doc
from spacy.vocab import Vocab # to create empty Vocab

doc = Doc(Vocab()).from_disk('/customer_feedback_627.bin') # load processed Doc



##Language data
$ python -m spacy download en_core_web_sm
$ python -m spacy download de_core_news_sm

#Every language is different 
#The shared language data in the directory root includes rules that can be generalised across languages 
from spacy.lang.en import English
from spacy.lang.de import German

nlp_en = English() # includes English data
nlp_de = German() # includes German data


#General files 
Stop words
    stop_words.py  
    List of most common words of a language that are often useful to filter out, for example "and" or "I". Matching tokens will return True for is_stop. 
Tokenizer exceptions
    tokenizer_exceptions.py  
    Special-case rules for the tokenizer, for example, contractions like "can't" and abbreviations with punctuation, like "U.K.". 
Norm exceptions 
    norm_exceptions.py  
    Special-case rules for normalising tokens to improve the model's predictions, for example on American vs. British spelling. 
Punctuation rules 
    punctuation.py  
    Regular expressions for splitting tokens, e.g. on punctuation or special characters like emoji. Includes rules for prefixes, suffixes and infixes. 
Character classes 
    char_classes.py  
    Character classes to be used in regular expressions, for example, latin characters, quotes, hyphens or icons. 
Lexical attributes 
    lex_attrs.py  
    Custom functions for setting lexical attributes on tokens, e.g. like_num, which includes language-specific words like "ten" or "hundred". 
Syntax iterators 
    syntax_iterators.py  
    Functions that compute views of a Doc object based on its syntax. At the moment, only used for noun chunks. 
Lemmatizer 
    lemmatizer.py  
    Lemmatization rules or a lookup-based lemmatization table to assign base forms, for example "be" for "was". 
Tag map
    tag_map.py  
    Dictionary mapping strings in your tag set to Universal Dependencies tags. 
Morph rules 
    morph_rules.py  
    Exception rules for morphological analysis of irregular words like personal pronouns. 

    
    
##Get tokens, noun chunks & sentences
import spacy 
nlp = spacy.load('en_core_web_sm')
doc = nlp(u"Peach emoji is where it has always been. Peach is the superior "
          u"emoji. It's outranking eggplant 🍑 ")
print(doc[0].text)          # Peach
print(doc[1].text)          # emoji
print(doc[-1].text)         # 🍑
print(doc[17:19].text)      # outranking eggplant

noun_chunks = list(doc.noun_chunks)
print(noun_chunks[0].text)  # Peach emoji

sentences = list(doc.sents)
assert len(sentences) == 3
print(sentences[1].text)    # 'Peach is the superior emoji.'


#Noun chunks are "base noun phrases" – flat phrases that have a noun as their head. 
#eg,  a noun plus the words describing the noun – 
#for example, "the lavish green grass" or "the world’s largest tech fund"
import spacy

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"Autonomous cars shift insurance liability toward manufacturers")
for chunk in doc.noun_chunks:
    print(chunk.text, chunk.root.text, chunk.root.dep_,
          chunk.root.head.text)
#Meaning 
Text: The original noun chunk text.
Root text: The original text of the word connecting the noun chunk to the rest of the parse.
Root dep: Dependency relation connecting the root to its head.
Root head text: The text of the root token's head.


##Sentence Segmentation
#available via the Doc.sents property.
#spaCy uses the dependency parse to determine sentence boundaries. 

#If texts are closer to general-purpose news or web text, this should work well out-of-the-box. 
#For social media or conversational text use a custom rule-based implementation. 


##Default: Using the dependency parse
#iterate over the Doc.sents, a generator that yields Span  objects.

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"This is a sentence. This is another sentence.")
for sent in doc.sents:
    print(sent.text)


##Setting boundaries manually
#spaCy's dependency parser respects already set boundaries, 
#so you can preprocess your Doc using custom rules before it's parsed. 
#This can be done by adding a custom pipeline component. 

text = u"this is a sentence...hello...and another sentence."

nlp = spacy.load('en_core_web_sm')
doc = nlp(text)
print('Before:', [sent.text for sent in doc.sents])

def set_custom_boundaries(doc):
    for token in doc[:-1]:
        if token.text == '...':
            doc[token.i+1].is_sent_start = True
    return doc

nlp.add_pipe(set_custom_boundaries, before='parser')
doc = nlp(text)
print('After:', [sent.text for sent in doc.sents])


##Rule-based pipeline component
#The sentencizer component is a pipeline component that splits sentences on punctuation like ., ! or ?. 
#You can plug it into your pipeline if you only need sentence boundaries without the dependency parse. 
#Note that Doc.sents will raise an error if no sentence boundaries are set.

from spacy.lang.en import English

nlp = English()  # just the language with no model
sbd = nlp.create_pipe('sentencizer')   # or: nlp.create_pipe('sbd')
nlp.add_pipe(sbd)
doc = nlp(u"This is a sentence. This is another sentence.")
for sent in doc.sents:
    print(sent.text)


##Custom rule-based strategy
#instantiate the SentenceSegmenter directly and pass in a strategy. 
#The strategy should be a function that takes a Doc object and yields a Span for each sentence. 

from spacy.pipeline import SentenceSegmenter

def split_on_newlines(doc):
    start = 0
    seen_newline = False
    for word in doc:
        if seen_newline and not word.is_space:
            yield doc[start:word.i]
            start = word.i
            seen_newline = False
        elif word.text == '\n':
            seen_newline = True
    if start < len(doc):
        yield doc[start:len(doc)]

nlp = English()  # just the language with no model
sbd = SentenceSegmenter(nlp.vocab, strategy=split_on_newlines)
nlp.add_pipe(sbd)
doc = nlp(u"This is a sentence\n\nThis is another sentence\nAnd more")
for sent in doc.sents:
    print([token.text for token in sent])



##Get part-of-speech tags and flags
#Rule-based morphology
#Inflectional morphology is the process by which a root form of a word is modified 
#by adding prefixes or suffixes that specify its grammatical function but do not changes its part-of-speech. 
#We say that a lemma (root form) is inflected (modified/combined) with one or more morphological features to create a surface form
#Lemmatization is part of POS tagging in Spacy 

nlp = spacy.load('en_core_web_sm')
doc = nlp(u'Apple is looking at buying U.K. startup for $1 billion')
apple = doc[0]
print('Fine-grained POS tag', apple.pos_, apple.pos)
print('Coarse-grained POS tag', apple.tag_, apple.tag)
print('Word shape', apple.shape_, apple.shape)
print('Alphanumeric characters?', apple.is_alpha)
print('Punctuation mark?', apple.is_punct)

billion = doc[10]
print('Digit?', billion.is_digit)
print('Like a number?', billion.like_num)
print('Like an email address?', billion.like_email)




##Recognise and update named entities

nlp = spacy.load('en_core_web_sm')
doc = nlp(u'San Francisco considers banning sidewalk delivery robots')
for ent in doc.ents:
    print(ent.text, ent.start_char, ent.end_char, ent.label_)

from spacy.tokens import Span
doc = nlp(u'FB is hiring a new VP of global policy')
doc.ents = [Span(doc, 0, 1, label=doc.vocab.strings[u'ORG'])]
for ent in doc.ents:
    print(ent.text, ent.start_char, ent.end_char, ent.label_)


##Train and update neural network models

import spacy
import random

nlp = spacy.load('en')
train_data = [("Uber blew through $1 million", {'entities': [(0, 4, 'ORG')]})]

with nlp.disable_pipes(*[pipe for pipe in nlp.pipe_names if pipe != 'ner']):
    optimizer = nlp.begin_training()
    for i in range(10):
        random.shuffle(train_data)
        for text, annotations in train_data:
            nlp.update([text], [annotations], sgd=optimizer)
nlp.to_disk('/model')


##Visualize a dependency parse and named entities in  browser

from spacy import displacy

doc_dep = nlp(u'This is a sentence.')
displacy.serve(doc_dep, style='dep')

doc_ent = nlp(u'When Sebastian Thrun started working on self-driving cars at Google '
              u'in 2007, few people outside of the company took him seriously.')
displacy.serve(doc_ent, style='ent')


##Navigating the parse tree
#spaCy uses the terms head and child to describe the words connected by a single arc in the dependency tree. 
#The term dep is used for the arc label, 
#which describes the type of syntactic relation that connects the child to the head. 
#As with other attributes, the value of .dep is a hash value. 
#You can get the string value with .dep_

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"Autonomous cars shift insurance liability toward manufacturers")
for token in doc:
    print(token.text, token.dep_, token.head.text, token.head.pos_,
          [child for child in token.children])


#Meaning: 
Text: The original token text.
Dep: The syntactic relation connecting child to head.
Head text: The original text of the token head.
Head POS: The part-of-speech tag of the token head.
Children: The immediate syntactic dependents of the token.



#Because the syntactic relations form a tree, every word has exactly one head. 
#iterate over the arcs in the tree by iterating over the words in the sentence. 
#This is usually the best way to match an arc of interest 

from spacy.symbols import nsubj, VERB

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"Autonomous cars shift insurance liability toward manufacturers")

# Finding a verb with a subject from below — good
verbs = set()
for possible_subject in doc:
    if possible_subject.dep == nsubj and possible_subject.head.pos == VERB:
        verbs.add(possible_subject.head)
print(verbs)

# Finding a verb with a subject from above — less good
verbs = []
for possible_verb in doc:
    if possible_verb.pos == VERB:
        for possible_subject in possible_verb.children:
            if possible_subject.dep == nsubj:
                verbs.append(possible_verb)
                break

                
#Get a whole phrase by its syntactic head using the Token.subtree  attribute. 
#This returns an ordered sequence of tokens. 
#You can walk up the tree with the Token.ancestors  attribute, 
#and check dominance with Token.is_ancestor() .

#The Token.lefts  and Token.rights  attributes provide sequences of syntactic children that occur before and after the token. 
#Both sequences are in sentence order. 
#There are also two integer-typed attributes, 
#Token.n_rights  and Token.n_lefts , that give the number of left and right children.

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"bright red apples on the tree")
print([token.text for token in doc[2].lefts])  # ['bright', 'red']
print([token.text for token in doc[2].rights])  # ['on']
print(doc[2].n_lefts)  # 2
print(doc[2].n_rights)  # 1




##Projective vs. non-projective
#For the default English model, the parse tree is projective, 
#which means that there are no crossing brackets. 
#The tokens returned by .subtree are therefore guaranteed to be contiguous. 
#This is not true for the German model, which has many non-projective dependencies.

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"Credit and mortgage account holders must submit their requests")

root = [token for token in doc if token.head == token][0]
subject = list(root.lefts)[0]
for descendant in subject.subtree:
    assert subject is descendant or subject.is_ancestor(descendant)
    print(descendant.text, descendant.dep_, descendant.n_lefts,
          descendant.n_rights,
          [ancestor.text for ancestor in descendant.ancestors])


#the .left_edge and .right_edge attributes give  the first and last token of the subtree. 
#This is the easiest way to create a Span object for a syntactic phrase. 
#Note that .right_edge gives a token within the subtree — 
#so if you use it as the end-point of a range, don't forget to +1!

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"Credit and mortgage account holders must submit their requests")
span = doc[doc[4].left_edge.i : doc[4].right_edge.i+1]
span.merge()
for token in doc:
    print(token.text, token.pos_, token.dep_, token.head.text)





##Simple and efficient serialization
import spacy
from spacy.tokens import Doc
from spacy.vocab import Vocab

nlp = spacy.load('en')
customer_feedback = open('customer_feedback_627.txt').read()
doc = nlp(customer_feedback)
doc.to_disk('/tmp/customer_feedback_627.bin')

new_doc = Doc(Vocab()).from_disk('/tmp/customer_feedback_627.bin')


##Match text with token rules
#operates over tokens, similar to regular expressions
#The rules can refer to token annotations (e.g. the token text or tag_, and flags (e.g. IS_PUNCT). 

from spacy.matcher import Matcher

nlp = spacy.load('en_core_web_sm')
matcher = Matcher(nlp.vocab)

'''
matcher
    Matcher 
    The matcher instance. 
doc 
    Doc 
    The document the matcher was used on. 
i 
    int 
    Index of the current match (matches[i]). 
matches 
    list 
    A list of (match_id, start, end) tuples, describing the matches. 
    A match tuple describes a span doc[start:end]. 

'''
def set_sentiment(matcher, doc, i, matches):
    doc.sentiment += 0.1

pattern1 = [{'ORTH': 'Google'}, {'ORTH': 'I'}, {'ORTH': '/'}, {'ORTH': 'O'}]
pattern2 = [[{'ORTH': emoji, 'OP': '+'}] for emoji in ['😀', '😂', '🤣', '😍']]
'''
Matcher.add(match_id, on_match, *patterns)
    match_id 
        unicode 
        An ID for the thing you're matching. 
    on_match 
        callable or None 
        Callback function to act on matches. Takes the arguments matcher, doc, i and matches. 
    *patterns 
        list Match pattern. 
        A pattern consists of a list of dicts, where each dict describes a token. 
'''
matcher.add('GoogleIO', None, pattern1) # match "Google I/O" or "Google i/o"
matcher.add('HAPPY', set_sentiment, *pattern2) # match one or more happy emoji

doc = nlp(u"A text about Google I/O 😀😀")
matches = matcher(doc)  #A list of (match_id, start, end) tuples, Note match_id is in hash Id, so get string from nlp.vocab.strings[match_id]

for match_id, start, end in matches:
   string_id = nlp.vocab.strings[match_id]
   span = doc[start:end]
   print(string_id, span.text)
print('Sentiment', doc.sentiment)

#Another example 
import spacy
from spacy.matcher import Matcher

nlp = spacy.load('en_core_web_sm')
matcher = Matcher(nlp.vocab)

# Get the ID of the 'EVENT' entity type. This is required to set an entity.
EVENT = nlp.vocab.strings['EVENT']

def add_event_ent(matcher, doc, i, matches):
    # Get the current match and create tuple of entity label, start and end.
    # Append entity to the doc's entity. (Don't overwrite doc.ents!)
    match_id, start, end = matches[i]
    entity = (EVENT, start, end)
    doc.ents += (entity,)
    print(doc[start:end].text, entity)

matcher.add('GoogleIO', add_event_ent,
            [{'ORTH': 'Google'}, {'ORTH': 'I'}, {'ORTH': '/'}, {'ORTH': 'O'}],
            [{'ORTH': 'Google'}, {'ORTH': 'I'}, {'ORTH': '/'}, {'ORTH': 'O'}, {'IS_DIGIT': True}])

doc = nlp(u"This is a text about Google I/O 2015.")
matches = matcher(doc)


##Attribute Description
ORTH        The exact verbatim text of a token. 
LOWER       The lowercase form of the token text. 
LENGTH      The length of the token text. 
IS_ALPHA, IS_ASCII, IS_DIGIT    Token text consists of alphanumeric characters, ASCII characters, digits. 
IS_LOWER, IS_UPPER, IS_TITLE    Token text is in lowercase, uppercase, titlecase. 
IS_PUNCT, IS_SPACE, IS_STOP     Token is punctuation, whitespace, stop word. 
LIKE_NUM, LIKE_URL, LIKE_EMAIL  Token text resembles a number, URL, email. 
POS, TAG, DEP, LEMMA, SHAPE     The token's simple and extended part-of-speech tag, dependency label, lemma, shape. 
ENT_TYPE                        The token's entity label. 

#Example 
#A token whose lowercase form matches "hello", e.g. "Hello" or "HELLO".
#A token whose is_punct flag is set to True, i.e. any punctuation.
#A token whose lowercase form matches "world", e.g. "World" or "WORLD".

[{'LOWER': 'hello'}, {'IS_PUNCT': True}, {'LOWER': 'world'}]



##Using wildcard token patterns
#use an empty dictionary, {} as a wildcard representing any token.
[{'ORTH': 'User'}, {'ORTH': 'name'}, {'ORTH': ':'}, {}]

##Using operators and quantifiers
#use quantifiers, specified as the 'OP' key. 
#Quantifiers let you define sequences of tokens to be mached, e.g. one or more punctuation marks, or specify optional tokens. 
#Note that there are no nested or scoped quantifiers – instead,  build those behaviours with on_match callbacks.

#OP Description
!   Negate the pattern, by requiring it to match exactly 0 times. 
?   Make the pattern optional, by allowing it to match 0 or 1 times. 
+   Require the pattern to match 1 or more times. 
*   Allow the pattern to match zero or more times. 

In versions before v2.1.0, the semantics of the + and * operators behave inconsistently. They were usually interpreted "greedily", i.e. longer matches are returned where possible. However, if you specify two + and * patterns in a row and their matches overlap, the first operator will behave non-greedily. This quirk in the semantics is corrected in spaCy v2.1.0.


##Adding phrase patterns
#to match large terminology lists, use the PhraseMatcher  
#and create Doc  objects instead of token patterns, which is much more efficient overall. 
#The Doc patterns can contain single or multiple tokens.

from spacy.matcher import PhraseMatcher

nlp = spacy.load('en_core_web_sm')
matcher = PhraseMatcher(nlp.vocab)
terminology_list = ['Barack Obama', 'Angela Merkel', 'Washington, D.C.']
patterns = [nlp(text) for text in terminology_list]
matcher.add('TerminologyList', None, *patterns)

doc = nlp(u"German Chancellor Angela Merkel and US President Barack Obama "
          u"converse in the Oval Office inside the White House in Washington, D.C.")
matches = matcher(doc)
for match_id, start, end in matches:
    span = doc[start:end]
    print(span.text)



##Using RegEx with Spacy 

import spacy
import re

nlp = spacy.load('en_core_web_sm')
doc = nlp(u'The spelling is "definitely", not "definately" or "deffinitely".')

DEFINITELY_PATTERN = re.compile(r'deff?in[ia]tely')

for match in re.finditer(DEFINITELY_PATTERN, doc.text):
    start, end = match.span()         # get matched indices
    span = doc.char_span(start, end)  # create Span from indices
    print(span.text)

#or with Matcher 

import spacy
from spacy.matcher import Matcher
import re

nlp = spacy.load('en_core_web_sm')
definitely_flag = lambda text: bool(re.compile(r'deff?in[ia]tely').match(text))
IS_DEFINITELY = nlp.vocab.add_flag(definitely_flag)

matcher = Matcher(nlp.vocab)
matcher.add('DEFINITELY', None, [{IS_DEFINITELY: True}])

doc = nlp(u'The spelling is "definitely", not "definately" or "deffinitely".')
matches = matcher(doc)
for match_id, start, end in matches:
    span = doc[start:end]
    print(span.text)

Providing the regular expressions as binary flags also lets you use them in combination with other token patterns – for example, to match the word "definitely" in various spellings, followed by a case-insensitive "not" and and adjective:
[{IS_DEFINITELY: True}, {'LOWER': 'not'}, {'POS': 'ADJ'}]


#Example - phone number 
import spacy
from spacy.matcher import Matcher

nlp = spacy.load('en_core_web_sm')
matcher = Matcher(nlp.vocab)
pattern = [{'ORTH': '('}, {'SHAPE': 'ddd'}, {'ORTH': ')'}, {'SHAPE': 'ddd'},
           {'ORTH': '-', 'OP': '?'}, {'SHAPE': 'ddd'}]
matcher.add('PHONE_NUMBER', None, pattern)

doc = nlp(u"Call me at (123) 456 789 or (123) 456 789!")
print([t.text for t in doc])
matches = matcher(doc)
for match_id, start, end in matches:
    span = doc[start:end]
    print(span.text)


#Example - Using linguistic annotations
import spacy
from spacy import displacy
from spacy.matcher import Matcher

nlp = spacy.load('en_core_web_sm')
matcher = Matcher(nlp.vocab)
matched_sents = [] # collect data of matched sentences to be visualized

def collect_sents(matcher, doc, i, matches):
    match_id, start, end = matches[i]
    span = doc[start : end]  # matched span
    sent = span.sent  # sentence containing matched span
    # append mock entity for match in displaCy style to matched_sents
    # get the match span by ofsetting the start and end of the span with the
    # start and end of the sentence in the doc
    match_ents = [{'start': span.start_char - sent.start_char,
                   'end': span.end_char - sent.start_char,
                   'label': 'MATCH'}]
    matched_sents.append({'text': sent.text, 'ents': match_ents })

pattern = [{'LOWER': 'facebook'}, {'LEMMA': 'be'}, {'POS': 'ADV', 'OP': '*'},
           {'POS': 'ADJ'}]
matcher.add('FacebookIs', collect_sents, pattern)  # add pattern
doc = nlp(u"I'd say that Facebook is evil. – Facebook is pretty cool, right?")
matches = matcher(doc)

# serve visualization of sentences containing match with displaCy
# set manual=True to make displaCy render straight from a dictionary
# (if you're not running the code within a Jupyer environment, you can
# remove jupyter=True and use displacy.serve instead)
displacy.render(matched_sents, style='ent', manual=True, jupyter=True)





##Multi-threaded generator
texts = [u'One document.', u'...', u'Lots of documents']
# .pipe streams input, and produces streaming output
iter_texts = (texts[i % 3] for i in xrange(100000000))
'''
stream 
    iterable 
    A stream of documents. 
batch_size 
    int 
    The number of texts to buffer. Defaults to 128. 
n_threads 
    int 
    The number of worker threads to use. If -1, OpenMP will decide how many to use at run time. Default is -1. 
yields Doc 
    Processed documents in the order of the original text. 

'''
for i, doc in enumerate(nlp.pipe(iter_texts, batch_size=50, n_threads=4)):
    assert doc.is_parsed
    if i == 100:
        break


        
        
##Get syntactic dependencies

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"When Sebastian Thrun started working on self-driving cars at Google "
          u"in 2007, few people outside of the company took him seriously.")

dep_labels = []
for token in doc:
    while token.head != token:
        dep_labels.append(token.dep_)
        token = token.head
print(dep_labels)


##Export to numpy arrays

from spacy.attrs import ORTH, LIKE_URL

nlp = spacy.load('en_core_web_sm')
doc = nlp(u"Check out https://spacy.io")
for token in doc:
    print(token.text, token.orth, token.like_url)

attr_ids = [ORTH, LIKE_URL]
doc_array = doc.to_array(attr_ids)
print(doc_array.shape)
print(len(doc), len(attr_ids))

assert doc[0].orth == doc_array[0, 0]
assert doc[1].orth == doc_array[1, 0]
assert doc[0].like_url == doc_array[0, 1]

assert list(doc_array[:, 1]) == [t.like_url for t in doc]
print(list(doc_array[:, 1]))




##Architecture- Container objects
Doc  
    A container for accessing linguistic annotations. 
Span  
    A slice from a Doc object. 
Token  
    An individual token — i.e. a word, punctuation symbol, whitespace, etc. 
Lexeme  
    An entry in the vocabulary. It's a word type with no context, as opposed to a word token. It therefore has no part-of-speech tag, dependency parse etc. 

##Processing pipeline
Language  
    A text-processing pipeline. Usually you'll load this once per process as nlp and pass the instance around your application. 
Pipe  
    Base class for processing pipeline components. 
Tagger  
    Annotate part-of-speech tags on Doc objects. 
DependencyParser 
    Annotate syntactic dependencies on Doc objects. 
EntityRecognizer  
    Annotate named entities, e.g. persons or products, on Doc objects. 
TextCategorizer  
    Assigning categories or labels to Doc objects. 
Tokenizer  
    Segment text, and create Doc objects with the discovered segment boundaries. 
Lemmatizer  
    Determine the base forms of words. 
Morphology 
    Assign linguistic features like lemmas, noun case, verb tense etc. based on the word and its part-of-speech tag. 
Matcher  
    Match sequences of tokens, based on pattern rules, similar to regular expressions. 
PhraseMatcher  
    Match sequences of tokens based on phrases. 

##Other classes
Vocab  
    A lookup table for the vocabulary that allows you to access Lexeme objects. 
StringStore  
    Map strings to and from hash values. 
Vectors  
    Container class for vector data keyed by string. 
GoldParse  
    Collection for training annotations. 
GoldCorpus  
    An annotated corpus, using the JSON file format. Manages annotations for tagging, dependency parsing and NER. 



 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


###Dependency parsing and Co-reference resolution in python nltk using Stanford coreNLP, stanfordcorenlp
#https://stanfordnlp.github.io/CoreNLP/

#Coreference resolution is the task of finding all expressions that refer to the same entity in a text

##Java 64 bit 1.8+ (Check with command: java -version) required, if 32 bit 
$ set PATH=C:\Program Files\Java\jre1.8.0_66\bin;%PATH%
#Download from https://stanfordnlp.github.io/CoreNLP/history.html


#https://github.com/Lynten/stanford-corenlp
#change site-packages\stanfordcorenlp\corenlp.py, line 46, include shell=True
$ pip install stanfordcorenlp


#Example 
import json
from stanfordcorenlp import StanfordCoreNLP

nlp = StanfordCoreNLP(r'C:\nltk_data\stanford-corenlp-full-2018-02-27', quiet=False)
props = {'annotators': 'dcoref', 'pipelineLanguage': 'en'} #dcoref - detreministic version, coref- might get Out of heap space 

text = 'Barack Obama was born in Hawaii.  He is the president. Obama was elected in 2008.'
result = json.loads(nlp.annotate(text, properties=props))

#All coreferences
#check https://nlp.stanford.edu/software/dcoref.html 
import pprint
for num,mention in result['corefs'].items():
    pprint.pprint([num,mention])
#Note '1' which contains 4 mentions related to Obama 
['6',
 [{'animacy': 'INANIMATE',
   'endIndex': 6,
   'gender': 'UNKNOWN',
   'headIndex': 5,
   'id': 6,
   'isRepresentativeMention': True,
   'number': 'SINGULAR',
   'position': [3, 2],
   'sentNum': 3,
   'startIndex': 5,
   'text': '2008',
   'type': 'PROPER'}]]
['1',
 [{'animacy': 'ANIMATE',
   'endIndex': 3,
   'gender': 'MALE',
   'headIndex': 2,
   'id': 1,
   'isRepresentativeMention': True,
   'number': 'SINGULAR',
   'position': [1, 1],
   'sentNum': 1,
   'startIndex': 1,
   'text': 'Barack Obama',
   'type': 'PROPER'},
  {'animacy': 'ANIMATE',
   'endIndex': 2,
   'gender': 'MALE',
   'headIndex': 1,
   'id': 3,
   'isRepresentativeMention': False,
   'number': 'SINGULAR',
   'position': [2, 1],
   'sentNum': 2,
   'startIndex': 1,
   'text': 'He',
   'type': 'PRONOMINAL'},
  {'animacy': 'ANIMATE',
   'endIndex': 5,
   'gender': 'MALE',
   'headIndex': 4,
   'id': 4,
   'isRepresentativeMention': False,
   'number': 'SINGULAR',
   'position': [2, 2],
   'sentNum': 2,
   'startIndex': 3,
   'text': 'the president',
   'type': 'NOMINAL'},
  {'animacy': 'ANIMATE',
   'endIndex': 2,
   'gender': 'MALE',
   'headIndex': 1,
   'id': 5,
   'isRepresentativeMention': False,
   'number': 'SINGULAR',
   'position': [3, 1],
   'sentNum': 3,
   'startIndex': 1,
   'text': 'Obama',
   'type': 'PROPER'}]]
['2',
 [{'animacy': 'INANIMATE',
   'endIndex': 7,
   'gender': 'NEUTRAL',
   'headIndex': 6,
   'id': 2,
   'isRepresentativeMention': True,
   'number': 'SINGULAR',
   'position': [1, 2],
   'sentNum': 1,
   'startIndex': 6,
   'text': 'Hawaii',
   'type': 'PROPER'}]]






##StanfordCoreNLP - Quick Intro 
## Simple usage
from stanfordcorenlp import StanfordCoreNLP

nlp = StanfordCoreNLP(r'C:\nltk_data\stanford-corenlp-full-2018-02-27')

sentence = 'Guangdong University of Foreign Studies is located in Guangzhou.'
print('Tokenize:', nlp.word_tokenize(sentence))
print( 'Part of Speech:', nlp.pos_tag(sentence))
print('Named Entities:', nlp.ner(sentence))
print('Constituency Parsing:', nlp.parse(sentence))
print('Dependency Parsing:', nlp.dependency_parse(sentence))

nlp.close() # Do not forget to close! The backend server will consume a lot memery.

#Output format:

# Tokenize
[u'Guangdong', u'University', u'of', u'Foreign', u'Studies', u'is', u'located', u'in', u'Guangzhou', u'.']

# Part of Speech
[(u'Guangdong', u'NNP'), (u'University', u'NNP'), (u'of', u'IN'), (u'Foreign', u'NNP'), (u'Studies', u'NNPS'), (u'is', u'VBZ'), (u'located', u'JJ'), (u'in', u'IN'), (u'Guangzhou', u'NNP'), (u'.', u'.')]

# Named Entities
 [(u'Guangdong', u'ORGANIZATION'), (u'University', u'ORGANIZATION'), (u'of', u'ORGANIZATION'), (u'Foreign', u'ORGANIZATION'), (u'Studies', u'ORGANIZATION'), (u'is', u'O'), (u'located', u'O'), (u'in', u'O'), (u'Guangzhou', u'LOCATION'), (u'.', u'O')]

# Constituency Parsing
 (ROOT
  (S
    (NP
      (NP (NNP Guangdong) (NNP University))
      (PP (IN of)
        (NP (NNP Foreign) (NNPS Studies))))
    (VP (VBZ is)
      (ADJP (JJ located)
        (PP (IN in)
          (NP (NNP Guangzhou)))))
    (. .)))

# Dependency Parsing
[(u'ROOT', 0, 7), (u'compound', 2, 1), (u'nsubjpass', 7, 2), (u'case', 5, 3), (u'compound', 5, 4), (u'nmod', 2, 5), (u'auxpass', 7, 6), (u'case', 9, 8), (u'nmod', 7, 9), (u'punct', 7, 10)]



##General Stanford CoreNLP API
#initialize the server with more memory. 8GB is recommended.

#properties:
#annotators: tokenize, ssplit, pos, lemma, ner, parse, depparse, dcoref 
#pipelineLanguage: en, zh, ar, fr, de, es (English, Chinese, Arabic, French, German, Spanish) 
#outputFormat: json, xml, text

#eg Other properties eg {"coref.algorithm": "neural"}

nlp = StanfordCoreNLP(r'path_to_corenlp', memory='6g')

text = 'Guangdong University of Foreign Studies is located in Guangzhou. ' \
       'GDUFS is active in a full range of international cooperation and exchanges in education. '

props={'annotators': 'tokenize,ssplit,pos','pipelineLanguage':'en','outputFormat':'xml'}
print(nlp.annotate(text, properties=props))

nlp.close()




##Use an Existing Server
#Start a CoreNLP Server with command:
java -mx4g -cp "*" edu.stanford.nlp.pipeline.StanfordCoreNLPServer -port 9000 -timeout 15000


# Use an existing server
nlp = StanfordCoreNLP('http://localhost', port=9000)

##Logging 
import logging
from stanfordcorenlp import StanfordCoreNLP

# Debug the wrapper
nlp = StanfordCoreNLP(r'path_or_host', logging_level=logging.DEBUG)

# Check more info from the CoreNLP Server 
nlp = StanfordCoreNLP(r'path_or_host', quiet=False, logging_level=logging.DEBUG)
nlp.close()




##Annotators
#check https://stanfordnlp.github.io/CoreNLP/annotators.html 
#and individual page for other options 
#Name    Annotator class name   
#        Generated Annotation    
#        Description
tokenize TokenizerAnnotator 
    TokensAnnotation (list of tokens); CharacterOffsetBeginAnnotation, CharacterOffsetEndAnnotation, TextAnnotation (for each token) 
    Tokenizes the text. This splits the text into roughly “words”, 
    using rules or methods suitable for the language being processed. 
    Sometimes the tokens split up surface words in ways suitable for further NLP-processing, 
    for example “isn’t” becomes “is” and “n’t”. 
    The tokenizer saves the beginning and end character offsets of each token in the input text. 
cleanxml CleanXmlAnnotator 
    XmlContextAnnotation 
    Remove xml tokens from the document. 
    May use them to mark sentence ends or to extract metadata. 
ssplit WordsToSentencesAnnotator 
    SentencesAnnotation
    Splits a sequence of tokens into sentences. 
pos POSTaggerAnnotator 
    PartOfSpeechAnnotation 
    Labels tokens with their POS tag. For more details see this page. 
lemma MorphaAnnotator 
    LemmaAnnotation 
    Generates the word lemmas for all tokens in the corpus. 
ner NERClassifierCombiner 
    NamedEntityTagAnnotation and NormalizedNamedEntityTagAnnotation 
    Recognizes named (PERSON, LOCATION, ORGANIZATION, MISC), 
    numerical (MONEY, NUMBER, ORDINAL, PERCENT), 
    and temporal (DATE, TIME, DURATION, SET) entities. 
    Named entities are recognized using a combination of three CRF sequence taggers trained on various corpora,  such as ACE and MUC. 
    Numerical entities are recognized using a rule-based system. 
    Numerical entities that require normalization, 
    e.g., dates, are normalized to NormalizedNamedEntityTagAnnotation. 
regexner TokensRegexNERAnnotator 
    NamedEntityTagAnnotation 
    Implements a simple, rule-based NER over token sequences using Java regular expressions. 
    The goal of this Annotator is to provide a simple framework to incorporate NE labels that are not annotated in traditional NL corpora. 
    For example, the default list of regular expressions that we distribute in the models file recognizes 
    ideologies (IDEOLOGY), nationalities (NATIONALITY), religions (RELIGION), and titles (TITLE). 
    For more complex applications, you might consider TokensRegex. 
sentiment SentimentAnnotator 
    entimentCoreAnnotations.AnnotatedTree 
    Implements Socher et al’s sentiment model. 
    Attaches a binarized tree of the sentence to the sentence level CoreMap. 
    The nodes of the tree then contain the annotations from RNNCoreAnnotations indicating the predicted class 
    and scores for that subtree. 
truecase TrueCaseAnnotator 
    TrueCaseAnnotation and TrueCaseTextAnnotation 
    Recognizes the true case of tokens in text where this information was lost, 
    e.g., all upper case text. 
    This is implemented with a discriminative model implemented using a CRF sequence tagger. 
    The true case label, e.g., INIT_UPPER is saved in TrueCaseAnnotation. 
    The token text adjusted to match its true case is saved as TrueCaseTextAnnotation. 
parse ParserAnnotator 
    TreeAnnotation, BasicDependenciesAnnotation, CollapsedDependenciesAnnotation, CollapsedCCProcessedDependenciesAnnotation 
    Provides full syntactic analysis, using both the constituent and the dependency representations. 
    The constituent-based output is saved in TreeAnnotation. 
    We generate three dependency-based outputs, as follows: 
    basic, uncollapsed dependencies, saved in BasicDependenciesAnnotation; 
    collapsed dependencies saved in CollapsedDependenciesAnnotation; 
    and collapsed dependencies with processed coordinations, in CollapsedCCProcessedDependenciesAnnotation. 
    Most users of our parser will prefer the latter representation. 
depparse DependencyParseAnnotator 
    BasicDependenciesAnnotation, CollapsedDependenciesAnnotation, CollapsedCCProcessedDependenciesAnnotation 
    Provides a fast syntactic dependency parser. 
    We generate three dependency-based outputs, as follows: basic, uncollapsed dependencies, 
    saved in BasicDependenciesAnnotation; collapsed dependencies saved in CollapsedDependenciesAnnotation; 
    and collapsed dependencies with processed coordinations, in CollapsedCCProcessedDependenciesAnnotation. 
    Most users of our parser will prefer the latter representation. 
dcoref DeterministicCorefAnnotator 
    CorefChainAnnotation 
    Implements both pronominal and nominal coreference resolution. 
    The entire coreference graph (with head words of mentions as nodes) is saved in CorefChainAnnotation. 
relation RelationExtractorAnnotator 
    MachineReadingAnnotations.RelationMentionsAnnotation 
    Stanford relation extractor is a Java implementation to find relations between two entities. 
    The current relation extraction model is trained on the relation types (except the ‘kill’ relation) and data from the paper Roth and Yih, Global inference for entity and relation identification via a linear programming formulation, 2007, except instead of using the gold NER tags, we used the NER tags predicted by Stanford NER classifier to improve generalization. 
    The default model predicts relations Live_In, Located_In, OrgBased_In, Work_For, and None. 
natlog NaturalLogicAnnotator 
    OperatorAnnotation, PolarityAnnotation 
    Marks quantifier scope and token polarity, according to natural logic semantics. 
    Places an OperatorAnnotation on tokens which are quantifiers (or other natural logic operators), and a PolarityAnnotation on all tokens in the sentence. 
quote QuoteAnnotator 
    QuotationAnnotation 
    Deterministically picks out quotes delimited by “ or ‘ from a text. 
    All top-level quotes are supplied by the top level annotation for a text. 
    If a QuotationAnnotation corresponds to a quote that contains embedded quotes, 
    these quotes will appear as embedded QuotationAnnotations that can be accessed from the QuotationAnnotation that they are embedded in. 
    The QuoteAnnotator can handle multi-line and cross-paragraph quotes, 
    but any embedded quotes must be delimited by a different kind of quotation mark than its parents. 
    Does not depend on any other annotators. 
    Support for unicode quotes is not yet present. 
openie 
    Open information extraction (open IE) refers to the extraction of relation tuples, 
    typically binary relations, from plain text, such as (Mark Zuckerberg; founded; Facebook). 
    The central difference from other information extraction is that the schema for these relations does not need to be specified in advance; 
    typically the relation name is just the text linking two arguments. 
    For example, Barack Obama was born in Hawaii would create a triple (Barack Obama; was born in; 
    Hawaii), corresponding to the open domain relation was-born-in(Barack-Obama, Hawaii)
    
##Example - Relation extraction using openie 
#set64 bit java 

from stanfordcorenlp import StanfordCoreNLP

nlp = StanfordCoreNLP(r'C:\nltk_data\stanford-corenlp-full-2018-02-27')

text = "Obama was born in Hawaii. He is our president."
props={'annotators': "tokenize,ssplit,pos,lemma,depparse,natlog,openie",
    'pipelineLanguage':'en','outputFormat':'json'}

import json 
obj  = json.loads(nlp.annotate(text, properties=props))
import pprint
pprint.pprint(obj)
for e in obj['sentences']:
    pprint.pprint(e['index'])
    pprint.pprint(e['openie'])

nlp.close()





    
    
    
    
    
    
    


###NLTK and Stanford CoreNLP - Sentiment analysis
#Sentiment analysis (sometimes known as opinion mining or emotion AI) 
#refers to the use of natural language processing, text analysis, computational linguistics, and biometrics 
#to systematically identify, extract, quantify, and study affective states and subjective information.

#sentiment analysis aims to determine the attitude of a speaker, writer, or other subject with respect to some topic or the overall contextual polarity or emotional reaction to a document, interaction, or event. 
#The attitude may be a judgment or evaluation , affective state (that is to say, the emotional state of the author or speaker), or the intended emotional communication (that is to say, the emotional effect intended by the author or interlocutor).


from nltk.classify import NaiveBayesClassifier
from nltk.corpus import subjectivity
from nltk.sentiment import SentimentAnalyzer
from nltk.sentiment.util import *

n_instances = 100
subj_docs = [(sent, 'subj') for sent in subjectivity.sents(categories='subj')[:n_instances]]
obj_docs = [(sent, 'obj') for sent in subjectivity.sents(categories='obj')[:n_instances]]
>>> len(subj_docs), len(obj_docs)
(100, 100)


#Each document is represented by a tuple (sentence, label). 
#The sentence is tokenized, so it is represented by a list of strings:

>>> subj_docs[0]
(['smart', 'and', 'alert', ',', 'thirteen', 'conversations', 'about', 'one',
'thing', 'is', 'a', 'small', 'gem', '.'], 'subj')


#We separately split subjective and objective instances 
#to keep a balanced uniform class distribution in both train and test sets.

train_subj_docs = subj_docs[:80]
test_subj_docs = subj_docs[80:100]
train_obj_docs = obj_docs[:80]
test_obj_docs = obj_docs[80:100]
training_docs = train_subj_docs+train_obj_docs
testing_docs = test_subj_docs+test_obj_docs

sentim_analyzer = SentimentAnalyzer()
#nltk.sentiment.util.mark_negation(document, double_neg_flip=False, shallow=False)
#Append _NEG suffix to words that appear in the scope between a negation and a punctuation mark

#all_words :Return all words/tokens from the documents (with duplicates).
all_words_neg = sentim_analyzer.all_words([mark_negation(doc) for doc in training_docs])


#We use simple unigram word features, handling negation:
#unigram_word_feats:Return most common top_n word features
unigram_feats = sentim_analyzer.unigram_word_feats(all_words_neg, min_freq=4)
>>> len(unigram_feats)
83

#add_feat_extractor:Add a new function to extract features from a document. 
#This function will be used in extract_features().

#nltk.sentiment.util.extract_unigram_feats(document, unigrams, handle_negation=False)
#Populate a dictionary of unigram features, reflecting the presence/absence in the document of each of the tokens in unigrams.
sentim_analyzer.add_feat_extractor(extract_unigram_feats, unigrams=unigram_feats)

#We apply features to obtain a feature-value representation of our datasets:
#apply_features(documents, labeled=None)[source]
#Apply all feature extractor functions to the documents
training_set = sentim_analyzer.apply_features(training_docs)
test_set = sentim_analyzer.apply_features(testing_docs)


#We can now train our classifier on the training set, 
#and subsequently output the evaluation results:

trainer = NaiveBayesClassifier.train
classifier = sentim_analyzer.train(trainer, training_set)

#Training classifier
for key,value in sorted(sentim_analyzer.evaluate(test_set).items()):
    print('{0}: {1}'.format(key, value))
Evaluating NaiveBayesClassifier results...
Accuracy: 0.8
F-measure [obj]: 0.8
F-measure [subj]: 0.8
Precision [obj]: 0.8
Precision [subj]: 0.8
Recall [obj]: 0.8
Recall [subj]: 0.8



##VADER sentiment analysis tools
$ pip install twython

from nltk.sentiment.vader import SentimentIntensityAnalyzer
sentences = ["VADER is smart, handsome, and funny.", # positive sentence example
        "VADER is smart, handsome, and funny!", # punctuation emphasis handled correctly (sentiment intensity adjusted)
        "VADER is very smart, handsome, and funny.",  # booster words handled correctly (sentiment intensity adjusted)
        "VADER is VERY SMART, handsome, and FUNNY.",  # emphasis for ALLCAPS handled
        "VADER is VERY SMART, handsome, and FUNNY!!!",# combination of signals - VADER appropriately adjusts intensity
        "VADER is VERY SMART, really handsome, and INCREDIBLY FUNNY!!!",# booster words & punctuation make this close to ceiling for score
        "The book was good.",         # positive sentence
        "The book was kind of good.", # qualified positive sentence is handled correctly (intensity adjusted)
        "The plot was good, but the characters are uncompelling and the dialog is not great.", # mixed negation sentence
        "A really bad, horrible book.",       # negative sentence with booster words
        "At least it isn't a horrible book.", # negated negative sentence with contraction
        ":) and :D",     # emoticons handled
        "",              # an empty string is correctly handled
        "Today sux",     #  negative slang handled
        "Today sux!",    #  negative slang with punctuation emphasis handled
        "Today SUX!",    #  negative slang with capitalization emphasis
        "Today kinda sux! But I'll get by, lol" # mixed sentiment example with slang and constrastive conjunction "but"
    ]
paragraph = "It was one of the worst movies I've seen, despite good reviews. \
    Unbelievably bad acting!! Poor direction. VERY poor production. \
    The movie was bad. Very bad movie. VERY bad movie. VERY BAD movie. VERY BAD movie!"

from nltk import tokenize
lines_list = tokenize.sent_tokenize(paragraph)
sentences.extend(lines_list)

tricky_sentences = [
        "Most automated sentiment analysis tools are shit.",
        "VADER sentiment analysis is the shit.",
        "Sentiment analysis has never been good.",
        "Sentiment analysis with VADER has never been this good.",
        "Warren Beatty has never been so entertaining.",
        "I won't say that the movie is astounding and I wouldn't claim that \
        the movie is too banal either.",
        "I like to hate Michael Bay films, but I couldn't fault this one",
        "It's one thing to watch an Uwe Boll film, but another thing entirely \
        to pay for it",
        "The movie was too good",
        "This movie was actually neither that funny, nor super witty.",
        "This movie doesn't care about cleverness, wit or any other kind of \
        intelligent humor.",
        "Those who find ugly meanings in beautiful things are corrupt without \
        being charming.",
        "There are slow and repetitive parts, BUT it has just enough spice to \
        keep it interesting.",
        "The script is not fantastic, but the acting is decent and the cinematography \
        is EXCELLENT!",
        "Roger Dodger is one of the most compelling variations on this theme.",
        "Roger Dodger is one of the least compelling variations on this theme.",
        "Roger Dodger is at least compelling as a variation on the theme.",
        "they fall in love with the product",
        "but then it breaks",
        "usually around the time the 90 day warranty expires",
        "the twin towers collapsed today",
        "However, Mr. Carter solemnly argues, his client carried out the kidnapping \
        under orders and in the ''least offensive way possible.''"
    ]
sentences.extend(tricky_sentences)


sid = SentimentIntensityAnalyzer() #Give a sentiment intensity score to sentences
for sentence in sentences:
    print(sentence)
    ss = sid.polarity_scores(sentence) #Return a float for sentiment strength based on the input text. Positive values are positive valence, negative value are negative valence
    for k in sorted(ss):
        print('{0}: {1}, '.format(k, ss[k]), end='')
    print()
#OUTPUT
VADER is smart, handsome, and funny.
compound: 0.8316, neg: 0.0, neu: 0.254, pos: 0.746,
VADER is smart, handsome, and funny!
compound: 0.8439, neg: 0.0, neu: 0.248, pos: 0.752,
VADER is very smart, handsome, and funny.
compound: 0.8545, neg: 0.0, neu: 0.299, pos: 0.701,
VADER is VERY SMART, handsome, and FUNNY.
compound: 0.9227, neg: 0.0, neu: 0.246, pos: 0.754,
VADER is VERY SMART, handsome, and FUNNY!!!
compound: 0.9342, neg: 0.0, neu: 0.233, pos: 0.767,
VADER is VERY SMART, really handsome, and INCREDIBLY FUNNY!!!
compound: 0.9469, neg: 0.0, neu: 0.294, pos: 0.706,
The book was good.
compound: 0.4404, neg: 0.0, neu: 0.508, pos: 0.492,
The book was kind of good.
compound: 0.3832, neg: 0.0, neu: 0.657, pos: 0.343,
The plot was good, but the characters are uncompelling and the dialog is not great.
compound: -0.7042, neg: 0.327, neu: 0.579, pos: 0.094,
A really bad, horrible book.
compound: -0.8211, neg: 0.791, neu: 0.209, pos: 0.0,
At least it isn't a horrible book.
compound: 0.431, neg: 0.0, neu: 0.637, pos: 0.363,
:) and :D
compound: 0.7925, neg: 0.0, neu: 0.124, pos: 0.876,
<BLANKLINE>
compound: 0.0, neg: 0.0, neu: 0.0, pos: 0.0,
Today sux
compound: -0.3612, neg: 0.714, neu: 0.286, pos: 0.0,
Today sux!
compound: -0.4199, neg: 0.736, neu: 0.264, pos: 0.0,
Today SUX!
compound: -0.5461, neg: 0.779, neu: 0.221, pos: 0.0,
Today kinda sux! But I'll get by, lol
compound: 0.2228, neg: 0.195, neu: 0.531, pos: 0.274,
It was one of the worst movies I've seen, despite good reviews.
compound: -0.7584, neg: 0.394, neu: 0.606, pos: 0.0,
Unbelievably bad acting!!
compound: -0.6572, neg: 0.686, neu: 0.314, pos: 0.0,
Poor direction.
compound: -0.4767, neg: 0.756, neu: 0.244, pos: 0.0,
VERY poor production.
compound: -0.6281, neg: 0.674, neu: 0.326, pos: 0.0,
The movie was bad.
compound: -0.5423, neg: 0.538, neu: 0.462, pos: 0.0,
Very bad movie.
compound: -0.5849, neg: 0.655, neu: 0.345, pos: 0.0,
VERY bad movie.
compound: -0.6732, neg: 0.694, neu: 0.306, pos: 0.0,
VERY BAD movie.
compound: -0.7398, neg: 0.724, neu: 0.276, pos: 0.0,
VERY BAD movie!
compound: -0.7616, neg: 0.735, neu: 0.265, pos: 0.0,
Most automated sentiment analysis tools are shit.
compound: -0.5574, neg: 0.375, neu: 0.625, pos: 0.0,
VADER sentiment analysis is the shit.
compound: 0.6124, neg: 0.0, neu: 0.556, pos: 0.444,
Sentiment analysis has never been good.
compound: -0.3412, neg: 0.325, neu: 0.675, pos: 0.0,
Sentiment analysis with VADER has never been this good.
compound: 0.5228, neg: 0.0, neu: 0.703, pos: 0.297,
Warren Beatty has never been so entertaining.
compound: 0.5777, neg: 0.0, neu: 0.616, pos: 0.384,
I won't say that the movie is astounding and I wouldn't claim that the movie is too banal either.
compound: 0.4215, neg: 0.0, neu: 0.851, pos: 0.149,
I like to hate Michael Bay films, but I couldn't fault this one
compound: 0.3153, neg: 0.157, neu: 0.534, pos: 0.309,
It's one thing to watch an Uwe Boll film, but another thing entirely to pay for it
compound: -0.2541, neg: 0.112, neu: 0.888, pos: 0.0,
The movie was too good
compound: 0.4404, neg: 0.0, neu: 0.58, pos: 0.42,
This movie was actually neither that funny, nor super witty.
compound: -0.6759, neg: 0.41, neu: 0.59, pos: 0.0,
This movie doesn't care about cleverness, wit or any other kind of intelligent humor.
compound: -0.1338, neg: 0.265, neu: 0.497, pos: 0.239,
Those who find ugly meanings in beautiful things are corrupt without being charming.
compound: -0.3553, neg: 0.314, neu: 0.493, pos: 0.192,
There are slow and repetitive parts, BUT it has just enough spice to keep it interesting.
compound: 0.4678, neg: 0.079, neu: 0.735, pos: 0.186,
The script is not fantastic, but the acting is decent and the cinematography is EXCELLENT!
compound: 0.7565, neg: 0.092, neu: 0.607, pos: 0.301,
Roger Dodger is one of the most compelling variations on this theme.
compound: 0.2944, neg: 0.0, neu: 0.834, pos: 0.166,
Roger Dodger is one of the least compelling variations on this theme.
compound: -0.1695, neg: 0.132, neu: 0.868, pos: 0.0,
Roger Dodger is at least compelling as a variation on the theme.
compound: 0.2263, neg: 0.0, neu: 0.84, pos: 0.16,
they fall in love with the product
compound: 0.6369, neg: 0.0, neu: 0.588, pos: 0.412,
but then it breaks
compound: 0.0, neg: 0.0, neu: 1.0, pos: 0.0,
usually around the time the 90 day warranty expires
compound: 0.0, neg: 0.0, neu: 1.0, pos: 0.0,
the twin towers collapsed today
compound: -0.2732, neg: 0.344, neu: 0.656, pos: 0.0,
However, Mr. Carter solemnly argues, his client carried out the kidnapping under orders and in the ''least offensive way possible.''
compound: -0.5859, neg: 0.23, neu: 0.697, pos: 0.074,


##Using Stanford CoreNLP for sentiment analysis 
from stanfordcorenlp import StanfordCoreNLP

nlp = StanfordCoreNLP(r'C:\nltk_data\stanford-corenlp-full-2018-02-27')

text = 'I like the service.'
output = nlp.annotate(sentence, properties={
        "annotators": "tokenize,ssplit,parse,sentiment",
        "outputFormat": "json",
        # Only split the sentence at End Of Line. We assume that this method only takes in one single sentence.
        "ssplit.eolonly": "true",
        # Setting enforceRequirements to skip some annotators and make the process faster
        "enforceRequirements": "false",
        'pipelineLanguage':'en'
    })
# Only care about the result of the first sentence because we assume we only annotate a single sentence in this method.
print(int(output['sentences'][0]['sentimentValue']))

import json 
obj  = json.loads(output)
import pprint
pprint.pprint(obj)


nlp.close()
   
    
    
    
    
 
###NLTK - Analyzing Sentence Structure- Dependency parsing and Grammer - used to find whether sentence is well formed or not 

#A “grammar” specifies which trees can represent the structure of a given text. 
#Each of these trees is called a “parse tree” for the text (or simply a “parse”). 

#In a “context free” grammar, the set of parse trees for any piece of a text 
#can depend only on that piece, and not on the rest of the text (i.e., the piece’s context). 
 
#The CFG class is used to encode context free grammars
# CFG consists of a start symbol and a set of productions(Production class)
#Start symbols are encoded using the Nonterminal 


#For example, the production <S> -> <NP> <VP> specifies 
#that an S node can be the parent of an NP node and a VP node.

#The operation of replacing the left hand side (lhs) of a production 
#with the right hand side (rhs) in a tree (tree) is known as “expanding” lhs to rhs in tree.

#Example 
from nltk import CFG
grammar = CFG.fromstring("""
S -> NP VP
PP -> P NP
NP -> Det N | NP PP
VP -> V NP | VP PP
Det -> 'a' | 'the'
N -> 'dog' | 'cat'
V -> 'chased' | 'sat'
P -> 'on' | 'in'
""")
>>> grammar
<Grammar with 14 productions>
>>> grammar.start()
S
>>> grammar.productions() 
[S -> NP VP, PP -> P NP, NP -> Det N, NP -> NP PP, VP -> V NP, VP -> VP PP,
Det -> 'a', Det -> 'the', N -> 'dog', N -> 'cat', V -> 'chased', V -> 'sat',
P -> 'on', P -> 'in']


##Recursive Descent Parsing
#Read as 'S' start consists of NP then VP, VP consists of ...
grammar1 = nltk.CFG.fromstring("""
  S -> NP VP
  VP -> V NP | V NP PP
  PP -> P NP
  V -> "saw" | "ate" | "walked"
  NP -> "John" | "Mary" | "Bob" | Det N | Det N PP
  Det -> "a" | "an" | "the" | "my"
  N -> "man" | "dog" | "cat" | "telescope" | "park"
  P -> "in" | "on" | "by" | "with"
  """)
 
#| (or) is an abbreviation for the two productions VP -> V NP and VP -> V NP PP.

#RecursiveDescentParser() takes an optional parameter trace. 
#If trace is greater than zero, then the parser will report the steps that it takes as it parses a text.


#Recursive descent parsing has three key shortcomings. 
#First, left-recursive productions like NP -> NP PP send it into an infinite loop. 
#Second, the parser wastes a lot of time considering words and structures that do not correspond to the input sentence. 
#Third, the backtracking process may discard parsed constituents that will need to be rebuilt again later. 

#Recursive descent parsing is a kind of top-down parsing. 
#Top-down parsers use a grammar to predict what the input will be, before inspecting the input


sent = "Mary saw Bob".split()
rd_parser = nltk.RecursiveDescentParser(grammar1)
for tree in rd_parser.parse(sent):  #each token(word) is fed into parse 
    print(tree)
(S (NP Mary) (VP (V saw) (NP Bob)))
 
#Meaning of the phrases  
S       sentence                the man walked 
NP      noun phrase             a dog 
VP      verb phrase             saw a park 
PP      prepositional phrase    with a telescope 
Det     determiner              the 
N       noun                    dog 
V       verb                    walked 
P       preposition             in 


#Loading grammer from file 

grammar1 = nltk.data.load('file:mygrammar.cfg')
sent = "Mary saw Bob".split()
rd_parser = nltk.RecursiveDescentParser(grammar1)
>>> for tree in rd_parser.parse(sent):
        print(tree)
 
 

##Recursion in Grammer 
#A grammar is said to be recursive if a category occurring on the left hand side of a production 
#also appears on the righthand side of a production, 

#The production Nom -> Adj Nom (where Nom is the category of nominals) involves direct recursion on the category Nom, 
#whereas indirect recursion on S arises from the combination of two productions, 
#namely S -> NP VP and VP -> V S.

 

grammar2 = nltk.CFG.fromstring("""
  S  -> NP VP
  NP -> Det Nom | PropN
  Nom -> Adj Nom | N
  VP -> V Adj | V NP | V S | V NP PP
  PP -> P NP
  PropN -> 'Buster' | 'Chatterer' | 'Joe'
  Det -> 'the' | 'a'
  N -> 'bear' | 'squirrel' | 'tree' | 'fish' | 'log'
  Adj  -> 'angry' | 'frightened' |  'little' | 'tall'
  V ->  'chased'  | 'saw' | 'said' | 'thought' | 'was' | 'put'
  P -> 'on'
  """)
 
##The Left-Corner Parser
#One of the problems with the recursive descent parser is that it goes into an infinite loop 
#when it encounters a left-recursive production. 

#A left-corner parser is a hybrid between the bottom-up and top-down approaches 

class nltk.parse.chart.BottomUpLeftCornerChartParser(grammar, **parser_args)
class nltk.parse.chart.LeftCornerChartParser(grammar, **parser_args)


##Shift-Reduce Parsing - bottom-up parsers

# a shift-reduce parser tries to find sequences of words and phrases 
#that correspond to the right hand side of a grammar production, 
#and replace them with the left-hand side, until the whole sentence is reduced to an S.


#The shift-reduce parser repeatedly pushes the next input word onto a stack -  the shift operation.
#reduce - If the top n items on the stack match the n items on the right hand side of some production, 
#then they are all popped off the stack, and the item on the left-hand side of the production is pushed on the stack. 


#NLTK provides ShiftReduceParser()
#This parser does not implement any backtracking, so it is not guaranteed to find a parse for a text, even if one exists. 
#Furthermore, it will only find at most one parse, even if more parses exist. 
#We can provide an optional trace parameter that controls how verbosely the parser reports the steps that it takes as it parses a text:

sr_parser = nltk.ShiftReduceParser(grammar1)
sent = 'Mary saw a dog'.split()
>>> for tree in sr_parser.parse(sent):
        print(tree)
  (S (NP Mary) (VP (V saw) (NP (Det a) (N dog))))
 
 



#A shift-reduce parser can reach a dead end and fail to find any parse, 
#even if the input sentence is well-formed according to the grammar. 
#When this happens, no input remains, and the stack contains items which cannot be reduced to an S. 
#The problem arises because there are choices made earlier that cannot be undone by the parser 

#There are two kinds of choices to be made by the parser: 
#(a) which reduction to do when more than one is possible 
#(b) whether to shift or reduce when either action is possible.


##nltk.parse contains two sub-modules for specialized kinds of parsing:
#check below for examples 
1. nltk.parser.chart defines chart parsing, 
   which uses dynamic programming to efficiently parse texts.
2. nltk.parser.probabilistic defines probabilistic parsing, 
   which associates a probability with each parse.




##Parse - Dependencies and Dependency Grammar
#Phrase structure grammar(eg CFG) is concerned 
#with how words and sequences of words combine to form constituents. 

#A complementary approach, dependency grammar, focusses instead 
#on how words relate to other words. 


#Dependency is a binary asymmetric relation that holds between a head and its dependents. 
#The head of a sentence is usually taken to be the tensed verb, 
#and every other word is either dependent on the sentence head, 
#or connects to it through a path of dependencies


#for sentence - 'I shot an elephant in my pajamas'

>>> groucho_dep_grammar = nltk.DependencyGrammar.fromstring("""
        'shot' -> 'I' | 'elephant' | 'in'
        'elephant' -> 'an' | 'in'
        'in' -> 'pajamas'
        'pajamas' -> 'my'
        """)
>>> print(groucho_dep_grammar)
Dependency grammar with 7 productions
  'shot' -> 'I'
  'shot' -> 'elephant'
  'shot' -> 'in'
  'elephant' -> 'an'
  'elephant' -> 'in'
  'in' -> 'pajamas'
  'pajamas' -> 'my'
 
 


#check data/nonProjectiveDependency.png
#A dependency graph is projective if, when all the words are written in linear order, 
#the edges can be drawn above the words without crossing. 
#compare -  'I shot an elephant in my pajamas'
#with 'john saw a dog yesterday which was a Yorkshire Terrier'

#This is equivalent to saying that a word and all its descendents 
#(dependents and dependents of its dependents, etc.) 
#form a contiguous sequence of words within the sentence. 

pdp = nltk.ProjectiveDependencyParser(groucho_dep_grammar)
sent = 'I shot an elephant in my pajamas'.split()
trees = pdp.parse(sent)
>>> for tree in trees:
        print(tree)
(shot I (elephant an (in (pajamas my))))
(shot I (elephant an) (in (pajamas my)))
 
 
##Understanding Verb Phrase and Dependency grammer 

#Example - for below 
a.  The squirrel was frightened. 
b.  Chatterer saw the bear. 
c.  Chatterer thought Buster was angry. 
d.  Joe put the fish on the log. 

#VP productions and their lexical heads
VP -> V Adj             was 
VP -> V NP              saw 
VP -> V S               thought 
VP -> V NP PP           put 

#'was' can occur with a following Adj, 
#'saw' can occur with a following NP, 
#'thought' can occur with a following S 
#'put' can occur with a following NP and PP. 

#The dependents Adj, NP, PP and S are called complements of the respective verbs 
#In dependency grammar term, the verbs are said to have different 'valencies'

#In a CFG, we need some way of constraining grammar productions 
#which expand VP so that verbs only co-occur with their correct complements. 

#We can do this by dividing the class of verbs into "subcategories", 
#each of which is associated with a different set of complements.


#If we introduce a new category label for transitive verbs, namely TV (for Transitive Verb), 
#then we can use it in the following productions:
VP -> TV NP
TV -> 'chased' | 'saw'

#Symbol     Meaning                 Example
IV          intransitive verb       barked 
TV          transitive verb         saw a man 
DatV        dative verb             gave a dog to a man 
SV          sentential verb         said that a dog barked 












##Scaling up 

#Grammar Development using Treebank 
#In linguistics, a treebank is a parsed text corpus that annotates syntactic or semantic sentence structure
#Most syntactic treebanks annotate variants of either phrase structure  or dependency structure 
#The Penn Treebank (PTB) project selected 2,499 stories from a three year Wall Street Journal (WSJ) collection of 98,732 stories for syntactic annotation



#The corpus module defines the treebank corpus reader, 
#which contains a 10% sample of the Penn Treebank corpus.

from nltk.corpus import treebank
t = treebank.parsed_sents('wsj_0001.mrg')
>>> print(t)
(S
  (NP-SBJ
    (NP (NNP Pierre) (NNP Vinken))
    (, ,)
    (ADJP (NP (CD 61) (NNS years)) (JJ old))
    (, ,))
  (VP
    (MD will)
    (VP
      (VB join)
      (NP (DT the) (NN board))
      (PP-CLR
        (IN as)
        (NP (DT a) (JJ nonexecutive) (NN director)))
      (NP-TMP (NNP Nov.) (CD 29))))
  (. .))
 
 

#We can use above data to help develop a grammar. 
#For example, a simple filter to find verbs that take sentential complements. 

#Assuming we already have a production of the form VP -> Vs S, 
#this information enables us to identify particular verbs that would be included in the expansion of Vs.


def filter(tree):
    child_nodes = [child.label() for child in tree  if isinstance(child, nltk.Tree)]
    return  (tree.label() == 'VP') and ('S' in child_nodes)
 
 
from nltk.corpus import treebank
>>> [subtree for tree in treebank.parsed_sents() for subtree in tree.subtrees(filter)]
[Tree('VP', [Tree('VBN', ['named']), Tree('S', [Tree('NP-SBJ', ...]), ...]), ...]
 
 
 

#As the coverage of the grammar increases and the length of the input sentences grows, 
#the number of parse trees grows rapidly. 
#In fact, it grows at an astronomical rate.

#Example 
>>> grammar = nltk.CFG.fromstring("""
    S -> NP V NP
    NP -> NP Sbar
    Sbar -> NP V
    NP -> 'fish'
    V -> 'fish'
    """)
 
 

#parse 'fish fish fish fish fish'
#for eample - from sentence  'fish that other fish fish are in the habit of fishing fish themselves'. 

tokens = ["fish"] * 5
cp = nltk.ChartParser(grammar)
>>> for tree in cp.parse(tokens):
        print(tree)
(S (NP fish) (V fish) (NP (NP fish) (Sbar (NP fish) (V fish))))
(S (NP (NP fish) (Sbar (NP fish) (V fish))) (V fish) (NP fish))
  

#As the length of this sentence goes up (3, 5, 7, ...) 
#we get the following numbers of parse trees: 1; 2; 5; 14; 42; 132; 429; 1,430; 4,862; 16,796; 58,786; 208,012; ... 
#(These are the Catalan numbers)
 
 
##Solution of above -   probabilistic parsing algorithms

#A probabilistic context free grammar (or PCFG) is a context free grammar 
#that associates a probability with each of its productions

#The probability of a parse generated by a PCFG is the product of the probabilities of the productions used to generate it.
 
grammar = nltk.PCFG.fromstring("""
    S    -> NP VP              [1.0]
    VP   -> TV NP              [0.4]
    VP   -> IV                 [0.3]
    VP   -> DatV NP NP         [0.3]
    TV   -> 'saw'              [1.0]
    IV   -> 'ate'              [1.0]
    DatV -> 'gave'             [1.0]
    NP   -> 'telescopes'       [0.8]
    NP   -> 'Jack'             [0.2]
    """)
 
>>> print(grammar)
Grammar with 9 productions (start state = S)
    S -> NP VP [1.0]
    VP -> TV NP [0.4]
    VP -> IV [0.3]
    VP -> DatV NP NP [0.3]
    TV -> 'saw' [1.0]
    IV -> 'ate' [1.0]
    DatV -> 'gave' [1.0]
    NP -> 'telescopes' [0.8]
    NP -> 'Jack' [0.2]
 
 

#can use below combinations as well 
VP -> TV NP [0.4] | IV [0.3] | DatV NP NP [0.3]


# A parser will be responsible for finding the most likely parses.
viterbi_parser = nltk.ViterbiParser(grammar)
for tree in viterbi_parser.parse(['Jack', 'saw', 'telescopes']):
    print(tree)
#OUTPUT
(S (NP Jack) (VP (TV saw) (NP telescopes))) (p=0.064)
 
 

 
 

###NLTK - Building Feature Based Grammars - extending CFG with features 

#Natural languages have an extensive range of grammatical constructions 
#which are hard to handle with the CFG based Parser 

#In order to gain more flexibility, 
#grammatical categories like S, NP and V may contain features (features is a dict with suitable keys) which can be extracted 
#Features could be anything important eg extracting the last letter of a word or pos-tag etc 
 

##Example - (* ungrammatical)- singular or plural
 
(1)  
a.  this dog 
b.  *these dog 
(2)  
a.  these dogs 
b.  *this dogs 

#CFG for 'this dog runs'
S   ->   NP VP
NP  ->   Det N
VP  ->   V

Det  ->  'this'
N    ->  'dog'
V    ->  'runs'

#To include plural- Note every line is replicated for singular and  plural
S -> NP_SG VP_SG
S -> NP_PL VP_PL
NP_SG -> Det_SG N_SG
NP_PL -> Det_PL N_PL
VP_SG -> V_SG
VP_PL -> V_PL

Det_SG -> 'this'
Det_PL -> 'these'
N_SG -> 'dog'
N_PL -> 'dogs'
V_SG -> 'runs'
V_PL -> 'run'

 
##SOLUTION - To represent compactly - Use Attributes and Constraints on Non Terminal 
 
 
#Example - category N has a (grammatical) feature called NUM (short for 'number') 
#and that the value of this feature is pl (short for 'plural')
#NUM and pl are example only, we can use any string there 
N[NUM=pl]



##Variables over feature values, - called constraints
N[NUM=?n]       #where ?n is a variable, either sg or pl
#it can be instantiated(by extracting feature) either to sg or pl
#Note number of constraints can be many , separeted by ',' eg VP[TENSE=?t, NUM=?n]

#S   ->   NP VP
#NP  ->   Det N
#VP  ->   V
#Note S is same for all ?n  
#actual instance for variable  is starting from Det[NUM=sg]
S -> NP[NUM=?n] VP[NUM=?n]
NP[NUM=?n] -> Det[NUM=?n] N[NUM=?n]
VP[NUM=?n] -> V[NUM=?n]

Det[NUM=sg] -> 'this'
Det[NUM=pl] -> 'these'

N[NUM=sg] -> 'dog'
N[NUM=pl] -> 'dogs'
V[NUM=sg] -> 'runs'
V[NUM=pl] -> 'run'
 

#S -> NP[NUM=?n] VP[NUM=?n] creates below 
#ie NUM value is sg 
NP[NUM=sg]
    Det[NUM=sg] -> 'this'
    N[NUM=sg] -> 'dog'
 
#ie NUM value is pl
NP[NUM=pl]
    Det[NUM=pl] -> 'these'
    N[NUM=pl] -> 'dogs'
 
#Production VP[NUM=?n] -> V[NUM=?n] creates below 
S    
    NP[NUM=pl]
        Det[NUM=pl] -> 'these'
        N[NUM=pl] -> 'dogs'
    VP[NUM=pl]
        V[NUM=pl] -> 'run'

        
#We could increase the production  of determiners    to include more values 
Det[NUM=sg] -> 'the' | 'some' | 'any'
Det[NUM=pl] -> 'the' | 'some' | 'any'

#OR 
Det[NUM=?n] -> 'the' | 'some' | 'any'
#OR 
Det -> 'the' | 'some' | 'several'

##Example feature CFG 
#Note '% start S' denotes the start tag as S
>>> nltk.data.show_cfg('grammars/book_grammars/feat0.fcfg')
% start S
# Grammar Productions
# S expansion productions
S -> NP[NUM=?n] VP[NUM=?n]
# NP expansion productions, extract value of NUM 
NP[NUM=?n] -> N[NUM=?n]
NP[NUM=?n] -> PropN[NUM=?n]
NP[NUM=?n] -> Det[NUM=?n] N[NUM=?n]
NP[NUM=pl] -> N[NUM=pl]
# VP expansion productions, extract value of TENSE and NUM 
VP[TENSE=?t, NUM=?n] -> IV[TENSE=?t, NUM=?n]
VP[TENSE=?t, NUM=?n] -> TV[TENSE=?t, NUM=?n] NP
# Lexical Productions
Det[NUM=sg] -> 'this' | 'every'
Det[NUM=pl] -> 'these' | 'all'
Det -> 'the' | 'some' | 'several'
PropN[NUM=sg]-> 'Kim' | 'Jody'
N[NUM=sg] -> 'dog' | 'girl' | 'car' | 'child'
N[NUM=pl] -> 'dogs' | 'girls' | 'cars' | 'children'
IV[TENSE=pres,  NUM=sg] -> 'disappears' | 'walks'
TV[TENSE=pres, NUM=sg] -> 'sees' | 'likes'
IV[TENSE=pres,  NUM=pl] -> 'disappear' | 'walk'
TV[TENSE=pres, NUM=pl] -> 'see' | 'like'
IV[TENSE=past] -> 'disappeared' | 'walked'
TV[TENSE=past] -> 'saw' | 'liked'
 
#Reference 
nltk.parse.util.load_parser(grammar_url, trace=0, parser=None, chart_class=None, beam_size=0, **load_args)
    Load a grammar from a file, and build a parser based on that grammar. 
    The following grammar formats are currently supported based on extension 
            'cfg' (CFGs: CFG)
            'pcfg' (probabilistic CFGs: PCFG)
            'fcfg' (feature-based CFGs: FeatureGrammar) 
        grammar_url (str) – A URL specifying where the grammar is located. 
                            The default protocol is "nltk:", which searches for the file in the the NLTK data package.
        trace (int) – The level of tracing that should be used when parsing a text. 0 will generate no tracing output; and higher numbers will produce more verbose tracing output.
        parser – The class used for parsing; should be ChartParser or a subclass. If None, the class depends on the grammar format.
        chart_class – The class used for storing the chart; should be Chart or a subclass. Only used for CFGs and feature CFGs. If None, the chart class depends on the grammar format.
        beam_size (int) – The maximum length for the parser’s edge queue. Only used for probabilistic CFGs.
        load_args – Keyword parameters used when loading the grammar. See data.load for more information.

        
#Usage 
>>> tokens = 'Kim likes children'.split()
>>> from nltk import load_parser 
>>> cp = load_parser('grammars/book_grammars/feat0.fcfg', trace=2)  #Loading parser and CFG is created 
>>> for tree in cp.parse(tokens):
        print(tree)

|.Kim .like.chil.|
Leaf Init Rule:
|[----]    .    .| [0:1] 'Kim'
|.    [----]    .| [1:2] 'likes'
|.    .    [----]| [2:3] 'children'
Feature Bottom Up Predict Combine Rule:
|[----]    .    .| [0:1] PropN[NUM='sg'] -> 'Kim' *
Feature Bottom Up Predict Combine Rule:
|[----]    .    .| [0:1] NP[NUM='sg'] -> PropN[NUM='sg'] *
Feature Bottom Up Predict Combine Rule:
|[---->    .    .| [0:1] S[] -> NP[NUM=?n] * VP[NUM=?n] {?n: 'sg'}  ##Feature struct, ?n extracted to be 'sg'
Feature Bottom Up Predict Combine Rule:
|.    [----]    .| [1:2] TV[NUM='sg', TENSE='pres'] -> 'likes' *
Feature Bottom Up Predict Combine Rule:
|.    [---->    .| [1:2] VP[NUM=?n, TENSE=?t] -> TV[NUM=?n, TENSE=?t] * NP[] {?n: 'sg', ?t: 'pres'} ##Feature struct, ?n extracted to be 'sg' and ?t extracted to be 'pres'
Feature Bottom Up Predict Combine Rule:
|.    .    [----]| [2:3] N[NUM='pl'] -> 'children' *
Feature Bottom Up Predict Combine Rule:
|.    .    [----]| [2:3] NP[NUM='pl'] -> N[NUM='pl'] *
Feature Bottom Up Predict Combine Rule:
|.    .    [---->| [2:3] S[] -> NP[NUM=?n] * VP[NUM=?n] {?n: 'pl'}
Feature Single Edge Fundamental Rule:
|.    [---------]| [1:3] VP[NUM='sg', TENSE='pres'] -> TV[NUM='sg', TENSE='pres'] NP[] *
Feature Single Edge Fundamental Rule:
|[==============]| [0:3] S[] -> NP[NUM='sg'] VP[NUM='sg'] *
(S[]
  (NP[NUM='sg'] (PropN[NUM='sg'] Kim))
  (VP[NUM='sg', TENSE='pres']
    (TV[NUM='sg', TENSE='pres'] likes)
    (NP[NUM='pl'] (N[NUM='pl'] children))))
 
#Understanding parsing, User can use value of NUM, TENSE for further logic 
>>> trees = list(cp2.parse(tokens)) 
>>> type(trees)  #list of parse trees, here it is one 
<class 'list'>
>>> type(trees[0])
<class 'nltk.tree.Tree'>
>>> print(trees[0])          #Tree structure 
(S[]
  (NP[NUM='sg'] (PropN[NUM='sg'] Kim))
  (VP[NUM='sg', TENSE='pres']
    (TV[NUM='sg', TENSE='pres'] likes)
    (NP[NUM='pl'] (N[NUM='pl'] children))))
    
>>> type(trees[0].label())   #label of Parse tree is Feature struct, a dict kind object 
<class 'nltk.grammar.FeatStructNonterminal'>
>>> trees[0].label()
S[]
>>> trees[0]
Tree(S[], [Tree(NP[NUM='sg'], [Tree(PropN[NUM='sg'], ['Kim'])]), Tree(
VP[NUM='sg', TENSE='pres'], [Tree(TV[NUM='sg', TENSE='pres'], ['likes'
]), Tree(NP[NUM='pl'], [Tree(N[NUM='pl'], ['children'])])])])
 
#To get the value of NUM which is extracted in NP as a featuredict 
>>> trees[0][0] #first children 
Tree(NP[NUM='sg'], [Tree(PropN[NUM='sg'], ['Kim'])])
>>> type(trees[0][0].label())
<class 'nltk.grammar.FeatStructNonterminal'>
>>> trees[0][0].label().keys()
dict_keys([*type*, 'NUM'])
>>> trees[0][0].label()
NP[NUM='sg']
>>> trees[0][0].label()['NUM']
'sg'
#similarly value of TENSE 
>>> trees[0][1].label()
VP[NUM='sg', TENSE='pres']
>>> trees[0][1].label()['TENSE']
'pres'


##Feature grammer - Terminology

#feature values like sg and pl called atomic(can not be broken)

##boolean feature value eg if AUX is true, then production 
V[TENSE=pres, AUX=+] -> 'can'
#OR, instead of AUX=+ or AUX=-, we use +AUX and -AUX

V[TENSE=pres, +AUX] -> 'can'
V[TENSE=pres, +AUX] -> 'may'

V[TENSE=pres, -AUX] -> 'walks'
V[TENSE=pres, -AUX] -> 'likes'

 

##features may take values that are themselves feature structures. 

#Grammer example - AGR having complex structure 

S                    -> NP[AGR=?n] VP[AGR=?n]
NP[AGR=?n]           -> PropN[AGR=?n]
VP[TENSE=?t, AGR=?n] -> Cop[TENSE=?t, AGR=?n] Adj

Cop[TENSE=pres,  AGR=[NUM=sg, PER=3]] -> 'is'
PropN[AGR=[NUM=sg, PER=3]]            -> 'Kim'
Adj                                   -> 'happy'


#Example - we can group together agreement features (e.g., person, number and gender) 
#as a distinguished part of a category, grouped together as  AGR. 
#AGR has a complex value , called attribute value matrix (AVM) 

[POS = N           ]
[                  ]
[AGR = [PER = 3   ]]
[      [NUM = pl  ]]
[      [GND = fem ]]

 
#Note above is equivalent to 

[AGR = [NUM = pl  ]]
[      [PER = 3   ]]
[      [GND = fem ]]
[                  ]
[POS = N           ]

 

 

##Processing Feature Structures - FeatStruct() - a kind of dictionary

#Atomic feature values can be strings or integers.
>>> fs1 = nltk.FeatStruct(TENSE='past', NUM='sg')
>>> print(fs1)
[ NUM   = 'sg'   ]
[ TENSE = 'past' ]
 
#get/set 
>>> fs1 = nltk.FeatStruct(PER=3, NUM='pl', GND='fem')
>>> print(fs1['GND'])
fem
>>> fs1['CASE'] = 'acc'
 
 
#With complex values 

>>> fs2 = nltk.FeatStruct(POS='N', AGR=fs1)
>>> print(fs2)
[       [ CASE = 'acc' ] ]
[ AGR = [ GND  = 'fem' ] ]
[       [ NUM  = 'pl'  ] ]
[       [ PER  = 3     ] ]
[                        ]
[ POS = 'N'              ]
>>> print(fs2['AGR'])
[ CASE = 'acc' ]
[ GND  = 'fem' ]
[ NUM  = 'pl'  ]
[ PER  = 3     ]
>>> print(fs2['AGR']['PER'])
3
 
 
#An alternative method of specifying feature structures 
#use a bracketed string consisting of feature-value pairs in the format feature=value, 
#where values may themselves be feature structures

>>> print(nltk.FeatStruct("[POS='N', AGR=[PER=3, NUM='pl', GND='fem']]"))
[       [ GND = 'fem' ] ]
[ AGR = [ NUM = 'pl'  ] ]
[       [ PER = 3     ] ]
[                       ]
[ POS = 'N'             ]
 
 
 
 
##It is often helpful to view feature structures as graphs- directed acyclic graphs (DAGs).

#The feature names appear as labels on the directed arcs, 
#and feature values appear as labels on the nodes that are pointed to by the arcs.
#Note feature values can be complex ie node may emit many arcs 

#A feature path is a sequence of arcs that can be followed from the root node. 
#We will represent paths as tuples or arcs (arc=feature name)

#check data/dag_as_feature02.png
#Example -('ADDRESS', 'STREET') is a feature path whose value is the node labeled 'rue Pascal'.


#DAGs can have structure sharing or reentrancy.(ie two path arrow meet at a node  from where another sub DAG is emited)
#When two paths have the same value, they are said to be equivalent.

#check data/dag_as_feature03.png
#Example - the value of the path ('ADDRESS') is identical to the value of the path ('SPOUSE', 'ADDRESS')

#In order to indicate reentrancy,
#prefix the first occurrence of a shared feature structure with an integer in parentheses eg (1)
#Any later reference to that structure will use the notation ->(1)



>>> print(nltk.FeatStruct("""[NAME='Lee', ADDRESS=(1)[NUMBER=74, STREET='rue Pascal'],
                        SPOUSE=[NAME='Kim', ADDRESS->(1)]]"""))
[ ADDRESS = (1) [ NUMBER = 74           ] ]
[               [ STREET = 'rue Pascal' ] ]
[                                         ]
[ NAME    = 'Lee'                         ]
[                                         ]
[ SPOUSE  = [ ADDRESS -> (1)  ]           ]
[           [ NAME    = 'Kim' ]           ]
 
 

#The bracketed integer is called a tag or a coindex. 
#The choice of integer is not significant. 
#There can be any number of tags within a single feature structure.
>>> print(nltk.FeatStruct("[A='a', B=(1)[C='c'], D->(1), E->(1)]"))
[ A = 'a'             ]
[                     ]
[ B = (1) [ C = 'c' ] ]
[                     ]
[ D -> (1)            ]
[ E -> (1)            ]
 
 

##Feature - Subsumption and Unification

##Note a has less information than b and b has less info on c  
a.  
[NUMBER = 74]

 
b.  
[NUMBER = 74          ]
[STREET = 'rue Pascal']

  
c.  
[NUMBER = 74          ]
[STREET = 'rue Pascal']
[CITY = 'Paris'       ]

 
#This ordering is called subsumption; 
#FS0 subsumes FS1 if all the information contained in FS0 is also contained in FS1. 
#use the symbol 'SUB' (subset notation) to represent subsumption.
#if FS0 'SUB' FS1, then FS1 must have all the paths and reentrancies of FS0
 
#Merging information from two feature structures is called unification 
#FS0 UNI FS1 (UNI- union notation)
#supported by the unify() method.
#Note - If FS0 SUB FS1, then FS0 UNI FS1 = FS1 
>>> fs1 = nltk.FeatStruct(NUMBER=74, STREET='rue Pascal')
>>> fs2 = nltk.FeatStruct(CITY='Paris')
>>> print(fs1.unify(fs2))
[ CITY   = 'Paris'      ]
[ NUMBER = 74           ]
[ STREET = 'rue Pascal' ]
 
 

#Unification is symmetric, so FS0 UNI FS1 = FS1 UNI FS0. 

>>> print(fs2.unify(fs1))
[ CITY   = 'Paris'      ]
[ NUMBER = 74           ]
[ STREET = 'rue Pascal' ]
 
 
#If we unify two feature structures which stand in the subsumption relationship, 
#then the result of unification is the most informative of the two


#Unification between FS0 and FS1 will fail 
#if the two feature structures share a path PHI, 
#but the value of PHI in FS0 is a distinct atom from the value of PHI in FS1. 

#This is implemented by setting the result of unification to be None.
>>> fs0 = nltk.FeatStruct(A='a')
>>> fs1 = nltk.FeatStruct(A='b')
>>> fs2 = fs0.unify(fs1)
>>> print(fs2)
None
 
 

##How unification interacts with structure-sharing

>>> fs0 = nltk.FeatStruct("""[NAME=Lee, ADDRESS=[NUMBER=74,STREET='rue Pascal'],
                              SPOUSE= [NAME=Kim,ADDRESS=[NUMBER=74,STREET='rue Pascal']]]""")
>>> print(fs0)
[ ADDRESS = [ NUMBER = 74           ]               ]
[           [ STREET = 'rue Pascal' ]               ]
[                                                   ]
[ NAME    = 'Lee'                                   ]
[                                                   ]
[           [ ADDRESS = [ NUMBER = 74           ] ] ]
[ SPOUSE  = [           [ STREET = 'rue Pascal' ] ] ]
[           [                                     ] ]
[           [ NAME    = 'Kim'                     ] ]
 
 
#Add CITY to SPOUSE 
>>> fs1 = nltk.FeatStruct("[SPOUSE = [ADDRESS = [CITY = Paris]]]")
>>> print(fs1.unify(fs0))
[ ADDRESS = [ NUMBER = 74           ]               ]
[           [ STREET = 'rue Pascal' ]               ]
[                                                   ]
[ NAME    = 'Lee'                                   ]
[                                                   ]
[           [           [ CITY   = 'Paris'      ] ] ]
[           [ ADDRESS = [ NUMBER = 74           ] ] ]
[ SPOUSE  = [           [ STREET = 'rue Pascal' ] ] ]
[           [                                     ] ]
[           [ NAME    = 'Kim'                     ] ]
 
 
#Whereas with structure sharing version


>>> fs2 = nltk.FeatStruct("""[NAME=Lee, ADDRESS=(1)[NUMBER=74, STREET='rue Pascal'],
                              SPOUSE=[NAME=Kim, ADDRESS->(1)]]""")
>>> print(fs1.unify(fs2))
[               [ CITY   = 'Paris'      ] ]
[ ADDRESS = (1) [ NUMBER = 74           ] ]
[               [ STREET = 'rue Pascal' ] ]
[                                         ]
[ NAME    = 'Lee'                         ]
[                                         ]
[ SPOUSE  = [ ADDRESS -> (1)  ]           ]
[           [ NAME    = 'Kim' ]           ]
 
 

##structure sharing can also be stated using variables such as ?x.
>>> fs1 = nltk.FeatStruct("[ADDRESS1=[NUMBER=74, STREET='rue Pascal']]")
>>> fs2 = nltk.FeatStruct("[ADDRESS1=?x, ADDRESS2=?x]")
>>> print(fs2)
[ ADDRESS1 = ?x ]
[ ADDRESS2 = ?x ]
>>> print(fs2.unify(fs1))
[ ADDRESS1 = (1) [ NUMBER = 74           ] ]
[                [ STREET = 'rue Pascal' ] ]
[                                          ]
[ ADDRESS2 -> (1)                          ]
 
 

##Feature - Subcategorization

#For example -category labels to represent different kinds of verb, 
#used the labels IV and TV for intransitive and transitive verbs respectively
VP -> IV
VP -> TV NP

 
#Can we replace category labels such as TV and IV by V along with a feature 
#that tells us whether the verb combines with a following NP object 
#or whether it can occur without any complement?

#Use Generalized Phrase Structure Grammar (GPSG)
#where lexical categories to bear a SUBCAT 
#which tells us what subcategorization class the item belongs to. 

#values for SUBCAT can be intrans, trans and clause

VP[TENSE=?t, NUM=?n] -> V[SUBCAT=intrans, TENSE=?t, NUM=?n]
VP[TENSE=?t, NUM=?n] -> V[SUBCAT=trans, TENSE=?t, NUM=?n] NP
VP[TENSE=?t, NUM=?n] -> V[SUBCAT=clause, TENSE=?t, NUM=?n] SBar

V[SUBCAT=intrans, TENSE=pres, NUM=sg] -> 'disappears' | 'walks'
V[SUBCAT=trans, TENSE=pres, NUM=sg] -> 'sees' | 'likes'
V[SUBCAT=clause, TENSE=pres, NUM=sg] -> 'says' | 'claims'

V[SUBCAT=intrans, TENSE=pres, NUM=pl] -> 'disappear' | 'walk'
V[SUBCAT=trans, TENSE=pres, NUM=pl] -> 'see' | 'like'
V[SUBCAT=clause, TENSE=pres, NUM=pl] -> 'say' | 'claim'

V[SUBCAT=intrans, TENSE=past, NUM=?n] -> 'disappeared' | 'walked'
V[SUBCAT=trans, TENSE=past, NUM=?n] -> 'saw' | 'liked'
V[SUBCAT=clause, TENSE=past, NUM=?n] -> 'said' | 'claimed'
#SBar - is a label for subordinate clauses
SBar -> Comp S
Comp -> 'that'


#An alternative treatment of subcategorization - categorial grammar
#is represented in feature based frameworks such as PATR and Head-driven Phrase Structure Grammar. 

#Rather than using SUBCAT values as a way of indexing productions, 
#the SUBCAT value directly encodes the valency of a head 
#(the list of arguments that it can combine with). 

#For example, a verb like 'put' that takes NP and PP complements 
#(eg, put the book on the table) might be represented 
 
V[SUBCAT=<NP, NP, PP>]

#This says that the verb can combine with three arguments. 
#The leftmost element in the list is the subject NP, 
#while everything else — an NP followed by a PP in this case 
#— comprises the subcategorized for complements. 

#When a verb like 'put' is combined with appropriate complements, 
#the requirements which are specified in the SUBCAT are discharged, 
#and only a subject NP is needed. 

#This category, which corresponds to what is traditionally thought of as VP, might be represented 
V[SUBCAT=<NP>]

 

#a sentence is a kind of verbal category that has no requirements for further arguments, 
#and hence has a SUBCAT whose value is the empty list

#Note :
#expressions of category V are heads of phrases of category VP. 
#Ns are heads of NPs, 
#As (i.e., adjectives) are heads of APs, 
#Ps (i.e., prepositions) are heads of PPs. 
#Not all phrases have heads — 
#for example,  coordinate phrases (e.g., the book and the bell) lack heads 



##X-bar Syntax - phrasal level. 

#It is usual to recognize three levels. 
#If N represents the lexical level, 
#then N' represents the next level up, corresponding to category Nom, 
#while N'' represents the phrasal level, corresponding to the category NP. 

#N' and N'' are called (phrasal) projections of N
#N'' is the maximal projection
#N is called the zero projection

N"
    Det
        a
    N'
        N
            Student
        P"
            of French 
            
#equivalent to 
NP
    Det
        a
    Norm
        N
            Student
        PP
            of French 
    

#Using X-bar syntax, we mean that all constituents share a structural similarity. 
#Using X as a variable over N, V, A and P, 
#directly subcategorized complements of a lexical head X are always placed as siblings of the head, 
#whereas adjuncts are placed as siblings of the intermediate category, X'. 

#in NLTK
S -> N[BAR=2] V[BAR=2]
N[BAR=2] -> Det N[BAR=1]
N[BAR=1] -> N[BAR=1] P[BAR=2]
N[BAR=1] -> N[BAR=0] P[BAR=2]
N[BAR=1] -> N[BAR=0]XS

 

##Auxiliary Verbs and Inversion

#Inverted clauses — where the order of subject and verb is switched 
#— occur in English interrogatives and also after 'negative' adverbs

 
a.  Do you like children? 
b.  Can Jody walk? 

 

a.  Rarely do you see Kim. 
b.  Never have I seen this dog. 

 
#we cannot place just any verb in pre-subject position:
a.  *Like you children? 
b.  *Walks Jody? 

a.  *Rarely see you Kim. 
b.  *Never saw I this dog. 

 

#Verbs that can be positioned initially in inverted clauses belong to the class known as auxiliaries, 
#and as well as do, can and have include be, will and shall. 

#One way of capturing such structures is with the following production:
#a clause marked as [+INV] consists of an auxiliary verb followed by a VP.
S[+INV] -> V[+AUX] NP VP

 
##Feature grammer - Slash categories

#Note - there is no upper bound on the distance between filler and gap. 
#This fact can be easily illustrated with constructions involving sentential complements, 
 
a.  Who do you like __? 
b.  Who do you claim that you like __? 
c.  Who do you claim that Jody says that you like __? 

#ie - an unbounded dependency construction 
#a filler-gap dependency where there is no upper bound on the distance between filler and gap.

#to handle  use slash categories - in Generalized Phrase Structure Grammar. 
#A slash category has the form Y/XP; 
#a phrase of category Y that is missing a sub-constituent of category XP. 

#For example, S/NP is an S that is missing an NP.
#S/NP is reducible to S[SLASH=NP]
S
    NP[+WH]
        who
    S[+INV]/NP
        V[+AUX]
            do
        NP[-WH]
            you
        VP/NP
            V[-AUX, SUBCAT=trans]
                like 
            NP/NP
    
#The top part of the tree introduces the filler 'who' 
#(treated as an expression of category NP[+wh]) 
#together with a corresponding gap-containing constituent S/NP. 

#The gap information is then "percolated" down the tree via the VP/NP category, 
#until it reaches the category NP/NP (empty string)


#Example 
>>> nltk.data.show_cfg('grammars/book_grammars/feat1.fcfg')
% start S
# Grammar Productions
S[-INV] -> NP VP
S[-INV]/?x -> NP VP/?x
S[-INV] -> NP S/NP
S[-INV] -> Adv[+NEG] S[+INV]
S[+INV] -> V[+AUX] NP VP
S[+INV]/?x -> V[+AUX] NP VP/?x
SBar -> Comp S[-INV]
SBar/?x -> Comp S[-INV]/?x
VP -> V[SUBCAT=intrans, -AUX]
VP -> V[SUBCAT=trans, -AUX] NP
VP/?x -> V[SUBCAT=trans, -AUX] NP/?x
VP -> V[SUBCAT=clause, -AUX] SBar
VP/?x -> V[SUBCAT=clause, -AUX] SBar/?x
VP -> V[+AUX] VP
VP/?x -> V[+AUX] VP/?x
# Lexical Productions
V[SUBCAT=intrans, -AUX] -> 'walk' | 'sing'
V[SUBCAT=trans, -AUX] -> 'see' | 'like'
V[SUBCAT=clause, -AUX] -> 'say' | 'claim'
V[+AUX] -> 'do' | 'can'
NP[-WH] -> 'you' | 'cats'
NP[+WH] -> 'who'
Adv[+NEG] -> 'rarely' | 'never'
NP/NP ->
Comp -> 'that' 
 
#Above contains one "gap-introduction" production, namely S[-INV] -> NP S/NP. 
#In order to percolate the slash feature correctly, 
#we need to add slashes with variable values to both sides of the arrow in productions 
#that expand S, VP and NP. 

#For example, VP/?x -> V SBar/?x is the slashed version of VP -> V SBar 
#and says that a slash value can be specified on the VP parent of a constituent 
#if the same value is also specified on the SBar child. 

#Finally, NP/NP -> allows the slash information on NP to be discharged as the empty string. 

#Example - Parsing - who do you claim that you like

>>> tokens = 'who do you claim that you like'.split()
>>> from nltk import load_parser
>>> cp = load_parser('grammars/book_grammars/feat1.fcfg')
>>> for tree in cp.parse(tokens):
        print(tree)
(S[-INV]
  (NP[+WH] who)
  (S[+INV]/NP[]
    (V[+AUX] do)
    (NP[-WH] you)
    (VP[]/NP[]
      (V[-AUX, SUBCAT='clause'] claim)
      (SBar[]/NP[]
        (Comp[] that)
        (S[-INV]/NP[]
          (NP[-WH] you)
          (VP[]/NP[] (V[-AUX, SUBCAT='trans'] like) (NP[]/NP[] )))))))
 
 
 
#This grammar  will also allow us to parse sentences without gaps:
>>> tokens = 'you claim that you like cats'.split()
>>> for tree in cp.parse(tokens):
        print(tree)
(S[-INV]
  (NP[-WH] you)
  (VP[]
    (V[-AUX, SUBCAT='clause'] claim)
    (SBar[]
      (Comp[] that)
      (S[-INV]
        (NP[-WH] you)
        (VP[] (V[-AUX, SUBCAT='trans'] like) (NP[-WH] cats))))))
 
 

#In addition, it admits inverted sentences which do not involve wh constructions:
>>> tokens = 'rarely do you sing'.split()
>>> for tree in cp.parse(tokens):
        print(tree)
(S[-INV]
  (Adv[+NEG] rarely)
  (S[+INV]
    (V[+AUX] do)
    (NP[-WH] you)
    (VP[] (V[-AUX, SUBCAT='intrans'] sing))))
 
 
 
 
 
 
 
 
 
 

###NLTK - Analyzing the Meaning of Sentences - Final Step 
 
#Example - Querying a Database
 
#If following NL question is asked 
Q.  Which country is Athens in? 
A.  Greece. 

 
#Given table , city_table: A table of cities, countries and populations
City        Country     Population
athens      greece      1368 
bangkok     thailand    1178 
barcelona   spain       1280 
berlin      east_germany 3481 
birmingham united_kingdom 1112 

#In SQL,  
SELECT Country FROM city_table WHERE City = 'athens' 

#In FCFG, convert natural languange(NL) question into QL query
#Each phrase structure rule is supplemented 
#with a recipe for constructing a value for the feature sem. 
#in each case, we use the string concatenation operation + to splice 
#the values for the child constituents to make a value for the parent constituent.

>>> nltk.data.show_cfg('grammars/book_grammars/sql0.fcfg')
#In one line, same variable(or LHS,RHS) means 'same meaning'
#in different line, same variable of earlier lines means different variables/meaning
% start S
S[SEM=(?np + WHERE + ?vp)] -> NP[SEM=?np] VP[SEM=?vp]     #1 
VP[SEM=(?v + ?pp)] -> IV[SEM=?v] PP[SEM=?pp]              #2 
VP[SEM=(?v + ?ap)] -> IV[SEM=?v] AP[SEM=?ap]              #3 
NP[SEM=(?det + ?n)] -> Det[SEM=?det] N[SEM=?n]            #4 
PP[SEM=(?p + ?np)] -> P[SEM=?p] NP[SEM=?np]               #5 
AP[SEM=?pp] -> A[SEM=?a] PP[SEM=?pp]                      #6 
NP[SEM='Country="greece"'] -> 'Greece'                    #7 
NP[SEM='Country="china"'] -> 'China'                      #8 
Det[SEM='SELECT'] -> 'Which' | 'What'                     #9 
N[SEM='City FROM city_table'] -> 'cities'                 #10
IV[SEM=''] -> 'are'                                       #11
A[SEM=''] -> 'located'                                    #12
P[SEM=''] -> 'in'                                         #13
#Check 
>>> cp = load_parser('grammars/book_grammars/sql0.fcfg',trace=1)
>>> cp.parse(query.split())
|.W.c.a.l.i.C.|
|[-] . . . . .| [0:1] 'What'
|. [-] . . . .| [1:2] 'cities'
|. . [-] . . .| [2:3] 'are'
|. . . [-] . .| [3:4] 'located'
|. . . . [-] .| [4:5] 'in'
|. . . . . [-]| [5:6] 'China'
|[-] . . . . .| [0:1] Det[SEM='SELECT'] -> 'What' *  #9, then check which RHS contains Det, ie 4
|[-> . . . . .| [0:1] NP[SEM=(?det+?n)] -> Det[SEM=?det] * N[SEM=?n] {?det: 'SELECT'} #4, ?det is determined , undetermined is N[SEM=?n], parse more 
|. [-] . . . .| [1:2] N[SEM='City FROM city_table'] -> 'cities' * #10, got 'cities', ?n = 'City FROM city_table'
|[---] . . . .| [0:2] NP[SEM=(SELECT, City FROM city_table)] -> Det[SEM='SELECT'] N[SEM='City FROM city_table'] * #Fully resolved now #4 , check which RHS got NP[..]
|[---> . . . .| [0:2] S[SEM=(?np+WHERE+?vp)] -> NP[SEM=?np] * VP[SEM=?vp] {?np: (SELECT, City FROM city_table)} #1, above line ?n is now ?np, hence ?np determined , determine ?vp 
|. . [-] . . .| [2:3] IV[SEM=''] -> 'are' * #11, process next work and proceed similarly to get value of ?vp of above line 
|. . [-> . . .| [2:3] VP[SEM=(?v+?pp)] -> IV[SEM=?v] * PP[SEM=?pp] {?v: ''} #2, two VP rules, check each rule seperately
|. . [-> . . .| [2:3] VP[SEM=(?v+?ap)] -> IV[SEM=?v] * AP[SEM=?ap] {?v: ''} #3
|. . . [-] . .| [3:4] A[SEM=''] -> 'located' *
|. . . [-> . .| [3:4] AP[SEM=?pp] -> A[SEM=?a] * PP[SEM=?pp] {?a: ''}
|. . . . [-] .| [4:5] P[SEM=''] -> 'in' *
|. . . . [-> .| [4:5] PP[SEM=(?p+?np)] -> P[SEM=?p] * NP[SEM=?np] {?p: ''}
|. . . . . [-]| [5:6] NP[SEM='Country="china"'] -> 'China' *
|. . . . . [->| [5:6] S[SEM=(?np+WHERE+?vp)] -> NP[SEM=?np] * VP[SEM=?vp] {?np: 'Country="china"'}
|. . . . [---]| [4:6] PP[SEM=(, Country="china")] -> P[SEM=''] NP[SEM='Country="china"'] *
|. . . [-----]| [3:6] AP[SEM=(, Country="china")] -> A[SEM=''] PP[SEM=(, Country="china")] *
|. . [-------]| [2:6] VP[SEM=(, , Country="china")] -> IV[SEM=''] AP[SEM=(, Country="china")] *
|[===========]| [0:6] S[SEM=(SELECT, City FROM city_table, WHERE, , ,Country="china")] -> NP[SEM=(SELECT, City FROM city_table)] VP[SEM=(,, Country="china")] *
 
#Full code 
>>> from nltk import load_parser
>>> cp = load_parser('grammars/book_grammars/sql0.fcfg',trace=1)
>>> query = 'What cities are located in China'
>>> trees = list(cp.parse(query.split()))
>>> print(trees[0])
(S[SEM=(SELECT, City FROM city_table, WHERE, , , Country="china")]  #(?np + WHERE + ?vp) = (?det + ?n) + WHERE + (?v +( (?p + ?np) ))
  (NP[SEM=(SELECT, City FROM city_table)]    #?np = ?det + ?n 
    (Det[SEM='SELECT'] What)                 #?det = SELECT 
    (N[SEM='City FROM city_table'] cities))  #?n = City FROM city_table'
  (VP[SEM=(, , Country="china")]   #?vp = ?v + ?pp or ?v + ?ap, final tree is ?v + ?ap
    (IV[SEM=''] are)               #?v = '' 
    (AP[SEM=(, Country="china")]   #?ap = ?pp = ?pp, Note ?a is discarded
      (A[SEM=''] located)          #?a = ''
      (PP[SEM=(, Country="china")] #?pp = ?p + ?np 
        (P[SEM=''] in)             #?p = ''
        (NP[SEM='Country="china"'] China)))))  #?np = Country="china"'
>>> answer = trees[0].label()['SEM']
>>> answer = [s for s in answer if s]
>>> q = ' '.join(answer)
>>> print(q)
SELECT City FROM city_table WHERE Country="china"
#get answers 
>>> from nltk.sem import chat80
>>> rows = chat80.sql_query('corpora/city_database/city.db', q)
>>> for r in rows: print(r[0], end=" ") 
canton chungking dairen harbin kowloon mukden peking shanghai sian tientsin
 
#Chat-80 was a natural language system which allowed the user 
#to interrogate a Prolog knowledge base in the domain of world geography
#Chat-80 relations are like tables in a relational database
#http://www.nltk.org/howto/chat80.html

>>> from nltk.sem import chat80
>>> print(chat80.items) 
('borders', 'circle_of_lat', 'circle_of_long', 'city', ...)



##Propositional Logic

#A logical language is designed to make reasoning formally explicit.
#For example 
 
[Klaus chased Evi] and [Evi ran away]. 

#can be translated into 
f & ?

#whereas 
f = Klaus chased Evi
? = Evi ran away

>>> nltk.boolean_ops()
negation            -
conjunction         &
disjunction         |
implication         ->
equivalence         <->
 

#Boolean Operator                           Truth Conditions
negation (it is not the case that ...)      -f is true in s iff f is false in s 
conjunction (and)                           (f & ?) is true in s iff f is true in s and ? is true in s 
disjunction (or)                            (f | ?) is true in s iff f is true in s or ? is true in s 
implication (if ..., then ...)              (f -> ?) is true in s iff f is false in s or ? is true in s 
equivalence/xor (if and only if)            (f <-> ?) is true in s iff f and ? are both true in s or both false in s 

#For Example 
#A formula of the form (P -> Q) is only false when P is true and Q is false. 
#If P is false  and Q is true  then P-> Q will come out true
# p -> Q is same as -P|Q 


>>> read_expr = nltk.sem.Expression.fromstring
>>> read_expr('-(P & Q)')
<NegatedExpression -(P & Q)>
>>> read_expr('P & Q')
<AndExpression (P & Q)>
>>> read_expr('P | (R -> Q)')
<OrExpression (P | (R -> Q))>
>>> read_expr('P <-> -- P')
<IffExpression (P <-> --P)>
 
 
##[A1, ..., An] / C represents the argument 
#that conclusion C follows from assumptions [A1, ...,An]. 

#Example 
Sylvania is to the north of Freedonia (FnS)
Therefore, Freedonia is not to the north of Sylvania (-SnF)
 
#Lets 
FnS - Freedonia is to the north of Sylvania
SnF - Sylvania is to the north of Freedonia

#Then example can be written as 
SnF -> -FnS 

#Then the argument can be written as 
[SnF, SnF -> -FnS] / -FnS 


#Arguments can be tested for "syntactic validity" by using a proof system. 
#Logical proofs can be carried out with NLTK's inference module, 
#for example via an interface to the third-party theorem prover Prover9. 
#download from and install to c:\nltk_data, http://www.cs.unm.edu/~mccune/mace4/gui/v05.html
#The inputs to the inference mechanism first have to be converted into logical expressions.



>>> read_expr = nltk.sem.Expression.fromstring
>>> SnF = read_expr('SnF')
>>> NotFnS = read_expr('-FnS')
>>> R = read_expr('SnF -> -FnS')
>>> prover = nltk.Prover9()
>>> prover.config_prover9(r'c:/nltk_data/prover9/bin-win32')
>>> prover.prove(NotFnS, [SnF, R])  #(goal, assumptions)
True
 
 

##A Valuation is a mapping from basic expressions of the logic to their values. 
>>> val = nltk.Valuation([('P', True), ('Q', True), ('R', False)]) #Bases: dict
>>> val['P']
True

##Assignment 
#An assigment can only assign values from its domain
#A dictionary which represents an assignment of values to variables.

#A variable Assignment is a mapping from individual variables to entities in the domain. 
#Individual variables are usually indicated with the letters 'x', 'y', 'w' and 'z', optionally followed by an integer (e.g., 'x0', 'y332').
>>> from nltk.sem.evaluate import Assignment
>>> dom = set(['u1', 'u2', 'u3', 'u4']) #set of entities/values
>>> g3 = Assignment(dom, [('x', 'u1'), ('y', 'u2')]) #(domain, assign=None),
                                                     #domain (set) – the domain of discourse
                                                     #assign (list) – a list of (varname, value) associations

>>> g3 == {'x': 'u1', 'y': 'u2'}
True
>>> print(g3)
g[u1/x][u2/y]

#to update an assignment using the add method:
>>> dom = set(['u1', 'u2', 'u3', 'u4'])
>>> g4 = Assignment(dom)
>>> g4.add('x', 'u1')
{'x': 'u1'}

#With no arguments, purge() is equivalent to clear() on a dictionary:
>>> g4.purge()
>>> g4
{}



#example 
>>> val = nltk.Valuation([('P', True), ('Q', True), ('R', False)]) #Bases: dict

>>> dom = set()
>>> g = nltk.Assignment(dom) #(domain, assign=None) Bases=dict 

#A first order model is a domain D of discourse(ie Universal set) and a valuation V.
#A domain D is a set of entities, and a valuation V is a map 
#that associates expressions with values in the model

#If an unknown expression a is passed to a model M‘s interpretation function i, 
#i will first check whether M‘s valuation assigns an interpretation to a as a constant, 
#and if this fails, i will delegate the interpretation of a to g(ie Assignment)
#g only assigns values to individual variables

>>> m = nltk.Model(dom, val) #(domain, valuation), 
 
>>> print(m.evaluate('(P & Q)', g) )  #evaluate(expr, g, trace=None)
True
>>> print(m.evaluate('-(P & Q)', g))
False
>>> print(m.evaluate('(P & R)', g))
False
>>> print(m.evaluate('(P | R)', g))
True
 
 
##First-Order Logic - also known as first-order predicate calculus and predicate logic

#First-order logic quantifies variables that can have single value
#second-order logic, in addition, also quantifies over sets; 
#third-order logic also quantifies over sets of sets, and so on. 

#Higher-order logic is the union of first-, second-, third-, …, nth-order logic; 
#i.e., higher-order logic admits quantification over sets that are nested arbitrarily deeply.


#First-order logic keeps all the boolean operators of Propositional Logic. 
#Also introduce predicates(function taking entity from domain/unversal set returning true/false)
#predicates take differing numbers of arguments. 

#For example, 'Angus walks' might be formalized as 'walk(angus)' 
#'Angus sees Bertie' as 'see(angus, bertie). 
#Note how predicate is written, walk is something(fn) with variable, hence walk(x), where x = angus 
#generally, verb, 2nd Noun(object) etc can be predicate and 1st Noun(subject) is value 
#if subject is Pronoun, then it is walk(x) and x is unbound 


#ie  walk a unary predicate, and see a binary predicate. 
#The symbols used as predicates do not have intrinsic meaning, 

#Whether an atomic predication like see(angus, bertie) is true or false 
#in a situation is not a matter of logic, 
#but depends on the particular valuation that we have chosen for the constants see, angus and bertie. 
#For this reason, such expressions are called non-logical constants. 


#By contrast, logical constants (such as the boolean operators) 
#always receive the same interpretation in every model for first-order logic.

#one binary predicate has special status, namely equality
#Equality is regarded as a logical constant, 
#since for individual terms t1 and t2, the formula t1 = t2 is true if and only if t1 and t2 refer to one and the same entity.
 
#Following the tradition of Montague grammar, 
#two basic types are used: 
#e is the type of entities(type of values in domain/universal set ) 
#while t is the type of formulas, i.e., expressions which have truth values. 

#given any types s and t, <s, t> is a complex type 
#corresponding to functions from 's things' to 't things'. 
#unary predicates : <e, t> (read f(e) returning t )is the type of expressions from entities to truth values
#Binary predicates:  <e, <e, t>> (read f(e)(e) returning t) from entities to unary predicate

>>> read_expr = nltk.sem.Expression.fromstring
>>> expr = read_expr('walk(angus)', type_check=True)
>>> expr.argument
<ConstantExpression angus>
>>> expr.argument.type
e
>>> expr.function
<ConstantExpression walk>
>>> expr.function.type
<e,?>
 
#<e,?> : Although the type-checker will try to infer as many types as possible, 
#in this case it has not managed to fully specify the type of walk, 
#since its result type is unknown. 

#Although we are intending walk to receive type <e, t>, 
#as far as the type-checker knows, in this context it could be of some other type such as <e, e> or <e, <e, t> >. 

#To help the type-checker, we need to specify a signature, 
#implemented as a dictionary that explicitly associates types with non-logical constants:

>>> sig = {'walk': '<e, t>'}
>>> expr = read_expr('walk(angus)', signature=sig)
>>> expr.function.type
e
 
 
#In NLTK, variables of type e are all lowercase
#In first-order logic, arguments of predicates can also be individual variables such as x, y and z

#Individual variables are similar to personal pronouns like he, she and it


##open formula - no binding(ie uses only Pronoun subject) - Binding means using Noun(subject) 
#eg  with two occurrences of the variable x. (x is not bound ie x is mentioned as Pronoun/without any exact Noun)
#AND is conjuction

a. He is a dog and he disappeared. 
#Note how predicate is reversed  as here He is variable 
b. (Open formula of a) dog(x) AND disappear(x) 

#To convert Open formula to closed/bound formula, either x is bound to Noun 
#or x is bound to exists x. or all x.  for Existential or universal quantifier

##Existential quantifier EXISTSx ('for some x'/'there exists'/atleast one/Some )
##By placing an EXISTSx in front of (b), 
#we can bind these variables by quantifiers(ie x to some Noun)
 
#all are equivalent 
a.  EXISTSx.(dog(x) AND disappear(x)) 
b.  At least one entity is a dog and disappeared. 
c.  A dog disappeared. 
#NLTK equivalent 
exists x.(dog(x) & disappear(x)) 


##universal quantifier ALLx ('for all x'/every including zero)

#all are equivalent 
a.  ALLx.(dog(x) -> disappear(x))  
b.  Everything has the property that if it is a dog, it disappears. 
    if some x is a dog, then x disappears 
    but it doesn't say that there are any dogs. 
    So in a situation where there are no dogs, it will still come out true. 
    (Remember that (P -> Q), -P|Q is true when P is false.)
c.  Every(including zero dog) dog disappeared. 
#NLTK
all x.(dog(x) -> disappear(x)) 

##Note, in general , EXISTSx is written with AND, conjuction. &
#ALLx is written with  if ... then .. ( ie ->)

#Some notation , Note how predicate is reversed 
"Some x are P" is EXISTSx(P(x))  #in NLTK some x.P(x) or exists x.P(x)
"Not all x are P" is EXISTSx(~P(x)), or equivalently, ~(ALLx P(x))
#If P(x) is never true, EXISTSx(P(x)) is false but EXISTSx(~P(x)) is true.







##Open vs Closed formula 
#Example 
((exists x. dog(x)) -> bark(x))

#The scope of the exists x quantifier is dog(x), 
#so the occurrence of x in bark(x) is unbound. 
#Consequently it can become bound by some other quantifier
all x.((exists x. dog(x)) -> bark(x))

#an occurrence of a variable x in a formula f is free in f 
#if that occurrence doesn't fall within the scope of all x or some x in f. 

#Conversely, if x is free in formula f, then it is bound in 'all x.f and exists x.f.' 
#If all variable occurrences in a formula are bound, the formula is said to be closed.

#class Expression has a method free() which returns the set of variables that are free in expr.

>>> read_expr = nltk.sem.Expression.fromstring
>>> read_expr('dog(cyril)').free()
set()
>>> read_expr('dog(x)').free()
{Variable('x')}
>>> read_expr('own(angus, cyril)').free()
set()
>>> read_expr('exists x.dog(x)').free()
set()
>>> read_expr('((some x. walk(x)) -> sing(x))').free()
{Variable('x')}
>>> read_expr('exists x.own(y, x)').free()
{Variable('y')}
 
 

 
 
 
##First Order Theorem Proving

#Example 
a. if x is to the north of y then y is not to the north of x. 
b. all x. all y.(north_of(x, y) -> -north_of(y, x))

#The general case in theorem proving is to determine 
#whether a formula that we want to prove (a proof goal) 
#can be derived by a finite sequence of inference steps 
#from a list of assumed formulas. 

#We write this as S PROV g, 
#where S is a (possibly empty) list of assumptions, and g is a proof goal

>>> read_expr = nltk.sem.Expression.fromstring
>>> NotFnS = read_expr('-north_of(f, s)')  
>>> SnF = read_expr('north_of(s, f)')    
>>> R = read_expr('all x. all y. (north_of(x, y) -> -north_of(y, x))')  
>>> prover = nltk.Prover9()   
>>> prover.config_prover9(r'c:/nltk_data/prover9/bin-win32')
>>> prover.prove(NotFnS, [SnF, R])  #goal, assumptions
True
 
 
#but below is false 
#all x. all y.(north_of(x, y) -> north_of(y, x))
>>> FnS = read_expr('north_of(f, s)')
>>> prover.prove(FnS, [SnF, R])
False
 
 
#Summary of new logical relations and operators required for First Order Logic, together with two useful methods of the Expression class.
#Example        Description
=               equality 
!=              inequality 
exists          existential quantifier 
all             universal quantifier 
e.free()        show free variables of e 
e.simplify()    carry out ß-reduction on e 





##Truth in Model
#The general process of determining truth or falsity of a formula in a model is called model checking.


#Given a first-order logic language L, 
#a model M for L is a pair <D, Val>, 
#where D is an nonempty set called the domain of the model/universal set 
#and Val is valuation function which assigns values from D to expressions of L as follows:
1.For every individual constant c in L, Val(c) is an element of D.
2.For every predicate symbol P of arity n , Val(P) is a function from Dn to {True, False}. 
#Dn is a tuple of n size , each element is taken from D 
(If the arity of P is 0, then Val(P) is simply a truth value, the P is regarded as a propositional symbol.)
(if P is of arity 2, then Val(P) will be a function f from pairs of elements of D to {True, False})

#Relations are represented semantically in NLTK : as sets of tuples. 
#NLTK: for arity 2, Val(P) is a set S of pairs, defined as follows
#Such an f is called the characteristic function of S 
S = {s | f(s) = True} , s is pairs of D 



#For example, A domain of discourse(universal set) consisting of the individuals Bertie, Olive and Cyril, 
#Bertie is a boy, Olive is a girl and Cyril is a dog. 
#olive walks , cyril walks 
#bertie sees olive, cyril sees bertie , olive sees cyril

 
#Use Valuation.fromstring() 
#to convert a list of strings of the form symbol => value into a Valuation object.

#Example - the value of 'see' is a set of tuples such that Bertie sees Olive, Cyril sees Bertie, and Olive sees Cyril.
#variables are b,o,c
#unary predicates (i.e, boy, girl, dog, walk) is sets of singleton tuples, 
#binary predicate is see
>>> v = """
    bertie => b
    olive => o
    cyril => c
    boy => {b}
    girl => {o}
    dog => {c}
    walk => {o, c}
    see => {(b, o), (c, b), (o, c)} 
    """
>>> val = nltk.Valuation.fromstring(v)
>>> print(val)
{'bertie': 'b',
 'boy': {('b',)},
 'cyril': 'c',
 'dog': {('c',)},
 'girl': {('o',)},
 'olive': 'o',
 'see': {('o', 'c'), ('c', 'b'), ('b', 'o')},
 'walk': {('c',), ('o',)}}
 
 


#A predication of the form P(t1, ... tn), where P is of arity n, comes out true 
#when tuple of values corresponding to (t1, ... tn) belongs to the set of tuples in the value of P.
>>> ('o', 'c') in val['see']
True
>>> ('b',) in val['boy']
True
 
 


##Individual Variables and Assignments
#variable assignment - a mapping from individual variables to entities in the domain. 
#Assignments are created using the Assignment constructor, 
#which also takes the model's domain of discourse as a parameter. 

#We are not required to actually enter any bindings, 
#but if we do, they are in a (variable, value) format 

>>> dom = {'b', 'o', 'c'}
>>> g = nltk.Assignment(dom, [('x', 'o'), ('y', 'c')]) #(dom, assgin)
>>> g
{'y': 'c', 'x': 'o'}
 
>>> print(g)  #similar to Logic textbook syntax 
g[c/y][o/x]
 
 

##evaluate an atomic formula of first-order logic. 
#First, we create a model, then we call the evaluate() method to compute the truth value.
>>> m = nltk.Model(dom, val)
>>> m.evaluate('see(olive, y)', g)  #see(olive, cyril), y comes from Assigment, g
True

>>> g['y']
'c'
 
>>> m.evaluate('see(y, x)', g) #x,y comes from Assigment, g, see(cyril, olive)
False
 
#Complex , Note a Predicate is true if it is part of Valuation 
>>> m.evaluate('see(bertie, olive) & boy(bertie) & -walk(bertie)', g)
True


#The method purge() clears all bindings from an assignment.
>>> g.purge()
>>> g
{}
 
>>> m.evaluate('see(olive, y)', g)
'Undefined'
 
 


 
 
##Quantification

#When is below true?
exists x.(girl(x) & walk(x)) 


#we want to know if there is some u in dom such that g[u/x] satisfies the open formula 
girl(x) & walk(x) 


>>> m.evaluate('exists x.(girl(x) & walk(x))', g)
True
 
 
#Infact x is o 
>>> m.evaluate('girl(x) & walk(x)', g.add('x', 'o'))
True
 
 

#satisfiers() method -returns a set of all the individuals that satisfy an open formula. 
>>> read_expr = nltk.sem.Expression.fromstring
>>> fmla1 = read_expr('girl(x) | boy(x)')
>>> m.satisfiers(fmla1, 'x', g)
{'b', 'o'}
>>> fmla2 = read_expr('girl(x) -> walk(x)')
>>> m.satisfiers(fmla2, 'x', g)
{'c', 'b', 'o'}
>>> fmla3 = read_expr('walk(x) -> girl(x)')
>>> m.satisfiers(fmla3, 'x', g)
{'b', 'o'}
 
#The truth conditions for -> mean that fmla2 is equivalent to -girl(x) | walk(x)
#which is satisfied by something which either isn't a girl or walks. 

# a universally quantified formula ALLx.f is true with respect to g 
#in case for every u, f is true with respect to g[u/x]

#Since neither b (Bertie) nor c (Cyril) are girls, they both satisfy the whole formula. 
#And  o satisfies the formula because o satisfies both disjuncts. 
#Now, since every member of the domain of discourse satisfies fmla2, 
>>> m.evaluate('all x.(girl(x) -> walk(x))', g)
True
 


##Quantifier Scope Ambiguity

Everybody admires someone. 

#There are (at least) two ways of expressing above  in first-order logic:
a.  all x.(person(x) -> exists y.(person(y) & admire(x,y))) 
b.  exists y.(person(y) & all x.(person(x) -> admire(x,y))) 

#(b) is logically stronger than (a): 
#it claims that there is a unique person, say Bruce, who is admired by everyone. 
#(a), requires that for every person u, we can find some person u' whom u admires; 
#but this could be a different person u' in each case. 

#We distinguish between (a) and (b) in terms of the scope of the quantifiers. 
#In the first, ALL has wider scope than EXISTS, 
#while in (b), the scope ordering is reversed. 

#So now we have two ways of representing the meaning of 'Everybody admires someone'
#they are both quite legitimate. 
#In other words, it is ambiguous with respect to quantifier scope

>>> v2 = """
    bruce => b
    elspeth => e
    julia => j
    matthew => m
    person => {b, e, j, m}
    admire => {(j, b), (b, b), (m, e), (e, m)}
    """
>>> val2 = nltk.Valuation.fromstring(v2)
 
#a.  all x.(person(x) -> exists y.(person(y) & admire(x,y))) -- True 
#b.  exists y.(person(y) & all x.(person(x) -> admire(x,y))) -- False 

>>> dom2 = val2.domain
>>> m2 = nltk.Model(dom2, val2)
>>> g2 = nltk.Assignment(dom2)
>>> read_expr = nltk.sem.Expression.fromstring
>>> fmla4 = read_expr('(person(x) -> exists y.(person(y) & admire(x, y)))')
>>> m2.satisfiers(fmla4, 'x', g2)
{'e', 'b', 'm', 'j'}
 
>>> fmla5 = read_expr('(person(y) & all x.(person(x) -> admire(x, y)))')
>>> m2.satisfiers(fmla5, 'y', g2)
set()
#That is, there is no person that is admired by everybody. 

#Taking a different open formula, fmla6, 
#we can verify that there is a person, namely Bruce, who is admired by both Julia and Bruce.

>>> fmla6 = read_expr('(person(y) & all x.((x = bruce | x = julia) -> admire(x, y)))')
>>> m2.satisfiers(fmla6, 'y', g2)
{'b'}
 
 
##Model Building
#model building tries to create a new model, given some set of sentences. 
#If it succeeds, then we know that the set is consistent, 
#since we have an existence proof of the model.

#One option is to treat our candidate set of sentences as assumptions, 
#while leaving the goal unspecified. 

#The following interaction shows how both [a, c1] and [a, c2] are consistent lists, 
#since Mace succeeds in building a model for each of them, while [c1, c2] is inconsistent

>>> read_expr = nltk.sem.Expression.fromstring
>>> a3 = read_expr('exists x.(man(x) & walks(x))')
>>> c1 = read_expr('mortal(socrates)')
>>> c2 = read_expr('-mortal(socrates)')
>>> mb = nltk.Mace(5)  #end_size=5

##below configuration does not work 
>>> mb.config_prover9(r'c:/nltk_data/prover9/bin-win32')
#hack , intsllation dir of prover9 
>>> mb._mace4_bin = r"c:/nltk_data/prover9/bin-win32/mace4.exe"

>>> print(mb.build_model(None, [a3, c1])) #goal, assumptions
True
>>> print(mb.build_model(None, [a3, c2]))
True
>>> print(mb.build_model(None, [c1, c2]))
False
 
 

#We can also use the model builder as an adjunct(supplementary) to the theorem prover. 

# to prove S PROV g, 
#i.e. that g is logically derivable from assumptions S = [s1, s2, ..., sn]. 

#We can feed this same input to Mace4, 
#and the model builder will try to find a counterexample, 
#that is, to show that g does not follow from S. 

#So, given this input, Mace4 will try to find a model 
#for the set S together with the negation of g, S' =[s1, s2, ..., sn, -g]. 
#If g fails to follow from S, 
#then Mace4 may well return with a counterexample faster than Prover9 concludes that it cannot find the required proof. 

#Conversely, if g is provable from S, Mace4 may take a long time unsuccessfully trying to find a countermodel, 
#and will eventually give up.

#Example - 
#Our assumptions are the list 
#[There is a woman that every man loves, Adam is a man, Eve is a woman]. 
#Our conclusion is Adam loves Eve. 

#Can Mace4 find a model in which the premises are true but the conclusion is false? 

#use MaceCommand() which will let us inspect the model that has been built.
class nltk.inference.mace.MaceCommand(goal=None, assumptions=None, max_models=500, model_builder=None)

>>> read_expr = nltk.sem.Expression.fromstring
>>> a4 = read_expr('exists y. (woman(y) & all x. (man(x) -> love(x,y)))')
>>> a5 = read_expr('man(adam)')
>>> a6 = read_expr('woman(eve)')
>>> g = read_expr('love(adam,eve)')
>>> mc = nltk.MaceCommand(g, assumptions=[a4, a5, a6])
>>> mc._modelbuilder._mace4_bin = r"c:/nltk_data/prover9/bin-win32/mace4.exe"
>>> mc._interpformat_bin = r"c:/nltk_data/prover9/bin-win32/interpformat.exe"
>>> mc.build_model()
True
>>> print(mc.valuation)
{'C1': 'b',
 'adam': 'a',
 'eve': 'a',
 'love': {('a', 'b')},
 'man': {('a',)},
 'woman': {('a',), ('b',)}}
 
>>> mc.print_assumptions()
exists y.(woman(y) & all x.(man(x) -> love(x,y)))
man(adam)
woman(eve)

#C1 - "skolem constant" 
#that the model builder introduces as a representative of the existential quantifier. 

#That is, when the model builder encountered the exists y part of a4 above, 
#it knew that there is some individual b in the domain which satisfies the open formula in the body of a4. 

#However, it doesn't know whether b is also the denotation of an individual constant anywhere else in its input, 
#so it makes up a new name for b on the fly, namely C1. 

#Note we didn't specify that man and woman denote disjoint sets, 
#so the model builder lets their denotations overlap. 

#So let's add a new assumption which makes the sets of men and women disjoint. 

>>> a7 = read_expr('all x. (man(x) -> -woman(x))')
>>> g = read_expr('love(adam,eve)')
>>> mc = nltk.MaceCommand(g, assumptions=[a4, a5, a6, a7])
>>> mc._modelbuilder._mace4_bin = r"c:/nltk_data/prover9/bin-win32/mace4.exe"
>>> mc._interpformat_bin = r"c:/nltk_data/prover9/bin-win32/interpformat.exe"
>>> mc.build_model()
True
>>> print(mc.valuation)
{'C1': 'c',
 'adam': 'a',
 'eve': 'b',
 'love': {('a', 'c')},
 'man': {('a',)},
 'woman': {('c',), ('b',)}}
#there is nothing in our premises which says that Eve is the only woman in the domain of discourse
#to ensure that there is only one woman in the model, add 
exists y. all x. (woman(x) -> (x = y))


 
##Compositional Semantics in Feature-Based Grammar

#Principle of Compositionality
1.The meaning of a whole is a function of the meanings of the parts 
  and of the way they are syntactically combined., Hence use function application 

##first approximation to the kind of analyses we would like to build  

#the sem value at the root node shows a semantic representation for the whole sentence, 
#while the sem values at lower nodes show semantic representations for constituents of the sentence. 

#Since the values of sem have to be treated in special manner(ie Whole and  parts)
#they are distinguished from other feature values by being enclosed in angle brackets.

S[SEM=<bark(cyril)>]
    NP[SEM=<cyril>]
        cyril
    VP[SEM=<bark>]
        IV[SEM=<\x.bark(x)>]   #Denotes 'bark' is Lambda function 
            barks

#To build above , use function application  
#suppose we have a NP and VP constituents with appropriate values for their sem nodes. 
#Then the sem value of an S is handled by a rule like below. 
#(Observe that in the case where the value of sem is a variable, we omit the angle brackets.)
S[SEM=<?vp(?np)>] -> NP[SEM=?np] VP[SEM=?vp] 
#means that given some sem value ?np for the subject NP and some sem value ?vp for the VP, 
#the sem value of the S parent is constructed by applying ?vp as a function expression to ?np.
#ie, ?vp has to denote a function which has the denotation of ?np in its domain

#To complete the grammar 
VP[SEM=?v] -> IV[SEM=?v]
NP[SEM=<cyril>] -> 'Cyril'
IV[SEM=<\x.bark(x)>] -> 'barks'
#The VP rule says that the parent's semantics is the same as the head child's semantics. 
#The two lexical rules provide non-logical constants to serve as the semantic values of Cyril and barks respectively. 
#last rule also contains lambda-Calculus


##The lambda Calculus - \x. EXPR can be treated as function(x) ie taking arg name = x and returning EXPR

#the set of all w such that w is an element of V (the vocabulary) and w has property P".
{w | w BELONGSTO V & P(w)} 
#OR using lambda operator 
LAMBDAw. (V(w) & P(w)) 


#lambda is a binding operator, just as the first-order logic quantifiers are. 

#For open formula (a), we can bind with  lambda-operator 
a.  (walk(x) AND chew_gum(x)) 
b.  LAMBDAx.(walk(x) AND chew_gum(x)) 
#NLTK
c.  \x.(walk(x) & chew_gum(x)) 
#Means 
#"be an x such that x walks and x chews gum" or "have the property of walking and chewing gum".

>>> read_expr = nltk.sem.Expression.fromstring
>>> expr = read_expr(r'\x.(walk(x) & chew_gum(x))')
>>> expr
<LambdaExpression \x.(walk(x) & chew_gum(x))>
>>> expr.free()
set()
>>> print(read_expr(r'\x.(walk(x) & chew_gum(y))'))
\x.(walk(x) & chew_gum(y))
 
 
 
#LAMBDA-operator is useful for below semantics 
a.  To walk and chew-gum is hard 
b.  hard(\x.(walk(x) & chew_gum(x))) 

#if f is an open formula, then the abstract LAMBDAx.f can be used as a unary predicate 
\x.(walk(x) & chew_gum(x)) (gerald) 
#says that Gerald has the property of walking and chewing gum, 
#which has the same meaning as 
(walk(gerald) & chew_gum(gerald)) 

#OR 
#use a[ß/x] as notation for the operation of replacing 
#all free occurrences of x in a by the expression ß(called ß-reduction)
(walk(x) & chew_gum(x))[gerald/x]  #ie value of x is gerald
#LAMBDAx. a(ß) has the same semantic values as a[ß/x]

#in NLTK, we can call the simplify() method 
>>> expr = read_expr(r'\x.(walk(x) & chew_gum(x))(gerald)')
>>> print(expr)
\x.(walk(x) & chew_gum(x))(gerald)
>>> print(expr.simplify()) 
(walk(gerald) & chew_gum(gerald))
 
 
#Here's an example with two LAMBDAs: works like a binary predicate
\x.\y.(dog(x) & own(y, x)) 
# \x.\y. to be written in the abbreviated form \x y. 
>>> print(read_expr(r'\x.\y.(dog(x) & own(y, x))(cyril)').simplify())
\y.(dog(cyril) & own(y,cyril))
>>> print(read_expr(r'\x y.(dog(x) & own(y, x))(cyril, angus)').simplify()) 
(dog(cyril) & own(angus,cyril))
 
 

#The process of relabeling bound variables is known as alpha-conversion
# Using ==, we are  testing for alpha-equivalence:
>>> expr1 = read_expr('exists x.P(x)')
>>> print(expr1)
exists x.P(x)
>>> expr2 = expr1.alpha_convert(nltk.sem.Variable('z'))
>>> print(expr2)
exists z.P(z)
>>> expr1 == expr2
True
 
#This relabeling is carried out automatically by the ß-reduction code in logic

>>> expr3 = read_expr('\P.(exists x.P(x))(\y.see(y, x))') #P is arg name, call LAMBDA with another lambda P = \y.see(y, x)
>>> print(expr3)
(\P.exists x.P(x))(\y.see(y,x))
>>> print(expr3.simplify())
exists z1.see(z1,x)
 
 
##Quantified NPs
 
a.  A dog barks. 
b1.  exists x.(dog(x) & bark(x)) 

#how do we give a semantic representation to the quantified NPs 'a dog' 
#so that it can be combined with bark to give the result in b1
 
#ie way of instantiating ?np so that 
[SEM=<?np(\x.bark(x))>] 
#is equivalent to 
[SEM=<exists x.(dog(x) & bark(x))>].

#b1 is equivalent to below 
#create Lambda operator P which is used in place of P (lambda = function(P))
\P.exists x.(dog(x) & P(x))  #***REF-1***

#OR with another level of abstraction (ie lambda(Q,P) function )
\Q P.exists x.(Q(x) & P(x))

#Note -Applying above as a function expression to 'dog' yields earlier one
#, and applying that to 'bark' gives us 
\P.exists x.(dog(x) & P(x))(\x.bark(x)). 
#Finally, carrying out ß-reduction yields just what we wanted, namely (b1).


#Note: a universally quantified NP will look like 
\P.all x.(dog(x) -> P(x)) 



##Transitive Verbs

a. Angus chases a dog. 
b2. exists x.(dog(x) & chase(angus, x))
 
#1st  level of abstraction with lambda - \y. EXPR 
\y.exists x.(dog(x) & chase(y, x)) 

#equivalent to \P.EXPR and call P(\z.chase(y, z))
\P.exists x.(dog(x) & P(x))(\z.chase(y, z)) 

#replace the above function expression by a variable X = \P.exists x.(dog(x) & P(x))
X(\z.chase(y, z)) 
#or in lambda Notation , \X.EXPR , EXPR =  \P.exists x.(dog(x) & P(x)) = \x.X(..)
#and call X with value (\P.exists x.(dog(x) & P(x)))
\X. \x.X(\y.chase(x, y)) 
#OR 
\X x.X(\y.chase(x, y)) 

>>> read_expr = nltk.sem.Expression.fromstring
>>> tvp = read_expr(r'\X x.X(\y.chase(x,y))')
>>> np = read_expr(r'(\P.exists x.(dog(x) & P(x)))')
>>> vp = nltk.sem.ApplicationExpression(tvp, np) #tvp(np)
>>> print(vp)
(\X x.X(\y.chase(x,y)))(\P.exists x.(dog(x) & P(x)))
>>> print(vp.simplify())
\x.exists z2.(dog(z2) & chase(x,z2))
 
 

#Note  lambda expression for single value , Angus.
\P. P(angus) 

#simple-sem.fcfg contains a small set of rules for parsing and translating simple examples of the kind 

>>> from nltk import load_parser
>>> nltk.data.show_cfg('grammars/book_grammars/simple-sem.fcfg')
#<> means Compostion of whole from Parts 
# f(x) means result from function application of f with arg x 
# \x.EXPR -> XXX means convert XXX to lambda EXPR(x) 
% start S
# Grammar Rules
S[SEM = <?subj(?vp)>] -> NP[NUM=?n,SEM=?subj] VP[NUM=?n,SEM=?vp]
NP[NUM=?n,SEM=<?det(?nom)> ] -> Det[NUM=?n,SEM=?det]  Nom[NUM=?n,SEM=?nom]
NP[LOC=?l,NUM=?n,SEM=?np] -> PropN[LOC=?l,NUM=?n,SEM=?np]
Nom[NUM=?n,SEM=?nom] -> N[NUM=?n,SEM=?nom]
VP[NUM=?n,SEM=?v] -> IV[NUM=?n,SEM=?v]
VP[NUM=?n,SEM=<?v(?obj)>] -> TV[NUM=?n,SEM=?v] NP[SEM=?obj]
VP[NUM=?n,SEM=<?v(?obj,?pp)>] -> DTV[NUM=?n,SEM=?v] NP[SEM=?obj] PP[+TO,SEM=?pp]
PP[+TO, SEM=?np] -> P[+TO] NP[SEM=?np]
# Lexical Rules
PropN[-LOC,NUM=sg,SEM=<\P.P(angus)>] -> 'Angus'
PropN[-LOC,NUM=sg,SEM=<\P.P(cyril)>] -> 'Cyril'
PropN[-LOC,NUM=sg,SEM=<\P.P(irene)>] -> 'Irene'
Det[NUM=sg,SEM=<\P Q.all x.(P(x) -> Q(x))>] -> 'every'
Det[NUM=pl,SEM=<\P Q.all x.(P(x) -> Q(x))>] -> 'all'
Det[SEM=<\P Q.exists x.(P(x) & Q(x))>] -> 'some'
Det[NUM=sg,SEM=<\P Q.exists x.(P(x) & Q(x))>] -> 'a'
Det[NUM=sg,SEM=<\P Q.exists x.(P(x) & Q(x))>] -> 'an'
N[NUM=sg,SEM=<\x.man(x)>] -> 'man'
N[NUM=sg,SEM=<\x.girl(x)>] -> 'girl'
N[NUM=sg,SEM=<\x.boy(x)>] -> 'boy'
N[NUM=sg,SEM=<\x.bone(x)>] -> 'bone'
N[NUM=sg,SEM=<\x.ankle(x)>] -> 'ankle'
N[NUM=sg,SEM=<\x.dog(x)>] -> 'dog'
N[NUM=pl,SEM=<\x.dog(x)>] -> 'dogs'
IV[NUM=sg,SEM=<\x.bark(x)>,TNS=pres] -> 'barks'
IV[NUM=pl,SEM=<\x.bark(x)>,TNS=pres] -> 'bark'
IV[NUM=sg,SEM=<\x.walk(x)>,TNS=pres] -> 'walks'
IV[NUM=pl,SEM=<\x.walk(x)>,TNS=pres] -> 'walk'
TV[NUM=sg,SEM=<\X x.X(\y.chase(x,y))>,TNS=pres] -> 'chases'
TV[NUM=pl,SEM=<\X x.X(\y.chase(x,y))>,TNS=pres] -> 'chase'
TV[NUM=sg,SEM=<\X x.X(\y.see(x,y))>,TNS=pres] -> 'sees'
TV[NUM=pl,SEM=<\X x.X(\y.see(x,y))>,TNS=pres] -> 'see'
TV[NUM=sg,SEM=<\X x.X(\y.bite(x,y))>,TNS=pres] -> 'bites'
TV[NUM=pl,SEM=<\X x.X(\y.bite(x,y))>,TNS=pres] -> 'bite'
DTV[NUM=sg,SEM=<\Y X x.X(\z.Y(\y.give(x,y,z)))>,TNS=pres] -> 'gives'
DTV[NUM=pl,SEM=<\Y X x.X(\z.Y(\y.give(x,y,z)))>,TNS=pres] -> 'give'
P[+to] -> 'to'


>>> parser = load_parser('grammars/book_grammars/simple-sem.fcfg', trace=1)
>>> sentence = 'Angus gives a bone to every dog'
>>> tokens = sentence.split()
>>> for tree in parser.parse(tokens):
        print(tree.label()['SEM'])
all z2.(dog(z2) -> exists z1.(bone(z1) & give(angus,z1,z2)))

>>> sen = list(parser.parse(tokens))[0].label()['SEM']
#Above can be tested via Model builder , given assumptions 
>>> read_expr = nltk.sem.Expression.fromstring
>>> a4 = sen 
>>> a5 = read_expr('dog(tom)')
>>> a6 = read_expr('bone(haddi)')
>>> g = read_expr('give(angus,haddi,tom)')
>>> mc = nltk.MaceCommand(g, assumptions=[a4, a5, a6])
>>> mc._modelbuilder._mace4_bin = r"c:/nltk_data/prover9/bin-win32/mace4.exe"
>>> mc._interpformat_bin = r"c:/nltk_data/prover9/bin-win32/interpformat.exe"
>>> mc.build_model()
True
>>> print(mc.valuation)
{'angus': 'a',
 'bone': {('b',), ('a',)},
 'dog': {('a',)},
 'give': {('a', 'b', 'a')},
 'haddi': 'a',
 'tom': 'a'}
 
>>> mc.print_assumptions()
all z10.(dog(z10) -> exists z9.(bone(z9) & give(angus,z9,z10)))
dog(tom)
bone(haddi)


#details 
>>> trees = list(parser.parse(tokens))
|.A.g.a.b.t.e.d.|
|[-] . . . . . .| [0:1] 'Angus'
|. [-] . . . . .| [1:2] 'gives'
|. . [-] . . . .| [2:3] 'a'
|. . . [-] . . .| [3:4] 'bone'
|. . . . [-] . .| [4:5] 'to'
|. . . . . [-] .| [5:6] 'every'
|. . . . . . [-]| [6:7] 'dog'
|[-] . . . . . .| [0:1] PropN[-LOC, NUM='sg', SEM=<\P.P(angus)>] -> 'Angus' *
|[-] . . . . . .| [0:1] NP[-LOC, NUM='sg', SEM=<\P.P(angus)>] -> PropN[-LOC, NUM='sg', SEM=<\P.P(angus)>] *
|[-> . . . . . .| [0:1] S[SEM=<?subj(?vp)>] -> NP[NUM=?n, SEM=?subj] * VP[NUM=?n, SEM=?vp] {?n: 'sg', ?subj: <LambdaExpression \P.P(angus)>}
|. [-] . . . . .| [1:2] DTV[NUM='sg', SEM=<\Y X x.X(\z.Y(\y.give(x,y,z)))>, TNS='pres'] -> 'gives' *
|. [-> . . . . .| [1:2] VP[NUM=?n, SEM=<?v(?obj,?pp)>] -> DTV[NUM=?n,SEM=?v] * NP[SEM=?obj] PP[SEM=?pp, +TO] {?n: 'sg', ?v: <LambdaExpression \Y X x.X(\z.Y(\y.give(x,y,z)))>}
|. . [-] . . . .| [2:3] Det[NUM='sg', SEM=<\P Q.exists x.(P(x) & Q(x))>] -> 'a' *
|. . [-> . . . .| [2:3] NP[NUM=?n, SEM=<?det(?nom)>] -> Det[NUM=?n, SEM=?det] * Nom[NUM=?n, SEM=?nom] {?det: <LambdaExpression \P Q.exists x.(P(x) & Q(x))>, ?n: 'sg'}
|. . . [-] . . .| [3:4] N[NUM='sg', SEM=<\x.bone(x)>] -> 'bone' *
|. . . [-] . . .| [3:4] Nom[NUM='sg', SEM=<\x.bone(x)>] -> N[NUM='sg', SEM=<\x.bone(x)>] *
|. . [---] . . .| [2:4] NP[NUM='sg', SEM=<\Q.exists x.(bone(x) & Q(x))>] -> Det[NUM='sg', SEM=<\P Q.exists x.(P(x) & Q(x))>] Nom[NUM='sg', SEM=<\x.bone(x)>] *
|. . [---> . . .| [2:4] S[SEM=<?subj(?vp)>] -> NP[NUM=?n, SEM=?subj] * VP[NUM=?n, SEM=?vp] {?n: 'sg', ?subj: <LambdaExpression \Q.exists x.(bone(x) & Q(x))>}
|. [-----> . . .| [1:4] VP[NUM=?n, SEM=<?v(?obj,?pp)>] -> DTV[NUM=?n,SEM=?v] NP[SEM=?obj] * PP[SEM=?pp, +TO] {?n: 'sg', ?obj: <LambdaExpression \Q.exists x.(bone(x) & Q(x))>, ?v: <LambdaExpression \Y X x.X(\z.Y(\y.give(x,y,z)))>}
|. . . . [-] . .| [4:5] P[+to] -> 'to' *
|. . . . [-> . .| [4:5] PP[SEM=?np, +TO] -> P[+TO] * NP[SEM=?np] {}
|. . . . . [-] .| [5:6] Det[NUM='sg', SEM=<\P Q.all x.(P(x) -> Q(x))>] -> 'every' *
|. . . . . [-> .| [5:6] NP[NUM=?n, SEM=<?det(?nom)>] -> Det[NUM=?n, SEM=?det] * Nom[NUM=?n, SEM=?nom] {?det: <LambdaExpression \P Q.all x.(P(x) -> Q(x))>, ?n: 'sg'}
|. . . . . . [-]| [6:7] N[NUM='sg', SEM=<\x.dog(x)>] -> 'dog' *
|. . . . . . [-]| [6:7] Nom[NUM='sg', SEM=<\x.dog(x)>] -> N[NUM='sg',SEM=<\x.dog(x)>] *
|. . . . . [---]| [5:7] NP[NUM='sg', SEM=<\Q.all x.(dog(x) -> Q(x))>]-> Det[NUM='sg', SEM=<\P Q.all x.(P(x) -> Q(x))>] Nom[NUM='sg', SEM=<\x.dog(x)>] *
|. . . . . [--->| [5:7] S[SEM=<?subj(?vp)>] -> NP[NUM=?n, SEM=?subj] * VP[NUM=?n, SEM=?vp] {?n: 'sg', ?subj: <LambdaExpression \Q.all x.(dog(x) -> Q(x))>}
|. . . . [-----]| [4:7] PP[SEM=<\Q.all x.(dog(x) -> Q(x))>, +TO] -> P[+TO] NP[SEM=<\Q.all x.(dog(x) -> Q(x))>] *
|. [-----------]| [1:7] VP[NUM='sg', SEM=<\x.all z2.(dog(z2) -> exists z1.(bone(z1) & give(x,z1,z2)))>] -> DTV[NUM='sg', SEM=<\Y X x.X(\z.Y(\y.give(x,y,z)))>] NP[SEM=<\Q.exists x.(bone(x) & Q(x))>] PP[SEM=<\Q.all x.(dog(x) -> Q(x))>, +TO] *
|[=============]| [0:7] S[SEM=<all z2.(dog(z2) -> exists z1.(bone(z1)& give(angus,z1,z2)))>] -> NP[NUM='sg', SEM=<\P.P(angus)>] VP[NUM='sg', SEM=<\x.all z2.(dog(z2) -> exists z1.(bone(z1) & give(x,z1,z2)))>] *

>>> print(trees[0])
#ie S = ?subj(?vp) = \P.P(angus)(\x.all z2.(dog(z2) -> exists z1.(bone(z1) & give(x,z1,z2))))
#= beta reduction, P=?vp ie = \x.all z2.(dog(z2) -> exists z1.(bone(z1) & give(x,z1,z2)))(angus)
#?subj from NP  = \P.P(angus)
#?vp from VP = \x.all z2.(dog(z2) -> exists z1.(bone(z1) & give(x,z1,z2)))

(S[SEM=<all z2.(dog(z2) -> exists z1.(bone(z1) & give(angus,z1,z2)))>]
  (NP[-LOC, NUM='sg', SEM=<\P.P(angus)>]
    (PropN[-LOC, NUM='sg', SEM=<\P.P(angus)>] Angus))
  (VP[NUM='sg', SEM=<\x.all z2.(dog(z2) -> exists z1.(bone(z1) & give(x,z1,z2)))>]
    (DTV[NUM='sg', SEM=<\Y X x.X(\z.Y(\y.give(x,y,z)))>, TNS='pres']    gives)
    (NP[NUM='sg', SEM=<\Q.exists x.(bone(x) & Q(x))>]
      (Det[NUM='sg', SEM=<\P Q.exists x.(P(x) & Q(x))>] a)
      (Nom[NUM='sg', SEM=<\x.bone(x)>]
        (N[NUM='sg', SEM=<\x.bone(x)>] bone)))
    (PP[SEM=<\Q.all x.(dog(x) -> Q(x))>, +TO])
      (P[+to] to)
      (NP[NUM='sg', SEM=<\Q.all x.(dog(x) -> Q(x))>]
        (Det[NUM='sg', SEM=<\P Q.all x.(P(x) -> Q(x))>] every)
        (Nom[NUM='sg', SEM=<\x.dog(x)>]
          (N[NUM='sg', SEM=<\x.dog(x)>] dog))))))
>>>

##Reference 

nltk.sem.util.evaluate_sents(inputs, grammar, model, assignment, trace=0)
    Add the truth-in-a-model value to each semantic representation 
    for each syntactic parse of each input sentences.
        inputs (list(str)) – a list of sentences
        grammar (nltk.grammar.FeatureGrammar) – FeatureGrammar or name of feature-based grammar
    Returns:a mapping from sentences to lists of triples (parse-tree, semantic-representations, evaluation-in-model)
    Return type: list(list(tuple(nltk.tree.Tree, nltk.sem.logic.ConstantExpression, bool or dict(str): bool)))

nltk.sem.util.interpret_sents(inputs, grammar, semkey='SEM', trace=0)
    Add the semantic representation to each syntactic parse tree of each input sentence.
        inputs (list(str)) – a list of sentences
        grammar (nltk.grammar.FeatureGrammar) – FeatureGrammar or name of feature-based grammar
    Returns: a mapping from sentences to lists of pairs (parse-tree, semantic-representations)
    Return type:list(list(tuple(nltk.tree.Tree, nltk.sem.logic.ConstantExpression)))

nltk.sem.util.parse_sents(inputs, grammar, trace=0)
    Convert input sentences into syntactic trees.
        inputs (list(str)) – sentences to be parsed
        grammar (nltk.grammar.FeatureGrammar) – FeatureGrammar or name of feature-based grammar
    Return type:list(nltk.tree.Tree) or dict(list(str)): list(Tree)
    Returns:a mapping from input sentences to a list of ``Tree``s

nltk.sem.util.read_sents(filename, encoding='utf8')

nltk.sem.util.root_semrep(syntree, semkey='SEM')
    Find the semantic representation at the root of a tree.
        syntree – a parse Tree
        semkey – the feature label to use for the root semantics in the tree
    Returns:  the semantic representation at the root of a Tree
    Return type: sem.Expression
 
 
#The function interpret_sents() is intended for interpretation of a list of input sentences. 
#It builds a dictionary d where for each sentence 'sent' in the input, 
#d[sent] is a list of pairs (synrep, semrep) consisting of trees and semantic representations for sent. 

>>> sents = ['Irene walks', 'Cyril bites an ankle']
>>> grammar_file = 'grammars/book_grammars/simple-sem.fcfg'
>>> for results in nltk.interpret_sents(sents, grammar_file):
        for (synrep, semrep) in results:
            print(synrep)
(S[SEM=<walk(irene)>]
  (NP[-LOC, NUM='sg', SEM=<\P.P(irene)>]
    (PropN[-LOC, NUM='sg', SEM=<\P.P(irene)>] Irene))
  (VP[NUM='sg', SEM=<\x.walk(x)>]
    (IV[NUM='sg', SEM=<\x.walk(x)>, TNS='pres'] walks)))
(S[SEM=<exists z3.(ankle(z3) & bite(cyril,z3))>]
  (NP[-LOC, NUM='sg', SEM=<\P.P(cyril)>]
    (PropN[-LOC, NUM='sg', SEM=<\P.P(cyril)>] Cyril))
  (VP[NUM='sg', SEM=<\x.exists z3.(ankle(z3) & bite(x,z3))>]
    (TV[NUM='sg', SEM=<\X x.X(\y.bite(x,y))>, TNS='pres'] bites)
    (NP[NUM='sg', SEM=<\Q.exists x.(ankle(x) & Q(x))>]
      (Det[NUM='sg', SEM=<\P Q.exists x.(P(x) & Q(x))>] an)
      (Nom[NUM='sg', SEM=<\x.ankle(x)>]
        (N[NUM='sg', SEM=<\x.ankle(x)>] ankle)))))
 
 
##Truth value of English sentences 
#We have seen now how to convert English sentences into logical forms, 
#and earlier we saw how logical forms could be checked as true or false in a model. 

#Putting these two mappings together, we can check the truth value of English sentences 

>>> v = """
    bertie => b
    olive => o
    cyril => c
    boy => {b}
    girl => {o}
    dog => {c}
    walk => {o, c}
    see => {(b, o), (c, b), (o, c)}
    """
>>> val = nltk.Valuation.fromstring(v)
>>> g = nltk.Assignment(val.domain)
>>> m = nltk.Model(val.domain, val)
>>> sent = 'Cyril sees every boy'
>>> grammar_file = 'grammars/book_grammars/simple-sem.fcfg'
>>> results = nltk.evaluate_sents([sent], grammar_file, m, g)
>>> for (syntree, semrep, value) in results:
        print(semrep)
        print(value)
all z4.(boy(z4) -> see(cyril,z4))
True
 
 
 
 
##Dealing with  Quantifier Ambiguity 

#Note above model would translate below to a, not b 
Every girl chases a dog.  
a.  all x.(girl(x) -> exists y.(dog(y) & chase(x,y))) 
b.  exists y.(dog(y) & all x.(girl(x) -> chase(x,y))) 

##NLTK- One SOlution is Cooper storage, 
#a semantic representation is no longer an expression of first-order logic, 
#but instead a pair consisting of a "core" semantic representation plus a list of binding operators. 

# a binding operator as being identical to the semantic representation of a quantified NP 
\P.all x.(girl(x) -> P(x)) 
\P.exists x.(dog(x) & P(x)) 

#let's take our core to be the open formula chase(x,y). 
#Given a list of above binding operators
#we pick a binding operator and combine it with the core=chase(x,y) .
\P.exists y.(dog(y) & P(y))(\z2.chase(z1,z2))

#Then we take the result, and apply the next binding operator  to it.
\P.all x.(girl(x) -> P(x))(\z1.exists x.(dog(x) & chase(z1,x)))

#Once the list is empty, we have a conventional logical form for the sentence.
#Combining binding operators with the core in this way is called S-Retrieval. 

#If we are careful to allow every possible order of binding operators 
#(for example, by taking all permutations of the list), 
#then we will be able to generate every possible scope ordering of quantifiers.

##To build Cooper storage, introduce new features 
#each phrasal and lexical rule in the grammar will have a sem feature, 
#now there will be embedded features core and store. 

#Example -  Cyril smiles. 
#Here's a lexical rule for the verb smiles (taken from the grammar storage.fcfg) 
IV[SEM=[core=<\x.smile(x)>, store=(/)]] -> 'smiles'

#The rule for the proper name Cyril is more complex.
NP[SEM=[core=<@x>, store=(<bo(\P.P(cyril),@x)>)]] -> 'Cyril'

#The bo predicate has two subparts: 
#the standard representation of a proper name, 
#and the expression @x, which is called the address of the binding operator.
 
#@x is a metavariable, 
#that is, a variable that ranges over individual variables of the logic 
#it also provides the value of core. 

#The rule for VP just percolates up the semantics of the IV
VP[SEM=?s] -> IV[SEM=?s]

S[SEM=[core=<?vp(?np)>, store=(?b1+?b2)]] ->
   NP[SEM=[core=?np, store=?b1]] VP[SEM=[core=?vp, store=?b2]]


#The core value at the S node is the result of applying the VP's core value, 
#namely \x.smile(x), to the subject NP's value. 

#The latter will not be @x, but rather an instantiation of @x, say z3. 
#After ß-reduction, <?vp(?np)> will be unified with <smile(z3)>. 

#Now, when @x is instantiated as part of the parsing process, 
#it will be instantiated uniformly. 
#In particular, the occurrence of @x in the subject NP's store will also be mapped to z3, 
#yielding the element bo(\P.P(cyril),z3). 

#These steps can be seen in the following parse tree.
(S[SEM=[core=<smile(z3)>, store=(bo(\P.P(cyril),z3))]]
  (NP[SEM=[core=<z3>, store=(bo(\P.P(cyril),z3))]] Cyril)
  (VP[SEM=[core=<\x.smile(x)>, store=()]]
    (IV[SEM=[core=<\x.smile(x)>, store=()]] smiles)))


#for 'Every girl chases a dog.'
core  = <chase(z1,z2)>
store = (bo(\P.all x.(girl(x) -> P(x)),z1), bo(\P.exists x.(dog(x) & P(x)),z2))

 
#The module nltk.sem.cooper_storage deals with the task of turning storage-style semantic representations into standard logical forms. 

class nltk.sem.cooper_storage.CooperStore(featstruct)
    Bases: object
    A container for handling quantifier ambiguity via Cooper storage.
    s_retrieve(trace=False)
        Carry out S-Retrieval of binding operators in store. 
        If hack=True, serialize the bindop and core as strings and reparse. 
        
        Each permutation of the store (i.e. list of binding operators) 
        is taken to be a possible scoping of quantifiers. 
        We iterate through the binding operators in each permutation, 
        and successively apply them to the current term, 
        starting with the core semantic representation, 
        working from the inside out.
        Binding operators are of the form:
        bo(\P.all x.(man(x) -> P(x)),z1)


nltk.sem.cooper_storage.parse_with_bindops(sentence, grammar=None, trace=0)
    Use a grammar with Binding Operators to parse a sentence.

#Example   
>>> from nltk.sem import cooper_storage as cs
>>> sentence = 'every girl chases a dog'
>>> trees = cs.parse_with_bindops(sentence, grammar='grammars/book_grammars/storage.fcfg')
>>> semrep = trees[0].label()['SEM']
>>> cs_semrep = cs.CooperStore(semrep)
>>> print(cs_semrep.core)  #self.core = featstruct['CORE']
chase(z2,z4)
>>> for bo in cs_semrep.store:  # self.store = featstruct['STORE']
        print(bo)
bo(\P.all x.(girl(x) -> P(x)),z2)
bo(\P.exists x.(dog(x) & P(x)),z4)
 
 
#Finally we call s_retrieve() and check the readings.
>>> cs_semrep.s_retrieve(trace=True)
Permutation 1
   (\P.all x.(girl(x) -> P(x)))(\z2.chase(z2,z4))
   (\P.exists x.(dog(x) & P(x)))(\z4.all x.(girl(x) -> chase(x,z4)))
Permutation 2
   (\P.exists x.(dog(x) & P(x)))(\z4.chase(z2,z4))
   (\P.all x.(girl(x) -> P(x)))(\z2.exists x.(dog(x) & chase(z2,x)))
 
 
>>> for reading in cs_semrep.readings:
        print(reading)
exists x.(dog(x) & all z3.(girl(z3) -> chase(z3,x)))
all x.(girl(x) -> exists z4.(dog(z4) & chase(x,z4)))
 
 
 
 
##NLTK- Discourse Semantics

#A discourse is a sequence of sentences. 
#Very often, the interpretation of a sentence in a discourse depends what preceded it. 

#Given discourse such as 'Angus used to have a dog. But he recently disappeared.', 
#you will probably interpret he as referring to Angus's dog. 

#However, in 'Angus used to have a dog. He took him for walks in New Town'., 
#you are more likely to interpret he as referring to Angus himself.

 
##NLTK- Discourse Representation Theory(DRT)
 
a.  Angus owns a dog. It bit Irene. 
b.  EXISTSx.(dog(x) AND own(Angus, x) AND bite(x, Irene)) 

#A discourse representation structure (DRS) presents the meaning of discourse 
#in terms of a list of discourse referents and a list of conditions. 

#The discourse referents are the things under discussion in the discourse, 
#and they correspond to the individual variables of first-order logic. 

#The DRS conditions apply to those discourse referents, 
#and correspond to atomic open formulas of first-order logic


##Building a DRS; 
#the DRS on the left hand side represents the result of processing the first sentence in the discourse, 
#while the DRS on the right hand side shows the effect of processing the second sentence and integrating its content.
 
 Angus owns a dog           Angus owns a dog, it bit Irene  
                                                
 x y                        x y u z                 
 ------                     ------              
 Angus(x)                   Angus(x)            
 dog(y)                     dog(y)              
 own(x,y)                   own(x,y)            
                            u = y
                            Irene(z)
                            bite(u,z)
 
#in NLTK, 
>>> read_dexpr = nltk.sem.DrtExpression.fromstring
>>> drs1 = read_dexpr('([x, y], [angus(x), dog(y), own(x, y)])') 
>>> print(drs1)
([x,y],[angus(x), dog(y), own(x,y)])
 
#to visualize the result
>>> drs1.draw()
 
 
#every DRS can be translated into a formula of first-order logic, 
#the fol() method implements this translation.
>>> print(drs1.fol())
exists x y.(angus(x) & dog(y) & own(x,y))
 
 

#In addition to the functionality available for first-order logic expressions, 
#DRT Expressions have a DRS-concatenation operator, represented as the + symbol. 

#The concatenation of two DRSs is a single DRS containing 
#the merged discourse referents and the conditions from both arguments.

#DRS-concatenation automatically alpha-converts bound variables to avoid name-clashes.

>>> drs2 = read_dexpr('([x], [walk(x)]) + ([y], [run(y)])')
>>> print(drs2)
(([x],[walk(x)]) + ([y],[run(y)]))
>>> print(drs2.simplify())
([x,y],[walk(x), run(y)])
 
 
#it is possible to embed one DRS within another, 
#and this is how universal quantification is handled. 
>>> drs3 = read_dexpr('([], [(([x], [dog(x)]) -> ([y],[ankle(y), bite(x, y)]))])')
>>> print(drs3.fol())
all x.(dog(x) -> exists y.(ankle(y) & bite(x,y)))
 
 

#DRT is designed to allow anaphoric pronouns to be interpreted by linking to existing discourse referents. 
#if the DRS contains a condition of the form PRO(x), 
#the method resolve_anaphora() replaces this 
#with a condition of the form x = [...], where [...] is a list of possible antecedents.

>>> drs4 = read_dexpr('([x, y], [angus(x), dog(y), own(x, y)])')
>>> drs5 = read_dexpr('([u, z], [PRO(u), irene(z), bite(u, z)])')
>>> drs6 = drs4 + drs5
>>> print(drs6.simplify())
([u,x,y,z],[angus(x), dog(y), own(x,y), PRO(u), irene(z), bite(u,z)])
>>> print(drs6.simplify().resolve_anaphora())
([u,x,y,z],[angus(x), dog(y), own(x,y), (u = [x,y,z]), irene(z), bite(u,z)])
 
 

#to build compositional semantic representations which are based on DRT 
#rather than first-order logic
Det[num=sg,SEM=<\P Q.(([x],[]) + P(x) + Q(x))>] -> 'a'
Det[num=sg,SEM=<\P Q.(([x],[]) + P(x) + Q(x))>] -> 'a'
Det[num=sg,SEM=<\P Q. exists x.(P(x) & Q(x))>] -> 'a'


#To get a better idea of how the DRT rule works, 
#look at this subtree for the NP a dog.
(NP[num='sg', SEM=<\Q.(([x],[dog(x)]) + Q(x))>]
  (Det[num='sg', SEM=<\P Q.((([x],[]) + P(x)) + Q(x))>] a)
  (Nom[num='sg', SEM=<\x.([],[dog(x)])>]
    (N[num='sg', SEM=<\x.([],[dog(x)])>] dog)))))



#In order to parse with grammar drt.fcfg

>>> from nltk import load_parser
>>> nltk.data.show_cfg('grammars/book_grammars/drt.fcfg')
% start S
# Grammar Rules
S[SEM = <app(?subj,?vp)>] -> NP[NUM=?n,SEM=?subj] VP[NUM=?n,SEM=?vp]
NP[NUM=?n,SEM=<app(?det,?nom)> ] -> Det[NUM=?n,SEM=?det]  Nom[NUM=?n,SEM=?nom]
NP[LOC=?l,NUM=?n,SEM=?np] -> PropN[LOC=?l,NUM=?n,SEM=?np]
Nom[NUM=?n,SEM=?nom] -> N[NUM=?n,SEM=?nom]
Nom[NUM=?n,SEM=<app(?pp,?nom)>] -> N[NUM=?n,SEM=?nom] PP[SEM=?pp]
VP[NUM=?n,SEM=?v] -> IV[NUM=?n,SEM=?v]
VP[NUM=?n,SEM=<app(?v,?obj)>] -> TV[NUM=?n,SEM=?v] NP[SEM=?obj]
# Lexical Rules
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Angus(x)])+P(x))>] -> 'Angus'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Irene(x)])+P(x))>] -> 'Irene'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[John(x)])+P(x))>] -> 'John'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Mary(x)])+P(x))>] -> 'Mary'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Suzie(x)])+P(x))>] -> 'Suzie'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Vincent(x)])+P(x))>] -> 'Vincent'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Mia(x)])+P(x))>] -> 'Mia'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Marsellus(x)])+P(x))>] -> 'Marsellus'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[Fido(x)])+P(x))>] -> 'Fido'
PropN[+LOC,NUM=sg,SEM=<\P.(DRS([x],[Noosa(x)])+P(x))>] -> 'Noosa'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[PRO(x)])+P(x))>] -> 'he'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[PRO(x)])+P(x))>] -> 'she'
PropN[-LOC,NUM=sg,SEM=<\P.(DRS([x],[PRO(x)])+P(x))>] -> 'it'
Det[NUM=sg,SEM=<\P Q.DRS([],[((DRS([x],[])+P(x)) implies Q(x))])>] ->'every' | 'Every'
Det[NUM=pl,SEM=<\P Q.DRS([],[((DRS([x],[])+P(x)) implies Q(x))])>] ->'all' | 'All'
Det[SEM=<\P Q.((DRS([x],[])+P(x))+Q(x))>] -> 'some' | 'Some'
Det[NUM=sg,SEM=<\P Q.((DRS([x],[])+P(x))+Q(x))>] -> 'a' | 'A'
Det[NUM=sg,SEM=<\P Q.(not ((DRS([x],[])+P(x))+Q(x)))>] -> 'no' | 'No'
N[NUM=sg,SEM=<\x.DRS([],[boy(x)])>] -> 'boy'
N[NUM=pl,SEM=<\x.DRS([],[boy(x)])>] -> 'boys'
N[NUM=sg,SEM=<\x.DRS([],[girl(x)])>] -> 'girl'
N[NUM=pl,SEM=<\x.DRS([],[girl(x)])>] -> 'girls'
N[NUM=sg,SEM=<\x.DRS([],[dog(x)])>] -> 'dog'
N[NUM=pl,SEM=<\x.DRS([],[dog(x)])>] -> 'dogs'
N[NUM=sg,SEM=<\x.DRS([],[student(x)])>] -> 'student'
N[NUM=pl,SEM=<\x.DRS([],[student(x)])>] -> 'students'
N[NUM=sg,SEM=<\x.DRS([],[person(x)])>] -> 'person'
N[NUM=pl,SEM=<\x.DRS([],[person(x)])>] -> 'persons'
N[NUM=sg,SEM=<\x.DRS([],[boxerdog(x)])>] -> 'boxer'
N[NUM=pl,SEM=<\x.DRS([],[boxerdog(x)])>] -> 'boxers'
N[NUM=sg,SEM=<\x.DRS([],[boxer(x)])>] -> 'boxer'
N[NUM=pl,SEM=<\x.DRS([],[boxer(x)])>] -> 'boxers'
N[NUM=sg,SEM=<\x.DRS([],[garden(x)])>] -> 'garden'
N[NUM=sg,SEM=<\x.DRS([],[kitchen(x)])>] -> 'kitchen'
IV[NUM=sg,SEM=<\x.DRS([],[bark(x)])>,tns=pres] -> 'barks'
IV[NUM=pl,SEM=<\x.DRS([],[bark(x)])>,tns=pres] -> 'bark'
IV[NUM=sg,SEM=<\x.DRS([],[walk(x)])>,tns=pres] -> 'walks'
IV[NUM=pl,SEM=<\x.DRS([],[walk(x)])>,tns=pres] -> 'walk'
IV[NUM=pl,SEM=<\x.DRS([],[dance(x)])>,tns=pres] -> 'dance'
IV[NUM=sg,SEM=<\x.DRS([],[dance(x)])>,tns=pres] -> 'dances'
TV[NUM=sg,SEM=<\X x.X(\y.DRS([],[own(x,y)]))>,tns=pres] -> 'owns'
TV[NUM=pl,SEM=<\X x.X(\y.DRS([],[own(x,y)]))>,tns=pres] -> 'own'
TV[NUM=sg,SEM=<\X x.X(\y.DRS([],[bite(x,y)]))>,tns=pres] -> 'bites'
TV[NUM=pl,SEM=<\X x.X(\y.DRS([],[bite(x,y)]))>,tns=pres] -> 'bite'
TV[NUM=sg,SEM=<\X x.X(\y.DRS([],[chase(x,y)]))>,tns=pres] -> 'chases'
TV[NUM=pl,SEM=<\X x.X(\y.DRS([],[chase(x,y)]))>,tns=pres] -> 'chase'
TV[NUM=sg,SEM=<\X x.X(\y.DRS([],[marry(x,y)]))>,tns=pres] -> 'marries'
TV[NUM=pl,SEM=<\X x.X(\y.DRS([],[marry(x,y)]))>,tns=pres] -> 'marry'
TV[NUM=sg,SEM=<\X x.X(\y.DRS([],[know(x,y)]))>,tns=pres] -> 'knows'
TV[NUM=pl,SEM=<\X x.X(\y.DRS([],[know(x,y)]))>,tns=pres] -> 'know'
TV[NUM=sg,SEM=<\X x.X(\y.DRS([],[see(x,y)]))>,tns=pres] -> 'sees'
TV[NUM=pl,SEM=<\X x.X(\y.DRS([],[see(x,y)]))>,tns=pres] -> 'see'
>>> parser = load_parser('grammars/book_grammars/drt.fcfg', logic_parser=nltk.sem.drt.DrtParser(), trace=1)
>>> trees = list(parser.parse('Angus owns a dog'.split()))
|.Ang.own. a .dog.|
|[---]   .   .   .| [0:1] 'Angus'
|.   [---]   .   .| [1:2] 'owns'
|.   .   [---]   .| [2:3] 'a'
|.   .   .   [---]| [3:4] 'dog'
|[---]   .   .   .| [0:1] PropN[-LOC, NUM='sg', SEM=<\P.(([x],[Angus(x)]) + P(x))>] -> 'Angus' *
|[---]   .   .   .| [0:1] NP[-LOC, NUM='sg', SEM=<\P.(([x],[Angus(x)]) + P(x))>] -> PropN[-LOC, NUM='sg', SEM=<\P.(([x],[Angus(x)]) + P(x))>] *
|[--->   .   .   .| [0:1] S[SEM=<?subj(?vp)>] -> NP[NUM=?n, SEM=?subj] * VP[NUM=?n, SEM=?vp] {?n: 'sg', ?subj: <DrtLambdaExpression \P.(([x],[Angus(x)]) + P(x))>}
|.   [---]   .   .| [1:2] TV[NUM='sg', SEM=<\X x.X(\y.([],[own(x,y)]))>, tns='pres'] -> 'owns' *
|.   [--->   .   .| [1:2] VP[NUM=?n, SEM=<?v(?obj)>] -> TV[NUM=?n, SEM=?v] * NP[SEM=?obj] {?n: 'sg', ?v: <DrtLambdaExpression \X x.X(\y.([],[own(x,y)]))>}
|.   .   [---]   .| [2:3] Det[NUM='sg', SEM=<\P Q.(([x],[]) + P(x) + Q(x))>] -> 'a' *
|.   .   [--->   .| [2:3] NP[NUM=?n, SEM=<?det(?nom)>] -> Det[NUM=?n,
SEM=?det] * Nom[NUM=?n, SEM=?nom] {?det: <DrtLambdaExpression \P Q.(([x],[]) + P(x) + Q(x))>, ?n: 'sg'}
|.   .   .   [---]| [3:4] N[NUM='sg', SEM=<\x.([],[dog(x)])>] -> 'dog' *
|.   .   .   [---]| [3:4] Nom[NUM='sg', SEM=<\x.([],[dog(x)])>] -> N[NUM='sg', SEM=<\x.([],[dog(x)])>] *
|.   .   .   [--->| [3:4] Nom[NUM=?n, SEM=<?pp(?nom)>] -> N[NUM=?n, SEM=?nom] * PP[SEM=?pp] {?n: 'sg', ?nom: <DrtLambdaExpression \x.([],[dog(x)])>}
|.   .   [-------]| [2:4] NP[NUM='sg', SEM=<\Q.(([x],[dog(x)]) + Q(x))>] -> Det[NUM='sg', SEM=<\P Q.(([x],[]) + P(x) + Q(x))>] Nom[NUM='sg', SEM=<\x.([],[dog(x)])>] *
|.   .   [------->| [2:4] S[SEM=<?subj(?vp)>] -> NP[NUM=?n, SEM=?subj] * VP[NUM=?n, SEM=?vp] {?n: 'sg', ?subj: <DrtLambdaExpression \Q.(([x],[dog(x)]) + Q(x))>}
|.   [-----------]| [1:4] VP[NUM='sg', SEM=<\z1.([x],[dog(x), own(z1,x)])>] -> TV[NUM='sg', SEM=<\X x.X(\y.([],[own(x,y)]))>] NP[SEM=<\Q.(([x],[dog(x)]) + Q(x))>] *
|[===============]| [0:4] S[SEM=<([x,z2],[Angus(x), dog(z2), own(x,z2)])>] -> NP[NUM='sg', SEM=<\P.(([x],[Angus(x)]) + P(x))>] VP[NUM='sg',SEM=<\z1.([x],[dog(x), own(z1,x)])>] *

>>> print(trees[0])
(S[SEM=<([x,z2],[Angus(x), dog(z2), own(x,z2)])>]
  (NP[-LOC, NUM='sg', SEM=<\P.(([x],[Angus(x)]) + P(x))>]
    (PropN[-LOC, NUM='sg', SEM=<\P.(([x],[Angus(x)]) + P(x))>] Angus))
  (VP[NUM='sg', SEM=<\z1.([x],[dog(x), own(z1,x)])>]
    (TV[NUM='sg', SEM=<\X x.X(\y.([],[own(x,y)]))>, tns='pres'] owns)
    (NP[NUM='sg', SEM=<\Q.(([x],[dog(x)]) + Q(x))>]
      (Det[NUM='sg', SEM=<\P Q.(([x],[]) + P(x) + Q(x))>] a)
      (Nom[NUM='sg', SEM=<\x.([],[dog(x)])>]
        (N[NUM='sg', SEM=<\x.([],[dog(x)])>] dog)))))
        
>>> print(trees[0].label()['SEM'].simplify())
([x,z2],[Angus(x), dog(z2), own(x,z2)])
 
 


##NLTK-Discourse Processing

#Whereas a discourse is a sequence s1, ... sn of sentences, 
#a discourse thread is a sequence s1-ri, ... sn-rj of readings, 
#one for each sentence in the discourse. 

#The nltk.inference.discourse processes sentences incrementally, 
#keeping track of all possible threads when there is ambiguity.

>>> dt = nltk.DiscourseTester(['A student dances', 'Every student is a person'])
>>> dt.readings()
s0 readings:
s0-r0: exists x.(student(x) & dance(x))
s1 readings:
s1-r0: all x.(student(x) -> person(x))
 
 

#When a new sentence is added to the current discourse, 
#setting the parameter consistchk=True causes consistency to be checked by invoking the model checker for each thread, 
#i.e., sequence of admissible readings. 

#In this case, the user has the option of retracting the sentence in question.

>>> dt.add_sentence('No person dances', consistchk=True)
Inconsistent discourse: d0 ['s0-r0', 's1-r0', 's2-r0']:
    s0-r0: exists x.(student(x) & dance(x))
    s1-r0: all x.(student(x) -> person(x))
    s2-r0: -exists x.(person(x) & dance(x))
 
>>> dt.retract_sentence('No person dances', verbose=True)
Current sentences are
s0: A student dances
s1: Every student is a person
 
 

#we use informchk=True to check whether a new sentence f is informative relative to the current discourse. 

#The theorem prover treats existing sentences in the thread as assumptions 
#and attempts to prove f; it is informative if no such proof can be found.

>>> dt.add_sentence('A person dances', informchk=True)
Sentence 'A person dances' under reading 'exists x.(person(x) & dance(x))':
Not informative relative to thread 'd0'
 
 
#The discourse module can accommodate semantic ambiguity 
#and filter out readings that are not admissible. 

#The following example invokes both Glue Semantics as well as DRT. 
#Since the Glue Semantics module is configured to use the wide-coverage Malt dependency parser, 
#the input (Every dog chases a boy. He runs.) needs to be tagged as well as tokenized.


>>> from nltk.tag import RegexpTagger
>>> tagger = RegexpTagger(
        [('^(chases|runs)$', 'VB'),
        ('^(a)$', 'ex_quant'),
        ('^(every)$', 'univ_quant'),
        ('^(dog|boy)$', 'NN'),
        ('^(He)$', 'PRP')
    ])
>>> rc = nltk.DrtGlueReadingCommand(depparser=nltk.MaltParser(tagger=tagger))
>>> dt = nltk.DiscourseTester(['Every dog chases a boy', 'He runs'], rc)
>>> dt.readings()

s0 readings:

s0-r0: ([],[(([x],[dog(x)]) -> ([z3],[boy(z3), chases(x,z3)]))])
s0-r1: ([z4],[boy(z4), (([x],[dog(x)]) -> ([],[chases(x,z4)]))])

s1 readings:

s1-r0: ([x],[PRO(x), runs(x)])
 
 
#The first sentence of the discourse has two possible readings, 
#depending on the quantfier scoping. 
#The unique reading of the second sentence represents the pronoun 
#He via the condition PRO(x)`. Now let's look at the discourse threads that result:

>>> dt.readings(show_thread_readings=True)
d0: ['s0-r0', 's1-r0'] : INVALID: AnaphoraResolutionException
d1: ['s0-r1', 's1-r0'] : ([z6,z10],[boy(z6), (([x],[dog(x)]) ->
([],[chases(x,z6)])), (z10 = z6), runs(z10)])
 
 
#Inadmissible readings can be filtered out by passing the parameter filter=True.
>>> dt.readings(show_thread_readings=True, filter=True)
d1: ['s0-r1', 's1-r0'] : ([z12,z15],[boy(z12), (([x],[dog(x)]) ->
([],[chases(x,z12)])), (z17 = z12), runs(z15)])
 
 

 
 
 
###NLTK - Quick summary of  Semantics
  
>>> import nltk
>>> from nltk.sem import Valuation, Model
>>> v = [('adam', 'b1'), ('betty', 'g1'), ('fido', 'd1'),
    ('girl', set(['g1', 'g2'])), ('boy', set(['b1', 'b2'])),
    ('dog', set(['d1'])),
    ('love', set([('b1', 'g1'), ('b2', 'g2'), ('g1', 'b1'), ('g2', 'b1')]))]
    
    
#Valuation: Keys are strings representing the constants to be interpreted, 
#and values correspond to individuals (represented as strings) and n-ary relations (represented as sets of tuples of strings)
>>> val = Valuation(v)  #Bases: dict 
>>> dom = val.domain #{'g1', 'b1', 'd1', 'b2', 'g2'}

     
>>> m = Model(dom, val)
#Evaluation
>>> dom = val.domain
#Assignment(domain, assign=None), Bases: dict
#A variable Assignment is a mapping from individual variables to entities in the domain
>>> g = nltk.sem.Assignment(dom)
>>> m.evaluate('all x.(boy(x) -> - girl(x))', g)
True
#evaluate() calls a recursive function satisfy(), 
#which in turn calls a function i() to interpret non-logical constants and individual variables. 
#i() delegates the interpretation of these to the the model's Valuation and the variable assignment g respectively. 
'''
satisfy(parsed, g, trace=None)
    Recursive interpretation function for a formula of first-order logic.
    Raises an Undefined error when parsed is an atomic string but is not a symbol or an individual variable.
    Returns a truth value or Undefined if parsed is complex, and calls the interpretation function i if parsed is atomic.
 
'''
>>> m.evaluate('walk(adam)', g, trace=2)
<BLANKLINE>
'walk(adam)' is undefined under M, g
'Undefined'



##Batch Processing

#use interpret_sents() and evaluate_sents() are for  multiple sentences. 

>>> sents = ['Mary walks']
'''
nltk.sem.util.interpret_sents(inputs, grammar, semkey='SEM', trace=0)
    Add the semantic representation to each syntactic parse tree of each input sentence

'''
>>> results = nltk.sem.util.interpret_sents(sents, 'grammars/sample_grammars/sem2.fcfg')
>>> for result in results:
        for (synrep, semrep) in result:
            print(synrep)
(S[SEM=<walk(mary)>]
  (NP[-LOC, NUM='sg', SEM=<\P.P(mary)>]
    (PropN[-LOC, NUM='sg', SEM=<\P.P(mary)>] Mary))
  (VP[NUM='sg', SEM=<\x.walk(x)>]
    (IV[NUM='sg', SEM=<\x.walk(x)>, TNS='pres'] walks)))


#backwards compatibility with 'legacy' grammars 
#where the semantics value is specified with a lowercase sem feature, 
#the relevant feature name can be passed to the function using the semkey parameter

>>> sents = ['raining']
>>> g = nltk.grammar.FeatureGrammar.fromstring("""
    % start S
    S[sem=<raining>] -> 'raining'
    """)

>>> results = nltk.sem.util.interpret_sents(sents, g, semkey='sem')
>>> for result in results:
        for (synrep, semrep) in result:
            print(semrep)
raining



##tests for relations and valuations

>>> from nltk.sem import *

#Relations are sets of tuples, all of the same length.
>>> s1 = set([('d1', 'd2'), ('d1', 'd1'), ('d2', 'd1')])
>>> is_rel(s1)
True
>>> s2 = set([('d1', 'd2'), ('d1', 'd2'), ('d1',)])
>>> is_rel(s2)
Traceback (most recent call last):
  . . .
ValueError: Set set([('d1', 'd2'), ('d1',)]) contains sequences of different lengths

>>> s3 = set(['d1', 'd2'])
>>> is_rel(s3)
Traceback (most recent call last):
  . . .
ValueError: Set set(['d2', 'd1']) contains sequences of different lengths
>>> s4 = set2rel(s3)
>>> is_rel(s4)
True
>>> is_rel(set())
True
>>> null_binary_rel = set([(None, None)])
>>> is_rel(null_binary_rel)
True




#Predication is evaluated by set membership.
>>> ('d1', 'd2') in s1
True
>>> ('d2', 'd2') in s1
False
>>> ('d1',) in s1
False
>>> 'd2' in s1
False
>>> ('d1',) in s4
True
>>> ('d1',) in set()
False
>>> 'd1' in  null_binary_rel
False

#Valuation is key vs relation or individual
>>> val = Valuation([('Fido', 'd1'), ('dog', set(['d1', 'd2'])), ('walk', set())])
>>> sorted(val['dog'])
[('d1',), ('d2',)]
>>> val.domain == set(['d1', 'd2'])
True
>>> print(val.symbols)
['Fido', 'dog', 'walk']


#Parse a valuation from a string.
>>> v = """
    john => b1
    mary => g1
    suzie => g2
    fido => d1
    tess => d2
    noosa => n
    girl => {g1, g2}
    boy => {b1, b2}
    dog => {d1, d2}
    bark => {d1, d2}
    walk => {b1, g2, d1}
    chase => {(b1, g1), (b2, g1), (g1, d1), (g2, d2)}
    see => {(b1, g1), (b2, d2), (g1, b1),(d2, b1), (g2, n)}
    in => {(b1, n), (b2, n), (d2, n)}
    with => {(b1, g1), (g1, b1), (d1, b1), (b1, d1)}
    """
>>> val = Valuation.fromstring(v)

>>> print(val) # doctest: +SKIP
{'bark': set([('d1',), ('d2',)]),
 'boy': set([('b1',), ('b2',)]),
 'chase': set([('b1', 'g1'), ('g2', 'd2'), ('g1', 'd1'), ('b2', 'g1')]),
 'dog': set([('d1',), ('d2',)]),
 'fido': 'd1',
 'girl': set([('g2',), ('g1',)]),
 'in': set([('d2', 'n'), ('b1', 'n'), ('b2', 'n')]),
 'john': 'b1',
 'mary': 'g1',
 'noosa': 'n',
 'see': set([('b1', 'g1'), ('b2', 'd2'), ('d2', 'b1'), ('g2', 'n'), ('g1', 'b1')]),
 'suzie': 'g2',
 'tess': 'd2',
 'walk': set([('d1',), ('b1',), ('g2',)]),
 'with': set([('b1', 'g1'), ('d1', 'b1'), ('b1', 'd1'), ('g1', 'b1')])}



#Model is (domain, Valuation)
#Assignment is (domain, assignment_as_dict_key_as_variableName)
>>> v = [('adam', 'b1'), ('betty', 'g1'), ('fido', 'd1'),\
        ('girl', set(['g1', 'g2'])), ('boy', set(['b1', 'b2'])), ('dog', set(['d1'])),
        ('love', set([('b1', 'g1'), ('b2', 'g2'), ('g1', 'b1'), ('g2', 'b1')])),
        ('kiss', null_binary_rel)]
        
>>> val = Valuation(v)
>>> dom = val.domain

>>> m = Model(dom, val)
>>> g = Assignment(dom)
>>> sorted(val['boy'])
[('b1',), ('b2',)]
>>> ('b1',) in val['boy']
True
>>> ('g1',) in val['boy']
False
>>> ('foo',) in val['boy']
False
>>> ('b1', 'g1') in val['love']
True
>>> ('b1', 'b1') in val['kiss']
False
>>> sorted(val.domain)
['b1', 'b2', 'd1', 'g1', 'g2']



#Model Tests-Extension of Lambda expressions
>>> v0 = [('adam', 'b1'), ('betty', 'g1'), ('fido', 'd1'),\
        ('girl', set(['g1', 'g2'])), ('boy', set(['b1', 'b2'])),
        ('dog', set(['d1'])),
        ('love', set([('b1', 'g1'), ('b2', 'g2'), ('g1', 'b1'), ('g2', 'b1')]))]

>>> val0 = Valuation(v0)
>>> dom0 = val0.domain
>>> m0 = Model(dom0, val0)
>>> g0 = Assignment(dom0)
'''
evaluate(expr, g, trace=None)
    Read input expressions and evaluate
'''
>>> print(m0.evaluate(r'\x. \y. love(x, y)', g0) == {'g2': {'g2': False, 'b2': False, 'b1': True, 'g1': False, 'd1': False}, 'b2': {'g2': True, 'b2': False, 'b1': False, 'g1': False, 'd1': False}, 'b1': {'g2': False, 'b2': False, 'b1': False, 'g1': True, 'd1': False}, 'g1': {'g2': False, 'b2': False, 'b1': True, 'g1': False, 'd1': False}, 'd1': {'g2': False, 'b2': False, 'b1': False, 'g1': False, 'd1': False}})
True
>>> print(m0.evaluate(r'\x. dog(x) (adam)', g0))
False
>>> print(m0.evaluate(r'\x. (dog(x) | boy(x)) (adam)', g0))
True
>>> print(m0.evaluate(r'\x. \y. love(x, y)(fido)', g0) == {'g2': False, 'b2': False, 'b1': False, 'g1': False, 'd1': False})
True
>>> print(m0.evaluate(r'\x. \y. love(x, y)(adam)', g0) == {'g2': False, 'b2': False, 'b1': False, 'g1': True, 'd1': False})
True
>>> print(m0.evaluate(r'\x. \y. love(x, y)(betty)', g0) == {'g2': False, 'b2': False, 'b1': True, 'g1': False, 'd1': False})
True
>>> print(m0.evaluate(r'\x. \y. love(x, y)(betty)(adam)', g0))
True
>>> print(m0.evaluate(r'\x. \y. love(x, y)(betty, adam)', g0))
True
>>> print(m0.evaluate(r'\y. \x. love(x, y)(fido)(adam)', g0))
False
>>> print(m0.evaluate(r'\y. \x. love(x, y)(betty, adam)', g0))
True
>>> print(m0.evaluate(r'\x. exists y. love(x, y)', g0) == {'g2': True, 'b2': True, 'b1': True, 'g1': True, 'd1': False})
True
>>> print(m0.evaluate(r'\z. adam', g0) == {'g2': 'b1', 'b2': 'b1', 'b1': 'b1', 'g1': 'b1', 'd1': 'b1'})
True
>>> print(m0.evaluate(r'\z. love(x, y)', g0) == {'g2': False, 'b2': False, 'b1': False, 'g1': False, 'd1': False})
True



#Propositional Model Test
>>> tests = [
        ('P & Q', True),
        ('P & R', False),
        ('- P', False),
        ('- R', True),
        ('- - P', True),
        ('- (P & R)', True),
        ('P | R', True),
        ('R | P', True),
        ('R | R', False),
        ('- P | R', False),
        ('P | - P', True),
        ('P -> Q', True),
        ('P -> R', False),
        ('R -> P', True),
        ('P <-> P', True),
        ('R <-> R', True),
        ('P <-> R', False),
        ]
>>> val1 = Valuation([('P', True), ('Q', True), ('R', False)])
>>> dom = set([])
>>> m = Model(dom, val1)
>>> g = Assignment(dom)

>>> for (sent, testvalue) in tests:
        semvalue = m.evaluate(sent, g)
        if semvalue == testvalue:
            print('*', end=' ')


#Test of i Function
'''
i(parsed, g, trace=False)
    An interpretation function.
    Assuming that parsed is atomic:
        if parsed is a non-logical constant, calls the valuation V
        else if parsed is an individual variable, calls assignment g
        else returns Undefined.
'''

>>> from nltk.sem import Expression
>>> v = [('adam', 'b1'), ('betty', 'g1'), ('fido', 'd1'),
        ('girl', set(['g1', 'g2'])), ('boy', set(['b1', 'b2'])), ('dog', set(['d1'])),
        ('love', set([('b1', 'g1'), ('b2', 'g2'), ('g1', 'b1'), ('g2', 'b1')]))]
>>> val = Valuation(v)
>>> dom = val.domain
>>> m = Model(dom, val)
>>> g = Assignment(dom, [('x', 'b1'), ('y', 'g2')])
>>> exprs = ['adam', 'girl', 'love', 'walks', 'x', 'y', 'z']
>>> parsed_exprs = [Expression.fromstring(e) for e in exprs]
>>> sorted_set = lambda x: sorted(x) if isinstance(x, set) else x
>>> for parsed in parsed_exprs:
        try:
            print("'%s' gets value %s" % (parsed, sorted_set(m.i(parsed, g))))
        except Undefined:
            print("'%s' is Undefined" % parsed)
'adam' gets value b1
'girl' gets value [('g1',), ('g2',)]
'love' gets value [('b1', 'g1'), ('b2', 'g2'), ('g1', 'b1'), ('g2', 'b1')]
'walks' is Undefined
'x' gets value b1
'y' gets value g2
'z' is Undefined



#Test for formulas in Model

>>> tests = [
        ('love(adam, betty)', True),
        ('love(adam, sue)', 'Undefined'),
        ('dog(fido)', True),
        ('- dog(fido)', False),
        ('- - dog(fido)', True),
        ('- dog(sue)', 'Undefined'),
        ('dog(fido) & boy(adam)', True),
        ('- (dog(fido) & boy(adam))', False),
        ('- dog(fido) & boy(adam)', False),
        ('dog(fido) | boy(adam)', True),
        ('- (dog(fido) | boy(adam))', False),
        ('- dog(fido) | boy(adam)', True),
        ('- dog(fido) | - boy(adam)', False),
        ('dog(fido) -> boy(adam)', True),
        ('- (dog(fido) -> boy(adam))', False),
        ('- dog(fido) -> boy(adam)', True),
        ('exists x . love(adam, x)', True),
        ('all x . love(adam, x)', False),
        ('fido = fido', True),
        ('exists x . all y. love(x, y)', False),
        ('exists x . (x = fido)', True),
        ('all x . (dog(x) | - dog(x))', True),
        ('adam = mia', 'Undefined'),
        ('\\x. (boy(x) | girl(x))', {'g2': True, 'b2': True, 'b1': True, 'g1': True, 'd1': False}),
        ('\\x. exists y. (boy(x) & love(x, y))', {'g2': False, 'b2': True, 'b1': True, 'g1': False, 'd1': False}),
        ('exists z1. boy(z1)', True),
        ('exists x. (boy(x) & - (x = adam))', True),
        ('exists x. (boy(x) & all y. love(y, x))', False),
        ('all x. (boy(x) | girl(x))', False),
        ('all x. (girl(x) -> exists y. boy(y) & love(x, y))', False),
        ('exists x. (boy(x) & all y. (girl(y) -> love(y, x)))', True),
        ('exists x. (boy(x) & all y. (girl(y) -> love(x, y)))', False),
        ('all x. (dog(x) -> - girl(x))', True),
        ('exists x. exists y. (love(x, y) & love(x, y))', True),
        ]
>>> for (sent, testvalue) in tests:
        semvalue = m.evaluate(sent, g)
        if semvalue == testvalue:
            print('*', end=' ')
        else:
            print(sent, semvalue)
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *



##Satisfier Tests
'''
satisfiers(parsed, varex, g, trace=None, nesting=0)
    Generate the entities from the model’s domain that satisfy an open formula

'''
>>> formulas = [
        'boy(x)',
        '(x = x)',
        '(boy(x) | girl(x))',
        '(boy(x) & girl(x))',
        'love(adam, x)',
        'love(x, adam)',
        '- (x = adam)',
        'exists z22. love(x, z22)',
        'exists y. love(y, x)',
        'all y. (girl(y) -> love(x, y))',
        'all y. (girl(y) -> love(y, x))',
        'all y. (girl(y) -> (boy(x) & love(y, x)))',
        'boy(x) & all y. (girl(y) -> love(x, y))',
        'boy(x) & all y. (girl(y) -> love(y, x))',
        'boy(x) & exists y. (girl(y) & love(y, x))',
        'girl(x) -> dog(x)',
        'all y. (dog(y) -> (x = y))',
        '- exists y. love(y, x)',
        'exists y. (love(adam, y) & love(y, x))'
        ]
>>> g.purge()
>>> g.add('x', 'b1')
{'x': 'b1'}
>>> for f in formulas: # doctest: +NORMALIZE_WHITESPACE
        try:
            print("'%s' gets value: %s" % (f, m.evaluate(f, g)))
        except Undefined:
            print("'%s' is Undefined" % f)
'boy(x)' gets value: True
'(x = x)' gets value: True
'(boy(x) | girl(x))' gets value: True
'(boy(x) & girl(x))' gets value: False
'love(adam, x)' gets value: False
'love(x, adam)' gets value: False
'- (x = adam)' gets value: False
'exists z22. love(x, z22)' gets value: True
'exists y. love(y, x)' gets value: True
'all y. (girl(y) -> love(x, y))' gets value: False
'all y. (girl(y) -> love(y, x))' gets value: True
'all y. (girl(y) -> (boy(x) & love(y, x)))' gets value: True
'boy(x) & all y. (girl(y) -> love(x, y))' gets value: False
'boy(x) & all y. (girl(y) -> love(y, x))' gets value: True
'boy(x) & exists y. (girl(y) & love(y, x))' gets value: True
'girl(x) -> dog(x)' gets value: True
'all y. (dog(y) -> (x = y))' gets value: False
'- exists y. love(y, x)' gets value: False
'exists y. (love(adam, y) & love(y, x))' gets value: True

>>> from nltk.sem import Expression
>>> for fmla in formulas: # doctest: +NORMALIZE_WHITESPACE
        p = Expression.fromstring(fmla)
        g.purge()
        print("Satisfiers of '%s':\n\t%s" % (p, sorted(m.satisfiers(p, 'x', g))))
Satisfiers of 'boy(x)':
['b1', 'b2']
Satisfiers of '(x = x)':
['b1', 'b2', 'd1', 'g1', 'g2']
Satisfiers of '(boy(x) | girl(x))':
['b1', 'b2', 'g1', 'g2']
Satisfiers of '(boy(x) & girl(x))':
[]
Satisfiers of 'love(adam,x)':
['g1']
Satisfiers of 'love(x,adam)':
['g1', 'g2']
Satisfiers of '-(x = adam)':
['b2', 'd1', 'g1', 'g2']
Satisfiers of 'exists z22.love(x,z22)':
['b1', 'b2', 'g1', 'g2']
Satisfiers of 'exists y.love(y,x)':
['b1', 'g1', 'g2']
Satisfiers of 'all y.(girl(y) -> love(x,y))':
[]
Satisfiers of 'all y.(girl(y) -> love(y,x))':
['b1']
Satisfiers of 'all y.(girl(y) -> (boy(x) & love(y,x)))':
['b1']
Satisfiers of '(boy(x) & all y.(girl(y) -> love(x,y)))':
[]
Satisfiers of '(boy(x) & all y.(girl(y) -> love(y,x)))':
['b1']
Satisfiers of '(boy(x) & exists y.(girl(y) & love(y,x)))':
['b1']
Satisfiers of '(girl(x) -> dog(x))':
['b1', 'b2', 'd1']
Satisfiers of 'all y.(dog(y) -> (x = y))':
['d1']
Satisfiers of '-exists y.love(y,x)':
['b2', 'd1']
Satisfiers of 'exists y.(love(adam,y) & love(y,x))':
['b1']



##Tests for mapping from syntax to semantics
#Load a valuation from a file.
'''
nltk.sem.util.parse_sents(inputs, grammar, trace=0)
    Convert input sentences into syntactic trees.
nltk.sem.util.root_semrep(syntree, semkey='SEM')
    Find the semantic representation at the root of a tree.
'''
>>> import nltk.data
>>> from nltk.sem.util import parse_sents
>>> val = nltk.data.load('grammars/sample_grammars/valuation1.val')
>>> dom = val.domain
>>> m = Model(dom, val)
>>> g = Assignment(dom)
>>> gramfile = 'grammars/sample_grammars/sem2.fcfg'
>>> inputs = ['John sees a girl', 'every dog barks']
>>> parses = parse_sents(inputs, gramfile)
>>> for sent, trees in zip(inputs, parses):
        print()
        print("Sentence: %s" % sent)
        for tree in trees:
            print("Parse:\n %s" %tree)
            print("Semantics: %s" %  root_semrep(tree))
<BLANKLINE>
Sentence: John sees a girl
Parse:
 (S[SEM=<exists x.(girl(x) & see(john,x))>]
  (NP[-LOC, NUM='sg', SEM=<\P.P(john)>]
    (PropN[-LOC, NUM='sg', SEM=<\P.P(john)>] John))
  (VP[NUM='sg', SEM=<\y.exists x.(girl(x) & see(y,x))>]
    (TV[NUM='sg', SEM=<\X y.X(\x.see(y,x))>, TNS='pres'] sees)
    (NP[NUM='sg', SEM=<\Q.exists x.(girl(x) & Q(x))>]
      (Det[NUM='sg', SEM=<\P Q.exists x.(P(x) & Q(x))>] a)
      (Nom[NUM='sg', SEM=<\x.girl(x)>]
        (N[NUM='sg', SEM=<\x.girl(x)>] girl)))))
Semantics: exists x.(girl(x) & see(john,x))
<BLANKLINE>
Sentence: every dog barks
Parse:
 (S[SEM=<all x.(dog(x) -> bark(x))>]
  (NP[NUM='sg', SEM=<\Q.all x.(dog(x) -> Q(x))>]
    (Det[NUM='sg', SEM=<\P Q.all x.(P(x) -> Q(x))>] every)
    (Nom[NUM='sg', SEM=<\x.dog(x)>]
      (N[NUM='sg', SEM=<\x.dog(x)>] dog)))
  (VP[NUM='sg', SEM=<\x.bark(x)>]
    (IV[NUM='sg', SEM=<\x.bark(x)>, TNS='pres'] barks)))
Semantics: all x.(dog(x) -> bark(x))

>>> sent = "every dog barks"
>>> result = nltk.sem.util.interpret_sents([sent], gramfile)[0]
>>> for (syntree, semrep) in result:
        print(syntree)
        print()
        print(semrep)
(S[SEM=<all x.(dog(x) -> bark(x))>]
  (NP[NUM='sg', SEM=<\Q.all x.(dog(x) -> Q(x))>]
    (Det[NUM='sg', SEM=<\P Q.all x.(P(x) -> Q(x))>] every)
    (Nom[NUM='sg', SEM=<\x.dog(x)>]
      (N[NUM='sg', SEM=<\x.dog(x)>] dog)))
  (VP[NUM='sg', SEM=<\x.bark(x)>]
    (IV[NUM='sg', SEM=<\x.bark(x)>, TNS='pres'] barks)))
<BLANKLINE>
all x.(dog(x) -> bark(x))

>>> result = nltk.sem.util.evaluate_sents([sent], gramfile, m, g)[0]
>>> for (syntree, semrel, value) in result:
        print(syntree)
        print()
        print(semrep)
        print()
        print(value)
(S[SEM=<all x.(dog(x) -> bark(x))>]
  (NP[NUM='sg', SEM=<\Q.all x.(dog(x) -> Q(x))>]
    (Det[NUM='sg', SEM=<\P Q.all x.(P(x) -> Q(x))>] every)
    (Nom[NUM='sg', SEM=<\x.dog(x)>]
      (N[NUM='sg', SEM=<\x.dog(x)>] dog)))
  (VP[NUM='sg', SEM=<\x.bark(x)>]
    (IV[NUM='sg', SEM=<\x.bark(x)>, TNS='pres'] barks)))
<BLANKLINE>
all x.(dog(x) -> bark(x))
<BLANKLINE>
True

>>> sents = ['Mary walks', 'John sees a dog']
>>> results = nltk.sem.util.interpret_sents(sents, 'grammars/sample_grammars/sem2.fcfg')
>>> for result in results:
        for (synrep, semrep) in result:
            print(synrep)
(S[SEM=<walk(mary)>]
  (NP[-LOC, NUM='sg', SEM=<\P.P(mary)>]
    (PropN[-LOC, NUM='sg', SEM=<\P.P(mary)>] Mary))
  (VP[NUM='sg', SEM=<\x.walk(x)>]
    (IV[NUM='sg', SEM=<\x.walk(x)>, TNS='pres'] walks)))
(S[SEM=<exists x.(dog(x) & see(john,x))>]
  (NP[-LOC, NUM='sg', SEM=<\P.P(john)>]
    (PropN[-LOC, NUM='sg', SEM=<\P.P(john)>] John))
  (VP[NUM='sg', SEM=<\y.exists x.(dog(x) & see(y,x))>]
    (TV[NUM='sg', SEM=<\X y.X(\x.see(y,x))>, TNS='pres'] sees)
    (NP[NUM='sg', SEM=<\Q.exists x.(dog(x) & Q(x))>]
      (Det[NUM='sg', SEM=<\P Q.exists x.(P(x) & Q(x))>] a)
      (Nom[NUM='sg', SEM=<\x.dog(x)>]
        (N[NUM='sg', SEM=<\x.dog(x)>] dog)))))



##Cooper Storage- Dealing with  Quantifier Ambiguity 
'''
nltk.sem.cooper_storage.parse_with_bindops(sentence, grammar=None, trace=0)
    Use a grammar with Binding Operators to parse a sentence.

'''
>>> from nltk.sem import cooper_storage as cs
>>> sentence = 'every girl chases a dog'
>>> trees = cs.parse_with_bindops(sentence, grammar='grammars/book_grammars/storage.fcfg')
>>> semrep = trees[0].label()['SEM']
>>> cs_semrep = cs.CooperStore(semrep)
>>> print(cs_semrep.core)
chase(z2,z4)
>>> for bo in cs_semrep.store:
        print(bo)
bo(\P.all x.(girl(x) -> P(x)),z2)
bo(\P.exists x.(dog(x) & P(x)),z4)
'''
s_retrieve(trace=False)
    Carry out S-Retrieval of binding operators in store. If hack=True, serialize the bindop and core as strings and reparse. Ugh.
    Each permutation of the store (i.e. list of binding operators) is taken to be a possible scoping of quantifiers. We iterate through the binding operators in each permutation, and successively apply them to the current term, starting with the core semantic representation, working from the inside out.
    Binding operators are of the form:
    bo(\P.all x.(man(x) -> P(x)),z1)

'''
>>> cs_semrep.s_retrieve(trace=True)
Permutation 1
   (\P.all x.(girl(x) -> P(x)))(\z2.chase(z2,z4))
   (\P.exists x.(dog(x) & P(x)))(\z4.all x.(girl(x) -> chase(x,z4)))
Permutation 2
   (\P.exists x.(dog(x) & P(x)))(\z4.chase(z2,z4))
   (\P.all x.(girl(x) -> P(x)))(\z2.exists x.(dog(x) & chase(z2,x)))

>>> for reading in cs_semrep.readings:
        print(reading)
exists x.(dog(x) & all z3.(girl(z3) -> chase(z3,x)))
all x.(girl(x) -> exists z4.(dog(z4) & chase(x,z4)))

 
 

###+++ LDA and display of LDA - using spacy, nltk, gensim and pyLDAvis
$ pip install pyLDAvis

#Latent Dirichlet Allocation (LDA)- topic modelling technique
#Given a document, we can find it's topic(relevance) based on corpora, dictionary 


##Step-1 - Text Cleaning

import spacy
spacy.load('en')
from spacy.lang.en import English
parser = English()

def tokenize(text):
    lda_tokens = []
    tokens = parser(text)
    for token in tokens:
        if token.orth_.isspace():
            continue
        elif token.like_url:
            lda_tokens.append('URL')
        elif token.orth_.startswith('@'):
            lda_tokens.append('SCREEN_NAME')
        else:
            lda_tokens.append(token.lower_)
    return lda_tokens

#use NLTK's Wordnet(a corpora) to find the meanings of words, synonyms, antonyms, and more. 
import nltk
nltk.download('wordnet')

from nltk.corpus import wordnet as wn
def get_lemma(word):
    lemma = wn.morphy(word)
    if lemma is None:
        return word
    else:
        return lemma
        
#Or use below (WordNetLemmatizer to get the root word)
from nltk.stem.wordnet import WordNetLemmatizer
def get_lemma2(word):
    return WordNetLemmatizer().lemmatize(word)

#Filter out stop words:
nltk.download('stopwords')
en_stop = set(nltk.corpus.stopwords.words('english'))

#Then full processing 

def prepare_text_for_lda(text):
    tokens = tokenize(text)
    tokens = [token for token in tokens if len(token) > 4]
    tokens = [token for token in tokens if token not in en_stop]
    tokens = [get_lemma(token) for token in tokens]
    return tokens

#Create list of tokens 

import random
text_data = []
with open('tobeShared/data/dataset.csv') as f:
    for line in f:
        tokens = prepare_text_for_lda(line)
        text_data.append(tokens)

        
        
##STEP-2: LDA with Gensim

#Then build our corpora and dictionary 
from gensim import corpora
dictionary = corpora.Dictionary(text_data)
corpus = [dictionary.doc2bow(text) for text in text_data]

#for later use 
dictionary.save('dictionary.gensim')
corpora.MmCorpus.serialize('corpus.gensim.mm', corpus) 




#Train LDA for 5 topics

import gensim
NUM_TOPICS = 5
ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics = NUM_TOPICS,
        id2word=dictionary, passes=15)
ldamodel.save('model5.gensim')


topics = ldamodel.print_topics(num_words=4)
for topic in topics:
    print(topic)
#Eg Topic 0 includes words like 'processor', "database", "issue" and "overview",
#and so-on 
(0, '0.034*"processor" + 0.019*"database" + 0.019*"issue" + 0.019*"overview"')
(1, '0.051*"computer" + 0.028*"design" + 0.028*"graphics" + 0.028*"gallery"')
(2, '0.050*"management" + 0.027*"object" + 0.027*"circuit" + 0.027*"efficient"')
(3, '0.019*"cognitive" + 0.019*"radio" + 0.019*"network" + 0.019*"distribute"')
(4, '0.029*"circuit" + 0.029*"system" + 0.029*"rigorous" + 0.029*"integration"')

#Find topics for  new document:

new_doc = 'Practical Bayesian Optimization of Machine Learning Algorithms'
new_doc = prepare_text_for_lda(new_doc)
new_doc_bow = dictionary.doc2bow(new_doc)
print(new_doc_bow)  #[(38, 1), (117, 1)]
print(ldamodel.get_document_topics(new_doc_bow))
#[(0, 0.06669136), (1, 0.40170625), (2, 0.06670282), (3, 0.39819494), (4, 0.066704586)]
#Topic 1 relevance is 0.40170625 , so on and so forth 

#Train LDA for 3 topics

ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics = 3, id2word=dictionary, passes=15)
ldamodel.save('model3.gensim')
topics = ldamodel.print_topics(num_words=4)
for topic in topics:
    print(topic)
#
(0, '0.029*"processor" + 0.016*"management" + 0.016*"aid" + 0.016*"algorithm"')
(1, '0.026*"radio" + 0.026*"network" + 0.026*"cognitive" + 0.026*"efficient"')
(2, '0.029*"circuit" + 0.029*"distribute" + 0.016*"database" + 0.016*"management"')

#Train LDA for 10 topics

ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics = 10, id2word=dictionary, passes=15)
ldamodel.save('model10.gensim')
topics = ldamodel.print_topics(num_words=4)
for topic in topics:
    print(topic)
#
(0, '0.055*"database" + 0.055*"system" + 0.029*"technical" + 0.029*"recursive"')
(1, '0.038*"distribute" + 0.038*"graphics" + 0.038*"regenerate" + 0.038*"exact"')
(2, '0.055*"management" + 0.029*"multiversion" + 0.029*"reference" + 0.029*"document"')
(3, '0.046*"circuit" + 0.046*"object" + 0.046*"generation" + 0.046*"transformation"')
(4, '0.008*"programming" + 0.008*"circuit" + 0.008*"network" + 0.008*"surface"')
(5, '0.061*"radio" + 0.061*"cognitive" + 0.061*"network" + 0.061*"connectivity"')
(6, '0.085*"programming" + 0.008*"circuit" + 0.008*"subdivision" + 0.008*"management"')
(7, '0.041*"circuit" + 0.041*"design" + 0.041*"processor" + 0.041*"instruction"')
(8, '0.055*"computer" + 0.029*"efficient" + 0.029*"channel" + 0.029*"cooperation"')
(9, '0.061*"stimulation" + 0.061*"sensor" + 0.061*"retinal" + 0.061*"pixel"')

##STEP3: Display 
#pyLDAvis is designed to help users interpret the topics in a topic model 
#an interactive web-based visualization.

#Visualizing 5 topics:

dictionary = corpora.Dictionary.load('dictionary.gensim')
corpus = corpora.MmCorpus('corpus.gensim.mm')
lda = gensim.models.ldamodel.LdaModel.load('model5.gensim')

import pyLDAvis.gensim
lda_display = pyLDAvis.gensim.prepare(lda, corpus, dictionary, sort_topics=False)
pyLDAvis.display(lda_display)

#Understanding 
Saliency
    a measure of how much the term tells you about the topic.
Relevance
    a weighted average of the probability of the word given the topic 
    and the word given the topic normalized by the probability of the topic.
Size of the bubble
    The size of the bubble measures the importance of the topics, relative to the data.

#Visualizing 3 topics:
lda3 = gensim.models.ldamodel.LdaModel.load('model3.gensim')
lda_display3 = pyLDAvis.gensim.prepare(lda3, corpus, dictionary, sort_topics=False)
pyLDAvis.display(lda_display3)

#Visualizing 10 topics:
lda10 = gensim.models.ldamodel.LdaModel.load('model10.gensim')
lda_display10 = pyLDAvis.gensim.prepare(lda10, corpus, dictionary, sort_topics=False)
pyLDAvis.display(lda_display10)







##build several estimators independently and then to average their predictions.
#Both increases slight bias, but decreases variance because of averaging 
BaggingClassifier ,BaggingRegressor
    User to specify another estimator eg, DecisionTreeRegressor, KNeighborsClassifier
    Algorithm uses this estimator to build many models 
    based on subset of feature and sample (max_samples and max_features)
    and where boostrap(sample with replacement) is on or off by 
    bootstrap and bootstrap_features
    Mention how many estimators to build by n_estimators
    And oob_score = True Whether to use out-of-bag samples to estimate the generalization error.
    Attributes Include 
        base_estimator_ :  The base estimator from which the ensemble is grown.
        estimators_ : list of estimators, The collection of fitted base estimators.
        classes_ : array of shape = [n_classes] The classes labels.
        n_classes_ : int or list The number of classes.
        oob_score_ : float    Score of the training dataset obtained using an out-of-bag estimate.
RandomForestClassifier , RandomForestRegressor 
ExtraTreesClassifier , ExtraTreesRegressor 
   ensemble of randomized decision trees  is built 
   from samples drawn with replacement(bootstrapping on) from training set
   (default on for RF, default off for ET)
   when splitting a node during the construction of the tree
   (instead of choosing best split among all features- original DT)
   They choose best split among a random subset of the feature
   RandomForest - which tests all possible splits over fraction of features
   ExtraTree - which tests random splits over fraction of features
   Causing further reduction of variance(with more increase of bias)
   RFs are often more compact than ETs. 
   ETs are generally cheaper to train from a computational point of view 
   but can grow much bigger. 
   ETs can sometime generalize better than RFs
   How many tree are built - n_estimators
   What is feature subset - max_features
   Grid search max_features, n_estimators
   but for classification max_features=sqrt(n_features)
   and for regression , max_features=n_features
   Use max_depth=None in combination with min_samples_split=2
   (all DT configurations can be used, but these leads to unpruned tree)
   If bootstrap is on , oob_score = True Whether to use out-of-bag samples to estimate the generalization error.
Attributes Include 
    estimators_ : list of DT, The collection of fitted base estimators.
    classes_ : array of shape = [n_classes] The classes labels.
    n_classes_ : int or list The number of classes.
    oob_score_ : float    Score of the training dataset obtained using an out-of-bag estimate.
    feature_importances_ : array of shape = [n_features]
    Return the feature importances (the higher, the more important the feature).

##Quick Example of Baggin and RF, ET 
#Real world data set 
#http://archive.ics.uci.edu/ml/datasets/Covertype
#The samples in this dataset correspond to 30×30m patches of forest in the US, collected for the task of predicting each patch’s cover type, i.e. the dominant species of tree
Classes 	7
Samples total 	581012
Dimensionality 	54
Features 	int
##code 
import time 
data = fetch_covtype()

X, y = data.data, data.target 


st = time.time()
clf1 = DecisionTreeClassifier(max_depth=None, min_samples_split=2)
scores = cross_val_score(clf1, X, y, cv=StratifiedKFold(n_splits=5,shuffle=True)) 
print("Accuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.94 (+/- 0.00) and time=76 sec

st = time.time()
clf2 = BaggingClassifier(clf1, max_samples=0.5, max_features=0.5)
scores = cross_val_score(clf2, X, y, cv=StratifiedKFold(n_splits=5,shuffle=True)) 
print("Accuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.90 (+/- 0.07) and time=164 sec

st = time.time()
clf = RandomForestClassifier(n_estimators=100, max_features = np.sqrt(54).astype(int), max_depth=None,min_samples_split=2)
scores = cross_val_score(clf, X, y, cv=StratifiedKFold(n_splits=5,shuffle=True)) 
print("Accuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.96 (+/- 0.00) and time=1057 sec

st = time.time()
clf = ExtraTreesClassifier(n_estimators=10,max_features = np.sqrt(54).astype(int), max_depth=None,min_samples_split=2)
scores = cross_val_score(clf, X, y, cv=StratifiedKFold(n_splits=5,shuffle=True)) 
print("Accuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.94 (+/- 0.00) and time=89 sec

#for Completion sake 
st = time.time()
clf =  GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=1, random_state=0)
scores = cross_val_score(clf, X, y, cv=StratifiedKFold(n_splits=5,shuffle=True)) 
print("Accuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.94 (+/- 0.00) and time=89 sec


#Ofcourse , you cn greadsearch
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
clf = ExtraTreesClassifier(max_features = np.sqrt(54).astype(int), max_depth=None,min_samples_split=2)
params = dict(n_estimators= list(range(10,100,10)))
search = GridSearchCV(clf, params, cv=StratifiedKFold(n_splits=5,shuffle=True))
st = time.time()
search.fit(X_train, y_train)
search.best_params_ #{'n_estimators': 80}
print("score= train:%f test:%f and time=%d sec" % (search.score(X_train, y_train),
        search.score(X_test, y_test), (time.time()-st)))
#score= train:1.000000 test:0.951870 and time=5299 sec
  
       
       

###Feature importance 
#higher value, more important 

data = fetch_covtype()

X, y = data.data, data.target 

forest = RandomForestClassifier(n_estimators=100, max_features = np.sqrt(54).astype(int), max_depth=None,min_samples_split=2)
forest.fit(X, y)
#Higher the more important 
importances = forest.feature_importances_
#find out stddev of each feature's feature importance
std = np.std([tree.feature_importances_ for tree in forest.estimators_],axis=0) #columnwise
#Returns the indices that would sort an array.
'''
>>> x = np.array([3, 1, 2]) #
>>> np.argsort(x)
array([1, 2, 0]) #sorted array x[1], x[2], x[0]
'''
indices = np.argsort(importances)[::-1] #then reverser it, so highest is first 

# Print the feature ranking
print("Feature ranking:")

for f in range(X.shape[1]):  #1 means feature's ie 54 
    print("%d. feature %d (%f)" % (f + 1, indices[f], importances[indices[f]]))

# Plot the feature importances of the forest
plt.figure()
plt.title("Feature importances")
#yerr = is line for variation of that bar 
plt.bar(range(X.shape[1]), importances[indices],color="r", yerr=std[indices], align="center")
plt.xticks(range(X.shape[1]), indices)
plt.xlim([-1, X.shape[1]])
plt.show()     
#so important features 
1. feature 0 (0.250479)
2. feature 5 (0.119955)
3. feature 9 (0.112707)
4. feature 3 (0.060466)
5. feature 4 (0.057400)


        
###Bias Varince Tradeoff 

#This example illustrates and compares the bias-variance decomposition 
#of the expected mean squared error of a single estimator against a bagging ensemble.

#50 repetations are taken 

#univariate Regression, y = np.exp(-x ** 2) + 1.5 * np.exp(-(x - 2) ** 2)
#so X = list of x , y = corresponding value 
# Generate data
def f(x):
    x = x.ravel()
    return np.exp(-x ** 2) + 1.5 * np.exp(-(x - 2) ** 2)


def generate(n_samples, noise, n_repeat=1):
    X = np.random.rand(n_samples) * 10 - 5 #-5 to +5 uniform distribution 
    X = np.sort(X)
    if n_repeat == 1:
        y = f(X) + np.random.normal(0.0, noise, n_samples) #sd = noise, mean =0 
    else:
        y = np.zeros((n_samples, n_repeat)) #n_samples x n_repeat
        for i in range(n_repeat):
            y[:, i] = f(X) + np.random.normal(0.0, noise, n_samples)
    X = X.reshape((n_samples, 1))
    return X, y

# Settings
n_repeat = 50       # Number of iterations for computing expectations
n_train = 50        # Size of the training set
n_test = 1000       # Size of the test set
noise = 0.1         # Standard deviation of the noise
np.random.seed(0)
X_train = []
y_train = []
#X_train, y_train = 50 x (50, 1), 50 x (50,)
for i in range(n_repeat):
    X, y = generate(n_samples=n_train, noise=noise)
    X_train.append(X)  
    y_train.append(y)

X_test, y_test = generate(n_samples=n_test, noise=noise, n_repeat=n_repeat)
#X_test.shape, (1000, 1)
#y_test.shape, (1000, 50)

#Calculate bias and variance of estimators 
def calculate(name, estimator):
    # Repeat 50 times so y_predict = 1000 x 50 = y_test 
    y_predict = np.zeros((n_test, n_repeat))
    for i in range(n_repeat):
        estimator.fit(X_train[i], y_train[i])
        y_predict[:, i] = estimator.predict(X_test)
    # Bias^2 + Variance + Noise decomposition of the mean squared error
    y_error = np.zeros(n_test) #(1000,)
    #calulate  total error for each sample of y 
    #total error = sqr(actual_y - predict_y)
    #y_test = 1000x50 , y_predict= 1000x50
    #for each X_test, we get one predict_y,
    #and for that , we get 50 repetations of  actual in y_test 
    for i in range(n_repeat):
        for j in range(n_repeat):
            y_error += (y_test[:, j] - y_predict[:, i]) ** 2 #(1000,) - (1000,) = (1000,)
    y_error /= (n_repeat * n_repeat) #normalize 
    y_noise = np.var(y_test, axis=1) # rowwise , (1000,)
    y_bias = (f(X_test) - np.mean(y_predict, axis=1)) ** 2 #(1000,) = (1000,) - (1000,)
    y_var = np.var(y_predict, axis=1) # rowwise , (1000,)
    print("{0}: {1:.4f} (error) = {2:.4f} (bias^2) "
          " + {3:.4f} (var) + {4:.4f} (noise)".format(name,
                                                      np.mean(y_error),
                                                      np.mean(y_bias),
                                                      np.mean(y_var),
                                                      np.mean(y_noise)))

estimators = [("Tree", DecisionTreeRegressor()),
              ("Bagging(Tree)", BaggingRegressor(DecisionTreeRegressor())),
              ('RF', RandomForestRegressor()),
              ('ET', ExtraTreesRegressor()),
              ('Ada', AdaBoostRegressor()),
              ('GBM', GradientBoostingRegressor()),
              ('Knn', KNeighborsRegressor()),
              ('SVM', SVR()),
              ('Ridge' , RidgeCV()),
              ('Lasso', LassoCV()),
              ('elastic', ElasticNetCV()),              
              ]

for n,e in estimators:
    calculate(n,e)
              
#Output - Bagging/RT/ET - high bias, low var 
#Boosting - low bias, high var              
Tree: 0.0255 (error) = 0.0003 (bias^2)  + 0.0152 (var) + 0.0098 (noise)
Bagging(Tree): 0.0198 (error) = 0.0004 (bias^2)  + 0.0094 (var) + 0.0098 (noise)
RF: 0.0196 (error) = 0.0004 (bias^2)  + 0.0092 (var) + 0.0098 (noise)
ET: 0.0187 (error) = 0.0002 (bias^2)  + 0.0085 (var) + 0.0098 (noise)
Ada: 0.0247 (error) = 0.0025 (bias^2)  + 0.0122 (var) + 0.0098 (noise)
GBM: 0.0231 (error) = 0.0003 (bias^2)  + 0.0128 (var) + 0.0098 (noise)
Knn: 0.0210 (error) = 0.0028 (bias^2)  + 0.0082 (var) + 0.0098 (noise)
SVM: 0.0152 (error) = 0.0012 (bias^2)  + 0.0040 (var) + 0.0098 (noise)
Ridge: 0.2332 (error) = 0.2144 (bias^2)  + 0.0076 (var) + 0.0098 (noise)
Lasso: 0.2691 (error) = 0.2490 (bias^2)  + 0.0090 (var) + 0.0098 (noise)
elastic: 0.2687 (error) = 0.2487 (bias^2)  + 0.0089 (var) + 0.0098 (noise)





###AdaBoost
#Train many classifiers (e.g. decision trees) in a sequence.
#A new classifier should focus(give more weight) on those cases which were incorrectly classified in the last round.
#Combine the classifiers by letting them vote on the final prediction (like bagging).
#Each classifier is “weak” but the ensemble is “strong.”


#For multi-class classification, 
#AdaBoostClassifier implements AdaBoost-SAMME(discrete) and AdaBoost-SAMME.R(real)
#For regression, AdaBoostRegressor implements AdaBoost.R2 

#n_estimators - The number of weak learners (also no of iterations)
#By default, weak learners are decision stumps
#base_estimator - provide weak learner estimator 
#Grid search n_estimators and base estimator complexity 
#(eg its depth max_depth or minimum required number of samples to consider a split min_samples_split).
#
#The learning_rate(~1) parameter controls the contribution of the weak learners in the final combination
#Attributes 
estimators_ : list of classifiers,  The collection of fitted sub-estimators.
classes_ : array of shape = [n_classes],  The classes labels.
estimator_weights_ : array of floats, Weights for each estimator in the boosted ensemble.
estimator_errors_ : array of floats,  Classification error for each estimator in the boosted ensemble.
feature_importances_ : array of shape = [n_features], Return the feature importances (the higher, the more important the feature).


##Regression y = sinx + sin6x + normal_noise(mean=0, sd=0.1)

#plot_adaboost_regression.py
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import AdaBoostRegressor

# Create the dataset
rng = np.random.RandomState(1)
X = np.linspace(0, 6, 100)[:, np.newaxis]
y = np.sin(X).ravel() + np.sin(6 * X).ravel() + rng.normal(0, 0.1, X.shape[0])

# Fit regression model
regr_1 = DecisionTreeRegressor(max_depth=4)

regr_2 = AdaBoostRegressor(DecisionTreeRegressor(max_depth=4),n_estimators=300, random_state=rng)

regr_1.fit(X, y)
regr_2.fit(X, y)

# Predict
y_1 = regr_1.predict(X)
y_2 = regr_2.predict(X)

# Plot the results
plt.figure()
plt.scatter(X, y, c="k", label="training samples")
plt.plot(X, y_1, c="g", label="n_estimators=1", linewidth=2)
plt.plot(X, y_2, c="r", label="n_estimators=300", linewidth=2)
plt.xlabel("data")
plt.ylabel("target")
plt.title("Boosted Decision Tree Regression")
plt.legend()
plt.show()


##Ada Classification 
#The difference in performance between the discrete SAMME boosting algorithm 
#and real SAMME.R boosting algorithm. 

#Real SAMME error is better 

#target Y is a non-linear function of 10 input features

#weak learners are 400 
#The test error at each iterations(=n_estimators) 
#staged_predict method which returns a generator that yields the predictions at each stag


#plot_adaboost_hastie_10_2.py
import numpy as np
import matplotlib.pyplot as plt

from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import zero_one_loss
from sklearn.ensemble import AdaBoostClassifier


'''
Generates data for binary classification used in Hastie et al. 2009, Example 10.2.
The ten features are standard independent Gaussian and the target y is defined by:
y[i] = 1 if np.sum(X[i] ** 2) > 9.34 else -1

'''
X, y = datasets.make_hastie_10_2(n_samples=12000, random_state=1)

X_test, y_test = X[2000:], y[2000:]
X_train, y_train = X[:2000], y[:2000]

#decision stump ie one root and two teaves 
dt_stump = DecisionTreeClassifier(max_depth=1, min_samples_leaf=1)
dt_stump.fit(X_train, y_train)
dt_stump_err = 1.0 - dt_stump.score(X_test, y_test)

#DT 
dt = DecisionTreeClassifier(max_depth=9, min_samples_leaf=1)
dt.fit(X_train, y_train)
dt_err = 1.0 - dt.score(X_test, y_test)

#a boosted decision stump using AdaBoost-SAMME and AdaBoost-SAMME.R.
n_estimators = 400
# A learning rate of 1. may not be optimal for both SAMME and SAMME.R
learning_rate = 1.

ada_discrete = AdaBoostClassifier(
    base_estimator=dt_stump,
    learning_rate=learning_rate,
    n_estimators=n_estimators,
    algorithm="SAMME")
ada_discrete.fit(X_train, y_train)

ada_real = AdaBoostClassifier(
    base_estimator=dt_stump,
    learning_rate=learning_rate,
    n_estimators=n_estimators,
    algorithm="SAMME.R")
ada_real.fit(X_train, y_train)

fig = plt.figure()
ax = fig.add_subplot(111)

ax.plot([1, n_estimators], [dt_stump_err] * 2, 'k-', label='Decision Stump Error')
ax.plot([1, n_estimators], [dt_err] * 2, 'k--', label='Decision Tree Error')

ada_discrete_err = np.zeros((n_estimators,))
for i, y_pred in enumerate(ada_discrete.staged_predict(X_test)):
    #zero_one_loss = the fraction of misclassifications (float)
    ada_discrete_err[i] = zero_one_loss(y_pred, y_test)

ada_discrete_err_train = np.zeros((n_estimators,))
for i, y_pred in enumerate(ada_discrete.staged_predict(X_train)):
    ada_discrete_err_train[i] = zero_one_loss(y_pred, y_train)

ada_real_err = np.zeros((n_estimators,))
for i, y_pred in enumerate(ada_real.staged_predict(X_test)):
    ada_real_err[i] = zero_one_loss(y_pred, y_test)

ada_real_err_train = np.zeros((n_estimators,))
for i, y_pred in enumerate(ada_real.staged_predict(X_train)):
    ada_real_err_train[i] = zero_one_loss(y_pred, y_train)

ax.plot(np.arange(n_estimators) + 1, ada_discrete_err,
        label='Discrete AdaBoost Test Error',
        color='red')
ax.plot(np.arange(n_estimators) + 1, ada_discrete_err_train,
        label='Discrete AdaBoost Train Error',
        color='blue')
ax.plot(np.arange(n_estimators) + 1, ada_real_err,
        label='Real AdaBoost Test Error',
        color='orange')
ax.plot(np.arange(n_estimators) + 1, ada_real_err_train,
        label='Real AdaBoost Train Error',
        color='green')

ax.set_ylim((0.0, 0.5))
ax.set_xlabel('n_estimators')
ax.set_ylabel('error rate')

leg = ax.legend(loc='upper right', fancybox=True)
leg.get_frame().set_alpha(0.7)
plt.show()
        
###GBM 
n_estimators - The number of weak learners (also no of iterations)
Control size of each tree by max_depth or max_leaf_nodes (no of leaf node)
max_leaf_nodes=k gives comparable results to max_depth=k-1 but faster to train 
at the expense of a slightly higher training error.
The learning_rate (0.0, 1.0] controls overfitting via shrinkage .
Smaller values of learning_rate require larger numbers of weak learners 
Smaller value of learning_rate (learning_rate <= 0.1) gives best test error 
Choose n_estimators by early stopping.

#Attributes 
n_estimators_ : int selected no of estimator with early stopping or user given 
feature_importances_ : (n_features,)the higher, the more important the feature).
train_score_ : (n_estimators,)The i-th score train_score_[i] is the deviance (= loss) of the model at iteration i on the in-bag sample. If subsample == 1 this is the deviance on the training data.
loss_ : LossFunction, The concrete LossFunction object.
estimators_ : (n_estimators, loss_.K) , fitted DT, loss_.K is 1 for binary classification, otherwise n_classes.

#Classification with more than 2 classes requires the induction of n_classes regression trees at each iteration
#thus, the total number of induced trees equals n_classes * n_estimators. 
#For datasets with a large number of classes, use RandomForestClassifier as an alternative to GradientBoostingClassifier

#GradientBoostingClassifier supports both binary and multi-class classification. 
#Example - with 100 decision stumps as weak learners:


from sklearn.datasets import make_hastie_10_2
from sklearn.ensemble import GradientBoostingClassifier

X, y = make_hastie_10_2(random_state=0)
X_train, X_test = X[:2000], X[2000:]
y_train, y_test = y[:2000], y[2000:]

clf = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0,
    max_depth=1, random_state=0).fit(X_train, y_train)
clf.score(X_test, y_test)                 


#Use warm_start=True to add more estimators to an already fitted model.
_ = clf.set_params(n_estimators=200, warm_start=True)  # set warm_start and new nr of trees
_ = clf.fit(X_train, y_train) # fit additional 100 trees to est
mean_squared_error(y_test, clf.predict(X_test))    






###Subsampling 
Stochastic gradient boosting, which combines gradient boosting with bootstrap averaging (bagging). This improves error 

At each iteration the base classifier is trained on a fraction subsample of the available training data. The subsample is drawn without replacement. A typical value of subsample is 0.5.

Shrinkage (learning_rate <= 0.1) outperforms no-shrinkage (learning_rate =1 subsample=1). 
Subsampling with shrinkage can further increase the accuracy of the model. 
Subsampling without shrinkage, on the other hand, does poorly.

Another strategy to reduce the variance is by subsampling the features analogous 
to the random splits in RandomForestClassifier . 
The number of subsampled features can be controlled via the max_features parameter.
Using a small max_features value can significantly decrease the runtime. 


#The loss function used is binomial deviance. 
#Subsampling with shrinkage can further increase the accuracy of the model. 

#plot_gradient_boosting_regularization.py

#binary class, 10 features 
X, y = make_hastie_10_2(n_samples=12000, random_state=1)
X = X.astype(np.float32)

# map labels from original y {-1, 1} to {0, 1}
# clf.loss_ assumes that y_test[i] in {0, 1}
labels, y = np.unique(y, return_inverse=True)

X_train, X_test = X[:2000], X[2000:]
y_train, y_test = y[:2000], y[2000:]

original_params = {'n_estimators': 1000, 'max_leaf_nodes': 4, 
                   'max_depth': None, 'random_state': 2,
                   'min_samples_split': 5}

plt.figure()

for label, color, setting in [('No shrinkage', 'orange',
                               {'learning_rate': 1.0, 'subsample': 1.0}),
                              ('learning_rate=0.1', 'turquoise',
                               {'learning_rate': 0.1, 'subsample': 1.0}),
                              ('subsample=0.5', 'blue',
                               {'learning_rate': 1.0, 'subsample': 0.5}),
                              ('learning_rate=0.1, subsample=0.5', 'gray',
                               {'learning_rate': 0.1, 'subsample': 0.5}),
                              ('learning_rate=0.1, max_features=2', 'magenta',
                               {'learning_rate': 0.1, 'max_features': 2})]:
    params = dict(original_params)
    params.update(setting)
    clf = GradientBoostingClassifier(**params)
    clf.fit(X_train, y_train)
    # compute test set deviance for each iteration/estimator 
    test_deviance = np.zeros((params['n_estimators'],), dtype=np.float64)
    #(n_samples, k) 
    #score/decision function( error on testing set) of X for each iteration for k classes 
    #k=1 for binary and regression
    for i, y_pred in enumerate(clf.staged_decision_function(X_test)):
        # clf.loss_ assumes that y_test[i] in {0, 1}
        test_deviance[i] = clf.loss_(y_test, y_pred)
    #plot every 5 th point 
    plt.plot((np.arange(test_deviance.shape[0]) + 1)[::5], test_deviance[::5],
        '-', color=color, label=label)

plt.legend(loc='upper left')
plt.xlabel('Boosting Iterations')
plt.ylabel('Test Set Deviance')

plt.show()




##Early stopping 
Enables us to find the least number of iterations which is sufficient to build a model that generalizes well to unseen data.
validation_fraction - Set used of evaluation
If evaluation score does not change last n_iter_no_change (within tol)
Then it is stopped 
The number of stages of the final model is available at the attribute n_estimators_.


# plot_gradient_boosting_early_stopping.py

import time

data_list = [load_iris(), load_digits()]
data_list = [(d.data, d.target) for d in data_list]
data_list += [make_hastie_10_2()]
names = ['Iris Data', 'Digits Data', 'Hastie Data']

n_gb = []
score_gb = []
time_gb = []
n_gbes = []
score_gbes = []
time_gbes = []

n_estimators = 500

for X, y in data_list:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,
                                                        random_state=0)
    # We specify that if the scores don't improve by atleast 0.01 for the last
    # 5 stages, stop fitting additional stages
    gbes = GradientBoostingClassifier(n_estimators=n_estimators,
                                               validation_fraction=0.2,
                                               n_iter_no_change=5, tol=0.01,
                                               random_state=0)
    gb = GradientBoostingClassifier(n_estimators=n_estimators,
                                             random_state=0)
    start = time.time()
    gb.fit(X_train, y_train)
    time_gb.append(time.time() - start)
    start = time.time()
    gbes.fit(X_train, y_train)
    time_gbes.append(time.time() - start)
    score_gb.append(gb.score(X_test, y_test))
    score_gbes.append(gbes.score(X_test, y_test))
    n_gb.append(gb.n_estimators_)
    n_gbes.append(gbes.n_estimators_)

print("n estimator (without early stopping) =" , n_gb)
print("score_gb (without early stopping)=" , score_gb)
print("time_gb (without early stopping)= " , time_gb)
print("n estimator (with early stopping) = " , n_gbes)
print("score_gbes (with early stopping)= " , score_gbes)
print("time_gbes (with early stopping)= " , time_gbes)


n estimator (without early stopping) = [500, 500, 500]
score_gb (without early stopping)= [1.0, 0.9638888888888889, 0.94875]
time_gb (without early stopping)=  [0.9688193798065186, 11.609541177749634, 8.921962022781372]
n estimator (with early stopping) =  [28, 149, 129]
score_gbes (with early stopping)=  [1.0, 0.9638888888888889, 0.92375]
time_gbes (with early stopping)=  [0.07806873321533203, 6.187617301940918, 1.8750371932983398]




###Feaure Importatance and Test and train error/deviance

#with least squares loss and 500 base learners to the Boston house price dataset 

#The plot on the left shows the train(train_score_) 
#and test error(staged_predict()) at each iteration/estimators. 
#Plots like these can be used to determine the optimal number of trees (i.e. n_estimators) by early stopping. 

#The plot on the right shows the feature importances which can be obtained v
#ia the feature_importances_ property.

#plot_gradient_boosting_regression.py

boston = load_boston()
X, y = shuffle(boston.data, boston.target, random_state=13)
X = X.astype(np.float32)
offset = int(X.shape[0] * 0.9)
X_train, y_train = X[:offset], y[:offset]
X_test, y_test = X[offset:], y[offset:]

params = {'n_estimators': 500, 'max_depth': 4, 'min_samples_split': 2,
          'learning_rate': 0.01, 'loss': 'ls'}
clf = GradientBoostingRegressor(**params)
clf.fit(X_train, y_train)
mse = mean_squared_error(y_test, clf.predict(X_test))
print("MSE: %.4f" % mse)

# Plot training deviance
# compute test set deviance
test_score = np.zeros((params['n_estimators'],), dtype=np.float64)
for i, y_pred in enumerate(clf.staged_predict(X_test)):
    test_score[i] = clf.loss_(y_test, y_pred)

plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.title('Deviance')
plt.plot(np.arange(params['n_estimators']) + 1, clf.train_score_, 'b-',
         label='Training Set Deviance')
plt.plot(np.arange(params['n_estimators']) + 1, test_score, 'r-',
         label='Test Set Deviance')
plt.legend(loc='upper right')
plt.xlabel('Boosting Iterations')
plt.ylabel('Deviance')


# Plot feature importance
feature_importance = clf.feature_importances_
# make importances relative to max importance
feature_importance = 100.0 * (feature_importance / feature_importance.max())

#give indices such that data[i] would be sorted order 
sorted_idx = np.argsort(feature_importance)
pos = np.arange(sorted_idx.shape[0]) + .5
plt.subplot(1, 2, 2)
plt.barh(pos, feature_importance[sorted_idx], align='center')
plt.yticks(pos, boston.feature_names[sorted_idx])
plt.xlabel('Relative Importance')
plt.title('Variable Importance')
plt.show()




##PDP
#interpret the partial dependence as the expected target response  
#as a function of the ‘target’ features 

#One-way PDPs tell us about the interaction between the target response 
#and the target feature (e.g. linear, non-linear). 

#The upper left plot in the above Figure shows the effect of the median income 
#in a district on the median house price; 
#we can clearly see a linear relationship among them.

#PDPs with two target features show the interactions among the two features. 
#For example, the two-variable PDP in the above Figure 
#shows the dependence of median house price on joint values of house age 
#and avg. occupants per household. 
#We can clearly see an interaction between the two features: 
#For an avg. occupancy greater than two, 
#the house price is nearly independent of the house age, 
#whereas for values less than two there is a strong dependence on age.


##Load the California housing dataset (regression).
Samples total 	20640
Dimensionality 	8
Features 	real
Target 	real 0.15 - 5.
#Attribute Information:
0. MedInc median income in block
1. HouseAge median house age in block
2. AveRooms average number of rooms
3. AveBedrms average number of bedrooms
4. Population block population
5. AveOccup average house occupancy
6. Latitude house block latitude
7. Longitude house block longitude
#This dataset was obtained from the StatLib repository. http://lib.stat.cmu.edu/datasets/
#The target variable is the median house value for California districts.

from sklearn.ensemble.partial_dependence import plot_partial_dependence
cal_housing = fetch_california_housing()

# split 80/20 train-test
X_train, X_test, y_train, y_test = train_test_split(cal_housing.data,
                                                    cal_housing.target,
                                                    test_size=0.2,
                                                    random_state=1)
names = cal_housing.feature_names

print("Training GBRT...")
clf = GradientBoostingRegressor(n_estimators=100, max_depth=4,
                                learning_rate=0.1, loss='huber',
                                random_state=1)
clf.fit(X_train, y_train)
print(" done.")

print('Convenience plot with ``partial_dependence_plots``')
#One way PDP: y vs feature 0, y vs feture 5 , y vs feature 1 , y vs feature 2 
#Two way PDP = y vs feature (5,1)
features = [0, 5, 1, 2, (5, 1)]
fig, axs = plot_partial_dependence(clf, X_train, features,
                                   feature_names=names,
                                   n_jobs=3, grid_resolution=50)
fig.suptitle('Partial dependence of house value on nonlocation features\n'
             'for the California housing dataset')
plt.subplots_adjust(top=0.9)  # tight_layout causes overlap with suptitle
plt.show()



###Majority Class Labels (Majority/Hard Voting)
E.g., if the prediction for a given sample is
    classifier 1 -> class 1
    classifier 2 -> class 1
    classifier 3 -> class 2
the VotingClassifier (with voting='hard') would classify the sample as “class 1” 
In the cases of a tie, the VotingClassifier will select the class based 
on the ascending sort order. E.g., in the following scenario
    classifier 1 -> class 2
    classifier 2 -> class 1
the class label 1 will be assigned to the sample.

##Weighted Average Probabilities (Soft Voting)
soft voting returns the class label as argmax of the sum of predicted probabilities.
we have 3 classifiers and a 3-class classification problems 
where we assign equal weights to all classifiers: w1=1, w2=1, w3=1.
classifier 	    class 1 	class 2 	class 3
classifier 1 	w1 * 0.2 	w1 * 0.5 	w1 * 0.3
classifier 2 	w2 * 0.6 	w2 * 0.3 	w2 * 0.1
classifier 3 	w3 * 0.3 	w3 * 0.4 	w3 * 0.3
weighted average 	0.37 	0.4 	0.23
the predicted class label is 2, since it has the highest average probability.

#note estimators in the VotingClassifier must support predict_proba method

#Optionally, weights can be provided for the individual classifiers:
eclf = VotingClassifier(estimators=[('lr', clf1), ('rf', clf2), ('gnb', clf3)],
            voting='soft', weights=[2, 5, 1])

#Using the VotingClassifier with GridSearch
iris = load_iris()
clf1 = LogisticRegression(solver='lbfgs', multi_class='multinomial', random_state=1)
clf2 = RandomForestClassifier(random_state=1)
clf3 = GaussianNB()
eclf = VotingClassifier(estimators=[('lr', clf1), ('rf', clf2), ('gnb', clf3)], voting='soft')

params = {'lr__C': [1.0, 100.0], 'rf__n_estimators': [20, 200]}
grid = GridSearchCV(estimator=eclf, param_grid=params, cv=5)
grid = grid.fit(iris.data, iris.target)



##Plot decision boundary using VotingClassifier

# Take only two features such that dicision boundary can be created 
iris = datasets.load_iris()
X = iris.data[:, [0, 2]]
y = iris.target

# Training classifiers
clf1 = DecisionTreeClassifier(max_depth=4)
clf2 = KNeighborsClassifier(n_neighbors=7)
clf3 = SVC(gamma=.1, kernel='rbf', probability=True)
eclf = VotingClassifier(estimators=[('dt', clf1), ('knn', clf2),
                                    ('svc', clf3)],
                        voting='soft', weights=[2, 1, 2])

clf1.fit(X, y)
clf2.fit(X, y)
clf3.fit(X, y)
eclf.fit(X, y)

# Plotting decision regions
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1),
                     np.arange(y_min, y_max, 0.1))
#'row': each subplot row will share an x- or y-axis.
#'col': each subplot column will share an x- or y-axis.
#When subplots have a shared x-axis along a column, 
#only the x tick labels of the bottom subplot are created. 
#Similarly, when subplots have a shared y-axis along a row, 
#only the y tick labels of the first column subplot are created

f, axarr = plt.subplots(2, 2, sharex='col', sharey='row', figsize=(10, 8))

#product is cartesian product ie 0,0 0,1, 1,0, 1,1 
for idx, clf, tt in zip(product([0, 1], [0, 1]),
                        [clf1, clf2, clf3, eclf],
                        ['Decision Tree (depth=4)', 'KNN (k=7)',
                         'Kernel SVM', 'Soft Voting']):
    #columnwise stack 
    #of two features 
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    #[x,y]=Z , draw contour lines and filled contours
    #basically draws contour of f(x,y)
    axarr[idx[0], idx[1]].contourf(xx, yy, Z, alpha=0.4)
    #plot two feature x vs y as scatter 
    axarr[idx[0], idx[1]].scatter(X[:, 0], X[:, 1], c=y,s=20, edgecolor='k')
    axarr[idx[0], idx[1]].set_title(tt)

plt.show()


###CatBoost vs. Light GBM vs. XGBoost

#flights.csv 
#MONTH, DAY, DAY_OF_WEEK: data type int
#AIRLINE and FLIGHT_NUMBER: data type int
#ORIGIN_AIRPORT and DESTINATION_AIRPORT: data type string
#DEPARTURE_TIME: data type float
#ARRIVAL_DELAY: this will be the target and is transformed into boolean variable indicating delay of more than 10 minutes
#DISTANCE and AIR_TIME: data type float
    

data = pd.read_csv("tobeShared/data/flights.csv")

data = data[["MONTH","DAY","DAY_OF_WEEK","AIRLINE","FLIGHT_NUMBER","DESTINATION_AIRPORT",
                 "ORIGIN_AIRPORT","AIR_TIME", "DEPARTURE_TIME","DISTANCE","ARRIVAL_DELAY"]]
data.dropna(inplace=True)

data["ARRIVAL_DELAY"] = (data["ARRIVAL_DELAY"]>10)*1

cols = ["AIRLINE","FLIGHT_NUMBER","DESTINATION_AIRPORT","ORIGIN_AIRPORT"]
#convert to numeric categorical , 0- size_of_cat
for item in cols:
    data[item] = data[item].astype("category").cat.codes +1

#axis=0, row, axis=1, column 
train, test, y_train, y_test = train_test_split(data.drop(["ARRIVAL_DELAY"], axis=1),
    data["ARRIVAL_DELAY"],random_state=10, test_size=0.25)
                                                
##XGBoost
import xgboost as xgb
from sklearn import metrics

#Return ROC/AUC 
#roc_auc_score(y_true, y_score)
#predict_proba return [n_samples, n_classes]
#where classes are ordered as they are in self.classes_.
#take only for delayed one [:,1]
def auc(m, train, test): 
    return (metrics.roc_auc_score(y_train,m.predict_proba(train)[:,1]),
                            metrics.roc_auc_score(y_test,m.predict_proba(test)[:,1]))

# Parameter Tuning
model = xgb.XGBClassifier()
param_dist = {"max_depth": [10,30,50],
              "min_child_weight" : [1,3,6],
              "n_estimators": [200],
              "learning_rate": [0.05, 0.1,0.16],}
grid_search = GridSearchCV(model, param_grid=param_dist, cv = 3, 
                                   verbose=10, n_jobs=-1)
grid_search.fit(train, y_train)

grid_search.best_estimator_

                  
model = xgb.XGBClassifier(n_jobs=-1 , verbose=1,**grid_search.best_params_)
model.fit(train,y_train)

auc(model, train, test) #

#Light GBM
import lightgbm as lgb
from sklearn import metrics

def auc2(m, train, test): 
    return (metrics.roc_auc_score(y_train,m.predict(train)),
                            metrics.roc_auc_score(y_test,m.predict(test)))

lg = lgb.LGBMClassifier(silent=False)
param_dist = {"max_depth": [25,50, 75],
              "learning_rate" : [0.01,0.05,0.1],
              "num_leaves": [300,900,1200],
              "n_estimators": [200]
             }
grid_search = GridSearchCV(lg, n_jobs=-1, param_grid=param_dist, cv = 3, scoring="roc_auc", verbose=5)
grid_search.fit(train,y_train)
grid_search.best_estimator_

d_train = lgb.Dataset(train, label=y_train)
#params = {"max_depth": 50, "learning_rate" : 0.1, "num_leaves": 900,  "n_estimators": 300}
params = grid_search.best_params_ 
# Without Categorical Features
model2 = lgb.train(params, d_train)
auc2(model2, train, test) #(0.9999080488022881, 0.7296877889286735)

#With Catgeorical Features
d_train = lgb.Dataset(train, label=y_train)
cate_features_name = ["MONTH","DAY","DAY_OF_WEEK","AIRLINE","DESTINATION_AIRPORT",
                 "ORIGIN_AIRPORT"]
model2 = lgb.train(params, d_train, categorical_feature = cate_features_name)
auc2(model2, train, test)#(0.999387513407222, 0.7550473212634693)

##CatBoost
#pip install catboost
#While tuning parameters for CatBoost, 
#it is difficult to pass indices for categorical features. 
#without passing categorical features and evaluated two model
#one with and other without categorical features. 
#I have separately tuned one_hot_max_size because it does not impact the other parameters.

import catboost as cb
'''
>>> data.columns
Index(['MONTH', 'DAY', 'DAY_OF_WEEK', 'AIRLINE', 'FLIGHT_NUMBER',
       'DESTINATION_AIRPORT', 'ORIGIN_AIRPORT', 'AIR_TIME', 'DEPARTURE_TIME',
       'DISTANCE', 'ARRIVAL_DELAY'],
      dtype='object')
'''      
cat_features_index = [0,1,2,3,4,5,6]

def auc(m, train, test): 
    return (metrics.roc_auc_score(y_train,m.predict_proba(train)[:,1]),
                            metrics.roc_auc_score(y_test,m.predict_proba(test)[:,1]))

params = {'depth': [4, 7, 10],
          'learning_rate' : [0.03, 0.1, 0.15],
         'l2_leaf_reg': [1,4,9],
         'iterations': [300]}
cb = cb.CatBoostClassifier()
cb_model = GridSearchCV(cb, params, scoring="roc_auc", cv = 3)
cb_model.fit(train, y_train) #(0.9232417545584556, 0.7494421049977306)
 
#Without Categorical features
clf = cb.CatBoostClassifier(eval_metric="AUC", depth=10, iterations= 500, l2_leaf_reg= 9, learning_rate= 0.15)
clf.fit(train,y_train)
auc(clf, train, test)

#With Categorical features
clf = cb.CatBoostClassifier(eval_metric="AUC",one_hot_max_size=31, \
                            depth=10, iterations= 500, l2_leaf_reg= 9, learning_rate= 0.15)
clf.fit(train,y_train, cat_features= cat_features_index)
auc(clf, train, test)

##using auto_ml to do the same 
#each column is a numerical column, unless you specify otherwise using one of the types noted below.
'output'        Output column, must 
'categorical'   By default, any string value in cloumn is taken as Categoorical 
                For numerucal category, use this type 
'nlp'           For NLP text data, encoded using TF-IDF, along with some other feature engineering 
                (count of some aggregations like total capital letters, puncutation characters, smiley faces, etc., as well as a sentiment prediction of that text).
'ignore'        This column of data will be ignored.
'date'          Creates new features like day_of_week, or minutes_into_day, etc. 
                Then the original date field will be removed from the training data   

class Predictor(type_of_estimator, column_descriptions, verbose=True, name=None)
Parameters:	
type_of_estimator ('regressor' or 'classifier')
    Whether you want a classifier or regressor
column_descriptions (dictionary)
    'column_name' : 'type '
    where type  ['categorical', 'output', 'nlp', 'date', 'ignore'] 
    All columns are assumed to be continuous unless labeled otherwise.      

#followings are train configurations 
compare_all_models - [default=False]
    True means many scikit Models would be compared 
    If False, by default uses GradientBoostingRegressor or GradientBoostingClassifier
       
take_log_of_y (Boolean) – [default- None] 
    For regression problems, 
    accuracy is sometimes improved by taking the natural log of y values during training, 
    so they all exist on a comparable scale.

model_names (list of strings) 
    [default- relevant 'GradientBoosting'] Which model(s) to try. 
    from scikit-learn are ['ARDRegression', 'AdaBoostClassifier', 'AdaBoostRegressor', 'BayesianRidge', 'ElasticNet', 'ExtraTreesClassifier', 'ExtraTreesRegressor', 'GradientBoostingClassifier', 'GradientBoostingRegressor', 'Lasso', 'LassoLars', 'LinearRegression', 'LogisticRegression', 'MiniBatchKMeans', 'OrthogonalMatchingPursuit', 'PassiveAggressiveClassifier', 'PassiveAggressiveRegressor', 'Perceptron', 'RANSACRegressor', 'RandomForestClassifier', 'RandomForestRegressor', 'Ridge', 'RidgeClassifier', 'SGDClassifier', 'SGDRegressor']. 
    Other options : eg model_names=['DeepLearningClassifier']
        DeepLearningClassifier and DeepLearningRegressor(tensorflow,keras)
        XGBClassifier and XGBRegressor
        LGBMClassifer and LGBMRegressor
        CatBoostClassifier and CatBoostRegressor
optimize_final_model (Boolean) – [default- False] 
    Whether or not to perform GridSearchCV on the final model. 
    True increases computation time significantly, 
    but will likely increase accuracy.  

#Example 
from auto_ml import Predictor

#comment out calc_feature_importance parameter 
'''
 File "c:\python35\lib\site-packages\auto_ml\utils_models.py", line 176, in get model_from_name
   model_map['CatBoostRegressor'] = CatBoostRegressor(calc_feature_importance=True)
TypeError: __init__() got an unexpected keyword argument 'calc_feature_importanc
'''


# Load data
#train, test, y_train, y_test   #from earlier example 

#tell only numeric categorical 
#string categorical is automatic 
column_descriptions = { 'ARRIVAL_DELAY': 'output'  , 'MONTH': 'categorical',
    'DAY': 'categorical', 'DAY_OF_WEEK': 'categorical'}

#sklearn models , 
ml1 = Predictor(type_of_estimator='classifier', column_descriptions=column_descriptions)
m11 = ml1.train(pd.concat([train, y_train], axis=1)) 
predictions = ml1.predict(pd.concat([test, y_test], axis=1))
m11.trained_final_model.model #model 
m11.trained_pipeline  #this is the Pipeline
#Note internally it uses internal scoring method, hence use below methods 
accuracy_score(y_train, ml1.predict(pd.concat([train, y_train], axis=1)))#0.859883236030025
accuracy_score(y_test, predictions) #0.8181818181818182



#XGBClassifier and XGBRegressor
ml3 = Predictor(type_of_estimator='classifier', column_descriptions=column_descriptions)
ml3 = ml3.train(pd.concat([train, y_train], axis=1), model_names=['XGBClassifier'], verbose=10) 
predictions = ml3.predict(pd.concat([test, y_test], axis=1))
accuracy_score(y_train, ml3.predict(pd.concat([train, y_train], axis=1)))#0.8137336669446761
accuracy_score(y_test, predictions) #0.8194328607172644

#LGBMClassifer and LGBMRegressor
ml4 = Predictor(type_of_estimator='classifier', column_descriptions=column_descriptions)
ml4 = ml4.train(pd.concat([train, y_train], axis=1), model_names=['LGBMClassifier'], verbose=10) 
predictions = ml4.predict(pd.concat([test, y_test], axis=1))
accuracy_score(y_train, ml4.predict(pd.concat([train, y_train], axis=1))) #0.8412566027244927
accuracy_score(y_test, predictions) #0.817347789824854

#CatBoostClassifier and CatBoostRegressor
ml5 = Predictor(type_of_estimator='classifier', column_descriptions=column_descriptions)
ml5 = ml5.train(pd.concat([train, y_train], axis=1), model_names=['CatBoostClassifier'], verbose=10) 
predictions = ml5.predict(pd.concat([test, y_test], axis=1))
accuracy_score(y_train, ml5.predict(pd.concat([train, y_train], axis=1))) #0.8262440922991382
accuracy_score(y_test, predictions)#0.8148457047539617





##Example of regressor 
from auto_ml import Predictor
from auto_ml.utils import get_boston_dataset
from auto_ml.utils_models import load_ml_model

# Load data
df_train, df_test = get_boston_dataset()

>>> df_train.columns
Index(['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD', 'TAX','PTRATIO', 'B', 'LSTAT', 'MEDV'],
      dtype='object')
      
column_descriptions = { 'MEDV': 'output'  , 'CHAS': 'categorical'}

ml_predictor = Predictor(type_of_estimator='regressor', column_descriptions=column_descriptions)

ml_predictor.train(df_train) #,optimize_final_model=True, compare_all_models=True)
# Score the model on test data, rmse 
test_score = ml_predictor.score(df_test, df_test.MEDV)

file_name = ml_predictor.save() #check the filename 
trained_model = load_ml_model(file_name)

# .predict and .predict_proba take in either:
# A pandas DataFrame
# A list of dictionaries
# A single dictionary (optimized for speed in production evironments)
predictions = trained_model.predict(df_test)
print(predictions)

             
             
#using TPOT 

from tpot import TPOTClassifier

# Load data
#train, test, y_train, y_test   #from earlier example 
#increase generations, and population_size, default both =100 
#but would take 5hrs
tpot = TPOTClassifier(generations=1,population_size=10, verbosity=2)
tpot.fit(train, y_train)
print(tpot.score(train, y_train))
print(tpot.score(test, y_test))
tpot.export('tpot_flights_pipeline.py')  #get the pipeline code 
predictions = tpot.predict(test)
accuracy_score(y_test, predictions)
accuracy_score(y_train, tpot.predict(train))
             
###Example - Boston housing prices modeling using TPOT
from tpot import TPOTRegressor
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split

housing = load_boston()
X_train, X_test, y_train, y_test = train_test_split(housing.data, housing.target,
                                                    train_size=0.75, test_size=0.25)

tpot = TPOTRegressor(generations=5, population_size=50, verbosity=2)
tpot.fit(X_train, y_train)
print(tpot.score(X_test, y_test))
tpot.export('tpot_boston_pipeline.py')#get the pipeline code 


 
             

###Artificial Neural Networks using keras 

#Tensorflow - Installation only on 3.5.2 x64 bit 
$ pip3 install --upgrade tensorflow
#https://stackoverflow.com/questions/47068709/your-cpu-supports-instructions-that-this-tensorflow-binary-was-not-compiled-to-u
#for AVX or GPU versions 

#MSVCP140.DLL  must be in system32 
#https://www.microsoft.com/en-us/download/details.aspxid=53587

$ pip install keras

#By default uses Tensorflow backend 
#change it in $HOME(or %USERPROFILE%)/.keras/keras.json
#change the field backend to "theano", "tensorflow", or "cntk
{
    "image_data_format": "channels_last",
    "epsilon": 1e-07,
    "floatx": "float32",
    "backend": "tensorflow"
}



#Also, image algorithms works with float64, not uint8
#To convert to and fro 
data = ...
info = np.iinfo(data.dtype) # Machine limits for integer types.
data = data.astype(np.float64) / info.max # normalize the data to 0 - 1
#convert ti uint8
data = 255 * data # Now scale by 255
img = data.astype(np.uint8)




#There are two types of models available in Keras: 
#the Sequential model and the Model class used with functional API.

#These models have many common methods 
model.summary()
    prints a summary representation of model. Shortcut for utils.print_summary
model.get_config()
    returns a dictionary containing the configuration of the model. 
    The model can be reinstantiated from its config via
    #Example 
    config = model.get_config()
    model = Model.from_config(config)
    # or, for Sequential:
    model = Sequential.from_config(config)
model.get_weights()
    returns a list of all weight tensors in the model, as Numpy arrays.
model.set_weights(weights)
    sets the values of the weights of the model, from a list of Numpy arrays. 
    The arrays in the list should have the same shape as those returned by get_weights().
model.to_json()
    returns a representation of the model as a JSON string. 
    Note that the representation does not include the weights, only the architecture. 
    You can reinstantiate the same model (with reinitialized weights) from the JSON string via:
    #Example 
    from models import model_from_json
    json_string = model.to_json()
    model = model_from_json(json_string)
model.save_weights(filepath)
    saves the weights of the model as a HDF5 file.
    HDF5:A versatile data model that can represent very complex data objects and a wide variety of metadata.
    Pandas support reading from HDF5 
    df_tl = pd.DataFrame(dict(A=list(range(5)), B=list(range(5))))
    df_tl.to_hdf('store_tl.h5','table',append=True)
    pd.read_hdf('store_tl.h5', 'table', where = ['index>2'])
model.load_weights(filepath, by_name=False)
    loads the weights of the model from a HDF5 file (created by save_weights).
    By default, the architecture is expected to be unchanged. 
    To load weights into a different architecture (with some layers in common), 
    use by_name=True to load only those layers with the same name.         
model.layers 
    a list of the layers added to the model.
model.get_layer( name=None, index=None)
    Retrieve a layer that is part of the model.
    Returns a layer based on either its name (unique) or its index in the graph. 
    Indices are based on order of horizontal graph traversal (bottom-up).
    Arguments
        name: string, name of layer.
        index: integer, index of layer.
    Returns
        A layer instance.  
        
#Methods at keras lavel       
keras.models.save_model(model, filepath, overwrite=True, include_optimizer=True):
    Save a model to a HDF5 file.
    The saved model contains:
        - the model's configuration (topology)
        - the model's weights
        - the model's optimizer's state (if any)        
keras.models.load_model(filepath, custom_objects=None, compile=True):
    Loads a model saved via `save_model`.    
    Returns
            A Keras model instance  
keras.models.model_from_json(json_string, custom_objects=None):
    Parses a JSON model configuration file and returns a model instance.    
keras.models.model_from_yaml(yaml_string, custom_objects=None):
    Parses a yaml model configuration file and returns a model instance.
        

#The neural network might give different results with different start weights
#use initializers https://keras.io/initializers/
from keras import initializers
model.add(Dense(64,
                kernel_initializer='random_uniform',
                bias_initializer='zeros'))

#Solution of Overfitting, use regularizers   or Dropout(.n) which randomly drops out neuron 
#https://keras.io/regularizers/
#l2 gives shrinkage, l1 gives sparse feature              
from keras import regularizers
model.add(Dense(64, input_dim=64,
                kernel_regularizer=regularizers.l2(0.01),
                activity_regularizer=regularizers.l1(0.01)))  

###Example -XOR Logic using MLP & Backpropagation
import numpy as np
from keras.models import Sequential
from keras.layers.core import Dense

#ie 0,0 => 0 
training_data = np.array([[0,0],[0,1],[1,0],[1,1]], "float32")
target_data = np.array([[0],[1],[1],[0]], "float32")

model = Sequential()
#Regular densely-connected NN layer.
#32 , dimensionality of the output space.
#activation: Activation function to use . 
#input_dim= n , for n features or (x,y) for 2D feature 
model.add(Dense(32, input_dim=2, activation='relu'))
#use relu for internal and for classification, use sigmoid or softmax 
model.add(Dense(1, activation='sigmoid'))

#https://keras.io/losses/
#for regression, use loss = mean_squared_error
#for classification, use categorical_crossentropy(multiclass) or binary_crossentropy(binary class)

#optimizer https://keras.io/optimizers/
#Use adam in general, for complex NN, use Nadam

#Metrics https://keras.io/metrics/, not used for training, only evaluation 
#Use any from losse as well 
#for regression, use metrics.mae  , mean absolute error 
#classification use metrics.binary_accuracy,metrics.categorical_accuracy(y_true, y_pred)

model.summary()
model.compile(loss='mean_squared_error', optimizer='adam', metrics=['binary_accuracy'])

#epoch - how many passes of full x,y data , 
model.fit(training_data, target_data, nb_epoch=1000, verbose=2)

model.predict(training_data) #in float64
#for binary, round it 
predictions = model.predict(training_data)
rounded = [round(x[0]) for x in predictions]
print(rounded)

scores = model.evaluate(training_data, target_data) #here metrics are used 
#returns [ test loss, accuracy]
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
#binary_accuracy: 100.00%




###Scikit-API  - Iris-csv with Early stoping and inpu scaling 

from keras.models import Sequential, load_model
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
import keras.utils 
from keras.callbacks import * 


dataframe   = pd.read_csv("data/iris.csv")
dataset     = dataframe.values

X = dataset[:,0:4].astype(float)
Y = dataset[:,4]

encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)

# to_categorical converts the numbered labels into a one-hot vector
#Classifier must use x or y as one hot encoded 
dummy_y = keras.utils.to_categorical(encoded_Y)
#so creates 3 output variable 

#StratifiedKFold does not work with multioutput 
kfold = KFold(n_splits=10, shuffle=True)

# define baseline model
def baseline_model():
    # create model
    model = Sequential()
    #input_dim= n , for n features or (x,y) for 2D feature 
    model.add(Dense(8, input_dim=4, activation='relu'))
    #for binary , final layer with one output, activation='sigmoid' and loss='binary_crossentropy'.
    #but we have three classe classifier, so output=3 
    model.add(Dense(3, activation='softmax'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
    

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5, verbose=0)


results = cross_val_score(estimator, X, dummy_y, cv=kfold)
print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))
#Baseline: 97.33% (4.42%)


#Check 
X_train, X_test, y_train, y_test, enc_y_train, enc_y_test = train_test_split(X, dummy_y, encoded_Y, random_state=0)

#fit
estimator.fit( X_train, y_train)

#score 
print(" train, test accuracy", estimator.score( X_train, y_train), estimator.score( X_test, y_test))
#0.9732142873108387
#0.9736842120948591

#predict 
predictions = estimator.predict( X_test)
print("predict as per numerical class\n", predictions)
#array([2, 2, 0, 2, 0, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 0, 0, 2, 2,  0, 0, 2, 0, 0, 2, 1, 0, 2, 2, 0, 2, 2, 2, 0, 2])
#With LabelEncoded Y 
print("confusion metrics\n", confusion_matrix(enc_y_test, predictions))
# array([[13,  0,  0],
       # [ 0, 14,  2],
       # [ 0,  0,  9]], dtype=int64)
       
             


print("""  --------------- GridSearch -----------------
accuracy is very sensitive of below Hyperparameters 
batch_size = sample size preferably to be multiple of batch size
epochs 
Dense - output no , 
        activation
""")


params = dict(
    epochs = [ 100, 200, 300],
    batch_size = [5,15,30],
    dense1_out = [8,16,32],
    dense1_activation = [ 'relu', 'tanh']
)

def search_model(dense1_out=8, dense1_activation='relu' ):
    # create model
    model = Sequential()
    model.add(Dense(dense1_out, input_dim=4, activation=dense1_activation))
    model.add(Dense(3, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

clf = KerasClassifier(build_fn=search_model, verbose=0)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(clf, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
print("Time taken: ", time.time()-st, " secs")  #175.9128041267395

print("Best param: ", search.best_params_ ) #{'epochs': 200, 'dense1_activation': 'tanh', 'batch_size': 30, 'dense1_out': 16}
print(" train, test accuracy", search.score( X_train, y_train), #0.9821428624647004
search.score( X_test, y_test)) #0.9736842105263158



print("""
Reducton of overfitting 
1.Setup Early Stopping
    Use EarlyStopping(monitor='val_loss', patience=2) 
        to define that we wanted to monitor the test (validation) loss at each epoch 
        and after the test loss has not improved after two epochs, training is interrupted. 
        However, since we set patience=2, we won't get the best model, 
        but the model two epochs after the best model. 
        Therefore, optionally, we can include a second operation, 
        ModelCheckpoint which saves the model to a file after every checkpoint 
        (which can be useful in case a multi-day training session is interrupted for some reason. 
        Helpful for us, if we set save_best_only=True then ModelCheckpoint will only save 
        the best model.
    And 
    Use validation_split=0.3 or validation_data=(val_x, val_y)
2.Use MinMaxscalar to scale the data also to reduce overfitting 
(dont use StandardScalar as data might not be normal)

""")
callbacks = [EarlyStopping(monitor='val_loss', patience=2),
             ModelCheckpoint(filepath='best_model.h5', monitor='val_loss', save_best_only=True)]
             
scaler = MinMaxScaler(feature_range=(-1,1))
X = scaler.fit(X).transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, dummy_y,  random_state=0)

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5,                       
                      verbose=1, # Print description after each epoch(0)+some addl  
                      callbacks=callbacks, # Early stopping
                      validation_data=(X_test, y_test) # Data for evaluation                      
                      )
estimator.fit( X_train, y_train)
    
#Load the best model from best_model.h5 which is compiled as well 
model = load_model('best_model.h5')
estimator1 = KerasClassifier(build_fn=lambda : model)
results = cross_val_score(estimator1, X, dummy_y, cv=kfold, scoring='roc_auc')
print("AUC with reduce overfitting: %3.2f (%3.2f)" % (results.mean(), results.std()))

    
    
###+++Keras - Example -Boston housing price regression 
'''
Target : The last column MEDV is a median value of owner-occupied homes in $1000
Features:
CRIM per capita crime rate by town
ZN proportion of residential land zoned for lots over 25,000 sq.ft.
INDUS proportion of non-retail business acres per town
CHAS Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
NOX nitric oxides concentration (parts per 10 million)
RM average number of rooms per dwelling
AGE proportion of owner-occupied units built prior to 1940
DIS weighted distances to five Boston employment centres
RAD index of accessibility to radial highways
TAX full-value property-tax rate per $10,000
PTRATIO pupil-teacher ratio by town
B 1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
LSTAT % lower status of the population
'''

# Read dataset into X and Y
df = pd.read_csv('tobeShared/data/boston.csv')
dataset = df.values

X = dataset[:, 0:13]
Y = dataset[:, 13]

#print "X: ", X
#print "Y: ", Y


# Define the neural network
from keras.models import Sequential
from keras.layers import Dense

#13 feature/input, one output

#Note Activation 
#Regression: linear (because values are unbounded)
#Classification: softmax (simple sigmoid works too but softmax works better)
#for binary, sigmoid is also ok , but the output is not a probability distribution (does not need to sum to 1).

#Sigmoid and tanh should not be used as activation function for the hidden layer. 
#This is because of the vanishing gradient problem, i.e., if your input is on a higher side (where sigmoid goes flat) then the gradient will be near zero. 
#The best function for hidden layers is thus ReLu.

def build_nn(dense1_out=20, dense1_activation='relu', dense1_init="normal"):
    model = Sequential()
    model.add(Dense(dense1_out, input_dim=13, kernel_initializer=dense1_init, activation=dense1_activation))
    # No activation needed in output layer (because regression)
    model.add(Dense(1, kernel_initializer=dense1_init))
    model.add(Activation("linear")) #by default, so no need to add 
    # Compile Model
    model.compile(loss='mean_squared_error', optimizer='adam', metrics=['mse'])
    return model


# Evaluate model (kFold cross validation)
from keras.wrappers.scikit_learn import KerasRegressor

#batch_size < n_samples 
#note Network parameters get updated (forward and backword ie one pass)
#only n_samples/batch_size (if not divisible, then last batch is only delta)
#hence per pass, requires less memory nd multiple updates are done for whole data set 

#if batch_size == n_samples, only 1 update, but high memory is required 

# Before feeding the i/p into neural-network, standardise the dataset because all input variables vary in their scales
estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, epochs=100, batch_size=5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=5, shuffle=True)
results = cross_val_score(pipeline, X, Y, cv=kfold)

#MSE 
print("Mean: ", results.mean()) #-16.17353722710814
print("StdDev: ", results.std()) #StdDev:  6.191083824421029

#initializers are used to thwart local minimum 
params = dict(
    mlp__epochs = [ 500, 1000],
    mlp__dense1_out = [20,48, 64],
    mlp__dense1_activation = ['relu'],
    mlp__dense1_init = ['glorot_normal', 'normal']
)

X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)

estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, batch_size = 5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(pipeline, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
time.time()-st  #705.3032658100128 sec

search.best_params_  #{'mlp__dense1_init': 'glorot_normal', 'mlp__batch_size': 5, 'mlp__epochs': 300,'mlp__dense1_activation': 'relu', 'mlp__dense1_out': 48}
search.score( X_train, y_train)  #3.2275988869270735
search.score( X_test, y_test) #15.513392695409106

predictions = search.predict( X_test)
r2_score(y_test, predictions) #0.8101153048345232




###HandsON- Diabetes Data Predictive Analysis using DNN(use one hidden layer)
from keras.models import Sequential
from keras.layers import Dense



dataset = pd.read_csv("tobeShared/data/pima-indians-diabetes.csv")

#Binary classification 
Z = dataset.values[:,0:8].astype(np.float64)
Q = dataset.values[:,8]

#Simple model - 12 feature/input , 1 output 
#but one hidden layer 
model = Sequential()
model.add(Dense(256, input_dim=8, activation='relu'))
#model.add(Dense(64, activation='relu'))
model.add(Dense(1, activation='sigmoid')) #or sigmoid as binary 

model.summary()
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['binary_accuracy'])
model.fit(Z, Q, epochs=20, batch_size=5)

predictions = model.predict(Z)
rounded = [round(x[0]) for x in predictions]
print(rounded)

scores = model.evaluate(Z, Q)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))




###+++Keras - Example - Handwritten digits recognitions with MLP  - mnist_mlp.py 
'''Trains a simple convnet on the MNIST dataset.

Gets to 99.25% test accuracy after 12 epochs
(there is still a lot of margin for parameter tuning).
16 seconds per epoch on a GRID K520 GPU.

MNIST database of handwritten digits
    Dataset of 60,000 28x28 grayscale images of the 10 digits, 
    along with a test set of 10,000 images.
    Returns:
        2 tuples:
            x_train, x_test: uint8 array of grayscale image data with shape (num_samples, 28, 28).
            y_train, y_test: uint8 array of digit labels (integers in range 0-9) with shape (num_samples,).
    Arguments:
        path: if you do not have the index file locally (at '~/.keras/datasets/' + path), it will be downloaded to this location.
    #Usage:
    from keras.datasets import mnist
    (x_train, y_train), (x_test, y_test) = mnist.load_data()
'''

from __future__ import print_function

import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import RMSprop 

batch_size = 128
num_classes = 10
epochs = 20

# the data, shuffled and split between train and test sets
(x_train, y_train), (x_test, y_test) = mnist.load_data()

y_test_original = np.copy(y_test)
#Dataset of 60,000 28x28(784) grayscale(uint8) images of the 10 digits, 
#along with a test set of 10,000 images.

x_train = x_train.reshape(60000, 784) #flatten 
x_test = x_test.reshape(10000, 784) #flatten 
x_train = x_train.astype('float32') #convert to float 
x_test = x_test.astype('float32')#convert to float 
x_train /= 255.0 #make it in 0 to 1
x_test /= 255.0

# One hot encoded , convert 0 to 9 to 10 one hot encoded 
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

#input/feature 784, output 10 
model = Sequential()
model.add(Dense(512, activation='relu', input_shape=(784,)))
model.add(Dropout(0.2))  #for regularize
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(num_classes, activation='softmax')) #softmax is must 

model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer=RMSprop(),
              metrics=['accuracy'])

history = model.fit(x_train, y_train,
                    batch_size=batch_size,
                    epochs=epochs,
                    verbose=1,
                    validation_data=(x_test, y_test))
score = model.evaluate(x_test, y_test, verbose=0)
print('Test loss:', score[0])#Test loss: 0.12485489313729654
print('Test accuracy:', score[1])#Test accuracy: 0.9831

predictions = model.predict(x_test)
#note one hot encoded is not collapsed
>>> np.round(predictions)
array([[0., 0., 0., ..., 1., 0., 0.],
       [0., 0., 1., ..., 0., 0., 0.],
       [0., 1., 0., ..., 0., 0., 0.],
       ...,
       [0., 0., 0., ..., 0., 0., 0.],
       [0., 0., 0., ..., 0., 0., 0.],
       [0., 0., 0., ..., 0., 0., 0.]], dtype=float32)

>>> np.argmax(predictions, axis=1) #digit predictions 
array([7, 2, 1, ..., 4, 5, 6], dtype=int64)
#sklearn metrics
>>> confusion_matrix(y_test_original, np.argmax(predictions, axis=1) )
array([[ 976,    1,    0,    0,    0,    1,    1,    1,    0,    0],
       [   0, 1125,    2,    0,    0,    1,    2,    2,    3,    0],
       [   4,    0, 1019,    2,    0,    0,    0,    4,    3,    0],
       [   0,    0,    8,  991,    0,    1,    0,    3,    1,    6],
       [   1,    1,    7,    0,  958,    0,    1,    3,    1,   10],
       [   2,    1,    0,    7,    1,  877,    2,    0,    2,    0],
       [   5,    2,    0,    1,    2,   10,  938,    0,    0,    0],
       [   2,    1,    8,    0,    0,    0,    0, 1010,    4,    3],
       [   5,    1,    2,    4,    1,    4,    0,    2,  950,    5],
       [   1,    2,    0,    4,    7,    3,    0,    4,    1,  987]],
      dtype=int64)


###Example - Handwritten digits recognitions with CNN - mnist.py 


from __future__ import print_function
import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras import backend as K

batch_size = 128
num_classes = 10
epochs = 12

# input image dimensions
img_rows, img_cols = 28, 28

# the data, shuffled and split between train and test sets
(x_train, y_train), (x_test, y_test) = mnist.load_data()

y_test_original = np.copy(y_test)

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255

# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

model = Sequential()
#output=32, input 28x28x1 , kernel_size = where convolution takes place 
model.add(Conv2D(32, kernel_size=(3, 3),
                 activation='relu',
                 input_shape=input_shape))  #1 channel, so 28x28x1
model.add(Conv2D(64, (3, 3), activation='relu'))
#pooling is for reducing no of connection to next layer, to reduce complexity(overfitting)
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(num_classes, activation='softmax'))

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer=keras.optimizers.Adadelta(),
              metrics=['accuracy'])
import time 
st = time.time()
model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=epochs,
          verbose=1,
          validation_data=(x_test, y_test))
>>> print(time.time() - st)
4413.019079685211
>>> score = model.evaluate(x_test, y_test, verbose=0)
>>> print('Test loss:', score[0])
Test loss: 0.029384243838775456
>>> print('Test accuracy:', score[1])
Test accuracy: 0.991
>>>
>>>
>>> predictions = model.predict(x_test)
>>> #note  hot encoded is not collapsed
... np.round(predictions)
array([[0., 0., 0., ..., 1., 0., 0.],
       [0., 0., 1., ..., 0., 0., 0.],
       [0., 1., 0., ..., 0., 0., 0.],
       ...,
       [0., 0., 0., ..., 0., 0., 0.],
       [0., 0., 0., ..., 0., 0., 0.],
       [0., 0., 0., ..., 0., 0., 0.]], dtype=float32)
>>>
>>>
>>> np.argmax(predictions, axis=1) #digit predictions
array([7, 2, 1, ..., 4, 5, 6], dtype=int64)
>>>
>>> #sklearn metrics
... confusion_matrix(y_test_original, np.argmax(predictions, axis=1) )
array([[ 979,    0,    0,    0,    0,    0,    0,    1,    0,    0],
       [   0, 1133,    0,    2,    0,    0,    0,    0,    0,    0],
       [   2,    2, 1023,    0,    1,    0,    0,    4,    0,    0],
       [   0,    0,    1, 1005,    0,    2,    0,    1,    1,    0],
       [   0,    0,    0,    0,  974,    0,    5,    0,    1,    2],
       [   3,    0,    0,    6,    0,  881,    2,    0,    0,    0],
       [   5,    2,    0,    0,    1,    1,  948,    0,    1,    0],
       [   0,    2,    4,    1,    0,    0,    0, 1019,    1,    1],
       [   4,    0,    2,    0,    0,    0,    0,    1,  966,    1],
       [   2,    2,    0,    0,    7,    5,    0,    6,    5,  982]],
      dtype=int64)
>>>



###NLP in Python 
##Automatic Summarization Using Different Methods from Sumy
#https://github.com/miso-belica/sumy


##Summerization method in sumy 
from sumy.parsers.html import HtmlParser
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer

from sumy.nlp.stemmers import Stemmer
from sumy.utils import get_stop_words
 
from sumy.summarizers.luhn import LuhnSummarizer
from sumy.summarizers.edmundson import EdmundsonSummarizer   #this is the best as 
from sumy.summarizers.lsa import LsaSummarizer
 
LANGUAGE = "english"
SENTENCES_COUNT = 10
 
 
url="https://en.wikipedia.org/wiki/Deep_learning"

parser = HtmlParser.from_url(url, Tokenizer(LANGUAGE))
# or for plain text files
# parser = PlaintextParser.from_file("document.txt", Tokenizer(LANGUAGE)) 
    
print ("--LsaSummarizer--")    
summarizer = LsaSummarizer(Stemmer(LANGUAGE))
summarizer.stop_words = get_stop_words(LANGUAGE)

#top 10 sentence
for sentence in summarizer(parser.document, SENTENCES_COUNT):
    print(sentence)
     
print ("--LuhnSummarizer--")     
summarizer = LsaSummarizer(Stemmer(LANGUAGE))
summarizer.stop_words = ("I", "am", "the", "you", "are", "me", "is", "than", "that", "this",)
#windows console can not display utf-8
for sentence in summarizer(parser.document, SENTENCES_COUNT):
    print(str(sentence).encode("utf-8"))
         
 

###Word vectors and similarity
#spaCy is able to compare two objects, and make a prediction of how similar they are. 
python -m spacy download en_core_web_md
#if linkinf fails, create it manually 
c:\python35\lib\site-packages\en_core_web_md --> c:\python35\lib\site-packages\spacy\data\en_core_web_md

mklink /D c:\python35\lib\site-packages\spacy\data\en_core_web_md c:\python35\lib\site-packages\en_core_web_md

#example 
import spacy 
nlp = spacy.load('en_core_web_md')  # make sure to use larger model!
tokens = nlp(u'dog cat banana')

for token1 in tokens:
    for token2 in tokens:
        print(token1.text, token2.text, token1.similarity(token2))

#or with doc 
doc1 = nlp("That person is dying")
doc2 = nlp("That person is dead")
doc3 = nlp("I love dog")
doc1.similarity(doc2) #.96
doc3.similarity(doc1) #.63

#(higher is more similar) 
        dog    cat     banana
dog     1.00    0.80    0.24  
cat     0.80    1.00    0.28  
banana  0.24    0.28    1.00  


#Similarity is determined by comparing word vectors or "word embeddings"(document term matrix), 
doc1.vector




###Sentiment analysis
##Java 64 bit 1.8+ (Check with command: java -version) is required, 
#if 32 bit , update path with 64 bit version 
$ set PATH=C:\Program Files\Java\jre1.8.0_66\bin;%PATH%
#Download from https://stanfordnlp.github.io/CoreNLP/history.html
#and unzip to eg C:\nltk_data\stanford-corenlp-full-2018-02-27

$ pip install stanfordcorenlp
#https://github.com/Lynten/stanford-corenlp
#Then change site-packages\stanfordcorenlp\corenlp.py, line 46, include shell=True



from stanfordcorenlp import StanfordCoreNLP




def getValue(text):
    nlp = StanfordCoreNLP(r'C:\nltk_data\stanford-corenlp-full-2018-02-27')
    output = nlp.annotate(text, properties={
            "annotators": "tokenize,ssplit,parse,sentiment",
            "outputFormat": "json",
            # Only split the sentence at End Of Line. We assume that this method only takes in one single sentence.
            "ssplit.eolonly": "true",
            # Setting enforceRequirements to skip some annotators and make the process faster
            "enforceRequirements": "false",
            'pipelineLanguage':'en'
        })
    # Only care about the result of the first sentence because we assume we only annotate a single sentence in this method.
    import json 
    obj  = json.loads(output)
    nlp.close()
    return int(obj['sentences'][0]['sentimentValue'])

texts = ['I like the service.', 
    'I absolutly love this service', 
    'I hate this service', 'I disgust this service']
    
for t in texts:
    print(getValue(t))
# 3 3 1 3 #???



###nltk - VADER sentiment analysis tools

from nltk.sentiment.vader import SentimentIntensityAnalyzer

texts = ['I like the service.', 
    'I absolutly love this service', 
    'I hate this service', 'I disgust this service']


    
sid = SentimentIntensityAnalyzer() #Give a sentiment intensity score to sentences
for sentence in texts:
    print(sentence)
    ss = sid.polarity_scores(sentence) 
    for k in sorted(ss):
        print('{0}: {1}, '.format(k, ss[k]), end='')
    print()
#OUTPUT
##Return a float for sentiment strength based on the input text. 
#compound key: Positive values are positive valence, negative value are negative valence
I like the service.
compound: 0.3612, neg: 0.0, neu: 0.444, pos: 0.556,
I absolutly love this service
compound: 0.6369, neg: 0.0, neu: 0.417, pos: 0.583,
I hate this service
compound: -0.5719, neg: 0.649, neu: 0.351, pos: 0.0,
I disgust this service
compound: -0.5994, neg: 0.661, neu: 0.339, pos: 0.0,

###NLTK Usages 
import nltk.corpus
import nltk 
text = nltk.Text(nltk.corpus.gutenberg.words('melville-moby_dick.txt'))


#OR 
f=open('toBeshared/data/melville-moby_dick.txt')
raw=f.read()
f.close()
tokens = nltk.word_tokenize(raw)
text = nltk.Text(tokens)

#collocations():Collocation refers to how words go together or form fixed relationships
text.collocations()

#common_contexts(words):Find contexts where the specified words appear
text.common_contexts(["monstrous", "very"])

#concordance(word):A concordance view shows us every occurrence of a given word
text.concordance("monstrous")

#count(word):Count the number of times this word appears in the text.
text.count("monstrous")

#dispersion_plot(words):Produce a plot showing the distribution of the words through the text. 
#Each stripe represents an instance of a word, and each row represents the entire text
#location of a word in the text: how many words from the beginning it appears
text.dispersion_plot(["citizens", "democracy", "freedom", "duties", "America"])

#findall(regexp);Find instances of the regular expression in the text
#angle brackets as non-capturing parentheses
text.findall("<.*><.*><monstrous>")
    
#plot():plot frquency distribution 
text.plot()

#similar(word): find other words which appear in the same contexts as the specified word
text.similar("monstrous")

#vocab() : FreqDist of all words 
text.vocab()


#Counting Vocabulary
len(text)
sorted(set(text)) 
len(set(text)) 

#calculate a measure of the lexical richness of the text
len(set(text)) / len(text)  #number of distinct words is just 6% of the total number of words


#Frequency of words 
fdist1 = nltk.probability.FreqDist(tokens) 
print(fdist1) 
fdist1.most_common(50)
fdist1['whale']

#Conditional FreqDist= conditions is len vs FreqDist of word 
cfdist = nltk.probability.ConditionalFreqDist((len(word), word) for word in tokens)
cfdist[3]  #for len 3
cfdist[3].freq('the') #for len 3, freq of 'the' across all 3 length  
cfdist[3]['dog'] #for len 3, # of dog 


#The Porter and Lancaster stemmers follow their own rules for stripping affixes. 
#Observe that the Porter stemmer correctly handles the word lying (mapping it to lie), 
#while the Lancaster stemmer does not.

porter = nltk.PorterStemmer()
lancaster = nltk.LancasterStemmer()
[porter.stem(t) for t in tokens[:100]]
[lancaster.stem(t) for t in tokens[:100]]

##Lemmatization
#The WordNet lemmatizer is a good choice if you want to compile the vocabulary of some texts 
#and want a list of valid lemmas (or lexicon headwords).


#The WordNet lemmatizer only removes affixes if the resulting word is in its dictionary. 
#This additional checking process makes the lemmatizer slower than the above stemmers. 
#Notice that it doesn't handle lying, but it converts women to woman.

wnl = nltk.WordNetLemmatizer()
[wnl.lemmatize(t) for t in tokens[:100]]


##Brown Corpus
#The Brown Corpus was the first million-word electronic corpus of English, 
#created in 1961 at Brown University. 

#ID File Genre   Description
A16 ca16 news Chicago Tribune: Society Reportage 
B02 cb02 editorial Christian Science Monitor: Editorials 
C17 cc17 reviews Time Magazine: Reviews 
D12 cd12 religion Underwood: Probing the Ethics of Realtors 
E36 ce36 hobbies Norling: Renting a Car in Europe 
F25 cf25 lore Boroff: Jewish Teenage Culture 
G22 cg22 belles_lettres Reiner: Coping with Runaway Technology 
H15 ch15 government US Office of Civil and Defence Mobilization: The Family Fallout Shelter 
J17 cj19 learned Mosteller: Probability with Statistical Applications 
K04 ck04 fiction W.E.B. Du Bois: Worlds of Color 
L13 cl13 mystery Hitchens: Footsteps in the Night 
M01 cm01 science_fiction Heinlein: Stranger in a Strange Land 
N14 cn15 adventure Field: Rattlesnake Ridge 
P12 cp12 romance Callaghan: A Passion in Rome 
R06 cr06 humor Thurber: The Future, If Any, of Comedy 

#Example 
from nltk.corpus import brown
>>> brown.categories()
['adventure', 'belles_lettres', 'editorial', 'fiction', 'government', 'hobbies',
'humor', 'learned', 'lore', 'mystery', 'news', 'religion', 'reviews', 'romance',
'science_fiction']
>>> brown.words(categories='news')
['The', 'Fulton', 'County', 'Grand', 'Jury', 'said', ...]
>>> brown.words(fileids=['cg22'])
['Does', 'our', 'society', 'have', 'a', 'runaway', ',', ...]
>>> brown.sents(categories=['news', 'editorial', 'reviews'])
[['The', 'Fulton', 'County'...], ['The', 'jury', 'further'...], ...]
 
 
#to obtain counts for each genre of interest
#(condition, variable),  For same condition , the freqdist of variable

cfd = nltk.ConditionalFreqDist( (genre, word) for genre in brown.categories() 
    for word in brown.words(categories=genre))
genres = ['news', 'religion', 'hobbies', 'science_fiction', 'romance', 'humor']
modals = ['can', 'could', 'may', 'might', 'must', 'will']
>>> cfd.tabulate(conditions=genres, samples=modals)
                 can could  may might must will
           news   93   86   66   38   50  389
       religion   82   59   78   12   54   71
        hobbies  268   58  131   22   83  264
science_fiction   16   49    4   12    8   16
        romance   74  193   11   51   45   43
          humor   16   30    8    8    9   13
 



###NLTK Based Tools and TD-IDF: Similarity(cosine similarity) with sklearn and nltk 
import nltk, string


#The Porter stemmers strip affixes(eg -ing) 
stemmer = nltk.stem.porter.PorterStemmer()
remove_punctuation_map = dict((ord(char), None) for char in string.punctuation)

def stem_tokens(tokens):
    return [stemmer.stem(item) for item in tokens]

'''remove punctuation, lowercase, stem'''
def normalize(text):
    #translate:Return a copy of the string S in which each character has been mapped through the given translation table.
    return stem_tokens(nltk.word_tokenize(text.lower().translate(remove_punctuation_map)))

vectorizer = TfidfVectorizer(tokenizer=normalize, stop_words='english')
# index [0,1] is the positions in the matrix for the similarity 
#since two text inputs will create a 2x2 symmetrical matrix
def cosine_sim(text1, text2):
    tfidf = vectorizer.fit_transform([text1, text2])
    return ((tfidf * tfidf.T).A) [0,1]  #matrix.A Return self as an ndarray object


print(cosine_sim('a little bird', 'a little bird'))#0.9999999999999998
print(cosine_sim('a little bird', 'a little bird chirps')) #0.7092972666062738
print(cosine_sim('a little bird', 'a big dog barks'))#0.0





###+++ LDA and display of LDA - using spacy, nltk, gensim and pyLDAvis
$ pip install pyLDAvis

#Latent Dirichlet Allocation (LDA)- topic modelling technique
#Given a document, we can find it's topic(relevance) based on corpora, dictionary 


##Step-1 - Text Cleaning

import spacy
spacy.load('en')
from spacy.lang.en import English
parser = English()

def tokenize(text):
    lda_tokens = []
    tokens = parser(text)
    for token in tokens:
        if token.orth_.isspace():
            continue
        elif token.like_url:
            lda_tokens.append('URL')
        elif token.orth_.startswith('@'):
            lda_tokens.append('SCREEN_NAME')
        else:
            lda_tokens.append(token.lower_)
    return lda_tokens

#use NLTK's Wordnet(a corpora) to find the meanings of words, synonyms, antonyms, and more. 
import nltk
nltk.download('wordnet')

from nltk.corpus import wordnet as wn
def get_lemma(word):
    lemma = wn.morphy(word)
    if lemma is None:
        return word
    else:
        return lemma

#Or use below (WordNetLemmatizer to get the root word)
from nltk.stem.wordnet import WordNetLemmatizer
def get_lemma2(word):
    return WordNetLemmatizer().lemmatize(word)

#Filter out stop words:
nltk.download('stopwords')
en_stop = set(nltk.corpus.stopwords.words('english'))

#Then full processing 

def prepare_text_for_lda(text):
    tokens = tokenize(text)
    tokens = [token for token in tokens if len(token) > 4]
    tokens = [token for token in tokens if token not in en_stop]
    tokens = [get_lemma(token) for token in tokens]
    return tokens

#Create list of tokens 

import random
text_data = []
with open('tobeShared/data/dataset.csv') as f:
    for line in f:
        tokens = prepare_text_for_lda(line)
        text_data.append(tokens)

        
        
##STEP-2: LDA with Gensim

#Then build our corpora and dictionary 
from gensim import corpora
dictionary = corpora.Dictionary(text_data)
corpus = [dictionary.doc2bow(text) for text in text_data]

#for later use 
dictionary.save('dictionary.gensim')
corpora.MmCorpus.serialize('corpus.gensim.mm', corpus) 




#Train LDA for 5 topics

import gensim
NUM_TOPICS = 5
#train LDA 
ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics = NUM_TOPICS,
        id2word=dictionary, passes=15)
ldamodel.save('model5.gensim')


topics = ldamodel.print_topics(num_words=4)
for topic in topics:
    print(topic)
#Eg Topic 0 includes words like 'processor', "database", "issue" and "overview",
#and so-on 
(0, '0.032*"query" + 0.016*"model" + 0.015*"using" + 0.011*"efficient"')
(1, '0.032*"base" + 0.020*"power" + 0.013*"system" + 0.012*"network"')
(2, '0.026*"base" + 0.013*"network" + 0.011*"analysis" + 0.010*"scheme"')
(3, '0.022*"design" + 0.021*"system" + 0.012*"using" + 0.012*"base"')
(4, '0.050*"network" + 0.027*"wireless" + 0.015*"sensor" + 0.013*"system"')

#Find topics for  new document:
new_doc = 'Practical Bayesian Optimization of Machine Learning Algorithms'
new_doc = prepare_text_for_lda(new_doc)
new_doc_bow = dictionary.doc2bow(new_doc)
print(new_doc_bow)  #(125, 1), (234, 1), (442, 1), (587, 1), (1859, 1)]
print(ldamodel.get_document_topics(new_doc_bow))
#(0, 0.033543985), (1, 0.37556702), (2, 0.033457167), (3, 0.52288413), (4, 0.03447675)]
#Topic 1 relevance is 0.37556702 , so on and so forth 


##STEP3: Display 
#pyLDAvis is designed to help users interpret the topics in a topic model 
#an interactive web-based visualization.

#Visualizing 5 topics:

dictionary = corpora.Dictionary.load('dictionary.gensim')
corpus = corpora.MmCorpus('corpus.gensim.mm')
lda = gensim.models.ldamodel.LdaModel.load('model5.gensim')

import pyLDAvis.gensim
lda_display = pyLDAvis.gensim.prepare(lda, corpus, dictionary, sort_topics=False)
#pyLDAviz expects continuous user interaction , so creates IPYTHON HTML object 
pyLDAvis.display(lda_display)
#save to html 
pyLDAvis.save_html(lda_display, open('display.html', "wt"))

#save_json: save json representation of visualization to file
#save_html : save html representation of a visualization to file
#show : launch a local server and show a visualization in a browser
#display : embed visualization within the IPython notebook
#enable_notebook : automatically embed visualizations in IPython notebook


#Understanding 
Saliency
    a measure of how much the term tells you about the topic.
Relevance
    a weighted average of the probability of the word given the topic 
    and the word given the topic normalized by the probability of the topic.
Size of the bubble
    The size of the bubble measures the importance of the topics, relative to the data.


    
    
    
###NMF and LDA 


n_samples = 2000
n_features = 1000
n_components = 10
n_top_words = 20
n_test_size = 10 

#.components_ contain topics 
#nmf.components_.shape = 10 x 1000 = n_components x n_features
#where value is the each feature/term/word, j relevance to topic i
def print_top_words(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components_):
        message = "Topic #%d: " % topic_idx
        message += " ".join([feature_names[i] for i in topic.argsort()[:-n_top_words - 1:-1]])
        print(message)
    print()

def print_new_data(model, n_topics, X):
    trx = model.transform(X)
    tops = [ "topic-"+str(i) for i in range(n_topics)]
    for sam in trx:
        d = dict(zip(tops,sam))
        print(sorted(d.items(), key=lambda t:t[1], reverse=True))
    
# Load the 20 newsgroups dataset and vectorize it. We use a few heuristics
# to filter out useless terms early on: the posts are stripped of headers,
# footers and quoted replies, and common English words, words occurring in
# only one document or in at least 95% of the documents are removed.


dataset = fetch_20newsgroups(shuffle=True, random_state=1, remove=('headers', 'footers', 'quotes'))
data_samples = dataset.data[:n_samples]
data_test = dataset.data[n_samples:n_samples + n_test_size]

'''
max_df : float in range [0.0, 1.0] or int, default=1.0
    When building the vocabulary ignore terms that have a document frequency strictly 
    higher than the given threshold 
    If float, the parameter represents a proportion of documents, 
    integer absolute counts. 
min_df : float in range [0.0, 1.0] or int, default=1
    When building the vocabulary ignore terms that have a document frequency strictly 
    lower than the given threshold. 
    This value is also called cut-off in the literature. 
    If float, the parameter represents a proportion of documents, 
    integer absolute counts. 
max_features : int or None, default=None
    If not None, build a vocabulary that only consider the top max_features 
    ordered by term frequency across the corpus.
'''  
    

# Use tf-idf features for NMF.
print("Extracting tf-idf features for NMF...")
#Remove words that are not present in 95% documents 
#Remove words that are only present in < 2 documents 
#Only take 1000 terms/features in the term document matrix 
tfidf_vectorizer = TfidfVectorizer(max_df=0.95, min_df=2,
                                   max_features=n_features,
                                   stop_words='english')
nmf = NMF(n_components=n_components, random_state=1,
          alpha=.1, l1_ratio=.5)
          
pn = Pipeline([('tfidf' , tfidf_vectorizer),('nmf', nmf)])
pn.fit(data_samples)
print("\nTopics in NMF model")
tfidf_feature_names = tfidf_vectorizer.get_feature_names()
print_top_words(nmf, tfidf_feature_names, n_top_words)
print_new_data(pn, n_components, data_test)                              

# Use tf (raw term count) features for LDA.
tf_vectorizer = CountVectorizer(max_df=0.95, min_df=2,
                                max_features=n_features,
                                stop_words='english')
lda = LatentDirichletAllocation(n_components=n_components, max_iter=5,
                                learning_method='online',
                                learning_offset=50.,
                                random_state=0)
pn2 = Pipeline([('tf' , tf_vectorizer),('lda', lda)])
pn2.fit(data_samples)
print("\nTopics in LDA model:")
tf_feature_names = tf_vectorizer.get_feature_names()
print_top_words(lda, tf_feature_names, n_top_words)
print_new_data(pn2, n_components, data_test)  









###Naive Bayes - applications - Spam detection 

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import nltk
import string
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report,confusion_matrix

#since the dataset comes with additional unnamed, column, drop them first

messages = pd.read_csv('tobeShared/data/spam.csv', encoding='latin-1')
messages.drop(['Unnamed: 2','Unnamed: 3','Unnamed: 4'],axis=1,inplace=True)
messages = messages.rename(columns={'v1': 'class','v2': 'text'})

messages.head()
messages.groupby('class').describe()
'''
       text
      count unique
class
ham    4825   4516
spam    747    653


from above information, we know that:

    only about 15% of the text messages is classified as a spam
    there are some duplicate messages, since the number of unique values lower than the count values of the text

in the next part, lext check the length of each text messages to see whether it is correlated with the text classified as a spam or not.
'''
#for Series, each element - apply
messages['length'] = messages['text'].apply(len)

messages.hist(column='length',by='class',bins=50, figsize=(15,6))


def process_text(text, lower_case = True, stem = True, stop_words = True):    
    message = [char for char in text if char not in string.punctuation]
    message = ''.join(message)     
    if lower_case:
        message = message.lower()
    words = word_tokenize(message)
    words = [w for w in words if len(w) > 2]
    if stop_words:
        sw = stopwords.words('english')
        words = [word for word in words if word not in sw]
    if stem:
        stemmer = PorterStemmer()
        words = [stemmer.stem(word) for word in words]       
    return words

    
    
msg_train, msg_test, class_train, class_test = train_test_split(messages['text'],messages['class'],test_size=0.2)

#take 1 .. 2 words 
pipeline = Pipeline([
    ('bow',CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), # converts strings to integer counts
    ('tfidf',TfidfTransformer()), # converts integer counts to weighted TF-IDF scores
    #it produces sparse matrix, hence next estimator must accept sparse matrix 
    ('classifier',MultinomialNB()) # train on TF-IDF vectors with Naive Bayes classifier
    #('classifier',SGDClassifier())
])

pipeline.fit(msg_train,class_train)

predictions = pipeline.predict(msg_test)
'''
precision
    for all instances classified positive, what percent was correct?
recall
    for all instances that were actually positive, what percent was classified correctly? ”
f1 score
    harmonic mean of precision and recall 
'''
print(classification_report(class_test,predictions))
>>> print(classification_report(class_test,predictions))
              precision    recall  f1-score   support#how many True class for that row

         ham       0.96      1.00      0.98       968
        spam       1.00      0.75      0.86       147

   micro avg       0.97      0.97      0.97      1115
   macro avg       0.98      0.87      0.92      1115
weighted avg       0.97      0.97      0.96      1115
import seaborn as sns
sns.heatmap(confusion_matrix(class_test,predictions),annot=True)




###Example - Categorization of text 

categories = [
    'alt.atheism',
    'talk.religion.misc',
]
# Uncomment the following to do the analysis on all the categories
#categories = None


data = fetch_20newsgroups(subset='train', categories=categories)
print("%d documents" % len(data.filenames))
print("%d categories %s" % (len(data.target_names),data.target_names) )
test = fetch_20newsgroups(subset='test', categories=categories)


pipeline = Pipeline([
    ('vect', CountVectorizer()),
    ('tfidf', TfidfTransformer()),
    ('clf', SGDClassifier()),
])

# uncommenting more parameters will give better exploring power but will
# increase processing time in a combinatorial way
parameters = {
    'vect__max_df': (0.5, 0.75, 1.0),
    # 'vect__max_features': (None, 5000, 10000, 50000),
    'vect__ngram_range': ((1, 1), (1, 2)),  # unigrams or bigrams
    # 'tfidf__use_idf': (True, False),
    # 'tfidf__norm': ('l1', 'l2'),
    'clf__max_iter': (5,),
    'clf__alpha': (0.00001, 0.000001),
    'clf__penalty': ('l2', 'elasticnet'),
    # 'clf__max_iter': (10, 50, 80),
}


# multiprocessing requires the fork to happen in a __main__ protected
# block

# find the best parameters for both the feature extraction and the
# classifier
grid_search = GridSearchCV(pipeline, parameters, cv=5,
                           n_jobs=-1, verbose=1)

grid_search.fit(data.data, data.target)

best_parameters = grid_search.best_estimator_.get_params()
grid_search.score(data.data, data.target)
grid_search.score(test.data, test.target)    


###+++ Recomender system in Python 
$ pip install --upgrade --no-deps  --force-reinstall scikit-surprise
#https://datasciencemadesimpler.wordpress.com/tag/alternating-least-squares/


###User-user Collaborative Filtering

from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from surprise import KNNWithMeans
from surprise import Dataset
from surprise import accuracy
from surprise.model_selection import train_test_split

# Load the movielens-100k dataset  UserID::MovieID::Rating::Timestamp
data = Dataset.load_builtin('ml-100k')
trainset, testset = train_test_split(data, test_size=.15)

# Use user_based true/false to switch between user-based or item-based collaborative filtering
algo = KNNWithMeans(k=50, sim_options={'name': 'pearson_baseline', 'user_based': True})
algo.fit(trainset)

# we can now query for specific predicions
uid = str(196)  # raw user id
iid = str(302)  # raw item id

# get a prediction for specific users and items.
pred = algo.predict(uid, iid, r_ui=4, verbose=True)

# run the trained model against the testset
test_pred = algo.test(testset)

# get RMSE
print("User-based Model : Test Set")
accuracy.rmse(test_pred, verbose=True)

# if you wanted to evaluate on the trainset
print("User-based Model : Training Set")
train_pred = algo.test(trainset.build_testset())
accuracy.rmse(train_pred)





###Item-Item Collaborative Filtering
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from surprise import KNNWithMeans
from surprise import Dataset
from surprise import accuracy
from surprise.model_selection import train_test_split

# Load the movielens-100k dataset  UserID::MovieID::Rating::Timestamp
data = Dataset.load_builtin('ml-100k')
trainset, testset = train_test_split(data, test_size=.15)

# Use user_based true/false to switch between user-based or item-based collaborative filtering
algo = KNNWithMeans(k=50, sim_options={'name': 'pearson_baseline', 'user_based': False})
algo.fit(trainset)

# run the trained model against the testset
test_pred = algo.test(testset)

# get RMSE
print("Item-based Model : Test Set")
accuracy.rmse(test_pred, verbose=True)

# if you wanted to evaluate on the trainset
print("Item-based Model : Training Set")
train_pred = algo.test(trainset.build_testset())
accuracy.rmse(train_pred)

# Testing ALS(alternating least squares) baseline
bsl_options = {'method': 'als',
               'n_epochs': 50,
               'reg_u': 5,
               'reg_i': 1
               }

# Testing SGD regressor
# bsl_options = {'method': 'sgd',
#                'learning_rate': .008,
#                }


algo = KNNWithMeans(k=50, bsl_options=bsl_options, sim_options={'name': 'pearson_baseline', 'user_based': False})
algo.fit(trainset)
test_pred = algo.test(testset)
print("Item-based Model : Test Set")
accuracy.rmse(test_pred, verbose=True)




###Matrix Factorization
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from surprise import SVDpp
from surprise import SVD
from surprise import Dataset
from surprise import accuracy
from surprise.model_selection import train_test_split
from surprise.model_selection import GridSearchCV
from surprise.model_selection import cross_validate

# Use movielens-100K
data = Dataset.load_builtin('ml-100k')
trainset, testset = train_test_split(data, test_size=.15)

# ----- SVD ----- #

param_grid = {'n_factors': [110, 120, 140, 160], 'n_epochs': [90, 100, 110], 'lr_all': [0.001, 0.003, 0.005, 0.008],
              'reg_all': [0.08, 0.1, 0.15]}
gs = GridSearchCV(SVD, param_grid, measures=['rmse', 'mae'], cv=3)
gs.fit(data)
algo = gs.best_estimator['rmse']
print(gs.best_score['rmse'])
print(gs.best_params['rmse'])
cross_validate(algo, data, measures=['RMSE', 'MAE'], cv=5, verbose=True)

# Use the new parameters with the train data
algo = SVD(n_factors=160, n_epochs=100, lr_all=0.005, reg_all=0.1)
algo.fit(trainset)
test_pred = algo.test(testset)
print("SVD : Test Set")
accuracy.rmse(test_pred, verbose=True)

# ----- SVD++ ----- #

param_grid = {'n_factors': [20, 30, 40], 'n_epochs': [20,30,40], 'lr_all': [0.001, 0.003, 0.005, 0.008],
              'reg_all': [0.08, 0.1, 0.15]}
gs = GridSearchCV(SVDpp, param_grid, measures=['rmse', 'mae'], cv=3)
gs.fit(data)
algo = gs.best_estimator['rmse']
print(gs.best_score['rmse'])
print(gs.best_params['rmse'])
cross_validate(algo, data, measures=['RMSE', 'MAE'], cv=5, verbose=True)

# Use the new parameters with the train data
algo = SVDpp(n_factors=40, n_epochs=40, lr_all=0.008, reg_all=0.1)
algo = SVDpp()
algo.fit(trainset)
test_pred = algo.test(testset)
print("SVD++ : Test Set")
accuracy.rmse(test_pred, verbose=True)

#Output 
Evaluating RMSE, MAE of algorithm KNNWithMeans on 5 split(s).

                  Fold 1  Fold 2  Fold 3  Fold 4  Fold 5  Mean    Std     
MAE (testset)     0.7191  0.7158  0.7138  0.7166  0.7254  0.7181  0.0040  
RMSE (testset)    0.9173  0.9162  0.9125  0.9179  0.9271  0.9182  0.0048  
Fit time          1.04    1.11    1.03    1.01    0.90    1.02    0.07    
Test time         2.08    2.06    2.06    2.05    2.06    2.06    0.01    
{'test_mae': array([0.71909501, 0.71579784, 0.71384567, 0.71656901, 0.72541331]), 'fit_time': (1.0419056415557861, 1.1055827140808105, 1.0349535942077637, 1.01346755027771, 0.9016950130462646), 'test_rmse': array([0.91726677, 0.91622589, 0.91245293, 0.91793969, 0.92711428]), 'test_time': (2.0783369541168213, 2.0616250038146973, 2.0627968311309814, 2.049354314804077, 2.058506727218628)}

SVD : Test Set
RMSE: 0.9000

##For SVD++ (Be warned it is much slower than SVD)

Grid Search Results:

0.9167768433405562
{'n_factors': 40, 'reg_all': 0.1, 'n_epochs': 40, 'lr_all': 0.008}

Evaluating RMSE, MAE of algorithm SVDpp on 5 split(s).

                  Fold 1  Fold 2  Fold 3  Fold 4  Fold 5  Mean    Std     
RMSE (testset)    0.9104  0.9053  0.9111  0.9133  0.9124  0.9105  0.0028  
MAE (testset)     0.7188  0.7145  0.7204  0.7224  0.7203  0.7193  0.0027  
Fit time          336.05  334.75  335.30  334.70  339.24  336.01  1.69    
Test time         1.79    1.84    1.86    1.84    1.74    1.81    0.04    

SVD++ : Test Set
RMSE: 0.9141






###Content-based : Nearest Neighbours - Top Recommendations

#This code demonstrates how to get the 10 most related items (nearest neighbours) to the movie item "Clockwork Orange".
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
import io  # needed because of weird encoding of u.item file

from surprise import KNNBaseline
from surprise import Dataset
from surprise import get_dataset_dir


def read_item_names():
    """Read the u.item file from MovieLens 100-k dataset and return two
    mappings to convert raw ids into movie names and movie names into raw ids.
    """

    file_name = get_dataset_dir() + '/ml-100k/ml-100k/u.item'
    rid_to_name = {}
    name_to_rid = {}
    with io.open(file_name, 'r', encoding='ISO-8859-1') as f:
        for line in f:
            line = line.split('|')
            rid_to_name[line[0]] = line[1]
            name_to_rid[line[1]] = line[0]

    return rid_to_name, name_to_rid


# First, train the algortihm to compute the similarities between items
data = Dataset.load_builtin('ml-100k')
trainset = data.build_full_trainset()
sim_options = {'name': 'pearson_baseline', 'user_based': False}
algo = KNNBaseline(sim_options=sim_options)
algo.fit(trainset)

# Read the mappings raw id <-> movie name
rid_to_name, name_to_rid = read_item_names()

# Retrieve inner id of the movie
movie_raw_id = name_to_rid['Clockwork Orange, A (1971)']
movie_inner_id = algo.trainset.to_inner_iid(movie_raw_id)
movie_neighbors = algo.get_neighbors(movie_inner_id, k=10)

# Convert inner ids of the neighbors into names.
movie_neighbors = (algo.trainset.to_raw_iid(inner_id)
                   for inner_id in movie_neighbors)
movie_neighbors = (rid_to_name[rid]
                   for rid in movie_neighbors)

print()
print('The 10 nearest neighbors of Toy Story are:')
for movie in movie_neighbors:
    print(movie)

    
###Association Mining
#association mining, which is a form of descriptive analytics. This can be used to develop marketing strategies like cross-selling or up-selling.
#Demonstrates how to get frequent items and association rules using the mlxtend package.
#One finding is this:
#Jumbo Storage Bag Suki is usually bought together with Jumbo Bag Red Retrospot.

import pandas as pd
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules


def encode_units(x):
    if x <= 0:
        return 0
    if x >= 1:
        return 1


df = pd.read_excel('http://archive.ics.uci.edu/ml/machine-learning-databases/00352/Online%20Retail.xlsx')
df.head()

# Data Preprocessing

df['Description'] = df['Description'].str.strip()  # remove spaces
df.dropna(axis=0, subset=['InvoiceNo'], inplace=True)  # drop all rows where invoiceNo is missing
df['InvoiceNo'] = df['InvoiceNo'].astype('str')
df = df[~df['InvoiceNo'].str.contains('C')]  # drop all rows where invoiceNo has C in it

new_df = df
new_df.groupby(["InvoiceNo", "Description"])["Quantity"].sum()
basket = pd.pivot_table(new_df, values='Quantity', index='InvoiceNo', columns='Description').fillna(0)

basket_sets = basket.applymap(encode_units)  # if > 1 set to 1
basket_sets.drop('POSTAGE', inplace=True, axis=1)

frequent_itemsets = apriori(basket_sets, min_support=0.035, use_colnames=True)
frequent_itemsets.groupby(["support"])

rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)
rules.head()

frequent_itemsets.to_csv("./frequent_itemsets.csv")
rules.to_csv("./rules.csv")




###basic recommendation system(collaborative filtering) using Python and Pandas.
#File.tsv contains 'user_id', 'item_id', 'rating', 'timestamp'
#whereas Movie_Id_Titles.csv contans item_id vs name 

import pandas as pd 
  
# Get the data 
column_names = ['user_id', 'item_id', 'rating', 'timestamp'] 
  
path = 'data/file.tsv'
  
df = pd.read_csv(path, sep='\t', names=column_names) 
  
# Check the head of the data 
df.head() 

# Check out all the movies and their respective IDs 
movie_titles = pd.read_csv('data/Movie_Id_Titles.csv') 
movie_titles.head() 


data = pd.merge(df, movie_titles, on='item_id') 
data.head() 

# Calculate mean rating of all movies 
data.groupby('title')['rating'].mean().sort_values(ascending=False).head() 

# Calculate count rating of all movies 
data.groupby('title')['rating'].count().sort_values(ascending=False).head() 


# creating dataframe with 'rating' count values 
ratings = pd.DataFrame(data.groupby('title')['rating'].mean())  
  
ratings['num of ratings'] = pd.DataFrame(data.groupby('title')['rating'].count()) 
  
ratings.head() 

#Visualization imports:

import matplotlib.pyplot as plt 
import seaborn as sns 
  
sns.set_style('white') 
%matplotlib inline 

# plot graph of 'num of ratings column' 
plt.figure(figsize =(10, 4)) 
  
ratings['num of ratings'].hist(bins = 70) 

# plot graph of 'ratings' column 
plt.figure(figsize =(10, 4)) 
  
ratings['rating'].hist(bins = 70) 

# Sorting values according to  
# the 'num of rating column' 
moviemat = data.pivot_table(index ='user_id', 
              columns ='title', values ='rating') 
  
moviemat.head() 
  
ratings.sort_values('num of ratings', ascending = False).head(10) 

# analysing correlation with similar movies 
starwars_user_ratings = moviemat['Star Wars (1977)'] 
liarliar_user_ratings = moviemat['Liar Liar (1997)'] 
  
starwars_user_ratings.head() 


# analysing correlation with similar movies 
similar_to_starwars = moviemat.corrwith(starwars_user_ratings) 
similar_to_liarliar = moviemat.corrwith(liarliar_user_ratings) 
  
corr_starwars = pd.DataFrame(similar_to_starwars, columns =['Correlation']) 
corr_starwars.dropna(inplace = True) 
  
corr_starwars.head() 

# Similar movies like starwars 
corr_starwars.sort_values('Correlation', ascending = False).head(10) 
corr_starwars = corr_starwars.join(ratings['num of ratings']) 
  
corr_starwars.head() 
  
corr_starwars[corr_starwars['num of ratings']>100].sort_values('Correlation', ascending = False).head() 

# Similar movies as of liarliar 
corr_liarliar = pd.DataFrame(similar_to_liarliar, columns =['Correlation']) 
corr_liarliar.dropna(inplace = True) 
  
corr_liarliar = corr_liarliar.join(ratings['num of ratings']) 
corr_liarliar[corr_liarliar['num of ratings']>100].sort_values('Correlation', ascending = False).head() 



###Another examples of Recommender system using surprise 

import pandas as pd
from surprise import Reader
from surprise import Dataset
from surprise.model_selection import cross_validate
from surprise import NormalPredictor
from surprise import KNNBasic
from surprise import KNNWithMeans
from surprise import KNNWithZScore
from surprise import KNNBaseline
from surprise import SVD
from surprise import BaselineOnly
from surprise import SVDpp
from surprise import NMF
from surprise import SlopeOne
from surprise import CoClustering
from surprise.accuracy import rmse
from surprise import accuracy
from surprise.model_selection import train_test_split


user = pd.read_csv('BX-Users.csv', sep=';', error_bad_lines=False, encoding="latin-1")
user.columns = ['userID', 'Location', 'Age']
rating = pd.read_csv('BX-Book-Ratings.csv', sep=';', error_bad_lines=False, encoding="latin-1")
rating.columns = ['userID', 'ISBN', 'bookRating']
> user.head()
  userID 	Location 	Age
0 	1 	nyc, new york, usa 	NaN
1 	2 	stockton, california, usa 	18.0
2 	3 	moscow, yukon territory, russia 	NaN
3 	4 	porto, v.n.gaia, portugal 	17.0
4 	5 	farnborough, hants, united kingdom 	NaN
> rating.head()
	userID 	ISBN 	bookRating
0 	276725 	034545104X 	0
1 	276726 	0155061224 	5
2 	276727 	0446520802 	0
3 	276729 	052165615X 	3
4 	276729 	0521795028 	6

df = pd.merge(user, rating, on='userID', how='inner')
df.drop(['Location', 'Age'], axis=1, inplace=True)
> df.head()
	userID 	ISBN 	bookRating
0 	2 	0195153448 	0
1 	7 	034542252 	0
2 	8 	0002005018 	5
3 	8 	0060973129 	0
4 	8 	0374157065 	0

> df.shape
(1149780, 3)

##Ratings Distribution

from plotly.offline import init_notebook_mode, plot, iplot
import plotly.graph_objs as go
init_notebook_mode(connected=True)

data = df['bookRating'].value_counts().sort_index(ascending=False)
trace = go.Bar(x = data.index,
               text = ['{:.1f} %'.format(val) for val in (data.values / df.shape[0] * 100)],
               textposition = 'auto',
               textfont = dict(color = '#000000'),
               y = data.values,
               )
# Create layout
layout = dict(title = 'Distribution Of {} book-ratings'.format(df.shape[0]),
              xaxis = dict(title = 'Rating'),
              yaxis = dict(title = 'Count'))
# Create plot
fig = go.Figure(data=[trace], layout=layout)
iplot(fig)

#We can see that over 62% of all ratings in the data are 0, 
#and very few ratings are 1 or 2, or 3, 
#low rating books mean they are generally really bad.

#Ratings Distribution By Book
# Number of ratings per book
data = df.groupby('ISBN')['bookRating'].count().clip(upper=50)

# Create trace
trace = go.Histogram(x = data.values,
                     name = 'Ratings',
                     xbins = dict(start = 0,
                                  end = 50,
                                  size = 2))
# Create layout
layout = go.Layout(title = 'Distribution Of Number of Ratings Per Book (Clipped at 50)',
                   xaxis = dict(title = 'Number of Ratings Per Book'),
                   yaxis = dict(title = 'Count'),
                   bargap = 0.2)

# Create plot
fig = go.Figure(data=[trace], layout=layout)
iplot(fig)


> df.groupby('ISBN')['bookRating'].count().reset_index().sort_values('bookRating', ascending=False)[:10]
	ISBN 	bookRating
247408 	0971880107 	2502
47371 	0316666343 	1295
83359 	0385504209 	883
9637 	0060928336 	732
41007 	0312195516 	723
101670 	044023722X 	647
166705 	0679781587 	639
28153 	0142001740 	615
166434 	067976402X 	614
153620 	0671027360 	586

#Most of the books received less than 5 ratings, 
#and very few books have many ratings, 
#although the most rated book has received 2,502 ratings.


##Ratings Distribution By User
# Number of ratings per user
data = df.groupby('userID')['bookRating'].count().clip(upper=50)

# Create trace
trace = go.Histogram(x = data.values,
                     name = 'Ratings',
                     xbins = dict(start = 0,
                                  end = 50,
                                  size = 2))
# Create layout
layout = go.Layout(title = 'Distribution Of Number of Ratings Per User (Clipped at 50)',
                   xaxis = dict(title = 'Ratings Per User'),
                   yaxis = dict(title = 'Count'),
                   bargap = 0.2)

# Create plot
fig = go.Figure(data=[trace], layout=layout)
iplot(fig)

> df.groupby('userID')['bookRating'].count().reset_index().sort_values('bookRating', ascending=False)[:10]
	userID 	bookRating
4213 	11676 	13602
74815 	198711 	7550
58113 	153662 	6109
37356 	98391 	5891
13576 	35859 	5850
80185 	212898 	4785
105111 	278418 	4533
28884 	76352 	3367
42037 	110973 	3100
88584 	235105 	3067

#Most of the users gave less than 5 ratings, 
#and very few users gave many ratings, 
#although the most productive user have given 13,602 ratings.

#To reduce the dimensionality of the dataset, 
#filter out rarely rated movies and rarely rating users.
min_book_ratings = 50
filter_books = df['ISBN'].value_counts() > min_book_ratings
filter_books = filter_books[filter_books].index.tolist()

min_user_ratings = 50
filter_users = df['userID'].value_counts() > min_user_ratings
filter_users = filter_users[filter_users].index.tolist()

df_new = df[(df['ISBN'].isin(filter_books)) & (df['userID'].isin(filter_users))]
print('The original data frame shape:\t{}'.format(df.shape))
print('The new data frame shape:\t{}'.format(df_new.shape))

#The original data frame shape:	(1149780, 3)
#The new data frame shape:	(140516, 3)

##Surprise
#To load a dataset from a pandas dataframe, 
#use the load_from_df() method, 
#The dataframe must have three columns, 
#corresponding to the user ids, the item ids, and the ratings in this order. 
#Each row thus corresponds to a given rating.


reader = Reader(rating_scale=(0, 9))
data = Dataset.load_from_df(df_new[['userID', 'ISBN', 'bookRating']], reader)

##With the Surprise library, we will benchmark the following algorithms
Basic algorithms
    NormalPredictor
        NormalPredictor algorithm predicts a random rating based 
        on the distribution of the training set, which is assumed to be normal. 
        This is one of the most basic algorithms that do not do much work.
    BaselineOnly
        BasiclineOnly algorithm predicts the baseline estimate 
        for given user and item.
k-NN algorithms
    KNNBasic
        KNNBasic is a basic collaborative filtering algorithm.
    KNNWithMeans
        KNNWithMeans is basic collaborative filtering algorithm, 
        taking into account the mean ratings of each user.
    KNNWithZScore
        KNNWithZScore is a basic collaborative filtering algorithm, 
        taking into account the z-score normalization of each user.
    KNNBaseline
        KNNBaseline is a basic collaborative filtering algorithm 
        taking into account a baseline rating.

Matrix Factorization-based algorithms
    SVD
        SVD algorithm is equivalent to Probabilistic Matrix Factorization 
        (http://papers.nips.cc/paper/3208-probabilistic-matrix-factorization.pdf)
    SVDpp
        The SVDpp algorithm is an extension of SVD that takes 
        into account implicit ratings.
    NMF
        NMF is a collaborative filtering algorithm based 
        on Non-negative Matrix Factorization. 
        It is very similar with SVD.
    Slope One
        Slope One is a straightforward implementation of the SlopeOne algorithm. 
        (https://arxiv.org/abs/cs/0702144)
    Co-clustering
        Co-clustering is a collaborative filtering algorithm based on co-clustering 
        (http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.113.6458&rep=rep1&type=pdf)


benchmark = []
# Iterate over all algorithms
for algorithm in [SVD(), SVDpp(), SlopeOne(), NMF(), NormalPredictor(), KNNBaseline(), KNNBasic(), KNNWithMeans(), KNNWithZScore(), BaselineOnly(), CoClustering()]:
    # Perform cross validation
    results = cross_validate(algorithm, data, measures=['RMSE'], cv=3, verbose=False)
    
    # Get results & append algorithm name
    tmp = pd.DataFrame.from_dict(results).mean(axis=0)
    tmp = tmp.append(pd.Series([str(algorithm).split(' ')[0].split('.')[-1]], index=['Algorithm']))
    benchmark.append(tmp)


surprise_results = pd.DataFrame(benchmark).set_index('Algorithm').sort_values('test_rmse')
> surprise_results
        fit_time 	test_rmse 	test_time
Algorithm 			
BaselineOnly 	0.233249 	3.379186 	0.319563
CoClustering 	2.294557 	3.466180 	0.273204
SlopeOne 	0.769663 	3.474766 	3.031999
KNNWithMeans 	0.755913 	3.489696 	4.461669
KNNBaseline 	0.880004 	3.490825 	5.455574
KNNWithZScore 	0.862389 	3.508873 	4.919546
SVD 	5.547440 	3.541042 	0.306871
KNNBasic 	0.667804 	3.725668 	4.032472
SVDpp 	136.691374 	3.790323 	4.714200
NMF 	6.082658 	3.843718 	0.309214
NormalPredictor 	0.114894 	4.665311 	0.308486

#BaselineOnly algorithm gave us the best rmse, 
#use BaselineOnly and use Alternating Least Squares (ALS).

print('Using ALS')
bsl_options = {'method': 'als',
               'n_epochs': 5,
               'reg_u': 12,
               'reg_i': 5
               }
algo = BaselineOnly(bsl_options=bsl_options)
> cross_validate(algo, data, measures=['RMSE'], cv=3, verbose=False)

{'fit_time': (0.13807177543640137, 0.12630414962768555, 0.1693267822265625),
 'test_rmse': array([ 3.37381566,  3.36756676,  3.37800743]),
 'test_time': (0.2851989269256592, 0.322648286819458, 0.3984529972076416)}

#use the train_test_split() to sample a trainset 
#and a testset with given sizes, 
trainset, testset = train_test_split(data, test_size=0.25)
algo = BaselineOnly(bsl_options=bsl_options)
predictions = algo.fit(trainset).test(testset)
> accuracy.rmse(predictions)
3.3581150404412017
# dump.dump('./dump_file', predictions, algo)
# predictions, algo = dump.load('./dump_file')

trainset = algo.trainset
print(algo.__class__.__name__)

#To inspect our predictions in details, 
#build a pandas data frame with all the predictions.

def get_Iu(uid):
    """ return the number of items rated by given user
    args: 
      uid: the id of the user
    returns: 
      the number of items rated by the user
    """
    try:
        return len(trainset.ur[trainset.to_inner_uid(uid)])
    except ValueError: # user was not part of the trainset
        return 0
    
def get_Ui(iid):
    """ return number of users that have rated given item
    args:
      iid: the raw id of the item
    returns:
      the number of users that have rated the item.
    """
    try: 
        return len(trainset.ir[trainset.to_inner_iid(iid)])
    except ValueError:
        return 0
    
df = pd.DataFrame(predictions, columns=['uid', 'iid', 'rui', 'est', 'details'])
df['Iu'] = df.uid.apply(get_Iu)
df['Ui'] = df.iid.apply(get_Ui)
df['err'] = abs(df.est - df.rui)
> df.head()
	uid 	iid 	rui 	est 	details 	Iu 	Ui 	err
0 	229741 	0451167805 	7.0 	4.080891 	{'was_impossible': False} 	79 	36 	2.919109
1 	234765 	0399501487 	10.0 	4.113245 	{'was_impossible': False} 	26 	128 	5.886755
2 	16106 	0805063897 	0.0 	2.618840 	{'was_impossible': False} 	67 	112 	2.618840
3 	138529 	014028009X 	7.0 	3.166524 	{'was_impossible': False} 	8 	128 	3.833476
4 	213531 	0671867156 	8.0 	3.725626 	{'was_impossible': False} 	11 	79 	4.274374


best_predictions = df.sort_values(by='err')[:10]
worst_predictions = df.sort_values(by='err')[-10:]
> best_predictions
	uid 	iid 	rui 	est 	details 	Iu 	Ui 	err
13857 	269566 	0061098795 	0.0 	0.0 	{'was_impossible': False} 	276 	30 	0.0
14688 	102967 	051512317X 	0.0 	0.0 	{'was_impossible': False} 	384 	59 	0.0
14689 	238781 	0451203895 	0.0 	0.0 	{'was_impossible': False} 	178 	76 	0.0
26302 	63938 	0380817446 	0.0 	0.0 	{'was_impossible': False} 	71 	26 	0.0
14712 	244736 	0061098795 	0.0 	0.0 	{'was_impossible': False} 	77 	30 	0.0
14720 	278418 	0743460529 	0.0 	0.0 	{'was_impossible': False} 	174 	51 	0.0
2771 	170518 	080411868X 	0.0 	0.0 	{'was_impossible': False} 	155 	105 	0.0
14737 	238545 	0440241073 	0.0 	0.0 	{'was_impossible': False} 	41 	146 	0.0
26275 	238120 	0553297260 	0.0 	0.0 	{'was_impossible': False} 	314 	34 	0.0
26273 	36836 	0394742117 	0.0 	0.0 	{'was_impossible': False} 	158 	25 	0.0

> worst_predictions
	uid 	iid 	rui 	est 	details 	Iu 	Ui 	err
4430 	263460 	0061097101 	10.0 	0.317065 	{'was_impossible': False} 	61 	88 	9.682935
12250 	129358 	0515128546 	10.0 	0.314570 	{'was_impossible': False} 	97 	80 	9.685430
33088 	35857 	0380710722 	10.0 	0.285230 	{'was_impossible': False} 	191 	59 	9.714770
1934 	78834 	0399145990 	10.0 	0.279658 	{'was_impossible': False} 	154 	17 	9.720342
2419 	226006 	0425100650 	10.0 	0.260445 	{'was_impossible': False} 	14 	42 	9.739555
29657 	14521 	0553275976 	10.0 	0.169291 	{'was_impossible': False} 	156 	84 	9.830709
2794 	14521 	0553269631 	10.0 	0.070703 	{'was_impossible': False} 	156 	27 	9.929297
25532 	115490 	081297106X 	10.0 	0.028978 	{'was_impossible': False} 	159 	41 	9.971022
30944 	182442 	0679433740 	10.0 	0.000000 	{'was_impossible': False} 	36 	33 	10.000000
5395 	26544 	055358264X 	10.0 	0.000000 	{'was_impossible': False} 	191 	47 	10.000000

#The worst predictions look pretty surprise. 
#Let's look in more details of the last one ISBN "055358264X", 
#the book was rated by 47 users, user "26544" rated 10, 
#our BaselineOnly algorithm predicts 0.
> df_new.loc[df_new['ISBN'] == '055358264X']['bookRating'].describe()
count    60.000000
mean      1.283333
std       2.969287
min       0.000000
25%       0.000000
50%       0.000000
75%       0.000000
max      10.000000
Name: bookRating, dtype: float64

#It turns out, most of the ratings this book received was "0", 
#in another word, most of the users in the data rated this book "0", 
#only very few users rated "10". 
#Same with the other predictions in "worst predictions" list. 
#It seems that for each prediction, the users are some kind of outsiders.

import matplotlib.pyplot as plt
%matplotlib notebook

df_new.loc[df_new['ISBN'] == '055358264X']['bookRating'].hist()
plt.xlabel('rating')
plt.ylabel('Number of ratings')
plt.title('Number of ratings book ISBN 055358264X has received')
plt.show();


### Reference of Suprise 
class surprise.reader.Reader(name=None, 
        line_format=u'user item rating', sep=None, 
        rating_scale=(1, 5), skip_lines=0)
    The Reader class is used to parse a file containing ratings.
    Such a file is assumed to specify only one rating per line, 
    and each line needs to respect the following structure:
        user ; item ; rating ; [timestamp]
    timestamp field is optional.
    For each built-in dataset, Surprise also provides predefined readers 
        
class surprise.dataset.Dataset(reader)
    classmethod load_builtin(name=u'ml-100k')
        Load a built-in dataset.
    classmethod load_from_df(df, reader)
        Load a dataset from a pandas dataframe.
        The dataframe containing the ratings. 
        It must have three columns, corresponding to the 
        user (raw) ids, the item (raw) ids, and the ratings, in this order.
        Only the rating_scale in reader field needs to be specified.
    classmethod load_from_file(file_path, reader)
        Load a dataset from a (custom) file.
    classmethod load_from_folds(folds_files, reader)
        Load a dataset where folds (for cross-validation) are predefined by some files.
        The purpose of this method is to cover a common use case 
        where a dataset is already split into predefined folds, 
        such as the movielens-100k dataset which defines files 
        u1.base, u1.test, u2.base, u2.test, etc… 
        It can also be used when you don’t want to perform cross-validation 
        but still want to specify your training and testing data 
        (which comes down to 1-fold cross-validation anyway). 
        folds_files (iterable of tuples) – The list of the folds. 
        A fold is a tuple of the form (path_to_train_file, path_to_test_file).
        reader (Reader) – A reader to read the files.

##prediction_algorithms package
random_pred.NormalPredictor 	
    Algorithm predicting a random rating based on the distribution of the training set, which is assumed to be normal.
baseline_only.BaselineOnlyy(bsl_options={}, verbose=True) 	
    Algorithm predicting the baseline estimate for given user and item.
    Baselines can be estimated in two different ways:
        Using Stochastic Gradient Descent (SGD).
        Using Alternating Least Squares (ALS).
    key 'method' indicates the method to use. 
    Accepted values are 'als' (default) and 'sgd'. 
    For ALS:
        'reg_i': The regularization parameter for items
        Default is 10.
        'reg_u': The regularization parameter for users. 
        Default is 15.
        'n_epochs': The number of iteration of the ALS procedure. 
        Default is 10. 
    for SGD:
        'reg': The regularization parameter of the cost function 
        that is optimized
        Default is 0.02.
        'learning_rate': The learning rate of SGD, 
        Default is 0.005.
        'n_epochs': The number of iteration of the SGD procedure. 
        Default is 20.
    #Usage examples:
    print('Using ALS')
    bsl_options = {'method': 'als',
                   'n_epochs': 5,
                   'reg_u': 12,
                   'reg_i': 5
                   }
    algo = BaselineOnly(bsl_options=bsl_options)

    print('Using SGD')
    bsl_options = {'method': 'sgd',
                   'learning_rate': .00005,
                   }
    algo = BaselineOnly(bsl_options=bsl_options)

    #Note that some similarity measures may use baselines, 
    #such as the pearson_baseline similarity. 
    bsl_options = {'method': 'als',
                   'n_epochs': 20,
                   }
    sim_options = {'name': 'pearson_baseline'}
    algo = KNNBasic(bsl_options=bsl_options, sim_options=sim_options)
    
knns.KNNBasic(k=40, min_k=1, sim_options={}, verbose=True, **kwargs) 	
    A basic collaborative filtering algorithm.
knns.KNNWithMeans(k=40, min_k=1, sim_options={}, verbose=True, **kwargs) 	
    A basic collaborative filtering algorithm, taking into account the mean ratings of each user.
knns.KNNWithZScore(k=40, min_k=1, sim_options={}, verbose=True, **kwargs) 	
    A basic collaborative filtering algorithm, taking into account the z-score normalization of each user.
knns.KNNBaseline(k=40, min_k=1, sim_options={}, bsl_options={}, verbose=True, **kwargs) 	
    A basic collaborative filtering algorithm taking into account a baseline rating.
    sim_options for similarity measures
        'name': The name of the similarity to use, 
        as defined in the similarities module. Default is 'MSD'.
        'user_based': Whether similarities will be computed between users or between items. 
        This has a huge impact on the performance of a prediction algorithm. 
        Default is True.
        'min_support': The minimum number of common items 
        (when 'user_based' is 'True') 
        or minimum number of common users (when 'user_based' is 'False') 
        'shrinkage': Shrinkage parameter to apply 
        (only relevant for pearson_baseline similarity). 
        Default is 100.
    #Usage examples:
    sim_options = {'name': 'cosine',
                   'user_based': False  # compute  similarities between items
                   }
    algo = KNNBasic(sim_options=sim_options)
    sim_options = {'name': 'pearson_baseline',
                   'shrinkage': 0  # no shrinkage
                   }
    algo = KNNBasic(sim_options=sim_options)
    
matrix_factorization.SVD(n_factors=100, n_epochs=20, biased=True, init_mean=0,
                 init_std_dev=.1, lr_all=.005,
                 reg_all=.02, lr_bu=None, lr_bi=None, lr_pu=None, lr_qi=None,
                 reg_bu=None, reg_bi=None, reg_pu=None, reg_qi=None,
                 random_state=None, verbose=False )	
    The famous SVD algorithm, as popularized by Simon Funk during the Netflix Prize.
matrix_factorization.SVDpp(n_factors=20, n_epochs=20, init_mean=0, init_std_dev=.1,
                 lr_all=.007, reg_all=.02, lr_bu=None, lr_bi=None, lr_pu=None,
                 lr_qi=None, lr_yj=None, reg_bu=None, reg_bi=None, reg_pu=None,
                 reg_qi=None, reg_yj=None, random_state=None, verbose=False) 	
    The SVD++ algorithm, an extension of SVD taking into account implicit ratings.
matrix_factorization.NMF(n_factors=15, n_epochs=50, biased=False, reg_pu=.06,
                 reg_qi=.06, reg_bu=.02, reg_bi=.02, lr_bu=.005, lr_bi=.005,
                 init_low=0, init_high=1, random_state=None, verbose=False) 	
    A collaborative filtering algorithm based on Non-negative Matrix Factorization.
slope_one.SlopeOne()	
    A simple yet accurate collaborative filtering algorithm.
co_clustering.CoClustering(n_cltr_u=3, n_cltr_i=3, n_epochs=20, random_state=None,verbose=False)	
    A collaborative filtering algorithm based on co-clustering.

surprise.prediction_algorithms.algo_base.AlgoBase(**kwargs)
    The algorithm base class
    Keyword Arguments:
     	baseline_options (dict, optional) 
        This is part of all above Algo's init parameter
    compute_baselines()
        Compute users and items baselines.
        This method is only relevant for algorithms using Pearson baseline similarty 
        or the BaselineOnly algorithm.
        Returns:	
        A tuple (bu, bi), which are users and items baselines.
    compute_similarities()
        Build the similarity matrix.
        This method is only relevant for algorithms using a similarity measure, 
        such as the k-NN algorithms.
        Returns:	
        The similarity matrix.
    default_prediction()
        Used when the PredictionImpossible exception is raised 
        during a call to predict(). 
        By default, return the global mean of all ratings 
        (can be overridden in child classes).
        Returns:	The mean of all ratings in the trainset.
        Return type:	(float)
    fit(trainset)
        Train an algorithm on a given training set.
    get_neighbors(iid, k)
        Return the k nearest neighbors of iid, 
        which is the inner id of a user or an item, 
        depending on the user_based field of sim_options 
        this method is only relevant for algorithms using a similarity measure, 
        such as the k-NN algorithms.
        Returns:	
        The list of the k (inner) ids of the closest users (or items) to iid.
    predict(uid, iid, r_ui=None, clip=True, verbose=False)
        Compute the rating prediction for given user and item.
        The predict method converts raw ids to inner ids 
        and then calls the estimate method 
            uid – (Raw) id of the user. 
            iid – (Raw) id of the item. 
            r_ui (float) – The true rating rui
        Returns:	
        A Prediction object containing:
            The (raw) user id uid.
            The (raw) item id iid.
            The true rating r_ui 
            The estimated rating     
    test(testset, verbose=False)
        Test the algorithm on given testset
        Returns A list of Prediction objects 
        that contains all the estimated ratings.


##Cross validation
surprise.model_selection.split.KFold(n_splits=5, random_state=None, shuffle=True)
    A basic cross-validation iterator.
surprise.model_selection.split.RepeatedKFold(n_splits=5, n_repeats=10, random_state=None)
    Repeated KFold cross validator.
surprise.model_selection.split.ShuffleSplit(n_splits=5, test_size=0.2, train_size=None, random_state=None, shuffle=True)
    A basic cross-validation iterator with random trainsets and testsets.
surprise.model_selection.split.LeaveOneOut(n_splits=5, random_state=None, min_n_ratings=0)
    Cross-validation iterator where each user has exactly one rating in the testset.
surprise.model_selection.split.PredefinedKFold
    A cross-validation iterator to when a dataset has been loaded with the load_from_folds method.
surprise.model_selection.split.train_test_split(data, test_size=0.2, train_size=None, random_state=None, shuffle=True)
    Split a dataset into trainset and testset.

surprise.model_selection.validation.cross_validate(algo, data, measures=[u'rmse', u'mae'], cv=None, return_train_measures=False, n_jobs=1, pre_dispatch=u'2*n_jobs', verbose=False)
    Run a cross validation procedure for a given algorithm, reporting accuracy measures and computation times.
    Returns:	
    A dict with the following keys:
        'test_*' where * corresponds to a lower-case accuracy measure, e.g. 'test_rmse': numpy array with accuracy values for each testset.
        'train_*' where * corresponds to a lower-case accuracy measure, e.g. 'train_rmse': numpy array with accuracy values for each trainset. Only available if return_train_measures is True.
        'fit_time': numpy array with the training time in seconds for each split.
        'test_time': numpy array with the testing time in seconds for each split.

surprise.model_selection.search.RandomizedSearchCV(algo_class, param_distributions, n_iter=10, measures=[u'rmse', u'mae'], cv=None, refit=False, return_train_measures=False, n_jobs=1, pre_dispatch=u'2*n_jobs', random_state=None, joblib_verbose=0)
surprise.model_selection.search.GridSearchCV(algo_class, param_grid, measures=[u'rmse', u'mae'], cv=None, refit=False, return_train_measures=False, n_jobs=1, pre_dispatch=u'2*n_jobs', joblib_verbose=0)
    The GridSearchCV class computes accuracy metrics 
    for an algorithm on various combinations of parameters, 
    over a cross-validation procedure. 
    best_estimator
        dict of AlgoBase – Using an accuracy measure as key, get the algorithm 
        that gave the best accuracy results for the chosen measure, averaged over all splits.
    best_score
        dict of floats – Using an accuracy measure as key, 
        get the best average score achieved for that measure.
    best_params
        dict of dicts – Using an accuracy measure as key, 
        get the parameters combination that gave the best accuracy results for the chosen measure (on average).
    best_index
        dict of ints – Using an accuracy measure as key, 
        get the index that can be used with cv_results that achieved the highest accuracy for that measure (on average).
    cv_results
        dict of arrays – A dict that contains accuracy measures 
        over all splits, as well as train and test time 
        for each parameter combination. 
        Can be imported into a pandas DataFrame 
    fit(data)
        Runs the fit() method of the algorithm 
        for all parameter combinations, over different splits given 
        by the cv parameter.
        Parameters:	data (Dataset) – 
        The dataset on which to evaluate the algorithm, in parallel.
    predict(*args)
        Call predict() on the estimator with the best found parameters 
        (according the the refit parameter). 
        Only available if refit is not False.
    test(testset, verbose=False)
        Call test() on the estimator with the best found parameters 



##similarities module
surprise.similarities.cosine()
    Compute the cosine similarity between all pairs of users (or items).
surprise.similarities.msd()
    Compute the Mean Squared Difference similarity 
    between all pairs of users (or items).
surprise.similarities.pearson()
    Compute the Pearson correlation coefficient 
    between all pairs of users (or items).
surprise.similarities.pearson_baseline()
    Compute the (shrunk) Pearson correlation coefficient 
    between all pairs of users (or items) using baselines 
    for centering instead of means.

##accuracy module
rmse 	
    Compute RMSE (Root Mean Squared Error).
mae 	
    Compute MAE (Mean Absolute Error).
fcp 	Compute FCP 
    (Fraction of Concordant Pairs).

    
##Trainset   
surprise.Trainset(ur, ir, n_users, n_items, n_ratings, 
        rating_scale, offset, raw2inner_id_users, raw2inner_id_items)
    A trainset contains all useful data that constitutes a training set.
    Trainsets are different from Datasets. 
    You can think of a Datasets as the raw data, 
    and Trainsets as higher-level data where useful methods are defined. 
    ur
        defaultdict of list – The users ratings. 
        This is a dictionary containing lists of tuples of the form 
        (item_inner_id, rating). 
        The keys are user inner ids.
    ir
        defaultdict of list – The items ratings. 
        This is a dictionary containing lists of tuples of the form 
        (user_inner_id, rating). 
        The keys are item inner ids.
    n_users
        Total number of users
    n_items
        Total number of items
    n_ratings
        Total number of ratings
    rating_scale
        tuple – The minimum and maximal rating of the rating scale.
    global_mean
        The mean of all ratings 
    all_items()
        Generator function to iterate over all items.
        Yields:	Inner id of items.
    all_ratings()
        Generator function to iterate over all ratings.
        Yields:	A tuple (uid, iid, rating) where ids are inner ids 
    all_users()
        Generator function to iterate over all users.
        Yields:	Inner id of users.
    build_anti_testset(fill=None)
        Return a list of ratings that can be used as a testset in the test() method.
    build_testset()
        Return a list of ratings that can be used as a testset in the test() method.
    global_mean
        Return the mean of all ratings.
    knows_item(iid)
        Indicate if the item is part of the trainset.
    knows_user(uid)
        Indicate if the user is part of the trainset.
    to_inner_iid(riid)
        Convert an item raw id to an inner id.
    to_inner_uid(ruid)
        Convert a user raw id to an inner id.
    to_raw_iid(iiid)
        Convert an item inner id to a raw id.
    to_raw_uid(iuid)
        Convert a user inner id to a raw id.

##dump module
surprise.dump.dump(file_name, predictions=None, algo=None, verbose=0)
surprise.dump.load(file_name)
    Returns:	
    A tuple (predictions, algo) 
    where predictions is a list of Prediction objects 
    and algo is an Algorithm object. 

    
###Example of Surprise - Automatic cross-validation
from surprise import SVD
from surprise import Dataset
from surprise.model_selection import cross_validate


# Load the movielens-100k dataset (download it if needed),
data = Dataset.load_builtin('ml-100k')

# We'll use the famous SVD algorithm.
algo = SVD()

# Run 5-fold cross-validation and print results
cross_validate(algo, data, measures=['RMSE', 'MAE'], cv=5, verbose=True)

#Evaluating RMSE, MAE of algorithm SVD on 5 split(s).

            Fold 1  Fold 2  Fold 3  Fold 4  Fold 5  Mean    Std
RMSE        0.9311  0.9370  0.9320  0.9317  0.9391  0.9342  0.0032
MAE         0.7350  0.7375  0.7341  0.7342  0.7375  0.7357  0.0015
Fit time    6.53    7.11    7.23    7.15    3.99    6.40    1.23
Test time   0.26    0.26    0.25    0.15    0.13    0.21    0.06

###Example of Surprise - Train-test split and the fit() method

from surprise import SVD
from surprise import Dataset
from surprise import accuracy
from surprise.model_selection import train_test_split

# Load the movielens-100k dataset (download it if needed),
data = Dataset.load_builtin('ml-100k')

# sample random trainset and testset
# test set is made of 25% of the ratings.
trainset, testset = train_test_split(data, test_size=.25)

# We'll use the famous SVD algorithm.
algo = SVD()

# Train the algorithm on the trainset, and predict ratings for the testset
algo.fit(trainset)
predictions = algo.test(testset)

# Then compute RMSE
accuracy.rmse(predictions)
#Result:
RMSE: 0.9411

###Example of Surprise - Train on a whole trainset and the predict() method
from surprise import KNNBasic
from surprise import Dataset

# Load the movielens-100k dataset
data = Dataset.load_builtin('ml-100k')

# Retrieve the trainset.
trainset = data.build_full_trainset()

# Build an algorithm, and train it.
algo = KNNBasic()
algo.fit(trainset)

uid = str(196)  # raw user id (as in the ratings file). They are **strings**!
iid = str(302)  # raw item id (as in the ratings file). They are **strings**!

# get a prediction for specific users and items.
#The predict() uses raw ids
pred = algo.predict(uid, iid, r_ui=4, verbose=True)

#The result should be:
user: 196        item: 302        r_ui = 4.00   est = 4.06   {'actual_k': 40, 'was_impossible': False}

###Example of Surprise - Use a custom dataset
#Loading a rating dataset can be done either from a file 
#(e.g. a csv file), or from a pandas dataframe. 

from surprise import BaselineOnly
from surprise import Dataset
from surprise import Reader
from surprise.model_selection import cross_validate
import os.path 

# path to dataset file
file_path = os.path.expanduser('~/.surprise_data/ml-100k/ml-100k/u.data')

# As we're loading a custom dataset, we need to define a reader. In the
# movielens-100k dataset, each line has the following format:
# 'user item rating timestamp', separated by '\t' characters.
reader = Reader(line_format='user item rating timestamp', sep='\t')

data = Dataset.load_from_file(file_path, reader=reader)

# We can now use this dataset as we please, e.g. calling cross_validate
cross_validate(BaselineOnly(), data, verbose=True)

#To load a dataset from a pandas dataframe
import pandas as pd

from surprise import NormalPredictor
from surprise import Dataset
from surprise import Reader
from surprise.model_selection import cross_validate


# Creation of the dataframe. Column names are irrelevant.
ratings_dict = {'itemID': [1, 1, 1, 2, 2],
                'userID': [9, 32, 2, 45, 'user_foo'],
                'rating': [3, 2, 4, 3, 1]}
df = pd.DataFrame(ratings_dict)

# A reader is still needed but only the rating_scale param is requiered.
reader = Reader(rating_scale=(1, 5))

# The columns must correspond to user id, item id and ratings (in that order).
data = Dataset.load_from_df(df[['userID', 'itemID', 'rating']], reader)

# We can now use this dataset as we please, e.g. calling cross_validate
cross_validate(NormalPredictor(), data, cv=2)



###Example of Surprise - Use cross-validation iterators

from surprise import SVD
from surprise import Dataset
from surprise import accuracy
from surprise.model_selection import KFold

# Load the movielens-100k dataset
data = Dataset.load_builtin('ml-100k')

# define a cross-validation iterator
kf = KFold(n_splits=3)

algo = SVD()

for trainset, testset in kf.split(data):

    # train and test algorithm.
    algo.fit(trainset)
    predictions = algo.test(testset)

    # Compute and print Root Mean Squared Error
    accuracy.rmse(predictions, verbose=True)



#A special case of cross-validation is when the folds 
#are already predefined by some files. 
#For instance, the movielens-100K dataset already provides 5 train and test files 
#(u1.base, u1.test … u5.base, u5.test).

from surprise import SVD
from surprise import Dataset
from surprise import Reader
from surprise import accuracy
from surprise.model_selection import PredefinedKFold

# path to dataset folder
files_dir = os.path.expanduser('~/.surprise_data/ml-100k/ml-100k/')

# This time, we'll use the built-in reader.
reader = Reader('ml-100k')

# folds_files is a list of tuples containing file paths:
# [(u1.base, u1.test), (u2.base, u2.test), ... (u5.base, u5.test)]
train_file = files_dir + 'u%d.base'
test_file = files_dir + 'u%d.test'
folds_files = [(train_file % i, test_file % i) for i in (1, 2, 3, 4, 5)]

data = Dataset.load_from_folds(folds_files, reader=reader)
pkf = PredefinedKFold()

algo = SVD()

for trainset, testset in pkf.split(data):

    # train and test algorithm.
    algo.fit(trainset)
    predictions = algo.test(testset)

    # Compute and print Root Mean Squared Error
    accuracy.rmse(predictions, verbose=True)

    
###Example of Surprise - Tune algorithm parameters with GridSearchCV

from surprise import SVD
from surprise import Dataset
from surprise.model_selection import GridSearchCV

# Use movielens-100K
data = Dataset.load_builtin('ml-100k')

param_grid = {'n_epochs': [5, 10], 'lr_all': [0.002, 0.005],
              'reg_all': [0.4, 0.6]}
gs = GridSearchCV(SVD, param_grid, measures=['rmse', 'mae'], cv=3)

gs.fit(data)

# best RMSE score
print(gs.best_score['rmse'])

# combination of parameters that gave the best RMSE score
print(gs.best_params['rmse'])
#Result:
#0.961300130118
#{'n_epochs': 10, 'lr_all': 0.005, 'reg_all': 0.4}


# We can now use the algorithm that yields the best rmse:
algo = gs.best_estimator['rmse']
algo.fit(data.build_full_trainset())

#Dictionary parameters such as bsl_options and sim_options 
#require particular treatment

param_grid = {'k': [10, 20],
              'sim_options': {'name': ['msd', 'cosine'],
                              'min_support': [1, 5],
                              'user_based': [False]}
              }

#OR 
param_grid = {'bsl_options': {'method': ['als', 'sgd'],
                              'reg': [1, 2]},
              'k': [2, 3],
              'sim_options': {'name': ['msd', 'cosine'],
                              'min_support': [1, 5],
                              'user_based': [False]}
              }

#For further analysis, the cv_results attribute 
#has all the needed information and can be imported in a pandas dataframe:

results_df = pd.DataFrame.from_dict(gs.cv_results)
#output 
'split0_test_rmse': [1.0, 1.0, 0.97, 0.98, 0.98, 0.99, 0.96, 0.97]
'split1_test_rmse': [1.0, 1.0, 0.97, 0.98, 0.98, 0.99, 0.96, 0.97]
'split2_test_rmse': [1.0, 1.0, 0.97, 0.98, 0.98, 0.99, 0.96, 0.97]
'mean_test_rmse':   [1.0, 1.0, 0.97, 0.98, 0.98, 0.99, 0.96, 0.97]
'std_test_rmse':    [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
'rank_test_rmse':   [7 8 3 5 4 6 1 2]
'split0_test_mae':  [0.81, 0.82, 0.78, 0.79, 0.79, 0.8, 0.77, 0.79]
'split1_test_mae':  [0.8, 0.81, 0.78, 0.79, 0.78, 0.79, 0.77, 0.78]
'split2_test_mae':  [0.81, 0.81, 0.78, 0.79, 0.78, 0.8, 0.77, 0.78]
'mean_test_mae':    [0.81, 0.81, 0.78, 0.79, 0.79, 0.8, 0.77, 0.78]
'std_test_mae':     [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
'rank_test_mae':    [7 8 2 5 4 6 1 3]
'mean_fit_time':    [1.53, 1.52, 1.53, 1.53, 3.04, 3.05, 3.06, 3.02]
'std_fit_time':     [0.03, 0.04, 0.0, 0.01, 0.04, 0.01, 0.06, 0.01]
'mean_test_time':   [0.46, 0.45, 0.44, 0.44, 0.47, 0.49, 0.46, 0.34]
'std_test_time':    [0.0, 0.01, 0.01, 0.0, 0.03, 0.06, 0.01, 0.08]
'params':           [{'n_epochs': 5, 'lr_all': 0.002, 'reg_all': 0.4}, {'n_epochs': 5, 'lr_all': 0.002, 'reg_all': 0.6}, {'n_epochs': 5, 'lr_all': 0.005, 'reg_all': 0.4}, {'n_epochs': 5, 'lr_all': 0.005, 'reg_all': 0.6}, {'n_epochs': 10, 'lr_all': 0.002, 'reg_all': 0.4}, {'n_epochs': 10, 'lr_all': 0.002, 'reg_all': 0.6}, {'n_epochs': 10, 'lr_all': 0.005, 'reg_all': 0.4}, {'n_epochs': 10, 'lr_all': 0.005, 'reg_all': 0.6}]
'param_n_epochs':   [5, 5, 5, 5, 10, 10, 10, 10]
'param_lr_all':     [0.0, 0.0, 0.01, 0.01, 0.0, 0.0, 0.01, 0.01]
'param_reg_all':    [0.4, 0.6, 0.4, 0.6, 0.4, 0.6, 0.4, 0.6]


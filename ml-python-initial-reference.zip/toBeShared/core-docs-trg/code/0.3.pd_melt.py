import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data)
#output 
#      weekday  Person 1  Person 2  Person 3
# 0     Monday        12        10         8
# 1    Tuesday         6         6         5
# 2  Wednesday         5        11         7

melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")

print("Given DF=", df,
"""
Q1: How can you do group by on person 
this is not normalized table 
Do Melt data -long form - creating a generic form internally, 
which you can cast to specific shape

#each row is converted into id_vars versus other columns 
#into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
""",
melt, 
sep="\n")
#output 
#      weekday    Person  Score
# 0     Monday  Person 1     12
# 1    Tuesday  Person 1      6
# 2  Wednesday  Person 1      5

pm = melt.pivot(index='weekday', columns='Person', values='Score')

print("", """
Q1: How can you undo melt?
pivot == unmelt 

pivot(index=None, columns=None, values=None)
    'columns' columns name would be new DF's column labels 
    'values'= columnName  to use for populating new frame's cell values 
    'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
""",
pm.reset_index(),
sep="\n")

#output 
# Person    Person 1  Person 2  Person 3
# weekday
# Friday          11         8         7
# Monday          12        10         8
# #reset_index()
pm2 = pm.reset_index()

table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

print("", """
Q1: How can you do excel style pivot table 

pivot_table(melt, values=None, index=None, columns=None, aggfunc='mean', margins=False)
    values=ColumnNames for aggfun , 
    index=ColumnsNames for row-groupby , 
    columns=ColumnNames on column-groupby , 
    aggfunc=not string, but functions 
    margins = Add all row / columns (e.g. for subtotal / grand totals)

table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 
""",
table,
sep="\n")
    
    
    
#or to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])
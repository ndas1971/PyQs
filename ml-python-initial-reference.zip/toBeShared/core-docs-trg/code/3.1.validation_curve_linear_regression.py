



import numpy as np

print("""
Most models have multiple hyperparameters and the best way 
to choose a combination of those parameters is with a grid search. 
However, it is sometimes useful to plot the influence 
of a single hyperparameter on the training and test data to determine 
if the estimator is underfitting or overfitting for some hyperparameter values.
""")

print("""
  
This validation curve explores the relationship of the "alpha" parameter 
to the R2 score with 10 shuffle split cross-validation. 

Shaded region shows variability  of the score under cross validation 

 The curves are plotted with the mean scores,
however variability during cross-validation is shown with the shaded areas
that represent a standard deviation above and below the mean for all cross-validations.

If the model suffers from error due to bias,
then there will likely be more variability around the training score curve.
that means it is underfitting

If the model suffers from error due to variance,
then there will be more variability around the cross validated score.
and that means it is overfitting
 """)

from sklearn.linear_model import Ridge
from yellowbrick.model_selection import ValidationCurve
import pandas as pd

# Load a regression dataset
data = pd.read_csv("data/energy.csv")

# Specify features of interest and the target
targets = ["heating load", "cooling load"]
features = [col for col in data.columns if col not in targets]

# Extract the instances and target
X = data[features]
y = data[targets[0]]

viz = ValidationCurve(
    Ridge(), param_name="alpha",
    param_range=[.0001, 0.01,.1, .5, 1,5,10], cv=10, scoring="r2"
)

# Fit and poof the visualizer
viz.fit(X, y)
viz.poof()
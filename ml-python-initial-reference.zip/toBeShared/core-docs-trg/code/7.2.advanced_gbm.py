import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)
warnings.simplefilter(action='ignore', category=DeprecationWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

PAUSE='N'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *
import time 

print("----------------- GBM vs CatBoost vs. Light GBM vs. XGBoost on flights.csv ----------------")


print("""

flights.csv 
MONTH, DAY, DAY_OF_WEEK: data type int
AIRLINE and FLIGHT_NUMBER: data type int
ORIGIN_AIRPORT and DESTINATION_AIRPORT: data type string
DEPARTURE_TIME: data type float
ARRIVAL_DELAY: this will be the target and is transformed into boolean variable 
indicating delay of more than 10 minutes
DISTANCE and AIR_TIME: data type float
""")

data = pd.read_csv("data/flights.csv")

data = data[["MONTH","DAY","DAY_OF_WEEK","AIRLINE","FLIGHT_NUMBER","DESTINATION_AIRPORT",
                 "ORIGIN_AIRPORT","AIR_TIME", "DEPARTURE_TIME","DISTANCE","ARRIVAL_DELAY"]]
data.dropna(inplace=True)

data["ARRIVAL_DELAY"] = (data["ARRIVAL_DELAY"]>10)*1

cols = ["AIRLINE","FLIGHT_NUMBER","DESTINATION_AIRPORT","ORIGIN_AIRPORT"]
#convert to numeric categorical , 0- size_of_cat
for item in cols:
    data[item] = data[item].astype("category").cat.codes +1

#axis=0, row, axis=1, column 
X = data.drop(["ARRIVAL_DELAY"], axis=1)
y = data["ARRIVAL_DELAY"]
train, test, y_train, y_test = train_test_split(data.drop(["ARRIVAL_DELAY"], axis=1),
    data["ARRIVAL_DELAY"],random_state=10, test_size=0.25)
    
CV= StratifiedKFold(n_splits=5,shuffle=True)

##sklearn RF and GBM 
clf =  GradientBoostingClassifier()
params = dict(max_features = np.arange(0.3,1.0,0.1), 
    n_estimators= np.arange(10,200,10), 
    learning_rate= np.arange(0.01, 0.5, 0.02) , 
    subsample=np.arange(0.1,1.0,0.2))
    
search = RandomizedSearchCV(clf, params,scoring='roc_auc', cv=CV)
st = time.time()
search.fit(train, y_train)
print("\n\nBest param for GradientBoostingClassifier", search.best_params_ )#{'n_estimators': 80}
print("AUC= train:%f test:%f and time=%d sec" % (search.score(train, y_train),
        search.score(test, y_test), (time.time()-st)))
#best = search.best_estimator_
#st = time.time()
#scores = cross_val_score(best, X, y, cv=CV, scoring='roc_auc') 
#print("AUC: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))

                                                
clf = RandomForestClassifier()
params = dict(max_features = np.arange(0.3,1.0,0.1), 
    n_estimators= np.arange(10,200,10), 
    min_samples_leaf= np.arange(2,10,1) , 
    max_depth=np.arange(1,10,1), 
    min_samples_split=np.arange(2,10,1))
search = RandomizedSearchCV(clf, params, scoring='roc_auc', cv=CV)
st = time.time()
search.fit(train, y_train)
print("\n\nBest param for RandomForestClassifier", search.best_params_ )#{'n_estimators': 80}
print("AUC= train:%f test:%f and time=%d sec" % (search.score(train, y_train),
        search.score(test, y_test), (time.time()-st)))
#best = search.best_estimator_
#st = time.time()
#scores = cross_val_score(best, X, y, cv=CV,  scoring='roc_auc') 
#print("AUC: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
                                           
                                    
print("----------------XGBoost----------------")
import xgboost as xgb
from sklearn import metrics

#Return ROC/AUC 
#roc_auc_score(y_true, y_score)
#predict_proba return [n_samples, n_classes]
#where classes are ordered as they are in self.classes_.
#take only for delayed one [:,1]
def auc(m, train, test): 
    return (metrics.roc_auc_score(y_train,m.predict_proba(train)[:,1]),
                            metrics.roc_auc_score(y_test,m.predict_proba(test)[:,1]))

# Parameter Tuning
model = xgb.XGBClassifier()
param_dist = {"max_depth": [10,30,50],
              "min_child_weight" : [1,3,6],
              "n_estimators": [200],
              "learning_rate": [0.05, 0.1,0.16],}
grid_search = RandomizedSearchCV(model, param_dist, scoring='roc_auc', cv = CV,n_jobs=-1)
st = time.time()
grid_search.fit(train, y_train)

print("Best model for XGBClassifier(",round(time.time()-st, 1)," secs)\n", grid_search.best_estimator_)

           
model = xgb.XGBClassifier(n_jobs=-1 ,**grid_search.best_params_)
st = time.time()
model.fit(train,y_train)
print("AUC(train,test) in ",round(time.time()-st,1)," secs ",auc(model, train, test))

pause_d()

print("----------------Light GBM----------------")
import lightgbm as lgb
from sklearn import metrics

def auc2(m, train, test): 
    return (metrics.roc_auc_score(y_train,m.predict(train)),
                            metrics.roc_auc_score(y_test,m.predict(test)))

lg = lgb.LGBMClassifier(silent=True, verbose=-1)
param_dist = {"max_depth": [25,50, 75],
              "learning_rate" : [0.01,0.05,0.1],
              "num_leaves": [300,900,1200],
              "n_estimators": [200]
             }
st = time.time()
grid_search = RandomizedSearchCV(lg,  param_dist, cv = CV, scoring="roc_auc", n_jobs=-1)#, verbose=5)
grid_search.fit(train,y_train)
print("Best model for LGBMClassifier(",round(time.time()-st,1)," secs)\n",  grid_search.best_estimator_)
pause_d()

d_train = lgb.Dataset(train, label=y_train)
#params = {"max_depth": 50, "learning_rate" : 0.1, "num_leaves": 900,  "n_estimators": 300}
params = grid_search.best_params_ 

#for suppressing 
#[LightGBM] [Warning] No further splits with positive gain, best gain: -inf
#It means 
#The num_leaves is too large, you can set it to a smaller value
#the min_data is too large
#your data is hard to fit
params['verbose'] = -1

print("Without Categorical Features")
st = time.time()
model2 = lgb.train(params, d_train, verbose_eval=False)
print("AUC(train,test) in ",round(time.time()-st,1)," secs ", auc2(model2, train, test)) #(0.9999080488022881, 0.7296877889286735)
pause_d()

print("With  Catgeorical Features marked as categorical ")
d_train = lgb.Dataset(train, label=y_train)
cate_features_name = ["MONTH","DAY","DAY_OF_WEEK","AIRLINE","DESTINATION_AIRPORT",
                 "ORIGIN_AIRPORT"]
st = time.time()
model2 = lgb.train(params, d_train, categorical_feature = cate_features_name, verbose_eval=False)
print("AUC(train,test) in ",round(time.time()-st,1)," secs ", auc2(model2, train, test))#(0.999387513407222, 0.7550473212634693)
pause_d()

"""
print("----------------Cat Boost----------------")
#pip install catboost
#While tuning parameters for CatBoost, 
#it is difficult to pass indices for categorical features. 
#without passing categorical features and evaluated two model
#one with and other without categorical features. 
#I have separately tuned one_hot_max_size because it does not impact the other parameters.

import catboost as cb

params = {'depth': [4, 7, 10],
          'learning_rate' : [0.03, 0.1, 0.15],
         'l2_leaf_reg': [1,4,9],
         'iterations': [300]}
model = cb.CatBoostClassifier(logging_level='Silent')
st = time.time()
cb_model = RandomizedSearchCV(model, params, scoring="roc_auc", cv = CV, n_jobs=-1)
cb_model.fit(train, y_train) #(0.9232417545584556, 0.7494421049977306)
print("Best model for CatBoostClassifier(",round(time.time()-st,1)," secs)\n",  cb_model.best_estimator_)


# >>> data.columns
# Index(['MONTH', 'DAY', 'DAY_OF_WEEK', 'AIRLINE', 'FLIGHT_NUMBER',
# 'DESTINATION_AIRPORT', 'ORIGIN_AIRPORT', 'AIR_TIME', 'DEPARTURE_TIME',
# 'DISTANCE', 'ARRIVAL_DELAY'],
# dtype='object')
    
import catboost as cb
cat_features_index = [0,1,2,3,4,5,6]

def auc3(m, train, test): 
    return (roc_auc_score(y_train,m.predict_proba(train)[:,1]),
                            roc_auc_score(y_test,m.predict_proba(test)[:,1]))


pause_d()


print("Without Categorical features")
clf = cb.CatBoostClassifier(logging_level='Silent', eval_metric="AUC", depth=10, iterations= 300, l2_leaf_reg= 9, learning_rate= 0.15)
st = time.time()
clf.fit(train,y_train)
print("AUC(train,test) in ",round(time.time()-st,1)," secs ",  auc3(clf, train, test))
pause_d()

print("With Categorical features")
clf = cb.CatBoostClassifier(logging_level='Silent', eval_metric="AUC",one_hot_max_size=31, 
                            depth=10, iterations= 300, l2_leaf_reg= 9, learning_rate= 0.15)
st = time.time()
clf.fit(train,y_train, cat_features= cat_features_index)
print("AUC(train,test) in ",round(time.time()-st,1)," secs ", auc3(clf, train, test))
"""


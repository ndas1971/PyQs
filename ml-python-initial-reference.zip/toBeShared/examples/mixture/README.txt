.. _mixture_examples:

Gaussian Mixture Models
-----------------------

Examples concerning the :mod:`sklearn.mixture` module.

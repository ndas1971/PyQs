###NP 
a = np.array([[1,2, 3, 4], 
              [5,6, 7, 8], 
              [9,10,11,12]])

a = np.array([[1,2], [3, 4], [5, 6]])



##Polyfit 
x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])
##HandsON - Create equal spaced 100 points between -2 and 6 and 
#then plot above p and p30 graphs for those x points 



def get_test_data(delta=0.05):
    from matplotlib.mlab import  bivariate_normal
    x = y = np.arange(-3.0, 3.0, delta)
    X, Y = np.meshgrid(x, y)
    Z1 = bivariate_normal(X, Y, 1.0, 1.0, 0.0, 0.0)
    Z2 = bivariate_normal(X, Y, 1.5, 0.5, 1, 1)
    Z = Z2 - Z1
    X = X * 10
    Y = Y * 10
    Z = Z * 500
    return X, Y, Z




##Pandas 
df = pd.DataFrame(np.random.randn(6,4),index=list('abcdef'),columns=list('ABCD'))


##Multindex accessing 
d = {'num_legs': [4, 4, 2, 2],
     'num_wings': [0, 0, 2, 2],
     'class': ['mammal', 'mammal', 'mammal', 'bird'],
     'animal': ['cat', 'dog', 'bat', 'penguin'],
     'locomotion': ['walks', 'walks', 'flies', 'walks']} 
     
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],index=pd.date_range('20130101',periods=100000,freq='T')) 
ts = pd.Series(np.random.randn(100000), index=pd.date_range('20130101',periods=100000,freq='T'))
df = pd.DataFrame({'A': ['cat', 'dog', 'bat']})
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],
    index=pd.date_range('20130101',periods=100000,freq='T'))    
df = pd.DataFrame({'A': pd.Series(["a","b","c","a"], dtype="category"),
                'B': ['cat','cat','bat','bat']})   
df1 = pd.DataFrame({'A': ['1', '2'], 'B':['20181231', '20180304'],
                     'C': [10000, 10000]})

df5 = pd.DataFrame({'A':[0, np.nan, 0, np.nan], 'B':[np.nan, 0, np.nan, 0]})
   
##Concatenate-DF 
df1 = pd.DataFrame({'A': ['A0', 'A1', 'A2', 'A3'],  #keys are columns                    
    'B': ['B0', 'B1', 'B2', 'B3'],                    
    'C': ['C0', 'C1', 'C2', 'C3'],                    
    'D': ['D0', 'D1', 'D2', 'D3']},                    
    index=[0, 1, 2, 3])
df2 = pd.DataFrame({'A': ['A4', 'A5', 'A6', 'A7'],                   
    'B': ['B4', 'B5', 'B6', 'B7'],                   
    'C': ['C4', 'C5', 'C6', 'C7'],                    
    'D': ['D4', 'D5', 'D6', 'D7']},                    
    index=[4, 5, 6, 7])
df3 = pd.DataFrame({'A': ['A8', 'A9', 'A10', 'A11'],                    
    'B': ['B8', 'B9', 'B10', 'B11'],                     
    'C': ['C8', 'C9', 'C10', 'C11'],                        
    'D': ['D8', 'D9', 'D10', 'D11']},                    
    index=[8, 9, 10, 11])




##merge 
>>> A              >>> B
    lkey value        rkey value
0   foo  1            foo  5
1   bar  2            bar  6
2   baz  3            qux  7
3   foo  4            bar  8


left = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
right = pd.DataFrame({'key1': ['K0', 'K1', 'K1', 'K2'],                      
        'key2': ['K0', 'K0', 'K0', 'K0'],                        
        'C': ['C0', 'C1', 'C2', 'C3'],                         
        'D': ['D0', 'D1', 'D2', 'D3']}) 

##Replace 
df = pd.DataFrame({'A': [0, 1, 2, 3, 4],
                   'B': [5, 6, 7, 8, 9],
                    'C': ['a', 'b', 'c', 'd', 'e']})        
        
df = pd.DataFrame({'A': ['bat', 'foo', 'bait'],
            'B': ['abc', 'bar', 'xyz']})
            
            
            
#dropna 
df = pd.DataFrame([[np.nan, 2, np.nan, 0], [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5]],
                    columns=list('ABCD'))


#fillna 
df = pd.DataFrame([[np.nan, 2, np.nan, 0],
                        [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5],
                        [np.nan, 3, np.nan, 4]],
                        columns=list('ABCD'))


#map 
x = pd.Series([1,2,3], index=['one', 'two', 'three'])
y = pd.Series(['foo', 'bar', 'baz'], index=[1,2,3])


df = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})


#trnsform 
df = pd.DataFrame(np.random.randn(10, 3), columns=['A', 'B', 'C'],
            index=pd.date_range('1/1/2000', periods=10))
        
        
        
#assign 
df = pd.DataFrame({'A': range(1, 11), 'B': np.random.randn(10)})        
        
#apply 
df = pd.DataFrame([[4, 9],] * 3, columns=['A', 'B'])       
        
#applymap 
df = pd.DataFrame([[1, 2.12], [3.356, 4.567]])    
        
#agg 
>>> df = pd.DataFrame({'Animal' : ['Falcon', 'Falcon','Parrot', 'Parrot'],
                       'Type' : ['fast', 'fast', 'slow', 'slow'],
                    'Max Speed' : [380., 370., 24., 26.]})
df = pd.DataFrame([['a','a','b','b','c','d', 'c'],
        [1, 3, 5, 7, 9, 2, 4]], index=["alpha", "val"])
df = pd.DataFrame({'A': [1, 1, 2, 2],
                    'B': [1, 2, 3, 4],
                    'C': np.random.randn(4)})       
        
#grp.apply 
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})      
        
#grp.transform 
   A      B         C         D
0  foo    one  0.162003  0.087469
1  bar    one -1.156319 -1.526272
2  foo    two  0.833892 -1.666304
3  bar  three -2.026673 -0.322057
4  foo    two  0.411452 -0.954371
5  bar    two  0.765878 -0.095968
6  foo    one -0.654890  0.678091
7  foo  three -1.789842 -1.130922
        
#pipe 
df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})     
    
df = pd.DataFrame(dict(
    A=list('XXXXYYYYYY'),
    B=range(10)
))    
        
#filter 
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})      
        
       
#pipe 
df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})

       
#Melt 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}       
df = pd.DataFrame(data)     
       
#stack/unstack 
tuples = list(zip(*[['bar', 'bar', 'baz', 'baz',
                    'foo', 'foo', 'qux', 'qux'],
                   ['one', 'two', 'one', 'two',
                    'one', 'two', 'one', 'two']]))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 2), index=index, columns=['A', 'B'])
  
       
columns = pd.MultiIndex.from_tuples([('A', 'cat'), ('B', 'dog'),
                                     ('B', 'cat'), ('A', 'dog')],
                                    names=['exp', 'animal'])
index = pd.MultiIndex.from_product([('bar', 'baz', 'foo', 'qux'),
                                    ('one', 'two')],
                                   names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 4), index=index, columns=columns)       
       
#Cross Tab 
df = pd.DataFrame({'A': [1, 2, 2, 2, 2], 'B': [3, 3, 4, 4, 4],
                   'C': [1, 1, np.nan, 1, 1]})
                   
foo = pd.Categorical(['a', 'b'], categories=['a', 'b', 'c'])
bar = pd.Categorical(['d', 'e'], categories=['d', 'e', 'f'])                 
      


#Take 
frm = pd.DataFrame(np.random.randn(5, 3))

#category index 
from pandas.api.types import CategoricalDtype

df = pd.DataFrame({'A': np.arange(6),'B': list('aabbca')})


#Other plot 
df = pd.DataFrame(np.random.randn(1000, 4), columns=['a', 'b', 'c', 'd'])
df = pd.DataFrame(np.random.rand(10, 4), columns=['a', 'b', 'c', 'd'])
df = pd.DataFrame(np.random.randn(1000, 2), columns=['a', 'b'])
      
#excel 
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parseDates=True, index_col=0, header=0, 
    date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))






###*** Pandas Hands on 

1.Read data/ver.csv

#columns 
#index,year,day of the year,time,atmospheric pressure (mBar),rainfall (mm),wind speed (m/s),wind direction (degrees),surface temperature (C),relative humidity (%),wind_max (m/s),Tdew (C),wind_chill (C),uncalibrated solar flux (Kw/m2), calibrated solar flux (Kw/m2),battery (V),not used

2.Check/do below 
    index 
    Display head 
    Shape 
    columns 
    datatypes 
    Get the first five rows of  column 'atmospheric pressure (mBar)'
    Create 14 bins  of  column 'atmospheric pressure (mBar)'
    Get value frequencies  of  column 'atmospheric pressure (mBar)' in the ranges created above
    Get first six columns of the first row
    Sort column 'atmospheric pressure (mBar)' and display first five rows 
    Sort by 'atmospheric pressure (mBar)', 'day of the year' 
    
    Obtain a cross-section(all rows, only first 6 columns) of that data
    Obtain the first three rows and first three columns of the sorted data
    Obtain value counts of column 'atmospheric pressure (mBar)'
    Get the unique values for a column 'year'
    Get a count of the unique values of column 'year'
    Get first four rows of column 'atmospheric pressure (mBar)'

    Get rows where 'atmospheric pressure (mBar) = 1025
    Get rows where 'atmospheric pressure (mBar)' > 1010 and 'atmospheric pressure (mBar)' < 1016) 
    
    Query the data where year = 2015
    
    Replace following in all columns 
        Space by _ 
        '(' by ''
        ')' by '' 
    Then Query the data where atmospheric_pressure_mBar = 1016
    Check whether any row is having 'atmospheric_pressure_mBar' > 1016 

    Do sum , min aggregation in each column 
    Do sum , min aggregation of atmospheric_pressure_mBar and min, max of rainfall_mm
    Do mean aggregation of each row 

    group by 'atmospheric_pressure_mBar', and then 'rainfall_mm 
        find mean of all other columns
        find sum, count of all other columns 
    
    Add new column 
        atmospheric_pressure_mBar_str which is string conversion of atmospheric_pressure_mBar
        How many of above column ends with '5'
    
    Apply np.sum to each column 
    Convert each element to string 
    Transform column 3 and 4 with zscore =(element - mean)/std
        
    Drop duplicates of 'atmospheric pressure (mBar)'
    
    excel styple pivot table (pd.pivot_table)
    values=ColumnNames for aggfun ,  'atmospheric pressure (mBar)','rainfall (mm)'
    index=ColumnsNames for row-groupby , 'year', 'day of the year'
    columns=ColumnNames on column-groupby ,  'battery (V)'
    aggfunc=not string, but functions , np.sum, np.max, lambda x:x.size

    plot horizontal bar graph of values of 'atmospheric_pressure_mBar'
    plot median values (bar) of surface_temperature_C column after group by with 'atmospheric_pressure_mBar'

##Hypothesis Testing 

Suppose that we have two variables, 
sex (male or female) and handedness (right or left handed). 
Further suppose that 100 individuals are randomly sampled 
from a very large population as part of a study of sex differences in handedness
        Handedness
Gender  Right handed    Left handed     Total
Male        43          9               52
Female      44          4               48 
Total       87          13              100 
Are left/right handed dependents on gender?


Problem - A soft drink company has invented a new drink, 
and would like to find out if it will be as popular as the existing favorite drink. 
For this purpose, its research department arranges 18 participants for taste testing. 
Each participant tries both drinks in random order before giving his or her opinion. 

It turns out that 5 of the participants like the new drink better, and the rest prefer the old one. 
At .05 significance level, can we reject the notion that the two drinks are equally popular? 



Example 
A biologist runs an experiment in which there are three groups of plants. 
Group 1 has 16 plants, group 2 has 15 plants, and group 3 has 17 plants. 
Each plant produces a number of seeds. 
The seed counts for each group are:
Group 1: 10 14 14 18 20 22 24 25 31 31 32 39 43 43 48 49
Group 2: 28 30 31 33 34 35 36 40 44 55 57 61 91 92 99
Group 3:  0  3  9 22 23 25 25 33 34 34 40 45 46 48 62 67 84
Are they similar in terms of seed productions?


###scikit-pandas 
data = pd.DataFrame({'pet':      ['cat', 'dog', 'dog', 'fish', 'cat', 'dog', 'cat', 'fish'],
                      'pet2':      ['cat', 'dog', 'dog', 'fish', 'cat', 'dog', 'cat', 'fish'],
                      'children': [4., 6, 3, 3, 2, 3, 5, 4],
                      'salary':   [90, 24, 44, 27, 32, 59, 36, 27]})
                      
data_3 = pd.DataFrame({'age': [1, np.nan, 3]})

data5 = pd.DataFrame({
        'col1': ['yes', 'no', 'yes'],
        'col2': [True, False, False],
        'col3': ['one', 'two', 'three']
    })

data6 = pd.DataFrame({
        'col1': [None, 1, 1, 2, 3],
        'col2': [True, False, None, None, True],
        'col3': [0, 0, 0, None, None]
    })                    

    
    
corpus = [
 'This is the first document.',
 'This is the second second document.',
 'And the third one.',
 'Is this the first document?', 
 ]
 
 



###HandsOn Titanic Data processing 
#Let's go through an example from Kaggle, the Titanic dataset. 
#The task here is to predict who will survive on Titanic, 
#based on a subset of whole dataset.
0. Note survived is 'y', rest all are 'X' 
1. Replace nan values of embarked, fare by mode of embarked, fare 
2. Create a transformer with following transformation 
   String categorical - embarked, pclass, sex, Title
                        FamilyID
   Take as it is - fare, parch , sibsp , FamiliySize, AgeOriginallyNaN
                   AgeFilledMedianByTitle   
   Create following columns as 
        Title - get Title portion from name
        LastName  - get last name ftom name 
        FamilySize - total of sibsp and parch + 1 
        FamilyID  - String of "LastName:FamiliySize"
                    If FamiliySize <=2 , then "Small_Family"
        AgeOriginallyNaN - new column where 0 = age is NaN, 1 = age is not NaN 
            Hint: Use .isnull() and convert to int 
        AgeFilledMedianByTitle , median age for that Title 
            Find median age for each title(groupby)
            then merge that with original DF on Title 
            


###HandsOn -  diabetes- Lasso, LassoCV 
1. load diabetes data (hint: use sklearn.datasets)
2. check scatter matrix of above 
3. Use Lasso with alpha from np.logspace(-4, -0.5, 30)
   Use cross_val_score for 3 folds 
   Get mean and std of above scores 
   Use LassoCV and do the same above 
4. Draw alphas vs scores   
   Draw error band and fill between  with std_error, (use std_error = scores_std / np.sqrt(n_folds))
   set ylabel('CV score +/- std error') and xlabel('alpha')



###HandsOn - Example - hand-written digits datasets 
1. load Mnist dataset (Hint, check sklearn.datasets)
2. Understand data (8x8 data)
   Take 50% as train data and rest as test data 
3. Write a function to automate estimation and then 
   print confusion_matrix, accuracy_score and classification_report
4. Apply all below classifiers(wih default value of hyper-parameters) 
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC

5. For one of the above , draw 4 samples 
   Test image and target 
   Test image and predicted 
   Hint: -use pl.subplot with 2 rows and 4 columns, first row for target and 2nd row for predicted 

   
   
   
##HandsOn - breast cancer prediction with LogisticRegression
#Draw ROCAUC 
#https://archive.ics.uci.edu/ml/datasets/Breast+Cancer+Wisconsin+(Diagnostic)
#check breast_cancer.csv , but use load_breast_cancer() 
#Diagnosis (M = malignant,1, B = benign,0) 
1) ID number
2) Diagnosis (M = malignant, B = benign)
3-32)Ten real-valued features are computed for each cell nucleus:
a) radius (mean of distances from center to points on the perimeter)
b) texture (standard deviation of gray-scale values)
c) perimeter
d) area
e) smoothness (local variation in radius lengths)
f) compactness (perimeter^2 / area - 1.0)
g) concavity (severity of concave portions of the contour)
h) concave points (number of concave portions of the contour)
i) symmetry
j) fractal dimension ("coastline approximation" - 1)


###HandsOn - Example - MNIST digit recognition using TPOT 
1. Use TPOT to get best model for MNIST data 



 
##HandsOn - DT Regressor on Boston data 
#load_boston()
#DO GridSearchCV/RandomizedSearchCV on below 
params = dict(min_samples_leaf= range(2,10) , 
    max_depth=range(1,10), 
    min_samples_split=range(2,10))


##HandsOn - KNN on Regressor 

#Sample data 
import numpy as np
import matplotlib.pyplot as plt
from sklearn import neighbors

np.random.seed(0)
X = np.sort(5 * np.random.rand(40, 1), axis=0) #(40, 1)
T = np.linspace(0, 5, 500)[:, np.newaxis] #(500, 1)
y = np.sin(X).ravel() #(40,)

# Add noise to targets
y[::5] += 1 * (0.5 - np.random.rand(8)) #every 5 th point, add some noise, note np.random.rand(8) generates (8,)


1) Fit regression model with n_neighbors = 5
2) Then draw scatter of original y and line plot of predicted y 


###HandsON- Diabetes Data Predictive Analysis using DNN(use one hidden layer)
dataset = pd.read_csv("data/pima-indians-diabetes.csv")
#Simple model - 8 feature/input , 1 output (last column is binary classifications)
#with one hidden layer 

##HandsOn - Check in boston.csv
- RM       average number of rooms per dwelling
- MEDV     Median value of owner-occupied homes in $1000's
- LSTAT    % lower status of the population
- TAX      full-value property-tax rate per $10,000

Find the correlation between medv and LSTAT
Find the correlation  between medv and RM
Draw a scatter plot between medv and LSTAT
















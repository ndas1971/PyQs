from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

user = pd.read_csv('https://raw.githubusercontent.com/ndas1971/Misc/master/BX-Users.csv',
    sep=';', error_bad_lines=False, encoding="latin-1")
user.columns = ['userID', 'Location', 'Age']
rating = pd.read_csv('https://raw.githubusercontent.com/ndas1971/Misc/master/BX-Book-Ratings.csv',
    sep=';', error_bad_lines=False, encoding="latin-1")
rating.columns = ['userID', 'ISBN', 'bookRating']
df = pd.merge(user, rating, on='userID', how='inner')
df.drop(['Location', 'Age'], axis=1, inplace=True)
print("Data", df.head())

print("Ratings Distribution")
#over 62% of all ratings in the data are 0, and very few ratings are 1 or 2, or 3, 
#low rating books mean they are generally really bad.
import plotly.graph_objs as go

data = df['bookRating'].value_counts().sort_index(ascending=False)
trace = go.Bar(x = data.index,
               text = ['{:.1f} %'.format(val) for val in (data.values / df.shape[0] * 100)],
               textposition = 'auto',
               textfont = dict(color = '#000000'),
               y = data.values,
               )
# Create layout
layout = dict(title = 'Distribution Of {} book-ratings'.format(df.shape[0]),
              xaxis = dict(title = 'Rating'),
              yaxis = dict(title = 'Count'))
# Create plot
fig = go.Figure(data=[trace], layout=layout)
fig.show()
    
    
# Number of ratings per book
data = df.groupby('ISBN')['bookRating'].count().clip(upper=50)

# Create trace
#matplotlib.pyplot.hist(x, bins=None)
#no_of_bins or sequence eg [1, 2, 3, 4] then then the first bin is [1, 2)
#or binning strategy, such as 'auto', 'sturges', 'fd', 'doane', 'scott', 'rice' or 'sqrt',
trace = go.Histogram(x = data.values,
                     name = 'Ratings',
                     xbins = dict(start = 0,
                                  end = 50,
                                  size = 2))
# Create layout
layout = go.Layout(title = 'Distribution Of Number of Ratings Per Book (Clipped at 100)',
                   xaxis = dict(title = 'Number of Ratings Per Book'),
                   yaxis = dict(title = 'Count'),
                   bargap = 0.2)

# Create plot
fig = go.Figure(data=[trace], layout=layout)
fig.show()


print("""
Most of the books in the data received less than 5 ratings, 
and very few books have many ratings, although the most rated book 
has received 2,502 ratings\r\n""",
df.groupby('ISBN')['bookRating'].count().reset_index().sort_values('bookRating', ascending=False)[:10] )


#Ratings Distribution By User
# Number of ratings per user
data = df.groupby('userID')['bookRating'].count().clip(upper=50)

# Create trace
trace = go.Histogram(x = data.values,
                     name = 'Ratings',
                     xbins = dict(start = 0,
                                  end = 50,
                                  size = 2))
# Create layout
layout = go.Layout(title = 'Distribution Of Number of Ratings Per User (Clipped at 50)',
                   xaxis = dict(title = 'Ratings Per User'),
                   yaxis = dict(title = 'Count'),
                   bargap = 0.2)

# Create plot
fig = go.Figure(data=[trace], layout=layout)
fig.show()

print("""Most of the users in the data gave less than 5 ratings, 
and not many users gave many ratings\r\n""",
df.groupby('userID')['bookRating'].count().reset_index().sort_values('bookRating', ascending=False)[:10])


#Filter based on > 50 ratings on books and given by users 
min_book_ratings = 50
filter_books = df['ISBN'].value_counts() > min_book_ratings
filter_books = filter_books[filter_books].index.tolist()

min_user_ratings = 50
filter_users = df['userID'].value_counts() > min_user_ratings
filter_users = filter_users[filter_users].index.tolist()

#() is must 
df_new = df[(df['ISBN'].isin(filter_books)) & (df['userID'].isin(filter_users))]
print('The original data frame shape:\t{}'.format(df.shape))
print('The new data frame shape:\t{}'.format(df_new.shape))
df_new.head()

#Now ALS 
import surprise as S
import surprise.accuracy as sa
import surprise.model_selection as sm 
#Read Data 
reader = S.Reader(rating_scale=(0, 9))
data = S.Dataset.load_from_df(df_new[['userID', 'ISBN', 'bookRating']], reader)

#Benchmark 
# benchmark = []
# # Iterate over all algorithms - S.NMF() gives division error 
# for algorithm in [S.SVD(), S.SVDpp(), S.SlopeOne(), S.NMF(), S.NormalPredictor(), 
#   S.KNNBaseline(), S.KNNBasic(), S.KNNWithMeans(), S.KNNWithZScore(), 
#   S.BaselineOnly(), S.CoClustering()]:
#     # Perform cross validation
#     results = sm.cross_validate(algorithm, data, measures=['RMSE'], cv=3, verbose=False)
#     
#     # Get results & append algorithm name
#     tmp = pd.DataFrame.from_dict(results).mean(axis=0)
#     tmp = tmp.append(pd.Series([str(algorithm).split(' ')[0].split('.')[-1]], index=['Algorithm']))
#     benchmark.append(tmp)
#     
# print("BaselineOnly algorithm gave us the best rmse\r\n",
# pd.DataFrame(benchmark).set_index('Algorithm').sort_values('test_rmse')    )
# 
#  
print('Using ALS and BaselineOnly')
bsl_options = {'method': 'als' } #or svd , use default configiration of als 
algo = S.BaselineOnly(bsl_options=bsl_options)
sm.cross_validate(algo, data, measures=['RMSE'], cv=3, verbose=False)

bsl_options = {'method': 'als' } #or svd , use default configiration of als 
trainset, testset = sm.train_test_split(data, test_size=0.25)
algo = S.BaselineOnly(bsl_options=bsl_options)
predictions = algo.fit(trainset).test(testset)
print("Test predictions", sa.rmse(predictions))

print("OR Compute the rating prediction for given user and item\r\n", df_new.head()) 
print("pick one ")
#243 	0060915544 	10
raw_uid = 243 	
raw_iid = '0060915544'
print(f"prediction for {raw_uid} {raw_iid}\r\n", algo.predict(raw_uid, raw_iid) ) #, true_r_ui_if_available=None)
#Prediction(uid=243, iid='0060915544', r_ui=10, est=2.8455528048498104, details={'was_impossible': False})


print("""To inspect our predictions in details, 
we are going to build a pandas data frame with all the predictions""")

def get_Iu(uid,ts):
    """ return the number of items rated by given user
    args: 
      uid: the id of the user
    returns: 
      the number of items rated by the user
    whereas ur   
      The users ratings. 
      This is a dictionary containing lists of tuples of the form (item_inner_id, rating). 
      The keys are user inner ids.
      
    """
    try:
        return len(ts.ur[ts.to_inner_uid(uid)])
    except ValueError: # user was not part of the ts
        return 0
    
def get_Ui(iid,ts):
    """ return number of users that have rated given item
    args:
      iid: the raw id of the item
    returns:
      the number of users that have rated the item.
    whereas 
     ir
        The items ratings. 
        This is a dictionary containing lists of tuples of the form (user_inner_id, rating). 
        The keys are item inner ids.    
    """
    try: 
        return len(ts.ir[ts.to_inner_iid(iid)])
    except ValueError:
        return 0
    
#uid – The (raw) user id. 
#iid – The (raw) item id. 
#r_ui (float) – The true rating rui.
#est (float) – The estimated rating r^ui
#details - some releavnt details 
df = pd.DataFrame(predictions, columns=['uid', 'iid', 'rui', 'est', 'details'])
from functools import partial 
df['inner_uid'] = df.uid.apply(partial(get_Iu,ts=trainset))
df['inner_iid'] = df.iid.apply(partial(get_Ui,ts=trainset))
df['err'] = abs(df.est - df.rui)
best_predictions = df.sort_values(by='err')[:10]
worst_predictions = df.sort_values(by='err')[-10:]
print("best_predictions=\r\n", best_predictions, "\r\nworst_predictions=\r\n", worst_predictions)

print("To find nearest of an ISBN...")
trainset, testset = sm.train_test_split(data, test_size=0.25)
algo = S.KNNBaseline(bsl_options=bsl_options)
predictions = algo.fit(trainset).test(testset)
print("Nearest of an ISBN rmse=\r\n", sa.rmse(predictions))

raw_uid = 243 	
raw_iid = '0060915544'
print("and the prediction=\r\n", algo.predict(raw_uid, raw_iid))  #, true_r_ui_if_available=None)
#Prediction(uid=243, iid='0060915544', r_ui=None, est=8.060252391846117, details={'actual_k': 40, 'was_impossible': False})


raw_item_id = '055358264X'
# Retrieve inner id 
item_inner_id = algo.trainset.to_inner_iid(raw_item_id)
items_neighbors = algo.get_neighbors(item_inner_id, k=10)

# Convert inner ids of the neighbors into names.
items_neighbors_raw = [algo.trainset.to_raw_iid(inner_id)
                   for inner_id in items_neighbors]

print("Reading more info on Books")
books = pd.read_csv('https://raw.githubusercontent.com/ndas1971/Misc/master/BX-Books.csv', 
    sep=';', index_col=0,error_bad_lines=False, encoding="latin-1")

print(f'The 10 nearest neighbors of {raw_item_id}:{books.loc[raw_item_id,:].tolist()}')
for isbn in items_neighbors_raw:
    print(f"->{isbn}:{books.loc[isbn,:].tolist()}")
    
import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn.datasets import *

from sklearn.ensemble import *  
from sklearn.tree import *

PAUSE='Y'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()

##Quick Example of Baggin and RF, ET 
#Real world data set 
#http://archive.ics.uci.edu/ml/datasets/Covertype
##The samples in this dataset correspond to 30×30m patches of forest in the US, collected for the task of predicting each patch’s cover type, i.e. the dominant species of tree
#Classes 	7
#Samples total 	581012
#Dimensionality 	54
#Features 	int
##code 
import time 
data = fetch_covtype()
print(data.DESCR.encode('ascii', 'ignore').decode())
#input()

X, y = data.data, data.target 

CV = 3 #StratifiedKFold(n_splits=5,shuffle=True)

st = time.time()
clf1 = DecisionTreeClassifier()
scores = cross_val_score(clf1, X, y, cv=CV) 
print("DecisionTreeClassifier\nAccuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.94 (+/- 0.00) and time=76 sec
print("with model\n", clf1)

st = time.time()
clf2 = BaggingClassifier(clf1, max_samples=0.5, max_features=0.5)
scores = cross_val_score(clf2, X, y, cv=CV) 
print("BaggingClassifier\nAccuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.90 (+/- 0.07) and time=164 sec
print("with model\n", clf2)


st = time.time()
clf10 = RandomForestClassifier(n_estimators=50, max_features = np.sqrt(54).astype(int), max_depth=4)
scores = cross_val_score(clf10, X, y, cv=CV) 
print("RandomForestClassifier\nAccuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.96 (+/- 0.00) and time=1057 sec
print("with model\n", clf10)

st = time.time()
clf = ExtraTreesClassifier(n_estimators=50,max_features = np.sqrt(54).astype(int), max_depth=4)
scores = cross_val_score(clf, X, y, cv=CV) 
print("ExtraTreesClassifier\nAccuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
#Accuracy: 0.94 (+/- 0.00) and time=89 sec
print("with model\n", clf)

#for Completion sake 
#st = time.time()
#clf =  GradientBoostingClassifier(n_estimators=50, learning_rate=1.0, max_depth=None, random_state=0)
#scores = cross_val_score(clf, X, y, cv=CV) 
#print("GradientBoostingClassifier\nAccuracy: %0.2f (+/- %0.2f) and time=%d sec" % (scores.mean(), scores.std() * 2, (time.time()-st)))
##Accuracy: 0.94 (+/- 0.00) and time=89 sec
#print("with model\n", clf)

print("----Ofcourse , you can gridsearch-----")
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
clf = ExtraTreesClassifier(max_features = np.sqrt(54).astype(int))
params = dict(n_estimators= [20,50,100],  max_depth=[5,10,25,35])
search = RandomizedSearchCV(clf, params)
st = time.time()
search.fit(X_train, y_train)
print("Best param for ExtraTreesClassifier", search.best_params_ )#{'n_estimators': 80}
print("score= train:%f test:%f and time=%d sec" % (search.score(X_train, y_train),
        search.score(X_test, y_test), (time.time()-st)))
#score= train:1.000000 test:0.951870 and time=5299 sec
print("with model\n", search.best_estimator_)
       
       


print("Feature ranking from RandomForestClassifier:")

importances = clf10.feature_importances_
#find out stddev of each tree's feature importance
std = np.std([tree.feature_importances_ for tree in clf10.estimators_],axis=0) #columnwise
#Returns the indices that would sort an array.
'''
>>> x = np.array([3, 1, 2]) #
>>> np.argsort(x)
array([1, 2, 0]) #sorted array x[1], x[2], x[0]
'''
indices = np.argsort(importances)[::-1] #then reverser it, so highest is first 

# Print the feature ranking
feature_names=["Feat"+str(i+1)   for i in range(data.data.shape[1])]
sorted_features = []
for f in range(X.shape[1]):  #1 means feature's ie 54 
    print("%d. feature %d (%f)" % (f + 1, indices[f], importances[indices[f]]))
    sorted_features.append(feature_names[indices[f]])
    
# Plot the feature importances of the forest
plt.figure()
plt.title("Feature importances")
#yerr = is line for variation of that bar 
plt.bar(range(X.shape[1]), importances[indices],color="r", yerr=std[indices], align="center")
plt.xticks(np.arange(X.shape[1]), sorted_features, rotation='vertical')
plt.xlim([-1, X.shape[1]])
plt.show()     


from langchain_core.tools import tool
from langchain_mistralai import ChatMistralAI
from langchain_core.messages import *
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_core.runnables import * 
from langchain.agents.tool_calling_agent.base import create_tool_calling_agent
from  langchain.agents.agent import AgentExecutor

from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
import time 
from langchain_core.chat_history import InMemoryChatMessageHistory

memory = InMemoryChatMessageHistory(session_id="test-session")


model = ChatMistralAI(
    model="open-mistral-nemo",
    temperature=0,
    max_retries=2,
)

@tool 
def add(a:int, b:int) -> int:
    """adds a and b"""
    return a + b 
    
@tool 
def multiply(a:int, b:int) -> int:
    """multiply a and b"""
    return a * b 
    
tools = [add, multiply]


prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant"),
    #below is must , inmemory uses it for internal work
    ('placeholder', "{chat_history}"),
    ('human', "{query}"),
    #below is must , agentexecutor uses it for internal work
    ('placeholder', "{agent_scratchpad}"),
    ])
    
    
agent = create_tool_calling_agent(model, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools)

agent_history = RunnableWithMessageHistory(
    agent_executor,
    # This is needed because in most real world scenarios, a session id is needed
    # It isn't really used here because we are using a simple in memory ChatMessageHistory
    lambda session_id: memory,
    input_messages_key="query",
    history_messages_key="chat_history",
)


conf = {"configurable": {"session_id" : "test-session"}}

queries = [
    "I am Das, what is 11 + 41",
    "Who am I",
    "What is last output"]
    
for query in queries:
    msg = dict(query=query)
    print(msg)
    time.sleep(2)
    response = agent_history.invoke(msg, conf)    
    print(response['output'])
    
    
    
    



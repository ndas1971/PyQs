from langchain_core.tools import tool
from langchain_mistralai import ChatMistralAI
from langchain_core.messages import *
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_core.runnables import * 
from langchain_core.agents import * 
from langchain.agents.tool_calling_agent.base import create_tool_calling_agent
from  langchain.agents.agent import AgentExecutor


model = ChatMistralAI(
    model="open-mistral-nemo",
    temperature=0,
    max_retries=2,
)

#Tools are Runnables ie functions
#arg types and doc_str in must <- based of that, AI selects 
@tool 
def add(a:int, b:int) -> int:
    """adds a and b"""
    return a + b 
    
@tool 
def multiply(a:int, b:int) -> int:
    """multiply a and b"""
    return a * b 
    
tools = [add, multiply]
#Internally AgentExecutor uses below 
#llm_with_tools = llm.bind_tools(tools)

query = "What is 3 * 1? Also what is 11 + 41"
#*** VERY VERY IMP, check this template 
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant"),
    ('human', "{query}"),
    #below is must , agentexecutor uses it for internal work
    ('placeholder', "{agent_scratchpad}"),
    ])
agent = create_tool_calling_agent(model, tools, prompt)
aexecutor = AgentExecutor(agent=agent, tools=tools)

m = aexecutor.invoke(dict(query=query))
print(m)

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_mistralai import ChatMistralAI
from langchain_mistralai import MistralAIEmbeddings

#pip install pymupdf
# Step 1: Load Documents
loader = PyMuPDFLoader("A European Approach to Artificial Intelligence - A Policy Perspective.pdf")
docs1 = loader.load()
print(f"Number of pages in the document: {len(docs1)}")
loader = PyMuPDFLoader("A European Approach to Artificial Intelligence - A Policy Perspective.pdf")
docs2 = loader.load()
print(f"Number of pages in the document: {len(docs2)}")
docs = docs1 + docs2

# Step 2: Split Documents
text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
split_documents = text_splitter.split_documents(docs)
print(f"Number of split chunks: {len(split_documents)}")

# Step 3: Generate Embeddings
embeddings = MistralAIEmbeddings(model="mistral-embed",)


# Step 4: Create and Save the Database
# Create a vector store.
#set HF_TOKEN environment var , Huggingface API token 
#pip install faiss-cpu
vectorstore = FAISS.from_documents(documents=split_documents, embedding=embeddings)
res = vectorstore.similarity_search("URBAN MOBILITY")
print(f"Number of pages in the result: {len(res)}")

# Step 5: Create Retriever
# Search and retrieve information contained in the documents.
retriever = vectorstore.as_retriever()
#retriever.invoke("What is the phased implementation timeline for the EU AI Act?")

# Step 6: Create Prompt
prompt = PromptTemplate.from_template(
    """You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, just say that you don't know. 

#Context: 
{context}

#Question:
{question}

#Answer:"""
)

# Step 7: Load LLM
llm = ChatMistralAI(
    model="open-mistral-nemo",
    temperature=0,
    max_retries=2,
)

# Step 8: Create Chain
chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

# Run Chain
# Input a query about the document and print the response.
question = "Where has the application of AI in healthcare been confined to so far?"
response = chain.invoke(question)
print(response)


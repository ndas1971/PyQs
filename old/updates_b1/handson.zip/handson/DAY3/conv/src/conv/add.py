from typing import Any, overload 

#overload when we want to fix types at many places 
#and union can not handle 
@overload 
def add(x:int, y:int)->int:
    ...         #pass 
    
@overload 
def add(x:float, y:float)->float:
    ...   
    
@overload 
def add(x:str, y:str)->str:
    ...   
    
@overload 
def add(x:list[int], y:list[int])->list[int]:
    ...   

@overload 
def add(x:tuple[int,...], y:tuple[int,...])->tuple[int,...]:
    ...   


#final implementation
def add(x,y):
    return x+y 
    
    
if __name__ == '__main__':
    print(add(1,2),
        add(1.2, 1.3),
        add("OK", "World"),
        add([1,23], [3]),
        add( (1,2), (3,)), 
        sep="\n",
        )
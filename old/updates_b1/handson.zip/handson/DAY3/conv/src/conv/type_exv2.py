"""
degtoF = lambda deg :  32 + 9/5 * deg 
FtoC   = lambda f : (f-32)*5/9

"""

from enum import Enum 

Unit = Enum("Unit", ['F', 'C'])                         

#Alias of existing type   - satya 
InType = int|float|list[float]|tuple[float]|list[int]|tuple[int]
OutType = float | list[float] | tuple[float,...]

#convert(2, Unit.F, prec = 4)
def convert(value: InType, /, unit:Unit, *, prec:int=3) -> OutType:
    d2f = lambda deg: (deg * 9/5) + 32
    f2d = lambda f : (f - 32) * 5/9 
    conv = { Unit.F : f2d, Unit.C: d2f }
    match value:
        case [a, ] | (a, ):                                 #list or tuple of one element 
            return [convert(a, unit)] if type(value) is list \
                else (convert(a, unit),)
        case [a, *b] | (a, *b):                         #list or tuple of inf 
            return [convert(a, unit), *convert(b, unit)] if type(value) is list \
                else (convert(a, unit), *convert(b, unit))
        case float(a) | int(a):                     # a has to be int | float 
            return round(conv[unit](a), prec)
        case _ :                                    #default 
            raise NotImplementedError()

if __name__ == '__main__':    
    # put types for mypy, else it would be inferred as object 
    values: list[int|float|list[int|float]|tuple[int|float,...]] \
        = [ 0, 32, [32], (32,), (32,32), [32,32], [[32,32]], [[32],[32]] ]
    units  = [Unit.F] * len(values) + [Unit.C] * len(values)
    for v, u in zip([*values, *values], units):
        print(f"{v=}, {u.name=}, {convert(v,u)=}")

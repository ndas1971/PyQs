import glob             #ls  or dir 
import os.path          # get size, to know is file or dir 

def get_files(path, ed = []):  
    files = glob.glob(os.path.join(path, "*"))
    for f in files:
        if os.path.isfile(f):
            ed.append(f)
        elif os.path.isdir(f):
            get_files(f, ed)
    return ed  
    
#Option-1 generator function, Yield is for one element, 
#Yield from is from another Itr
def get_files_it(path):  
    files = glob.glob(os.path.join(path, "*"))
    for f in files:
        if os.path.isfile(f):
            yield f 
        elif os.path.isdir(f):
            yield from get_files_it(f)
            
#OPtion-2 
class Files:
    def __init__(self, path):
        self.path = path 
    def __iter__(self):
        files = glob.glob(os.path.join(self.path, "*"))
        for f in files:
            if os.path.isfile(f):
                yield f 
            elif os.path.isdir(f):
                yield from get_files_it(f)
    
    
if __name__ == '__main__':
    path = r"C:\Windows"  #?
    for f in Files(path):
        print(f)
from fastapi import FastAPI, Request, HTTPException, Form
from typing import Any, Annotated 
#https://www.starlette.io/requests/
#https://www.starlette.io/responses/

app = FastAPI()

#.get for GET 
#.post for POST ...
#Generates OpenAPI spec, through which we can unit test and see doc 
#REST - input Content-Type = application/json 
#OUtput Content-Type  = application json 

@app.get("/")               #http://localhost:8000/
async def hello():
    return {"Hello": "World"}   #Dict, list , Pydantic model 

#PATH- item_id, GET/Query- name, count params 
#PATH - /   , Query - ? and then & for others 
#http://localhost:8000/ex/2                          item_id=2, name=abc, count=2               
#http://localhost:8000/ex/2?name=das&count=3         item_id=2, name=das, count=3 
#http://localhost:8000/ex/2?name=das
#http://localhost:8000/ex/2?count=3                  item_id=2, name=abc, count=3 
#http://localhost:8000/ex/2?count=3&name=das&limit=3 item_id=2, name=das, count=3 
#http://localhost:8000/ex/bhuv                        Error
ids = [1,2,3,4]
@app.get("/ex/{item_id}")
async def path_query_params(item_id : int, request:Request, name:str = "abc",count: int= 2):
    if item_id not in ids:
        raise HTTPException(status_code=410, detail="Item not found")
    return dict(item_id=item_id, name=name, count=count, host=request.client.host )
    


#POST 
from pydantic import BaseModel
    
class Output(BaseModel):
    name: str 
    final_price : float 
    

class Item(BaseModel):
    name: str 
    description: str |None = None 
    price : float 
    tax: float|None = None 

#Validating response , Use response model 
@app.post("/calculate", response_model=Output)
async def calculate(item:Item):
    item_dict = item.dict()
    if item_dict['tax']:
        final_price = (1+ item_dict['tax']/100) * item_dict['price']
    else:
        final_price = item_dict['price']
    return  dict(name=item_dict['name'], final_price=final_price)
    
"""
import requests 
response = requests.post("http://localhost:8000/calculate", json=dict(name="name", price=100))
response.json()
""" 

#FormData, Query(), Header(), Cookie
@app.post("/calcform", response_model=Output)
async def calcform(item:Annotated[Item, Form()]):
    item_dict = item.dict()
    if item_dict['tax']:
        final_price = (1+ item_dict['tax']/100) * item_dict['price']
    else:
        final_price = item_dict['price']
    return  dict(name=item_dict['name'], final_price=final_price)


#Depends 

#Auth 
    


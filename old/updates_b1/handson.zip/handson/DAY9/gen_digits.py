import numpy as np

# Define 8x8 pixel patterns for digits 0-9
digits = {
    0: [
        " 1111 ",
        "1    1",
        "1   11",
        "1  1 1",
        "11   1",
        "1    1",
        " 1111 ",
        "      "
    ],
    1: [
        "   1   ",
        "  11   ",
        "   1   ",
        "   1   ",
        "   1   ",
        "   1   ",
        "  1111 ",
        "       "
    ],
    2: [
        " 1111 ",
        "1    1",
        "     1",
        "   11 ",
        " 11   ",
        "1     ",
        "111111",
        "      "
    ],
    3: [
        " 1111 ",
        "1    1",
        "     1",
        "  111 ",
        "     1",
        "1    1",
        " 1111 ",
        "      "
    ],
    4: [
        "   11  ",
        "  1 1  ",
        " 1  1  ",
        "1   1  ",
        "111111 ",
        "    1  ",
        "    1  ",
        "       "
    ],
    5: [
        "111111",
        "1     ",
        "1     ",
        "11111 ",
        "     1",
        "1    1",
        " 1111 ",
        "      "
    ],
    6: [
        " 1111 ",
        "1    1",
        "1     ",
        "11111 ",
        "1    1",
        "1    1",
        " 1111 ",
        "      "
    ],
    7: [
        "111111",
        "     1",
        "    1 ",
        "   1  ",
        "  1   ",
        " 1    ",
        "1     ",
        "      "
    ],
    8: [
        " 1111 ",
        "1    1",
        "1    1",
        " 1111 ",
        "1    1",
        "1    1",
        " 1111 ",
        "      "
    ],
    9: [
        " 1111 ",
        "1    1",
        "1    1",
        " 11111",
        "     1",
        "1    1",
        " 1111 ",
        "      "
    ]
}

# Create a function to display the digit grid
def display_digit(digit):
    grid = np.array([list(row) for row in digits[digit]])
    for row in grid:
        print("".join(row))

# Display digits 0-9
for i in range(10):
    print(f"Digit {i}:")
    display_digit(i)
    print("\n")
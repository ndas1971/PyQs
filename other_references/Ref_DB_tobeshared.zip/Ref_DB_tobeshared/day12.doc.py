###Install and Check --WORKSHOP --IMP
Runs small serverless compute
https://docs.databricks.com/aws/en/getting-started/free-edition
https://docs.databricks.com/aws/en/getting-started/free-edition-limitations
https://login.databricks.com/?intent=SIGN_UP&provider=DB_FREE_TIER&tuuid=4bc1e8d7-20b5-49c8-b065-8467e6dd5665&dbx_source=direct&rl_aid=52499833-3275-4811-9382-60ad8530e80b




Note structured streaming has limitations in serverless (only availableNow-called batch, no trigger possible)
https://docs.databricks.com/aws/en/compute/serverless/limitations
https://docs.databricks.com/aws/en/compute/access-mode-limitations#streaming-shared


All-purpose compute
	Limited to small cluster sizes.

SQL warehouses
	One SQL warehouse, limited to a 2X-Small cluster size.

Jobs
	Max of 5 concurrent job tasks per account.

Lakeflow Declarative Pipelines
	One active pipeline per pipeline type.


By default environment version 2
can be made 3 from configuuration
https://docs.databricks.com/aws/en/release-notes/serverless/environment-version/three
You can add more module in Dependencies textbox eg
simplejson==3.19.*

##'default' schema vs 'main' schema
if your workspace launched with an automatically-provisioned workspace catalog,
all workspace users can create objects in the workspace catalog's 'default' schema.

Run a SQL query to confirm Unity Catalog enablement
SELECT CURRENT_METASTORE();

If your workspace was enabled for Unity Catalog manually,
it has a 'main' catalog provisioned automatically.

Workspace users have the USE CATALOG privilege on the 'main' catalog,
which doesn't grant the ability to create or select from any objects in the catalog,
but is a prerequisite for working with any objects in the catalog.
The user who created the metastore owns the 'main' catalog by default
and can both transfer ownership and grant access to other users.


The user who creates the workspace is automatically added as a workspace user
with the workspace admin role (that is, a user in the admins workspace-local group).
As a workspace admin, you can add and invite users to the workspace,
can assign the workspace admin role to other users,
and can create service principals and groups.

Account admins also have the ability to add users, service principals, and groups to your workspace.
They can grant the account admin and metastore admin roles.

If your workspace was enabled for Unity Catalog automatically:
    Workspace admins can create new catalogs and objects in new catalogs, and grant access to them.
    There is no metastore admin by default.
    Workspace admins own the workspace catalog (if there is one)
    and can grant access to that catalog and any objects in that catalog.
If your workspace was enabled for Unity Catalog manually:
    Workspace admins have no special Unity Catalog privileges by default.
    Metastore admins must exist and can create any Unity Catalog object
    and can take ownership of any Unity Catalog object.

If your workspace was enabled for Unity Catalog automatically,
the workspace admin owns the workspace catalog and can grant the ability to create new schemas:

GRANT CREATE SCHEMA ON <workspace-catalog> TO `data-consumers`;

You can also grant and revoke privileges using Catalog Explorer.

##system catalog vs information_schema
https://learn.microsoft.com/en-us/azure/databricks/admin/system-tables/
System tables are an Databricks-hosted analytical store of your account's operational
data found in the 'system' catalog. System tables can be used for historical observability
across your account.

The INFORMATION_SCHEMA is a SQL standard based schema, provided in every catalog created
on Unity Catalog.

Within the information schema, you can find a set of views describing the objects known
to the schema's catalog that you are privileged to see.

The information schema of the SYSTEM catalog returns information about objects across
all catalogs within the metastore.
Information schema system tables do not contain metadata about hive_metastore objects.

The purpose of the information schema is to provide a SQL based,
self describing API to the metadata.

Check Entity relationship diagram of the information schema
https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-information-schema

###First code   with Sample DataSet  --WORKSHOP --IMP (basic-etl)
https://docs.databricks.com/aws/en/discover/databricks-datasets

https://docs.databricks.com/aws/en/dbfs/
Community edition has DBFS support and hive_metastore, Unit catalog
support (hive_metastore is deprecated, new cloud based DB has 'default' unit catalog,
User can create, delete etc .  Needs cloud based storage account.
Community edition does not have that)

Databricks recommends against using DBFS and mounted cloud object storage
for most use cases in Unity Catalog-enabled Databricks workspaces.
Some sample datasets mounted to DBFS are available in Databricks

https://docs.databricks.com/aws/en/dev-tools/databricks-utils
display(dbutils.fs.ls('/databricks-datasets'))

path	name	size	modificationTime
dbfs:/databricks-datasets/COVID/	COVID/	0	0
dbfs:/databricks-datasets/README.md	README.md	976	1532468253000
dbfs:/databricks-datasets/Rdatasets/	Rdatasets/	0	0
dbfs:/databricks-datasets/SPARK_README.md	SPARK_README.md	3359	1455043490000
dbfs:/databricks-datasets/adult/	adult/	0	0
dbfs:/databricks-datasets/airlines/	airlines/	0	0
dbfs:/databricks-datasets/amazon/	amazon/	0	0
dbfs:/databricks-datasets/asa/	asa/	0	0
dbfs:/databricks-datasets/atlas_higgs/	atlas_higgs/	0	0
dbfs:/databricks-datasets/bikeSharing/	bikeSharing/	0	0
dbfs:/databricks-datasets/cctvVideos/	cctvVideos/	0	0
dbfs:/databricks-datasets/credit-card-fraud/	credit-card-fraud/	0	0
dbfs:/databricks-datasets/cs100/	cs100/	0	0
dbfs:/databricks-datasets/cs110x/	cs110x/	0	0
dbfs:/databricks-datasets/cs190/	cs190/	0	0
dbfs:/databricks-datasets/data.gov/	data.gov/	0	0
dbfs:/databricks-datasets/definitive-guide/	definitive-guide/	0	0
dbfs:/databricks-datasets/delta-sharing/	delta-sharing/	0	0
dbfs:/databricks-datasets/flights/	flights/	0	0
dbfs:/databricks-datasets/flower_photos/	flower_photos/	0	0
dbfs:/databricks-datasets/flowers/	flowers/	0	0
dbfs:/databricks-datasets/genomics/	genomics/	0	0
dbfs:/databricks-datasets/hail/	hail/	0	0
dbfs:/databricks-datasets/identifying-campaign-effectiveness/	identifying-campaign-effectiveness/	0	0
dbfs:/databricks-datasets/iot/	iot/	0	0
dbfs:/databricks-datasets/iot-stream/	iot-stream/	0	0
dbfs:/databricks-datasets/learning-spark/	learning-spark/	0	0
dbfs:/databricks-datasets/learning-spark-v2/	learning-spark-v2/	0	0
dbfs:/databricks-datasets/lending-club-loan-stats/	lending-club-loan-stats/	0	0
dbfs:/databricks-datasets/med-images/	med-images/	0	0
dbfs:/databricks-datasets/media/	media/	0	0
dbfs:/databricks-datasets/mnist-digits/	mnist-digits/	0	0
dbfs:/databricks-datasets/news20.binary/	news20.binary/	0	0
dbfs:/databricks-datasets/nyctaxi/	nyctaxi/	0	0
dbfs:/databricks-datasets/nyctaxi-with-zipcodes/	nyctaxi-with-zipcodes/	0	0
dbfs:/databricks-datasets/online_retail/	online_retail/	0	0
dbfs:/databricks-datasets/overlap-join/	overlap-join/	0	0
dbfs:/databricks-datasets/power-plant/	power-plant/	0	0
dbfs:/databricks-datasets/retail-org/	retail-org/	0	0
dbfs:/databricks-datasets/rwe/	rwe/	0	0
dbfs:/databricks-datasets/sai-summit-2019-sf/	sai-summit-2019-sf/	0	0
dbfs:/databricks-datasets/sample_logs/	sample_logs/	0	0
dbfs:/databricks-datasets/samples/	samples/	0	0
dbfs:/databricks-datasets/sfo_customer_survey/	sfo_customer_survey/	0	0
dbfs:/databricks-datasets/sms_spam_collection/	sms_spam_collection/	0	0
dbfs:/databricks-datasets/songs/	songs/	0	0
dbfs:/databricks-datasets/structured-streaming/	structured-streaming/	0	0
dbfs:/databricks-datasets/timeseries/	timeseries/	0	0
dbfs:/databricks-datasets/tpch/	tpch/	0	0
dbfs:/databricks-datasets/travel_recommendations_realtime/	travel_recommendations_realtime/	0	0
dbfs:/databricks-datasets/warmup/	warmup/	0	0
dbfs:/databricks-datasets/weather/	weather/	0	0
dbfs:/databricks-datasets/wiki/	wiki/	0	0
dbfs:/databricks-datasets/wikipedia-datasets/	wikipedia-datasets/	0	0
dbfs:/databricks-datasets/wine-quality/	wine-quality/	0	0

The DBFS root is a storage location provisioned during workspace creation
in the cloud account containing the Databricks workspace.
Databricks does not recommend storing production data, libraries, or scripts in DBFS root

Mounting object storage to DBFS allows you to access objects in object storage
as if they were on the local file system.
Mounts store Hadoop configurations necessary for accessing storage.

DBC Archive: Export a Databricks archive, a binary format that includes metadata
and notebook command outputs. Source File: Export a ZIP archive of notebook source files,
which can be imported into an Azure Databricks workspace

DB to S3/GCP/Azure storage
    https://docs.databricks.com/aws/en/connect/storage/
RECCO- connect Unity Catalog with object storage
    https://docs.databricks.com/aws/en/connect/unity-catalog/cloud-storage/
To Lakehouse federation
    https://docs.databricks.com/aws/en/query-federation/


##Lets check
Open notebook by creating new
Requires compute single node (community and others ) or cluster
By pressing Run, uou can create backing compute node
(% magic commands - %lsmagic)
https://learn.microsoft.com/en-us/azure/databricks/notebooks/notebooks-code
    %fs -> Alternatively, one can use dbutils.fs
    %run: runs a Python file or a notebook.
    %sh: executes shell commands on the cluster nodes.
    %fs: allows you to interact with the Databricks file system.
    %sql: allows you to run SQL queries.
    %scala: switches the notebook context to Scala.
    %python: switches the notebook context to Python.
    %md: allows you to write markdown text.
    %r: switches the notebook context to R.
    %lsmagic: lists all the available magic commands.
    %jobs: lists all the running jobs.
    %config: allows you to set configuration options for the notebook.
    %reload: reloads the contents of a module.
    %pip: allows you to install Python packages.
    %load: loads the contents of a file into a cell.
    %matplotlib: sets up the matplotlib backend.
    %who: lists all the variables in the current scope.
    %env: allows you to set environment variables.


%md # ** Recipe ** – Create a Table from CSV using SQL in Databricks Community Edition
%sql
DROP TABLE IF EXISTS diamonds;
CREATE TABLE diamonds USING CSV OPTIONS (path "/databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv", header "true",inferschema "true")
select * from diamonds

%sql
DESCRIBE diamonds
select clarity,mean(price) as MeanPrice  from diamonds group by clarity order by MeanPrice desc

%sql
DROP TABLE IF EXISTS diamonds;



In Python code

# Load CSV into DataFrame
diamonds = spark.read.csv("/databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv",
                          header=True,
                          inferSchema=True)

# Display the data
display(diamonds)   #result.show()

diamonds.printSchema()

from pyspark.sql.functions import avg

# Group by 'clarity', calculate mean price, and sort descending
result = diamonds.groupBy("clarity") \
    .agg(avg("price").alias("MeanPrice")) \
    .orderBy("MeanPrice", ascending=False)

# Display the result
display(result)

%sql
DROP TABLE IF EXISTS diamonds;

Note following  data formats are supported
https://learn.microsoft.com/en-us/azure/databricks/query/streaming
https://learn.microsoft.com/en-us/azure/databricks/query/formats/
    Delta Lake
    Delta Sharing
    Parquet
    ORC
    JSON
    CSV
    Avro
    Text
    Binary
    XML
    Databricks recommends loading images as binary data.
    Azure Databricks can directly read compressed files in many file format
    https://spark.apache.org/docs/latest/sql-data-sources-load-save-functions.html


##First code of Visualization
Step 1: Create a new notebook
  Then Rename
  Note it is auto saved
Step 2: Query a table (catalog.schema.table)
display(spark.read.table("samples.nyctaxi.trips"))
This result is stored as _sqldf and can be used in other Python and SQL cells.

SELECT * FROM samples.nyctaxi.trips

Press Shift+Enter to run the cell and then move to the next cell.

Display the average fare amount by trip distance, grouped by the pickup zip code.

    Next to the Table tab, click + and then click Visualization.

    The visualization editor displays.

    In the Visualization Type drop-down, verify that Bar is selected.

    Select fare_amount for the X column.

    Select trip_distance for the Y column.

    Select Average as the aggregation type.

    Select pickup_zip as the Group by column.

Then add to Dashborad and copy link
Then delete all


##Tutorial: Create your first table and grant privileges

You can define access to tables declaratively using SQL or the Databricks Explorer UI:

    In the sidebar, click +New > Notebook.

    Select SQL as your notebook language.

    Click Connect and attach the notebook to a compute resource.

    Note catalog name is workspace and schema is default
    (autocreated)

    USE CATALOG workspace;
    USE SCHEMA default;

SQL

CREATE TABLE IF NOT EXISTS default.department
(
   deptcode   INT,
   deptname  STRING,
   location  STRING
);

SQL

INSERT INTO default.department VALUES
   (10, 'FINANCE', 'EDINBURGH'),
   (20, 'SOFTWARE', 'PADDINGTON');

In the sidebar, click Data icon. Catalog and then search for the workspace catalog (<workspace-name>)
and the default schema, where you'll find your new department table.

As the original table creator, you're the table owner,
and you can grant other users permission to read or write to the table.
You can even transfer ownership, but we won't do that here

##Grant permissions using the UI
To give users permissions on your table using the UI:

    Click the table name in Catalog Explorer to open the table details page,
    and go to the Permissions tab.
    Click Grant.
    On the Grant on dialog:
        Select the users and groups you want to give permission to.
        Select the privileges you want to grant.
        For this example, assign the SELECT (read) privilege and click Grant.

OR

GRANT SELECT ON default.department TO `data-consumers`;

Use AI to create visualization
https://docs.databricks.com/aws/en/dashboards/tutorials/create-w-db-assistant

Then drop
Drop table if exists department;

###More Understanding of dbutils --WORKSHOP --IMP (basic-etl)


dbutils.fs.help("cp")

/**
* Copies a file or directory, possibly across FileSystems..
*
* Example: cp("/mnt/my-folder/a", "s3n://bucket/b")
*
* @param from FileSystem URI of the source file or directory
* @param to FileSystem URI of the destination file or directory
* @param recurse if true, all files and directories will be recursively copied
* @return true if all files were successfully copied
*/
cp(from: java.lang.String, to: java.lang.String, recurse: boolean = false): boolean

dbutils.fs.help('ls')
/**
* Lists the contents of a directory.
*
* Example: display(ls("/mnt/my-folder/"))
*
* The FileInfo object that is returned has the following helper methods:
* val files = ls("/mnt/my-folder/")
* files.map(_.name) // [myFile, myDir/]
* files.map(_.length) // [1286, 0]
* files.map(_.path) // [/mnt/my-folder/myFile, /mnt/my-folder/myDir/]
* files.map(_.isDir) // [false, true]
* files.map(_.isFile) // [true, false]
* files.map(_.modificationTime) // [1615937446000, 1615937224000]
*
* @param dir FileSystem URI
* @return Ordered sequence of FileInfos containing the name, size and modification time
* of each file.
*/
ls(dir: java.lang.String): scala.collection.Seq


https://docs.databricks.com/aws/en/files/
Databricks has multiple utilities and APIs for interacting with files in the following locations:


Drag and drop file in workspace or upload to a Volume
and then copy the file path

Pandas
	df = pd.read_csv('/Workspace/Users/<user-folder>/data.csv')
Apache Spark
	spark.read.format("json").load("file:/Workspace/Users/<user-folder>/data.json").show()

Spark SQL and Databricks SQL
	SELECT * FROM json.`file:/Workspace/Users/<user-folder>/file.json`;
Databricks file system utilities
	dbutils.fs.ls("file:/Workspace/Users/<user-folder>/")
    %fs ls file:/Workspace/Users/<user-folder>/

For Volume
Pandas
	df = pd.read_csv('/Volumes/my_catalog/my_schema/my_volume/data.csv')
Apache Spark
	spark.read.format("json").load("/Volumes/my_catalog/my_schema/my_volume/data.json").show()

Spark SQL and Databricks SQL
	SELECT * FROM csv.`/Volumes/my_catalog/my_schema/my_volume/data.csv`;
    LIST '/Volumes/my_catalog/my_schema/my_volume/';

Databricks file system utilities
	dbutils.fs.ls("/Volumes/my_catalog/my_schema/my_volume/")
    %fs ls /Volumes/my_catalog/my_schema/my_volume/


Drag and drop iris.csv to Workspace
#below works
df1 = spark.read.format("csv").option("header", "true")\
      .load("file:/Workspace/Users/<user-folder>/iris.csv")

##Volumes limitations

Volumes have the following limitations:
    Direct-append or non-sequential (random) writes,
    such as writing Zip and Excel files are not supported.

    For direct-append or random-write workloads, perform the operations on a local disk first
    and then copy the results to Unity Catalog volumes. For example:


    # python
    import xlsxwriter
    from shutil import copyfile

    workbook = xlsxwriter.Workbook('/local_disk0/tmp/excel.xlsx')
    worksheet = workbook.add_worksheet()
    worksheet.write(0, 0, "Key")
    worksheet.write(0, 1, "Value")
    workbook.close()

    copyfile('/local_disk0/tmp/excel.xlsx', '/Volumes/my_catalog/my_schema/my_volume/excel.xlsx')


    Sparse files are not supported. To copy sparse files, use cp --sparse=never:
    Bash
    $ cp sparse.file /Volumes/my_catalog/my_schema/my_volume/sparse.file
    error writing '/dbfs/sparse.file': Operation not supported
    $ cp --sparse=never sparse.file /Volumes/my_catalog/my_schema/my_volume/sparse.file

##Where do deleted workspace files go?
Deleting a workspace file sends it to the trash.
You can recover or permanently delete files from the trash using the UI.

##Work with files in cloud object storage
Databricks recommends using Unity Catalog volumes to configure secure access to files
in cloud object storage. You must configure permissions if you choose
to access data directly in cloud object storage using URIs.


Apache Spark
	spark.read.format("json").load("s3://<bucket>/path/file.json").show()

Spark SQL and Databricks SQL
	SELECT * FROM csv.`s3://<bucket>/path/file.json`; LIST 's3://<bucket>/path';

Databricks file system utilities
	dbutils.fs.ls("s3://<bucket>/path/") %fs ls s3://<bucket>/path/

Databricks CLI
	Not supported

Databricks REST API
	Not supported

Bash shell commands
	Not supported

Library installs
	%pip install s3://bucket-name/path/to/library.whl

Pandas
	Not supported

OSS Python
	Not supported

##Move data from ephemeral storage to volumes
Python
dbutils.fs.cp ("file:/<path>", "/Volumes/<catalog>/<schema>/<volume>/<path>")

Bash
%sh cp /<path> /Volumes/<catalog>/<schema>/<volume>/<path>

Bash
%fs cp file:/<path> /Volumes/<catalog>/<schema>/<volume>/<path>


##Tutorial: Import and visualize CSV data from a notebook
Your workspace must have Unity Catalog enabled.
You must have the WRITE VOLUME privilege on a volume,
    the USE SCHEMA privilege on the parent schema,
    and the USE CATALOG privilege on the parent catalog.
You must have permission to use an existing compute resource or create a new compute resource

Create Catalog
CREATE CATALOG IF NOT EXISTS mycatalog
  MANAGED LOCATION 's3://depts/finance';

GRANT SELECT ON mycatalog TO `finance-team`;

Note mycatalog automatically has default schema
Check details  in Catalog explorer


In the Catalog pane on the left, click the catalog you want to create the schema in.
In the detail pane, click Create schema.
OR

CREATE { DATABASE | SCHEMA } [ IF NOT EXISTS ] <catalog-name>.<schema-name>
    [ MANAGED LOCATION '<location-path>' | LOCATION '<location-path>']
    [ COMMENT <comment> ]
    [ WITH DBPROPERTIES ( <property-key = property_value [ , ... ]> ) ];

USE CATALOG mycatalog;
CREATE SCHEMA IF NOT EXISTS myschema;
USE SCHEMA myschema;

In your Databricks workspace, click Data icon. Catalog.
Search or browse for the schema that you want to add the volume to and select it.
Click the Create Volume button. (You must have sufficient privileges.)

Enter a name for the volume.
OR
CREATE VOLUME <catalog>.<schema>.<volume-name>;

CREATE VOLUME IF NOT EXISTS mycatalog.myschema.myvolume;

Resource
	Permissions required

Schema
	USE SCHEMA, CREATE VOLUME

Catalog
	USE CATALOG

To interact with files in a volume, do the following:
    In your Databricks workspace, click Data icon. Catalog.
    Search or browse for the volume that you want to work with and select it.

Commands that do not specify the catalog
(for example GRANT CREATE TABLE ON SCHEMA myschema TO mygroup) are evaluated
for the catalog in the following order:
    Is the catalog set for the session using a USE CATALOG statement or a JDBC setting?
    Is the Spark configuration spark.databricks.sql.initial.catalog.namespace set on the cluster?
    Is there a workspace default catalog set for the cluster?
        For some workspaces that were enabled for Unity Catalog automatically,
        the workspace catalog was set as the default catalog.
        For all other workspaces, the hive_metastore catalog was set as the default catalog.

        To Check
        SELECT current_catalog();

        To configure a different default catalog for a workspace:
            Log in to your workspace as a workspace admin.
            Click your username in the top bar of the workspace and select Admin Settings from the dropdown.
            Click the Advanced tab.
            On the Default catalog for the workspace row, enter the catalog name and click Save.


#code

catalog = "mycatalog"
schema = "myschema"
volume = "myvolume"
download_url = "https://health.data.ny.gov/api/views/jxy9-yhdk/rows.csv"
file_name = "baby_names.csv"
table_name = "baby_names"
path_volume = "/Volumes/" + catalog + "/" + schema + "/" + volume
path_table = catalog + "." + schema
print(path_table) # Show the complete path
print(path_volume) # Show the complete path

Import CSV file
dbutils.fs.cp(f"{download_url}", f"{path_volume}" + "/" + f"{file_name}")

Press Shift+Enter to run the cell and then move to the next cell.

dbutils.fs.ls(f"{path_volume}")
Out[10]: [FileInfo(path='dbfs:/FileStore/data/rows.csv', name='rows.csv', size=2258987, modificationTime=1743388758000)]

dbutils.fs.head(f"{path_volume}/{file_name}", 25)


dbutils.fs.ls("/")
Out[2]: [FileInfo(path='dbfs:/FileStore/', name='FileStore/', size=0, modificationTime=0),
 FileInfo(path='dbfs:/databricks-datasets/', name='databricks-datasets/', size=0, modificationTime=0),
 FileInfo(path='dbfs:/databricks-results/', name='databricks-results/', size=0, modificationTime=0)]

%sh ls /
BUILD
Volumes
Workspace
bin
boot
databricks
dbfs
dev
etc
home
lib
lib32
lib64
libx32
local_disk0
media
mnt
opt
proc
root
run
sbin
srv
sys
tmp
usr
var

%sh ls /dbfs
Empty at root

%sh ls /mnt
Empty as nothing is mounted




df_csv = spark.read.csv(f"{path_volume}/{file_name}",
  header=True,
  inferSchema=True,
  sep=",")
display(df_csv)

Review the results in the table.

Next to the Table tab, click + and then click Visualization.

In the visualization editor, click Visualization Type, and verify that Word cloud is selected.

In the Words column, verify that First Name is selected.

In Frequencies limit, click 35.
Click Save.
Note
Word Cloud is a visual representation of word frequency and value.
Use it to get instant insight into the most important terms in your data
and the importance of each tag is shown with font size or color

##more code
df_csv = df_csv.withColumnRenamed("First Name", "First_Name")
df.printSchema()

df_csv.write.mode("overwrite").saveAsTable(f"{path_table}" + "." + f"{table_name}")

To verify that the table was saved, click Catalog in the left sidebar
to open the Catalog Explorer UI. Open your catalog and then your schema
to verify that the table appears.

Click your table to view the table schema on the Overview tab.

Click Sample Data to view 100 rows of data from the table.


# The display() method is specific to Databricks notebooks and provides a richer visualization.
# df1.show() The show() method is a part of the Apache Spark DataFrame API and provides basic visualization.
#Use spark 3.3.2
Create a DataFrame
data = [[2021, "test", "Albany", "M", 42]]
columns = ["Year", "First_Name", "County", "Sex", "Count"]

Create Dataframe of data by providing schema
df1 = spark.createDataFrame(data, schema="Year int, First_Name STRING, County STRING, Sex STRING, Count int")
display(df1)

Combine DataFrames
df = df1.union(df_csv)
display(df)

Filter rows in a DataFrame
display(df.filter(df["Count"] > 50))
display(df.where(df["Count"] > 50))

Select columns from a DataFrame and order by frequency
from pyspark.sql.functions import desc
display(df.select("First_Name", "Count").orderBy(desc("Count")))

Create a subset DataFrame
subsetDF = df.filter((df["Year"] == 2009) & (df["Count"] > 100) & (df["Sex"] == "F")).select("First_Name", "County", "Count").orderBy(desc("Count"))
display(subsetDF)

Save the DataFrame to a table
df.write.mode("overwrite").saveAsTable(f"{path_table}.{table_name}")

Save the DataFrame to JSON files
df.write.format("json").mode("overwrite").save(f"{path_volume}/json_data")

Read the DataFrame from a JSON file
display(spark.read.format("json").json(f"{path_volume}/json_data"))

Specify a column as a SQL query
display(df.selectExpr("Count", "upper(County) as big_name"))

Use expr() to use SQL syntax for a column

from pyspark.sql.functions import expr
display(df.select("Count", expr("lower(County) as little_name")))

Run an arbitrary SQL query using spark.sql() function
display(spark.sql(f"SELECT * FROM {path_table}.{table_name}"))

Pandas on Spark
https://spark.apache.org/docs/latest/api/python/getting_started/quickstart_ps.html
import pandas as pd
import numpy as np
import pyspark.pandas as ps

#Good to enable pyArrow
spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", True)

#spark -> sparkPandasAPI
sparkDataFrame = df
#pandas_api(index_col)
psdf = sparkDataFrame.pandas_api() #allmost all pandas API
psdf.columns
psdf.index
psdf.dtypes
psdf.describe()
psdf.to_numpy()

#pandas     -> sparkPandasAPI
pdf = pd.read_csv(path)
psdf = ps.from_pandas(pdf)

#read directly in sparkPandasAPI
psdf = ps.read_csv(path)

#sparkDF -> pandas - Risky
sdf.toPandas()

#Drop the catalog
RESTRICT
If specified, restricts dropping a non-empty catalog.
Enabled by default.

CASCADE
If specified, drops all of the associated databases (schemas) and the objects within them,
recursively. In Unity Catalog, dropping a catalog using CASCADE soft-deletes tables:
managed table files will be cleaned up within 7 to 30 days,
but external files are not deleted.

DESCRIBE CATALOG <catalog-name>;
DESCRIBE CATALOG EXTENDED mycatalog;
DROP CATALOG IF EXISTS mycatalog CASCADE;

If you use DROP CATALOG without the CASCADE option,
you must delete all schemas in the catalog except information_schema
before you can delete the catalog.
This includes the auto-created default schema.
###Delta Lake Table  --WORKSHOP --IMP (pydeltatable) (sqldeltatable)

To get the People 10 M dataset for this tutorial, do the following:

    Go to the People 10 M page in Kaggle.
    https://www.kaggle.com/datasets/asthamular/people-10-m

    Click Download to download a file named export.csv

To upload the export.csv file into the volume(create the volume at first), do the following:
    On the sidebar, click Catalog.

    In Catalog Explorer, browse to and open the volume
    where you want to upload the export.csv file.

    Click Upload to this volume.

    Drag and drop, or browse to and select,
    the export.csv file on your local machine.

    Click Upload.


API
https://docs.delta.io/latest/delta-apidoc.html#delta-spark

##Create a table

All tables created on Azure Databricks use Delta Lake by default.


from pyspark.sql.types import StructType, StructField, IntegerType, StringType, TimestampType

schema = StructType([
  StructField("id", IntegerType(), True),
  StructField("firstName", StringType(), True),
  StructField("middleName", StringType(), True),
  StructField("lastName", StringType(), True),
  StructField("gender", StringType(), True),
  StructField("birthDate", TimestampType(), True),
  StructField("ssn", StringType(), True),
  StructField("salary", IntegerType(), True)
])

df = spark.read.format("csv").option("header", True).schema(schema).load("/Volumes/workspace/default/my-volume/export.csv")


# Create the table if it does not exist. Otherwise, replace the existing table.
df.writeTo("workspace.default.people_10m").createOrReplace()
#DBC
df.writeTo("hive_metastore.my_schema.people_10m").createOrReplace()

Use DROP TABLE table_name for permanent delete without any re-creation
Alsways use create or replace for atomic data overwrite with intact history

# If you know the table does not already exist, you can call this instead:
# df.saveAsTable("workspace.default.people_10m")
#DBC
#df.saveAsTable("hive_metastore.my_schema.people_10m")

NOTE: spark sql parameters -protect against SQL injection attacks
    query = """SELECT id1, SUM(v1) AS v1
    FROM h20_1e9
    WHERE id1 = {id1_val}
    GROUP BY id1"""

    spark.sql(query, id1_val="id016").show()
    OR
    query = "SELECT item, sum(amount) from some_purchases group by item having item = :item"
    spark.sql(query, args={"item": "socks"}).show()



    #SQL PArameters
    https://docs.databricks.com/aws/en/sql/user/queries/query-parameters
    Use  :parameter_name.

    When you include a named parameter marker in a SQL query, a widget appears in the UI
    Click the Gear icon gear icon near the parameter widget.

    You can use the widget to edit the parameter type and name.
    originally Databricks SQL used mustache syntax(now also supported)
    for example
    SELECT * FROM {{catalog}}.{{schema}}.{{table}}
    is now
    SELECT * FROM IDENTIFIER(:catalog || '.' || :schema || '.' || :table)

    for example
    '({{area_code}}) {{phone_number}}'
    is now
    format_string("(%d)%d", :area_code, :phone_number)

    for example
    SELECT INTERVAL {{p}} MINUTE
    is now
    SELECT CAST(format_string("INTERVAL '%s' MINUTE", :param) AS INTERVAL MINUTE)

    OR create widget
    https://docs.databricks.com/aws/en/notebooks/widgets
    dbutils.widgets.dropdown("state", "CA", ["CA", "IL", "MI", "NY", "OR", "VA"])
    dbutils.widgets.get("state")
    #types
    dbutils.widgets.dropdown("database", "default", [database[0] for database in spark.catalog.listDatabases()])
    dbutils.widgets.text("table", "")
    dbutils.widgets.text("filter_value", "")

    in SQL
    CREATE WIDGET DROPDOWN state DEFAULT "CA" CHOICES SELECT * FROM (VALUES ("CA"), ("IL"), ("MI"), ("NY"), ("OR"), ("VA"))
    SELECT :state
    SHOW TABLES IN IDENTIFIER(:database)
    SELECT * FROM IDENTIFIER(:database || '.' || :table) WHERE col == :filter_value LIMIT 100

    OR DO like - Runtime 15.1 and below(supported now as well)
    %python spark.conf.set('personal.foo','bar')
    %sql
    select * from table where column = '${personal.foo}';
    in SQL-  To escape the $ character in a SQL string literal, use \$
    CREATE WIDGET TEXT database DEFAULT ""
    CREATE WIDGET TEXT table DEFAULT ""
    CREATE WIDGET TEXT filter_value DEFAULT "100"
    SELECT *
    FROM ${database}.${table}
    WHERE col == ${filter_value}
    LIMIT 100
    if you run a notebook that contains widgets,
    the specified notebook is run with the widget’s default values.

    If the notebook is attached to a cluster (not a SQL warehouse),
    you can also pass values to widgets. For example:

%run /path/to/notebook $X="10" $Y="1"


#OUR code
CREATE OR REPLACE TABLE main.default.people_10m (
  id INT,
  firstName STRING,
  middleName STRING,
  lastName STRING,
  gender STRING,
  birthDate TIMESTAMP,
  ssn STRING,
  salary INT
);

COPY INTO main.default.people_10m
FROM '/Volumes/main/default/my-volume/export.csv'
FILEFORMAT = CSV
FORMAT_OPTIONS ( 'header' = 'true', 'inferSchema' = 'true' );



The preceding operations create a new managed table.

#Managed vs external with overwrite mode for data
#and overwrite schema for schema overwrite as well
#Replacewhere for selective over write
dataframe.write \
  .mode("overwrite") \
  .option("overwriteSchema", "true") \
  .option("replaceWhere", "start_date >= '2017-01-01' AND end_date <= '2017-01-31'")
  .saveAsTable("<your-table>") # Managed table

dataframe.write \
  .mode("overwrite") \
  .option("overwriteSchema", "true") \
  .option("path", "<your-table-path>") \ <- path makes external table
  .saveAsTable("<your-table>") # External table

REPLACE TABLE <your-table> AS SELECT ... -- Managed table
REPLACE TABLE <your-table> LOCATION "<your-table-path>" AS SELECT ... -- External table



you can use CREATE TABLE LIKE to create a new empty Delta
table that duplicates the schema and table properties for a source Delta table.

CREATE TABLE main.default.people_10m_prod LIKE main.default.people_10m

CTAS (CREATE TABLE AS SELECT):
Schema: CREATE TABLE -> Explicit schema definition. CTAS -> Schema is inferred from the query.
Data: CREATE TABLE -> Starts empty. CTAS -> Populates immediately with query results.
overwrites the underlying data source with the data of the input query

CREATE TABLE people_10m_copy AS SELECT * FROM people_10m;

To create an empty table, you can also use the DeltaTableBuilder API in Delta Lake for Python and
Scala. Compared to equivalent DataFrameWriter APIs, these APIs make it easier to specify additional
information like column comments, table properties, and generated columns.

DeltaTable.createIfNotExists(spark)
  .tableName("main.default.people_10m")
  .addColumn("id", "INT")
  .addColumn("firstName", "STRING")
  .addColumn("middleName", "STRING")
  .addColumn("lastName", "STRING", comment = "surname")
  .addColumn("gender", "STRING")
  .addColumn("birthDate", "TIMESTAMP")
  .addColumn("ssn", "STRING")
  .addColumn("salary", "INT")
  .execute()





##Upsert to a table
To merge a set of updates and insertions into an existing Delta table, you use the DeltaTable.merge method for Python and Scala, and the MERGE INTO statement for SQL. For example, the following example
takes data from the source table and merges it into the target Delta table. When there is a matching
row in both tables, Delta Lake updates the data column using the given expression. When there is no
matching row, Delta Lake adds a new row. This operation is known as an upsert.
Python


from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType
from datetime import date

schema = StructType([
  StructField("id", IntegerType(), True),
  StructField("firstName", StringType(), True),
  StructField("middleName", StringType(), True),
  StructField("lastName", StringType(), True),
  StructField("gender", StringType(), True),
  StructField("birthDate", DateType(), True),
  StructField("ssn", StringType(), True),
  StructField("salary", IntegerType(), True)
])

data = [
  (9999998, 'Billy', 'Tommie', 'Luppitt', 'M', date.fromisoformat('1992-09-17'), '953-38-9452', 55250),
  (9999999, 'Elias', 'Cyril', 'Leadbetter', 'M', date.fromisoformat('1984-05-22'), '906-51-2137', 48500),
  (10000000, 'Joshua', 'Chas', 'Broggio', 'M', date.fromisoformat('1968-07-22'), '988-61-6247', 90000),
  (20000001, 'John', '', 'Doe', 'M', date.fromisoformat('1978-01-14'), '345-67-8901', 55500),
  (20000002, 'Mary', '', 'Smith', 'F', date.fromisoformat('1982-10-29'), '456-78-9012', 98250),
  (20000003, 'Jane', '', 'Doe', 'F', date.fromisoformat('1981-06-25'), '567-89-0123', 89900)
]

people_10m_updates = spark.createDataFrame(data, schema)
people_10m_updates.createTempView("people_10m_updates")

# ...

from delta.tables import DeltaTable

deltaTable = DeltaTable.forName(spark, 'main.default.people_10m')

(deltaTable.alias("people_10m")
  .merge(
    people_10m_updates.alias("people_10m_updates"),
    "people_10m.id = people_10m_updates.id")
  .whenMatchedUpdateAll()
  .whenNotMatchedInsertAll()
  .execute()
)

SQL

CREATE OR REPLACE TEMP VIEW people_10m_updates (
  id, firstName, middleName, lastName, gender, birthDate, ssn, salary
) AS VALUES
  (9999998, 'Billy', 'Tommie', 'Luppitt', 'M', '1992-09-17T04:00:00.000+0000', '953-38-9452', 55250),
  (9999999, 'Elias', 'Cyril', 'Leadbetter', 'M', '1984-05-22T04:00:00.000+0000', '906-51-2137', 48500),
  (10000000, 'Joshua', 'Chas', 'Broggio', 'M', '1968-07-22T04:00:00.000+0000', '988-61-6247', 90000),
  (20000001, 'John', '', 'Doe', 'M', '1978-01-14T04:00:00.000+000', '345-67-8901', 55500),
  (20000002, 'Mary', '', 'Smith', 'F', '1982-10-29T01:00:00.000+000', '456-78-9012', 98250),
  (20000003, 'Jane', '', 'Doe', 'F', '1981-06-25T04:00:00.000+000', '567-89-0123', 89900);

MERGE INTO people_10m
USING people_10m_updates
ON people_10m.id = people_10m_updates.id
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;

In SQL, if you specify *, this updates or inserts all columns in the target table, assuming that the
source table has the same columns as the target table. If the target table doesn’t have the same
columns, the query throws an analysis error.

You must specify a value for every column in your table when you perform an insert operation (for
example, when there is no matching row in the existing dataset). However, you do not need to update
all values.

To see the results, query the table.

Python

df = spark.read.table("main.default.people_10m")
df_filtered = df.filter(df["id"] >= 9999998)
display(df_filtered)

SQL

SELECT * FROM main.default.people_10m WHERE id >= 9999998

Read a table

You access data in Delta tables by the table name or the table path,
as shown in the following examples:
Python
people_df = spark.read.table("main.default.people_10m")
display(people_df)

SQL

SELECT * FROM main.default.people_10m;



##Write to a table
To atomically add new data to an existing Delta table,
use the append mode as shown in the following examples:

df.write.mode("append").saveAsTable("main.default.people_10m")

SQL

INSERT INTO main.default.people_10m SELECT * FROM main.default.more_people

To replace all the data in a table, use the overwrite mode as in the following examples:
Python

df.write.mode("overwrite").saveAsTable("main.default.people_10m")

SQL

INSERT OVERWRITE TABLE main.default.people_10m SELECT * FROM main.default.more_people

Many Inserts are possible
https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-syntax-dml-insert-into

##Update a table
You can update data that matches a predicate in a Delta table. For example, in the example people_10m
table, to change an abbreviation in the gender column from M or F to Male or Female, you can run the following:

Python

from delta.tables import *
from pyspark.sql.functions import *

deltaTable = DeltaTable.forName(spark, "main.default.people_10m")

# Declare the predicate by using a SQL-formatted string.
deltaTable.update(
  condition = "gender = 'F'",
  set = { "gender": "'Female'" }
)

# Declare the predicate by using Spark SQL functions.
deltaTable.update(
  condition = col('gender') == 'M',
  set = { 'gender': lit('Male') }
)

SQL

UPDATE main.default.people_10m SET gender = 'Female' WHERE gender = 'F';
UPDATE main.default.people_10m SET gender = 'Male' WHERE gender = 'M';



Delete from a table
You can remove data that matches a predicate from a Delta table. For instance, in the example
people_10m table, to delete all rows corresponding to people with a value in the birthDate column from
before 1955, you can run the following:

Python

from delta.tables import *
from pyspark.sql.functions import *

deltaTable = DeltaTable.forName(spark, "main.default.people_10m")

# Declare the predicate by using a SQL-formatted string.
deltaTable.delete("birthDate < '1955-01-01'")

# Declare the predicate by using Spark SQL functions.
deltaTable.delete(col('birthDate') < '1960-01-01')

SQL

DELETE FROM main.default.people_10m WHERE birthDate < '1955-01-01'

Important

Deletion removes the data from the latest version of the Delta table but does not remove it from the
physical storage until the old versions are explicitly vacuumed.

##Display table history
To view the history of a table, you use the DeltaTable.history method for Python and Scala, and the DESCRIBE HISTORY statement in SQL, which provides provenance information, including the table version,
operation, user, and so on, for each write to a table.

Python

from delta.tables import *

deltaTable = DeltaTable.forName(spark, "main.default.people_10m")
display(deltaTable.history())

SQL

DESCRIBE HISTORY main.default.people_10m


##Query an earlier version of the table (time travel)

Delta Lake time travel allows you to query an older snapshot of a Delta table.

To query an older version of a table, specify the table’s version or timestamp.
For example, to query version 0 or timestamp 2024-05-15T22:43:15.000+00:00Z from the preceding history, use the following:

Python

from delta.tables import *

deltaTable = DeltaTable.forName(spark, "main.default.people_10m")
deltaHistory = deltaTable.history()

display(deltaHistory.where("version == 0"))
# Or:
display(deltaHistory.where("timestamp == '2024-05-15T22:43:15.000+00:00'"))

SQL

SELECT * FROM main.default.people_10m VERSION AS OF 0
-- Or:
SELECT * FROM main.default.people_10m TIMESTAMP AS OF '2019-01-29 00:37:58'

For timestamps, only date or timestamp strings are accepted, for example, "2024-05-15T22:43:15.000+00:00" or "2024-05-15 22:43:15".

DataFrameReader options allow you to create a DataFrame from a Delta table
that is fixed to a specific version or timestamp of the table, for example:

Python

df = spark.read.option('versionAsOf', 0).table("main.default.people_10m")
# Or:
df = spark.read.option('timestampAsOf', '2024-05-15T22:43:15.000+00:00').table("main.default.people_10m")

display(df)

SQL

SELECT * FROM main.default.people_10m VERSION AS OF 0
-- Or:
SELECT * FROM main.default.people_10m TIMESTAMP AS OF '2024-05-15T22:43:15.000+00:00'


##Optimize a table
After you have performed multiple changes to a table, you might have a lot of small files. To improve
the speed of read queries, you can use the optimize operation to collapse small files into larger ones:

Python
from delta.tables import *

deltaTable = DeltaTable.forName(spark, "main.default.people_10m")
deltaTable.optimize().executeCompaction()

SQL

OPTIMIZE main.default.people_10m


##Z-order by columns
To improve read performance further, you can collocate related information in the same set of files by
z-ordering. Delta Lake data-skipping algorithms use this collocation to dramatically reduce the amount
of data that needs to be read. To z-order data, you specify the columns to order on in the z-order by
operation. For example, to collocate by gender, run:

Python

from delta.tables import *

deltaTable = DeltaTable.forName(spark, "main.default.people_10m")
deltaTable.optimize().executeZOrderBy("gender")

SQL

OPTIMIZE main.default.people_10m
ZORDER BY (gender)


##Clean up snapshots with VACUUM
Delta Lake provides snapshot isolation for reads, which means that it is safe to run an optimize
operation even while other users or jobs are querying the table. Eventually however, you should clean
up old snapshots. You can do this by running the vacuum operation:

Python

from delta.tables import *

deltaTable = DeltaTable.forName(spark, "main.default.people_10m")
deltaTable.vacuum()

SQL

VACUUM main.default.people_10m

For details on using the vacuum operation effectively, see Remove unused data files with vacuum.
https://learn.microsoft.com/en-us/azure/databricks/delta/vacuum

###Demo of Delta Lake change data feed  --WORKSHOP --IMP  (cdf)
Create a silver table that tracks absolute number vaccinations and available doses by country

countries = [("USA", 10000, 20000), ("India", 1000, 1500), ("UK", 7000, 10000), ("Canada", 500, 700) ]

columns = ["Country","NumVaccinated","AvailableDoses"]

spark.createDataFrame(data=countries, schema = columns).write.format("delta").mode("overwrite").saveAsTable("silverTable")

%sql
SELECT * FROM silverTable


import pyspark.sql.functions as F
spark.read.format("delta").table("silverTable")\
   .withColumn("VaccinationRate", F.col("NumVaccinated") / F.col("AvailableDoses")) \
  .drop("NumVaccinated").drop("AvailableDoses") \
  .write.format("delta").mode("overwrite").saveAsTable("goldTable")

Generate gold table showing vaccination rate by country

%sql
SELECT * FROM goldTable


Enable change data feed on silver table

%sql
ALTER TABLE silverTable SET TBLPROPERTIES (delta.enableChangeDataFeed = true)

OK
Update silver table daily

# Insert new records
new_countries = [("Australia", 100, 3000)]
spark.createDataFrame(data=new_countries, schema = columns).write.format("delta").mode("append").saveAsTable("silverTable")

%sql
-- update a record
UPDATE silverTable SET NumVaccinated = '11000' WHERE Country = 'USA'


%sql
-- delete a record
DELETE from silverTable WHERE Country = 'UK'


%sql
SELECT * FROM silverTable


Explore the change data in SQL and PySpark
Starting version 2 as first version ie 1's data are already in gold table
annd version 0 is create table

%sql
-- view the changes
SELECT * FROM table_changes('silverTable', 2, 5) order by _commit_timestamp


changes_df = spark.read.format("delta").option("readChangeData", True).option("startingVersion", 2).table('silverTable')
display(changes_df)


olumn name 	        Type 	    Values
_change_type 	    String 	    insert, update_preimage , update_postimage, delete (1)
_commit_version 	Long 	    The Delta log or table version containing the change.
_commit_timestamp 	Timestamp 	The timestamp associated when the commit was created.
(1) preimage is the value before the update, postimage is the value after the update.

#Reference
start: A BIGINT or TIMESTAMP literal,
representing the first version or timestamp of change to return.
end: An optional BIGINT or TIMESTAMP literal,
representing the last version or timestamp of change to return.
If not specified all changes from start up to the current change are returned.

Propagate changes from silver to gold table
%sql
-- Collect only the latest version for each country
CREATE OR REPLACE TEMPORARY VIEW silverTable_latest_version as
    SELECT *
    FROM
         (SELECT *, rank() over (partition by Country order by _commit_version desc) as rank
          FROM table_changes('silverTable', 2, 5)
          WHERE _change_type !='update_preimage')
    WHERE rank=1
-- take only one record per Country with largest  _commit_version

%sql
-- Merge the changes to gold
MERGE INTO goldTable t USING silverTable_latest_version s
    ON s.Country = t.Country
    WHEN MATCHED AND s._change_type='update_postimage' THEN
        UPDATE SET VaccinationRate = s.NumVaccinated/s.AvailableDoses
    WHEN NOT MATCHED THEN
        INSERT (Country, VaccinationRate)
            VALUES (s.Country, s.NumVaccinated/s.AvailableDoses)


%sql
SELECT * FROM goldTable


%sql
DROP TABLE silverTable;
DROP TABLE goldTable;




-- Create a Delta table with Change Data Feed;
#0 version
> CREATE TABLE myschema.t(c1 INT, c2 STRING) TBLPROPERTIES(delta.enableChangeDataFeed=true);

-- Modify the table
#1 version
> INSERT INTO myschema.t VALUES (1, 'Hello'), (2, 'World');
> INSERT INTO myschema.t VALUES (3, '!');
> UPDATE myschema.t SET c2 = upper(c2) WHERE c1 < 3;
> DELETE FROM myschema.t WHERE c1 = 3;

-- Show the history of table change events
> DESCRIBE HISTORY myschema.t;
 version timestamp                    userId           userName      operation    operationParameters                                            ...
       4 2022-09-01T18:32:35.000+0000 6167625779053302 alf@melmak.et DELETE       {"predicate":"[\"(spark_catalog.myschema.t.c1 = 3)\"]"}
       3 2022-09-01T18:32:32.000+0000 6167625779053302 alf@melmak.et UPDATE       {"predicate":"(c1#3195878 < 3)"}
       2 2022-09-01T18:32:28.000+0000 6167625779053302 alf@melmak.et WRITE        {"mode":"Append","partitionBy":"[]"}
       1 2022-09-01T18:32:26.000+0000 6167625779053302 alf@melmak.et WRITE        {"mode":"Append","partitionBy":"[]"}
       0 2022-09-01T18:32:23.000+0000 6167625779053302 alf@melmak.et CREATE TABLE {"isManaged":"true","description":null,"partitionBy":"[]","properties":"{\"delta.enableChangeDataFeed\":\"true\"}"}

-- Show the change table feed using a the commit timestamp retrieved from the history.
> SELECT * FROM table_changes('`myschema`.`t`', 2); -- 2 to latest version
 c1 c2     _change_type    _commit_version _commit_timestamp
  3 !      insert                        2 2022-09-01T18:32:28.000+0000
  2 WORLD  update_postimage              3 2022-09-01T18:32:32.000+0000
  2 World  update_preimage               3 2022-09-01T18:32:32.000+0000
  1 Hello  update_preimage               3 2022-09-01T18:32:32.000+0000
  1 HELLO  update_postimage              3 2022-09-01T18:32:32.000+0000
  3 !      delete                        4 2022-09-01T18:32:35.000+0000

-- Show the ame change table feed using a point in time.
> SELECT * FROM table_changes('`myschema`.`t`', '2022-09-01T18:32:27.000+0000') ORDER BY _commit_version;
 c1 c2     _change_type    _commit_version _commit_timestamp
  3 !      insert                        2 2022-09-01T18:32:28.000+0000
  2 WORLD  update_postimage              3 2022-09-01T18:32:32.000+0000
  2 World  update_preimage               3 2022-09-01T18:32:32.000+0000
  1 Hello  update_preimage               3 2022-09-01T18:32:32.000+0000
  1 HELLO  update_postimage              3 2022-09-01T18:32:32.000+0000
  3 !      delete                        4 2022-09-01T18:32:35.000+0000


###Complex Examples --WORKSHOP --IMP (adv-etl)
#column is ArrayType and MapType and StructType
SomeClass = Row('a', 'b')

raw = [ ("name", [10,20], {"age" : 30}, SomeClass(1, 2))]
data = sc.parallelize(raw)


df = data.toDF()
#DataFrame[_1: string, _2: array<bigint>, _3: map<string,bigint>, _4: struct<a:bigint,b:bigint>]

df.select(F.col("_1"), F.col("_2").getItem(0).alias("first"),
        F.col("_3").getItem("age"),F.col("_4").getField("a"))
#DataFrame[_1: string, first: bigint, _3[age]: bigint, _4.a: bigint]
+----+-----+-------+----+
|  _1|_2[0]|_3[age]|_4.a|
+----+-----+-------+----+
|name|   10|     30|   1|
+----+-----+-------+----+

#alternate syntax
df.select("*", F.col("_1"), F.col("_2")[0].alias("first"), F.col("_3")["age"],F.col("_4.a"))
+----+--------+-----------+------+----+-----+-------+---+
|  _1|      _2|         _3|    _4|  _1|first|_3[age]|  a|
+----+--------+-----------+------+----+-----+-------+---+
|name|[10, 20]|{age -> 30}|{1, 2}|name|   10|     30|  1|
+----+--------+-----------+------+----+-----+-------+---+
Use .toDF(col1, ...) to rename the columns

#More Example
rdd = sc.parallelize([
  ("i like blue and red",),
  ("you pink and blue",),
])


df = rdd.toDF(["word1"])

import pyspark.sql.functions as F

actualDF = df.withColumn(
  "colors",
  F.array(
    F.when(F.col("word1").contains("blue"), "blue"),
    F.when(F.col("word1").contains("red"), "red"),
    F.when(F.col("word1").contains("pink"), "pink"),
    F.when(F.col("word1").contains("cyan"), "cyan")
  )
)
#The array() function unfortunately includes null values in the colors column.
actualDF.show(truncate = False)
+-------------------+------------------------+
|word1              |colors                  |
+-------------------+------------------------+
|i like blue and red|[blue, red, null, null] |
|you pink and blue  |[blue, null, pink, null]|
+-------------------+------------------------+

#OR
colors = ["blue", "red", "pink", "cyan"]

actualDF = df.withColumn(
  "colors",
  F.array(
    *map(lambda c: F.when(F.col("word1").contains(c), c), colors)
  )
)

actualDF.show(truncate=False)
+-------------------+------------------------+
|word1              |colors                  |
+-------------------+------------------------+
|i like blue and red|[blue, red, null, null] |
|you pink and blue  |[blue, null, pink, null]|
+-------------------+------------------------+

#More examples - Eliminating null from the arrays

actualDF = df.withColumn(
  "colors",
  F.split(
    F.concat_ws(
      ",",
      F.when(F.col("word1").contains("blue"), "blue"),
      F.when(F.col("word1").contains("red"), "red"),
      F.when(F.col("word1").contains("pink"), "pink"),
      F.when(F.col("word1").contains("cyan"), "cyan")
    ),
    ","
  )
)

actualDF.show(truncate=False)
+-------------------+------------+
|word1              |colors      |
+-------------------+------------+
|i like blue and red|[blue, red] |
|you pink and blue  |[blue, pink]|
+-------------------+------------+


When
df = spark.range(3)

df.select(F.when(df['id'] == 2, 3).otherwise(4).alias("age")).show()
+---+
|age|
+---+
|  4|
|  4|
|  3|
+---+

df.select(when(df.id == 2, df.id + 1).alias("age")).show()
+----+
| age|
+----+
|NULL|
|NULL|
|   3|
+----+


#More examples - Creating a schema with a column that uses MapType and ArrayType
from pyspark.sql.types import *
import pyspark.sql.functions as F

singersDF = spark.createDataFrame(
  sc.parallelize([
    Row("miley",{
      "good_songs" : ["party in the usa", "wrecking ball"],
      "bad_songs"  : ["younger now"]}
    ),
    Row("kesha", {
      "good_songs" : ["tik tok", "timber"],
      "bad_songs"  : ["rainbow"]}
    )
  ]), StructType([
    StructField("name", StringType(), True),
    StructField("songs", MapType(StringType(), ArrayType(StringType(), True), True), True),
  ])
)

singersDF.show()
#output
+-----+--------------------+
| name|               songs|
+-----+--------------------+
|miley|Map(good_songs ->...|
|kesha|Map(good_songs ->...|
+-----+--------------------+

singersDF.printSchema()
#output
root
 |-- name: string (nullable = true)
 |-- songs: map (nullable = true)
 |    |-- key: string
 |    |-- value: array (valueContainsNull = true)
 |    |    |-- element: string (containsNull = true)

# display the good songs for each singer.
singersDF\
  .select(
    F.col("name"),
    F.col("songs")["good_songs"].alias("fun")
  ).show()
#output
+-----+--------------------+
| name|                 fun|
+-----+--------------------+
|miley|[party in the usa...|
|kesha|   [tik tok, timber]|
+-----+--------------------+

singersDF.select("name", F.col("songs")["good_songs"][0].alias("fun1"))
singersDF.select(F.col("name"), F.col("songs")["good_songs"][0].alias("fun1"))
singersDF.select(F.column("name"), F.col("songs")["good_songs"][0].alias("fun1"))
singersDF.select(singersDF.name, F.col("songs")["good_songs"][0].alias("fun1"))
singersDF.select(singersDF["name"], F.col("songs")["good_songs"][0].alias("fun1"))

df = singersDF.select("name", F.explode(F.col("songs")["good_songs"]).alias("songs"))
df1 = df.groupBy("name").agg(F.collect_list("songs").alias("gsn"))
df1.select(F.slice(F.col("gsn"), 1, F.size("gsn")))

concat(*cols)
	Concatenates multiple input columns together into a single column.
    The function works with strings, numeric, binary and compatible array columns.,
    simply does +

concat_ws(sep, *cols)
	Concatenates multiple input string columns together
    into a single string column, using the given separator.

array(*cols)
	Creates a new array column.

array_contains(col, value)
	Collection function: returns null if the array is null,
    true if the array contains the given value, and false otherwise.

array_join(col, delimiter[, null_replacement])
	Concatenates the elements of column using the delimiter.

create_map(*cols)
	Creates a new map column.

slice(x, start, length)
    array indices start at 1, or from the end if start is negative
    with the specified length.

array_position(col, value)
	Locates the position of the first occurrence of the given value in the given array.

element_at(col, extraction)
	Returns element of array at given index in extraction if col is array.

array_append(col, value)
	returns an array of the elements in col1 along
    with the added element in col2 at the last of the array.

array_size(col)
	Returns the total number of elements in the array.

array_sort(col[, comparator])
	sorts the input array in ascending order.
    comparator, A binary (Column, Column) -> Column: ....
    -1, 0, 1

array_insert(arr, pos, value)
	adds an item into a given array at a specified array index.

array_remove(col, element)
	Remove all elements that equal to element from the given array.

array_prepend(col, value)
	Returns an array containing element as well as all elements from array.

array_distinct(col)
	removes duplicate values from the array.

array_intersect(col1, col2)
	returns an array of the elements in the intersection of col1 and col2, without duplicates.

array_union(col1, col2)
	returns an array of the elements in the union of col1 and col2, without duplicates.

array_except(col1, col2)
	returns an array of the elements in col1 but not in col2, without duplicates.

array_compact(col)
	removes null values from the array.

transform(col, f)
	Returns an array of elements after applying a transformation
    to each element in the input array.
    Unary (x: Column) -> Column: ...
    Binary (x: Column, i: Column) -> Column...,
    where the second argument is
       a 0-based index of the element.

exists(col, f)
	Returns whether a predicate holds for one or more elements in the array.

forall(col, f)
	Returns whether a predicate holds for every element in the array.

filter(col, f)
	Returns an array of elements for which a predicate holds in a given array.

    df = spark.createDataFrame(
        [(1, ["2018-09-20",  "2019-02-03", "2019-07-01", "2020-06-01"])],
        ("key", "values")
    )

    def after_second_quarter(x):
        return month(to_date(x)) > 6

    df.select(
        filter("values", after_second_quarter).alias("after_second_quarter")
    ).show(truncate=False)
    +------------------------+
    |after_second_quarter    |
    +------------------------+
    |[2018-09-20, 2019-07-01]|
    +------------------------+



aggregate(col, initialValue, merge[, finish])
	Applies a binary operator to an initial state
    and all elements in the array, and reduces this to a single state.
    mergefunction
        a binary function (acc: Column, x: Column) -> Column... returning expression of the same type as zero
    finishfunction
        an optional unary function (x: Column) -> Column: ... used to convert accumulated value.

    def merge(acc, x):
        count = acc.count + 1
        sum = acc.sum + x
        return struct(count.alias("count"), sum.alias("sum"))

    df.select(
        aggregate(
            "values",
            struct(lit(0).alias("count"), lit(0.0).alias("sum")),
            merge,
            lambda acc: acc.sum / acc.count,
        ).alias("mean")
    ).show()


zip_with(left, right, f)
	Merge two given arrays, element-wise, into a single array using a function.
    a binary function (x1: Column, x2: Column) -> Column...

    df = spark.createDataFrame([(1, ["foo", "bar"], [1, 2, 3])], ("id", "xs", "ys"))
    df.select(zip_with("xs", "ys", lambda x, y: concat_ws("_", x, y)).alias("xs_ys")).show()
    +-----------------+
    |            xs_ys|
    +-----------------+
    |[foo_1, bar_2, 3]|
    +-----------------+


transform_keys(col, f)
transform_values(col, f)
	Applies a function to every key-value pair in a map
    and returns a map with the results of those applications as the new keys for the pairs.
     (k: Column, v: Column) -> Column

	df = spark.createDataFrame([(1, {"IT": 10.0, "SALES": 2.0, "OPS": 24.0})], ("id", "data"))
    row = df.select(transform_values(
        "data", lambda k, v: when(k.isin("IT", "OPS"), v + 10.0).otherwise(v)
    ).alias("new_data")).head()
    sorted(row["new_data"].items())
    [('IT', 20.0), ('OPS', 34.0), ('SALES', 2.0)]


map_filter(col, f)
	Returns a map whose key-value pairs satisfy a predicate.
    (k: Column, v: Column) -> Column.

map_from_arrays(col1, col2)
	Creates a new map from two arrays.

map_zip_with(col1, col2, f)
	Merge two given maps, key-wise into a single map using a function.
    (k: Column, v1: Column, v2: Column) -> Column.

explode(col)
	Returns a new row for each element in the given array or map.

explode_outer(col)
	Returns a new row for each element in the given array or map.
    For null element, emits one recor with null

posexplode(col)
	Returns a new row for each element with position in the given array or map.

    from pyspark.sql import Row
    df = spark.createDataFrame([Row(a=1, intlist=[1,2,3], mapfield={"a": "b"})])

    df.select(posexplode(df.intlist)).collect()
    [Row(pos=0, col=1), Row(pos=1, col=2), Row(pos=2, col=3)]
    df.select(posexplode(df.mapfield)).show()
    +---+---+-----+
    |pos|key|value|
    +---+---+-----+
    |  0|  a|    b|
    +---+---+-----+


posexplode_outer(col)
	Returns a new row for each element with position in the given array or map.
    Unlike posexplode, if the array/map is null or empty then the row (null, null) is produced.


inline(col)
	Explodes an array of structs into a table.
    from pyspark.sql import Row

    df = spark.createDataFrame([Row(structlist=[Row(a=1, b=2), Row(a=3, b=4)])])
    df.select(inline(df.structlist)).show()
    +---+---+
    |  a|  b|
    +---+---+
    |  1|  2|
    |  3|  4|
    +---+---+


inline_outer(col)
    Unlike inline, if the array is null or empty then null is produced for each nested column.


size(col)
	Collection function: returns the length of the array or map stored in the column.

cardinality(col)
 returns the length of the array or map stored in the column.

struct(*cols)
	Creates a new struct column.

sort_array(col[, asc])
	 sorts the input array in ascending or descending order according
     to the natural ordering of the array elements.

array_max(col)
	returns the maximum value of the array.

array_min(col)
	returns the minimum value of the array.

shuffle(col)
	Generates a random permutation of the given array.

reverse(col)
	returns a reversed string or an array with reverse order of elements.

flatten(col)
	creates a single array from an array of arrays.

sequence(start, stop[, step])
	Generate a sequence of integers from start to stop, incrementing by step.

array_repeat(col, count)
	creates an array containing a column repeated count times.

map_contains_key(col, value)
	Returns true if the map contains the key.

map_keys(col)
	Returns an unordered array containing the keys of the map.

map_values(col)
	Returns an unordered array containing the values of the map.

map_entries(col)
	Returns an unordered array of all entries in the given map.

map_from_entries(col)
	Converts an array of entries (key value struct types) to a map of values.

arrays_zip(*cols)
	Returns a merged array of structs in which the N-th struct contains all N-th values of input arrays.

map_concat(*cols)
	Returns the union of all the given maps.


###JOIN --WORKSHOP --IMP (join)
Default how = inner
Default on = cross join

on : str, list or Column - OPTIONAL
    a string for the join column name, a list of column names,
    a join expression (Column), or a list of Columns.
    If `on` is a string or a list of strings indicating the name of the join column(s),
    the column(s) must exist on both sides, and this performs an equi-join.


left = sc.parallelize([(0, "zero") , (1, "one")]).toDF(["id", "left"])
right = sc.parallelize([(0, "zero"), (2, "two"), (3, "three")]).toDF(["id", "right"])

#defaults - crossJoin
>>> left.join(right).show()
+---+----+---+-----+
| id|left| id|right|
+---+----+---+-----+
|  0|zero|  0| zero|
|  0|zero|  2|  two|
|  0|zero|  3|three|
|  1| one|  0| zero|
|  1| one|  2|  two|
|  1| one|  3|three|
+---+----+---+-----+
>>> left.join(right, how='cross').show()
+---+----+---+-----+
| id|left| id|right|
+---+----+---+-----+
|  0|zero|  0| zero|
|  0|zero|  2|  two|
|  0|zero|  3|three|
|  1| one|  0| zero|
|  1| one|  2|  two|
|  1| one|  3|three|
+---+----+---+-----+


# Inner join - for common "id" in both - also called natural join, no id column repeated
>>> left.join(right, "id").show()
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
+---+----+-----+

#inner
left.join(right, left.id == right.id).show()

>>> left.join(right, left.id == right.id).show()
+---+----+---+-----+
| id|left| id|right|
+---+----+---+-----+
|  0|zero|  0| zero|
+---+----+---+-----+

#non-equijoin - using < - extremely expensive
>>> left.join(right, left.id < right.id).select(left.id, left.left, right.id, right.right).show()
+---+----+---+-----+
| id|left| id|right|
+---+----+---+-----+
|  0|zero|  2|  two|
|  0|zero|  3|three|
|  1| one|  2|  two|
|  1| one|  3|three|
+---+----+---+-----+

#SQL operators
https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-functions-builtin
& 	        expr1 & expr2 	                        Returns the bitwise AND of expr1 and expr2.
and 	    expr1 and expr2 	                    Returns the logical AND of expr1 and expr2.
* 	        multiplier * multiplicand 	            Returns multiplier multiplied by multiplicand.
!= 	        expr1 != expr2 	                        Returns true if expr1 does not equal expr2, or false otherwise.
! 	        !expr 	                                Returns the logical NOT of a Boolean expression.
between     expr1 [not] between expr2 and expr2 	Tests whether expr1 is greater or equal than expr2 and less than or equal to expr3.
[] 	        arrayExpr [ indexExpr ] 	            Returns indexExprnd element of ARRAY arrayExpr.
[] 	        mapExpr [ keyExpr ] 	                Returns value at keyExpr of MAP mapExpr.
^ 	        expr1 ^ expr2 	                        Returns the bitwise exclusive OR (XOR) of expr1 and expr2.
: 	        jsonStr : jsonPath 	                    Returns fields extracted from the jsonStr.
:: 	        expr :: type 	                        Casts the value expr to the target data type type.
?:: 	    expr ?:: type 	                        Casts the value expr to the target data type type if possible,or  returns NULL otherwise.
div 	    dividend div divisor 	                Returns the integral part of the division of dividend by divisor.
. 	        mapExpr . keyIdentifier 	            Returns a MAP value by keyIdentifier.
. 	        structExpr . fieldIdentifier 	        Returns a STRUCT field by fieldIdentifier.
== 	        expr1 == expr2 	                        Returns true if expr1 equals expr2, or false otherwise.
= 	        expr1 = expr2 	                        Returns true if expr1 equals expr2, or false otherwise.
>= 	        expr1 >= expr2 	                        Returns true if expr1 is greater than or equal to expr2, or false otherwise.
> 	        expr1 > expr2 	                        Returns true if expr1 is greater than expr2, or false otherwise.
exists 	    exists(query) 	                        Returns true if query returns at least one row, or false otherwise.
ilike 	    str [not] ilike (pattern[ESCAPE escape])Returns true if str does (not) match pattern with escape case-insensitively.
ilike 	    str [not] ilike {ANY\|SOME\|ALL}([pattern[, ...]]) 	Returns true if str does (not) match any/all patterns case-insensitively.
in 	        elem [not] in (expr1[, ...]) 	        Returns true if elem does (not) equal any exprN.
in  	    elem [not] in (query) 	                Returns true if elem does (not) equal any row in query.
is distinct expr1 is [not] distinct from expr2 	    Tests whether the arguments do (not) have different values where NULLs are considered as comparable values.
is false 	expr is [not] false 	                Tests whether expr is (not) false.
is null 	expr is [not] null 	                    Returns true if expr is (not) NULL.
is true 	expr is [not] true 	                    Tests whether expr is (not) true.
like 	    str [not] like (pattern[ESCAPE escape]) Returns true if str does (not) match pattern with escape.
like 	    str [not] like {ANY\|SOME\|ALL}([pattern[, ...]]) 	Returns true if str does (not) match any/all patterns.
<=> 	    expr1 <=> expr2 	                    Returns the same result as the EQUAL(=) for non-null operands, but returns true if both are NULL, false if one of the them is NULL.
<= 	        expr1 <= expr2 	                        Returns true if expr1 is less than or equal to expr2, or false otherwise.
<> 	        expr1 <> expr2 	                        Returns true if expr1 does not equal expr2, or false otherwise.
< 	        expr1 < expr2 	                        Returns true if expr1 is less than expr2, or false otherwise.
- 	        expr1 - expr2 	                        Returns the subtraction of expr2 from expr1.
not 	    not expr 	                            Returns the logical NOT of a Boolean expression.
or 	        expr1 or expr2 	                        Returns the logical OR of expr1 and expr2.
% 	        dividend % divisor 	                    Returns the remainder after dividend / divisor.
|| 	        expr1 \|\| expr2 	                    Returns the concatenation of expr1 and expr2.
| 	        expr1 \| expr2 	                        Returns the bitwise OR of expr1 and expr2.
+ 	        expr1 + expr2 	                        Returns the sum of expr1 and expr2.
regexp 	    str [not] regexp regex 	                Returns true if str does (not) match regex.
regexp_like str [not] regexp_like regex 	        Returns true if str does (not) match regex.
rlike 	    str [not] rlike regex 	                Returns true if str does (not) match regex.
/ 	        dividend / divisor 	                    Returns dividend divided by divisor.
~ 	        ~ expr 	                                Returns the bitwise NOT of expr.



Join String 	                    Equivalent SQL Join
inner	                            INNER JOIN
outer, full, fullouter, full_outer	FULL OUTER JOIN
left, leftouter, left_outer	        LEFT JOIN
right, rightouter, right_outer	    RIGHT JOIN
cross
anti, leftanti, left_anti	<-  left rows with common id with right
semi, leftsemi, left_semi   <- left rows with non-common id with right

Rows with null in left are expected to be excluded from the result
as nulls do not match with any value, including other nulls.

Spark doesn't support right semi and right anti joins.

#cross - crossJoin
with id , equality cross join
ie if id matching 1 , then result 1
if id matching 2 rows , then 4 results

#check all
types = ["inner", "cross", "outer", "full", "fullouter", "full_outer", "left",
    "leftouter", "left_outer", "right", "rightouter", "right_outer", "semi",
    "leftsemi", "left_semi", "anti", "leftanti" , "left_anti"]

#lets print - all natural join as only mentioning of columns
for t in types:
    print(t, "==========>")
    left.join(right, "id", t).show()

inner ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
+---+----+-----+

cross ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
+---+----+-----+

outer ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
|  2|null|  two|
|  3|null|three|
+---+----+-----+

full ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
|  2|null|  two|
|  3|null|three|
+---+----+-----+

fullouter ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
|  2|null|  two|
|  3|null|three|
+---+----+-----+

full_outer ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
|  2|null|  two|
|  3|null|three|
+---+----+-----+

left ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
+---+----+-----+

leftouter ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
+---+----+-----+

left_outer ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
+---+----+-----+

right ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  2|null|  two|
|  3|null|three|
+---+----+-----+

rightouter ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  2|null|  two|
|  3|null|three|
+---+----+-----+

right_outer ==========>
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  2|null|  two|
|  3|null|three|
+---+----+-----+

semi ==========>
+---+----+
| id|left|
+---+----+
|  0|zero|
+---+----+

leftsemi ==========>
+---+----+
| id|left|
+---+----+
|  0|zero|
+---+----+

left_semi ==========>
+---+----+
| id|left|
+---+----+
|  0|zero|
+---+----+

anti ==========>
+---+----+
| id|left|
+---+----+
|  1| one|
+---+----+

leftanti ==========>
+---+----+
| id|left|
+---+----+
|  1| one|
+---+----+

left_anti ==========>
+---+----+
| id|left|
+---+----+
|  1| one|
+---+----+

#natural join - only contains column once
x = spark.createDataFrame([(1, "a"), (2, "b"), (3, "c")], ["c1", "c2"])
z = spark.createDataFrame([(1, "aaaaa"), (2, "bbbbb")], ["c1", "c3"])

#here c1 is repeated from both
>>> x.join(z, x.c1 == z.c1).show()
+---+---+---+-----+
| c1| c2| c1|   c3|
+---+---+---+-----+
|  1|  a|  1|aaaaa|
|  2|  b|  2|bbbbb|
+---+---+---+-----+

#to remove one c1 , mention only col as condition
>>> x.join(z, "c1").show()
+---+---+-----+
| c1| c2|   c3|
+---+---+-----+
|  1|  a|aaaaa|
|  2|  b|bbbbb|
+---+---+-----+

If you don't want to specify the columns to join on,
and automatically select the columns with the same name

def natural_join(df1: DataFrame, df2: DataFrame) -> DataFrame:
    common_columns = list(set(x.columns).intersection(set(z.columns)))
    if common_columns:
        return df1.join(df2, common_columns)


natural_join(x, z).show()
+---+---+-----+
| c1| c2|   c3|
+---+---+-----+
|  1|  a|aaaaa|
|  2|  b|bbbbb|
+---+---+-----+

#SQL join
x.createOrReplaceTempView("nt1")
z.createOrReplaceTempView("nt2")

create temporary view nt1 as select * from values
  ("one", 1),
  ("two", 2),
  ("three", 3)
  as nt1(k, v1);

create temporary view nt2 as select * from values
  ("one", 1),
  ("two", 22),
  ("one", 5)
  as nt2(k, v2);

create temporary view nt3 as select * from values
  ("one", 4),
  ("two", 5),
  ("one", 6)
  as nt3(k, v3);

create temporary view nt4 as select * from values
  ("one", 7),
  ("two", 8),
  ("one", 9)
  as nt4(k, v4);

SELECT * FROM nt1 natural join nt2;

SELECT * FROM nt1 natural join nt2 where k = "one";

SELECT * FROM nt1 natural left join nt2 order by v1, v2;

SELECT * FROM nt1 natural right join nt2 order by v1, v2;

SELECT count(*) FROM nt1 natural full outer join nt2;

SELECT k FROM nt1 natural join nt2;

SELECT k FROM nt1 natural join nt2 where k = "one";

SELECT nt1.* FROM nt1 natural join nt2;

SELECT nt2.* FROM nt1 natural join nt2;

SELECT sbq.* from (SELECT * FROM nt1 natural join nt2) sbq;

SELECT sbq.k from (SELECT * FROM nt1 natural join nt2) sbq;

SELECT nt1.*, nt2.* FROM nt1 natural join nt2;

SELECT *, nt2.k FROM nt1 natural join nt2;

SELECT nt1.k, nt2.k FROM nt1 natural join nt2;

SELECT k FROM (SELECT nt2.k FROM nt1 natural join nt2);

SELECT nt2.k AS key FROM nt1 natural join nt2 ORDER BY key;

SELECT nt1.k, nt2.k FROM nt1 natural join nt2 where k = "one";

SELECT * FROM (SELECT * FROM nt1 natural join nt2);

SELECT * FROM (SELECT nt1.*, nt2.* FROM nt1 natural join nt2);

SELECT * FROM (SELECT nt1.v1, nt2.k FROM nt1 natural join nt2);

SELECT nt2.k FROM (SELECT * FROM nt1 natural join nt2);

SELECT * FROM nt1 natural join nt2 natural join nt3;

SELECT nt1.*, nt2.*, nt3.* FROM nt1 natural join nt2 natural join nt3;

SELECT nt1.*, nt2.*, nt3.* FROM nt1 natural join nt2 join nt3 on nt2.k = nt3.k;

SELECT * FROM nt1 natural join nt2 join nt3 on nt1.k = nt3.k;

SELECT * FROM nt1 natural join nt2 join nt3 on nt2.k = nt3.k;

SELECT nt1.*, nt2.*, nt3.*, nt4.* FROM nt1 natural join nt2 natural join nt3 natural join nt4;

#Asof join
Perform an as-of join.

This is similar to a left-join except that we match on the nearest
key rather than equal keys.

Parameters
----------
other : :class:`DataFrame`
    Right side of the join
leftAsOfColumn : str or :class:`Column`
    a string for the as-of join column name, or a Column
rightAsOfColumn : str or :class:`Column`
    a string for the as-of join column name, or a Column
on : str, list or :class:`Column`, optional
    a string for the join column name, a list of column names,
    a join expression (Column), or a list of Columns.
    If `on` is a string or a list of strings indicating the name of the join column(s),
    the column(s) must exist on both sides, and this performs an equi-join.
how : str, optional
    default ``inner``. Must be one of: ``inner`` and ``left``.
tolerance : :class:`Column`, optional
    an asof tolerance within this range; must be compatible
    with the merge index.
allowExactMatches : bool, optional
    default ``True``.
direction : str, optional
    default ``backward``. Must be one of: ``backward``, ``forward``, and ``nearest``.

Examples
--------
The following performs an as-of join between ``left`` and ``right``.

>>> left = spark.createDataFrame([(1, "a"), (5, "b"), (10,  "c")], ["a", "left_val"])
>>> right = spark.createDataFrame([(1, 1), (2, 2), (3, 3), (6, 6), (7, 7)],
...                               ["a", "right_val"])
>>> left._joinAsOf(
        right, leftAsOfColumn="a", rightAsOfColumn="a"
    ).select(left.a, 'left_val', 'right_val').sort("a").collect()
[Row(a=1, left_val='a', right_val=1),
 Row(a=5, left_val='b', right_val=3),
 Row(a=10, left_val='c', right_val=7)]

>>> from pyspark.sql import functions as sf
>>> left._joinAsOf(
        right, leftAsOfColumn="a", rightAsOfColumn="a", tolerance=sf.lit(1)
    ).select(left.a, 'left_val', 'right_val').sort("a").collect()
[Row(a=1, left_val='a', right_val=1)]

>>> left._joinAsOf(
        right, leftAsOfColumn="a", rightAsOfColumn="a", how="left", tolerance=sf.lit(1)
    ).select(left.a, 'left_val', 'right_val').sort("a").collect()
[Row(a=1, left_val='a', right_val=1),
 Row(a=5, left_val='b', right_val=None),
 Row(a=10, left_val='c', right_val=None)]

>>> left._joinAsOf(
        right, leftAsOfColumn="a", rightAsOfColumn="a", allowExactMatches=False
    ).select(left.a, 'left_val', 'right_val').sort("a").collect()
[Row(a=5, left_val='b', right_val=3),
 Row(a=10, left_val='c', right_val=7)]

>>> left._joinAsOf(
        right, leftAsOfColumn="a", rightAsOfColumn="a", direction="forward"
    ).select(left.a, 'left_val', 'right_val').sort("a").collect()
[Row(a=1, left_val='a', right_val=1),
 Row(a=5, left_val='b', right_val=6)]


### rollup and cube --WORKSHOP --IMP  (rollup)
##Details of cube - cube is more than rollup operator,
#i.e. cube does rollup with aggregation over all the missing combinations given the columns.
sales = sc.parallelize([
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]).toDF(["city", "year", "amount"])

from pyspark.sql import functions as F
sales.groupBy("city").count().show()

sales.groupBy("city").count().toPandas().values.shape
#output
(3,2)

sales.groupBy("city").agg({'amount': 'min'}).show()
sales.groupBy("city").agg({"*": "count"}).show()
sales.groupBy("city").agg(F.min("amount")).show()
sales.groupBy("city").agg(F.min("amount"), F.max("amount")).show()

>>> sales.groupBy("city", "year").count().show()
+-------+----+-----+
|   city|year|count|
+-------+----+-----+
| Warsaw|2016|    1|
| Warsaw|2017|    1|
| Boston|2015|    1|
| Boston|2016|    1|
|Toronto|2017|    1|
+-------+----+-----+

q = sales.groupBy("city", "year")\
  .agg(F.sum("amount").alias("amount"))\
  .sort(F.col("city").desc(), F.col("year").asc())

+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
|Toronto|2017|    50|
| Boston|2015|    50|
| Boston|2016|   150|
+-------+----+------+

q = sales.rollup("city", "year")\
  .agg(F.sum("amount").alias("amount"))\
  .sort(F.col("city").desc(), F.col("year").asc())
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|null|   300|
| Warsaw|2016|   100|
| Warsaw|2017|   200|
|Toronto|null|    50|
|Toronto|2017|    50|
| Boston|null|   200|
| Boston|2015|    50|
| Boston|2016|   150|
|   null|null|   550|
+-------+----+------+

q = sales.cube("city", "year")\
  .agg(F.sum("amount").alias("amount"))\
  .sort(F.col("city").desc(), F.col("year").asc())
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|  <-- total in Warsaw in 2016
| Warsaw|2017|   200|  <-- total in Warsaw in 2017
| Warsaw|null|   300|  <-- total in Warsaw (across all years)
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total in 2015 (across all cities)
|   null|2016|   250|
|   null|2017|   250|
|   null|null|   550|  <-- grand total (across cities and years)
+-------+----+------+


sales.createOrReplaceTempView("sales")

# equivalent to rollup("city", "year")
q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), ()) -- could have added (year) - means year null
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """).show()

+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550|  <-- grand total across all cities and years
+-------+----+------+

# equivalent to cube("city", "year")
# note the additional (year) grouping set
q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), (year), ())
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total across all cities in 2015
|   null|2016|   250|  <-- total across all cities in 2016
|   null|2017|   250|  <-- total across all cities in 2017
|   null|null|   550|
+-------+----+------+




##Understanding cube and rollup
#Multi-dimensional aggregate operators are enhanced variants of groupBy operator
#that allow you to create queries for subtotals, grand totals and superset of subtotals in one go.

#grouping(*cols)  is an aggregate function that indicates whether a specified column is aggregated or not and:
#    returns  1  if the column is in a subtotal and is  NULL
#    returns  0  if the underlying value is  NULL  or any other value
#grouping_id(*cols)  is an aggregate function that computes the level of grouping:
#    Returns
#        0  for combinations of each column
#        1  for subtotals of column 1
#        2  for subtotals of column 2
#        And so on...

sales = sc.parallelize([
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]).toDF(["city", "year", "amount"])

from pyspark.sql import functions as F
# very labor-intense
# groupBy's unioned
groupByCityAndYear = sales              \
  .groupBy("city", "year")              \   # <-- subtotals (city, year)
  .agg(F.sum("amount").alias("amount"))

groupByCityOnly = sales                             \
  .groupBy("city")                                  \  # <-- subtotals (city)
  .agg(F.sum("amount").alias("amount"))               \
  .select("city", F.lit(None).alias("year"), "amount")   # <-- year is null

withUnion = groupByCityAndYear  \
  .union(groupByCityOnly)   \
  .sort(F.col("city").desc(), F.col("year").asc())

>>> withUnion.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|null|   300|
| Warsaw|2016|   100|
| Warsaw|2017|   200|
|Toronto|null|    50|
|Toronto|2017|    50|
| Boston|null|   200|
| Boston|2015|    50|
| Boston|2016|   150|
+-------+----+------+




##Multi-dimensional aggregate operators are semantically equivalent to union operator
#(or SQL’s UNION ALL) to combine single grouping queries.

#Note groupby result also contains columns on which group by is done along with all others
from pyspark.sql import functions as F
withRollup = sales                                                  \
  .rollup("city", "year")                                           \
  .agg(F.sum("amount").alias("amount"), F.grouping_id().alias("gid"))   \
  .sort(F.col("city").desc(), F.col("year").asc())                      \
  .filter("gid != 3")                                               \
  .select("city", "year", "amount")

>>> withRollup.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|null|   300|
| Warsaw|2016|   100|
| Warsaw|2017|   200|
|Toronto|null|    50|
|Toronto|2017|    50|
| Boston|null|   200|
| Boston|2015|    50|
| Boston|2016|   150|
+-------+----+------+

# SQL only,
sales.createOrReplaceTempView("sales")
withGroupingSets = sql("""
  SELECT city, year, SUM(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city))
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> withGroupingSets.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
+-------+----+------+

##Details of  rollup
#Note the subtotal
sales = sc.parallelize([
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]).toDF(["city", "year", "amount"])

from pyspark.sql import functions as F
q = sales   \
  .rollup("city", "year")   \
  .agg(F.sum("amount").alias("amount"))    \
  .sort(F.col("city").desc(), F.col("year").asc())

>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100| <-- subtotal for Warsaw in 2016
| Warsaw|2017|   200|
| Warsaw|null|   300| <-- subtotal for Warsaw (across years)
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550| <-- grand total
+-------+----+------+

# The above query is semantically equivalent to the following
from pyspark.sql import functions as F
q1 = sales
  .groupBy("city", "year")  # <-- subtotals (city, year)
  .agg(F.sum("amount").alias("amount"))
q2 = sales
  .groupBy("city")          # <-- subtotals (city)
  .agg(F.sum("amount").alias("amount"))
  .select("city", F.lit(None).alias("year"), "amount")  # <-- year is null
q3 = sales
  .groupBy()                # <-- grand total
  .agg(F.sum("amount").alias("amount"))
  .select(F.lit(None).alias("city"), F.lit(None).alias("year"), "amount")  # <-- city and year are null
qq = q1
  .union(q2)
  .union(q3)
  .sort(F.col("city").desc(), "year".asc())
>>> qq.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550|
+-------+----+------+

###Time Window --WORKSHOP --IMP  (watermark)
F.window(col_timestamp , windowDuration, slideDuration =None,startTime =None)
    Bucketize rows into one or more time windows given a column with timestamp
    Window starts are inclusive but the window ends are exclusive,
    e.g. 12:05 will be in the window [12:05,12:10) but not in [12:00,12:05).
    Windows can support microsecond precision.
    Windows in the order of months are not supported.

    The time column must be of org.apache.spark.sql.types.TimestampType.
    Durations(windowDuration, slideDuration)  are provided as strings,
    e.g. "1 second", "1 day 12 hours", "2 minutes".
    Valid interstrings are "week", "day", "hour", "minute", "second", "millisecond", "microsecond".
    If the slideDuration is not provided, the windows will be tumbling windows.


    The startTime is the offset with respect to 1970-01-01 00:00:00 UTC
    with which to start window intervals. For example, in order to have hourly tumbling windows
    that start 15 minutes past the hour, e.g. 12:15-13:15, 13:15-14:15…
    provide startTime as 15 minutes.


    The output column will be a struct called "window" by default
    with the nested columns "start" and "end",
    where "start" and "end" will be of org.apache.spark.sql.types.TimestampType.

timeColumn should be of TimestampType
#Example
Windows starts always on 00:00:00, but startTime can be '15 minutes'
then it starts from 00:15:00


import pyspark.sql.functions as F
import datetime
data = map(lambda t: (datetime.datetime(*t[0]),t[1]), [
  # (year, month, dayOfMonth, hour, minute, second), level
  ((2012, 12, 12, 12, 12, 12), 5),
  ((2012, 12, 12, 12, 12, 14), 9),
  ((2012, 12, 12, 13, 13, 14), 4),
  ((2016, 8,  13, 0, 0, 0), 10),
  ((2017, 5,  27, 0, 0, 0), 15)])

#Create dataframe of above using SparkSession
#with cols time and level
levels = spark.createDataFrame(data, ["time", "level"])


#Create tumbling window of 5 seconds without any alias
#select that window and level in that order
q = levels.select(F.window("time", "5 seconds"), "level")
#it creates 4 windows
#first window has 2 events
>>> q.show(truncate = False)
+---------------------------------------------+-----+
|window                                       |level|
+---------------------------------------------+-----+
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|5    |
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|9    |
|[2012-12-12 13:13:10.0,2012-12-12 13:13:15.0]|4    |
|[2016-08-13 00:00:00.0,2016-08-13 00:00:05.0]|10   |
|[2017-05-27 00:00:00.0,2017-05-27 00:00:05.0]|15   |
+---------------------------------------------+-----+

>>> q.schema
StructType([StructField('window', StructType([StructField('start', TimestampType(), True), StructField('end', TimestampType(), True)]), False), StructField('level', LongType(), True)])
#print schema
>>> q.printSchema()
root
 |-- window: struct (nullable = false)
 |    |-- start: timestamp (nullable = true)
 |    |-- end: timestamp (nullable = true)
 |-- level: long (nullable = true)

 #print DDL string(simple string) of above schema
>>> q.schema.simpleString()
'struct<window:struct<start:timestamp,end:timestamp>,level:bigint>'

#Create sliding window of 5 seconds with 2 seconds as step
#select that window and level in that order
q = levels.select(F.window("time", "5 seconds", "2 seconds"), "level")
#first event/level goes into 3 windows
#thoses windows' start time are 12:12:08, 12:12:10 12:12:12
#Note events at start times are inclusive
#but at end times are exclusive
q.show(truncate = False)
+------------------------------------------+-----+
|window                                    |level|
+------------------------------------------+-----+
|{2012-12-12 12:12:12, 2012-12-12 12:12:17}|5    |
|{2012-12-12 12:12:10, 2012-12-12 12:12:15}|5    |
|{2012-12-12 12:12:08, 2012-12-12 12:12:13}|5    |
|{2012-12-12 12:12:14, 2012-12-12 12:12:19}|9    |
|{2012-12-12 12:12:12, 2012-12-12 12:12:17}|9    |
|{2012-12-12 12:12:10, 2012-12-12 12:12:15}|9    |
|{2012-12-12 13:13:14, 2012-12-12 13:13:19}|4    |
|{2012-12-12 13:13:12, 2012-12-12 13:13:17}|4    |
|{2012-12-12 13:13:10, 2012-12-12 13:13:15}|4    |
|{2016-08-13 00:00:00, 2016-08-13 00:00:05}|10   |
|{2016-08-12 23:59:58, 2016-08-13 00:00:03}|10   |
|{2016-08-12 23:59:56, 2016-08-13 00:00:01}|10   |
|{2017-05-27 00:00:00, 2017-05-27 00:00:05}|15   |
|{2017-05-26 23:59:58, 2017-05-27 00:00:03}|15   |
|{2017-05-26 23:59:56, 2017-05-27 00:00:01}|15   |
+------------------------------------------+-----+

# calculating the sum of levels every 5 seconds
#Sum has alias level_sum and then
#select start and end of window and level sum without any alias
sums = levels.\
  groupBy(F.window("time", "5 seconds")).\
  agg(F.sum("level").alias("level_sum")).\
  select("window.start", "window.end", "level_sum")

#Level sum for 12:12:10 to 12:12:15 would be 14
>>> sums.show()
+-------------------+-------------------+---------+
|              start|                end|level_sum|
+-------------------+-------------------+---------+
|2012-12-12 13:13:10|2012-12-12 13:13:15|        4|
|2012-12-12 12:12:10|2012-12-12 12:12:15|       14|
|2016-08-13 00:00:00|2016-08-13 00:00:05|       10|
|2017-05-27 00:00:00|2017-05-27 00:00:05|       15|
+-------------------+-------------------+---------+

#session window has dynamic time, start time is event time
#and wait for gapduration , if any event comes, end time
#will increase by gapDuration and so on
#window closes when no event in gapDuration+ last event time
# calculating the sum of levels every 5 seconds in session windows
#Sum has alias level_sum
w = levels.groupBy(F.session_window("time", "5 seconds")).agg(F.sum("level").alias("level_sum"))

>>> w.printSchema()
root
 |-- session_window: struct (nullable = false)
 |    |-- start: timestamp (nullable = true)
 |    |-- end: timestamp (nullable = true)
 |-- level_sum: long (nullable = true)

w.show()
#first window start will be 12:12:12 and end will be 12:12:19
#This window will have level_sum  as value 14
>>> w.show(truncate=False)
+------------------------------------------+---------+
|session_window                            |level_sum|
+------------------------------------------+---------+
|{2012-12-12 12:12:12, 2012-12-12 12:12:19}|14       |
|{2012-12-12 13:13:14, 2012-12-12 13:13:19}|4        |
|{2016-08-13 00:00:00, 2016-08-13 00:00:05}|10       |
|{2017-05-27 00:00:00, 2017-05-27 00:00:05}|15       |
+------------------------------------------+---------+
##SQL
> SELECT a, window.start as start, window.end as end, window_time(window), cnt
    FROM (SELECT a, window, count(*) as cnt
           FROM VALUES ('A1', '2021-01-01 00:00:00'),
                       ('A1', '2021-01-01 00:04:30'),
                       ('A1', '2021-01-01 00:06:00'),
                       ('A2', '2021-01-01 00:01:00') AS tab(a, b)
           GROUP by a, window(b, '5 MINUTES'))
    ORDER BY a, window.start;
  A1  2021-01-01 00:00:00  2021-01-01 00:05:00  2021-01-01 00:04:59.999999 2
  A1  2021-01-01 00:05:00  2021-01-01 00:10:00  2021-01-01 00:09:59.999999 1
  A2  2021-01-01 00:00:00  2021-01-01 00:05:00  2021-01-01 00:04:59.999999 1
> SELECT a, session_window.start, session_window.end, count(*) as cnt
    FROM VALUES ('A1', '2021-01-01 00:00:00'),
                ('A1', '2021-01-01 00:04:30'),
                ('A1', '2021-01-01 00:10:00'),
                ('A2', '2021-01-01 00:01:00') AS tab(a, b)
    GROUP by a, session_window(b, '5 minutes')
    ORDER BY a, start;
  A1  2021-01-01 00:00:00  2021-01-01 00:09:30  2
  A1  2021-01-01 00:10:00  2021-01-01 00:15:00  1
  A2  2021-01-01 00:01:00  2021-01-01 00:06:00  1

> SELECT a, session_window.start, session_window.end, count(*) as cnt
    FROM VALUES ('A1', '2021-01-01 00:00:00'),
                ('A1', '2021-01-01 00:04:30'),
                ('A1', '2021-01-01 00:10:00'),
                ('A2', '2021-01-01 00:01:00'),
                ('A2', '2021-01-01 00:04:30') AS tab(a, b)
    GROUP by a, session_window(b, CASE WHEN a = 'A1' THEN '5 minutes'
                                       WHEN a = 'A2' THEN '1 minute'
                                       ELSE '10 minutes' END)
    ORDER BY a, start;
  A1  2021-01-01 00:00:00  2021-01-01 00:09:30  2
  A1  2021-01-01 00:10:00  2021-01-01 00:15:00  1
  A2  2021-01-01 00:01:00  2021-01-01 00:02:00  1
  A2  2021-01-01 00:04:30  2021-01-01 00:05:30  1

  > SELECT window, min(val), max(val), count(val)
  FROM VALUES (TIMESTAMP'2020-08-01 12:20:21', 17),
              (TIMESTAMP'2020-08-01 12:20:22', 12),
              (TIMESTAMP'2020-08-01 12:23:10',  8),
              (TIMESTAMP'2020-08-01 12:25:05', 11),
              (TIMESTAMP'2020-08-01 12:28:59', 15),
              (TIMESTAMP'2020-08-01 12:30:01', 23),
              (TIMESTAMP'2020-08-01 12:30:15',  2),
              (TIMESTAMP'2020-08-01 12:35:22', 16) AS S(stamp, val)
  GROUP BY window(stamp, '2 MINUTES 30 SECONDS', '30 SECONDS', '15 SECONDS');
  {2020-08-01 12:19:15, 2020-08-01 12:21:45} 12       17       2
  {2020-08-01 12:18:15, 2020-08-01 12:20:45} 12       17       2
  {2020-08-01 12:20:15, 2020-08-01 12:22:45} 12       17       2
  {2020-08-01 12:19:45, 2020-08-01 12:22:15} 12       17       2
  {2020-08-01 12:18:45, 2020-08-01 12:21:15} 12       17       2
  {2020-08-01 12:21:45, 2020-08-01 12:24:15} 8        8        1
  {2020-08-01 12:22:45, 2020-08-01 12:25:15} 8        11       2
  {2020-08-01 12:21:15, 2020-08-01 12:23:45} 8        8        1
  {2020-08-01 12:22:15, 2020-08-01 12:24:45} 8        8        1
  {2020-08-01 12:20:45, 2020-08-01 12:23:15} 8        8        1
  {2020-08-01 12:23:45, 2020-08-01 12:26:15} 11       11       1
  {2020-08-01 12:23:15, 2020-08-01 12:25:45} 11       11       1
  {2020-08-01 12:24:45, 2020-08-01 12:27:15} 11       11       1
  {2020-08-01 12:24:15, 2020-08-01 12:26:45} 11       11       1
  {2020-08-01 12:27:15, 2020-08-01 12:29:45} 15       15       1
  {2020-08-01 12:27:45, 2020-08-01 12:30:15} 15       23       2
  {2020-08-01 12:28:45, 2020-08-01 12:31:15} 2        23       3
  {2020-08-01 12:26:45, 2020-08-01 12:29:15} 15       15       1
  {2020-08-01 12:28:15, 2020-08-01 12:30:45} 2        23       3
  {2020-08-01 12:29:45, 2020-08-01 12:32:15} 2        23       2

##Another Example --WORKSHOP


#Example
df = sc.parallelize( [("2016-03-11 09:00:07", 1),]).toDF(["date", "val"])

import pyspark.sql.functions as F

w = df.groupBy(F.window(col("date"), "5 seconds")).agg(F.sum("val").alias("sum"))
>>> w.select(F.col("window.start").cast("string").alias("start"), F.col("window.end").cast("string").alias("end"), col("sum")).collect()
[Row(start =u"2016-03-11 09:00:05",end =u"2016-03-11 09:00:10",sum =1)]



pyspark.sql.functions.session_window(timeColumn,
        gapDuration: Union[pyspark.sql.column.Column, str])
    Generates session window given a timestamp specifying column.

    Session window is one of dynamic windows, which means the length of window
    is varying according to the given inputs. The length of session window is defined as
    'the timestamp of latest input of the session + gap duration',
    so when the new inputs are bound to the current session window, the end time of session window
    can be expanded according to the new inputs.

    Windows can support microsecond precision.
    Windows in the order of months are not supported.

    For a streaming query, you may use the function current_timestamp
    to generate windows on processing time.

    gapDuration is provided as strings, e.g. '1 second',
    '1 day 12 hours', '2 minutes'.

    Valid interval strings are 'week', 'day', 'hour', 'minute', 'second', 'millisecond', 'microsecond'.
    It could also be a Column which can be evaluated to gap duration dynamically
    based on the input row.

    The output column will be a struct called 'session_window' by default
    with the nested columns 'start' and 'end', where 'start' and 'end' will be of pyspark.sql.types.TimestampType.

#Example
df = spark.createDataFrame([("2016-03-11 09:00:07", 1)]).toDF("date", "val")

w = df.groupBy(session_window("date", "5 seconds")).agg(sum("val").alias("sum"))

w.select(w.session_window.start.cast("string").alias("start"),
         w.session_window.end.cast("string").alias("end"), "sum").collect()

[Row(start='2016-03-11 09:00:07', end='2016-03-11 09:00:12', sum=1)]

w = df.groupBy(session_window("date", lit("5 seconds"))).agg(sum("val").alias("sum"))

w.select(w.session_window.start.cast("string").alias("start"),
         w.session_window.end.cast("string").alias("end"), "sum").collect()
[Row(start='2016-03-11 09:00:07', end='2016-03-11 09:00:12', sum=1)]



###Generating Records  based window Function --WORKSHOP  --IMP (overwindow)

#Example
from pyspark.sql.types import *
import pyspark.sql.functions as F
from pyspark.sql import *

Salary =  Row('dept', 'empNo', 'salary')
empsalary = [
  Salary("sales", 1, 5000),
  Salary("personnel", 2, 3900),
  Salary("sales", 3, 4800),
  Salary("sales", 4, 4800),
  Salary("personnel", 5, 3500),
  Salary("develop", 7, 4200),
  Salary("develop", 8, 6000),
  Salary("develop", 9, 4500),
  Salary("develop", 10, 5200),
  Salary("develop", 11, 5200)]

df = spark.createDataFrame(empsalary)
df.createOrReplaceTempView("empsalary")

df.select("empNo", "dept", F.avg('salary').over(Window.partitionBy('dept') ).alias("avg_salary")).show()
+-----+---------+-----------------+
|empNo|     dept|       avg_salary|
+-----+---------+-----------------+
|    7|  develop|           5020.0|
|    8|  develop|           5020.0|
|    9|  develop|           5020.0|
|   10|  develop|           5020.0|
|   11|  develop|           5020.0|
|    2|personnel|           3700.0|
|    5|personnel|           3700.0|
|    1|    sales|4866.666666666667|
|    3|    sales|4866.666666666667|
|    4|    sales|4866.666666666667|
+-----+---------+-----------------+

spark.sql("""
SELECT empNo,
         dept,
         avg(salary) OVER (PARTITION BY dept) AS avg_salary
  FROM empsalary;
""").show()


df.select("empNo", "dept", F.rank().over(Window.partitionBy('dept').orderBy('salary') ).alias("rank")).show()
+-----+---------+----+
|empNo|     dept|rank|
+-----+---------+----+
|    7|  develop|   1|
|    9|  develop|   2|
|   10|  develop|   3|
|   11|  develop|   3|
|    8|  develop|   5|
|    5|personnel|   1|
|    2|personnel|   2|
|    3|    sales|   1|
|    4|    sales|   1|
|    1|    sales|   3|
+-----+---------+----+
df.select("empNo", "dept", F.dense_rank().over(Window.partitionBy('dept').orderBy('salary') ).alias("rank")).show()
+-----+---------+----+
|empNo|     dept|rank|
+-----+---------+----+
|    7|  develop|   1|
|    9|  develop|   2|
|   10|  develop|   3|
|   11|  develop|   3|
|    8|  develop|   4|
|    5|personnel|   1|
|    2|personnel|   2|
|    3|    sales|   1|
|    4|    sales|   1|
|    1|    sales|   2|
+-----+---------+----+

spark.sql("""
SELECT empNo,
         dept,
         RANK() OVER (PARTITION BY dept ORDER BY salary) AS rank
  FROM empsalary
""").show()

#cume_dist - % of preceeding range to current
df.select("empNo", "dept", "salary", F.cume_dist().over(Window.partitionBy('dept').orderBy(F.col('salary').desc())\
    .rangeBetween(Window.unboundedPreceding, Window.currentRow) ).alias("cume_dist")).show()

+-----+---------+------+------------------+
|empNo|     dept|salary|         cume_dist|
+-----+---------+------+------------------+
|    8|  develop|  6000|               0.2|
|   10|  develop|  5200|               0.6|
|   11|  develop|  5200|               0.6|
|    9|  develop|  4500|               0.8|
|    7|  develop|  4200|               1.0|
|    2|personnel|  3900|               0.5|
|    5|personnel|  3500|               1.0|
|    1|    sales|  5000|0.3333333333333333|
|    3|    sales|  4800|               1.0|
|    4|    sales|  4800|               1.0|
+-----+---------+------+------------------+

spark.sql("""
 SELECT empNo,
         dept,
         salary,
         CUME_DIST() OVER (PARTITION BY dept ORDER BY salary DESC
                           RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cume_dist
   FROM empsalary
""").show()

#lag(col,count =1,default =None) - default preceding one
#lead(col,count =1,default =None) - next one
spark.sql("""
SELECT empNo,
         salary,
         LAG(salary) OVER (PARTITION BY dept ORDER BY salary) AS lag,
         LEAD(salary) OVER (PARTITION BY dept ORDER BY salary) AS lead
    FROM empsalary
""").show()

+-----+------+----+----+
|empNo|salary| lag|lead|
+-----+------+----+----+
|    7|  4200|null|4500|
|    9|  4500|4200|5200|
|   10|  5200|4500|5200|
|   11|  5200|5200|6000|
|    8|  6000|5200|   0|
|    5|  3500|null|3900|
|    2|  3900|3500|   0|
|    3|  4800|null|4800|
|    4|  4800|4800|5000|
|    1|  5000|4800|   0|
+-----+------+----+----+

#Global Window - no partition by
#not performant as all data to move into single partition


spark.sql("""
SELECT round(avg(salary) OVER win, 1) AS avgsalary,
         min(salary) OVER win AS minsalary,
         max(salary) OVER win AS maxsalary,
         count(*) OVER win AS numEmps
    FROM empsalary
    WINDOW win AS (ORDER BY salary
                   ROWS BETWEEN 2 PRECEDING AND 2 FOLLOWING)
""").show()

+---------+---------+---------+-------+
|avgsalary|minsalary|maxsalary|numEmps|
+---------+---------+---------+-------+
|   3866.7|     3500|     4200|      3|
|   4025.0|     3500|     4500|      4|
|   4180.0|     3500|     4800|      5|
|   4440.0|     3900|     4800|      5|
|   4660.0|     4200|     5000|      5|
|   4860.0|     4500|     5200|      5|
|   5000.0|     4800|     5200|      5|
|   5240.0|     4800|     6000|      5|
|   5350.0|     5000|     6000|      4|
|   5466.7|     5200|     6000|      3|
+---------+---------+---------+-------+

##Example Window -  - Difference on Column
#Compute a difference between values in rows in a column.

pairs = [(x, 10 * x * y) for x in range(1,5) for y in range(1,2)]

ds = sc.parallelize(pairs).toDF(["ns", "tens"])

>>> ds.show()
+---+----+
| ns|tens|
+---+----+
|  1|  10|
|  1|  20|
|  2|  20|
|  2|  40|
|  3|  30|
|  3|  60|
|  4|  40|
|  4|  80|
|  5|  50|
|  5| 100|
+---+----+

overNs = Window.partitionBy('ns').orderBy('tens')
diff = F.lead('tens', 1).over(overNs)

ds.withColumn("diff", diff - F.col('tens')).show()
+---+----+----+
| ns|tens|diff|
+---+----+----+
|  1|  10|  10|
|  1|  20|null|
|  3|  30|  30|
|  3|  60|null|
|  5|  50|  50|
|  5| 100|null|
|  4|  40|  40|
|  4|  80|null|
|  2|  20|  20|
|  2|  40|null|
+---+----+----+


#Example Window - Partitioning Records—partitionBy Methods

# partition records into two groups
# * tokens starting with "h"
# * others


byHTokens = Window.partitionBy(F.col('token').startsWith("h"))

tokens = sc.parallelize(
    [ (e, i) for i,e in enumerate(["hello", "henry", "and", "harry"])]
    ).toDF(["id", "token"])

# count the sum of ids in each group
result = tokens.select('*', F.sum('id').over(byHTokens).alias("sum over h tokens").orderBy('id') #'

scala> result.show
+---+-----+-----------------+
| id|token|sum over h tokens|
+---+-----+-----------------+
|  0|hello|                4|
|  1|henry|                4|
|  2|  and|                2|
|  3|harry|                4|
+---+-----+-----------------+




#Example Window -   -Top N per Group
#Top N per Group is useful when you need to compute the first and second best-sellers in category.

#Question: What are the best-selling and the second best-selling products in every category

data = sc.parallelize([
  ("Thin",       "cell phone", 6000),
  ("Normal",     "tablet",     1500),
  ("Mini",       "tablet",     5500),
  ("Ultra thin", "cell phone", 5000),
  ("Very thin",  "cell phone", 6000),
  ("Big",        "tablet",     2500),
  ("Bendable",   "cell phone", 3000),
  ("Foldable",   "cell phone", 3000),
  ("Pro",        "tablet",     4500),
  ("Pro2",       "tablet",     6500)])
  .toDF(["product", "category", "revenue"])

> data.show()
+----------+----------+-------+
|   product|  category|revenue|
+----------+----------+-------+
|      Thin|cell phone|   6000|
|    Normal|    tablet|   1500|
|      Mini|    tablet|   5500|
|Ultra thin|cell phone|   5000|
| Very thin|cell phone|   6000|
|       Big|    tablet|   2500|
|  Bendable|cell phone|   3000|
|  Foldable|cell phone|   3000|
|       Pro|    tablet|   4500|
|      Pro2|    tablet|   6500|
+----------+----------+-------+

> data.where(F.col('category') == F.lit("tablet")).show()  #'
+-------+--------+-------+
|product|category|revenue|
+-------+--------+-------+
| Normal|  tablet|   1500|
|   Mini|  tablet|   5500|
|    Big|  tablet|   2500|
|    Pro|  tablet|   4500|
|   Pro2|  tablet|   6500|
+-------+--------+-------+

#The question boils down to ranking products in a category
#based on their revenue, and to pick the best selling and the second best-selling products
#based the ranking.


overCategory = Window.partitionBy('category').orderBy(F.col('revenue').desc())

ranked = data.withColumn("rank", F.dense_rank.over(overCategory))

scala> ranked.show()
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|       Pro|    tablet|   4500|   3|
|       Big|    tablet|   2500|   4|
|    Normal|    tablet|   1500|   5|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
|  Bendable|cell phone|   3000|   3|
|  Foldable|cell phone|   3000|   3|
+----------+----------+-------+----+

> ranked.where(F.col('rank') <= 2).show()  #'
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
+----------+----------+-------+----+

#Example Window - Revenue Difference per Category

reveDesc = Window.partitionBy('category').orderBy(F.col('revenue').desc())
reveDiff = F.max('revenue').over(reveDesc) - F.col('revenue')

scala> data.select('*', reveDiff.alias('revenue_diff')).show()
+----------+----------+-------+------------+
|   product|  category|revenue|revenue_diff|
+----------+----------+-------+------------+
|      Pro2|    tablet|   6500|           0|
|      Mini|    tablet|   5500|        1000|
|       Pro|    tablet|   4500|        2000|
|       Big|    tablet|   2500|        4000|
|    Normal|    tablet|   1500|        5000|
|      Thin|cell phone|   6000|           0|
| Very thin|cell phone|   6000|           0|
|Ultra thin|cell phone|   5000|        1000|
|  Bendable|cell phone|   3000|        3000|
|  Foldable|cell phone|   3000|        3000|
+----------+----------+-------+------------+




#Example Window - HandsOn - Running Total
#The running total is the sum of all previous lines including the current one.

sales = sc.parallelize([
  (0, 0, 0, 5),
  (1, 0, 1, 3),
  (2, 0, 2, 1),
  (3, 1, 0, 2),
  (4, 2, 0, 8),
  (5, 2, 2, 8)].toDF(["id", "orderID", "prodID", "orderQty"])

> sales.show()
+---+-------+------+--------+
| id|orderID|prodID|orderQty|
+---+-------+------+--------+
|  0|      0|     0|       5|
|  1|      0|     1|       3|
|  2|      0|     2|       1|
|  3|      1|     0|       2|
|  4|      2|     0|       8|
|  5|      2|     2|       8|
+---+-------+------+--------+

orderedByID = Window.orderBy('id')

totalQty = sum('orderQty').over(orderedByID).alias('running_total')
salesTotalQty = sales.select('*', totalQty).orderBy('id')  #'

> salesTotalQty.show
16/04/10 23:01:52 WARN Window: No Partition Defined for Window operation! Moving all data to a single partition, this can cause serious performance degradation.
+---+-------+------+--------+-------------+
| id|orderID|prodID|orderQty|running_total|
+---+-------+------+--------+-------------+
|  0|      0|     0|       5|            5|
|  1|      0|     1|       3|            8|
|  2|      0|     2|       1|            9|
|  3|      1|     0|       2|           11|
|  4|      2|     0|       8|           19|
|  5|      2|     2|       8|           27|
+---+-------+------+--------+-------------+

byOrderId = orderedByID.partitionBy('orderID')
totalQtyPerOrder = sum('orderQty').over(byOrderId).alias('running_total_per_order')
salesTotalQtyPerOrder = sales.select('*', totalQtyPerOrder).orderBy('id') #'

scala> salesTotalQtyPerOrder.show()
+---+-------+------+--------+-----------------------+
| id|orderID|prodID|orderQty|running_total_per_order|
+---+-------+------+--------+-----------------------+
|  0|      0|     0|       5|                      5|
|  1|      0|     1|       3|                      8|
|  2|      0|     2|       1|                      9|
|  3|      1|     0|       2|                      2|
|  4|      2|     0|       8|                      8|
|  5|      2|     2|       8|                     16|
+---+-------+------+--------+-----------------------+

###UDF - Python --WORKSHOP --IMP  (udf)
UDFs created using SQL are registered in Unity Catalog and have associated permissions,
whereas UDFs created within your notebook are session-based and are scoped to the current SparkSession.

You can define and access session-based UDFs using any language supported by Databricks.
UDFs can be scalar or non-scalar.

Currently only SQL and Python scalar UDFs registered in Unity Catalog are available in DBSQL.

Session scoped UDF - use decorator in python
For all sessions and in SQL - use SQL create function with python as language

##Scalar UDFs
Scalar UDFs operate on a single row and return a single value for each row.

df = spark.createDataFrame([("alice",10.0),
("bob",20.0),
("carol",30.0),
("dave",40.0),
("eve",50.0),], ["name","score"])

df.createOrReplaceTempView("marks")

#Check
https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-syntax-ddl-create-sql-function
#for dependencies of python function
Check
https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-function-invocation#named-parameter-invocation


-- Create a SQL UDF for name length
spark.sql("""
CREATE OR REPLACE FUNCTION get_name_length(name STRING) RETURNS INT
RETURN LENGTH(name)
""")

-- Use the UDF in a SQL query
spark.sql("""
SELECT name, get_name_length(name) AS name_length
FROM marks
""").show()

+-------+-------+-------------+
| name  | score | name_length |
+-------+-------+-------------+
| alice |  10.0 |      5      |
|  bob  |  20.0 |      3      |
| carol |  30.0 |      5      |
| dave  |  40.0 |      4      |
|  eve  |  50.0 |      3      |
+-------+-------+-------------+

To implement this in a Databricks notebook using PySpark:


from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType

@udf(returnType=IntegerType())
def get_name_length(name):
   return len(name)

df = df.withColumn("name_length", get_name_length(df.name))

# Show the result
display(df)


DROP [ TEMPORARY ] FUNCTION [ IF EXISTS ] function_name
DROP FUNCTION IF EXISTS get_name_length;


##User-defined aggregate functions (UDAFs)
User-defined aggregate functions (UDAFs) operate on multiple rows
and return a single aggregated result. I

from pyspark.sql.functions import pandas_udf
from pyspark.sql import SparkSession
import pandas as pd

# Define a pandas UDF for aggregating scores
@pandas_udf("int")  # Return type
def total_score_udf(scores: pd.Series) -> int:
    return scores.sum()

# Group by name length and aggregate
result_df = (df.groupBy("name_length")
              .agg(total_score_udf(df["score"]).alias("total_score")))

display(result_df)

+-------------+-------------+
| name_length | total_score |
+-------------+-------------+
|      3      |     70.0    |
|      4      |     40.0    |
|      5      |     40.0    |
+-------------+-------------+

##Python UDTF
Python UDTFs are available in Databricks Runtime 14.3 LTS and above.

Python user-defined table functions (UDTFs) can return multiple rows and columns for each input row.

In the following example, each value in the score column corresponds to a list of categories.
A UDTF is defined to split the comma separated list into multiple rows.


+-------+-------+-----------------+
| name  | score |   categories    |
+-------+-------+-----------------+
| alice |  10.0 |  math,science   |
|  bob  |  20.0 |  history,math   |
| carol |  30.0 | science,history |
| dave  |  40.0 |    math,art     |
|  eve  |  50.0 |  science,art    |
+-------+-------+-----------------+




from pyspark.sql.functions import udtf

@udtf(returnType="score: int, categories: string, name: string")
class ScoreCategoriesUDTF:
    def eval(self, name: str, score: float, categories: str):
        category_list = categories.split(',')
        for category in category_list:
            yield (name, score, category)

# Apply the UDTF
result_df = df.select(ScoreCategoriesUDTF(df.score, df.categories, df.name))
display(result_df)

+-------+-------+----------+
| name  | score | category |
+-------+-------+----------+
| alice |  10.0 |   math   |
| alice |  10.0 | science  |
|  bob  |  20.0 | history  |
|  bob  |  20.0 |   math   |
| carol |  30.0 | science  |
| carol |  30.0 | history  |
| dave  |  40.0 |   math   |
| dave  |  40.0 |   art    |
|  eve  |  50.0 | science  |
|  eve  |  50.0 |   art    |
+-------+-------+----------+


##Details of Creating UDFs in Unity Catalog
To create a UDF in Unity Catalog, users need USAGE and CREATE permission on the schema
and USAGE permission on the catalog.

To run a UDF, users need EXECUTE permission on the UDF.
Users also need USAGE permission on the schema and catalog.


CREATE OR REPLACE FUNCTION my_catalog.my_schema.calculate_bmi(weight DOUBLE, height DOUBLE)
RETURNS DOUBLE
LANGUAGE SQL
AS
SELECT weight / (height * height);

Python UDFs for Unity Catalog use statements offset by double dollar signs ($$).
You also need to specify a data type mapping.
The following example registers a UDF that calculates body mass index:


CREATE FUNCTION my_catalog.my_schema.calculate_bmi(weight_kg DOUBLE, height_m DOUBLE)
RETURNS DOUBLE
LANGUAGE PYTHON
AS $$
return weight_kg / (height_m ** 2)
$$;

You can now use this Unity Catalog function in your SQL queries or PySpark code:

df = spark.createDataFrame([("alice",10.0),
("bob",20.0, 1.0),
("carol",30.0, 1.2),
("dave",40.0, 1.4),
("eve",50.0, 0.5),], ["person_id","weight_kg", "height_m"])

df.createOrReplaceTempView("person_data")


SELECT person_id, my_catalog.my_schema.calculate_bmi(weight_kg, height_m) AS bmi
FROM person_data;

##Using the Unity Catalog UDF in PySpark
from pyspark.sql.functions import expr

result = df.withColumn("bmi", expr("my_catalog.my_schema.calculate_bmi(weight_kg, height_m)"))
display(result)

##Extend UDFs using custom dependencies
You can extend the functionality of Unity Catalog Python UDFs beyond the Databricks Runtime
environment by defining custom dependencies for external libraries.

Dependencies can be installed from the following sources:
    PyPi packages
    Files stored in Unity Catalog volumes
        The user invoking the UDF must have READ VOLUME permissions
        on the source volume.
    Files hosted on S3 using pre-signed URLs

Custom dependencies for Unity Catalog UDFs are supported on the following compute types:
    Serverless compute
    All-purpose compute using Databricks Runtime version 16.2 and above
    SQL warehouse classic or pro

Use the ENVIRONMENT section of the UDF definition to specify dependencies:

##Call python UDF in SQL - must register
Note this is session scoped  so not shared so can not be used in SQL notebook
outside this session. To create shareable one, Use SQL syntax and Unity catalog

def squared(s):
  return s * s
spark.udf.register("squaredWithPython", squared)

You can optionally set the return type of your UDF. The default return type is StringType.


from pyspark.sql.types import LongType
def squared_typed(s):
  return s * s
spark.udf.register("squaredWithPython", squared_typed, LongType())

Call the UDF in Spark SQL

spark.range(1, 20).createOrReplaceTempView("test")

Below SQL OK as it is in the same session

%sql select id, squaredWithPython(id) as id_squared from test

Use UDF with DataFrames


from pyspark.sql.functions import udf
from pyspark.sql.types import LongType
squared_udf = udf(squared, LongType())
df = spark.table("test")
display(df.select("id", squared_udf("id").alias("id_squared")))

Alternatively, you can declare the same UDF using annotation syntax:


from pyspark.sql.functions import udf
@udf("long")
def squared_udf(s):
  return s * s
df = spark.table("test")
display(df.select("id", squared_udf("id").alias("id_squared")))


###Autoloaders --WORKSHOP --IMP (autoloader)
Use DLT to build ETL pipelines. Databricks created DLT to reduce the complexity of
building, deploying, and maintaining production ETL pipelines.
https://learn.microsoft.com/en-us/azure/databricks/dlt/tutorial-pipelines

You can also use the Databricks Terraform provider to create this article's resources.
See Create clusters, notebooks, and jobs with Terraform.
https://learn.microsoft.com/en-us/azure/databricks/dev-tools/terraform/cluster-notebook-job

Step 1: Create a cluster
To do exploratory data analysis and data engineering,
create a cluster to provide the compute resources needed to execute commands.

    Click compute icon Compute in the sidebar.
    On the Compute page, click Create Cluster. This opens the New Cluster page.
    Specify a unique name for the cluster, leave the remaining values in their default state,
    and click Create Cluster.


Step 2: Create a Databricks notebook
To create a notebook in your workspace, click New Icon New in the sidebar,
and then click Notebook. A blank notebook opens in the workspace.


Step 3: Configure Auto Loader to ingest data to Delta Lake


# Import functions
from pyspark.sql.functions import col, current_timestamp

# Define variables used in code below
file_path = "/databricks-datasets/structured-streaming/events"
username = "ndas"  #spark.sql("SELECT regexp_replace(current_user(), '[^a-zA-Z0-9]', '_')").first()[0]
table_name = f"{username}_etl_quickstart"
checkpoint_path = f"/Volumes/workspace/default/check_volume/check3"

# Clear out data from previous demo execution
spark.sql(f"DROP TABLE IF EXISTS {table_name}")
dbutils.fs.rm(checkpoint_path, True)

dbutils.fs.ls(file_path)

# Configure Auto Loader to ingest JSON data to a Delta table
#availableNow is called incremental batch loading
#Again run, then delta input will be ingested , dont delete checkpointLocation
(spark.readStream
  .format("cloudFiles")
  .option("cloudFiles.format", "json")                  #Must
  .option("cloudFiles.schemaLocation", checkpoint_path) #Must
  .load(file_path)
  .select("*", col("_metadata.file_path").alias("source_file"), current_timestamp().alias("processing_time"))
  .writeStream
  .option("checkpointLocation", checkpoint_path)
  .trigger(availableNow=True)
  .toTable(table_name))

#Many options
https://learn.microsoft.com/en-us/azure/databricks/ingestion/cloud-object-storage/auto-loader/options

#Input-json file, output- delta table
#Use autoloader
(spark
    # Configure Autoloader to read json files
    .readStream

    #schema is tags-string, version - int
    .schema("tags string, version int")

    #Autoloader format
    .format("cloudFiles")

    #file type json
    .option("cloudFiles.format", "json")

    #track of data schema over time
    .option("cloudFiles.schemaLocation", checkpoint_path)

    #By default json fields are of type String
    #Use this option to infer types like spark
    .option("cloudFiles.inferColumnTypes", True)

    #Give rescued as rescued data column
    #by default the column name is _rescued_data
    .option("rescuedDataColumn", "rescued")

     #Give schema hints tags-string, version - int
     #This is not required as already schema is provided
    .option("cloudFiles.schemaHints", "tags string, version int")

    #Provide evolution mode as none
    #This is default because schema is provided
    #if that is not provided, the default is addNewColumns
    .option("cloudFiles.schemaEvolutionMode", "none")

    #Make case sensitivity True,
    #by default it is true, so really not required
    .option("readerCaseSensitive", True)

    #Provide date and hour as partition columns
    .option("cloudFiles.partitionColumns", "date,hour")

    #Read existing files when starting up
    #After that these file will never be read up
    #because of checkpoint
    #By default True, so really not required
    .option("cloudFiles.includeExistingFiles", True)

    #Make 90 days for tracking file
    #for deduplication purposes
    .option("cloudFiles.maxFileAge", "90 days")

    #per trigger, read 1000 files
    #this is default hence not really required
    .option("cloudFiles.maxFilesPerTrigger", 1000)

    #ignore corrupt files , by default false
    .option("ignoreCorruptFiles", True)
    #Load
    .load(file_path)

    #select all columns and also make one column
    #processing time based on current timestamp
    .select("*", current_timestamp().alias("processing_time"))

    #Write back
    .writeStream

    #Provide query1 as name for debugging purpose
    .queryName("query1")

    #make check point available
    .option("checkpointLocation", checkpoint_path)

    #process all available data once
    .trigger(availableNow=True)

    #outputs to delta table table_name
    .toTable(table_name))


In above case, The rescued data column contains
    Missing columns
    Type mismatches.
    Case mismatches.

In above case,  the columns abc, Abc, and ABC are considered the different column.

#https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/functions/read_files
#Reads JSON files
#and overrides the data type of the column `id` to integer.
inferColumnTypes

spark.sql(f"""
  SELECT * FROM read_files(
    '{file_path}',
    format => 'json',
    schemaLocation => '{checkpoint_path}'
    schemaHints => 'id int')
  """)

cloudFiles.allowOverwrites false
    Whether to allow input directory file changes to overwrite existing data

cloudFiles.schemaLocation enables schema inference  and evolution
    for json and CSV, inferred schema is STRING

set the option cloudFiles.inferColumnTypes to True.
    for spark like schema inference else for CSV and JSON
    column type will be STRING

.schema("<schema>")
    provide exact schema as DDL string

.option("cloudFiles.schemaHints", "tags map<string,string>, version int")
    when no exact schema, but provide hints

cloudFiles.includeExistingFiles  True
    Whether to include existing files in the stream processing input path
    or to only process new files arriving after initial setup.
    This option is evaluated only when you start a stream for the first time.

cloudFiles.maxFileAge None
    How long a file event is tracked for deduplication purposes.



Step 4: Process and interact with data

Notebooks execute logic cell-by-cell. To execute the logic in your cell:

    To run the cell you completed in the previous step, select the cell and press SHIFT+ENTER.

    To query the table you've just created, copy and paste the following code into an empty cell,
    then press SHIFT+ENTER to run the cell.

df = spark.read.table(table_name)
display(df)


Step 5: Schedule a job
You can run Databricks notebooks as production scripts by adding them as a task
in a Databricks job. In this step, you will create a new job that you can trigger manually.

To schedule your notebook as a task:

    Click Schedule on the right side of the header bar.
    Enter a unique name for the Job name.
    Click Manual or give Schedule(advancted Tab requires Cron syntax)
    In the Cluster drop-down, select the cluster you created in step 1.
    Click Create.
    In the window that appears, click Run now.
    To see the job run results, click the External Link icon next to the Last run timestamp.

###Build an ETL pipeline with Lakeflow Declarative Pipelines --WORKSHOP --IMP  (dlt)
You can use fully declarative SQL syntax in Databricks SQL to register and set refresh schedules
for materialized views and streaming tables as Unity Catalog-managed objects.
See Use materialized views in Databricks SQL and Load data using streaming tables in Databricks SQL.
https://learn.microsoft.com/en-us/azure/databricks/dlt/configure-pipeline
https://learn.microsoft.com/en-us/azure/databricks/views/materialized
https://learn.microsoft.com/en-us/azure/databricks/tables/streaming


Use expectations to apply quality constraints that validate data as it flows through ETL pipelines.
Expectations provide greater insight into data quality metrics and allow you to fail updates
or drop records when detecting invalid records.

This code demonstrates a simplified example of the medallion architecture.
https://health.data.ny.gov/Health/Baby-Names-Beginning-2007/jxy9-yhdk/about_data
https://learn.microsoft.com/en-us/azure/databricks/dlt/expectations
https://learn.microsoft.com/en-us/azure/databricks/lakehouse/medallion

Step 1: Create a pipeline
DLT creates pipelines by resolving dependencies defined in notebooks or files
(called source code) using DLT syntax. Each source code file can contain only one language,
but you can add multiple language-specific notebooks or files in the pipeline.

The instructions in this tutorial use serverless compute and Unity Catalog.
Use the default settings for all configuration options not specified in these instructions.

If serverless is not enabled or supported in your workspace,
you can complete the tutorial as written using default compute settings.
You must manually select Unity Catalog under Storage options in the Destination
section of the Create pipeline UI.

Some sample Code
    -- This file defines a sample transformation.
    -- Edit the sample below or add new transformations
    -- using "+ Add" in the file browser.
    USE CATALOG `workspace`;
    USE SCHEMA `default`;
    CREATE MATERIALIZED VIEW `sample_trips_pipeline1` AS
    SELECT
        pickup_zip,
        fare_amount
    FROM samples.nyctaxi.trips;

    CREATE MATERIALIZED VIEW `sample_zones_pipeline1` AS
    SELECT
        pickup_zip,
        SUM(fare_amount) AS total_fare
    FROM `sample_trips_pipeline1`
    GROUP BY pickup_zip;

    Use Run file to run and preview a single transformation.
    Use Run pipeline to run all transformations in the entire pipeline.
    Use + Add in the file browser to add a new data set definition.
    Use Schedule to run the pipeline on a sched

    -- !!! Before performing any data analysis, make sure to run the pipeline to materialize the
    --sample datasets. The tables referenced in this notebook depend on that step.
    USE CATALOG `workspace`;
    USE SCHEMA `default`;
    SELECT * from `sample_trips_pipeline1`;

    In Notebook, CREATE MV automically
    gives option create pipeline
    Without pipeline, view will not be refreshed (eg in notebook REFRESH gives error)
    Click Create Pipeline with below conf (select JSON) in UI
    {
    "development": true,
    "continuous": false,
    "channel": "PREVIEW",
    "photon": true,
    "libraries": [],
    "name": "Pipeline2",
    "serverless": true,
    "catalog": "workspace",
    "schema": "default",
    "data_sampling": false
   }
   Check
   https://docs.databricks.com/aws/en/dlt/properties

To configure a new pipeline, do the following(in old UI):
    In the sidebar, click DLT.
    Click Create pipeline.
    In Pipeline name, type a unique pipeline name.
    Select the Serverless checkbox.
    In Destination, to configure a Unity Catalog location where tables are published,
        select a Catalog and a Schema.
    In Advanced, click Add configuration and then define pipeline parameters for the catalog,
    schema, and volume to which you downloaded data using the following parameter names:
        my_catalog
            workspace
        my_schema
            default
        my_volume
            Create a new volume as default_volume
    Click Create.

In New UI:
    Give Pipeline Name
    and start with single transformation file under Advanced
    Then Create and change all above configurations in Settings

The pipelines UI appears for the new pipeline.
A source code notebook is automatically created and configured for the pipeline.

The notebook is created in a new directory in your user directory.
The name of the new directory and file match the name of your pipeline.
For example, /Users/your.username@databricks.com/my_pipeline/my_pipeline.


Step 2: Declare materialized views and streaming tables in a notebook with Python or SQL

You must attach your notebook to the pipeline to use this functionality.

To attach your newly created notebook to the pipeline you just created:
    Click Connect in the upper-right to open the compute configuration menu.
    Hover over the name of the pipeline you created in Step 1.
    Click Connect.

The UI changes to include Validate and Start buttons in the upper-right.

Important
    DLT pipelines evaluate all cells in a notebook during planning.
    Unlike notebooks that are run against all-purpose compute or scheduled as jobs,
    pipelines do not guarantee that cells run in the specified order.

    Notebooks can only contain a single programming language.
    Do not mix Python and SQL code in pipeline source code notebooks.

For details on developing code with Python or SQL, see Develop pipeline code with Python or Develop pipeline code with SQL.
    https://learn.microsoft.com/en-us/azure/databricks/dlt-ref/python-ref
    https://learn.microsoft.com/en-us/azure/databricks/dlt/sql-dev
    https://learn.microsoft.com/en-us/azure/databricks/dlt-ref/sql-ref
    https://learn.microsoft.com/en-us/azure/databricks/dlt/external-dependencies
Examples of Apache Spark operations that should never be used in DLT code:
    collect()
    count()
    toPandas()
    save()
    saveAsTable()
    start()
    toTable()


Step 0: Download data
(do it in seperate notebook because
'CreateNamespace' is not supported in spark.sql("...") API in DLT Python.
Supported command: `SELECT`, `DESCRIBE`, `SHOW TABLES`, `SHOW TBLPROPERTIES`,
`SHOW NAMESPACES`, `SHOW COLUMNS IN`, `SHOW FUNCTIONS`, `SHOW VIEWS`, `SHOW CATALOGS`,
`SHOW CREATE TABLE`, `USE SCHEMA`, `USE CATALOG`.
UNSUPPORTED_SPARK_SQL_COMMAND'CreateNamespace' is not supported in spark.sql("...") API in DLT Python. Supported command: `SELECT`, `DESCRIBE`, `SHOW TABLES`, `SHOW TBLPROPERTIES`, `SHOW NAMESPACES`, `SHOW COLUMNS IN`, `SHOW FUNCTIONS`, `SHOW VIEWS`, `SHOW CATALOGS`, `SHOW CREATE TABLE`, `USE SCHEMA`, `USE CATALOG`.
)


my_catalog = "workspace"
my_schema = "default"
my_volume = "default_volume"

#spark.sql(f"CREATE SCHEMA IF NOT EXISTS {my_catalog}.{my_schema}")
#spark.sql(f"CREATE VOLUME IF NOT EXISTS {my_catalog}.{my_schema}.{my_volume}")

volume_path = f"/Volumes/{my_catalog}/{my_schema}/{my_volume}/"
download_url = "https://health.data.ny.gov/api/views/jxy9-yhdk/rows.csv"
filename = "babynames.csv"

dbutils.fs.cp(download_url, volume_path + filename)


Example pipeline code - create Two files, first file
https://docs.databricks.com/notebooks/source/dlt-babynames-python.html
# Import modules

import dlt
from pyspark.sql.functions import *

# Assign pipeline parameters to variables

my_catalog = spark.conf.get("my_catalog")
my_schema = spark.conf.get("my_schema")
my_volume = spark.conf.get("my_volume")

# Define the path to source data

volume_path = f"/Volumes/{my_catalog}/{my_schema}/{my_volume}/"

#Our code
@dlt.table(
  comment="Popular baby first names in New York. This data was ingested from the New York State Department of Health."
)
def baby_names_raw():
    df = (spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("inferSchema", True)
    .option("header", True)
    .load(volume_path)
    )
    df_renamed_column = df.withColumnRenamed("First Name", "First_Name")
    return df_renamed_column

#2nd files
import dlt
from pyspark.sql.functions import *

# Assign pipeline parameters to variables

my_catalog = spark.conf.get("my_catalog")
my_schema = spark.conf.get("my_schema")
my_volume = spark.conf.get("my_volume")

# Define the path to source data
volume_path = f"/Volumes/{my_catalog}/{my_schema}/{my_volume}/"



# Define a materialized view that validates data and renames a column
#See the function name becomes table names
#An expectation name must be unique for a given datase
@dlt.table(
  comment="New York popular baby first name data cleaned and prepared for analysis."
)
@dlt.expect("valid_first_name", "First_Name IS NOT NULL")
@dlt.expect_or_fail("valid_count", "Count > 0")
def baby_names_prepared():
    return (
    spark.read.table("baby_names_raw")
        .withColumnRenamed("Year", "Year_Of_Birth")
        .select("Year_Of_Birth", "First_Name", "Count")
    )

# Define a materialized view that has a filtered, aggregated, and sorted view of the data

@dlt.table(
  comment="A table summarizing counts of the top baby names for New York for 2021."
)
def top_baby_names_2021():
    return (
    spark.read.table("baby_names_prepared")
        .filter(expr("Year_Of_Birth == 2021"))
        .groupBy("First_Name")
        .agg(sum("Count").alias("Total_Count"))
        .sort(desc("Total_Count"))
        .limit(10)
    )

Check in Table view in bottom window
top_baby_names_2021
Also can be refreshed again
Dont do full refresh as it will truncate the data
and do it from the begining

Then check in some notebook
or add exploration folder of pipeline
%sql
select * from top_baby_names_2021;

Then change the file name
filename = "babynames2.csv"
Do the download and then refresh

OR SQL
-- Define a streaming table to ingest data from a volume

CREATE OR REFRESH STREAMING TABLE baby_names_raw
COMMENT "Popular baby first names in New York. This data was ingested from the New York State Department of Health."
AS SELECT Year, `First Name` AS First_Name, County, Sex, Count
FROM STREAM(read_files(
  '/Volumes/${my_catalog}/${my_schema}/${my_volume}/babynames.csv',
  in DBC
  "/mnt/user_data/babynames.csv"
  format => 'csv',
  header => True,
  mode => 'FAILFAST'));

-- Define a materialized view that validates data and renames a column

CREATE OR REFRESH MATERIALIZED VIEW baby_names_prepared(
  CONSTRAINT valid_first_name EXPECT (First_Name IS NOT NULL),
  CONSTRAINT valid_count EXPECT (Count > 0) ON VIOLATION FAIL UPDATE
)
COMMENT "New York popular baby first name data cleaned and prepared for analysis."
AS SELECT
  Year AS Year_Of_Birth,
  First_Name,
  Count
FROM baby_names_raw;

-- Define a materialized view that provides a filtered, aggregated, and sorted view of the data

CREATE OR REFRESH MATERIALIZED VIEW top_baby_names_2021
COMMENT "A table summarizing counts of the top baby names for New York for 2021."
AS SELECT
  First_Name,
  SUM(Count) AS Total_Count
FROM baby_names_prepared
WHERE Year_Of_Birth = 2021
GROUP BY First_Name
ORDER BY Total_Count DESC
LIMIT 10;

To view expectation metrics, complete the following steps:

    Click DLT in the sidebar.
    Click the Name of your pipeline.
    Click a dataset with an expectation defined.
    Select the Data quality tab in the right sidebar.
You can view data quality metrics by querying the DLT event log
    dropped_records
        The number of records that were dropped because they failed one or more expectations.
    passed_records
        The number of records that passed the expectation criteria.
    failed_records
        The number of records that failed the expectation criteria.
    https://learn.microsoft.com/en-us/azure/databricks/dlt/observability
        From event log
            Query data quality from the event log
            Query lineage information from the event log
            Query Auto Loader events from the event log
            Monitor data backlog by querying the event log
            Monitor enhanced autoscaling events from the event log for pipelines without serverless enabled
            Monitor compute resource utilization
            Audit DLT pipelines
            Query user actions in the event log
            Runtime information

Step 3: Start a pipeline update

To start a pipeline update, click the Start button in the top right of the notebook UI.

To import a notebook, complete the following steps:
    Open the notebook UI.
        Click + New > Notebook.
        An empty notebook opens.
    Click File > Import…. The Import dialog appears.
    Select the URL option for Import from.
    Paste the URL of the notebook.
    Click Import.

This article shows how to convert an existing DLT pipeline into a Databricks Asset Bundles project.
Bundles enable you to define and manage your Azure Databricks data processing configuration in a
single, source-controlled YAML file that provides easier maintenance and enables automated deployment
to target environments.
Check
https://learn.microsoft.com/en-us/azure/databricks/dlt/convert-to-dab

Step 4: Create a job to run the pipeline

Next, create a workflow to automate data ingestion, processing,
and analysis steps using a Databricks job.

    In your workspace, click Workflows icon. Jobs & Pipelines in the sidebar.
    Under New, click Job.

    In the task title box, replace New Job <date and time> with your job name.
    For example, Songs workflow.
    In Task name, enter a name for the first task, for example, ETL_songs_data.
    In Type, select Pipeline.
    In Pipeline, select the pipeline you created in step 1.
    Click Create.

    To run the workflow, click Run Now.
    To view the details for the run, click the Runs tab. Click the task to view details
    for the task run.

    To view the results when the workflow is completed, click Go to the latest successful run
    or the Start time for the job run.
    The Output page appears and displays the query results.

    See Monitoring and observability for Lakeflow Jobs for more information about job runs.
    https://docs.databricks.com/aws/en/jobs/monitor

Step 5: Schedule the pipeline job

To run the ETL pipeline on a schedule, follow these steps:
    Navigate to the Jobs & Pipelines UI in the same Databricks workspace as the job.
    Optionally, select the Jobs and Owned by me filters.

    In the Name column, click the job name. The side panel displays the Job details.
    Click Add trigger in the Schedules & Triggers panel
    and select Scheduled in Trigger type.

    Specify the period, starting time, and time zone.
    Click Save.

    Note Trigger vs Continuous mode
    https://docs.databricks.com/aws/en/dlt/pipeline-mode
    You set pipelines.trigger.interval on a table using spark_conf in Python or SET in SQL:
    Python

    @dlt.table(
      spark_conf={"pipelines.trigger.interval" : "10 seconds"}
    )
    def <function-name>():
        return (<query>)

    SQL

    SET pipelines.trigger.interval=10 seconds;

    CREATE OR REFRESH MATERIALIZED VIEW TABLE_NAME
    AS SELECT ...

    To set pipelines.trigger.interval on a pipeline, add it to the configuration object
    in the pipeline settings:
    JSON

    {
      "configuration": {
        "pipelines.trigger.interval": "10 seconds"
      }
    }

##Reference
The syntax is
https://learn.microsoft.com/en-us/azure/databricks/dlt/python-ref
To define a materialized view in Python, apply @table to a query that performs a static read
against a data source. To define a streaming table, apply @table to a query that performs
a streaming read against a data source or use the create_streaming_table() function


import dlt

@dlt.table(
  name="<name>",
  comment="<comment>",
  spark_conf={"<key>" : "<value>", "<key>" : "<value>"},
  table_properties={"<key>" : "<value>", "<key>" : "<value>"},
  path="<storage-location-path>",
  partition_cols=["<partition-column>", "<partition-column>"],
  cluster_by = ["<clustering-column>", "<clustering-column>"],
  schema="schema-definition",
  row_filter = "row-filter-clause",
  temporary=False)
@dlt.expect
@dlt.expect_or_fail
@dlt.expect_or_drop
@dlt.expect_all
@dlt.expect_all_or_drop
@dlt.expect_all_or_fail
def <function-name>():
    return (<query>)

OR Create a view
import dlt

@dlt.view(
  name="<name>",
  comment="<comment>")
@dlt.expect
@dlt.expect_or_fail
@dlt.expect_or_drop
@dlt.expect_all
@dlt.expect_all_or_drop
@dlt.expect_all_or_fail
def <function-name>():
    return (<query>)

# Define a streaming table to ingest data from a volume
@expect("description", "constraint")
@expect_or_drop("description", "constraint")
@expect_or_fail("description", "constraint")
    By default, check , but still add the row
    _drop means dont add the row
    _fail means stops the execution

@expect_all(expectations)
@expect_all_or_drop(expectations)
@expect_all_or_fail(expectations)
    expectations is a Python dictionary
    any constraint fails, add/drop/stop

Action      SQL syntax      Python syntax       Result
warn (default)
	EXPECT
	dlt.expect
	Invalid records are written to the target.

drop
	EXPECT ... ON VIOLATION DROP ROW
	dlt.expect_or_drop
	Invalid records are dropped before data is written to the target.
    The count of dropped records is logged alongside other dataset metrics.

fail
	EXPECT ... ON VIOLATION FAIL UPDATE
	dlt.expect_or_fail
	Invalid records prevent the update from succeeding.
    Manual intervention is required before reprocessing.
    This expectation causes a failure of a single flow and does not cause other flows in your pipeline
    to fail.
#Example
-- Simple constraint
CONSTRAINT non_negative_price EXPECT (price >= 0)

-- SQL functions
CONSTRAINT valid_date EXPECT (year(transaction_date) >= 2020)

-- CASE statements
CONSTRAINT valid_order_status EXPECT (
  CASE
    WHEN type = 'ORDER' THEN status IN ('PENDING', 'COMPLETED', 'CANCELLED')
    WHEN type = 'REFUND' THEN status IN ('PENDING', 'APPROVED', 'REJECTED')
    ELSE false
  END
)

-- Multiple constraints
CONSTRAINT non_negative_price EXPECT (price >= 0)
CONSTRAINT valid_purchase_date EXPECT (date <= current_date())

-- Complex business logic
CONSTRAINT valid_subscription_dates EXPECT (
  start_date <= end_date
  AND end_date <= current_date()
  AND start_date >= '2020-01-01'
)

-- Complex boolean logic
CONSTRAINT valid_order_state EXPECT (
  (status = 'ACTIVE' AND balance > 0)
  OR (status = 'PENDING' AND created_date > current_date() - INTERVAL 7 DAYS)
)
#Example
# Simple constraint
@dlt.expect("non_negative_price", "price >= 0")

# SQL functions
@dlt.expect("valid_date", "year(transaction_date) >= 2020")

# CASE statements
@dlt.expect("valid_order_status", """
   CASE
     WHEN type = 'ORDER' THEN status IN ('PENDING', 'COMPLETED', 'CANCELLED')
     WHEN type = 'REFUND' THEN status IN ('PENDING', 'APPROVED', 'REJECTED')
     ELSE false
   END
""")

# Multiple constraints
@dlt.expect("non_negative_price", "price >= 0")
@dlt.expect("valid_purchase_date", "date <= current_date()")

# Complex business logic
@dlt.expect(
  "valid_subscription_dates",
  """start_date <= end_date
    AND end_date <= current_date()
    AND start_date >= '2020-01-01'"""
)

# Complex boolean logic
@dlt.expect("valid_order_state", """
   (status = 'ACTIVE' AND balance > 0)
   OR (status = 'PENDING' AND created_date > current_date() - INTERVAL 7 DAYS)
""")


###*** Advanced SQL HOF --WORKSHOP --IMP  (sqlhof)
Lambda functions

{ param -> expr |
  (param1 [, ...] ) -> expr }

Examples

The array_sort function function expects a lambda function with two parameters. The parameter types will be the type of the elements of the array to be sorted. The expression is expected to return an INTEGER where -1 means param1 < param2, 0 means param1 = param2, and 1 otherwise.

To sort an ARRAY of STRING in a right to left lexical order, you can use the following lambda function.
SQL

(p1, p2) -> CASE WHEN p1 = p2 THEN 0
                 WHEN reverse(p1) < reverse(p2) THEN -1
                 ELSE 1 END

Lambda functions are defined and used ad hoc. So the function definition is the argument:
SQL

> SELECT array_sort(array('Hello', 'World'),
  (p1, p2) -> CASE WHEN p1 = p2 THEN 0
              WHEN reverse(p1) < reverse(p2) THEN -1
              ELSE 1 END);
[World, Hello]

More Reference
aggregate(expr, start, merge [, finish])

> SELECT aggregate(array(1, 2, 3), 0, (acc, x) -> acc + x);
 6
> SELECT aggregate(array(1, 2, 3), 0, (acc, x) -> acc + x, acc -> acc * 10);
 60

> SELECT aggregate(array(1, 2, 3, 4),
                   named_struct('sum', 0, 'cnt', 0),
                   (acc, x) -> named_struct('sum', acc.sum + x, 'cnt', acc.cnt + 1),
                   acc -> acc.sum / acc.cnt) AS avg
 1.5


array_sort(array, func)
> SELECT array_sort(array(5, 6, 1),
                   (left, right) -> CASE WHEN left < right THEN -1
                                         WHEN left > right THEN 1 ELSE 0 END);
 [1,5,6]
> SELECT array_sort(array('bc', 'ab', 'dc'),
                    (left, right) -> CASE WHEN left IS NULL and right IS NULL THEN 0
                                          WHEN left IS NULL THEN -1
                                          WHEN right IS NULL THEN 1
                                          WHEN left < right THEN 1
                                          WHEN left > right THEN -1 ELSE 0 END);
 [dc,bc,ab]
> SELECT array_sort(array('b', 'd', null, 'c', 'a'));
 [a,b,c,d,NULL]

exists(expr, func)

exists(query)

> SELECT exists(array(1, 2, 3), x -> x % 2 == 0);
 True
> SELECT exists(array(1, 2, 3), x -> x % 2 == 10);
 false
> SELECT exists(array(1, NULL, 3), x -> x % 2 == 0);
 NULL
> SELECT exists(array(0, NULL, 2, 3, NULL), x -> x IS NULL);
 True
> SELECT exists(array(1, 2, 3), x -> x IS NULL);
 false

> SELECT count(*) FROM VALUES(1)
   WHERE exists(SELECT * FROM VALUES(1), (2), (3) AS t(c1) WHERE c1 = 2);
  1
> SELECT count(*) FROM VALUES(1)
   WHERE exists(SELECT * FROM VALUES(1), (NULL), (3) AS t(c1) WHERE c1 = 2);
  0
> SELECT count(*) FROM VALUES(1)
     WHERE NOT exists(SELECT * FROM VALUES(1), (NULL), (3) AS t(c1) WHERE c1 = 2);
  1

filter(expr, func)
> SELECT filter(array(1, 2, 3), x -> x % 2 == 1);
 [1,3]
> SELECT filter(array(0, 2, 3), (x, i) -> x > i);
 [2,3]
> SELECT filter(array(0, null, 2, 3, null), x -> x IS NOT NULL);
 [0,2,3]

forall(expr, func)
> SELECT forall(array(1, 2, 3), x -> x % 2 == 0);
 false
> SELECT forall(array(2, 4, 8), x -> x % 2 == 0);
 True
> SELECT forall(array(1, NULL, 3), x -> x % 2 == 0);
 false
> SELECT forall(array(2, NULL, 8), x -> x % 2 == 0);
 NULL


 map_filter(expr, func)

> SELECT map_filter(map(1, 0, 2, 2, 3, -1), (k, v) -> k > v);
  {1 -> 0, 3 -> -1}

map_zip_with(map1, map2, func)
> SELECT map_zip_with(map(1, 'a', 2, 'b'), map(1, 'x', 2, 'y'), (k, v1, v2) -> concat(v1, v2));
 {1 -> ax, 2 -> by}

transform(expr, func)

> SELECT transform(array(1, 2, 3), x -> x + 1);
 [2,3,4]
> SELECT transform(array(1, 2, 3), (x, i) -> x + i);
 [1,3,5]

transform_keys(expr, func)
> SELECT transform_keys(map_from_arrays(array(1, 2, 3), array(1, 2, 3)), (k, v) -> k + 1);
 {2 -> 1, 3 -> 2, 4 -> 3}
> SELECT transform_keys(map_from_arrays(array(1, 2, 3), array(1, 2, 3)), (k, v) -> k + v);
 {2 -> 1, 4 -> 2, 6 -> 3}

transform_values(expr, func)

> SELECT transform_values(map_from_arrays(array(1, 2, 3), array(1, 2, 3)), (k, v) -> v + 1);
 {1 -> 2, 2 -> 3, 3 -> 4}
> SELECT transform_values(map_from_arrays(array(1, 2, 3), array(1, 2, 3)), (k, v) -> k + v);
 {1 -> 2, 2 -> 4, 3 -> 6}

zip_with(expr1, expr2, func)
> SELECT zip_with(array(1, 2, 3), array('a', 'b', 'c'), (x, y) -> (y, x));
 [{a, 1}, {b, 2}, {c, 3}]
> SELECT zip_with(array(1, 2), array(3, 4), (x, y) -> x + y);
 [4,6]
> SELECT zip_with(array('a', 'b', 'c'), array('d', 'e', 'f'), (x, y) -> concat(x, y));
 [ad , be, cf]
###Query JSON strings --WORKSHOP --IMP (qjson)

CREATE TABLE store_data AS SELECT
'{
   "store":{
      "fruit": [
        {"weight":8,"type":"apple"},
        {"weight":9,"type":"pear"}
      ],
      "basket":[
        [1,2,{"b":"y","a":"x"}],
        [3,4],
        [5,6]
      ],
      "book":[
        {
          "author":"Nigel Rees",
          "title":"Sayings of the Century",
          "category":"reference",
          "price":8.95
        },
        {
          "author":"Herman Melville",
          "title":"Moby Dick",
          "category":"fiction",
          "price":8.99,
          "isbn":"0-553-21311-3"
        },
        {
          "author":"J. R. R. Tolkien",
          "title":"The Lord of the Rings",
          "category":"fiction",
          "reader":[
            {"age":25,"name":"bob"},
            {"age":26,"name":"jack"}
          ],
          "price":22.99,
          "isbn":"0-395-19395-8"
        }
      ],
      "bicycle":{
        "price":19.95,
        "color":"red"
      }
    },
    "owner":"amy",
    "zip code":"94025",
    "fb:testid":"1234"
 }' as raw


Extract a top-level column
To extract a column, specify the name of the JSON field in your extraction path.
You can provide column names within brackets. Columns referenced inside brackets are matched case sensitively. The column name is also referenced case insensitively.

SQL
SELECT raw:owner, RAW:owner FROM store_data
+-------+-------+
| owner | owner |
+-------+-------+
| amy   | amy   |
+-------+-------+

SQL
-- References are case sensitive when you use brackets
SELECT raw:OWNER case_insensitive, raw:['OWNER'] case_sensitive FROM store_data
+------------------+----------------+
| case_insensitive | case_sensitive |
+------------------+----------------+
| amy              | null           |
+------------------+----------------+

Use backticks to escape spaces and special characters.
The field names are matched case insensitively.
SQL
-- Use backticks to escape special characters. References are case insensitive when you use backticks.
-- Use brackets to make them case sensitive.
SELECT raw:`zip code`, raw:`Zip Code`, raw:['fb:testid'] FROM store_data
+----------+----------+-----------+
| zip code | Zip Code | fb:testid |
+----------+----------+-----------+
| 94025    | 94025    | 1234      |
+----------+----------+-----------+

Note
If a JSON record contains multiple columns that can match your extraction path due to case
insensitive matching, you will receive an error asking you to use brackets. If you have matches of
columns across rows, you will not receive any errors.
The following will throw an error: {"foo":"bar", "Foo":"bar"}, and the following won't throw an error:
{"foo":"bar"}
{"Foo":"bar"}


Extract nested fields
You specify nested fields through dot notation or using brackets. When you use brackets, columns are
matched case sensitively.

SQL
-- Use dot notation
SELECT raw:store.bicycle FROM store_data
-- the column returned is a string
+------------------+
| bicycle          |
+------------------+
| {                |
|   "price":19.95, |
|   "color":"red"  |
| }                |
+------------------+
SQL
-- Use brackets
SELECT raw:store['bicycle'], raw:store['BICYCLE'] FROM store_data
+------------------+---------+
| bicycle          | BICYCLE |
+------------------+---------+
| {                | null    |
|   "price":19.95, |         |
|   "color":"red"  |         |
| }                |         |
+------------------+---------+

Extract values from arrays
You index elements in arrays with brackets. Indices are 0-based.
You can use an asterisk (*) followed by dot or bracket notation to extract subfields f
rom all elements in an array.
SQL
-- Index elements
SELECT raw:store.fruit[0], raw:store.fruit[1] FROM store_data
+------------------+-----------------+
| fruit            | fruit           |
+------------------+-----------------+
| {                | {               |
|   "weight":8,    |   "weight":9,   |
|   "type":"apple" |   "type":"pear" |
| }                | }               |
+------------------+-----------------+
SQL
-- Extract subfields from arrays
SELECT raw:store.book[*].isbn FROM store_data
+--------------------+
| isbn               |
+--------------------+
| [                  |
|   null,            |
|   "0-553-21311-3", |
|   "0-395-19395-8"  |
| ]                  |
+--------------------+
SQL
-- Access arrays within arrays or structs within arrays
SELECT
    raw:store.basket[*],
    raw:store.basket[*][0] first_of_baskets,
    raw:store.basket[0][*] first_basket,
    raw:store.basket[*][*] all_elements_flattened,
    raw:store.basket[0][2].b subfield
FROM store_data

Cast values
You can use :: to cast values to basic data types. Use the from_json method
to cast nested results into more complex data types, such as arrays or structs.
SQL
-- price is returned as a double, not a string
SELECT raw:store.bicycle.price::double FROM store_data
+------------------+
| price            |
+------------------+
| 19.95            |
+------------------+


-- use from_json to cast into more complex types
SELECT from_json(raw:store.bicycle, 'price double, color string') bicycle FROM store_data
-- the column returned is a struct containing the columns price and color
+------------------+
| bicycle          |
+------------------+
| {                |
|   "price":19.95, |
|   "color":"red"  |
| }                |
+------------------+


SELECT from_json(raw:store.basket[*], 'array<array<string>>') baskets FROM store_data
-- the column returned is an array of string arrays
+------------------------------------------+
| basket                                   |
+------------------------------------------+
| [                                        |
|   ["1","2","{\"b\":\"y\",\"a\":\"x\"}]", |
|   ["3","4"],                             |
|   ["5","6"]                              |
| ]                                        |
+------------------------------------------+

NULL behavior
When a JSON field exists with a null value, you will receive a SQL null value for that column,
not a null text value.


select '{"key":null}':key is null sql_null, '{"key":null}':key == 'null' text_null
+-------------+-----------+
| sql_null    | text_null |
+-------------+-----------+
| True        | null      |
+-------------+-----------+


#JSON 
lst = [1,2,3,4]
print("JSON encoding ", str(lst)) 
json_encoded_str = '[1, 2, 3, 4]'  
#Decode - given json_encoded_str, convert to python list of numbers 

#Strip with '[]' and split with ',' and store to s2 
#Create empty list 
#Take each from s2 
#    Convert to int and append to empty list 
#    
#print that empty list 
s1 = json_encoded_str.strip("[]")
s2 = s1.split(",")
#print(s2)
lst1 = []
for e in s2:
    lst1.append(int(e))
print(lst1)    



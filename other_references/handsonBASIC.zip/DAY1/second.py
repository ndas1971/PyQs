a = 1

# INDENTATION ERROR - INDENT must 
# TAB or space - but mix it 
# PEP8 - four space 
# SYNTAX ERROR 

if a >= 1:
    print(a)
    print(a)
    print(a)
elif a < 1:
    print("elseif")
    print("elseif")
else:
    print("else")
    print("else")
    print("else")
print("outside")
    


# if name is "XYZ" and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#OBJ - nested if and how many indents 
#first if - checking name, inside if - checking age 

name = "YZ"
age = 45
if name == "XYZ":
    if age < 40:
        print("Suitable")
    elif age > 50:
        print("Old")
    else:
        print("OK")
else:
    print("not known")
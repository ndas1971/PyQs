input_str = "Hello world"
# print frequency of each alphabets 
# H-1
# e-1
# l-3
# and so on for other alphabets  

#Take each char(ch1) from s 
#    initialize count 
#    Take each char(ch2) from s 
#        if ch1 and ch2 are same 
#            increment count 
#    print ch1 and count 

input_str ="Hello World"
for ch1 in set(input_str):
    count = 0
    for ch2 in input_str:
        if ch1 == ch2:
            count = count + 1
    print(ch1, "-", count)
    

# if name is "XYZ" and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#OBJ - nested if and how many indents 
#first if - checking name, inside if - checking age 

'''
User inputs are in string, convert if neccessary
user inputs 
    config files 
        xml, yaml, json 
    input 
    command line args  (can use argparse/getopt/...)
        Execute script by 'python ins.py 20 30'
        sys.argv = ['ins.py', '20', '30']
'''

import sys 
#print(sys.argv)

default_age = 40 

name = input("Give Name: ")
try:
    #X if Y else Z => if Y is true do X else do Z 
    age = int(sys.argv[1]) if len(sys.argv) > 1 else default_age 
except:
    print(f"BAD_NUMBER_FORMAT, using default = {default_age}")
    age = default_age
    
if name == "XYZ":
    if age < 40:
        print("Suitable")
    elif age > 50:
        print("Old")
    else:
        print("OK")
else:
    print("not known")
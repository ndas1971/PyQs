#module - contains functions/class 

"""My Module 

this is module doc_str 
all doc_str can be collated by pydoc tool 
can be published as html
"""

import math 

def square(x):
    #documentation string-doc_string 
    """Square of
    the numeric"""
    z = x * x 
    return z

def mean(lst):
    """Sum of lst/length of lst 
    Use builtin method sum 
    """
    #s = 0
    #for e in lst:
    #    s=s+e
    return sum(lst)/len(lst) 
    
def sd(lst):
    """
    sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
    
    Example 
    lst = [1,2]
    m = mean of lst 
    res = square of (1-m) + square of (2-m)
    return sqrt of res/length 
    
    Use math.sqrt 
    """
    m = mean(lst)
    o = []
    for e in lst:
        o.append( square(e-m))    
    return math.sqrt(sum(o)/len(lst))
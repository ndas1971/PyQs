#script - contains, import and executing statements
import mex 

print(mex.square(10))

lst = [1,2,3,4]
m,sd = mex.mean(lst), mex.sd(lst)
print(f"mean={m}, sd={sd}")
from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer

#Poisonous mushroom model 
#Display for each class, precision, recall and f1 



from yellowbrick.classifier import ConfusionMatrix, ROCAUC
from sklearn_pandas import gen_features

def draw_auc_confusion_matrix(X, y, model, features, labels):     
    # Create a new figure to draw the classification report on
    fig, (ax1,ax2) = plt.subplots(1,2)
    # Instantiate the classification model and visualizer
    visualizer = ConfusionMatrix( model, ax=ax1, classes=labels )
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.finalize()
    visualizer = ROCAUC(model, ax=ax2, classes=labels)
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.finalize()
    visualizer.show()

dataset = pd.read_csv('data/mushroom.csv')
names = [
    'class',
    'cap-shape',
    'cap-surface',
    'cap-color'
]
dataset.columns = names
features = ['cap-shape', 'cap-surface', 'cap-color']
target   = 'class'

X = dataset[features]
y = dataset[target]  
lenc = LabelEncoder().fit(y)
y = lenc.transform(y)

estimator = RandomForestClassifier()
#old code when ColumnTransformer was not present in sklearn 
##transformer for each column 
#feature_def = gen_features(
#    columns=features,
#    classes=[LabelEncoder]  #scikit_pandas can not handle OneHotEncoder after LabelEncoder as LabelEncoder expects 1D, oneHotEncoder expects 2D 
#)                           #Can use LabelBinarizer which is same as LabelEncoder, then OneHotEncoder
#X_mapper = DataFrameMapper(feature_def)
##Note features categorical, so, convert them to OneHotEncoding 
#model = Pipeline([
#    ('mapper', X_mapper),
#    ('hotencoder', OneHotEncoder()), #OneHotEncoder requires numerical categorical 
#    ('estimator', estimator)
#])
col_tran = ColumnTransformer(
    [
        ("one_hot",
            OneHotEncoder(),                
            features), #OneHotEncoder currently can take both numerical and categorical 
                
    ],
    remainder="drop",
)
model = Pipeline([('trx', col_tran),('estimator', estimator)])

draw_auc_confusion_matrix(X,y, model, features, lenc.classes_)

#Sklearn metrics 
model.fit(X,y)
y_pred = model.predict(X)
    
cr = classification_report(y,y_pred, 
    output_dict=True, target_names=lenc.classes_)
df = pd.DataFrame(cr)
df['micro'] = precision_recall_fscore_support(y, y_pred, average='micro')
df.fillna(len(y_pred), inplace=True)
print("Classification report\n",df.astype(np.float64).round(2))

df2 = pd.DataFrame(confusion_matrix(y, y_pred), 
    columns=["p-"+n for n in lenc.classes_],
    index=["a-"+n for n in lenc.classes_])
print("\nConfusion Matrix\n", df2)
print("""\nonly for binary cases
         predicted
         T       F 
         ----------
       T| tp    fn 
actual  |
       F| fp    tn
""")
tp,fn,fp,tn  = df2.iat[0,0],df2.iat[0,1], df2.iat[1,0],df2.iat[1,1]
print(f"""accuracy= (tp+tn)/all = {round((tp+tn)/(tp+fn+fp+tn), 2)}
precision= tp/(tp+fp) = {round(tp/(tp+fp), 2)}, precision of positive class
sensitivity= tp/(tp+fn) = {round(tp/(tp+fn), 2)}, recall of positive class
specificity= tn/(tn+fp) = {round(tn/(tn+fp), 2)}, recall of negative class
""")
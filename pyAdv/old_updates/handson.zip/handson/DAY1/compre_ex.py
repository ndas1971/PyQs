lst = [1,2,3,4]

#Square each even element 
o = []
for e in lst:
    if e % 2 == 0:
        o.append(e*e)
print(o)
#equiv
o = [e*e for e in lst if e % 2 == 0]
#proc if x in ... if ... if y in ... if ...
#create  tuple of even and odd 
o = [(e1,e2) for e1 in lst if e1 % 2 == 0 
      for e2 in lst if e2 % 2 == 1]
#equiv 
o = []
for e in lst:
    if e % 2 == 0:
        for e1 in lst:
            if e1 % 2 == 1:
                o.append( (e,e1))

#in set 
o = {e*e for e in lst if e % 2 == 0}
#in dict, key and value 
o = {e: e*e for e in lst if e % 2 == 0}


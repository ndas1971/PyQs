#convert deg to F and vice versa 
#C, F 
from enum import Enum 
Unit = Enum('Unit', ['F', 'C'])

#Type 
#https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html

def convert(value : int|float, unit:Unit) -> float:
    d2f = lambda deg : (deg * 9/5) + 32 
    f2d = lambda f: (f - 32) * 5/9 
    conv = { Unit.F: f2d, Unit.C: d2f }
    #https://peps.python.org/pep-0636/
    match unit:
        case Unit():
            return conv[unit](value)
        case _:
            raise Exception("not valid unit")
        
if __name__ == '__main__':
    values: list[int|float] = [0, 32]
    units = [Unit.F] * len(values) + [Unit.C] * len(values)
    #[(0, Unit.F), (32, Unit.F), (0, Unit.C), (32, Unit.C)]
    for v, u in zip([*values, *values], units):
        print(f"from {u} value {v}, result={convert(v,u)}")
        
    

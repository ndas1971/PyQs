import xml.etree.ElementTree as ET
path = r"D:\handson\DAY1\data\example.xml"
tr = ET.parse(path)
root = tr.getroot() # root.tag. root.attrib is a dict, root.text 
xpath = "./country/rank" #or xpath = ".//rank"
nn = root.findall(xpath)
#XPATH - no datatype, all are string
print([ int(n.text) for n in nn])
#[1, 4, 68]
o = []
for n in nn:
    o.append(int(n.text))
#XPATH - https://www.w3schools.com/xml/xpath_syntax.asp
#HAndson-1: Get all the countries from xml file 
print([n.attrib['name'] for n in root.findall("./country")])
#Complex - extraction, country and its neighbors
#{ cname: [n1, n2], ...}
print({ n.attrib['name']: [e.attrib['name'] 
    for e in n.findall("./neighbor")] 
        for n in root.findall("./country")}
)        
#equiv 
o = {}
for n in root.findall("./country"):
    lst = []
    for e in n.findall("./neighbor"):
        lst.append(e.attrib['name'] )
    o[ n.attrib['name']] = lst
print(o)
import xml.etree.ElementTree as ET
path = r"D:\handson\DAY1\data\example1.xml"
tr = ET.parse(path)
root = tr.getroot() 
ns = dict(default="http://people.example.com",
          fictional="http://characters.example.com")
xpath = ".//default:name"
nn = root.findall(xpath, ns)
print([n.text for n in nn])    
#Handson - {actorname: [characters]}    
o = { actor.findall(".//default:name", ns)[0].text :
    [ch.text
       for ch in actor.findall("fictional:character", ns)]
     for actor in root.findall(".//default:actor", ns)}
print(o)
#How to write XML file 
some_value = 20 
xml = f"""<?xml version="1.0"?>
<data>{some_value}</data>
"""
#jinja2 template can be used for writing xml 
#ET have few methods for creating XML
a = ET.Element("a")
b = ET.SubElement(a, "b", attrib=dict(count="1"))
b.text = "Hello"
ET.dump(a) #<a><b count="1">Hello</b></a>



#Bank User has name and account. There are two types of Users
#Normal and privileged user . There are two types of privileged
#users, Gold and Silver. Gold has cashback of 5% and Silver has 
#cashback of 3% of expenditure when they spend any cash 
"""
Noun
    class
        methods(specification)
        data(variables)
Verb 
    methods of class 
Cohesive
    verb go to active noun 
Instance/object 
    Memory presence
    and here methods are called 
    
Relations 
    composition 
        has /have 
    inheritance 
        is/are 
    
Error 
    Exception 
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    Many New syntaxes, Exception group 
    https://docs.python.org/3/library/exceptions.html
Special method 
    https://docs.python.org/3/reference/datamodel.html
    
Self 
    Not a keyword
    Convention 
    position is fixed, first argument
    
Python OOP
    instance method/variable 
        first argument is instance 
    No access control
        all public
            convention , if a method starts with _ 
            it is considered private 
    no interface/abstract keyword 
        we have abc module to implement abstract class 
    class method/variable 
        global space for all the instances of the class 
        equivalent - static in java 
        Using classname
        first argument is class 
    static method 
        method where first arg is not there 
    property 
        get/set - lazy variable 
    Reflection 
    slots 
    metaclass
"""
class NotEnoughBalance(Exception):
    pass 

class BankAccount:
    def __init__(self, init_amount): #instance method 
        self.amount = init_amount   #instance variable 
    def transact(self, amount):
        if self.amount + amount < 0:
            raise NotEnoughBalance("not possible")
        self.amount += amount 
    def __str__(self):
        return f"BankAccount({self.amount})"
        
class BankUser:
    @staticmethod 
    def version():
        return '0.0.1'
    @property 
    def balance(self):
        return self.account.amount 
    def __init__(self, name, init_amount):  #composition 
        self.name = name 
        self.account = BankAccount(init_amount)
    def transact(self, amount):
        #delegate , template DP
        try:
            self.account.transact(amount)
            if amount < 0:
                cashback = self.get_cashback_percentage() * abs(amount)
                self.account.transact(cashback)
        except NotEnoughBalance as ex:
            print(ex, "Name:", self.name, "Amount:", amount)  
    def __str__(self):
        return f"BankUser({self.name}, {self.account})"
    def get_cashback_percentage(self):
        return 0
        
        
class NormalUser(BankUser):
    pass 

class GoldUser(BankUser):
    def get_cashback_percentage(self):
        return 0.05

class SilverUser(BankUser):
    def get_cashback_percentage(self):
        return 0.03

if __name__ == '__main__':          # pragma: no cover 
    users = [GoldUser("Gold", 100),
             SilverUser("Silver", 100),
             NormalUser("Normal", 100),]
    amounts = [100,-200,300,-400,400]
    for u in users:
        for am in amounts:
            u.transact(am)
        print(u.balance)
    print(BankUser.version())

    #ba = BankUser("ABC", 100)      #BankUser.__init__( ba , 100)
    #ba.transact(100)                #BankUser.transact( ba , 100)
    #print(ba)                       #BankUser.__str__(ba)








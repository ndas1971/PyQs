from oop import * 

#Test module - file with test prefix 
#testcase - function with test prefix 
#test suite - class with Test prefix 

"""
Execute by 
pytest -v 
pytest --cov=oop --cov-report term-missing

https://docs.pytest.org/en/6.2.x/fixture.html
    Test Data 
https://docs.pytest.org/en/6.2.x/skipping.html
    Skip test 
    Test filtering 
    OPTION-1 : pytest marker 
    OPTION-2: K expresion 
https://docs.pytest.org/en/6.2.x/monkeypatch.html
    Mock testing 


 -k EXPRESSION         Only run tests which match the given substring expression. An
                        expression is a Python evaluable expression where all names are
                        substring-matched against test names and their parent classes.
                        Example: -k 'test_method or test_other' matches all test functions and
                        classes whose name contains 'test_method' or 'test_other', while -k
                        'not test_method' matches those that don't contain 'test_method' in
                        their names. -k 'not test_method and not test_other' will eliminate
                        the matches. Additionally keywords are matched to classes and
                        functions containing extra names in their 'extra_keyword_matches' set,
                        as well as functions which have names assigned directly to them. The
                        matching is case-insensitive.
                        
pytest -v -k "TestUser"
pytest -v -k "not TestUser"
pytest -v -k "normal or bankaccount"
"""
class TestUser:
    def test_normal_user(self):
        u = NormalUser("Normal", 100)
        amounts = [100,-200,300,-400,400]
        for am in amounts:
            u.transact(am)
        assert u.balance == 700        
    def test_gold_user(self):
        u = GoldUser("Normal", 100)
        amounts = [100,-200,300,-400,400]
        for am in amounts:
            u.transact(am)
        assert u.balance == 710        
    def test_silver_user(self):
        u = SilverUser("Normal", 100)
        amounts = [100,-200,300,-400,400]
        for am in amounts:
            u.transact(am)
        assert u.balance == 706
        
def test_bankaccount_str():
    ba = BankAccount(100)
    assert str(ba) == "BankAccount(100)"
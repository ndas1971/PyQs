from  oop import * 

def test_add_fractions():
    a = Fraction(1,2)
    b = Fraction(2,3)
    assert a+b == Fraction(7, 6)
    
    
#1/2 + 2/3 = 5/6
import subprocess as S
import re 

class Execute:
    def __init__(self, command):
        self.command = command 
    def search(self, what):
        out = S.run([self.command], 
                shell=True, 
                capture_output=True,
                universal_newlines=True)
        res = re.findall(what, out.stdout)
        return res
    def __str__(self):
        return f"Execute({self.command})"
from auto import * 

def test_execute_search():
    out = Execute("dir").search(r"\d\d-\d\d-\d\d\d\d")
    assert type(out) is list 
"""
Python DB 
    DB API 
    ORM 
DB Engines 
    mysql
    oracle 
    ...
Per DB engines
    module1
    module2
    
So use SQLALCHEMY 
https://docs.sqlalchemy.org/en/20/core/engines.html
"""
from sqlalchemy import create_engine, text 
eng = create_engine("sqlite:///people.db")
"""
people 
    name   string 
    age    int 
"""
create_sql = """
create table if not exists people(name string, 
age int)
"""
insert_sql = "insert into people values(:x, :y)"
select_sql = "select age from people where name = :x"
data = [("das", 20), ("abc", 60)]
with eng.connect() as con:
    con.execute(text(create_sql))
    for n,a in data:
        con.execute(text(insert_sql), dict(x=n,y=a)) #param binding
    con.commit()  # or .rollback()
#DB created 
with eng.connect() as con:
    res = con.execute(text(select_sql), dict(x="das"))
    print(res.fetchall()) #res.fetchone()

#Hands on 
#Insert another row ("abc", 60)
#Find max age 
with eng.connect() as con:
    res = con.execute(text("select max(age) from people"))
    print(res.fetchone())




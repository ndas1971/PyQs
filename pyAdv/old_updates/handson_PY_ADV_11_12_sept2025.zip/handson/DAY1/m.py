print(__name__) 
#in script(run), = '__main__'
#in module(import) = 'm' which is file name 

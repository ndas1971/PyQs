"""
Commands 
tasklist /FI "IMAGENAME eq python.exe"
taskkill /F /IM python.exe 

Manager Process 
    Extra process created to manage all processes 
    CHeck Ref 
"""

import multiprocessing
import time 

def worker(sleeptime):
    print(multiprocessing.current_process().name, "Entering")
    time.sleep(sleeptime)
    print(multiprocessing.current_process().name, "Exiting")
    
    
if __name__ == '__main__':
    print("Sequentially")
    worker(5)
    print("Parallelly")
    ths = []
    st = time.time()
    for _ in range(10):
        th = multiprocessing.Process(target=worker, args=(5,))
        ths.append(th)
    #start it 
    [th.start() for th in ths] #comprehension 
    #wait for end 
    [th.join() for th in ths]
    print("Time taken:", time.time()-st, "secs")
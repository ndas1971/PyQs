"""
module must have prefix test 
testcase is a function prefix test 
    must have assert 
    if assert fails , test case failed 
Test suite is a class prefix Test 

Execute 
pytest -v test_userh.py 
pytest --cov=userh --cov-report term-missing test_userh.py 
"""

#HOME work - write four testcase 
#to cover 84, 97, 103, 105
"""
Fixture 
    Testdata
assert 
    Test exception 
    capture print output 
Skip 
Filter 
    -k expression 
        pytest -k "golduser" -v test_userh.py 
        Check 
        pytest --help 
    Mark
        Using decorator @mark 
Mock

"""

import userh 
class TestUser:
    def test_golduser(self):
        u = userh.GoldUser("Gold", 100)
        amounts = [100,-200, 300, -400, 500]
        for am in amounts:
            u.transact(am)
        assert u.balance == 810
    def test_normaluser(self):
        u = userh.NormalUser("Gold", 100)
        amounts = [100,-200, 300, -400, 500]
        for am in amounts:
            u.transact(am)
        assert u.balance == 800
    def test_silveruser(self):
        u = userh.SilverUser("Gold", 100)
        amounts = [100,-200, 300, -400, 500]
        for am in amounts:
            u.transact(am)
        assert u.balance == 806
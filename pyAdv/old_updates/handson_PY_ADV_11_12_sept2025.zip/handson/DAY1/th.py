"""
https://wiki.python.org/moin/ParallelProcessing
single host, single process , single thread 
    As of now working like that 
single host, single process , multithread 
    https://docs.python.org/3/library/threading.html
single host, multiprocess
    https://docs.python.org/3/library/multiprocessing.html
multi host 
    Needs framework eg pyspark 

Process 
    heavy wt 
    can have many threads 
    Use when 
    1)going beyond process constraint 
    2) CPU bound code because of GIL 
    (getting removed in python3.13 in free threaded
    Then use thread for both usecase)
Thread (#thread - 1.5 to 2 times of core)
    can create many threads or other process 
    light wt 
    By default use this eg for IO bound code 
    
Synchronization 
    eg return from thread, or intermediate control 
    Lock/RLock 
        one thread at a time 
    Condition objects
        producer consumer 
        Use Queue 
    Semaphore objects
        N thread at time 
    Event objects
        pub-sub problem 
    Timer objects
        execute something in future 
    Barrier objects
        intermediate synchornization
Many sync objects 
    deadlock 
    
Map/reduce or fork/join - ThreadPoolExecutor
    1 master(join/reduce ) <=>N workers(fork/map)
    concurrent.futures 
    https://docs.python.org/3/library/concurrent.futures.html
    
"""
import threading
import time 

def worker(sleeptime):
    print(threading.current_thread().name, "Entering")
    time.sleep(sleeptime)
    print(threading.current_thread().name, "Exiting")
    
    
if __name__ == '__main__':
    print("Sequentially")
    worker(5)               #MainProcess MainThread
    print("Parallelly")
    ths = []
    st = time.time()
    for _ in range(10):
        th = threading.Thread(target=worker, args=(5,))
        ths.append(th)
    #start it 
    [th.start() for th in ths] #comprehension 
    #wait for end 
    [th.join() for th in ths]
    #ths[0].join() #MainThread will now wait on only first thread 
    print("Time taken:", time.time()-st, "secs")
    
from flask import Flask 

#app = Flask(__name__)
from flaskr import app

@app.route("/")   #http://localhost:5000/
def home():
    return """
    <html><body>
    <h1>Hello there</h1>
    </body></html>
    """

"""
GET params 
    URL params http://localhost:5000/helloj?name=abc
    path params http://localhost:5000/helloj/abc

POST params http://localhost:5000/helloj
    body with Content-Type application/json 
    '{"name": "abc"}'
    
"""
from flask import jsonify, request 

@app.route("/helloj", methods=['GET', 'POST'])   #URL and POST 
@app.route("/helloj/<string:name>", methods=['GET']) #PATH
def helloj(name="abc"):     #PATH 
    """given a name, send age"""
    db = [dict(name="abc", age=20), dict(name="xyz", age=50)]
    fname = None 
    if request.method == 'GET':
        fname = request.args.get("name", name)      #URL          
    elif request.method == 'POST':              #POST
        if 'Content-Type' in request.headers and \
                request.headers['Content-Type'] in ["application/json"]:
            fname = request.json.get("name", name)
    
    age = None 
    for e in db:
        if e['name'].lower() == fname.lower():
            age = e['age']
    if age:
        obj = dict(name=fname, age=age)
        resp = jsonify(obj)
        resp.status_code = 200
    else:
        #error 
        obj = dict(name=fname, details="not found")
        resp = jsonify(obj)
        resp.status_code = 500
    return resp 
    



if __name__ == '__main__':
    #http://localhost:5000
    app.run()

"""
import requests as r 
url1 = "http://localhost:5000/helloj?name=abc"
url2 = "http://localhost:5000/helloj/abc"
url3 = "http://localhost:5000/helloj/bnf"
resp = r.get(url1)
print(resp.status_code, resp.json())
resp = r.get(url2)
print(resp.status_code, resp.json())
resp = r.get(url3)
print(resp.status_code, resp.json())


url4 = "http://localhost:5000/helloj"
headers = {'Content-Type': 'application/json'}
obj = dict(name="abc")
resp = r.post(url4, json=obj, headers=headers)
print(resp.status_code, resp.json())
"""
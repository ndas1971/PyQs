from gevent.pywsgi import WSGIServer
from flaskr import app

# http_server = WSGIServer(('localhost', 443), app, keyfile='key.pem', certfile='cert.pem')
http_server = WSGIServer(('localhost', 8080), app)
http_server.serve_forever()

"""
http://localhost:8080/
https:
keyfile='key.pem'<=private, certfile='cert.pem'<=public

"""
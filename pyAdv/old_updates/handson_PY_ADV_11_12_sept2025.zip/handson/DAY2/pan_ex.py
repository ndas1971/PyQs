"""
Pandas - 2D 
rows x cols 

long form 
    normal data 
wide form 
melt <=> pivot
Cols are very important - Long form
    features
rows 
    example of features 
    
Pandas 
    2d - DataFrame 
        list of cols/Series 
    Columns are VIP 
    
Pandas 
    Eager lib 
Dask (pandas API)
    lazy pandas 
pyspark(Pandas API)
    multihost 
"""
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
path = r"D:\handson\DAY2\code\data\iris.csv"
iris = pd.read_csv(path)
#Metadata
len(iris)       # no of rows 
iris.columns    #SepalLength,SepalWidth,PetalLength,PetalWidth,Name
iris.index      # row_id is called index 
iris.dtypes     #datatype of cols 
iris.head()     #first five rows 
#Access
type(iris)      #DataFrame 
type(iris.SepalLength)  #Series 
iris['SepalLength']    
iris[['SepalLength', 'PetalLength']]  #DataFrame 
#slice in dict access, those row_ids , is end included?
iris[0:4]      #DF
#Adv access 
#iloc[row_index, col_index] vs loc[row_id, col_name]
#both can contain :, in iloc, end not included 
#in loc end is included 
iris.iloc[0:4, [0,1]]    #DF 
iris.loc[0:3, ['SepalLength',  'SepalWidth']] 
#Loc can contain boolean query 
#and - &, or -|, not - ~
iris.loc[iris.SepalLength > 5, :]
iris.loc[(iris.SepalLength > 5) & (iris.SepalLength < 5.5), :]
#Creation of Cols 
iris['dummy'] = iris.SepalLength - 2*iris.PetalLength - 2 
#DONOT use bultin in fn abs - those are  scalar
#Use numpy equivalent as they can undertstand Series- called vector fn 
iris['dummy'] = np.abs(iris.dummy)
#Deletion of columns 
iris.drop(columns=['dummy'])  #returns new DF 
iris.drop(columns=['dummy'], inplace=True) #now mutates
#Applying function 
#DF and Series share many same named fns 
iris.SepalLength.mean()  
iris.iloc[:,0:4].mean()
iris.iloc[:,0:4].mean(axis=0)  # columwise, default 
iris.iloc[:,0:4].mean(axis=1)  #rowwise 
#Please check reference of axis per fn in doc 

#Groupby 
iris.iloc[:, 0:4].describe()
iris.Name.unique()
gr = iris.groupby("Name")
gr.mean()
gr.agg({'SepalLength': ['mean', 'count']})
gr.agg({'SepalLength': ['mean', 'count', 'std', 'min']}).to_excel("proc.xlsx")
import glob 
glob.glob("*.xlsx")

#Plot  
iris.iloc[:, 0:4].plot(kind='line')
#plt.savefig('p.png')

#HOME-concat and merge aka join 
#Check seaborn offline 
import seaborn as sns 
#flights = sns.load_dataset("flights")
flights = pd.read_csv("flights_sns.csv")
flights.head()
sns.relplot(data=flights, x="year", y="passengers", hue="month", kind="line")
#line diagram  x vs y with groupby hue 
plt.savefig("flights.png")


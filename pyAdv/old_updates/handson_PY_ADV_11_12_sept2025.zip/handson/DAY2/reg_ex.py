# Read boston.csv 
# How many cols and how many rows 
# Display crim, zn, indus columns 
# Display first two rows of all columns 
# Find min of lstat and medv
# For each rad, find min and max value of lstat and medv
"""
Variables in order:
 CRIM     per capita crime rate by town
 ZN       proportion of residential land zoned for lots over 25,000 sq.ft.
 INDUS    proportion of non-retail business acres per town
 CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
 NOX      nitric oxides concentration (parts per 10 million)
 RM       average number of rooms per dwelling
 AGE      proportion of owner-occupied units built prior to 1940
 DIS      weighted distances to five Boston employment centres
 RAD      index of accessibility to radial highways
 TAX      full-value property-tax rate per $10,000
 PTRATIO  pupil-teacher ratio by town
 B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
 LSTAT    % lower status of the population
 MEDV     Median value of owner-occupied homes in $1000's
"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn.svm import *  
from sklearn.tree import *  

boston = pd.read_csv(r"D:\handson\DAY2\code\data\boston.csv")
#rows 
len(boston)
#columns 
len(boston.columns)
#Display crim, zn, indus co
boston[['crim', 'zn', 'indus']]
# Display first two rows of all columns 
boston.iloc[:2, :]
#Find min of lstat and medv
boston[['lstat', 'medv']].min()
# For each rad, find min and max value of lstat and medv
gr = boston.groupby('rad')
gr.agg({'lstat': [ 'max', 'min'], 
    'medv': [ 'max', 'min']})
#DEFINE data as all columns except mdev in 2D
#DEFINE target as mdev in 1D
#in numpy 
dataset = boston.values
data = dataset[:, :-1]
target = dataset[:,-1]
#>>> data.shape
#(506, 13)
#>>> target.shape
#(506,)
#>>>
    # Y = F(X)   , where x is given and find Y 
    #F is called Model 
    #(If given Y and find X - generative AI)
    #When there is target - supervised 
    # continuous - Regression 
    # discrete  - classification
    #No target - unsupervised 
    
#What is relation of house price with others ?
    #Regression - LinearRegression
#how much is it true ? is any feature missing?
    #Check R^2 value of train and test 
    
#FEATURE importance 
#Which parameter most affects mdev negatively? 
    #coeff to understand , negative cofficient 
#Which parameters most affect mdev positively? 


#Features - 13, rows -506
#target is vector

#STEP-1 : Any preprocessing to y 
#If y is discrete string , the LabelEncode() to convert to Number
    #Iris-setosa to 0, ...
#If NN, then convert number to onehot encoding 
    #0 => 00, 1 => 01, 2=> 10 ...
#enc = LabelEncoder()
#y = enc.fit_transform(target)
X = data
y = target 

#on un-seen data = test data => R^2(0-1) for unseen data 
#seen data = train data     #fit and find  model and R^ on seen data 
#underfit - train error is more => R^2 is very less 
#OPTIONs are increase model complexity SVM, GBM
#HYper parameters - model initializer parameter- see doc 
# GridSearch goves best hyperparametes
#Linear regression - y = mx + C 
#when we fit on model, it find m and C 


#STEP2 - Split 
X_train, X_test, y_train, y_test = train_test_split(
    X, y, random_state=0)


#STEP-3 : Any preprocessing on X 
#In general, standardize X 
sc  = StandardScaler()
#X_processed = sc.fit_transform(X)  # 2D

#STEP4: Create estimator 
lg = LinearRegression()
#gbm = GradientBoostingRegressor() #Change 
#lr = LogisticRegression()


#STEP5 : create pipeline 
pipeline = Pipeline([('sc', sc),('lg', lg)])
pgbm = Pipeline([('sc', sc),('gbm', gbm)])

#FIT 
final = pipeline.fit(X_train, y_train)
final2 = pgbm.fit(X_train, y_train)

#CHECK Train score 
final.score(X_train, y_train)
final2.score(X_train, y_train)
#Check unknown test score 
final.score(X_test, y_test)
final2.score(X_test, y_test)
#predict 
y_pred = final.predict(X_test)

m = LinearRegression().fit(X_train, y_train)
# >>> m.coef_
# array([-1.17735289e-01,  4.40174969e-02, -5.76814314e-03,  2.39341594e+00,
#        -1.55894211e+01,  3.76896770e+00, -7.03517828e-03, -1.43495641e+00,
#         2.40081086e-01, -1.12972810e-02, -9.85546732e-01,  8.44443453e-03,
#        -4.99116797e-01])
# >>> #"crim","zn","indus","chas","nox","rm","age","dis","rad","tax","ptratio","b","lstat",
# >>> np.round
# <function round at 0x000002AFE3956330>
# >>> np.round(m.coef_)
# array([ -0.,   0.,  -0.,   2., -16.,   4.,  -0.,  -1.,   0.,  -0.,  -1.,
#          0.,  -0.])
# >>>


####Handson 
#Read Iris 
#put LabelEncoder transformation on y 
#Put StandardScaler on X 
#Split train and test 
#Use LogisticRegression 
#train and test error 
path = r"D:\handson\DAY2\code\data\iris.csv"
iris = pd.read_csv(path)

data = iris[['SepalLength' , 'SepalWidth',  'PetalLength',  'PetalWidth']]
target = iris.Name
enc = LabelEncoder()
y = enc.fit_transform(target)
X = data

X_train, X_test, y_train, y_test = train_test_split(
    X, y, random_state=0)
sc  = StandardScaler()
lr = LogisticRegression()  #one hyperparameter C 
pipeline = Pipeline([('sc', sc),('lr', lr)])
final = pipeline.fit(X_train, y_train)
final.score(X_train, y_train)
final.score(X_test, y_test)


search_grid = dict(lr__C=[0.1, 1,10, 100])
m = GridSearchCV(pipeline, search_grid)  
m.fit(X_train,y_train)
final_model = m.best_estimator_
final_model.score(X_train, y_train)
final_model.score(X_test, y_test)

m = LogisticRegression().fit(X_train, y_train)
m.coef_ 

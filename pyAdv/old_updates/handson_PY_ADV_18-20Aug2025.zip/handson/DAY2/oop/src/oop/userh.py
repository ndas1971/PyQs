# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 
"""
Noun
    a class 
Verb 
    method on that class 
    
How to write class in python 
    1. find initializer parameters
    2. Write initializer method 
        def __init__
        create any instance variable 
    3. Then write other methods 
Self
    Must be first arg 
    Py will put instance 
    Not a keyword, by convention, it is called self
OOP
    NO Access control
        instance.balance 
    does not have interface/abstract keywords 
        has abstractmethod concept through metaclass 
            refere abc module 
    has instance method/variables 
        first arg is instance 
        variable per instance 
    has class method/variables 
        first arg is class 
        usage - global variable for all the instance class 
    has staticmethod 
        there is no first arg
    property 
        Access like variable, but it calls method 
        (similar to javabeans)
    slots etc 
        Refer Learning Python book 
Special Methods
    eg __init__
    Ref 
    https://docs.python.org/3/reference/datamodel.html#special-method-names
    Many special methods are available 
    Py uses those on special purposes, for calling operator 
    
OOP relations
    is/are 
        inheritance 
        1. no override, calls baseclass method 
        2. override, calls subclass method 
        3. override with super()
    has/have 
        composition 
        ie taking in __init__ args 

"""
class NotEnoughBalance(Exception):
    pass

class BankAccount:
    count = 0                    #class variable , access BankAccount.count 
    @classmethod                # @ is for applying decorator 
    def how_many(cls):          #first arg will be class
        return cls.count 
    @staticmethod 
    def version():
        return '0.0.1'
    @property 
    def account_balance(self):    # call like instance.account_balance, note there is no () at the end 
        return self.balance
    def __init__(self, init_amount):
        self.balance = init_amount  #ba.balance == 100
        BankAccount.count += 1
    def transact(self, amount):
        if self.balance + amount < 0:
            #return error 
            raise NotEnoughBalance("not possible")
        self.balance += amount 
    def __str__(self):
        return f"BankAccount(balance={self.balance})"
        
class SpecialBankAccount(BankAccount):
    def __str__(self):
        return f"SpecialBankAccount(balance={self.balance})"
    def transact(self, amount, cb_per=0.05):
        try:
            super().transact(amount)
            if amount < 0:
                cb = cb_per * abs(amount)
                super().transact(cb)        
        except NotEnoughBalance as ex:
            print(ex) 
        
if __name__ == '__main__': # pragma: no cover 
    #Usage 
    sba = SpecialBankAccount(100)  # SpecialBankAccount.__init__(ba, 100)
    sba.transact(-50)       # SpecialBankAccount.transact(ba, 100)
    print(sba)      #SpecialBankAccount.__str__(ba)
    [BankAccount(100), BankAccount(100)]
    print(BankAccount.how_many(), BankAccount.version(), sba.account_balance)
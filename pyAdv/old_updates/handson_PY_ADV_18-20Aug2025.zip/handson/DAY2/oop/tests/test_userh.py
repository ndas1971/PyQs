import oop 

"""
Execute by 
pytest -v 

With coverage 
pytest -v --cov=oop  --cov-report term-missing

"""

"""
test modules should have 'test' prefix
Testcase 
    function with test prefix 
    atleast one assert 
    which checks some boolean condition 
    if success, test case is passed 
    else failed 
Test suite 
    collection of testcases 
    class with Test prefix 

"""

def test_sba_transact():
    sba = oop.SpecialBankAccount(100) 
    sba.transact(-50)    
    assert sba.account_balance == 52.5

def test_count():
    old = oop.BankAccount.how_many()
    sba = oop.SpecialBankAccount(100) 
    latest = oop.BankAccount.how_many()
    assert (latest - old) == 1
    
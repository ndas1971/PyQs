r"""
Design an automation framework which can execute 
any command and it has a functionality of search 
any information in the command output 

Only create skeleton by following below
Hint:
1. Create a package called auto 
poetry new auto 
cd auto 
2. add pytest as dev dependencies
poetry add --group dev pytest 
3. create a module command.py 
echo > src\auto\command.py 
4. Create a test module test_command.py 
echo > tests\test_command.py 

5. Integrate command.py content at package level 
#src\auto\__init__.py 
from .command import * 
6. Create skeleton class called Execute 
    Decide what needs to be taken as initialization
    parameter, write initialization method 
    Decide what other methods to be written 
    (hint, print is one good candidate
    also, search is another method,
    it returns a list )
    A) USe subprocess to execute the command 
    https://docs.python.org/3/library/subprocess.html
    B) Enable below flags 
    capture_output (output comes into stdout)
    shell    ( Execute the command under shell) 
    universal_newlines ( to convert to string)
    C) Use re module to extract the info from 
    stdout of above 

7. Write test case for testing search method 
   checks whether return type is list or not   
   Use command = "dir" and then test  
#tests\test_command.py 
import auto 
def test_search():
    out = auto.Execute("dir").search(r"\d{2}-\d{2}-\d{4}")
    assert type(out) is list 
    
8. pytest should run for all these 
   skeleton code 
   (hint - update pyproject.toml with following)
[tool.pytest.ini_options]
pythonpath = [
  "src"
]
9. Test - activate virtual env 
poetry env activate 
Run output of above command 
pytest -v 
10. Then build 
poetry build -v 
11. Install the dist 
deactivate 
cd ..
pip install auto\dist\*.whl 
And then test anywhere 

"""
import subprocess as S 
import re 

class Execute:
    def __init__(self, command):
        self.command = command 
    def search(self, what):
        p = S.run([self.command], 
                capture_output=True, 
                shell=True, universal_newlines=True)
        return re.findall(what, p.stdout) 

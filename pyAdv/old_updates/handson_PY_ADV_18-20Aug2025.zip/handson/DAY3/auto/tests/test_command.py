import auto 
def test_search():
    out = auto.Execute("dir").search(r"\d{2}-\d{2}-\d{4}")
    assert type(out) is list 
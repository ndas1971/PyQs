"""
2 kinds of data 
-> nosql data 
   ex: json , sql 
   kind - text data, repeated data 
   usecase - search 
-> sql data 
   2D data , rows x cols 
   eg csv, excel...
   kind - relational data 
   usecase - aggregation 
   adv - USe high level api 
   pandas 
    pip install pandas matplotlib 
   https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf
   concepts 
   2D is called DataFrame 
   which is list of COlumns/Series 
   - eager 
   Dask - lazy pandas 
   pyspark pandas - clustered computation/big data 
"""
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
path = r"D:\handson\DAY1\data\iris.csv"
iris = pd.read_csv(path)
print(type(iris), # DataFrame 
    type(iris.SepalLength) # Series 
    )
#Check metadata 
#Please use print() to print in script 
iris.head()  # first five rows as sample data
#    SepalLength  SepalWidth  PetalLength  PetalWidth         Name
# 0          5.1         3.5          1.4         0.2  Iris-setosa
# 1          4.9         3.0          1.4         0.2  Iris-setosa
# 2          4.7         3.2          1.3         0.2  Iris-setosa
# 3          4.6         3.1          1.5         0.2  Iris-setosa
# 4          5.0         3.6          1.4         0.2  Iris-setosa 
iris.columns  # list of columns as string 
iris.index   # row_id of 2D data , 1 to 150 
iris.dtypes   # datatypes of each column, str is called object 
#Access 
iris.SepalLength 
iris['SepalLength']  # Series 
iris[['SepalLength', 'SepalWidth']] #DF 
#Adv access
#.iloc[index_row, index_col]
#.loc [row_id, col_names]
#both accept slice syntax start:end
#diff, iloc , end is not included 
#loc, end is included 
iris.iloc[0:3, [0,1]]
iris.loc[0:2, ['SepalLength', 'SepalWidth']]
#loc can take boolean query 
iris.loc[iris.SepalLength > 5, :]
#and -&, or |, not ~, use ()
iris.loc[(iris.SepalLength > 5)& (iris.SepalLength > 5.5),  :]
#Creation of column 
iris['dummy'] = iris.SepalLength - 2* iris.PetalLength - 3
#we can not use builtin function like abs ,
#we need vector fn which can be used on Series
iris['dummy'] = np.abs(iris.dummy)
iris.dummy
#deletion 
df = iris.drop(columns=["dummy"])  #return new DF 
df.columns 
#Many APIs return new DF 
#To update inplace, use 
iris.drop(columns=["dummy"], inplace=True) 

#function
iris.SepalLength.mean()  # mean of one col
iris.iloc[:,0:4].mean()  #mean of each col 
#by default it works on colum , axis=0 
iris.iloc[:,0:4].mean(axis=0) # columnwise 
iris.iloc[:,0:4].mean(axis=1) #rowwise, 
#Refere to API to understand axis 
#groupby
gr = iris.groupby("Name")
gr.mean()  # for each Name, each column's mean 
gr.agg({'SepalLength':['mean', 'min', 'max']}) # {column:[agg_fn_names]}
gr.agg({'SepalLength':['mean', 'min', 'max']})\
    .to_excel("proc.xlsx")


#plot 
iris.iloc[:, 0:4].plot(kind='line')
plt.savefig('p.png')















"""
DB API(sql) or ORM (table => class)
Oracle, mysql ...
many libs for each engine 
Use sqlalchemy 
    pip install sqlalchemy 
https://docs.sqlalchemy.org/en/20/core/engines.html
"""
from sqlalchemy import text, create_engine
engine = create_engine("sqlite:///foo.db")

create_s = "create table if not exists people(name string, age int)"
insert_s = "insert into people values(:x,:y)" #:key is placeholder 
select_s = "select age from people where name=:x"

data = [("abc", 20), ("xyz", 30)]

with engine.connect() as con:
    con.execute(text(create_s))
    for n,g in data:
        con.execute(text(insert_s), dict(x=n, y=g))
    con.commit()
    
with engine.connect() as con:
    cursor = con.execute(text(select_s), dict(x="abc"))
    #cursor.fetchall() or .fetchone 
    print(cursor.fetchall())
    
select_s2 = "select max(age) from people"
with engine.connect() as con:
    cursor = con.execute(text(select_s2))
    print(cursor.fetchone())
    
#Handson
#insert another record ("xyz", 30) elegantly 
#get the max age of all records   
    






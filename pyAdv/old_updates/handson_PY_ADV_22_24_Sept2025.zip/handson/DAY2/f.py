class Fraction:
    def __init__(self, numerator, denominator):
        self.numerator = numerator
        self.denominator = denominator

    def __add__(self, other):
        print(self)
        print(type(other))
        print(other.denominator)
        numerator = (self.numerator * other.denominator) + (self.denominator * other.numerator)
        denominator = self.denominator * other.denominator
        result =  Fraction(numerator, denominator)
        return result

    def __str__(self):
        return f"Fraction {self.numerator, self.denominator}"

if __name__ == '__main__':
    a = Fraction(1,2)
    #b = Fraction(2,3)
    c = a + 2
    print(c)
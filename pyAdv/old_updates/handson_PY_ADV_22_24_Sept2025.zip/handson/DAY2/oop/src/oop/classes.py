# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 
r"""
class 
    instance methods/variables
        contains many methods
        and few variables
instance/object 
    we use them those methods and variables 
    here . Means it has physical memory 
Relations 
    is/are - inheritance 
    has/have - composition 
        take those components 
        in __init__ method 
    
1. Find initialization parameters 
2. Write initialization method 
      We call this to create instance 
      def __init__(self, initialization_parameters..)
        create instance variable 
3. Write other methods 
      we use those instance variables 
self 
    python puts instance 
    not a keyword, must first argument to 
    any instance method 
    Use that to create instance variable 
Special Method 
    instance methods 
    https://docs.python.org/3/reference/datamodel.html
    called at special places by python 
    eg 
        __init__ 
        __str__ 
        
OOP 
    No access control 
        prefix _ is taken as private as per convention
    instance method 
        first arg is self/instance 
    instance variable 
        prefix self/instance 
    No interface or abstract 
        module abc has AbstractClass and Abstractmethod 
        using metaclass 
    class method 
        first arg is class 
    class variable 
        defined in class body 
    static method 
        does not have first arg 
    property 
        use case of descriptor 
    slots 
        restricting variable creation 
    Reflection methods 
        getattr etc 
"""
class NotEnoughBalance(Exception):
    pass   # no operation 
    
class BankAccount:
    count = 0               #class variable 
    @classmethod     # @ is called decorator 
    def how_many(cls):
        return cls.count 
    @staticmethod 
    def version():
        return "0.1"
    def __init__(self, init_balance):
        self.balance = init_balance  #ba.balance = 100
        BankAccount.count += 1
    def transact(self, amount):
        if self.balance + amount < 0:
            raise NotEnoughBalance("not possible")
        self.balance += amount       #ba.balance += 100
    def __str__(self):
        return f"BankAccount(balance={self.balance})"        
    @property 
    def amount(self):           #instance.amount
        return self.balance
        
#MRO = (SpecialBankAccount, BankAccount, object)
class SpecialBankAccount(BankAccount):
    def transact(self, amount, per=0.05):
        try:
            super().transact(amount)  #BankAccount.transact(self, amount)
            if amount < 0:
                cashback = 0.05 * abs(amount)
                super().transact(cashback)
        except NotEnoughBalance as ex:
            print(ex, "Amount:", amount)


if __name__ == '__main__':   # pragma: no cover
    accounts = [BankAccount(100), 
                SpecialBankAccount(100)]
    amounts = [100, 200, -100, 300]
    for ba in accounts:
        for am in amounts:
            ba.transact(am)
        print(ba.amount)
    print(BankAccount.how_many(), BankAccount.version())
    
    #ba = BankAccount(100) #BankAccount.__init__(ba, 100)
    #try:
    #    ba.transact(-200)      #BankAccount.transact(ba,100)
    #except NotEnoughBalance as ex:
    #    print(ex)
    #print(ba)                   #BankAccount.__str_-(ba)

































r"""
> poetry new oop 
> cd  oop 
> tree . /F 

For office PC, we need to add artefactory/internal pypi before below 
Get artefactory link 
> pip config list 
Note down index-url , then add it exactly
> poetry source add  myownpypi index-url 


Add pytest and pytest-cov as dev dependencies 
> poetry add --group dev pytest pytest-cov 
These will not be installed while installing whl 
for run time dependencies , remove --group dev 
and then those wud be installed while installing whl 

Copy classes.py to src\oop\ 
Copy test_classes.py to tests\

Update src\oop\__init__.py 
from .classes import *

Update tests\test_classes.py with below 
from oop import * 


Open pyproject.toml and add below section at the last 
>
[tool.pytest.ini_options]
pythonpath = [
  "src"
]

Enable virtual env 
> poetry env activate 
Above will give full path to execute for enable 
Execute above 
>

Then run pytest 
> pytest -v 

Then build 
> deactivate 
> poetry build -v 
> dir dist\* 
> cd ..
Can enable new virtual env 
> python -m venv .venv
> .venv\Scripts\activate
> pip install oop\dist\oop-0.1.0-py3-none-any.whl
Can work on those classes  and then decativate 
> deactivate 

"""






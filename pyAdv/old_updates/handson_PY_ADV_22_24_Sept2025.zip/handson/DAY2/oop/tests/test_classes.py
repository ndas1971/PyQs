r"""
modules - prefix test 
testcase - function with prefix test 
        use assert boolean_condition 
        if boolean_condition is False, 
        test fails 
testsuite - class with Test prefix 

Execute by 
pytest -v test_classes.py 
To get coverage 
pytest -v --cov=classes --cov-report term-missing  test_classes.py 

Filtering based on k expression 
Check help 
pytest --help 

Example 
pytest -v -k "TestAccount" test_classes.py 

Reference 
https://docs.pytest.org/en/6.2.x/fixture.html
    Test Data 
https://docs.pytest.org/en/6.2.x/capture.html
    print testing 
https://docs.pytest.org/en/6.2.x/skipping.html
    Test skipping
https://docs.pytest.org/en/6.2.x/monkeypatch.html
    mocking 

"""
from oop import * 
class TestAccount:
    def test_bankaccount(self):
        ba = BankAccount(100)
        amounts = [100, 200, -100, 300]
        for am in amounts:
            ba.transact(am)
        assert ba.amount == 600         
    def test_specialbankaccount(self):
        ba = SpecialBankAccount(100)
        amounts = [100, 200, -100, 300]
        for am in amounts:
            ba.transact(am)
        assert ba.amount == 605 
        
def test_ba_version():
    assert BankAccount.version() == "0.1"
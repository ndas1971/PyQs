"""
Web 
    selenium 
Windows GUI 
    ...
Shell automation 
    command 
    Execute the command 
    capture stdout 
        Use subprocess        https://docs.python.org/3/library/subprocess.html
        Enable  below flags 
        shell    # execute under shell 
        capture_output 
        universal_newlines or text 
        
    Extract relevant information 
        Use re and findall 
        https://docs.python.org/3/library/re.html

"""
Design an automation framework which can execute 
any command and it has a functionality of search 
any information in the command output 

Only create skeleton by following below
Hint:
1. Create a package called auto 
3. create a module command.py 
4. Create a test module test_command.py 
5. Integrate command.py content at package level 
6. Create skeleton class called Execute 
    Decide what needs to be taken as initialization
    parameter, write initialization method 
    Decide what other methods to be written 
    (hint, print is one good candidate
    also, search is another method,
    it returns a list )
7. Write test case for testing search method 
   checks whether return type is list or not    
8. pytest should run for all these 
   skeleton code 
   (hint - update pyproject.toml with following)
[tool.pytest.ini_options]
pythonpath = [
  "src"
]

##solution
poetry new auto 
cd auto 
#src\auto\command.py 
from .command import *
#src\auto\command.py 
import subprocess as S 
import re 
class Execute:
    def __init__(self, command):
        self.command = command 
    def search(self, what):
        proc = S.run([self.command], capture_output=True, universal_newlines=True)
        return re.findall(what, proc.stdout)
    def __str__(self):
        return f"Execute({self.command})"
#tests\test_command.py 
from auto import * 
def test_execute_search():
    out = Execute("systeminfo").search(r"KB\d+")
    assert type(out) is list 

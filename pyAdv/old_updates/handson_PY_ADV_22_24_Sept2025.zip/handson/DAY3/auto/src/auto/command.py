import subprocess as S
import re 

class Execute:
    def __init__(self, command):
        self.command = command 
    def search(self, what):
        proc = S.run([self.command],
            shell = True,
            capture_output=True ,
            universal_newlines=True)
        return re.findall(what, proc.stdout)

import auto 


def test_execute_search():
    ep = auto.Execute("dir")
    res = ep.search(r"\d\d-\d\d-\d\d\d\d")
    assert type(res) is list 

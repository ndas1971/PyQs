"""
Data 
    SQL 
        2D - rows x cols 
    noSQL
        xml, json 
        nested/dynamic schema 
        can not do aggregation or join 
        Extract via comprehension

2D data - rows x cols 
    columns are important 
    High level API can simplify processing 
    
Pandas 
    eager(in memory) 2D - called DataFrame 
    DataFrame - list of columns/Series 
    By default, many operations are column based 
Dask 
    lazy(disk based) pandas API 
pyspark 
    cluster pandas API 
    
Jypyter 
> jupyter lab --notebook-dir="."
Commands 
SHIFT+ENTER  run a cell 
Change to Markdown to get formatting 
Use any html tags or markdown symbols eg # is for h1 
"""
#pip install numpy pandas matplotlib openpyxl
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 

#Read 
path = r"D:\handson\DAY1\data\iris.csv"
#C:\Users\python\Desktop\data\iris.csv
iris = pd.read_csv(path)
#checking metadata 
print(iris.head())     # first five lines 
#    SepalLength  SepalWidth  PetalLength  PetalWidth         Name
# 0          5.1         3.5          1.4         0.2  Iris-setosa
# 1          4.9         3.0          1.4         0.2  Iris-setosa
# 2          4.7         3.2          1.3         0.2  Iris-setosa
# 3          4.6         3.1          1.5         0.2  Iris-setosa
# 4          5.0         3.6          1.4         0.2  Iris-setosa
iris.columns    # list fo columns 
len(iris)       # how many rows 
iris.index      #row_id is called index 
iris.dtypes     #
# SepalLength    float64    
# SepalWidth     float64
# PetalLength    float64
# PetalWidth     float64
# Name            object   #str is called object 
# dtype: object

#accessing cols or sub2D 
iris.SepalLength 
iris['SepalLength']  # type(..) = Series 
iris[['SepalLength', 'SepalWidth']] # type(..) = DataFrame 

iris[0:4]             # slice for rows, end not included 
#for sub2D - iloc[row_index, col_index]
#or .loc[row_id, col_names]
#may contain slice, in iloc, end is not included 
#in loc, end row_id is included 
#    SepalLength  SepalWidth
# 0          5.1         3.5 
# 1          4.9         3.0 
# 2          4.7         3.2 
iris.loc[0:2, ['SepalLength','SepalWidth']]
iris.iloc[0:3, [0,1]]
 
#adv loc , may contain bool query 
iris.loc[iris.SepalLength > 5, :]
#and &, or | , not ~ , Must use ()
iris.loc[(iris.SepalLength > 5) & (iris.SepalLength < 5.5), :]

#creating column 
iris['dummy'] = iris.SepalLength - 2* iris.SepalWidth - 2
iris.dummy
iris['dummy'] = np.abs(iris.dummy)  # dont use builtin fn , use numpy equiv
#drop a column
iris.drop(columns=['dummy']) #returns new DF 
iris.drop(columns=['dummy'], inplace=True) #now updated original DF 

#Applying functions 
iris.SepalLength.mean()
iris.iloc[:, 0:4].mean()
iris.iloc[:, 0:4].mean(axis=0) # columnwise
iris.iloc[:, 0:4].mean(axis=1) # rowwise
#Aggregation 
iris.Name.unique()
gr = iris.groupby("Name")
gr.mean()
gr.agg({'SepalLength': ['mean', 'count', 'min', 'max']})
gr.agg({'SepalLength': ['mean', 'count', 'min', 'max']}).to_excel("proc.xlsx")
#plot 
iris.iloc[:,0:4].plot(kind='line')
plt.savefig("p.png")

#join - Pandas cheat sheet 
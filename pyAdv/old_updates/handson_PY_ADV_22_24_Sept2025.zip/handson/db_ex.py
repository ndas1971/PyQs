"""
DB API(sql) or ORM( oop) 
Many DB engines - mysql, oracle,..
Each DB engine has many modules

Use SQlalchemy 
https://docs.sqlalchemy.org/en/14/core/engines.html
"""
from sqlalchemy import create_engine, text
engine = create_engine("sqlite:///foo.db")

create_s = "create table if not exists people(name string, age int)"
insert_s = "insert into people values(:x,:y)"  # :var called placeholder
select_s = "select age from people where name = :x"
select_s1 = "select max(age) from people"
data = [dict(name="abc", age=20), 
      dict(name="xyz", age=40)]

with engine.connect() as con:
    con.execute(text(create_s))
    for d in data:
        con.execute(text(insert_s), dict(x=d['name'], y=d['age']))
    con.commit()
    
with engine.connect() as con:
    cur = con.execute(text(select_s), dict(x="abc"))
    print(cur.fetchall()) # or cur.fetchone()
    cur = con.execute(text(select_s1))
    print(cur.fetchone()) 
#Handson 
#insert another row, name=xyz, age =40
#find the max age from people 
import subprocess as S 
import re 

class Execute:
    def __init__(self, command):
        self.command = command 
        self.proc = None 
    def __str__(self):
        return f"Execute(command={self.command})"
    def _exec(self):
        if self.proc:
            return 
        self.proc = S.run([self.command], 
                      capture_output=True,   #to capture stdout
                      universal_newlines=True) #to convert to str 
    def search(self, what):
        self._exec()
        return re.findall(what, self.proc.stdout)
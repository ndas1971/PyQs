from auto import * 


def test_execution():
    command = "systeminfo"
    p = Execute(command)
    out = p.search(r"KB\d{7}")
    assert type(out) is list 
    assert len(out) >= 1
    assert all(["KB" in e for e in out])
    #all and any -> builtin fn 
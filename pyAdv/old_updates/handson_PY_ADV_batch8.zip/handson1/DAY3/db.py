# DB API/sqlbased vs ORM/class based 
# DB engine - oracle/mysql/
# many libs/engine - 
from sqlalchemy import create_engine, text 
DATABASE_URL = "sqlite:///foo.db"
engine = create_engine(DATABASE_URL)
create_s = """create table if not exists people
(name string, age float)"""
insert_s = "insert into people values(:x,:y)"
select_q = "select name from people where age > :y"
select_q2 = "select max(age) from people"
select_q3 = "select name from people where age =(select max(age) from people)"

data = [("abc", 20.5),("xyz", 40)]
with engine.connect() as con:
    con.execute(text(create_s))
    for e in data:
        con.execute( text(insert_s), dict(x=e[0], y=e[1]))
    con.commit()    
with engine.connect() as con:
    cur = con.execute(text(select_q), dict(y=15))
    print(cur.fetchall()) #fetchone()
    cur = con.execute(text(select_q2))
    print(cur.fetchone())
    cur = con.execute(text(select_q3))
    print(cur.fetchone())
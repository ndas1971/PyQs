import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
path = r"D:\handson1\DAY1\data\iris.csv"
#READ
iris = pd.read_csv(path)
#check metadata 
len(iris)  # no of rows 
iris.columns #list of columns 
iris.head()   #first five rows 
iris.dtypes   # data types of each column 
iris.index    #row_id of each column 
#2D - DATAFRAME - list of columns, each col - Series
type(iris)
#<class 'pandas.core.frame.DataFrame'>
type(iris.SepalLength)
#<class 'pandas.core.series.Series'>
#access rows/columns 
iris.SepalLength   # object attribute access 
iris['SepalLength']  #dict like access 
iris[['SepalLength', 'SepalWidth']]
#submatrix - .loc[row_id, col_names]
#.iloc[row_index, column_index]
#slice is possible, .loc, end is included , iloc, end  is not included 
#   SepalLength  SepalWidth
#0          5.1         3.5
#1          4.9         3.0
#2          4.7         3.2
iris.iloc[0:3, [0,1]]  #or iris.iloc[0:3, 0:2]
iris.loc[0:2,['SepalLength',  'SepalWidth']]
#loc can contain bool query 
iris.loc[iris.SepalLength > 5 , :]
#&-and, |-or, ~ - not 
iris.loc[(iris.SepalLength > 5) & (iris.SepalLength < 5.5) , :]
#same 
iris[(iris.SepalLength > 5) & (iris.SepalLength < 5.5)] 

#create new columns/drop 
#assignment only using dict notation
iris['dummy'] = iris.SepalLength + 2* iris.SepalWidth - 2
#only use numpy 
iris['dummy'] = np.abs(iris.dummy)
#by default drop returns a new DF 
iris.drop(columns=['dummy'], inplace=True)
#applying a functions 
#DF, axis=0, columnwise(default), axis=1, rowwise 
iris.SepalLength.mean()   # single mean 
iris.iloc[:,0:4].mean()   #by default columwise ie 4 nos 
iris.iloc[:,0:4].mean(axis=1) #rowwise, 150 no 
iris.Name.unique()
#groupby 
gr = iris.groupby("Name")
#columnname:[fn1, fn2,..]
res = gr.agg({'SepalLength':['mean', 'max', 'count']}) 
res.to_excel("proc.xlsx")
#plot 
#uses matplotlib 
iris.iloc[:,0:4].plot(kind='line')
#plt.show()
plt.savefig("p.png")
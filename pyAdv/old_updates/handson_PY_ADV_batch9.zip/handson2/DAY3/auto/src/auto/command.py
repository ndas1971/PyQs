import subprocess as S 
import re 

class Execute:
    def __init__(self, command):
        self.command = command 
        self.proc = S.run([self.command],
                        capture_output=True,
                        universal_newlines=True)
    def __str__(self):
        return f"Execute(command={self.command},returncode={self.proc.returncode})"
    def search(self, what):
        return re.findall(what, self.proc.stdout)
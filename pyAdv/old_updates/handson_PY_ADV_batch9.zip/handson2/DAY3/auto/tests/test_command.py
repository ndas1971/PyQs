from auto import * 

def test_execution():
    command = "systeminfo"
    pat = r"KB\d{7}"
    out = Execute(command).search(pat)
    assert type(out) is list 
    assert len(out) >= 1
# DB API/sql vs ORM/class 
# DB engines - mysql/oracle/...
# many libs/engine -- 
from sqlalchemy import create_engine, text 

engine = create_engine("sqlite:///foo.db")

cs = "create table if not exists people(name string, age float)"
isq = "insert into people  values(:x, :y)"
ss = "select name, age from people"
ss2 = "select max(age) from people"
data = [('abc', 20.5),('xyz', 40)]
with engine.connect() as con:
    con.execute(text(cs))
    for n,a in data:
        con.execute(text(isq), {'x': n, "y": a})
    con.commit()
    
with engine.connect() as con:
    cur = con.execute(text(ss2))
    print(cur.fetchall())  #fetchone()
#Handson - add a row ('xyx', 40), find max of age  
"""
fetchone()
    fetch next row or None 
    when None, cursor is autoclosed
fetchall()
    all rows and cursor is autoclosed
fetchmany(size=None)
    based on size 
one(), first(), one_or_none()
    only one or exception if many or no row 
    first one 
    only one or none if many or no row 
rowcount
    how many rows impacted or returned 
keys() 
    column names 
scalar()
    return one value eg like above for max(age)
"""   

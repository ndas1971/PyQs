import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
path = r"D:\handson2\DAY1\data\iris.csv"
"""
2D - DataFrame - list of columns, series 
https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf
"""
#READ 
iris = pd.read_csv(path)
#metadata 
len(iris)  # no of rows 
iris.columns # list of columns 
iris.head()  # first five rows 
iris.dtypes # data types of each columns 
iris.index  # row_id 
#access
#SepalLength  SepalWidth  PetalLength  PetalWidth         Name
iris.SepalLength                    # Series
iris['SepalLength']                 # Series 
iris[['SepalLength','SepalWidth']]  # DataFrame 
#    SepalLength  SepalWidth
# 0          5.1         3.5
# 1          4.9         3.0
# 2          4.7         3.2
#.iloc[row_index, col_index], loc[row_id, col_names]
#slice start:end:step , iloc - end is not included 
#loc - end is included 
iris.iloc[0:3, [0,1]]  #[0:3, 0:2]
iris.loc[0:2, ['SepalLength','SepalWidth']]
#loc can have bool query 
iris.loc[iris.SepalLength > 5, :]
#and - &, or - |, not - ~
iris.loc[(iris.SepalLength > 5) & (iris.SepalLength < 5.5), :]
#possible in dict notation 
iris[(iris.SepalLength > 5) & (iris.SepalLength < 5.5)]
#create/delete 
#only dict notation 
iris['dummy'] = iris.SepalLength + 2* iris.SepalWidth - 2 
#apply a function from numpy 
iris['dummy'] = np.abs(iris.dummy)
#by default, returns new DF , to modify, use inplace 
iris.drop(columns=['dummy'], inplace=True )
iris.columns 
#function/groupby 
iris.SepalLength.mean()   #one number 
iris.iloc[:, 0:4].mean()  #by default , axis=0, columnwise means 4 no 
iris.iloc[:, 0:4].mean(axis=1)  #rowwise, 150 no, each no is mean of 4 cols 
iris.Name.unique()   #3 names 
gr = iris.groupby('Name')
#columnname:[fn1, ...]
gr.agg({'SepalLength':['mean', 'max','count']}).to_excel("p.xlsx")
#plot 
iris.iloc[:, 0:4].plot(kind='line')
plt.savefig('p.png')

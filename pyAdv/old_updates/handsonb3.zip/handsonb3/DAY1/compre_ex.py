###Comprehension
lst = [1,5,2,10]
#square each number 
o = []
for e in lst:
    o.append(e*e)
print(o)
#Square only even numbers 
o = []
for e in lst:
    if e%2 == 0:
        o.append(e*e)
print(o)
lst = [1,5,2,10]
#Equiv in list comprehension 
o = [e*e for e in lst]              #map(lambda e: e*e, lst) 
o = [e*e for e in lst if e%2 == 0]  #map(lambda e: e*e,filter(lambda e: e%2 ==0,lst))
#tuple of odd and even numbers 
o = [(e1,e2) for e1 in lst if e%2 == 1 
  for e2 in lst if e2%2 == 0]
#set comprehension 
o = {e*e for e in lst}
o = {e*e for e in lst if e%2 == 0}
#dict 
o = {e: e*e for e in lst}
o = {e: e*e for e in lst if e%2 == 0}


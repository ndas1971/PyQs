# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits
"""
Noun
    Class
Verbs
    its methods 
Class 
    collection of methods(instance)
    operating on data(instance variable)
Instance
    has memory location , has specific 
    values in instance variables   
Special methods
    https://docs.python.org/3/reference/datamodel.html
    **Initialization method 
        def __init__(self, ...)
    Prettify object 
        def __str__(self)
    
self 
    is not a key word, must be the first arg 
    By convention, self 
    where python puts the instance 
    
Relations 
    is/are - inheritance 
    has/have - composition 
            take in as initialization parameter 
            
OOP
    no access control 
    no interface of abstract key word 
        but abc has abstractmethod 
        implemented using metaclass 
    instance method /instance variable 
        first arg is self 
    class method/class variable 
        method is used to access class variable 
        and first arg is class 
    static method 
        no first arg 
    property 
        we access like instance variable 
        but python calls a method 
    slots
    ...    
    
"""
class NotEnoughBalance(Exception):
    pass 
class BankAccount:
    count = 0                       #BankAccount.count 
    @classmethod 
    def howmany(cls):               #BankAccount.howmany()
        return cls.count 
    @staticmethod
    def version():                  #BankAccount.version()
        return "0.1"
    @property 
    def balance(self):              #instance.balance
        return self.amount 
    def __init__(self, init_amount):
        self.amount = init_amount
        BankAccount.count  += 1
    def transact(self, amount):
        if self.amount + amount < 0:
            raise NotEnoughBalance("not possible")
        self.amount += amount 
    def __str__(self):
        return f"BankAccount(balance={self.amount})"
        
#MRO = (SpecialBankAccount, BankAccount, object)
class SpecialBankAccount(BankAccount): 
    def transact(self, amount, cbp=0.05):
        try:
            super().transact(amount)
            if amount < 0:
                cashback = cbp * abs(amount)
                super().transact(cashback)
        except NotEnoughBalance as ex:
            print(ex, "For amount:", amount)
        
if __name__ == '__main__':      # pragma: no cover 
    accounts = [BankAccount(100), 
                SpecialBankAccount(100)]
    amounts = [100, -50]
    for a in accounts:
        for am in amounts:
            a.transact(am)
        print(a.balance)
    print(BankAccount.howmany(), BankAccount.version())

    #ba = BankAccount(100)       #BankAccount.__init__(ba, 100)
    #try:
    #    ba.transact(-200)            #BankAccount.transact(ba, 100)
    #except NotEnoughBalance as ex:
    #    print(ex)
    ##print(ba.amount)            #no access control, all public 
    #print(ba)    
        
        


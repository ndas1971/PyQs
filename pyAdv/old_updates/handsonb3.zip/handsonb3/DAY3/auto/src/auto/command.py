import subprocess as S
import re

class Execute:
    def __init__(self, command):
        self.command = command 
    def __str__(self):
        return f"Execute({self.command})"
    def search(self, info):
        p = S.run([self.command], shell=True, 
                capture_output=True,
                universal_newlines=True)
        return re.findall(info,p.stdout)

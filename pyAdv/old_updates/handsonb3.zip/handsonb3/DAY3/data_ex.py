"""
SQL(2D, rowsxcols vs nSQL(eg XML, json-comprehension)
SQL - csv, excel....
Use Pandas 
https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf
2D - DataFrame - list of columns/Series 
2D - VIP is columns 
By default all DF operations at colum levels or axis=0 
"""
import pandas as pd 
import matplotlib.pyplot as plt
path = r"D:\handsonb3\DAY1\data\iris.csv"
iris = pd.read_csv(path)
#Metadata
iris.head()     # check few rows , by default 5 rows 
iris.columns 
iris.dtypes     #from numpy , str = object 
iris.index      #rowid is called index 
len(iris)
#Accessing columns 
type(iris)               #DF 
type(iris.SepalLength )  # Series 
iris.SepalLength 
iris['SepalLength']
iris[['SepalLength', 'SepalWidth']]  # DF 
#rows 
#.loc[row_id, columns]
#.iloc[row_index, col_index]
#iloc, slice start:end:step, end is not included 
#loc , slice - end is included 
iris.loc[0:2, ['SepalLength',  'SepalWidth']]
iris.iloc[0:3, [0,1]]
#.loc may condition = query 
iris.loc[iris.SepalLength > 5.0, :]
#and, or, not - &, |, ~
iris.loc[(iris.SepalLength > 5.0) &
     (iris.SepalLength < 5.5)   , :]
#creation of new column 
iris['dummy'] = iris.SepalLength \
    - 2*iris.PetalWidth + 2
iris.dummy 
#Dont use builtin method, use numpy equiv method 
import numpy as np 
iris['dummy'] = np.abs(iris.dummy)
#delete of column 
iris.drop(columns=['dummy'])
iris.columns # above has not updated iris but 
             # returned new updated DF 
iris.drop(columns=['dummy'], inplace=True ) #now it is updated 
#apply functions 
len(dir(iris)), len(dir(iris.SepalLength))
iris.SepalLength.mean()
iris.iloc[:,0:4].mean()# by default column wise
iris.iloc[:,0:4].mean(axis=0) #by axis=0
iris.iloc[:,0:4].mean(axis=1) #rowwise 
#Aggregation 
iris.Name.unique()
gr = iris.groupby('Name')
gr.mean()
gr.agg({'SepalLength':['mean', 'min','max']})
gr.agg({'SepalLength':['mean', 'min','max']})\
  .to_excel('p.xlsx')

#plot 
iris.iloc[:, 0:4].plot(kind='line')
plt.savefig('p.png')

#Handson 
#Read boston.csv 
path = r"D:\handsonb3\DAY1\data\boston.csv"
bo = pd.read_csv(path)
#How many cols and how many rows 
len(bo.columns)     #14 
len(bo)             #506
#Display crim, zn, indus columns 
#['crim', 'zn', 'indus', 'chas', 'nox', 'rm', 'age', 'dis', 'rad', 'tax',
#'ptratio', 'b', 'lstat', 'medv']
bo[['crim', 'zn', 'indus']]
#Display first two rows of all columns 
bo.iloc[0:2, :]
#Find min of lstat and medv
bo[['lstat', 'medv']].min()
#For each rad, find min and max value 
#of lstat and medv
gr = bo.groupby('rad')
gr.agg({'lstat':['min','max'],'medv':['min','max']})




"""
DB API(sql) vs ORM(table => class)
MANY DB engines 
many libs/engine 
Use sqlalchemy 
https://docs.sqlalchemy.org/en/20/core/engines.html

"""
from sqlalchemy import create_engine, text 
engine = create_engine("sqlite:///people.db")
csql = """create table if not exists 
 people (name string, age int)"""
isql = "insert into people values(:x,:y)"
ssql = "select age from people where name=:x"
ssql1 = "select max(age) from people"
values = [("abc", 60), ("xyz", 20)]
with engine.connect() as c:
    c.execute(text(csql))
    for n,a in values:
        c.execute(text(isql), dict(x=n, y=a))
    c.commit()       #.rollback()    
with engine.connect() as c:
    cur = c.execute(text(ssql), dict(x="abc"))
    print(cur.fetchall())   #.fetchone()
with engine.connect() as c:
    cur = c.execute(text(ssql1))
    print(cur.fetchone())
#Hands on 
#Insert another row ("abc", 60)
#Find max age 
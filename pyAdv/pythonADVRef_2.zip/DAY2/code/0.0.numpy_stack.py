import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 




print("a,b are 2D , axis=0, rowwise, axis=1, columnwise")
a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6]])
print("\na=", a, "b=", b, "np.concatenate((a, b), axis=0)=",np.concatenate((a, b), axis=0), sep="\n")
#array([[1, 2],
#       [3, 4],
#       [5, 6]])
       
#b.T
#array([[5],
#       [6]]) 

print("\na=", a, "b.T=", b.T, "np.concatenate((a, b.T), axis=1)=",np.concatenate((a, b.T), axis=1), sep="\n")
#>>> np.concatenate((a, b.T), axis=1)
#array([[1, 2, 5],
#       [3, 4, 6]])       
  
print("\na=", a, "b=", b, "np.concatenate((a, b), axis=None)=",np.concatenate((a, b), axis=None), sep="\n")
  
#>>> np.concatenate((a, b), axis=None)
#array([1, 2, 3, 4, 5, 6])



print("""
When a,b are 1D 
np.r_  
    By default: create a array(1D) from comma seperated many 
    slices start:stop:step (stop exclusive)
    or comman seperated numbers (along the first axis ie row)
    it has many other functonalities - check Reference 

np.c_ 
    create a array(2D) from comma seperated many 1D arrays 
    or start:stop:step (stop exclusive)
    but  along the second axis(ie column) -> Column stack 

note used with []   not ()
""")

#column stacking 
a = np.array([1, 2, 3])
b = np.array([4,5,6])

print("\na=", a, "b=", b, "np.c_[a,b]=",np.c_[a,b], sep="\n")

#>>> np.c_[a,b]
#array([[1, 4],
#       [2, 5],
#       [3, 6]])
#       
print("np.r_[-2:3, 0,0, 3:9]=",np.r_[-2:3, 0,0, 3:9], sep="\n")

#>>> x = np.r_[-2:3, 0,0, 3:9]
#>>> x
#array([-2, -1,  0,  1,  2,  0,  0,  3,  4,  5,  6,  7,  8]

#vstack vs hstack
a = np.array([1, 2, 3])
b = np.array([2, 3, 4])
print("\na=", a, "b=", b, "np.vstack((a,b))=",np.vstack((a,b)), sep="\n")

#>>> np.vstack((a,b))
#array([[1, 2, 3],
#       [2, 3, 4]])
print("\na=", a, "b=", b, "np.hstack((a,b))=",np.hstack((a,b)), sep="\n")

#>>> np.hstack((a,b))
#array([1, 2, 3, 2, 3, 4])

print("when a,b are 2D")
a1 = np.array([[1],[2],[3]])
b1 = np.array([[2],[3],[4]])       
print("\na=", a1, "b=", b1, "np.vstack((a,b))=",np.vstack((a1,b1)), sep="\n")

#>>> np.vstack((a1,b1))
#array([[1],
#       [2],
#       [3],
#       [2],
#       [3],
#       [4]])
print("\na=", a1, "b=", b1, "np.hstack((a,b))=",np.hstack((a1,b1)), sep="\n") 
#>>> np.hstack((a1,b1))
#array([[1, 2],
#       [2, 3],
#       [3, 4]])
#Stack 
x = [-2.1, -1,  4.3]
y = [3,  1.1,  0.12]

print("\na=", x, "b=", y, "np.stack((a, b), axis=0)=",np.stack((x, y), axis=0), sep="\n")
print("\na=", x, "b=", y, "np.stack((a, b), axis=1)=",np.stack((x, y), axis=1), sep="\n")

#>>> X = np.stack((x, y), axis=0)
#>>> X
#array([[-2.1 , -1.  ,  4.3 ],
#       [ 3.  ,  1.1 ,  0.12]])
#>>> X = np.stack((x, y), axis=1)
#>>> X
#array([[-2.1 ,  3.  ],
#       [-1.  ,  1.1 ],
#       [ 4.3 ,  0.12]])
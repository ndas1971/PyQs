import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
from sklearn_pandas import DataFrameMapper, gen_features #don't bring other methods 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline


print("--------------LogisticRegression VIF on School admissions ---------------")

print("""
admit: Yes, no ,
variables:  gre(Graduate Record Examinations), gpa(Grade Point Average) and Institutions rank(categorical)
Institutions with a rank of 1 have the highest prestige, 
""")

# module imports
from patsy import dmatrices
import pandas as pd
from sklearn.linear_model import LogisticRegression
import statsmodels.api as sm

# read in the data & create matrices
df = pd.read_csv("data/binary.csv")
y, X = dmatrices('admit ~ gre + gpa + C(rank)', df, return_type = 'dataframe')

print("sklearn output")
model = LogisticRegression(fit_intercept = False, C = 1e9)
mdl = model.fit(X, y)
print(model.coef_)



print("""
calculating VIF and dropping high VIF(>10) features
VIF is 1/(1-r^2) of each X as y vs all other X
""")

def vif_cal(input_data, dependent_col):
    x_vars = input_data.drop([dependent_col], axis=1)
    xvar_names = x_vars.columns
    for i in range(0,xvar_names.shape[0]):
        y = x_vars[xvar_names[i]] 
        x = x_vars[xvar_names.drop(xvar_names[i])]
        rsq=sm.OLS(y,x).fit().rsquared  
        vif=round(1/(1-rsq),2)
        print (xvar_names[i], " VIF = " , vif)

vif_cal(input_data=df, dependent_col="admit")





print("""
Individual Impact of Variables
    Calculate z values of the each X
    Look at their absolute values, Highest are most important , 
    Remove those near to zero
""")

logit = sm.Logit(y, X)
res = logit.fit()
#print("Coeff=", res.params, " abs z values=", res.tvalues.sort_values().abs())
#sorted coeff: res.params[res.tvalues.argsort().values]
#or: pd.DataFrame({'coeff': res.params, 'z': res.tvalues}).sort_values(by=['z'])
print("statsmodel output")
print(logit.fit().summary2())

"""
Optimization terminated successfully.
         Current function value: 0.573147
         Iterations 6
                        Results: Logit
===============================================================
Model:              Logit            No. Iterations:   6.0000
Dependent Variable: admit            Pseudo R-squared: 0.083
Date:               2019-02-02 19:16 AIC:              470.5175
No. Observations:   400              BIC:              494.4663
Df Model:           5                Log-Likelihood:   -229.26
Df Residuals:       394              LL-Null:          -249.99
Converged:          1.0000           Scale:            1.0000
---------------------------------------------------------------
                 Coef.  Std.Err.    z    P>|z|   [0.025  0.975]
---------------------------------------------------------------
Intercept       -3.9900   1.1400 -3.5001 0.0005 -6.2242 -1.7557
C(rank)[T.2]    -0.6754   0.3165 -2.1342 0.0328 -1.2958 -0.0551
C(rank)[T.3]    -1.3402   0.3453 -3.8812 0.0001 -2.0170 -0.6634
C(rank)[T.4]    -1.5515   0.4178 -3.7131 0.0002 -2.3704 -0.7325
gre              0.0023   0.0011  2.0699 0.0385  0.0001  0.0044
gpa              0.8040   0.3318  2.4231 0.0154  0.1537  1.4544
===============================================================
"""
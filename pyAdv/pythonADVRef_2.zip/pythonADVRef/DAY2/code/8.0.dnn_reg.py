import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)
warnings.simplefilter(action='ignore', category=DeprecationWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *
import time 

print("----------------- DNN on boston regression  ----------------")

from keras.models import Sequential, load_model
from keras.layers import Dense, Activation 
from keras.wrappers.scikit_learn import KerasClassifier
import keras.utils 
from keras.callbacks import * 

print('''
Target : The last column MEDV is a median value of owner-occupied homes in $1000
Features:
CRIM per capita crime rate by town
ZN proportion of residential land zoned for lots over 25,000 sq.ft.
INDUS proportion of non-retail business acres per town
CHAS Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
NOX nitric oxides concentration (parts per 10 million)
RM average number of rooms per dwelling
AGE proportion of owner-occupied units built prior to 1940
DIS weighted distances to five Boston employment centres
RAD index of accessibility to radial highways
TAX full-value property-tax rate per $10,000
PTRATIO pupil-teacher ratio by town
B 1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
LSTAT % lower status of the population
''')

# Read dataset into X and Y
df = pd.read_csv('data/boston.csv')
dataset = df.values

X = dataset[:, 0:13]
Y = dataset[:, 13]

#print "X: ", X
#print "Y: ", Y


#13 feature/input, one output

#Note Activation 
#Regression: linear (because values are unbounded)
#Classification: softmax (simple sigmoid works too but softmax works better)
#for binary, sigmoid is also ok , but the output is not a probability distribution (does not need to sum to 1).

#Sigmoid and tanh should not be used as activation function for the hidden layer. 
#This is because of the vanishing gradient problem, i.e., if your input is on a higher side (where sigmoid goes flat) then the gradient will be near zero. 
#The best function for hidden layers is thus ReLu.

def build_nn(dense1_out=20, dense1_activation='relu', dense1_init="normal"):
    model = Sequential()
    model.add(Dense(dense1_out, input_dim=13, kernel_initializer=dense1_init, activation=dense1_activation))
    # No activation needed in output layer (because regression)
    model.add(Dense(1, kernel_initializer=dense1_init))
    model.add(Activation("linear")) #by default, so no need to add 
    # Compile Model
    model.compile(loss='mean_squared_error', optimizer='adam', metrics=['mse'])
    return model


# Evaluate model (kFold cross validation)
from keras.wrappers.scikit_learn import KerasRegressor

#batch_size < n_samples 
#note Network parameters get updated (forward and backword ie one pass)
#only n_samples/batch_size (if not divisible, then last batch is only delta)
#hence per pass, requires less memory nd multiple updates are done for whole data set 

#if batch_size == n_samples, only 1 update, but high memory is required 

# Before feeding the i/p into neural-network, standardise the dataset because all input variables vary in their scales
estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, epochs=100, batch_size=5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=5, shuffle=True)
results = cross_val_score(pipeline, X, Y, cv=kfold)

#MSE 
print("MSE Mean: ", results.mean()) #-16.17353722710814
print("MSE StdDev: ", results.std()) #StdDev:  6.191083824421029

print(" ------------------- GridSearch ------------")
#initializers are used to thwart local minimum 
params = dict(
    mlp__epochs = [ 500, 1000],
    mlp__dense1_out = [20,48, 64],
    mlp__dense1_activation = ['relu'],
    mlp__dense1_init = ['glorot_normal', 'normal']
)

X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0)

estimators = []
estimators.append(('trx', StandardScaler()))
estimators.append(('mlp', KerasRegressor(build_fn=build_nn, batch_size = 5, verbose=0)))

pipeline = Pipeline(estimators)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(pipeline, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
time.time()-st  #705.3032658100128 sec

print("Best Params", search.best_params_ ) #{'mlp__dense1_init': 'glorot_normal', 'mlp__batch_size': 5, 'mlp__epochs': 300,'mlp__dense1_activation': 'relu', 'mlp__dense1_out': 48}
print("Train score", search.score( X_train, y_train) ) #3.2275988869270735
print("test score", search.score( X_test, y_test)) #15.513392695409106

predictions = search.predict( X_test)
print("test R^2", r2_score(y_test, predictions)) #0.8101153048345232
import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)
warnings.simplefilter(action='ignore', category=UserWarning)
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # or any {'0', '1', '2'}
import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)


import numpy as np
from keras.models import Sequential
from keras.layers.core import Dense

#ie 0,0 => 0 
training_data = np.array([[0,0],[0,1],[1,0],[1,1]], "float32")
target_data = np.array([[0],[1],[1],[0]], "float32")

model = Sequential()

#Regular densely-connected NN layer.
#4 , dimensionality of the output space.
#activation: Activation function to use . 
#input_dim= n , for n features or (x,y) for 2D feature 
model.add(Dense(4, input_dim=2, 
                    activation='relu',
                    kernel_initializer='random_uniform',
                    bias_initializer='zeros'))
#use relu for internal and for classification, use sigmoid or softmax 
model.add(Dense(1, activation='sigmoid',
                    kernel_initializer='random_uniform',
                    bias_initializer='zeros'))
print("XOR model")
print(model.summary())
model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])
print("""
weights for 4 DenslyConnected Hidden layer and output layer after each epoch
layers[0]
    weights.shape = (2,4) as no of input is 2 ie for each input, 4 weights 
    bias.shape =  (4,)
layers[1]
    weights.shape = (4,1) as no of output is 1 
    bias.shape =  (1,)
   
One Epoch - forward and back propagation of all 4 data points 
There are total four data points 
    input 
x1          x2      y
0           0       0
0           1       1
1           0       1
1           1       0
""")
from keras.callbacks import LambdaCallback, CSVLogger

#Callback that streams epoch results to a csv file.
csv_logger = CSVLogger('training.log')

#epoch - how many passes of full x,y data , 
#Prints Weights after each epock 
#keras.callbacks.LambdaCallback(on_epoch_begin=None, on_epoch_end=None, on_batch_begin=None, on_batch_end=None, on_train_begin=None, on_train_end=None)
#on_epoch_begin and on_epoch_end expect two positional arguments: epoch, logs
#on_batch_begin and on_batch_end expect two positional arguments: batch, logs
#on_train_begin and on_train_end expect one positional argument: logs

#or Use model.get_weights()
print_weights = LambdaCallback(on_epoch_begin=lambda epoch, logs: print("Weights of layer 0", model.layers[0].get_weights(), "Weights of layer 1", model.layers[1].get_weights(), sep='\n'), 
                               on_epoch_end= lambda epoch, logs: print("Loss", logs['loss']))

model.fit(training_data, target_data, nb_epoch=20, callbacks = [print_weights, ])

          
#for binary, round it 
print("---------------Final Result --------------")
print("predictions for\nX= ", training_data, "\nwith target\n Y_true=", target_data)
predictions = model.predict(training_data) #in float64
rounded = [round(x[0]) for x in predictions]
print("y_pred=",rounded)

scores = model.evaluate(training_data, target_data) #here metrics are used 
print("evaluate returns [ test loss, accuracy], take only accuracy ")
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
#binary_accuracy: 100.00%


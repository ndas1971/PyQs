from tpot import TPOTClassifier
from sklearn.model_selection import train_test_split
import pandas as pd 
import numpy as np

# Load the data
titanic = pd.read_csv('data/titanic_train.csv')


print("""
The TPOTClassifier performs an intelligent search over machine learning pipelines that can contain supervised classification models, preprocessors, feature selection techniques, and any other estimator or transformer that follows the scikit-learn API. 
The TPOTClassifier will also search over the hyperparameters of all objects in the pipeline.
By default, TPOTClassifier will search over a broad range of supervised classification algorithms, transformers, and their parameters. 
However, the algorithms, transformers, and hyperparameters that the TPOTClassifier searches over can be fully customized using the config_dict parameter.

Main tunings:

generations: int, optional (default=100)
    Number of iterations to the run pipeline optimization process. Must be a positive number.
    Generally, TPOT will work better when you give it more generations (and therefore time) to optimize the pipeline.
    TPOT will evaluate population_size + generations × offspring_size pipelines in total. 
population_size: int, optional (default=100)
    Number of individuals to retain in the genetic programming population every generation. Must be a positive number.
    Generally, TPOT will work better when you give it more individuals with which to optimize the pipeline. 
offspring_size: int, optional (default=100)
    Number of offspring to produce in each genetic programming generation. Must be a positive number. 
mutation_rate: float, optional (default=0.9)
    Mutation rate for the genetic programming algorithm in the range [0.0, 1.0]. This parameter tells the GP algorithm how many pipelines to apply random changes to every generation.
    mutation_rate + crossover_rate cannot exceed 1.0.
    We recommend using the default parameter unless you understand how the mutation rate affects GP algorithms. 
crossover_rate: float, optional (default=0.1)
    Crossover rate for the genetic programming algorithm in the range [0.0, 1.0]. This parameter tells the genetic programming algorithm how many pipelines to "breed" every generation.
    mutation_rate + crossover_rate cannot exceed 1.0.
    We recommend using the default parameter unless you understand how the crossover rate affects GP algorithms. 
""")

#The first and most important step in using TPOT on any data set 
#is to rename the target class/response variable to class.
titanic.rename(columns={'survived': 'class'}, inplace=True)
#At present, TPOT requires all the data to be in numerical format. 
#Categorical:  Name, Sex, Ticket, Cabin and Embarked.

#number of levels that each of the five categorical variables have.
for cat in ['name', 'sex', 'ticket', 'cabin', 'embarked']:
    print("Number of levels in category '{0}': \b {1:2.2f} ".format(cat, titanic[cat].unique().size))

#output 
# Number of levels in category 'Name':  891.00 
# Number of levels in category 'Sex':  2.00 
# Number of levels in category 'Ticket':  681.00 
# Number of levels in category 'Cabin':  148.00 
# Number of levels in category 'Embarked':  4.00 

#Find level 
for cat in ['sex', 'embarked']:
    print("Levels for catgeory '{0}': {1}".format(cat, titanic[cat].unique()))

#output 
#Levels for catgeory 'Sex': ['male' 'female']
#Levels for catgeory 'Embarked': ['S' 'C' 'Q' nan]

#code these levels manually into numerical values. 
#For nan i.e. the missing values, replace them with a placeholder value (-999). 
titanic['sex'] = titanic['sex'].map({'male':0,'female':1})
titanic['embarked'] = titanic['embarked'].map({'S':0,'C':1,'Q':2})
titanic = titanic.fillna(-999)

#Drop - Name and Ticket and Cabin  as they  have so many levels
#For Cabin, encode the levels as digits using Scikit-learn's MultiLabelBinarizer and treat them as new features.

from sklearn.preprocessing import MultiLabelBinarizer
mlb = MultiLabelBinarizer()
CabinTrans = mlb.fit_transform([{str(val)} for val in titanic['cabin'].values])
#>>> CabinTrans
#array([[1, 0, 0, ..., 0, 0, 0],
#       [0, 0, 0, ..., 0, 0, 0],
#       [1, 0, 0, ..., 0, 0, 0],
#       ..., 
#       [1, 0, 0, ..., 0, 0, 0],
#       [0, 0, 0, ..., 0, 0, 0],
#       [1, 0, 0, ..., 0, 0, 0]])

#axis=1, column 
titanic_new = titanic.drop(['name','ticket','cabin','class'], axis=1)
assert (len(titanic['cabin'].unique()) == len(mlb.classes_)), "Not Equal" #check correct encoding done
#Stack columnwise 
#titanic_new = np.hstack((titanic_new.values,CabinTrans))
#False
#sklearn only understands ndarray (Not true anymore)
titanic_class = titanic['class'].values


##Data Analysis using TPOT
X = titanic_new
y = titanic['class']
X_train, X_test, y_train, y_test = train_test_split(X,y, stratify = titanic_class, train_size=0.75, test_size=0.25)

tpot = TPOTClassifier(generations=2, verbosity=2, population_size=100)
tpot.fit(X_train, y_train)
print(f"""
Train score:
{tpot.score(X_train, y_train)}
test score:
{tpot.score(X_test, y_test)}
""")
#0.8340807174887892
tpot.export('tpot_titanic_pipeline.py')
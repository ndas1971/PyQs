import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
from patsy import dmatrices
import numpy as np 
import pandas as pd 

df = pd.read_csv('data/loan.csv')
df = df._get_numeric_data() #drop non-numeric cols
#drop columns where all NaN 
df = df.dropna(how='all',axis=1) #axis=0, rowwise, axis=1 columnswise 
df.index = df.id
df.head()

#Get subset 
df = df[['annual_inc','loan_amnt', 'funded_amnt','dti']].dropna() 

#run the cell, capturing stdout, stderr, and IPython’s rich display() calls.
#and discard 
#%%capture
#gather features
features = "+".join(set(df.columns) - {'annual_inc'})

#Construct a single design matrix given a formula_like and data.
y, X = dmatrices('annual_inc ~' + features, df, return_type='dataframe')


#Calculate VIF Factors
# For each X, calculate VIF and save in dataframe
vif = pd.DataFrame()
vif["VIF Factor"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
vif["features"] = X.columns
print(vif.round(1))

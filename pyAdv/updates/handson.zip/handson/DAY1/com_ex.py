lst = [1,2,3]
#Square every number 
o = []   #create empty set 
for e in lst:
    o.append( e*e)  # how to add into set 
print(o)
#python - comprehension 
o = [e*e for e in lst]
[ n.text for n in nn]
#equv 
o = []
for n in nn:
    o.append(n.text) 

#Guard - square all even numbers 
o = [e*e for e in lst if e%2 == 0]
#Create set of square of all even numbers 
o = {e*e for e in lst if e%2 == 0}
#create a dict of even number 
o = {e: e*e for e in lst if e%2 == 0}
#Create even and odd tuple 
o = [(e,e1) for e in lst if e%2 == 0
             for e1 in lst if e1%2 == 1]
#Equiv 
o = []
for e in lst:
    if e%2 == 0:
        for e1 in lst:
            if e1%2 == 1:
                o.append( (e,e1) )
#Write a function convert which converts 
#deg to C and vice versa 
#(deg * 9/5) + 32 = f
#(f - 32) * 5/9 = deg

def convert(value, unit):
    conv = dict(C = lambda deg : (deg * 9/5) + 32,
               F = lambda f : (f - 32) * 5/9  )
    fn = conv.get(unit, None)
    if fn is not None:
        return fn(value)
    
    
    
if __name__ == '__main__':
    values = [(0, 'F'), (0, 'C')]
    for v,u in values:
        print(f"{v=}, {u=}, {convert(v,u)=}")
        
"""
lambda deg : (deg * 9/5) + 32
#equiv#
def deg_to_F(deg):
    return (deg * 9/5) + 32


"""
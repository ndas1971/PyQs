"""
### Module concepts 
Lib 
    We use 'poetry' package manager 
    to create *.whl out of package 
    and we install by 
    >pip install *.whl 
    
package 
    directory containing modules 
    and __init__.py(package initialization module)
    
module 
    file with .py extension 
    contains reusable code 
        functions, classes 
    local modules     
    global modules     
    virtual env module 

script 
    We execute in shell 
    >python filename.py arg1 arg2 ..
    here, we import modules 
    
##Packaging 
create a project 
> poetry new demo 
> cd demo 
> tree . /F 
pyproject.toml - project conf file 
> type pyproject.toml
    
"""
# Create a module utilities which has a function named convert 
# it converts degree to Fahrenheit and vice versa using below 
# (deg * 9/5) + 32 = f
# (f - 32) * 5/9 = deg

#mypy - type checker, execute by below to see type consistency 
#Type - https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html
#mypy utilities.py
#install it at first , pip install mypy  

#Match tutorials - https://peps.python.org/pep-0636/

from enum import Enum 
Unit = Enum('Unit', ['F', 'C'])

def convert(value: int|float, unit:Unit) -> float:
    conv = {Unit.C : lambda deg: (deg * 9/5) + 32,
            Unit.F : lambda f: (f - 32) * 5/9 } 
    match unit:
        case Unit():
            return conv[unit](value)
        case _:
            raise NotImplementedError("not valid unit")
        
        
if __name__ == '__main__':
    values: list[tuple[int,Unit]] = [(0,Unit.C), (0,Unit.F)]
    for v,u in values:
        print(f"{v=},{u=}, {convert(v,u)=}")
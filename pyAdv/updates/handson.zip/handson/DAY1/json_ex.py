import json 
path = r"D:\handson\DAY1\data\example.json"
with open(path, "rt") as f:
    obj = json.load(f)

#empIF
[emp['empId'] for emp in obj]
[1, 20]
#firstname
[emp['details']['firstName'] for emp in obj]
#['John', 'Johns']
[emp['details']['address']['state'] for emp in obj]
#['NY', 'CL']

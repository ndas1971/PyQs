# Bank User has name and account. There are two types of Users
# Normal and privileged user . There are two types of privileged
# users, Gold and Silver. Gold has cashback of 5% and Silver has 
# cashback of 3% of expenditure when they spend any cash 
"""
Noun
    class     
Verb 
    method of that class 
STEPs
    find initial parameters which initializes 
    the instance 
    Then write initializer method to take those 
    and create instance variable 
    Write other methods to modify those variabels 

Instance method 
Instance variable 
Self 
    not a key word , by convention, it is called self 
    Must be first argument 
    where python puts the instance 
Special method 
    https://docs.python.org/3/reference/datamodel.html#special-method-names
    Operator overloading
    These are instance methodsso first arg is selfor instance 
    
oop relation 
    has/have - composition 
        __init__ 
    is/are  - inheritance
Design Pattern 
    pattern template 
        algo in base class 
        tweaking in derived 
OOP in python 
    no access control 
        prefix _ is taken as private 
        by convention 
    instance method 
        first arg is instance 
    instance variable 
        self as prefix 
    class method 
        first arg is class 
        create by @classmethod 
        Only we can access class variables 
    class variable 
        defined in body of class 
        Access by ClassName as prefix 
    static method 
        there is no first arg 
        @staticmethod 
    property 
        we use as instance variable 
        but py calls a method 
        Refer - classPrimer.py 
    no interface or abstract 
        abstract class using metaclass 
    metaclass 
        metaclass is a class which creates 
        other class 
    slots 
        restricting variable creation 
    descriptor 
        get/set 
        ex: property 
    Design pattern 
        decorator 
        Iterator/generator 
        
"""
class NotEnoughBalance(Exception): # inheritance 
    pass

class BankAccount:
    def __init__(self, init_amount):
        self.amount = init_amount
    def transact(self, amount):
        if self.amount + amount < 0:
            raise NotEnoughBalance("no possible")
        self.amount += amount 
    def __str__(self):
        return f"BankAccount(balance={self.amount})"
        
        
class BankUser:
    count = 0           #class variable 
    def __init__(self, name, init_amount):
        self.name = name 
        self.account = BankAccount(init_amount)
        BankUser.count += 1   #<=== class variable access
        # count = 0             #simple variable 
        # self.count = 0        #instance variable 
    @classmethod                #@ means decorator 
    def how_many(cls):
        return cls.count 
    @property 
    def balance(self):
        return self.account.amount 
    @staticmethod 
    def version():          #BankUser.version()
        return "0.1"
    def __str__(self):
        return f"BankUser({self.name},{self.account})"
    def transact(self, amount):    
        try:
            self.account.transact(amount) #delegate
            if amount < 0:
                cashback = self.get_cashback_percentage() * abs(amount)
                self.account.transact(cashback)
        except NotEnoughBalance as ex:
            print(ex,"Name:", self.name, "Amount:", amount)
    def get_cashback_percentage(self):
        return 0 
        
class GoldUser(BankUser):
    def get_cashback_percentage(self):
        return 0.05 
    
class NormalUser(BankUser):
    def get_cashback_percentage(self):
        return super().get_cashback_percentage() 

class SilverUser(BankUser):
    def get_cashback_percentage(self):
        return 0.03     
        
if __name__ == '__main__':      # pragma: no cover
    bu = [GoldUser("Gold", 100),        
          SilverUser("Silver", 100),
          NormalUser("Normal", 100)]
    amounts = [100,-200, 300, -400, 500]
    for u in bu:
        for am in amounts:
            u.transact(am)
        print(u.balance)
    print(BankUser.how_many())
    
    # bu = BankUser("ABC", 100)    #BankUser.__init__(ba, "ABC", 100)
    # bu.transact(-200)            #BankUser.transact(ba, 100)
    # print(bu)                    #BankUser.__str__(ba)
    
"""#GoldUser, BankUser, object 

gold = GoldUser("Gold", 100) 
    BankUser.__init__(gold, "ABC", 100)
        gold.name = name 
        gold.account = BankAccount(init_amount)
gold.transact(-100)
    BankUser.transact(gold, -100)
        gold.account.transact(-100)  #above account 
            BankAccount.transact(gold.account, -100) =>DOne 
        cashback = gold.get_cashback_percentage() * abs(amount)
gold.get_cashback_percentage()
    return 0.05 
    
"""
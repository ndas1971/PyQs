from __future__ import print_function

print('''Trains a simple convnet on the MNIST dataset.

Gets to 99.25% test accuracy after 12 epochs
(there is still a lot of margin for parameter tuning).
16 seconds per epoch on a GRID K520 GPU.
''')



from tensorflow import keras
import numpy as np
from keras import layers

"""
## Prepare the data
"""

# Model / data parameters
num_classes = 10
input_shape = (28, 28, 1)

# Load the data and split it between train and test sets
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# Scale images to the [0, 1] range
x_train = x_train.astype("float32") / 255
x_test = x_test.astype("float32") / 255
# Make sure images have shape (28, 28, 1)
x_train = np.expand_dims(x_train, -1)
x_test = np.expand_dims(x_test, -1)
print("x_train shape:", x_train.shape)
print(x_train.shape[0], "train samples")
print(x_test.shape[0], "test samples")

y_test_original = y_test.copy()


# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

"""
## Build the model
"""

model = keras.Sequential(
    [
        keras.Input(shape=input_shape),
        layers.Conv2D(32, kernel_size=(3, 3), activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2)),
        layers.Conv2D(64, kernel_size=(3, 3), activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2)),
        layers.Flatten(),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation="softmax"),
    ]
)

model.summary()

"""
## Train the model
"""

batch_size = 128
epochs = 15

model.compile(loss="categorical_crossentropy", optimizer="adam", metrics=["accuracy"])

model.fit(x_train, y_train, batch_size=batch_size, epochs=epochs, validation_split=0.1)

"""
## Evaluate the trained model
"""

score = model.evaluate(x_test, y_test, verbose=0)
print("Test loss:", score[0])
print("Test accuracy:", score[1])

predictions = model.predict(x_test)
print("Predictions: note one hot encoded is not collapsed")
print(np.round(predictions))
# array([[0., 0., 0., ..., 1., 0., 0.],
       # [0., 0., 1., ..., 0., 0., 0.],
       # [0., 1., 0., ..., 0., 0., 0.],
       # ...,
       # [0., 0., 0., ..., 0., 0., 0.],
       # [0., 0., 0., ..., 0., 0., 0.],
       # [0., 0., 0., ..., 0., 0., 0.]], dtype=float32)

print("digit predictions", np.argmax(predictions, axis=1))#rowwise 
#array([7, 2, 1, ..., 4, 5, 6], dtype=int64)

from sklearn.metrics import *  
print("confusion_matrix",confusion_matrix(y_test_original, np.argmax(predictions, axis=1) ))
# array([[ 976,    1,    0,    0,    0,    1,    1,    1,    0,    0],
       # [   0, 1125,    2,    0,    0,    1,    2,    2,    3,    0],
       # [   4,    0, 1019,    2,    0,    0,    0,    4,    3,    0],
       # [   0,    0,    8,  991,    0,    1,    0,    3,    1,    6],
       # [   1,    1,    7,    0,  958,    0,    1,    3,    1,   10],
       # [   2,    1,    0,    7,    1,  877,    2,    0,    2,    0],
       # [   5,    2,    0,    1,    2,   10,  938,    0,    0,    0],
       # [   2,    1,    8,    0,    0,    0,    0, 1010,    4,    3],
       # [   5,    1,    2,    4,    1,    4,    0,    2,  950,    5],
       # [   1,    2,    0,    4,    7,    3,    0,    4,    1,  987]],
      # dtype=int64)

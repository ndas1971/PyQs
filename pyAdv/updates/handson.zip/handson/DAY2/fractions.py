#Implement based on USage 
class Fraction:
    def __init__(self, n, d):
        self.n = n 
        self.d = d 
    def __str__(self):
        return f"Fraction({self.n}, {self.d})" #c.n=5, c.d=6
    def __add__(self, other): #self=a, other=b 
        n = self.n * other.d + self.d * other.n 
        d = self.d * other.d  # d = a.d * b.d 
        return Fraction(n,d)


if __name__ == '__main__':
    # 1/3  +   1/2 =  5/6
    a = Fraction(1,3)   # a.n=1, a.d=3
    b = Fraction(1,2)   #b.n =1, b.d=2
    c = a + b           #c = Fraction.__add__(a,b)
    #c == Fraction(5,6)
    print(c)       #Fraction(5, 6)  #Fraction.__str__ (c)
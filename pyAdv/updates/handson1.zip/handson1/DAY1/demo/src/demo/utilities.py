#Write a function 'convert' which converts 
#deg to F and vice versa 
#Use lambda of these 
#- (deg * 9/5) + 32 = f
# -(f - 32) * 5/9 = deg
#Use Enum for F and C to denote F and deg 


"""
Type 
https://mypy.readthedocs.io/en/latest/cheat_sheet_py3.html
To check type related errors 
>mypy src\demo\utilities.py 

Match
https://peps.python.org/pep-0636/
"""
from enum import Enum 
Unit = Enum("Unit", ['F', 'C']) #both Unit must match 

def convert(value: int|float, unit:Unit)-> float:
    d2f = lambda deg: (deg * 9/5) + 32
    f2d = lambda f: (f - 32) * 5/9
    conv = {Unit.F : f2d , Unit.C: d2f }
    match unit:
        case Unit():
            return conv[unit](value)
        case _:
            raise Exception("not valid unit")


#to add script code in module
if __name__ == '__main__':
    #understanding enum 
    #print(Unit.F, Unit.C) 
    values : list[int|float] = [0, 32]
    units = [Unit.F] * len(values) + [Unit.C] * len(values)
    for v, u in zip([*values, *values], units):
        print(f"{v=},{u=}, {convert(v,u)}")
    
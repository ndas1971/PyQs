# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 
"""
OOD 
    classes - nouns 
    relationships of classes - is/are(inheritance) OR has/have(composition - __init__) 
    Sequence of calling class's instance methods - verbs

Special methods 
    https://docs.python.org/3/reference/datamodel.html
    operator overloading,
        operators => instance methods 
        in, len, +, - ...
    signature is fixed 
        name, args, return are fixed and describe in above link 
    instance 
        __init__ 
        
Refer - learning python 
Other subjects 
    instance/method and variables 
    no access control 
    
    ----------
    no interface/abstract keyword 
        but, you have abstractmethod 
        which is implemented using metaclass 
    class methods/variables 
        equiv java static 
    static method 
    ....
"""
class NotEnoughBalance(Exception): #inheritance 
    pass 

class BankAccount:
    def __init__(self, init_amount): #self=ba, init_amount=100
        self.balance = init_amount   #ba.balance = 100
    def transact(self, amount):
        if self.balance + amount < 0:
            raise NotEnoughBalance("not possible")
        self.balance += amount  #ba.balance += 100
    def __str__(self):
        return f"{self.get_account_type()}({self.balance})"
    def get_account_type(self):
        return "BankAccount"
        
class SpecialBankAccount(BankAccount):
    def transact(self, amount):
        super().transact(amount)
        if amount < 0:
            cashback = self.get_cashback_percentage() * abs(amount)
            super().transact(cashback)    
    def get_account_type(self):
        return "SpecialBankAccount"
    def get_cashback_percentage(self):
        return 0.05
        
class SuperSpecialBankAccount(SpecialBankAccount):
    def get_account_type(self):
        return "SuperSpecialBankAccount"
    def get_cashback_percentage(self):
        return 0.1
        
        
if __name__ == '__main__': # pragma: no cover 
    #create instance 
    # ba = BankAccount(100) #BankAccount.__init__(ba, 100)
    # try:
    #     ba.transact(-1000)      #BankAccount.transact(ba, 100)
    # except NotEnoughBalance as ex:
    #     print(ex)
    # print(ba)
    bas = [BankAccount(100), 
          SpecialBankAccount(100),
          SuperSpecialBankAccount(100),
          ]
    amounts = [100,-50,100,-50,100,-1000]
    for ba in bas:
        for am in amounts:
            try:
                ba.transact(am)   
            except NotEnoughBalance as ex:
                print(ex)
        print(ba)
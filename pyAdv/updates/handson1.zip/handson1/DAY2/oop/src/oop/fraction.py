#Write Fraction class and its test cases to make 100% coverage,  a= Fraction(1,3);
#b=Fraction(1,2);c = a + b;print(c) prints Fraction(5,6)

class Fraction:
    def __init__(self, n, d):
        self.n = n 
        self.d = d 
    def __add__(self, other):
        d = self.d * other.d 
        n = self.n * other.d + \
                other.n * self.d 
        return Fraction(n, d)
    def __str__(self):
        return f"Fraction({self.n},{self.d})"
"""
commands:
pytest -v 
pytest -v --cov=oop --cov-report term-missing 

Filtering based on k expression 
pytest -v -k "not transact"
pytest -v -k "exception or transact"
pytest -v -k "exception"

Testcase 
    function with test_ prefix 
    conatining atleast one assert 
    assert condition, condition true, testcase passed 
    condition is false, testcase fails 
Test suite 
    class with similar testcase, named Test* 
Test module 
    file with test_*.py 
    
Commands 
pytest -m 
pytest -v -m account 
pytest -v -m fraction 
pytest -v -m "not fraction"
pytest -v -m "account" -k "exception"
"""
from oop import * 
import pytest 

#can stack many decorators 
@pytest.mark.account 
class TestBankAccount:
    def test_ba_exception(self):
        ba = BankAccount(100)
        with pytest.raises(NotEnoughBalance):
            ba.transact(-1000)
    def test_ba_transact(self):
        ba = BankAccount(100)
        ba.transact(100)
        assert ba.balance == 200 
    def test_ba_str(self):
        ba = BankAccount(100)
        assert str(ba) == 'BankAccount(100)'


def test_special_account_transact():
    ba = SpecialBankAccount(100)
    amounts = [100,-50,100,-50,100,-1000]
    for am in amounts:
        try:
            ba.transact(am)   
        except NotEnoughBalance as ex:
            print(ex)
    assert ba.balance == 305
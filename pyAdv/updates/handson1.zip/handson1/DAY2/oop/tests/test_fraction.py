"""
commands:
pytest -v 
pytest -v --cov=oop --cov-report term-missing 

Filtering based on k expression 
pytest -v -k "not transact"
pytest -v -k "exception or transact"
pytest -v -k "exception"

Testcase 
    function with test_ prefix 
    conatining atleast one assert 
    assert condition, condition true, testcase passed 
    condition is false, testcase fails 
Test suite 
    class with similar testcase, named Test* 
Test module 
    file with test_*.py 
"""
from oop import * 
import pytest 

@pytest.mark.fraction
class TestFraction:
    def test_addition(self):
        a = Fraction(1,2)
        b = Fraction(1,3)
        c = a + b
        assert str(c) == "Fraction(5,6)"

#Write a function convert which converts 
#deg to C and vice versa 
#(deg * 9/5) + 32 = f
#(f - 32) * 5/9 = deg
r"""
Type 
https://mypy.readthedocs.io/en/latest/cheat_sheet_py3.html
To check type related errors 
>mypy src\demo\utilities.py 

Match
https://peps.python.org/pep-0636
"""


from enum import Enum 
Unit = Enum("Unit", ['F', 'C'])


def convert(value: int|float, /, unit=Unit)->float:
    conv = {Unit.F : lambda f: (f - 32) * 5/9,
            Unit.C : lambda deg: (deg * 9/5) + 32}
    match unit:
        case Unit():
            return conv[unit](value)
        case _:
            raise Exception("not valid Unit")
            
            
# To include script code in module 
#when we import a module, __name__ become module_filename 
#when we execute , python that_file.py, __name__ becomes __main__           
if __name__ == '__main__':
    values: list[int|float] = [0, 32]
    units = [Unit.F] * len(values) + [Unit.C] * len(values)
    for v, u in zip([*values, *values], units):
        print(f"{v=} {u=} -> {convert(v,u)=}")

# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 
"""
OOD 
    classes - Nouns 
    classes with other classes - relationship 
        has/have - composition 
        is/are  - inheritance 
    class's instance  methods - verbs 
    
Special methods 
    https://docs.python.org/3/reference/datamodel.html
    instance => __init__ 
    operator overloading
        in, len, +, - => Special method 
    Signature is fixed 
        name, #args, retutn descrive in abovve link 
    
COncepts 
    no access control 
    instance variable 
        prefix=self 
        self.some_name = something 
    instance method 
        first arg is self 
        Note self is not keyword 
        
    ----REFER Learning Python book -----
    interface or abstract keyword 
        refer module abc 
        created abstract concept using metaclass 
    class methods and variables 
        equiv java static 
        class methods - @classmethod 
        first arg becomes class 
    static method 
        created by @staticmethod 
        there is no first argument 
    property 
    __slots__
    Metaclass 
        class which creates other class 
        inheritance from default metaclass(type)
        -- metaprogramming 
    Reflection 
    
"""
class NotEnoughBalance(Exception): #inheritance
    pass 
    
class BankAccount:
    def __init__(self, initial_balance): #self=ba, initial=100 
        self.balance = initial_balance   #ba.balance = 100
    def transact(self, amount):
        if self.balance + amount < 0:
            raise NotEnoughBalance("not possible")
        self.balance += amount  #ba.balance += 100 
    def __str__(self):
        return f"{self.get_account_type()}({self.balance})"
    def get_account_type(self):
        return "BankAccount"
        
class SpecialBankAccount(BankAccount):
    def transact(self, amount):
        super().transact(amount)
        if amount < 0:
            cashback = \
                self.get_cashback_percentage() * \
                abs(amount)
            super().transact(cashback)
    def get_account_type(self):
        return "SpecialBankAccount"
    def get_cashback_percentage(self):
        return 0.05 
        
class GoldSpecialBankAccount(SpecialBankAccount):
    def get_account_type(self):
        return "GoldSpecialBankAccount"
    def get_cashback_percentage(self):
        return 0.1 
        
if __name__ == '__main__': # pragma: no cover 
    #creating instance 
    #ba = BankAccount(100) #BankAccount.__init__(ba, 100)
    #try:
    #    ba.transact(-1000)      #BankAccount.transact(ba, 100)
    #except NotEnoughBalance as ex:
    #    print(ex) 
    #print(ba)          #200
    bas = [BankAccount(100),
           SpecialBankAccount(100),
           GoldSpecialBankAccount(100),
           ]
    amounts = [100,-500,200,-300,1000]
    for ba in bas:
        for am in amounts:
            try:
                ba.transact(am)
            except NotEnoughBalance:
                pass 
        print(ba)
# Write fraction such that 
# a = Fraction(1,2)
# b = Fraction(1,3)
# c = a + b 
# print(c) # prints Fraction(5,6)
# Ensure 100% test
class Fraction:
    def __init__(self, n, d):
        self.n = n 
        self.d = d 
    def __str__(self):
        return f"Fraction({self.n},{self.d})"
    def __add__(self, other):
        n = self.n * other.d + other.n * self.d
        d = self.d * other.d
        return Fraction(n, d)

"""
testcase - 
    fn with test_ prefix 
    must have assert condition 
    if condition ==True, test succeeds 
    if condition==False, test fails 
Test suite 
    class with prefix Test* containing 
    similar testcases 
Module 
    must have test_* 
  
Commands 
pytest -v 
pytest -v --cov=oop --cov-report term-missing   

Filtering 
  #based on test case name 
  pytest -v -k "exception"
  pytest -v -k "not exception"
  pytest -v -k "exception or transact"
  #Based on markers 
  pytest -v -m "fraction"
  pytest -v -m "not fraction"
  
  pytest -v -m "not fraction" -k "exception"

"""
from oop import * 
import pytest 

@pytest.mark.account 
class TestBankAccount:
    def test_ba_transact(self):
        ba = BankAccount(100)
        ba.transact(100)
        assert ba.balance == 200
        assert str(ba) == "BankAccount(200)"
    def test_ba_exception(self):
        ba = BankAccount(100)
        with pytest.raises(NotEnoughBalance):
            ba.transact(-1000)
    def test_ba_str(self):
        ba = BankAccount(100)        
        assert str(ba) == "BankAccount(100)"
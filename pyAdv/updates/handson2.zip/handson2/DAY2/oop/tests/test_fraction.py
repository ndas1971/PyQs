from oop import * 
import pytest 

@pytest.mark.fraction 
def test_fraction():
    a = Fraction(1,2)
    b = Fraction(1,3)
    c = a + b 
    assert str(c) == 'Fraction(5,6)'
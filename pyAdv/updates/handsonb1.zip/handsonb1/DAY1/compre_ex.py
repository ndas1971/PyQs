lst = [20,1,3,40]
#Square each element 
o = []
for e in lst:
    o.append(e*e)    
print(o)
#Using comprehension #Output is list , so use list syntax 
o = [e*e for e in lst]
#square for odd numbers 
o = [e*e for e in lst if e%2 == 1]
#Can have multiple for statements , ex #create even and odd pairs 
o = [(e1,e2) for e1 in lst 
    if e1%2 == 0 for e2 in lst if e2%2 == 1]
#if we require output as set - use set syntax 
o = {e*e for e in lst}
#if we require output as dict - use dict syntax 
o = {e: e*e for e in lst}
#Write a function convert which converts 
#deg to C and vice versa 
#(deg * 9/5) + 32 = f
#(f - 32) * 5/9 = deg

#https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html
#TODO - convert unit:string to Enum 
def convert(value: float, unit:str)->float:
    conv = dict(F=lambda f: (f - 32) * 5/9,
                C=lambda deg: (deg * 9/5) + 32)
    fn = conv.get(unit, None)
    if fn is not None:
        return fn(value)
    
    
    
if __name__ == '__main__':
    values = [(0,'F'), (0, 'C'), (32,'F')]
    for v, u in values:
        print(f"from {u} value={v}, {convert(v,u)}")
# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits 

"""
Nouns 
    probable classes 
verbs 
    probable methods of the class 
class 
    collection methods (instance)
    which operate on its variable 
instance/object 
    having memory location 
Special methods 
    https://docs.python.org/3/reference/datamodel.html
    special names for instance method 
    For example 
    ** Initializer method 
        def __init__(self, ...)
    ** prettify print 
        def __str__(self)
        
self 
    Not a key word
    must be first argument 
    Python puts instance     
    
Two kinds of relation 
    is/are - inheritance 
        __mro__ 
    has/have - composition 
    
Instance methods and variables 
    first argument is self 
    
No access control 
    by convention _method 
    is taken as private method
    
class methods/variables 
    variable 
        global variable which is shared by all instances 
    method 
        first argument is now class 
        Use decorator classmethod 
static method 
    There is no first arg 
    Never used in real life 
property 
    Use like a instance variable 
    but it calls a instance method internal 
    Used when lazy calculation needs to be done 
    while accessing a variable 
    
Python OOP 
    no access control 
    Special methods as a way of operator overloading 
    instance/class/static methods 
    property 
    instance/class variables 
    No interface or abstract 
        abc module has abstractmethod based on metaclass 
    Root class is object 
    default metaclass type 
    slots 
    Design pattern 
        Iterator,decorator    
    => Learning python , Mark lutz 
"""
"""
Handson 
Bank User has name and account.
BankUser can do transact on BankAccount 

Hint: Use earlier bank account 
Use name as primitive string.
Decide initializer method of BankUser 
and write transact which delegates to account transact 


"""
class NotEnoughBalance(Exception):
    pass 

class BankAccount:
    count = 0               #class variable 
    def __init__(self, init_amount): #instance methods
        self.amount = init_amount  #instance variable
        BankAccount.count += 1
    @classmethod 
    def howmany(cls):
        return cls.count 
    @staticmethod 
    def version():
        return "0.1"
    @property 
    def balance(self):          #instance.balance
        return self.amount   
    def transact(self, amount):
        if self.amount + amount < 0:
            raise NotEnoughBalance("not possible")
        self.amount += amount 
    def __str__(self):
        return f"BankAccount(balance={self.amount})"
        
class SpecialBankAccount(BankAccount):
    def transact(self, amount, cbp=0.05):
        try:
            super().transact(amount)
            if amount < 0:
                cashback = cbp * abs(amount)
                super().transact(cashback)
        except NotEnoughBalance as ex:
            print(ex, "For amount:", amount, 
              "having balance", self.amount)

if __name__ == '__main__':  # pragma: no cover 
    #ba = BankAccount(100) #BankAccount.__init__(ba, 100)
    accounts = [BankAccount(100), SpecialBankAccount(100)]
    amounts = [100,-50]
    for a in accounts:
        for am in amounts:
            a.transact(am)
        print(a.balance)
    #classmethod calling 
    print(f"no of accounts= {BankAccount.howmany()}")  # Note prefix is class name 
    print(BankAccount.version())
    #
    #
    #try:
    #    ba.transact(-200)
    #except NotEnoughBalance as ex:
    #    print(ex)
    #print(ba)

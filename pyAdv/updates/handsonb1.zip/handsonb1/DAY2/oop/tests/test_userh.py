from userh import *
"""
python -m pytest -k "TestBA" test_userh.py 
For details of k expression, check pytest --help 
"""
class TestBA:
    def test_special_ba(self):
        a = SpecialBankAccount(100)
        amounts = [100,-50]
        for am in amounts:
            a.transact(am)
        assert a.balance == 152.5        
    def test_ba(self):
        a = BankAccount(100)
        amounts = [100,-50]
        for am in amounts:
            a.transact(am)
        assert a.balance == 150

def test_homany():
    last_v = BankAccount.howmany()
    temp = [BankAccount(100), SpecialBankAccount(100)]
    now_v = BankAccount.howmany()
    assert (now_v - last_v) == 2
    
"""
pip install pytest pytest-cov 
#execute 
pytest -v test_userh.py 
#OR 
python -m pytest -v test_userh.py 
#converage report 
pytest -v --cov=userh --cov-report term-missing test_userh.py 
OR 
python -m pytest -v --cov=userh --cov-report term-missing test_userh.py 

Inside Poetry 
pytest -v t
#converage report 
pytest -v --cov=userh --cov-report term-missing 

"""

"""
Test module 
    file with test as prefix 
Testcase 
    functions with test prefix 
    contains atleast one assert 
Test suite 
    class with Test prefix 
"""
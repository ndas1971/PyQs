import subprocess as S
import re 

class Execute:
    def __init__(self, command):
        self.command = command 
    def __str__(self):
        return f"Execute({self.command})"
    def find(self, info):
        p = S.run([self.command], shell=True, 
                capture_output=True,
                universal_newlines=True)
        return re.findall(info, p.stdout)
        
        
if __name__ == '__main__':
    print(Execute("dir").find(r"\d{2}:\d{2}"))
    
"""
python -m poetry new auto 
cd  demo 
#COPY command.py into src\auto\
#src\auto\__init__.py 
from .command import * 

#COPY test_command .py into tests folder 

#Now build 
python -m poetry build -v 

The whl file it inside dist folder 
install it at any place 
by 
pip install  auto\dist\auto-0.1.0-py3-none-any.whl


Then usage 
import auto

"""
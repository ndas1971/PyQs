"""
DB API vs ORM 
Many DB Engines 
Many python libs for each DB engine
sqlalchemy
    install by 
    >pip install sqlalchemy
    https://docs.sqlalchemy.org/en/20/core/engines.html
"""
#DB API - sql 
from sqlalchemy import create_engine, text 
engine = create_engine("sqlite:///people.db")
csql = """create table if not exists people(name string,
   age int)"""
isql = "insert into people values(:x,:y)"
ssql = "select age from people where name=:x"
ssql2 = "select max(age) from people"
data = [("abc", 20), ("xyz", 60), ("abc", 5)]
with engine.connect() as c:
    c.execute(text(csql))
    for n,a in data:
        c.execute(text(isql), dict(x=n, y=a))
    c.commit()  # .rollback()
    
with engine.connect() as c :
    cur = c.execute(text(ssql), dict(x="abc"))
    print(cur.fetchall()) # .fetchone() for one row 
#Hands on 
#Insert another row ("abc", 60)
#Find max age 
with engine.connect() as c :
    cur = c.execute(text(ssql2))
    print(cur.fetchall()) 






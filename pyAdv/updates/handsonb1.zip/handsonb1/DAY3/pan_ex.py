"""
SQL -2D - rows x cols 
USe pandas - DataFrame - list of Columns/Series 
https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf
"""
import pandas as pd 
import matplotlib.pyplot as plt
path = r"D:\handsonb1\DAY1\data\iris.csv"
iris = pd.read_csv(path)
#Checking metadata
print(iris.head())  #first 5 rows 
print(len(iris))    # no of rows 
print(iris.columns)
print(iris.index)   #row_id 
print(iris.dtypes) #columns datatypes, in pandas, float is float64, str is called object 
print(type(iris), 
    type(iris.SepalLength),
    type(iris['SepalLength']))
    
#Access a column 
iris.SepalLength
iris['SepalLength']
iris[['SepalLength', 'SepalWidth']] #DF 
#access sub dataframe 
#.iloc[row_index, column_index]
#.loc[ row_id, column_names]
#it may contain slice start:end:step 
#in iloc, end is not included 
#in loc , end is included 
iris.loc[0:2, ['SepalLength','SepalWidth']]
iris.iloc[0:3, [0,1]]
#Filter is possible in loc 
iris.loc[iris.SepalLength > 5.0, :]
iris.loc[(iris.SepalLength > 5.0) & 
   (iris.SepalLength < 5.6) , :]

#create a column 
iris['dummy'] = iris.SepalLength\
  - 2* iris.SepalWidth + 1
iris.columns

#drop column 
iris.drop(columns=['dummy']) # returns a new DF 
iris.columns
iris.drop(columns=['dummy'], inplace=True)
iris.columns

#call any function, understand axis 
iris.SepalLength.mean(),  #one mean 
iris.iloc[:,0:4].mean(),        #all 4 columns mean 
iris.iloc[:,0:4].mean(axis=0),  #default column oriented
iris.iloc[:,0:4].mean(axis=1)   #row oriented 


#aggregation 
print(iris.Name.unique())
gr = iris.groupby('Name')
print(gr.mean())
print(gr.agg({'SepalLength': 
    ['mean', 'min', 'max']}))
gr.agg({'SepalLength': 
    ['mean', 'min', 'max']}).to_excel('p.xlsx')
#plot 
iris.iloc[:,0:4].plot(kind='line')
plt.savefig('p.png')


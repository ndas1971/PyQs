from command import * 

"""
python -m pytest -v test_command.py 
"""

def test_command_find():
    out = Execute("dir").find(r"\d{2}:\d{2}")
    assert type(out) is list 

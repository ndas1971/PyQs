lst = [10,2,3,5,90]
#SQuare each number 
#Normal 
o = []
for e in lst:
    o.append(e*e)
print(o)
#Equivalent comprehension syntax 
o = [ e*e for e in lst] #list comprehension , output = list 
o = { e*e for e in lst} #set comprehension , output = set 
o = { e: e*e for e in lst} #dict comprehension , output = dict 
#Can have guard , eg - square only for even number 
o = [ e*e for e in lst if e%2 == 0]
#for ..in .. if .. can be repeated N times, == nested for loop 
#to create even and odd pairs 
o = [ (e1,e2) for e1 in lst if e1%2 == 0 for e2 in lst if e2%2 == 1]
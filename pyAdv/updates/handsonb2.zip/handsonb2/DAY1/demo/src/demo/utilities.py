#Write a function convert which converts 
#deg to C and vice versa 

# F-> C, C->F 
def convert(value:float, unit:str) -> float:
    conv = dict(F= lambda f:(f - 32) * 5/9,
            C= lambda deg: (deg * 9/5) + 32)
    fn = conv.get(unit, None)
    if fn is not None:
        return fn(value)
    else:
        raise NotImplementedError("unknown unit")
        
if __name__ == '__main__':
    values = [(0,'F'), (0,'C'), (32, 'C')]
    for v, u in values:
        print(f"From {u} with {v} = {convert(v,u)}")
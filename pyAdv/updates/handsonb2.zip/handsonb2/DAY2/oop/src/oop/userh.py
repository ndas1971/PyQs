# Create BankAccount which takes initial balance 
# It can transact . SpecialBankAccount is a BankAccount
# which gives 5% cashback when somebody debits

"""
Nouns 
    potential classes     
Verbs 
    methods of those classes 
Class 
    collection of methods(instance)
    which operate on data(instance variables)
instance/object 
    having memory address 
    and having a particular value of those instance variables 

Special methods
    https://docs.python.org/3/reference/datamodel.html
    **Initializer method 
        def __init__( self, ...)
    prettify instance prints 
        def __str__(self)
    
self 
    it is not a keyword 
    but must be at first arg in instance method 
    by convention
    
Types of relations 
    is/are - inheritance 
    has/have - composition 
    
instance methods/variables 
    first argument instance/self 
class methods/variables 
    first argument is class 
staticmethod 
    no first argument 
property 
    we call like a instance variable 
    but python calls a instance method 
    Used for lazy calculation 
    
    
"""
class NotEnoughBalance(Exception):
    pass 
class BankAccount:
    count = 0                           # class variable 
    def __init__(self, init_amount):    #instance method 
        self.amount = init_amount       #instance variable 
        BankAccount.count += 1
    @classmethod 
    def howmany(cls):                   #BankAccount.howmany()
        return cls.count 
    @staticmethod 
    def  version():                     #BankAccount.version()
        return '0.1'
    @property 
    def balance(self):                  #instance.balance
        return self.amount 
    def transact(self, amount):
        if self.amount + amount < 0:
            raise NotEnoughBalance("not possible")
        self.amount += amount 
    def __str__(self):
        return f"BankAccount(balance={self.amount})"
        
#SpecialBankAccount.__mro__ = (SpecialBankAccount, BankAccount, object)
#SpecialBankAccount(100) => BankAccount.__init__(instance_sp_ba, 100) 
#=> instance_sp_ba.amount = 100 
#instance_sp_ba.transact(100) => SpecialBankAccount.transact(instance_sp_ba, 100)
#=> BankAccount.transact(instance_sp_ba, 100) =>....
class SpecialBankAccount(BankAccount):
    def transact(self, amount, cbp=0.05):
        try:
            super().transact(amount)
            if amount < 0:
                cashback = cbp * abs(amount)
                super().transact(cashback)
        except NotEnoughBalance as ex:
            print(ex, "For amount:", amount)
        
if __name__ == '__main__': # pragma: no cover 
    accounts = [BankAccount(100), 
                SpecialBankAccount(100)]
    amounts = [100, -50]
    for a in accounts:
        for am in amounts:
            a.transact(am)
        print(a.balance)
    print(BankAccount.how(), BankAccount.version())
    #ba = BankAccount(100)  # BankAccount.__init__(ba, 100)
    #try:
    #    ba.transact(-200)       # BankAccount.transact(ba, 100)
    #except NotEnoughBalance as ex:
    #    print(ex)
    #print(ba)
    
    
"""
module
    file with .py 
    __name__ will be filename/modulename 
    contains classes/functions 
    we should not execute 
script 
    file with .py 
    __name__ is __main__ 
    we execute 
""" 
from userh import * 

def test_special_ba():
    a = SpecialBankAccount(100)
    amounts = [100, -50]
    for am in amounts:
        a.transact(am)
    assert a.balance == 152.5 
    
def test_howmany():
    last_v = BankAccount.howmany()
    accounts = [BankAccount(100), 
                SpecialBankAccount(100)]
    cur_v = BankAccount.howmany()
    assert (cur_v - last_v) == 2
    
"""
Test module 
    module with test prefix
testcase 
    function with test prefix 
    and contains atleast one assert 
Testsuite 
    a class with Test prefix 
"""

"""
Install using 
> pip install pytest pytest-cov   -i ... ...

Execute by 
python -m pytest -v test_userh.py 
To coverage report 
python -m pytest -v --cov=userh --cov-report term-missing test_userh.py 

"""

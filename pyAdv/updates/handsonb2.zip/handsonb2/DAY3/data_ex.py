"""
SQL vs nSQL(dynamic schema) 
SQL = 2D , rows x cols 
pandas
https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf

DataFrame - list of Columns/Series 
Many API common in DF and Series 
    DF API works on either rows or columns 
    by default column (axis=0)
    Series API, column does not axis 
"""
import pandas as pd 
import matplotlib.pyplot as plt 
path = r"D:\handsonb2\DAY1\data\iris.csv"
iris = pd.read_csv(path)
#Read metadata
iris.head()  # by D, first 5 rows 
iris.columns  #list of col names 
iris.index    #row_id 
iris.dtypes   #columns and its data 
len(iris)     #how many rows 
#access 
type(iris)   # DF 
iris.SepalLength                     #Series 
iris['SepalLength']                  #Series 
iris[['SepalLength', 'SepalWidth']]  #DF 
#acces row 
#.iloc[row_index, column_index]
#.loc[row_id, column_names]
#may have slice, start:end:step 
#in loc, end is included 
#in iloc, end is not included 
#loc can have query 
#   SepalLength  SepalWidth
#0          5.1         3.5
#1          4.9         3.0
#2          4.7         3.2
iris.loc[0:2, ['SepalLength','SepalWidth']]
iris.iloc[0:3, [0,1]]
iris.loc[iris.SepalLength > 5.0, :]
iris.loc[(iris.SepalLength > 5.0) &
        (iris.SepalLength <6.6), :]
#create new column 
iris['dummy'] = iris.SepalLength\
    - 2* iris.SepalWidth + 1
iris.columns 
#function must be from numpy
import numpy as np
iris['dummy'] = np.abs(iris.dummy)
iris.dummy
#delete a column 
iris.drop(columns=['dummy']) #returns a new DF 
iris.columns     # original not mutated 
iris.drop(columns=['dummy'], inplace=True) #now mutating 
iris.columns   # dummy is removed 
#Apply APIs 
iris.SepalLength.mean()  # single mean 
iris.iloc[:, 0:4].mean()  # by default colwise, 4 means 
iris.iloc[:, 0:4].mean(axis=0)  #same as above 
iris.iloc[:, 0:4].mean(axis=1) #now row wise 
#Aggregation 
iris.Name.unique()
iris.iloc[:,0:4].describe()
gr = iris.groupby("Name")
gr.mean()
gr.agg({'SepalLength':['mean', 'max', 'min']})
gr.agg({'SepalLength':
    ['mean', 'max', 'min']}).to_excel("p.xlsx")

#Plot 
iris.iloc[:,:4].plot(kind='line')
plt.savefig('p.png')








"""
DB API vs ORM 
Many DB engines 
Many python libs for each engine 

Use sqlalchemy 
https://docs.sqlalchemy.org/en/20/core/engines.html


"""
from sqlalchemy import create_engine, text 
engine = create_engine("sqlite:///people.db")
csql = """create table if not exists 
  people(name string ,
  age int)"""
isql = "insert into people values(:x, :y)"
ssql = "select age from people where name=:x"

values = [("abc", 60), ("xyz", 20)]
with engine.connect() as c:
    c.execute(text(csql))
    for n,a in values:
        c.execute(text(isql), dict(x=n, y=a))
    c.commit()  #.rollback() 
#Hands on 
#Insert another row ("abc", 60)
#Find max age 
maxagesql = "select max(age) from people"
with engine.connect() as c:
	cur = c.execute(text(maxagesql))
	print(cur.fetchone())
    
with engine.connect() as c:
    cur = c.execute(text(ssql), dict(x="xyz"))
    print(cur.fetchall())  #.fetchone()





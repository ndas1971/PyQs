from command import * 

"""
python -m pytest -v test_command.py 

"""
def test_command_search():
    p =Execute("dir").search(r"\d{2}-\d{2}-\d{4}")
    assert type(p) is list 
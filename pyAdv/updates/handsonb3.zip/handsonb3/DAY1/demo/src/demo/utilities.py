#Write a function convert which converts 
#deg to C and vice versa 
#(deg * 9/5) + 32 = f
#(f - 32) * 5/9 = deg
from enum import Enum 
Unit = Enum('Unit', ['F', 'C'])

#Type annotation
#https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html
#Match Tutorials
#https://peps.python.org/pep-0636/
def convert(value:float, unit:Unit)->float:
    conv = {Unit.C: lambda deg: (deg * 9/5) + 32,
            Unit.F: lambda f: (f - 32) * 5/9,
            }
    #fn = conv.get(unit, None)
    #if fn is not None:
    #    return fn(value)
    match unit:
        case Unit():
            return conv[unit](value)
        case _:
            raise NotImplementedError("not valid unit")
            
    
    
if __name__ == '__main__':
    values = [(0,Unit.F), (0,Unit.C)]
    for v,u in values:
        print(f"{v=},{u.name=}={convert(v,u)}")
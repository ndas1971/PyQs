from oop import *

class TestAccount:
    def test_special_transact(self):
        a = SpecialBankAccount(100)
        amounts = [100, -50]
        for am in amounts:
            a.transact(am)
        assert a.balance == 152.5
    def test_bankaccount_transact(self):
        a = BankAccount(100)
        amounts = [100, -50]
        for am in amounts:
            a.transact(am)
        assert a.balance == 150
        
def test_howmany():
    last_v = BankAccount.howmany()
    [BankAccount(100), 
        SpecialBankAccount(100)]
    cur_v = BankAccount.howmany()          
    assert (cur_v - last_v) == 2
    
"""
-k expr - check pytest --help 
Example, test only TestAccount
python -m pytest -k "TestAccount" -v test_userh.py 
Test all except TestAccount
python -m pytest -k "not TestAccount" -v test_userh.py 
Test howmany and special 
python -m pytest -k "howmany or special" -v test_userh.py 



"""
    
"""
Module
    must have prefix test 
Testcase 
    a function having prefix test 
    and contains atleast one assert 
Test suite 
    Class with prefix Test 
    collection of similar testcases 

Install
    > pip install pytest pytest-cov 
Execute 
python -m pytest -v test_userh.py 
For cov report 
python -m pytest --cov=userh --cov-report term-missing test_userh.py 

"""

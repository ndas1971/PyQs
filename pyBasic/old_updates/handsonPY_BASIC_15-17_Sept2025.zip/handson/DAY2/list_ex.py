input = '[1,2,3,4]'

#Given above , create 
#output = [1,2,3,4]

#hint - remove [], then split by ","
#and we get list of str 
#We need to have list of number 
#hint :create empty list, iterate above 
#convert to int, then append to empty list
output = []
for e in input.strip('[]').split(","):
    output.append(int(e))
print(output)
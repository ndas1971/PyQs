"""
Always in string, use conversion if required
Use input 
    not reco 
    but use for password/sensitive data 
Use env variable 
    set MYPW=ok
    Then inside python 
    import os 
    os.environ['MYPW']
Use file 
    read/write 
command line arg 
    when we execute 
    >python filename.py arg1 arg2 
    inside python 
    sys.argv =['filename.py' ,'arg1', 'arg2' ]
PROB1:
    if user does not provide
    SOL - use some default strategy     
    
PROB2
    provides, but wrong data 
    SOL - handle that error/exception 
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    try:
        #exception raised 
    except exception1:
        #handle exception1 here 
    except exception2:
        #handle exception2 here  
    except Exception   # base class 
        #catch all 
    finally:
        #executed always 
"""
import sys 
default_age = 100
name = input("Give Name:")
#X if Y else Z => If Y is true , do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError:
    print("Could not convert, using default age")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")

def square(x):
    """square the number 
    and return
    Called doc str 
    and shown in help()"""
    z = x * x 
    return z

def mean(lst):
    #Sum of lst/length of lst 
    #Use builtin sum methods
    #https://docs.python.org/3/library/functions.html
    #sum([1,2,3]) = 6 
    return sum(lst)/len(lst)


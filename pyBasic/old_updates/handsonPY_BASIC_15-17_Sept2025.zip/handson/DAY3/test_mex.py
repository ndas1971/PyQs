import mex 

print(f"""
square of 10 = {mex.square(10)}
""")

lst = list(range(10))
m = mex.mean(lst)
print(m)

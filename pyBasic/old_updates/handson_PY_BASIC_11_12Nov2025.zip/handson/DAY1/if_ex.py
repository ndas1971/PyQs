# if name is "XYZ" and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#Objective - write  nested if 
#if name checking - inside if age checking
name = "xyz"
age = 51
if name == "xyz":
    if age < 40:
        print("Suitable")
    if age >50:
        print("OLD")
    else:
        print("OK")
else:
    print("Not Known")
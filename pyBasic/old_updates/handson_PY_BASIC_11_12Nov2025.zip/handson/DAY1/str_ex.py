s = "Hello World and Hello Earth"

#print no of upper case, lower case 
#and space 

#hint: Use .islower etc 
#put it in for loop and count seperately 
cspace, clower, cupper = 0,0,0
for ch in s:
    if ch == ' ':
        cspace += 1
    elif ch.islower():
        clower += 1
    elif ch.isupper():
        cupper += 1
print(f"{cspace=},{clower=},{cupper=}")

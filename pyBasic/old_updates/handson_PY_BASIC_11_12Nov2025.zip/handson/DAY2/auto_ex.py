#Find all patches installed in windows system 
"""

1. execute the command 
2. capture console output, stdout 
    Use subprocess module 
    https://docs.python.org/3/library/subprocess.html
    shell=True 
    universal_newlines=True 
    capture_output=True for  stdout 
    fn(rag=value, arg=value) #keyword way arg passsing

3. Extract the required info 
    Use re 
    https://docs.python.org/3/library/re.html

"""
import re 
import subprocess as S  # alias 

#[01]: KB5066130
pat = r"\[\d\d\]:\s(KB\d+)"
pat = r'KB\d{7}' #KB5066130
command = "systeminfo"


proc = S.run([command], shell=True ,
    universal_newlines=True ,
    capture_output=True)
patches = re.findall(pat, proc.stdout )
print(patches)
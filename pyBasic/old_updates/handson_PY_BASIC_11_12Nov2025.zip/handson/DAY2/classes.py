#BankAccount with initial balance and it can do transact

"""
class 
    collection of methods 
    and instance variables 
object/instance 
    has memory 
    and we use methods which are defined class 
    
STEP-1:
    find out all initialization parameters 
STEP-2
    create initialization method , __init__ 
    and then create instance variable 
STEP-3
    Define other methods 
    which uses those instance variables
self 
        not a keyword 
        must be first arg where puthon puts the instance 
"""
class BankAccount:
    def __init__(self, init_amount): #self=ba, init_amount=100
        self.balance = init_amount   #ba.balance = 100
    def transact(self, amount):
        #how_much = 2
        self.balance += amount    #ba.balance += 100
        
#Usage 
ba = BankAccount(100) #BankAccount.__init__(ba, 100)
ba.transact(100)      #BankAccount.transact(ba, 100)
print(ba.balance)     #200
ba1 = BankAccount(100) #BankAccount.__init__(ba, 100)
ba1.transact(100)      #BankAccount.transact(ba, 100)
print(ba1.balance)     #200


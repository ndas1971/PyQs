#How many count of each subspecies
#select count(*) from iris group by Name 
#DS - {'Iris-setosa': 30,...}

path = r"D:\handson\DAY2\data\iris.csv"
with open(path, "rt") as f:
    lines = f.readlines()
header = lines[0]
rows = lines[1:]
es = {e.strip().split(",")[-1] for e in rows}

ed = {}
for name in es:
    lst = []
    for e in rows:
        if name == e.strip().split(",")[-1]:
            lst.append(e)
    ed[name ] = len(lst)
    
#comprehension
{name:len([e for e in rows if name == e.strip().split(",")[-1]])  for name in es}

LIST PROCESSIng
MAP - each element is transformed without 
      depending on other element => map
REDUCE - we need to see other elements => reduce 

lst = [1,2,3]
#square each no - list 
o = []
for e in lst:
    o.append( (e*e, e*e*e) )
#comprehension
[(e*e, e*e*e) for e in lst ]#<- eager #=> map(lambda e: e*e, lst) <-lazy
#square each even no 
def square(e):
    return e*e
o = []
for e in lst:
    if e%2 == 0:
        o.append( e*e )
[square(e) for e in lst if e%2 == 0]
#square each unique even no 
o = set()
for e in lst:
    if e%2 == 0:
        o.add( e*e )
{e*e for e in lst if e%2 == 0}    
#we should have even number and its square value 
o = {}
for e in lst:
    if e%2 == 0:
        o[e] = e*e 
{e:e*e for e in lst if e%2 == 0} #N no of times

"""
User input - always in string
    Use input 
        Use for sensitive data 
    Use env var 
        shell>set MYPW=ok

        >>> import os
        >>> os.environ['MYPW']
        'ok'
        >>>
    Use file 
        use open 
    Command line args 
        Execute 
        > python filename.py arg1 arg2 arg3 
        comes 
        sys.argv = ['filename.py', 'arg1' ,'arg2' ,'arg3'] 
    PROB1: if user does not give data 
    Use some default strategy
    PROB2: if user provide wrong data 
    handle exception
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    try:
        #raising code 
    except Exception1 as ex:
        #code 
    except Exception2 as ex:
        #code     
    except Exception as ex: #Exception is base class     
        #catch all 
    else:
        #only when no exception 
    finally:
        #always 

        
    raise ValueError("not possible")
"""
import sys 
default_age = 10
name = input("Give Name:")
#X if Y else Z => if Y is true, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError as ex:
    print(ex)
    print("Using default age")
    age = default_age
    
if name == "xyz":
    if age < 40:
        print("Suitable")
    elif age > 50:
        print("OLD")
    else:
        print("OK")
else:
    print("Not Known")
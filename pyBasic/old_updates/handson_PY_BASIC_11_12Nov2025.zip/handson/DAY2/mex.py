def square(x):
    """squaring a number 
    and returning"""
    z = x * x 
    return z 

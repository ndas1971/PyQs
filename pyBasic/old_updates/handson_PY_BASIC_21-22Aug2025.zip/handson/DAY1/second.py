a = 1
#: is must else SyntaxError
#: signifies block 
#inside block, indents are must else IndentationError:
#Indents - tab or space, but dont mix 
#no indent means block over
#Coding style(PEP8) - 4 space 
#In nested block, level of indents should be increased 
if a >= 1:
    print("greater")
    print("greater")
    print("greater")
elif a < 1:
    print("less")
    print("less")
else:
    print("else")
print("OUTSIDE")

p = 2
if p>=4:
    print("greater")
elif p<4:
    print("lesser")
else:
     print("else")
print("outside")


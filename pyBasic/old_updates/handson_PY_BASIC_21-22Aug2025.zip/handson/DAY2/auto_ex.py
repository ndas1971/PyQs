"""
Prob: Find hotfixes/windows patches/KB installed in a machine 
command = "systeminfo"

STEP1 - Execute command under shell 
capture stdout 
    subprocess module 
    https://docs.python.org/3/library/subprocess.html
    Hint: enable 
    shell to execute command under shell, 
    capture_output to capture stdout
    universal_newlines for converting bytes to str
    
STEP2- Extract required info from the output 
    Use re module 
    https://docs.python.org/3/library/re.html
    hint: Decide pattern of KB5056578
    and use findall
"""
import subprocess
import re 
command = "systeminfo"
proc = subprocess.run([command], 
    shell=True, 
    capture_output=True, 
    universal_newlines=True)
kbs = re.findall(r"KB\d+" , proc.stdout)
print(kbs)
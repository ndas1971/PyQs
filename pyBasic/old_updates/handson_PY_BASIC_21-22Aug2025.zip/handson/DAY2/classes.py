"""
BankAccount can take initial amount 
for opening. It can also do transaction which 
updates its balance 

"""
#class definition contains methods 
"""
STEP1- find out initialization parameters 
    those with which instance is created 
STEP2: Write initialization method 
    def __init__
    create instance variable
Then write other methods
which modifies instance variables
Note there is access control
Self 
    Not a keyword
    must be first arg 
    where py puts instance 
    and all methods uses that variable 
    to access instance variable 
"""
class BankAccount:
    def __init__(self, init_amount):
        self.balance = init_amount  # NOTE how we create instance variable
        #ba.balance = 100
    def transact(self, amount):
        self.balance += amount 
        #ba.balance += 200

#Usage 
#create instance and call those methods
ba = BankAccount(100)  #BankAccount.__init__(ba, 100)
ba.transact(200)       #BankAccount.transact(ba, 200)
print(ba.balance)      #300
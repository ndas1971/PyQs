"""
Use input 
    always in string, so convert 
    Using input (sys.stdin)
        Use only for password
        use modules- getpass
    Using env var 
        Set by 
        set MYPW=ok
        Then inside python 
        import os
        os.environ['MYPW']
    Using files 
        file handling techniques
        xml/json - use modules
        Use vaults..
    Using command line arguments 
        When we execute 
        >python filename.py arg1 arg2 ...
        then inside python 
        sys.argv = ['filename.py', 'arg1', 'arg2']
    PROB1:
        if user does not provide any input 
        SOL - do some default action 
    PROB2: user provides wrong input    
        SOL - do some default action 
"""
import sys 
default_age = 40 

name = input("Give Name:")
#X if Y else Z => if Y is true, do X else do Z 
#PROB1
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
#PROB2
try:
    age = int(sage)
except ValueError:
    print("INFO: wrong input for age, using default age")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")
    
# name = "XYZ"
# age = 40
# if name == "XYZ" :
#     if age < 40:
#         print("suitable")
#     elif age > 50:
#         print("old")
#     else:
#         print("OK")
# else:
#         print(" un known")
    
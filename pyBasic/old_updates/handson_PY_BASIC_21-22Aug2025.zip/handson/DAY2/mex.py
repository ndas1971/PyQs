def square(x):
    """squaring a number 
    and returning"""
    z = x*x 
    return z
    
    
#Mean(lst) 
#    Sum of lst/length of lst 
#    use builtin func 
#    sum([1,2,3]) = 6
#    Ref 
#    https://docs.python.org/3/library/functions.html
def mean(x):
    return sum(x)/len(x)
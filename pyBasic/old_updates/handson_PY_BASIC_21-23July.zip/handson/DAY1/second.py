a = 1
#SYNTAX ERROR - without :
#: starts  a block 
#inside block, we must indent else INDENTATIONERROR 
#indent - space or tab, but dont mix it 
#CS - PEP8 - Use 4 space
#any IDE or notepad++, use tab as 4 space  
if a >= 1:
    print("greater")
    print("greater")
    print("greater")
elif a < 1:
    print("less")
    print("less")
    print("less")
else:
    print("else")
    print("else")
    print("else")
print("OUTSIDE")
    
    

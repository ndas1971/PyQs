s = "Hello world and hello EARTH"
#find lowercase, uppercase and space count 

#hint - use for loop and then use .islower() 
#and .isupper() if condition 

clower, cupper, cspace = 0, 0, 0 
for ch in s:
    if ch.islower():
        clower = clower + 1
    elif ch.isupper():
        cupper += 1  #cupper = cupper + 1
    elif ch.isspace():
        cspace += 1 
print(clower, cupper, cspace)
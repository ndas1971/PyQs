"""
Taking user inputs 
(always in string, convert to own datatype)
    Using input function
    Using config file 
    Using command line argument 
        When we execute 
        > python filename arg1 arg2 
        it will come inside 
        sys.argv = ['filename', 'arg1', 'arg2' ]
        PROB1: if user does not provide, what to do 
        PROB1: user inputs erroneous data 
            sol: Handle exception 
            https://docs.python.org/3/library/exceptions.html#exception-hierarchy
      #syntax       
      try:
        #exception generating line 
      except exception_name1 as ex:
        #handle 
      except exception_name2 as ex:
        #handle 
      except Exception as ex:
        #handle catch all 
      finally:
        #executed whether exception or not 
        #closing file ..
        
"""
import sys 
default_age = 40 
name = input("Give name:")
#X if Y else Z => if Y true, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError as ex:
    print(ex, "Using default age")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")

def square(x):
    """taking a number and 
    returns square of that number"""
    z = x*x 
    return z

#Use builtin function sum 
#https://docs.python.org/3/library/functions.html#sum
def mean(lst):
    return sum(lst)/len(lst)
a = 1
#: is must else SyntaxError
#: means block is starting 
#next line must be indented else IndentationError - 
#indents - tab or space - dont mix it 
#CS - PEP8- Use 4 space 
if a >= 1:
    print("greater-equal")
    print("greater-equal")
    print("greater-equal")
elif a < 1:
    print("elif")
    print("elif")
    print("elif")
else:
    print("else")
    print("else")
print("OUTSIDE")

s = "Hello World and Hello Earth"

#how many upper case, lowercase and spaces 

#Hint- use islower(), isupper() instance methods
#and for loop to iterate s string 

clower, cupper, space = 0, 0, 0
for ch in s:
    if ch.isupper():
        cupper += 1
    elif ch.islower():
        clower += 1
    elif ch == ' ':
        space += 1
print(f"{clower=}, {cupper=}, {space=}")

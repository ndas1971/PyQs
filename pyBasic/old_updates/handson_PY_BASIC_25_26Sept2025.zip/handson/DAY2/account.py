# BankAccount can take initial balance 
# and it can transact
"""
1. FInd initialization parameters
    with which we create instance 
2. Write initializer method 
   taking initialization parameter 
      def __init__(self, params)
      This should create instance variables 
      
3. Write other methods 
   which modifies instance variable created 
   above 
Special methods 
    __init__
    https://docs.python.org/3/reference/datamodel.html#special-method-names
    
self 
    not a keyword, by convention
    must be the first arg in any instance method 
    where python will put the instance 
    All instance vars have self. prefix 
"""

class BankAccount:
    def __init__(self, init_amount):
        self.balance = init_amount  #ba.balance = 100
    def transact(self, amount):
        self.balance += amount   #ba.balance += 100
        
#creating an instance 
ba = BankAccount(100) #BankAccount.__init__(ba , 100)
ba.transact(100)      #BankAccount.transact(ba , 100)
print(ba.balance)     #200

lst = [BankAccount(100), BankAccount(200)]
for e in lst:
    e.transact(100)
    print(e.balance)  #200, 300 




""" Shell Automation
Find hotfixes/updates/KB installed in one machine 
command = 'systeminfo'
STEP-1
    Execute the command 
    Capture the output
    import subprocess
    https://docs.python.org/3/library/subprocess.html
    Hint:
    Enable below arguments 
    Shell      #to execute under shell 
    capture_output # to see captured output in stdout 
    universal_newlines # to capture in str 
STEP-2
    extract required information
    import re 
    https://docs.python.org/3/library/re.html
    pat = r"KB\d+"

"""
import subprocess as S  #S is alias 
import re 


# proc = S.run([command], 
#         capture_output=True,
#         shell=True,
#         universal_newlines=True)
# hotfixes = re.findall(pat, proc.stdout)
# print(hotfixes)
class Execute:
    def __init__(self, command):
        self.command = command 
    def search(self, what):
        proc = S.run([self.command], 
         capture_output=True,
         shell=True,
         universal_newlines=True)
        return re.findall(what, proc.stdout)
        
        
#Uses 
command = "systeminfo"
pat = r"KB\d+"
proc = Execute(command) #Execute.__init__(proc, command)
print(proc.search(pat))
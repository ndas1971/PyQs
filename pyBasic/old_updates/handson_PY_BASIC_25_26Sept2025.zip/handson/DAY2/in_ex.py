"""
User input - in string, we need to convert if required 
    Using input()
        Not reco 
        Use when we require sensitive data
        In that case, use dedicated module eg getpass
    Using env variable 
        set MYPW=ok
        Inside python 
            import os
            os.environ['MYPW']
    Use configuration file 
        Use open etc 
    Use command line parameter     
        We execute 
        > python filename.py arg1 arg2 
        those will come into 
        sys.argv = ['filename.py', 'arg1' ,'arg2']
    PROB1: User does not provide 
        SOL - decide a default strategy
    PROB2: Provides but wrong value
        sol - handle error/exception 
        in exception handling use default strategy
        https://docs.python.org/3/library/exceptions.html#exception-hierarchy
        
        try:
            #raises
        except except1:
            #handle except1 
        except except2:
            #handle except2 
        except Exception:
            #catch all 
"""
import sys 
default_age = 20 

name = input("Give Name:")
#X if Y else Z => If Y is trye, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError:
    print("Wrong age format, using default")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")     
else:
    print("not known")
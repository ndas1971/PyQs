def square(x):
    #doc string 
    """squaring a number 
    and returning"""
    z = x * x
    return z
    

# Mean(lst) 
#     Sum of lst/length of lst 
#     Use builtin sum function 
#     sum([1,2,3]) = 6 
#     https://docs.python.org/3/library/functions.html
# sd(lst) =           
#     sqrt of( SUM of square of 
#     ( each element - mean)  / length of lst  )

def mean(lst):
    return sum(lst)/len(lst)

import math 
def sd(lst):
    m = mean(lst)
    o = []
    for e in lst:
        o.append( square(e-m))
    return math.sqrt(sum(o)/len(o))
"""
mex.py  C:\...\dir1
import sys 
sys.path.append(r"C:\...\dir1")
import mex   #mex.py will be searched from sys.path 
"""

import mex 

print(f"""
Square of 10 = {mex.square(10)}
""")
lst = list(range(10))  #0, 10-1=9 numbers 
m, s = mex.mean(lst), mex.sd(lst)
print(f"{m=}, {s=}")
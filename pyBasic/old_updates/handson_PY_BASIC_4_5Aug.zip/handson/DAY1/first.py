# Execute by 
# python first.py 
a = 1
print("Hello World", a)

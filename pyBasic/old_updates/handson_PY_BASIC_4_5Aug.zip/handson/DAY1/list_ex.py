#convert input to output 
input = '[1,2,3,4]'
output = [1,2,3,4]


#hint - remove [] (by strip) and then split with ","
#we will get list of string of number 
#Then convert each string into number 
#by creating empty list and then iterating original one 
#and convert each and append to empty list 
output = []
for e in input[1:-1].split(","):
    output.append(int(e))
    
print(output)
a = 1
# : starts block , without : , it is SyntaxError 
#Next line must be indented else IndentationError
#indent could be space or tab - dont mix 
#Coding style(PEP8) - 4 spaces 
if a >= 1:
    print("greater-equal")
    print("greater-equal")
    print("greater-equal")
elif a < 1 :
    print("less")
    print("less")
    print("less")
else:
    print("else")
    print("else")
print("OUTSIDE")

#Extract hotfixes/patches installed in one machine
command = "systeminfo"
"""
Execute this command 
Capture stdout 
    https://docs.python.org/3/library/subprocess.html
    import subprocess
    hint- enable 
        shell
        capture_output 
        universal_newlines
Extract pattern of KB5056578
    import re
"""
import re
import subprocess
command = "systeminfo"
output = subprocess.run([command], 
    shell=True, 
    capture_output=True, 
    universal_newlines=True)
matches = re.findall(r"KB\d+", 
    output.stdout)
print(matches)
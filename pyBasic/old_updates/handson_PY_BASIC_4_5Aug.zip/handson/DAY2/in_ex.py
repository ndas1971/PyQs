"""
Taking user input 
        in str, so convert to required datatype 
    Using input()
        uses internally sys.stdin 
    Use env var 
        > set MYPWD=ok
        >>> import os
        >>> os.environ['MYPWD']
        'ok'
    Use configuration file 
    Use command line argument 
        when we execute 
        > python filename.py arg1 arg2 
        those come into 
        sys.argv = ['filename.py', 'arg1', 'arg2']
        
      PROB1:
        if user does not provide the value 
        SOL - decide default strategy 
      PROB2- 
        if user provices wrong input 
        SOL: Handle exception 
        https://docs.python.org/3/library/exceptions.html#exception-hierarchy
        
"""
import sys 
default_age = 20 

name = input("Give Name:")
#X if Y else Z => if Y is true, do X else Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError:
    print("Error, age is wrong, using default age")
    age = default_age
if name == "XYZ" :
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")
import math 
def square(x):
    """squaring a number 
    returning"""
    z = x*x 
    return z

#hint - use builtin function sum 
#sum([1,2,3]) gives sum 

def mean(lst):
    return sum(lst)/len(lst)
    
def sd(lst):
    m = mean(lst)
    o = []
    for e in lst:
        o.append(square(e-m))
    return math.sqrt(sum(o)/len(o))
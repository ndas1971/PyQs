#Bank account can take initial balance 
#and can transact 
"""
FInd out what the initialization parameters are 
    with which we create instance 
Write initializer method 
    def __init__(self,....)
    we create all instance variables 
Write other method 
    eg transact
    which uses instance variables created above 
Instance variables  
    created with self. as prefix 
    no access control 
    
Instance methods 
    1st arg is self 
    where python puts instance 
self 
    not a keyword 
    but must be first arg 
    where python puts the instance 
__init__ 
    part of special methods 
    Lots of special methods 
    for different purposes , Refer:    https://docs.python.org/3/reference/datamodel.html#special-method-names

"""
class BankAccount:
    def __init__(self, init_amount):  #self=ba, init_amount=100
        self.balance = init_amount   # instance variable
        #ba.balance = 100
    def transact(self, amount):  #self=ba, amount =100
        self.balance += amount 
        #ba.balance += 100 
        #=> ba.balance == 200
        
#usage 
#create instance
ba = BankAccount(100) #=>#BankAccount.__init__(ba, 100)
ba.transact(100)      #=>#BankAccount.transact(ba, 100)
print(ba.balance)     #200
        
a = 5
#: is must else SyntaxError
#: denotes block starting 
#next line must be indented else IndentationError
#indents - space or TAB - dont mix 
#CS - PEP8 - 4 spaces 
if a < 1:
    print("greater")
    print("greater")
    print("greater")
elif a > 2:
    print("greater")
    print("greater")
    print("greater")
else:
    print("else")
    print("else")
print("OUTSIDE")

#TASK1- Write 5 times "hello world" to  "demo.txt" file 
#TASK2- Read "demo.txt" and prepend "#" 
#to each line and write that to "demo.bak.txt"
path = "demo.txt"
out = ["Hello World\n"] * 5 
with open(path, "wt") as f:
    f.writelines(out)
    
#TASK-2 
#Read 
with open(path, "rt") as f:
    lines = f.readlines()
#process 
out = []
for l in lines:
    out.append(f"#{l}")
#write 
path = r"demo.bak.txt"
with open(path, "wt") as f:
    f.writelines(out)
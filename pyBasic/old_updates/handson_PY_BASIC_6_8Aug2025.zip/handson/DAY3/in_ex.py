"""
User input 
    str, so convert to other data type 
    Use input function 
    Use env var 
        >set MYPWD=ok
        >python
        >>> import os
        >>> os.environ['MYPWD']
        'ok'
    Use config file 
    Use command line arg 
        when we execute 
        >python filename.py arg1 arg2 
        it comes into 
        sys.argv = ['filename.py', 'arg1', 'arg2']
    PROB1: what if user does not provide value 
        SOL- Create default action 
    PROB2: what if user provides erroneous input 
        SOL - handle the exception with default strategy         https://docs.python.org/3/library/exceptions.html#exception-hierarchy
"""
import sys 
default_age = 40

name = input("Give Name:")
#X if Y else Z => if Y is true do X else do Z
sage = sys.argv[1] if len(sys.argv) > 1 
    else default_age
try:
    age = int(sage)
except ValueError:
    print("Count not parse, using default age")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known" )
        

def square(x):
    """squaring a number 
    and returning"""
    z = x*x 
    return z 

def mean(lst):
    return sum(lst)/len(lst) 

import mex 

print(f"""
square of 10 
= {mex.square(10)}
""")
lst = list(range(10)) #0,to9 with step of 1
lst = list(range(0,10,1)) # start, end, step, end is not included 
m = mex.mean(lst)
print(m)
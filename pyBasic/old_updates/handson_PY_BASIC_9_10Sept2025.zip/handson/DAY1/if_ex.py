# if name is "XYZ" and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 


#Write in nested if to understand indents in nested if 
#if name checking, inside if age checking

name = "XYZ"
age = 45
if name == "XYZ":
    if age < 40:
        print("Suitable.")
    elif age > 50:
        print("Old.")
    else:
        print("OK.")
else:
    print("Not Known.")
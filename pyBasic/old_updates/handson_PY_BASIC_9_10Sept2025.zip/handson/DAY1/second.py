a = 1
#SyntaxError - : starts a block 
#Next line must be indented else IndentationError
#Indent can be space or tab , dont mix 
#CS - PEP8 - 4 spaces 

if a >= 1:
    print("greater-equal")
    print("greater-equal")
    print("greater-equal")
elif a < 1:
    print("Less")
    print("less")
else:
    print("else")
    print("else")
print("OUTSIDE")
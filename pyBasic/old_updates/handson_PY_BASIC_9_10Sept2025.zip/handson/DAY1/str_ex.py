s = "Hello World and Earth"
#print the count of uppercase, lowercase charcaters
#and how many spaces 

#hint- .islower(), isupper()..
#put the string in for loop 

upper, lower , space = 0, 0, 0
for char in s:
    if char.isupper():
        upper = upper + 1
        #upper += 1
    elif char.islower():
        lower += 1
    elif char.isspace():
        space += 1

print(f"upper={upper}, {lower=}, {space=}")
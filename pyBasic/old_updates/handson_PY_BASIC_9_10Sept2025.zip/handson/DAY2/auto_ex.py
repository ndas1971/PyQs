#Find all windows patches/hotfixes/KB installed in one machine 
"""
Execute one command 
    command = "systeminfo"
capture the output 
    import subprocess
    https://docs.python.org/3/library/subprocess.html
    hint - Enable 
    capture_output     => captures stdout
    shell              => executing under shell
    universal_newlines => convert bin to text
extract required info
    import re 
    pat = r""
"""
import re 
import subprocess 
command = 'systeminfo'
pat = r"KB\d+"
proc = subprocess.run(['systeminfo'],
        shell=True,
        capture_output=True,
        text=True)
kbs = re.findall(pat, proc.stdout)
print(kbs)
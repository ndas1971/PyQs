#We can create Bankaccount with initial balance 
#we can transact

"""
class 
    collection instance methods 
    and instance variable 
instance/object 
    we call those methods 
    which operate on instance variables 
    
STEP1
    what are the variables with which 
    we create instance 
        init_balance 
    those are generally instance variable 
    create those in initiizer method 
STEP2
    write a initializer method 
    named __init__
    which takes initial balance 
    and create instance variable 
Step3:
    Write other methods which modify 
    instance variable created in STEP2 
__init__
    Special method 
    https://docs.python.org/3/reference/datamodel.html#special-method-names
self 
    Not a keyword , by convention 
    MUST be first arg 
    where Py will put instances 
    through that we access all instance variable 
"""
class Bankaccount:
    def __init__(self, init_balance): #self=ba, init_balance=100
        self.balance = init_balance  #instance variable 
        #self.twiceOfBalance = self.balance * 2
        #ba.balance = 100
        #ba2.balance = 1000
    def transact(self, amount): #self=ba, amount=100
        self.balance += amount 
        #ba.balance += 100
        #ba2.balance += 500
        
#__name__ in scrip = '__main__'
#in module - it filename 
if __name__ == '__main__':
    #Usage #create an instance 
    ba = Bankaccount(100) #Bankaccount.__init__(ba, 100)
    ba.transact(100)      #Bankaccount.transact(ba, 100)
    print(ba.balance)     #200
    ba2 = Bankaccount(1000) #Bankaccount.__init__(ba2, 1000)
    ba2.transact(500)       #Bankaccount.transact(ba2, 500)
    print(ba2.balance)      #1500
    
    

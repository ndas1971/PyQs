"""
Always in string, convert to other datatype 
Using input (uses internally stdin file)
    For sensetive data entry eg passowrd 
    check REF getpass etc module
Use environment variable 
    >set MYPWD=ok
    Then inside python 
    import os
    os.environ['MYPWD']
    #'ok'
Use configuration file 
    open etc methods
Command line arguments 
    When we execute 
    >python filename.py arg1 arg2 ...
    those will come to 
    sys.argv = [ 'filename.py', 'arg1' ,'arg2']
    
PROB1: User does not provide 
    sol - use default strategy 

PROB2: User provides wrong data 
    SOL - handle exception 
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    
"""
import sys 
default_age = 20 

name = input("Give Name:")
#X if Y else Z => if Y is true, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
#except ValueError:
except Exception:  
    print("Can not convert your age, using default")
    age = default_age
#except another_except:
    #more handling 
#except Exception:  # catch all 
    #catch all handling 

if name == "XYZ":
    if age < 40:
        print("Suitable.")
    elif age > 50:
        print("Old.")
    else:
        print("OK.")
else:
    print("Not Known.")
def square(x):
    """Squaring a number and 
    returning"""
    z = x * x 
    return z
    
    
# Mean(lst) =
#     Sum of lst/length of lst 
#     hint - builtin sum func 
#     https://docs.python.org/3/library/functions.html
#     sum([1,2,3]) => 6 
def mean(list_num):
    return sum(list_num)/len(list_num)

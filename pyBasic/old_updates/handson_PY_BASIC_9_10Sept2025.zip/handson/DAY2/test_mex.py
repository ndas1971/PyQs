import mex #Py search mex.py from sys.path 
#so cwd be searched at first

print(f"""
square of 10 = {mex.square(10)}
""")

lst = [1,2,3,4]
m = mex.mean(lst)
print(m)

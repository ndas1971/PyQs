# if name is "XYZ"  and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#OBJ - nested if 
#if name checking, inside if age checking 
age = 40
name = "XYZ"
if name == "XYZ":
	if age < 40:
		print("suitable")
	elif age > 50:
		print("Old")
	else:
		print("OK")
else:
	print("not known")
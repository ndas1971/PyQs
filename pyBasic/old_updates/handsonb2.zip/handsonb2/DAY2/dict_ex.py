para = """Python is an easy to learn, powerful programming language. It has efficient high-level data structures and a simple but effective approach to object-oriented programming. Python’s elegant syntax and dynamic typing, together with its interpreted nature, make it an ideal language for scripting and rapid application development in many areas on most platforms.
"""
#dict problem - key = word, value = count of that word 

#hint - create an empty dict, Pick each word (after splitting)
#if that word exists in that dict. increment its value 
#else create a key with that word and initialize its value  
freq = {}
for wd in para.split():
    if wd not in freq:
        freq[wd] = 1 
    else:
        freq[wd] += 1
print(freq)
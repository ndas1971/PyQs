s = "Hello World Hello Earth"
#print the frequency of each character 
#frq - how many times 
#H - 2
#e - 2
#l - 5 
#....
#Pick each char, ch1 from  s 
#    initialize a count 
#    Pick each char , ch2, from s 
#        if ch1 and ch2 are same 
#            increment the count 
#    print ch1 and its count 
for ch1 in set(s):
    count = 0 
    for ch2 in s:
        if ch1 == ch2:
            count += 1 # count = count + 1
    print(ch1, "-", count)


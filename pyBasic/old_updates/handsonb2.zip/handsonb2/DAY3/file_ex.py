# TASK1:
# Write 5 times "hello world" to  "demo.txt" file
lines = [ "hello world\n" * 5]
path = "demo.txt"
with open(path, "wt") as f:
    f.writelines(lines)

# TASK2
# Read "demo.txt" and prepend "#" to each line 
# and write that to "demo.bak.txt"
#read 
with open(path, "rt") as f:
    lines = f.readlines()
#process 
olines = []
for line in lines:
    olines.append(f"#{line}")
#write 
with open("demo.bak.txt", "wt") as f:
    f.writelines(olines)

#hint - TASK1 - use wt mode 
#then use writelines 
#TASk2: rt for reading, wt for writing 
#readlines -> gives list of lines 
#do line processing and then do writelines
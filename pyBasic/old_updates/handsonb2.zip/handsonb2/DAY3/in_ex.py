# if name is "XYZ"  and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#OBJ - nested if 
#if name checking, inside if age checking 
"""
4 ways 
    we get only string, so we need to convert 
  Using input 
        password 
  Using env var 
    import os 
    os.environ['MYPASSWORD']
  Reading config files 
    Use file handling 
  Using command line variables 
    when we execute 
    python filename arg1 arg2 
    it goes 
    sys.argv = [ 'filename', 'arg1', 'arg2'] 
    
Error 
    via exception 
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    try:
        do any code which might raise exception 
    except firstexception:
        do something 
    except firstexception:
        do other thing 
    except Exception:  # catch all, Exception is base class 
        do something 
    finally:
        always gets executed 
        
        
"""
import sys 
default_age = 40 
name = input("Give Name:")
#X if Y else Z => if Y true, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError as ex:
    print(ex)
    print("Using default age")
    age = default_age
if name == "XYZ":
	if age < 40:
		print("suitable")
	elif age > 50:
		print("Old")
	else:
		print("OK")
else:
	print("not known")
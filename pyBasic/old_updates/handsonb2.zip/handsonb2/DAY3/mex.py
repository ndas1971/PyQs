def square(x):
    """squaring and returning 
    the square"""
    z = x*x 
    return z 

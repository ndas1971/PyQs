para = "Hello World and Hello Earth and Hello to everybody"
#write a code to print frequency of each word
#key=word , value = count 
#create freq of words ie dict of word:count,...

#hint - split with spaces to create list of words 
#create empty dict, Iterate above list 
#if a word does not exist in dict, create a key with that word 
#and initialize, else increment its value 
words = para.split()
dist = {}
for word in words:
    if word in dist:
        dist[word] += 1
    else:
        dist[word] = 1
    
print(dist)
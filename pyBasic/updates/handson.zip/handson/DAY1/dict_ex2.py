master_covid_data = { 'usa' : {'+ive': 20, 'test': 200 },
                    'india': {'+ive': 15, 'test': 100 }}
#Update master_covid_data with today's data
today_data = {'usa' : {'+ive': 1, 'test': 1.5 },
         'india': {'+ive': 0.75, 'test': 1 },
         'af' : {'+ive': 0, 'test': 0 }} 

#hint - handle all the cases, countryname is present in both dict 
#countryname is not present in master_covid_data
#and even if it is present, new keys might be there in today_data

print(master_covid_data)
for cname in today_data:
    if cname not in master_covid_data:
        #copy all from today_data to master_covid_data
        master_covid_data[cname] = {}
        for k,v in today_data[cname].items():
            master_covid_data[cname][k] = v
        #all above can be written like 
        #master_covid_data[cname] = today_data[cname].copy()
    else:
        #we should merge today_data with master_covid_data
        #TODO - simplify like above 
        for k in today_data[cname]:
            master_covid_data[cname][k] += today_data[cname][k]
        
        
print(master_covid_data)
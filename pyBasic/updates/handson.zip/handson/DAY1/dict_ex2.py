master_covid_data = { 'usa' : {'+ive': 20, 'test': 200 },
                    'india': {'+ive': 15, 'test': 100 },
                    'zim': {'+ive': 10, 'test': 1 }}

#Update todate's data in master data 
#such that existing keys are added with  new value 
#new keys are added 
today_data = {'usa' : {'+ive': 1, 'test': 1.5 },
         'india': {'+ive': 0.75, 'test': 1 },
         'af' : {'+ive': 0, 'test': 0 }}

for country in today_data:
    if country in master_covid_data:
        master_covid_data[country]['+ive'] += today_data[country]['+ive']
        master_covid_data[country]['test'] += today_data[country]['test']
    else:
        master_covid_data[country] = today_data[country].copy()

print(master_covid_data)
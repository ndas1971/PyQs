# Execute this file by 
# python first.py 
a = 1
print(a, "Hello World")


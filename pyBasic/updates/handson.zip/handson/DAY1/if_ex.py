a = 1
#INDENTATIONERROR - inside block 
#give space or tab (DONT MIX)
#CS - PEP8 - four space 

#SyntaxError- : starts a block 
#block must be indented 

if a == 1:
    print("greater")
    print("greater")
    print("greater")
elif a < 1:
    print("less")
    print("less")
else:
    print("else")
    print("else")
print("OUTSIDE")

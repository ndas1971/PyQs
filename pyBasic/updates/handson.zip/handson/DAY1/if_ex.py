# if name is "XYZ" and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#OBJ - write nested if - to understand indentation
#if name checking , inside if age checking 
name = "XYZ"
age = 55
if name == "XYZ" : 
    if age <= 40 :
        print("Suitable")
    elif  age >= 50 :
        print("age is old")
    else :   
        print("OK")
else :    
    print("Not known")
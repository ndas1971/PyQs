#Given input, convert into output 
input = '[1,2,3,4]'
output = [1,2,3,4]

#hint - Remove '[]' and then 
#split by ',' which gives list of string 
#now each of these string needs to be converted to number 
#by 
#create an empty list, then iterate 
#above list, convert each and then append to empty list 
el = []
for e in input.strip('[]').split(","):
    el.append(int(e))
#Above can be written using simplified
#syntax called comprehension
#REF - https://docs.python.org/3/tutorial/datastructures.html#list-comprehensions
print(el)
input = '[1,2,3,4]'
#Parse this to convert list of numbers 
#ie output = [1,2,3,4]

#hint: remove [] (strip) and split by , 
#gives list of str
#create an empty list , loop above, convert to int 
#and then append to the empty list  
in2 = input.strip('[]')
in3 = in2.split(",")
#--- map or comprehension
el = []
for e in in3:
    el.append(int(e))
#--- map or comprehension ends 
#https://docs.python.org/3/tutorial/index.html
print(el)


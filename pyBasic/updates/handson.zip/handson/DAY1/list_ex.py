input = '[1,2,3,4]'
output = [1,2,3,4]
#Given input , convert that to output 

#Hint - remove [] and then split by , 
#we wud have list of string 
#convert to list number 
#subhint - create empty list 
#iterate above, convert each str to int 
#append to empty list 
#------Map pattern 
el = []
for e in input.strip('[]').split(","):
    el.append(int(e))
#-----
#comprehension - https://docs.python.org/3/tutorial/datastructures.html#list-comprehensions
print(el)
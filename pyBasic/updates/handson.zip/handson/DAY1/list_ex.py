input = '[1,2,3,4]'
#parse it to output 
output = [1,2,3,4]

#hint - remove [], then split by , 
#to get list of str(each str containing int)
#so convert each str to int by 
#creating empty list, iterate original 
#convert each to int and append to empty list 
tmp = input.strip('[]').split(",")
output = []
for e in tmp:
    output.append(int(e))
print(output)

#Pl check comprehension syntax 
#which simplifies above into single line 
#Ref - https://docs.python.org/3/tutorial/datastructures.html#list-comprehensions


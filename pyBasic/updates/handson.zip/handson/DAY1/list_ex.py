#Given input,
input = '[1,2,3,4]'
#get the output 
output = [1,2,3,4]

#hint - strip [], then split 
#after this, we will get , list of number string
#convert this list of number 
#Hint- create empty list, iterate, convert each element 
#and append that empty list 
list1=[]
for e in input.strip("[]").split(","):
    list1.append(int(e))
print(list1)
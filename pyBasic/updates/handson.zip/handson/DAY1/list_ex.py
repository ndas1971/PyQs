#parse input and create output 
input = '[1,2,3,40]'

output = [1,2,3,40]

#hint - Remove '[]' - slice/strip 
#then split by ',' to list string 
#convert each element to number by int 
#subhint - create an empty list, iterate source list 
#convert and append to empty list 
#---------------MAP-----
output = []
for e in input.strip('[]').split(","):
    output.append(int(e))
#---- comprehension - https://docs.python.org/3/tutorial/datastructures.html#list-comprehensions 
print(output)

lst = ["Hello", "World", "OK", "FOUR"]

#how many strings in lst? 
#create a new list containing only even length strings 
#how many even length strings 

print(f"how many strings in lst? -> result :{len(lst)}")

el = []
for e in lst:
    if len(e) % 2 == 0:
        el.append(e)
        
print(el)
print(f"how many even length strings: {len(el)}")
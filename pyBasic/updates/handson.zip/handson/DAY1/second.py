a = 1

#SyntaxError - : is must, means a block has started 
#next line must have indents else IndentationError
#indents - space or tab - DONT MIX it 
#Coding style - PEP8 - 4 spaces 

if a >= 1:
    print("greater-equal")
    print("greater-equal")
    print("greater-equal")
elif a < 1:
   print("elif")
   print("elif")
   print("elif")
else:
    print("else")
    print("else")
print("OUTSIDE")
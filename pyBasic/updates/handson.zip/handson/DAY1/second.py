a = 1
# SYNTAX ERROR - : is must , a block starts 
#INDENTATION ERROR - inside block, INDENT is must 
#INDENT - tab or space , block ends when indentation ends 
#TAB or space - dont mix it 
#CS - PEP8 - 4 spaces - stick to tab
if a >= 1:
    print("greater")
    print("greater")
    print("greater")
elif a < 1:
    print("lesser")
    print("lesser")
else: 
    print("else")
    print("else")
print("OUTSIDE")

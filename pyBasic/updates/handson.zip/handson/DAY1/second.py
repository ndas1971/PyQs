a = 1
#SyntaxError- : is mandatory
#: says block is starting 
#block should be indented else INDENTATIONERROR
#by TAB or space - DONT MIX 
#CS - PEP8 - 4space 
if a >= 1:
    print("greater")
    print("greater")
    print("greater")
elif a < 1:
    print("less")
    print("less")
    print("less")
else:
    print("else")
    print("else")
print("OUTSIDE")

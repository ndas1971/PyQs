a = 1
# : must else SyntaxError
#: means block , next line must have indents 
#else IndentationError
#indents are tab or space , DONT MIX IT 
#Coding style - PEP8- 4 space 
if a >= 1:
    print("greater-equal")
    print("greater-equal")
    print("greater-equal")
elif a < 1:
    print("elseif")
    print("elseif")
    print("elseif")
else:
    print("else")
    print("else")
print("OUTSIDE")

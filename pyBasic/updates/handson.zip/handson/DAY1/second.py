a = 1
#SyntaxError - : is must 
#means starts a block 
#inside block, lines should be indented else IndentationError
#indents - tab or space - dont mix it 
#as Coding style - PEP8 - use 4 space 
if a >= 1:
    print("greater-equal")
    print("greater-equal")
    print("greater-equal")
elif a < 1:
    print("less")
    print("less")
    print("less")
else:
    print("else")
    print("else")
    print("else")
print("OUTSIDE")

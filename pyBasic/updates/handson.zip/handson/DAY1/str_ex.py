s = "Hello World and Hello Earth"

#how many uppercase , lowercase 
#and how many spaces 

#hint - use .islower etc instance methods 
#then use for loop and count accordingly 
cupper , clower, cspace = 0, 0, 0
for ch in s:
    if ch.islower():
        clower += 1 #clower = clower + 1
    elif ch.isupper():
        cupper += 1
    elif ch == ' ':
        cspace += 1
print(cupper , clower, cspace)

s = "Hello World and Hello Earth"
#count how many upper case and lower case characters
#also how many spaces 

#Hint - .islower, .isupper instance methods 
clower, cupper, cspace = 0,0,0
for ch in s:
    if ch.islower():
        clower += 1
    elif ch.isupper():
        cupper += 1
    elif ch == ' ':
        cspace += 1
print(clower, cupper, cspace)
#in python >3.10
#print(f"{clower=}, {cupper=}, {cspace=}")
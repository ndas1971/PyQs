s = "Hello World and Hello Earth"
#how many lower case, upper case characters 
#also how many spaces 
#hint - .islower(), isupper() etc 
#Use for loop for iteration 
clower, cupper, cspace = 0, 0, 0
for ch in s:
    if ch.islower():
        clower += 1 #=># clower = clower + 1
    elif ch.isupper():
        cupper += 1
    elif ch == ' ':
        cspace += 1
print(clower, cupper, cspace)
#for > p3.10 
#print(f"{clower=}, {cupper=}, {cspace=}")


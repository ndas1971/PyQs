para = "Hello World and Hello Earth and Hello to everybody"
#write a code to print frequency of each alphabet
#it should print 
#H - 3 
#e - ...
#Pick each character, ch1  from para 
#    initialize count 
#    Pick each character, ch2 from para   
#        if ch1 and ch2 are same 
#            increment count 
#    print ch1 and count 
for ch1 in set(para):
    count = 0
    for ch2 in para:
        if ch1 == ch2:
            count = count + 1
    print(ch1, count)


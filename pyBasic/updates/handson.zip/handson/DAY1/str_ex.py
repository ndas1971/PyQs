s = "Hello World and Hello Earth"

#Count uppercase, lowercase characters 
#and space in s 

#hint - use instance methods, eg .islower()...
#and for loop 

cupper, clower, cspace = 0,0,0
for ch in s:
    if ch.isupper():
        cupper = cupper + 1
    elif ch.islower():
        clower += 1  #=># clower = clower + 1
    elif ch == ' ':
        cspace += 1
        
print(f"{cupper=}, {clower=}, {cspace=}") #{var=} prints var and its value 

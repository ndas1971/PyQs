s = """Hello world
and hello
earth"""
#can you tell me how many lines 
#and length of each line
print(s.splitlines())
#list is exactly same as string 
#only difference is list contains few elements 
#whereas string contains few characters 
for line in s.splitlines():
    print(len(line))


s = "Hello World and hello earth and hello to every one"
#find number of lower case, uppercase and 
#spaces in the string s 

#hint- Use .islower(), .isupper() 
#Iterate s uisng for loop, then use if 
#to find out all these three counts 
clower, cupper, cspace = 0, 0, 0
for ch in s:
    if ch.islower():
        clower += 1
    elif ch.isupper():
        cupper += 1
    elif ch == ' ':
        cspace += 1
#print(f"{clower=},{cupper=},{cspace=}")
print(clower, cupper, cspace)  
s = "Hello World and Hello Earth"

#find how many upper case, lower case 
#characters and also find how many spaces 

#Hint - .lower() etc instance methods 
#You need to use for loop as well to iterate the s 

cupper, clower, cspace = 0,0,0
for ch in s:
    if ch.islower():
        clower += 1
    elif ch.isupper():
        cupper += 1
    elif ch == ' ':
        cspace += 1
print(f"{cupper=}, {clower=}, {cspace=}")
print(cupper, clower, cspace)


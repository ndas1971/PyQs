"""
pytest 
    GUI automation 
        Web page 
            dynamic 
                selenium 
            static 
                requests 
        windows GUI 
            OCR 
            pywinauto
    REST API automation 
        json with requests 
    Shell automation 
        key = what tool 
        how to run a program 
            using subprocess
            https://docs.python.org/3/library/subprocess.html
            command = "systeminfo"
        and then capture the output 
            stdout 
        and process the output 
            string processing 
            using REGEX 
            https://docs.python.org/3/library/re.html
"""
#Handson - what are hotfixes installed in own machine 
import re 
import subprocess 
command = "systeminfo"
cproc = subprocess.run([command], 
        capture_output=True,
        universal_newlines=True) #by default, captures in bytes, convert to string
stdout = cproc.stdout 
pat = r"KB\d+"
hotfixes = re.findall(pat, stdout)
print(hotfixes)





#find all the hotfixes installed in one machine
"""
Any module?
Any tool?
    (shell automation)
    commandline tool 
        command = "systeminfo"
        execute that command 
            import subprocess
            check ref which method to execute 
        capture the output 
            enable flag 
            shell=True, universal_newlines=True 
            capture_output=True 
            read stdout 
        extract info 
            import re 
            decide pattern 
    UI tool 
        webserver based UI 
            requests/selenium 
        app based UI 
            autowingui/...
            RPA
                blueprism 
"""
import subprocess 
import re 
command = "systeminfo"
p = subprocess.run([command], 
        shell=True,
        capture_output=True,
        universal_newlines=True)
#print(p.stdout)
pat = r"KB\d{7}"  #KB5056578
hotfixes = re.findall(pat, p.stdout)
print(hotfixes)
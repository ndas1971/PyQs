"""
Get the list of windows patches 

1. execute systeminfo command 
2. capture the output 
   import subprocess
   https://docs.python.org/3/library/subprocess.html
   OS opens three IOs, stdin - input 
   stdout - print, stderr - print errors 
   Capture stdout 
   Do we want to execute under shell ?
      shell = True 
   Do you want to capture the output in text?
      universal_newlines = True 
   Do you want to capture output?
        enable that flag 
3. extract KB information 
    import re 
    pat = r"..."    
"""
import subprocess 
import re 
command = "systeminfo"
pat = r"KB\d+"
p = subprocess.run([command], 
            shell=True, 
            capture_output=True, 
            universal_newlines=True)
fixes = re.findall(pat, p.stdout)
print(fixes)










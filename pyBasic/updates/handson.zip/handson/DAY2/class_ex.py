"""
Bank account can be created with initial balance
and it can transact
STEP-1:
    decide initialization parameter
    initial_amount
STEP-2:
    write initialization method taking those parameter
    def __init__(self,....)
    Create instance variables 
    - are variables which will be used by other methods 
STEP-3:
        write other methods 
        which read or write instance variables 
Python 
    No access control 
Self
    not a keyword 
    Must be first arg where pythons puts instance 
    by convention , we call self 
__init__ 
    part of many such methods 
        special methods 
        https://docs.python.org/3/reference/datamodel.html#special-method-names
Adv 
    inheritance 
    own exception 
    class/static/property 
    special methods 
    MRO/metaclass
    unit testing 
    package using poetry  
Private method 
        Not there 
        by convenstion, if anymethod starts with _ 
        it is considered private 
"""
class BankAccount:
    def __init__(self, initial_amount):
        self.balance = initial_amount  #ba.balance = 100
    def transact(self, amount):
        self.balance += amount   #ba.balance += 100
        
#Handson 
#Bank user has name and bankaccount. It can transact 
#Hint - delegate that transact to bankaccount transact 
class BankUser:
    def __init__(self, name, initial_amount):   #composition- has/have 
        self.name = name 
        self.account = BankAccount(initial_amount)
    def transact(self, amount):
        self.account.transact(amount) #delegation
    def balance(self):
        return self.account.balance
#Usage 
ba = BankAccount(100)  #BankAccount.__init__(ba, 100)
ba.transact(100)       #BankAccount.transact(ba, 100)
print(ba.balance)      #200

bu = BankUser("ABC", 100)
bu.transact(1000)
print(bu.balance())

"""
BankAccount takes initial balance 
can do transaction 
can print to check latest balance 
"""

"""
class 
    collection of instance methods (functions)
    they operate on instance variables
    instance variable 
        some variables/data part of an instance 
instance 
    memory of above class    

self
    that instance 
    No 
    MUST BE first arg 
Special methods 
    methods called for certain tasks 
    https://docs.python.org/3/reference/datamodel.html
    https://docs.python.org/3/reference/datamodel.html#special-method-names
    __init__ called during initialization 
    __str__ is called during print 
"""
class BankAccount:
    def __init__(self, init_amount): #instance methods 
        self.balance = init_amount   #instance variable 
        print("__init__", self, init_amount)
    def transact(self, amount):
        print("transact", self, amount)
        self.balance += amount 
    def __str__(self):
        print("__str__", id(self))
        return f"BankAccount({self.balance})"
    
print("creating instance")
ba = BankAccount(100)  #BankAccount.__init__(ba, 100)
print("calling transact")
ba.transact(100)       #BankAccount.transact(ba, 100)
print("now printing")
print(ba)              #BankAccount.__str__(ba)
print(ba.balance) 

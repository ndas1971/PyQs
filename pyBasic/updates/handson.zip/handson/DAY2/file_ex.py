#TASK1- Write 5 times "hello world" to  "demo.txt" file 
#TASK2- Read "demo.txt" and prepend "#" to each line 
#and write that to "demo.bak.txt"
#TASK1:
path = r"demo.txt"
out = ["Hello World\n"] * 5
with open(path, "wt") as f:
    f.writelines(out)
    
#TASk2:
in_f = r"demo.txt"
out_f = r"demo.bak.txt"
with open(in_f, "rt") as f:
    lines = f.readlines()
#now process 
out = []
for l in lines:
    out.append(f"#{l}")
with open(out_f, "wt") as f:
    f.writelines(out)
    
    
    
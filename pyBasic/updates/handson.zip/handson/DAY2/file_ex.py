#Write 5 times "hello world" to  "demo.txt" file (file mode-wt)
#Read "demo.txt" and prepend "#" to each line 
#and write that to "demo.bak.txt"
original_file = r"demo.txt"
lines = ["Hello world\n"] * 5
with open(original_file, "wt") as file:
    file.writelines(lines)
    
updated_file = r"demo.bak.txt"
with open(original_file, "rt") as data_file:
    lines = data_file.readlines()
    with open(updated_file, "wt") as write_file:
        for line in lines:
            write_file.write(f"#{line.strip()}\n")
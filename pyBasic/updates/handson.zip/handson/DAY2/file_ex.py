#TASK1 - Write 5 times "hello world" to  "demo.txt" file 
#TASK2 - Read "demo.txt" and prepend "#" to each line 
#and write that to "demo.bak.txt"

#TASK1 
path = "demo.txt"
out = ["Hello World\n"] * 5 
with open(path, "wt") as f:
    f.writelines(out)
    
#TASK2 
with open(path, "rt") as f:
    lines = f.readlines()
#Process
out = []
for l in lines:
    out.append(f"#{l}")
#store 
path1 = "demo.bak.txt"
with open(path1, "wt") as f:
    f.writelines(out)
"""
How to take user inputs 
    (always in string )
    Use input 
    Use environment variable 
        os.environ is dict 
        > set MYPW=xbcv
        os.environ['MYPW']
    Use config file 
        text file, use open with rt 
    Use command line 
        > python filename arg1 arg2 
      comes into sys.argv 
      sys.argv = ['filename', 'arg1' ,'arg2']
Exception 
https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    Multiple except block 
    catch all block 
    finally block 
    https://docs.python.org/3/library/exceptions.html
"""
import sys
print(sys.argv)

default_age = 40  
default_salary = 1000
name = input("Give Name:")
#X if Y else Z => if Y true, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 \
    else default_age
ssalary = sys.argv[2] if len(sys.argv) > 2 else default_salary
try:
    age = int(sage)
except ValueError as ex:
    print(f"Error: {ex}, using default age") 
    age = default_age
if name in [ "XYZ", "ABC"]:
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")
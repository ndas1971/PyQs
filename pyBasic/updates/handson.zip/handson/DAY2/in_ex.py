"""
User data 
    (always in string, so convert)
    Use input 
        for password
    Use env var 
        set MYPWD=xyz
        Then 
        import os
        os.environ['MYPWD']
    Use configuration file 
        json/ini/toml/xml - dedicated modules
    Using command line 
        When we execute 
        > python filename arg1 arg2 
        comes into 
        sys.argv = ['filename', 'arg1', 'arg2' ]
        Use high level modules based on sys.argv 
            eg argparse 
     PROB1:when user does not provide 
        sol - default action when not existing 
     PROB2: user provides erroneous data 
        sol - handle the exception 
            option1 - use default 
            
Exception 
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    try:
        #some line 
    except exception_name1 as ex:
        #handle 
    except exception_name2 as ex:
        #handle 
    except Exception as ex:
        #catch all 
        #handle 
    finally:
        #always gets executed 

"""
import sys 
default_age = 40 

name = input("Give Name:")
#X if Y else Z => if Y true, do X else do Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError:
    print("Erroneous data, using default age")
    age = default_age
if name == "XYZ" : 
    if age <= 40 :
        print("Suitable")
    elif  age >= 50 :
        print("age is old")
    else :   
        print("OK")
else :    
    print("Not known")
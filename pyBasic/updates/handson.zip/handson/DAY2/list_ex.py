input = '[1,2,3,4]'
#parse above input to below output 
output = [1,2,3,4]

#hint - remove prefix and suffix [] - use strip or slice 
#Then split based on ,  Result is list of string 
#convert that to list of number 
#subhint - create empty list, iterate above 
#convert each to int and append to empty list 
el = []
tmp = input.strip('[]').split(",")
for e in tmp:
    el.append(int(e))
    
print(el)
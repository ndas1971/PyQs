#Given input, get the output 
input = '[1,2,3,4]'
output = [1,2,3,4]

#hint: remove prefix/suffix [] - slicing or strip 
#then split based on , - we will get list of string 
#convert each str to int - by 
#create empty list, iterate and convert each and then append to empty list 
tmp = input[1:-1].split(",")
output = []
for e in tmp:
    output.append(int(e))
print(output)
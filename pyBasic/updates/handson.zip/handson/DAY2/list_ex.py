#Given input, create output 
input = '[1,2,3,4]'  #<= string of list of numbers

output = [1,2,3,4]   #<= list of string 

#hint- remove '[]' - strip/slice, then split by ",", => list of string 
#create empty list, iterate, convert each str to int 
#and append to empty list 
output = []
for e in input.strip('[]').split(","):
    output.append( int(e))
    
print(output)

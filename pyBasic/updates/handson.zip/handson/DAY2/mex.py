def square(x):
    """squaring a number 
    and returning"""
    z = x*x 
    return z 

    
# mean(lst) =         
# Sum of lst/length of lst 
# Use builtin sum function 
# https://docs.python.org/3/library/functions.html
def mean(lst):
    return sum(lst)/len(lst)
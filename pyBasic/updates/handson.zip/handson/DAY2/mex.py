def square(x):
    """square and return 
    squared number"""
    z = x*x 
    return z 
    
    
"""
Mean(lst) = 
Sum of lst/length of lst 

Builtin function list 
https://docs.python.org/3/library/functions.html
"""
def mean(lst):
    return sum(lst)/len(lst)

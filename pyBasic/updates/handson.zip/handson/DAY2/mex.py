def square(x):
    """squaring number"""
    z = x*x
    return z
    
    

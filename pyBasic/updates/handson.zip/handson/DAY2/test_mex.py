import mex

print(f"""
square of 10 = {mex.square(10)}
""")
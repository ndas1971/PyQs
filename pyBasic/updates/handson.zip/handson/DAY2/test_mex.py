import mex  # RECCO 
x = 10
print(f"""
Square of {x}= {mex.square(x)}
""")
lst = [1,2,3,4]
res = mex.mean(lst)
print(res)




#OTHER options 
import mex as m   #alias of module #RECCO 
m.square(10)

#BELOW not RECCO
from mex import square 
square(10)
from mex import square as ms  #alias of function
ms(10)
from mex import * 
square(10)

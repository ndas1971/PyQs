#BankAccount can have initial opening balance 
#it can transact 
"""
STEP1:
    decide initialization parameters 
    Write a initializer taking those 
        name = __init__ 
        Create instance variables 
            these variabes are modified/accessed 
            in other methods of class - instane methods 
Step2:
    Write other methods which manipulates those instance variable 
Step3: Usage 
    creat a instance 
__init__ 
    one example of special methods
    Ref 
    https://docs.python.org/3/reference/datamodel.html#special-method-names

self 
    self is not a keyword 
    by convention, we call self 
    MUST be at first arg 
    thorugh which we create instance variable 
"""

class BankAccount:
    def __init__(self, init_amount):  
        self.balance = init_amount  #instance variable 
    def transact(self, amount):
        self.balance += amount      #access those instance variables 
        
        
#usage 
ba = BankAccount(100)  #BankAccount.__init__(ba, 100)
ba.transact(100)       #BankAccount.transact(ba, 100)
print(ba.balance)


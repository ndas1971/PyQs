# if name is "XYZ" and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#OBJ - nested if -
#first if check name 
#inside check age 
"""
OPtion-1:
    using input 
Option-2:
    os.environ is dict 
    key = env var, value = that's value 
Option-3:
    xml, yaml, ini - text files
    use open and others 
Option-4:
    command lines 
    > python file.py arg1 arg2 arg3 
    coms into 
    sys.argv = [ 'file.py', 'arg1', 'arg2', 'arg3']
    
    builtinmodules
    argparse 
    
Exception 
https://docs.python.org/3/library/exceptions.html#exception-hierarchy
"""
import sys 
print(sys.argv)

name = input("Give name:")
"""
might not provide age 
    Using default 
provide but wrong eg AB 
    Use default 
"""
default_age = 40 
# X if Y else Z 
#If Y is true, do X else Z 
age_ = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(age_)
#except ValueError as ex:
#    print("Error", ex, "Hence using default")
#    age = default_age
except Exception as ex:  #catch all 
    print("Error", ex, "Hence using default")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("Suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")


"""
User inputs are in str, use appropriate conversion 
Using input function 
    NOT RECo 
    getpass module and function
Using env variable 
    cmd>set MYPW=ok
    >>> import os
    >>> os.environ['MYPW']
    'ok'  
Use config files 
        Use open file
        ini or json 
Uase command line arg 
    cmd>python filename.py arg1 arg2 
    it comes and 
    sys.argv = ['filename.py', 'arg1', 'arg2'] 

PROB1:
    if user does not give input 
    strategy - have some default action 
PROB2:
    Use gives wrong data 
    strategy: handle exception 
    with some strategy 
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy

"""
import sys 
name = input("Give Name:")
default_age = 40 
#X if Y else Z => If Y true, do X else do Z 
#when user does not give data 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age

#below section for when user provides wrong data 
try:
    age = int(sage)
except ValueError:
    #
    print("Wrong age data, using default")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("ok")
else:
    print("not known")
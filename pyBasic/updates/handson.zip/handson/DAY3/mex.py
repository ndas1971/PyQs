def add(x,y):
    """add two numbers
    and return the addition"""
    z = x+y 
    return z 
    
    
#default arg always comes last 
def add1(x, y=20):
    return x+y 
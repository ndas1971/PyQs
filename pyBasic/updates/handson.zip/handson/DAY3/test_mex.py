import mex 

print(f"""
#positional way arg passing 
{mex.add(1,2)}
#keyword way arg passing 
{mex.add(y=3, x=2)}
#Mix but positional comes first 
{mex.add(1, y=3)}

#Default comes from definition 
{mex.add1(2)}
#Could have explitcitly passed 
{mex.add1(2,3)}

""")

a = 1
#syntax error - : - starts a block 
#IndentationError - inside block - idented
#indents - space or tab , dont mix it 
# Coding style - PEP8 - 4 space  
if a > 0:
    print("greater")
    print("greater")
    print("greater")
elif a < 0:
    print("lesser")
    print("lesser")
else:
    print("else")
    print("else")
print("OUTSIDE")
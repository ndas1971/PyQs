s = "Hello World and Hello Earth"
#count no of upper case, lower case and spaces 
#hint - use right instance methods and for loop 

clower, cupper, cspaces = 0, 0, 0 
for ch in s:
    if ch.islower():
        clower += 1
    elif ch.isupper():
        cupper += 1    
    wlif ch == " ":
        cspaces += 1
print(clower, cupper, cspaces)
#given a string of list 
#convert to list of NUMBERS 
input = '[1,2,3,4]'
output = [1,2,3,4]

#hint- strip [] and split by , and then 
#convert each string number to number and append to empty list 
el = []
for e in input.strip('[]').split(','):
    el.append(int(e))
print(el)
#Above pattern is called Map pattern 
#Python gives simple syntax - called comprehension 
#Refer for more details 
#https://docs.python.org/3/tutorial/datastructures.html#list-comprehensions
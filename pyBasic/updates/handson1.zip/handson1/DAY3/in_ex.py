"""
User inputs - in string  
Using input 
    Not used in real 
    Useful for taking sensitive data 
    Use - getpass , ...
    
Using environment variable 
    set MYPW=OK
    >>> import os
    >>> os.environ['MYPW']
    'OK'
Using config files 
    Use open/read etc 
    yaml/json/xml - use a module 
Using command line 
    (argparse... use module)
    when we execute 
    > python in_ex.py arg1 arg2 
    it comes and sits at 
    sys.argv = ['in_ex.py', 'arg1', 'arg2']
    
PROB1: DOnt provide data 
       - use a default strategy 
PROB2: provide data but wrong data 
        - Handle exception 
Exception :
https://docs.python.org/3/library/exceptions.html#exception-hierarchy
Handled by 
try:
    use API which raises exception 
except exception1 as ex:
    #handle exception1 
except exception2 as ex:
    #handle exception2 
except Exception as ex :
    #catch all 
finally:
    #always executed , exception or not 
"""
import sys 
default_age = 40 
name = input("Give Name:")
#X if Y else Z => if Y true, do X else do Z 
iage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(iage)
except ValueError as ex:
    print('error:', ex) 
    print("Using default age")
    age = default_age
    #exit(1)
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")

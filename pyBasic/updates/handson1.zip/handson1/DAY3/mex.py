def add(x,y):
    #doc string, help(mex.add)
    """adds two numbers 
    and returns"""
    z = x + y 
    return z 
#default comes last 
def add1(x,y=2):
    #doc string, help(mex.add)
    """adds two numbers 
    and returns"""
    z = x + y 
    return z 
    
add2 = lambda x, y: x+y 

#lambda - without name 
#dont use it , use def one 
#usecase- when function takes another function - ex- sorted/map/filter/reduce 
#Check - https://docs.python.org/3/library/functions.html
#can have default 
#but MUST have only expr as body which is implicitly returned 
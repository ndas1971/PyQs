import mex 

x,y = 10, 20
print(f"""
adding {x},{y} :
Positional= {mex.add(x,y)}
keyword = {mex.add(y=20,x=10)}
mix but positional comes first ={mex.add(10,y=20)} 
#with default 
{mex.add1(x)}
{mex.add1(x,100)}
#calling lambda 
{mex.add2(10,100)}

""")
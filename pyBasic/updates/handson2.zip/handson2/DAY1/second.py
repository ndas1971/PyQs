a = 1
#SyntaxError - : must , starts a block 
#IndentationError - block requires indents 
#tab or space - but dont mix it 
#no indent means block ends 
#CS - PEP8 - 4spaces
if a > 0:
    print("greater")
    print("greater")
    print("greater")
elif a < 0:
    print("lesser")
    print("lesser")
    print("lesser")
else:
    print("else")
print("OUTSIDE")

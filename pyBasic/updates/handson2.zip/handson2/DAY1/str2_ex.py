s = "Hello World"
#FInd frequency of each char 
#freq = how many times each char occurs 
#H - 1, e-1, l-3 ,....


#Hint - take each char, compare with again each char 
#if same, increment a count, when all done for inner for 
#loop, print count for that character 
for ch in s:
    count = 0 
    for ch1 in s:
        if ch == ch1:
            count += 1
    print(ch, count) 
s = "Hello World and Hello Earth"

#count uppercase, lowercase and space 
#hint - use instance method and for loop
clower, cupper, cspaces = 0, 0, 0 
for ch in s:
    if ch.isupper():
        cupper += 1
    elif ch.islower():
        clower += 1
    if ch == ' ':
        cspaces += 1
print(f"{clower=},{cupper=},{cspaces=}")
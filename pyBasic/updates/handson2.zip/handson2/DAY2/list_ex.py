input = '[1,2,3,4]'
output = [1,2,3,4]

#Given input, convert list of NUMBERS , not list of strings 
#hint - strip [] and split by , and then iterate 
#convert each to int and then append to empty list 
output = []
for e in input.strip('[]').split(','):
    output.append(int(e))
print(e)
#Above pattern is called Map 
#has a simpler syntax in python - comprehension 
#Refer - https://docs.python.org/3/tutorial/datastructures.html#list-comprehensions
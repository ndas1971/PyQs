"""
User inputs - in str 
Using input (stdin)
    NOT recommended 
    for taking sensitive data 
    USe getpass 
Use env variable 
    set MYPW=ok
    >>> import os
    >>> os.environ['MYPW']
    'ok'
config file 
    -text - open etc , modules to read xml/yaml/ini 
    - bin - vaults - 
command line arg(argparse or click)
    execute 
    > python file.py arg1 arg2 
    comes into 
    sys.argv = ['file.py', 'arg1', 'arg2']
PROB1: User does not give 
    sol - create a default strategy 
    
PROB2: user give wrong data 
        Handle exception 
        
Exception:
https://docs.python.org/3/library/exceptions.html#exception-hierarchy
try:
    #API causing exception 
except exception1 as ex:
    #handle exception1 
except exception2 as ex:
    #handle exception2
except Exception as ex :
    #catch all 
finally:
    #always executed 


"""
import sys 
default_age = 40 
name = input("Give Name:")
#X if Y else Z => if Y is true, do X else do Z
iage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(iage)
except ValueError as ex:
    #exit(1)
    print("Error:", ex)
    print("Using default age")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")
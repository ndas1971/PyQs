def add(x,y):
    #doc string , help(mex.add)
    #below string is shown 
    """adding two numbers 
    and returning"""
    z = a+b 
    return z
    
#defaults come last 
def add1(x, y=20):
    return x+y 
    
add2 = lambda x,y: x+y 
add3 = lambda x,y=1: x+y 

    
#lambda - no named function 
#all args possible but body contains 
#one expression which is returned implicitely 
#usecase - a function takes a function 
#refer - sorted/map/filter/reduce 
#https://docs.python.org/3/library/functions.html

#Handson - Write function 
#and its testing in test_mex.py 
def mean(lst):
    return sum(lst)/len(lst) 
    
#mean is sum of numbers 
#divided by len of number 
#Use builtin sum 
#check help(sum) and then use 
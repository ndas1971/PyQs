import mex 

#positional way 
res1 = mex.add(2,3)
#keyword way 
res2 = mex.add(y=3, x=1)
#mix 
#positional comes first 
res3 = mex.add(1, y=3)
#with default 
res4 = mex.add1(3) #y=default 
res5 = mex.add1(3,100)
#lambda calling 
res6 = mex.add3(3) #y=default 
res7 = mex.add2(3,100)

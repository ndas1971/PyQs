a = 1
#: is mandatory, it starts a block 
#Inside block, INDENTs must or IndentationError
#INDENT - tab or space , DONT MIX it 
#CS - PEP8 - 4 space 
if a >= 1:
    print("greater")
    print("greater")
    print("greater")
elif a < 1:
    print("lesser")
    print("lesser")
    print("lesser")
else:
    print("else")
    print("else")
print("OUTSIDE")


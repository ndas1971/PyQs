s = "Hello world"
#print each character and its count 
#frequency operations
# H - 1
#e - 1
#l - 3
#....
#Pick each character, ch1 from s
#    initialize count 
#    Then again pick each char, ch2 , from s 
#        if ch1 and ch2 are same 
#            increment the count 
#    print ch1 and its count 
s = "Hello world"
for ch1 in s:
    count = 0
    for ch2 in s:
        if ch1 == ch2:
            count += 1
    print(f"'{ch1}': {count}")
master_covid_data = { 'usa' : {'+ive': 20, 'test': 200 },
                    'india': {'+ive': 15, 'test': 100 },
                    'zim': {'+ive': 10, 'test': 1 }}

#update today_data into master_covid_data
today_data = {'usa' : {'+ive': 1, 'test': 1.5 },
         'india': {'+ive': 0.75, 'test': 1 },
         'af' : {'+ive': 0, 'test': 0 }}
         
for cn, data in today_data.items():
    if cn in master_covid_data:
        master_covid_data[cn]['+ive'] += data['+ive']
        master_covid_data[cn]['test'] += data['test']
    else:
        master_covid_data[cn] = data.copy()
        
print(master_covid_data)
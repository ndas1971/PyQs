para = """Python is an easy to learn, powerful programming language. It has efficient high-level data structures and a simple but effective approach to object-oriented programming. Python’s elegant syntax and dynamic typing, together with its interpreted nature, make it an ideal language for scripting and rapid application development in many areas on most platforms.
"""
#find the frequency of words 
#dict because key = word and value = count 
#hint- create empty dict, pick each word 
#if that word exists in that dict, increment its value
#if not, create that word as key and initialize its value  

freq = {}
for wd in para.split():
    if wd not in freq:
        freq[wd] = 1
    else:
        freq[wd] += 1
        
print(freq)
#Given input, find output 
input = '[1,2,3,4]'
#output = [1,2,3,4]
#hint - remove prefix[and suffix ]
#split based on , and then individually 
#convert each number from str )

#--- Map starts----- == comprehension
output = []
for e in input.strip('[]').split(","):
    output.append(int(e))
#--- Map ends-----  
print(output)
#check comprehension syntax 
#https://docs.python.org/3/tutorial/index.html

# if name is "XYZ" and age is below 40, 
# print "suitable" else if age is greater
# than 50, print "old", else print "OK"
# For all other names, print "not known" 

#OBJ - write nested if 
#if checking name , inside if checking age 
"""
Ways to take user inputs 
    We get inputs as str, so convert it 
  Using input 
  Using env var 
    set via cmd line as set NEWENV=OK
    import os 
    os.environ is a dict 
    os.environ['NEWENV']
  Using configuration file 
    uses file manipulation 
  Command line argument 
    when we execute like 
        python filename arg1 arg2 
    then it goes to
        sys.argv = ['filename', 'arg1', 'arg2'] 
Error 
    Exception 
    https://docs.python.org/3/library/exceptions.html#exception-hierarchy
    try:
        call method which raises exception 
    except Except1:
        do some 
    except Except2:   
        do something else 
     except Exception:        #Exception is base class.. catch all 
        do something 
     finally:
        do something in finally 
        which gets executed during 
        exception or otherwise 
    

"""

import sys 

default_age = 40 

name = input("Give Name:")
#Y if X else Z 
#=> if X true, do Y else do Z
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError as ex: #ex = ValueError(..)
    print(ex)
    print("Using default value of age")
    age = default_age
    
if name == "XYZ" :
	if age < 40 :
         print("suitable")
	elif age > 50 :
		print("old")
	else :
		print("OK")
else :
	print("not known")
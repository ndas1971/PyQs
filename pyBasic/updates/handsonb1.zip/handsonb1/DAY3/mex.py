def square(x):
    """squaring a number 
    and returning"""
    z = x*x 
    return z 

    
# print(f"""
# Square of 10 = {mex.square(10)}
# """)
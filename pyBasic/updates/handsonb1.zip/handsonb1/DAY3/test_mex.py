import mex

print(f"""
Square of 10 = {mex.square(10)}
""")

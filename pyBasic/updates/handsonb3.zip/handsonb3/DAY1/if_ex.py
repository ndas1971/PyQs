a = 1
#: starts a block 
#in block, lines should be indented else IndentationError
#Tab or space - DONT MIX 
#CS - PEP8- https://peps.python.org/pep-0008/
#Use 4 spaces 

if a >= 1:
    print("greater-equal")
    print("greater-equal")
    print("greater-equal")
elif a < 1 :
    print("lesser")
    print("lesser")
else:
    print("else")
print("OUTSIDE")

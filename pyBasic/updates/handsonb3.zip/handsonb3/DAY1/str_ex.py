s = "Hello World"
#print frequency of each character 
#H - 1
#e - 1
#l - 3 #....
#Pick each char, ch1 from  s 
#    initialize count 
#    Pick each char, ch2, from s
#        if ch1 and ch2 are same 
#            increment count 
#    print ch1 and its count
for ch1 in s:
    count =0
    for ch2 in s:
        if ch1 == ch2:
            count+=1
    print(f"{ch1}, {count}")

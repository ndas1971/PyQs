input = "aaabbcaabdef"
output = "abcdef"
#Use string knowledge 
#hint - use for loop, use empty string 
#use in and use concatenation
output = ""
 
for char in input:
    if char not in output:
        output += char
 
print(output)  


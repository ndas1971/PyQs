lst = ["OK", "NOK", "hello", "hi"]
#TASK1: How many even length string 
#TASk2:What is the total length 
#of all strings 
#--- Map pattern - comprehension 
el = []
for e in lst:
    if len(e)%2 == 0:
        el.append(e)
#OR 
el = [e for e in lst if len(e)%2 == 0]
#----Map ends 
#Reduce pattern 
print(len(el))
#OR 
print(len([e for e in lst if len(e)%2 == 0]))
#--- Map pattern - comprehension 
el = []
for e in lst:
    el.append(len(e))
#OR 
el = [len(e) for e in lst]
#----Map ends 
#Reduce pattern 
print(sum(el))
#https://docs.python.org/2/tutorial/datastructures.html



#count=0
#for ele in lst:
#    if len(ele)%2==0:
#        count+=1
#print(count)
#total_len=0
#for ele in lst:
#    total_len+=len(ele)
#print(total_len)
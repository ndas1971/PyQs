s = "Hello World"
#print frequency of each character 
for ch1 in set(s):
    count =0
    for ch2 in s:
        if ch1 == ch2:
            count+=1
    print(f"{ch1}, {count}")

#TASK1: Write 5 lines of  "hello world" to  "demo.txt" file 
#TASK2: Read "demo.txt" and prepend "#" to each line 
#and write that to "demo.bak.txt"

path = r"demo.txt"
out = ["Hello World\n"] * 5
with open(path, "wt") as f:
    f.writelines(out)

#Read 
with open(path, "rt") as f:
    lines = f.readlines()

#Process - MAP 
out = []
for line in lines:
    out.append(f"#{line}")
    
with open("demo.bak.txt", "wt") as f:
    f.writelines(out)

    
import mex 

print(f"""
square of 10 is {mex.square(10)}
""")

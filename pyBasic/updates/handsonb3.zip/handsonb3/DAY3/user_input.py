"""
4 ways to user input 
        all gives in string 
   Using input 
        uses console sys.stdin 
        NOT recco except password
        Use getpass
   Use env variable for sensitive input 
        >set PASS=ok
        Read it using os.environ['PASS']
   Use configuration file 
        open etc functions 
   Use command line param (RECCO)
        When we execute 
        python filename.py arg1 arg2 
        those goes into 
        sys.argv = ['filename.py', 'arg1', 'arg2' ]
        
Exception 
https://docs.python.org/3/library/exceptions.html#exception-hierarchy
"""
import sys 
default_age = 40 
name = input("Give Name:")
#X if Y else Z => if Y then X else Z 
sage = sys.argv[1] if len(sys.argv) > 1 else default_age
try:
    age = int(sage)
except ValueError as ex: 
    print(ex)
    print("using default age")
    age = default_age
if name == "XYZ":
    if age < 40:
        print("suitable")
    elif age > 50:
        print("old")
    else:
        print("OK")
else:
    print("not known")
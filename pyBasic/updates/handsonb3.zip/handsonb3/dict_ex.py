para = """Python is an easy to learn, powerful programming language. It has efficient high-level data structures and a simple but effective approach to object-oriented programming. Python elegant syntax and dynamic typing, together with its interpreted nature, make it an ideal language for scripting and rapid application development in many areas on most platforms.ECHO is on"""
#freq = dict , key = word, value = count 
#hint - creat a empty dict, pick each word from para 
#if that word does not exist in empty dict, create a #key and initialize, else, increment key's value 
freq = {}
for wd in para.split():
    if wd not in freq:
        freq[wd] = 1 
    else:
        freq[wd] += 1 
print(freq)



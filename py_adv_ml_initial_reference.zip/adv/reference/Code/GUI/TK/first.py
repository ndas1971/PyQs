from tkinter import *

root = Tk()
w = Label(root, text="Hello, world!")
w.pack()			# make it visible
root.mainloop()     #start event main loop 

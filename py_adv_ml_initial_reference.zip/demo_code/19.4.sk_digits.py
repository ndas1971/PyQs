from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

#load the digits dataset, part of the datasets module of scikit-learn. 
#This dataset contains handwritten digits that have been manually labeled

digits = load_digits()
X = digits.data
y = digits.target
#print((X.min(), X.max()))
#print(X.shape)
#(0.0, 16.0)
#(1797, 64)

#In the matrix X, each row contains 8*8=64 pixels (in grayscale, values between 0 and 16). 
#The row-major ordering is used.

#display some of the images along with their labels:

nrows, ncols = 2, 5
fig, axes = plt.subplots(nrows, ncols, figsize=(6, 3))
fig.suptitle("Sample picture from the database")
for i in range(nrows):
    for j in range(ncols):
        # Image index
        k = j + i * ncols
        ax = axes[i, j]
        ax.matshow(digits.images[k, ...],  cmap=plt.cm.gray)
        ax.set_axis_off()
        ax.set_title(digits.target[k])
fig.tight_layout()

#fit a K-nearest neighbors classifier on the data:
(X_train, X_test, y_train, y_test) =  train_test_split(X, y, test_size=.25)
knc = KNeighborsClassifier()
knc.fit(X_train, y_train)

#evaluate the score of the trained classifier on the test dataset:
knc.score(X_test, y_test)
#0.987

#now predict 
# Let's draw a 1.
one = np.zeros((8, 8))
one[1:-1, 4] = 16  # The image values are in [0, 16].
one[2, 3] = 16

fig, ax = plt.subplots(1, 1, figsize=(2, 2))
ax.imshow(one, interpolation='none',  cmap=plt.cm.gray)
ax.grid(False)
ax.set_axis_off()
ax.set_title("Predicting below image: First")

# We need to pass a (1, D) array.
print("Prediction for first:", knc.predict(one.reshape((1, -1))))

#array([1])
#now predict 
# Let's draw a 1.
one = np.zeros((8, 8))
one[1:-1, 4] = 16  # The image values are in [0, 16].
one[2, 3] = 16
one[2, 5] = 16

fig, ax = plt.subplots(1, 1, figsize=(2, 2))
ax.imshow(one, interpolation='none',  cmap=plt.cm.gray)
ax.grid(False)
ax.set_axis_off()
ax.set_title("Predicting below image: Second")

# We need to pass a (1, D) array.
print("Prediction for second:", knc.predict(one.reshape((1, -1))))
#array([1])
from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import nltk
import string

def process_text(text, lower_case = True, stem = False, stop_words = True):    
    message = [char for char in text if char not in string.punctuation]
    message = ''.join(message)     
    if lower_case:
        message = message.lower()
    words = word_tokenize(message)
    words = [w for w in words if len(w) > 2]
    if stop_words:
        sw = stopwords.words('english')
        words = [word for word in words if word not in sw]
    if stem:
        stemmer = PorterStemmer()
        words = [stemmer.stem(word) for word in words]       
    return words

def convert_loc2number(df):
    locations= {'delhi': 0, 'pune': 1, 'hyderabad': 2, 'bengaluru': 3, 'chennai': 4}
    def find(val):
        for k, v in locations.items():
            if k.lower() in val.lower():
                return v
        return 99
    return df.applymap(lambda v: find(v))

data = pd.read_csv("data/Predict-The-Data-Scientists-Salary-In-India_Train_Dataset.csv")

'''
>>> data.dtypes
Unnamed: 0               int64
experience              object
job_description         object
job_desig               object
job_type                object
key_skills              object
location                object
salary                  object
company_name_encoded     int64
dtype: object

>>> data.experience.unique().shape
(129,)
>>> data.location.unique().shape
(1504,)
>>> data.job_type.unique().shape
(6,)
>>> data.salary.unique().shape
(6,)
>>> data.company_name_encoded.unique().shape
(5035,)
>>> data.job_desig.unique().shape
(11708,)

>>> data.iloc[0,:]
Unnamed: 0                                                              0
*experience                                                        5-7 yrs
*job_description         Exp: Minimum 5 years;Good understanding of IOC...
job_desig                     Senior Exploit and Vulnerability Researcher
*job_type                                                              NaN
*key_skills              team skills, communication skills, analytical ...
*location                                            Delhi NCR(Vikas Puri)
*salary                                                              6to10
*company_name_encoded                                                 3687
Name: 0, dtype: object

>>> data.company_name_encoded.value_counts()
190     720
1969    323
1305    235
1988    235
3319    222
       ... 
744       1
4826      1
728       1
4810      1
0         1
#5035 values and sall having 1 to 3 names, but one has 720??
>>> data.company_name_encoded.value_counts().describe()
count    5035.000000
mean        3.932870
std        14.482953
min         1.000000
25%         1.000000
50%         2.000000
75%         3.000000
max       720.000000


#Check  howmany nan in each column 
>>> data.isna().sum(axis=0) 
Unnamed: 0                  0
experience                  0
job_description          4418
job_desig                   0
job_type                15005
key_skills                  1
location                    0
salary                      0
company_name_encoded        0
dtype: int64
data.isna().sum(axis=1)  #in each row 
'''


#Lots of NaN , so delete 
data.drop(['job_description', 'job_type'], axis=1, inplace=True)

sal_encoder = LabelEncoder().fit(data['salary'])
y = sal_encoder.transform(data['salary'])


exp = data['experience'].str.replace("yrs","").str.strip().str.split("-",expand=True)
data["minimum_exp"] = exp.iloc[:,0]
data["maximum_exp"] = exp.iloc[:,1]






column_trans = ColumnTransformer(
    [
        ("stdscaler", 
            StandardScaler(),
            ["minimum_exp", "maximum_exp"]),  # these are orderable, so not categorical 
        #Many categories 
        #("passthrough_numeric", "passthrough",
        #    ["company_name_encoded"]),
        
        ("onhot",             
                OneHotEncoder(),
            ["company_name_encoded"]),
        
        #This we have dropped as many Nans 
        #("imputer_onehot", 
        #    make_pipeline(
        #        SimpleImputer(strategy='constant', fill_value='other'),
        #        OneHotEncoder()
        #        ),
        #    ["job_type"]),
        ("tfidf", 
            Pipeline([
                ('imp', SimpleImputer(strategy='constant', fill_value='other')), 
                ('bow', CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), 
                ('tfidf',TfidfTransformer())]), 
            ["key_skills", 'job_desig']),
        ("loc", 
            make_pipeline(
                FunctionTransformer(func=convert_loc2number),
                OneHotEncoder()),                
            ["location"]),
                
    ],
    remainder="drop",
)

X = column_trans.fit_transform(data)

X_train,  X_test, y_train, y_test  = train_test_split(X, y, test_size = 0.2, random_state = 21)


def print_score(clf):
    print(clf)
    clf.fit(X_train,y_train)
    print("Train score", clf.score(X_train, y_train), #Bias
        "test score", clf.score(X_test, y_test))
    y_pred = clf.predict(X_test)
    print("confusion matrix :\n", confusion_matrix( y_test,y_pred))
    #Printing the accuracy
    print("classication report :\n", classification_report(y_test, y_pred, target_names=sal_encoder.classes_) )

#SGDClassifier can accept sparse matrix 
print_score(SGDClassifier(tol=1e-3)) #default is linear SVC 
print_score(SGDClassifier(loss='log', tol=1e-3, max_iter=5000))
#print_score(GradientBoostingClassifier(n_estimators=1000, learning_rate=0.01,
#    subsample=0.5, max_features = 0.5, 
#    max_depth=4, min_samples_split=2, random_state=0,
#    validation_fraction=0.2,
#    n_iter_no_change=5, tol=1e-3))

#With PCA, takes lots of time 
#clf = SGDClassifier(tol=1e-3, max_iter=5000)
#pipeline = Pipeline([('pca', TruncatedSVD(n_components=int(X.shape[-1]*.50))),('clf', clf)])
#params = dict(clf__alpha = np.logspace(-3,2,20),
#              clf__loss = ['hinge', 'log', 'modified_huber', 'squared_hinge', 'perceptron'],
#              pca__n_components=[int(n) for n in [X.shape[-1]*.50, X.shape[-1]*.8, X.shape[-1]*.3]])
#
#
##Takes lot of time 
#cv = CV= KFold(n_splits=3,shuffle=True)
#gs = RandomizedSearchCV(pipeline, params, cv=cv)
#print_score(gs)
#print(gs.best_estimator_)


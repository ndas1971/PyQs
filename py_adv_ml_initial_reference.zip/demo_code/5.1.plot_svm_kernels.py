#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
=========================================================
SVM-Kernels
=========================================================

Three different types of SVM-Kernels are displayed below.
The polynomial and RBF are especially useful when the
data-points are not linearly separable.


"""
print(__doc__)
import warnings
warnings.filterwarnings("ignore")




# Code source: Gaël Varoquaux
# License: BSD 3 clause

import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm
from sklearn import metrics

# Our dataset and targets
X = np.c_[(.4, -.7),
          (-1.5, -1),
          (-1.4, -.9),
          (-1.3, -1.2),
          (-1.1, -.2),
          (-1.2, -.4),
          (-.5, 1.2),
          (-1.5, 2.1),
          (1, 1),
          # --
          (1.3, .8),
          (1.2, .5),
          (.2, -2),
          (.5, -2.4),
          (.2, -2.3),
          (0, -2.7),
          (1.3, 2.1)].T
Y = [0] * 8 + [1] * 8

# figure number
fig, ax = plt.subplots(3, 3)
Cs = [0.01, 1, 10]
print("---------------- SVC of binary class ------------------")
print("""
Some properties of Classifier
-------------------------------
clf.coef_       
    Coefficients for each feature 
    only for linear problem
clf.support_
    SupportVectorIndices 
    Vector of indices that specify the rows in the training data X, 
    that were selected as support vectors 
clf.support_vectors_  
    are subset of features (rows of X) which are used for decision boundary
clf.n_support_ 
    get number of support vectors for each class

clf.decision_function
    decision function that tells us how close to the seperating line we are 
    (close to the boundary means a low-confidence decision)
    Returns (n_samples, n_classes * (n_classes-1) / 2) for ovo, 
    for ovr, the shape is (n_samples, n_classes).
    each value is proportional to the distance of the each Sample 
    to the separating hyperplane
    
    Note SVC is inherently binary 
    to make it multiclass, by default OneVsOne ie requires to fit 
    n_classes * (n_classes - 1) / 2 classifiers
    This strategy consists in fitting one classifier per class pair. 
    Note other methods is OneVsRest, this strategy consists in fitting 
    one classifier per class. 
    For each classifier, the class is fitted against all the other classes.
    At prediction time, the class which received the most votes is selected
    ie
    cs = list of class names
    votes = [(i if decision[p] > 0 else j) for p,(i,j) in enumerate((i,j) 
                                               for i in range(len(cs))
                                               for j in range(i+1,len(cs)))]
    return cs[max(set(votes), key=votes.count)]

    
    
Doubled circle means, those points are participated 
in hyperplan calculation- called support vectors

any mis colored point means mis classifications

Solid line is hyperplan seperating two classes, 
dotted lines are two contour lines of hyperplan
(can be taken as +/- 10% boundary of hyperplan)
""")
# fit the model
for i, kernel in enumerate(['linear', 'poly', 'rbf']):
    for j, C in enumerate(Cs):
        clf = svm.SVC(kernel=kernel, gamma=2, C=C)
        clf.fit(X, Y)        
        #plot computed support vector x, y ie nearest vectors to the plane
        #s = marker size , so support vectors are bigger 
        ax[i,j].scatter(clf.support_vectors_[:, 0], clf.support_vectors_[:, 1], s=80,
                facecolors='none', zorder=10, edgecolors='k')
        #Plot original x, y, c=index to cmap, which is Paired ie has two colors based on true Y 
        #s = default size 
        ax[i,j].scatter(X[:, 0], X[:, 1], c=Y, zorder=10, cmap=plt.cm.Paired,
                edgecolors='k')

        ax[i,j].axis('tight')
        x_min = -3
        x_max = 3
        y_min = -3
        y_max = 3

        XX, YY = np.mgrid[x_min:x_max:200j, y_min:y_max:200j]
        Z = clf.decision_function(np.c_[XX.ravel(), YY.ravel()])

        # Put the result into a color plot
        Z = Z.reshape(XX.shape)
        #plt.cm.Paired for two color, 'k' means black 
        #Since it is binary with hyperplan 0,0, hence Z>0 means one side or Z <0 means other side 
        ax[i,j].pcolormesh(XX, YY, Z > 0, cmap=plt.cm.Paired)
        ax[i,j].contour(XX, YY, Z, colors=['k', 'k', 'k'], linestyles=['--', '-', '--'],
                levels=[-.5, 0, .5])

        ax[i,j].set_xlim(x_min, x_max)
        ax[i,j].set_ylim(y_min, y_max)

        ax[i,j].set_xticks(())
        ax[i,j].set_yticks(())
        ax[i,j].set_title("%s:%3.2f" % (kernel, C) )
        print("Acc %s:C:%3.2f - %4.3f" % (kernel, C, metrics.accuracy_score(Y, clf.predict(X))))
plt.tight_layout()
plt.show()
